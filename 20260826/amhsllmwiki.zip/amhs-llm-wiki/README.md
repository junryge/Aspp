# AMHS LLM-WIKI 지식정보 시스템

Andrej Karpathy의 [llm-wiki](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f)
([긱뉴스](https://news.hada.io/topic?id=28208)) 스펙을 AMHS 현장에 맞춘 지식 시스템.

담당자들이 **양식에 맞게 작성**하고, MD/PDF/이미지/TXT/CSV 원본을 넣으면
LLM이 **관련 페이지까지 같이 갱신**해서 지식이 복리로 쌓인다.

- Python + HTML (Flask 모놀리식 단일 파일, 외부 CDN 없음) — 브라우저로 접속
- LLM은 **Claude 아님, OpenAI 호환 API** — 사내 게이트웨이 주소를 설정 화면에 입력
- 폐쇄망 기준: pip-only, Node/Docker 불필요
- 담당 구분 = **FAB** (공통 / M14 / M14B / M16A / M16B / M16HUB), 설비(OHT·AGV·CNV·MCS)는 태그

## 1. 설치 / 실행

```bash
pip install flask          # 필수
pip install pypdf          # 선택: PDF 텍스트 추출
python app.py              # http://0.0.0.0:8100
```

| 환경변수 | 기본값 | 설명 |
|---|---|---|
| `LLM_WIKI_PORT` | 8100 | 웹 포트 |
| `LLM_WIKI_HOST` | 0.0.0.0 | 바인드 주소 |
| `LLM_WIKI_DATA` | ./data | 데이터 디렉토리 |
| `LLM_WIKI_SECRET` | (랜덤) | 세션 키 — 운영 시 고정값 권장 |

폐쇄망 반입: 폴더 zip → base64 → 내부망 → 압축 해제. 전부 순수 파이썬이라 휠 반입도 간단.

## 2. 구조 — 카파시 3-layer

```
data/
├─ sources/<FAB>/               원본 자료 (불변 — 진실의 출처)
├─ wiki/
│   ├─ index.md                 전체 카탈로그 (자동 생성)
│   ├─ log.md                   활동 로그, append-only (자동 생성)
│   └─ <FAB>/<타입>/*.md        지식 페이지 (프론트매터 포함)
├─ schema/schema.md             작성 규칙 (원문의 CLAUDE.md 역할)
└─ wiki.db                      SQLite
```

**페이지 타입**: `concept`(주제·절차) / `entity`(호기·구간·시스템) / `source`(원본 1건 요약)

## 3. 연산 (카파시 스펙)

| 연산 | 화면 | 하는 일 |
|---|---|---|
| **ingest** | 소스 상세 → [Ingest 실행] | ① 소스 요약 페이지 생성 ② **관련 기존 페이지 5~15개 갱신안 생성** ③ 검토 후 선택 적용 ④ 로그 기록 |
| **query** | 담당 노트북 / [질문] | 위키·소스에서 근거 검색 → 출처 명시 답변 → 좋은 답변은 노트로 저장 |
| **lint** | [린트] | 깨진 링크·고아 페이지·빈 요약·180일 미갱신·**미반영 소스** + LLM 모순/중복 점검 |
| **index** | [카탈로그] | 타입·FAB별 한줄요약 카탈로그 (index.md 자동 생성) |
| **log** | [로그] | `## [DATE] op \| Title` 형식 append-only 기록 |

> ingest가 이 시스템의 핵심이다. 소스 1건이 위키 여러 페이지에 퍼지면서 지식이 누적된다.
> **LLM이 자동 반영하지 않는다** — 전부 담당자가 체크한 것만 적용된다.

## 4. 운영 흐름

1. **설정**에서 LLM 주소 입력 + FAB/양식을 조직에 맞게 조정
2. 담당자에게 URL 배포 → 각자 FAB 노트북에서:
   - 자료 업로드 → **Ingest 실행** → 검토 후 적용
   - **양식으로 작성** 버튼 → 섹션별 폼 채우기 (LLM 없이도 됨)
   - 소스 체크 → **질문** → 좋은 답변은 노트로 저장
3. **린트** 주기적으로 돌려서 품질 관리
4. **내보내기** → 담당별 MD zip / combined.md (RAG·파인튜닝·이관용)

## 5. LLM 설정

설정 화면에 OpenAI 호환 주소 입력 (끝에 `/v1`까지):

```
API Base URL: http://<사내 추론서버 또는 게이트웨이>/v1
모델명:       <서버에 로드된 모델 ID>
API Key:      (필요한 경우만)
```

`/v1/chat/completions`만 사용. vLLM·llama.cpp server·사내 게이트웨이 전부 호환.
**LLM 없이도** 작성·검색·카탈로그·린트(규칙)·내보내기는 다 동작한다.

## 6. MCP 연동

**① 동봉된 MCP 서버** (웹앱 꺼져 있어도 DB 직접 읽어서 동작)

```bash
pip install "mcp>=1.27,<2"
python mcp_server.py        # streamable-http, http://<주소>:8020/mcp
```

도구: `listDomains` / `searchWiki(query, topK)` / `readPage(pageId)` /
`listSources(domainSlug)` / `readSource(sourceId)`

**② JSON API**

```
GET  /api/health · /api/domains · /api/pages?domain=<slug> · /api/page/<id>
GET  /api/search?q=<검색어>&k=5 · /api/sources · /api/source/<id>
POST /api/ask   {"question": "..."}
```

## 7. 파일 구성

| 파일 | 설명 |
|---|---|
| `app.py` | 웹앱 전체 (Flask + 템플릿 + BM25 + 마크다운 렌더러 + ingest/lint + LLM 클라이언트) |
| `mcp_server.py` | MCP 서버 (FastMCP, streamable-http :8020) |
| `requirements.txt` | 의존성 |

## 8. 기존 설치 업그레이드

`pages` 테이블에 `ptype` / `source_ids` 컬럼이 자동 추가된다(마이그레이션 내장).
기존 페이지는 전부 `concept`으로 들어간다. `data/` 그대로 두고 app.py만 교체하면 된다.
