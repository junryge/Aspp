# -*- coding: utf-8 -*-
"""
LLM-WIKI — LLM 도메인 학습용 사내 지식 위키 (Flask 모놀리식 단일 파일)

개념: Karpathy llm-wiki (3-layer)
  1) sources/  원본 데이터 (불변, MD/PDF/이미지/TXT/CSV)
  2) wiki/     LLM/사람이 유지하는 마크다운 페이지 (지식 자산)
  3) schema/   작성 규칙 (schema.md)

특징:
  - 담당(도메인)별 관리 + 양식(템플릿) 기반 작성 폼 → 담당자 배포용
  - MD/PDF/이미지/TXT/CSV 업로드 → 텍스트 추출 → 소스 등록
  - OpenAI 호환 API LLM 연동 (사내 게이트웨이 주소를 설정 화면에서 입력)
    · 소스 → 위키 초안 생성  · 위키 기반 QA  · 린트(품질 점검)
  - BM25 검색 (stdlib 구현), 리비전 이력, 전체 export
  - MCP 연동 대비 JSON API (/api/*) + 동봉된 mcp_server.py

의존성: Flask (필수), pypdf (선택: PDF 텍스트 추출)
폐쇄망 기준: Node/Docker 불필요, pip-only, 외부 CDN 없음
"""
import csv
import io
import json
import math
import os
import re
import secrets
import sqlite3
import urllib.request
import urllib.error
import urllib.parse
import zipfile
from collections import Counter
from datetime import datetime, timedelta
from pathlib import Path

from flask import (Flask, g, request, redirect, url_for, flash, session,
                   send_file, jsonify, render_template, abort, Response)
from jinja2 import DictLoader
from werkzeug.utils import secure_filename

# ---------------------------------------------------------------- 경로/설정
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("LLM_WIKI_DATA", BASE_DIR / "data"))
DB_PATH = DATA_DIR / "wiki.db"
SRC_DIR = DATA_DIR / "sources"
WIKI_DIR = DATA_DIR / "wiki"
SCHEMA_DIR = DATA_DIR / "schema"
SCHEMA_FILE = SCHEMA_DIR / "schema.md"

TEXT_EXT = {".md", ".txt", ".log"}
CSV_EXT = {".csv", ".tsv"}
PDF_EXT = {".pdf"}
IMG_EXT = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}
ALLOWED_EXT = TEXT_EXT | CSV_EXT | PDF_EXT | IMG_EXT
MAX_UPLOAD_MB = 100

DRAFT_CACHE = {}  # LLM 초안 임시 저장 (token -> markdown)


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


# ---------------------------------------------------------------- DB
def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def get_db():
    if "db" not in g:
        g.db = _connect()
    return g.db


SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS domains(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  description TEXT DEFAULT '',
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS templates(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  domain_id INTEGER,
  name TEXT NOT NULL,
  sections TEXT NOT NULL,
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS pages(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  domain_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  slug TEXT NOT NULL,
  tags TEXT DEFAULT '',
  summary TEXT DEFAULT '',
  body_md TEXT DEFAULT '',
  author TEXT DEFAULT '',
  created_at TEXT,
  updated_at TEXT
);
CREATE TABLE IF NOT EXISTS revisions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  page_id INTEGER NOT NULL,
  title TEXT,
  body_md TEXT,
  author TEXT,
  saved_at TEXT
);
CREATE TABLE IF NOT EXISTS sources(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  domain_id INTEGER NOT NULL,
  filename TEXT,
  stored_name TEXT,
  filetype TEXT,
  description TEXT DEFAULT '',
  extracted_text TEXT DEFAULT '',
  uploader TEXT DEFAULT '',
  created_at TEXT
);
CREATE TABLE IF NOT EXISTS settings(
  key TEXT PRIMARY KEY,
  value TEXT
);
"""

DEFAULT_DOMAINS = [
    ("common", "공통", "전 담당 공통 지식 (조직/시스템 개요, 공용 용어)"),
    ("oht", "OHT", "OHT 반송 관련 지식"),
    ("agv", "AGV", "AGV 반송 관련 지식"),
    ("cnv", "CNV", "컨베이어 반송 관련 지식"),
    ("mcs", "MCS", "MCS 제어/로그 관련 지식"),
]

DEFAULT_TEMPLATES = [
    ("기본 지식 양식", [
        {"title": "개요", "guide": "이 주제가 무엇이고 왜 중요한지 3~5문장으로. 처음 보는 사람 기준으로 작성"},
        {"title": "핵심 용어 정의", "guide": "'- 용어: 정의' 형태로 나열. LLM이 그대로 학습할 수 있게 명확하게"},
        {"title": "프로세스 / 절차", "guide": "단계별로 번호를 붙여 서술. 조건 분기는 '만약 ~이면' 형태로"},
        {"title": "데이터 / 지표", "guide": "관련 테이블·로그·지표의 이름과 의미. 단위를 반드시 명시"},
        {"title": "장애 / 사례", "guide": "실제 발생 사례를 현상 → 원인 → 조치 순서로"},
        {"title": "FAQ", "guide": "신입/타 담당이 자주 묻는 질문과 답"},
        {"title": "참고 소스", "guide": "근거가 된 문서/파일명. 업로드한 소스 번호(#id) 기재"},
    ]),
    ("장애 사례 양식", [
        {"title": "현상", "guide": "언제, 어디서, 무엇이 발생했는지. 시각/호기/구간 명시"},
        {"title": "원인 분석", "guide": "근본 원인. 확정과 추정을 구분해 표기 — 추정이면 '(추정)' 붙이기"},
        {"title": "조치 내용", "guide": "시간 순서대로 조치 내역"},
        {"title": "재발 방지", "guide": "시스템/절차 개선 사항"},
        {"title": "교훈", "guide": "다음 담당자가 반드시 알아야 할 핵심 한두 줄"},
    ]),
]

DEFAULT_SCHEMA_MD = """# LLM-WIKI 작성 규칙 (schema)

이 문서는 위키 전체의 작성 규칙이다. 사람과 LLM 모두 이 규칙을 따른다.

## 구조 (3-layer)
1. **sources/** — 원본 데이터. 업로드된 파일은 수정하지 않는다 (불변, 근거 자료)
2. **wiki/** — 지식 페이지 (마크다운). 소스를 근거로 사람/LLM이 작성·갱신
3. **schema/** — 이 규칙 문서

## 페이지 작성 규칙
- **1주제 1페이지**: 한 페이지는 하나의 주제만 다룬다
- **한줄요약 필수**: 검색과 LLM 컨텍스트 선별에 그대로 쓰인다
- **용어는 정의 목록으로**: `- 용어: 정의` 형태. 사내 약어는 풀네임 병기
- **사실과 추정 구분**: 확인 안 된 내용은 문장 끝에 `(추정)` 표기
- **근거 명시**: 참고한 소스 파일/번호를 페이지에 기재
- **상호 연결**: 관련 페이지는 `[[페이지제목]]` 위키링크로 연결
- **갱신 우선**: 새 페이지 남발보다 기존 페이지를 갱신·통합한다

## LLM 사용 규칙
- LLM이 생성한 초안은 반드시 담당자가 검토 후 저장한다
- LLM 답변(QA)은 위키에 있는 내용만 근거로 하고, 출처 페이지를 명시한다
- 요약의 요약을 반복해 원본 정보가 희석되지 않게, 수치·조건은 원문 그대로 유지
"""


def seed_settings(conn):
    defaults = {
        "site_name": "LLM-WIKI",
        "llm_base_url": "",
        "llm_model": "",
        "llm_api_key": "",
    }
    for k, v in defaults.items():
        conn.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (k, v))


def init_db():
    for d in (DATA_DIR, SRC_DIR, WIKI_DIR, SCHEMA_DIR):
        d.mkdir(parents=True, exist_ok=True)
    conn = _connect()
    conn.executescript(SCHEMA_SQL)
    if conn.execute("SELECT COUNT(*) c FROM domains").fetchone()["c"] == 0:
        for slug, name, desc in DEFAULT_DOMAINS:
            conn.execute(
                "INSERT INTO domains(slug,name,description,created_at) VALUES(?,?,?,?)",
                (slug, name, desc, now_str()))
    if conn.execute("SELECT COUNT(*) c FROM templates").fetchone()["c"] == 0:
        for name, sections in DEFAULT_TEMPLATES:
            conn.execute(
                "INSERT INTO templates(domain_id,name,sections,created_at) VALUES(NULL,?,?,?)",
                (name, json.dumps(sections, ensure_ascii=False), now_str()))
    seed_settings(conn)
    conn.commit()
    conn.close()
    if not SCHEMA_FILE.exists():
        SCHEMA_FILE.write_text(DEFAULT_SCHEMA_MD, encoding="utf-8")


def get_setting(key, default=""):
    row = get_db().execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    return row["value"] if row and row["value"] is not None else default


def set_setting(key, value):
    get_db().execute(
        "INSERT INTO settings(key,value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
    get_db().commit()


# ---------------------------------------------------------------- 유틸
def slugify(s):
    s = re.sub(r"[^\w가-힣\- ]", "", (s or "").strip())
    s = re.sub(r"[\s_]+", "-", s).strip("-").lower()
    return s[:80] or "page"


def unique_page_slug(domain_id, title, exclude_id=None):
    base = slugify(title)
    slug, n = base, 2
    db = get_db()
    while True:
        q = "SELECT id FROM pages WHERE domain_id=? AND slug=?"
        args = [domain_id, slug]
        if exclude_id:
            q += " AND id<>?"
            args.append(exclude_id)
        if not db.execute(q, args).fetchone():
            return slug
        slug = f"{base}-{n}"
        n += 1


def tokenize(text):
    toks = []
    for m in re.findall(r"[0-9A-Za-z_]+|[가-힣]+", (text or "").lower()):
        toks.append(m)
        if re.match(r"[가-힣]", m) and len(m) > 1:
            toks.extend(m[i:i + 2] for i in range(len(m) - 1))
    return toks


def bm25_search(query, docs, k=10):
    """docs: list of dicts {id, kind, title, text, ...}. return [(score, doc)]"""
    q = set(tokenize(query))
    if not q or not docs:
        return []
    dtoks, df = [], Counter()
    for d in docs:
        t = tokenize((d["title"] + " ") * 3 + (d.get("text") or ""))
        dtoks.append(t)
        for w in set(t):
            df[w] += 1
    N = len(docs)
    avgdl = max(1.0, sum(len(t) for t in dtoks) / N)
    k1, b = 1.5, 0.75
    scored = []
    for i, t in enumerate(dtoks):
        tf = Counter(t)
        dl = len(t) or 1
        s = 0.0
        for w in q:
            f = tf.get(w, 0)
            if not f:
                continue
            idf = math.log(1 + (N - df[w] + 0.5) / (df[w] + 0.5))
            s += idf * f * (k1 + 1) / (f + k1 * (1 - b + b * dl / avgdl))
        if s > 0:
            scored.append((s, docs[i]))
    scored.sort(key=lambda x: -x[0])
    return scored[:k]


def all_search_docs(domain_id=None, include_sources=True):
    db = get_db()
    docs = []
    q = ("SELECT p.id,p.title,p.summary,p.body_md,p.tags,d.name dname,d.slug dslug "
         "FROM pages p JOIN domains d ON d.id=p.domain_id")
    args = []
    if domain_id:
        q += " WHERE p.domain_id=?"
        args.append(domain_id)
    for r in db.execute(q, args):
        docs.append({"id": r["id"], "kind": "page", "title": r["title"],
                     "text": f"{r['tags']} {r['summary']} {r['body_md']}",
                     "domain": r["dname"], "summary": r["summary"]})
    if include_sources:
        q2 = ("SELECT s.id,s.filename,s.description,s.extracted_text,d.name dname "
              "FROM sources s JOIN domains d ON d.id=s.domain_id")
        args2 = []
        if domain_id:
            q2 += " WHERE s.domain_id=?"
            args2.append(domain_id)
        for r in db.execute(q2, args2):
            docs.append({"id": r["id"], "kind": "source", "title": r["filename"] or "",
                         "text": f"{r['description']} {r['extracted_text'] or ''}"[:20000],
                         "domain": r["dname"], "summary": (r["description"] or "")[:200]})
    return docs


# ---------------------------------------------------------------- 마크다운 렌더러 (stdlib)
import html as html_mod


def _md_inline(s):
    s = html_mod.escape(s, quote=False)
    codes = []

    def _stash(m):
        codes.append(m.group(1))
        return f"\x00{len(codes)-1}\x00"

    s = re.sub(r"`([^`]+)`", _stash, s)
    s = re.sub(r"!\[([^\]]*)\]\(([^)\s]+)\)",
               r'<img src="\2" alt="\1" style="max-width:100%">', s)
    s = re.sub(r"\[\[([^\]|]+)\]\]",
               lambda m: '<a class="wikilink" href="/page/t/%s">%s</a>' % (
                   urllib.parse.quote(m.group(1).strip()), m.group(1).strip()), s)
    s = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)", r'<a href="\2">\1</a>', s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"(?<!\*)\*([^*\n]+)\*(?!\*)", r"<em>\1</em>", s)
    s = re.sub(r"\x00(\d+)\x00", lambda m: "<code>%s</code>" % codes[int(m.group(1))], s)
    return s


def md_to_html(text):
    if not text:
        return ""
    lines = text.replace("\r\n", "\n").split("\n")
    out, i, n = [], 0, len(lines)
    para = []

    def flush():
        if para:
            out.append("<p>" + "<br>".join(_md_inline(x) for x in para) + "</p>")
            para.clear()

    while i < n:
        ln = lines[i]
        # fenced code
        if ln.strip().startswith("```"):
            flush()
            buf = []
            i += 1
            while i < n and not lines[i].strip().startswith("```"):
                buf.append(lines[i])
                i += 1
            i += 1
            out.append("<pre><code>%s</code></pre>" % html_mod.escape("\n".join(buf)))
            continue
        # header
        m = re.match(r"^(#{1,6})\s+(.*)$", ln)
        if m:
            flush()
            lvl = len(m.group(1))
            out.append(f"<h{lvl}>{_md_inline(m.group(2))}</h{lvl}>")
            i += 1
            continue
        # hr
        if re.match(r"^\s*(-{3,}|\*{3,})\s*$", ln):
            flush()
            out.append("<hr>")
            i += 1
            continue
        # table
        if ln.strip().startswith("|") and i + 1 < n and re.match(r"^\s*\|?[\s:|-]+\|?\s*$", lines[i + 1]):
            flush()
            header = [c.strip() for c in ln.strip().strip("|").split("|")]
            i += 2
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            t = "<table><thead><tr>" + "".join(f"<th>{_md_inline(c)}</th>" for c in header) + "</tr></thead><tbody>"
            for r in rows:
                t += "<tr>" + "".join(f"<td>{_md_inline(c)}</td>" for c in r) + "</tr>"
            t += "</tbody></table>"
            out.append('<div class="tablewrap">%s</div>' % t)
            continue
        # blockquote
        if ln.startswith(">"):
            flush()
            buf = []
            while i < n and lines[i].startswith(">"):
                buf.append(re.sub(r"^>\s?", "", lines[i]))
                i += 1
            out.append("<blockquote>%s</blockquote>" % "<br>".join(_md_inline(x) for x in buf))
            continue
        # unordered list
        if re.match(r"^\s*[-*]\s+", ln):
            flush()
            items = []
            while i < n and re.match(r"^\s*[-*]\s+", lines[i]):
                items.append(re.sub(r"^\s*[-*]\s+", "", lines[i]))
                i += 1
            out.append("<ul>" + "".join(f"<li>{_md_inline(x)}</li>" for x in items) + "</ul>")
            continue
        # ordered list
        if re.match(r"^\s*\d+[.)]\s+", ln):
            flush()
            items = []
            while i < n and re.match(r"^\s*\d+[.)]\s+", lines[i]):
                items.append(re.sub(r"^\s*\d+[.)]\s+", "", lines[i]))
                i += 1
            out.append("<ol>" + "".join(f"<li>{_md_inline(x)}</li>" for x in items) + "</ol>")
            continue
        # blank
        if not ln.strip():
            flush()
            i += 1
            continue
        para.append(ln)
        i += 1
    flush()
    return "\n".join(out)


# ---------------------------------------------------------------- 파일 추출
def read_text_file(path: Path):
    raw = path.read_bytes()
    for enc in ("utf-8", "cp949", "euc-kr"):
        try:
            return raw.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("utf-8", errors="replace")


def extract_csv(path: Path, max_rows=30):
    txt = read_text_file(path)
    delim = "\t" if path.suffix.lower() == ".tsv" else ","
    try:
        delim = csv.Sniffer().sniff(txt[:2000]).delimiter
    except csv.Error:
        pass
    rows = list(csv.reader(io.StringIO(txt), delimiter=delim))
    if not rows:
        return "(빈 파일)"
    header, body = rows[0], rows[1:]
    ncol = len(header)
    md = ["| " + " | ".join(c.replace("|", "\\|") for c in header) + " |",
          "|" + "---|" * ncol]
    for r in body[:max_rows]:
        r = (r + [""] * ncol)[:ncol]
        md.append("| " + " | ".join(c.replace("|", "\\|") for c in r) + " |")
    info = f"\n\n(총 {len(body)}행 × {ncol}열"
    if len(body) > max_rows:
        info += f", 위는 앞 {max_rows}행 미리보기"
    info += ")"
    return "\n".join(md) + info


def extract_pdf(path: Path):
    try:
        from pypdf import PdfReader
    except ImportError:
        return None, "pypdf 미설치 — 'pip install pypdf' 후 재업로드하면 텍스트가 추출된다"
    try:
        reader = PdfReader(str(path))
        parts = []
        for pi, pg in enumerate(reader.pages):
            t = (pg.extract_text() or "").strip()
            if t:
                parts.append(f"[p.{pi+1}]\n{t}")
        return "\n\n".join(parts), None
    except Exception as e:
        return None, f"PDF 추출 실패: {e}"


def extract_source(path: Path):
    """returns (filetype, extracted_text, warn)"""
    ext = path.suffix.lower()
    if ext in TEXT_EXT:
        return "text", read_text_file(path), None
    if ext in CSV_EXT:
        return "csv", extract_csv(path), None
    if ext in PDF_EXT:
        txt, warn = extract_pdf(path)
        return "pdf", (txt or ""), warn
    if ext in IMG_EXT:
        return "image", "", None
    return "other", "", None


# ---------------------------------------------------------------- 위키 파일 미러 (지식 자산 레이어)
def page_frontmatter(p, domain_name):
    tags = ", ".join(t.strip() for t in (p["tags"] or "").split(",") if t.strip())
    return ("---\n"
            f"title: {p['title']}\n"
            f"domain: {domain_name}\n"
            f"tags: [{tags}]\n"
            f"summary: {p['summary']}\n"
            f"author: {p['author']}\n"
            f"updated: {p['updated_at']}\n"
            "---\n\n")


def write_page_file(page_id):
    db = get_db()
    p = db.execute("SELECT p.*, d.slug dslug, d.name dname FROM pages p "
                   "JOIN domains d ON d.id=p.domain_id WHERE p.id=?", (page_id,)).fetchone()
    if not p:
        return
    d = WIKI_DIR / p["dslug"]
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{p['slug']}.md").write_text(
        page_frontmatter(p, p["dname"]) + (p["body_md"] or ""), encoding="utf-8")


def sync_all_wiki_files():
    """wiki/ 디렉토리를 DB 기준으로 전체 재생성 (export 시 호출)"""
    import shutil
    if WIKI_DIR.exists():
        shutil.rmtree(WIKI_DIR)
    WIKI_DIR.mkdir(parents=True, exist_ok=True)
    db = get_db()
    for p in db.execute("SELECT id FROM pages"):
        write_page_file(p["id"])


def find_backlinks(title):
    db = get_db()
    inner = title.replace("~", "~~").replace("%", "~%").replace("_", "~_")
    pat = "%~[~[" + inner + "~]~]%"
    return db.execute(
        "SELECT p.id,p.title,d.name dname FROM pages p JOIN domains d ON d.id=p.domain_id "
        "WHERE p.body_md LIKE ? ESCAPE '~'", (pat,)).fetchall()


# ---------------------------------------------------------------- LLM (OpenAI 호환 API)
def llm_ready():
    return bool(get_setting("llm_base_url") and get_setting("llm_model"))


def llm_chat(messages, max_tokens=2500, temperature=0.3):
    base = get_setting("llm_base_url").rstrip("/")
    model = get_setting("llm_model")
    key = get_setting("llm_api_key")
    if not base or not model:
        raise RuntimeError("LLM 설정이 비어있다. [설정]에서 API 주소와 모델명을 입력해라.")
    url = base + "/chat/completions"
    body = json.dumps({"model": model, "messages": messages,
                       "max_tokens": max_tokens, "temperature": temperature}).encode()
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = "Bearer " + key
    req = urllib.request.Request(url, data=body, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            data = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"LLM API HTTP {e.code}: {e.read()[:300]!r}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"LLM API 접속 실패: {e.reason}")
    try:
        return data["choices"][0]["message"]["content"]
    except (KeyError, IndexError):
        raise RuntimeError(f"LLM 응답 형식 이상: {str(data)[:300]}")


def schema_text():
    return SCHEMA_FILE.read_text(encoding="utf-8") if SCHEMA_FILE.exists() else DEFAULT_SCHEMA_MD


def llm_draft_from_source(src, template_sections):
    sec_desc = "\n".join(f"## {s['title']}\n({s['guide']})" for s in template_sections)
    text = (src["extracted_text"] or "")[:9000]
    if not text.strip():
        raise RuntimeError("이 소스는 추출된 텍스트가 없다 (이미지/추출실패). 설명을 먼저 입력해라.")
    sys_p = ("너는 사내 지식위키(LLM-WIKI) 작성 보조다. 아래 작성 규칙을 따르고, "
             "주어진 소스 내용만 근거로 위키 페이지 초안을 한국어 마크다운으로 작성해라. "
             "소스에 없는 내용은 지어내지 말고, 불확실하면 '(추정)'을 붙여라.\n\n"
             "=== 작성 규칙 ===\n" + schema_text()[:3000] +
             "\n\n=== 출력 형식 ===\n순수 마크다운 본문만 출력. 아래 섹션 구성을 따라라:\n" + sec_desc)
    user_p = f"[소스 파일: {src['filename']}]\n[소스 설명: {src['description'] or '없음'}]\n\n{text}"
    return llm_chat([{"role": "system", "content": sys_p},
                     {"role": "user", "content": user_p}])


def llm_answer(question, top_docs):
    ctx_parts = []
    for score, d in top_docs:
        body = (d.get("text") or "")[:3000]
        ctx_parts.append(f"### [{d['kind']}#{d['id']}] {d['title']} (담당: {d['domain']})\n{body}")
    ctx = "\n\n".join(ctx_parts) if ctx_parts else "(검색된 문서 없음)"
    sys_p = ("너는 사내 지식위키(LLM-WIKI) QA 어시스턴트다. 아래 위키 문서 발췌만 근거로 "
             "한국어로 답해라. 근거가 없으면 '위키에 근거 자료가 없다'고 말해라. "
             "답변 끝에 참고한 문서를 [page#번호 제목] 형태로 명시해라.")
    user_p = f"=== 위키 발췌 ===\n{ctx}\n\n=== 질문 ===\n{question}"
    return llm_chat([{"role": "system", "content": sys_p},
                     {"role": "user", "content": user_p}], max_tokens=2000)


# ---------------------------------------------------------------- 린트 (규칙 기반)
def run_lint():
    db = get_db()
    pages = db.execute("SELECT p.*, d.name dname FROM pages p JOIN domains d ON d.id=p.domain_id").fetchall()
    titles = {p["title"] for p in pages}
    linked = set()
    issues = []
    for p in pages:
        for m in re.findall(r"\[\[([^\]|]+)\]\]", p["body_md"] or ""):
            t = m.strip()
            linked.add(t)
            if t not in titles:
                issues.append({"page_id": p["id"], "title": p["title"], "level": "warn",
                               "msg": f"깨진 위키링크: [[{t}]] — 대상 페이지가 없다"})
    cutoff = datetime.now() - timedelta(days=180)
    for p in pages:
        if not (p["summary"] or "").strip():
            issues.append({"page_id": p["id"], "title": p["title"], "level": "warn",
                           "msg": "한줄요약이 비어있다 (검색/LLM 컨텍스트 품질 저하)"})
        if len((p["body_md"] or "").strip()) < 200:
            issues.append({"page_id": p["id"], "title": p["title"], "level": "info",
                           "msg": f"본문이 빈약하다 ({len((p['body_md'] or '').strip())}자)"})
        if p["title"] not in linked and len(pages) > 1:
            issues.append({"page_id": p["id"], "title": p["title"], "level": "info",
                           "msg": "고아 페이지 — 다른 페이지에서 [[링크]]되지 않음"})
        try:
            upd = datetime.strptime(p["updated_at"], "%Y-%m-%d %H:%M")
            if upd < cutoff:
                issues.append({"page_id": p["id"], "title": p["title"], "level": "info",
                               "msg": f"180일 이상 미갱신 (마지막: {p['updated_at']})"})
        except (ValueError, TypeError):
            pass
    return issues


# ---------------------------------------------------------------- Flask 앱
app = Flask(__name__)
app.secret_key = os.environ.get("LLM_WIKI_SECRET", secrets.token_hex(16))
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_MB * 1024 * 1024


@app.teardown_appcontext
def _close_db(exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


@app.template_filter("md")
def _f_md(text):
    return md_to_html(text)


@app.template_filter("nl2br")
def _f_nl2br(text):
    return html_mod.escape(text or "").replace("\n", "<br>")


@app.context_processor
def _ctx():
    db = get_db()
    domains = db.execute("SELECT * FROM domains ORDER BY id").fetchall()
    return {"nav_domains": domains, "site_name": get_setting("site_name", "LLM-WIKI"),
            "llm_ok": llm_ready()}


# ---------------------------------------------------------------- 라우트: 대시보드
@app.route("/")
def index():
    db = get_db()
    stats = {
        "domains": db.execute("SELECT COUNT(*) c FROM domains").fetchone()["c"],
        "pages": db.execute("SELECT COUNT(*) c FROM pages").fetchone()["c"],
        "sources": db.execute("SELECT COUNT(*) c FROM sources").fetchone()["c"],
        "revisions": db.execute("SELECT COUNT(*) c FROM revisions").fetchone()["c"],
    }
    dom_rows = db.execute(
        "SELECT d.*, (SELECT COUNT(*) FROM pages p WHERE p.domain_id=d.id) pcnt, "
        "(SELECT COUNT(*) FROM sources s WHERE s.domain_id=d.id) scnt "
        "FROM domains d ORDER BY d.id").fetchall()
    recent_pages = db.execute(
        "SELECT p.*, d.name dname, d.slug dslug FROM pages p JOIN domains d ON d.id=p.domain_id "
        "ORDER BY p.updated_at DESC LIMIT 8").fetchall()
    recent_sources = db.execute(
        "SELECT s.*, d.name dname FROM sources s JOIN domains d ON d.id=s.domain_id "
        "ORDER BY s.id DESC LIMIT 8").fetchall()
    return render_template("index.html", stats=stats, dom_rows=dom_rows,
                           recent_pages=recent_pages, recent_sources=recent_sources)


# ---------------------------------------------------------------- 라우트: 담당
@app.route("/domain/<slug>")
def domain_view(slug):
    db = get_db()
    d = db.execute("SELECT * FROM domains WHERE slug=?", (slug,)).fetchone()
    if not d:
        abort(404)
    pages = db.execute("SELECT * FROM pages WHERE domain_id=? ORDER BY updated_at DESC",
                       (d["id"],)).fetchall()
    sources = db.execute("SELECT * FROM sources WHERE domain_id=? ORDER BY id DESC",
                         (d["id"],)).fetchall()
    templates = db.execute(
        "SELECT * FROM templates WHERE domain_id IS NULL OR domain_id=? ORDER BY id",
        (d["id"],)).fetchall()
    return render_template("domain.html", d=d, pages=pages, sources=sources,
                           templates=templates)


# ---------------------------------------------------------------- 라우트: 페이지
@app.route("/page/new", methods=["GET", "POST"])
def page_new():
    db = get_db()
    domains = db.execute("SELECT * FROM domains ORDER BY id").fetchall()
    templates = db.execute("SELECT * FROM templates ORDER BY id").fetchall()
    if request.method == "POST":
        domain_id = int(request.form["domain_id"])
        title = request.form["title"].strip()
        if not title:
            flash("제목은 필수다", "err")
            return redirect(request.url)
        mode = request.form.get("mode", "free")
        if mode == "form":
            tpl = db.execute("SELECT * FROM templates WHERE id=?",
                             (int(request.form["template_id"]),)).fetchone()
            sections = json.loads(tpl["sections"])
            parts = []
            for idx, sec in enumerate(sections):
                content = (request.form.get(f"sec_{idx}") or "").strip()
                if content:
                    parts.append(f"## {sec['title']}\n\n{content}")
            body = "\n\n".join(parts)
        else:
            body = request.form.get("body_md", "").strip()
        slug = unique_page_slug(domain_id, title)
        now = now_str()
        cur = db.execute(
            "INSERT INTO pages(domain_id,title,slug,tags,summary,body_md,author,created_at,updated_at) "
            "VALUES(?,?,?,?,?,?,?,?,?)",
            (domain_id, title, slug, request.form.get("tags", "").strip(),
             request.form.get("summary", "").strip(), body,
             request.form.get("author", "").strip(), now, now))
        pid = cur.lastrowid
        db.execute("INSERT INTO revisions(page_id,title,body_md,author,saved_at) VALUES(?,?,?,?,?)",
                   (pid, title, body, request.form.get("author", ""), now))
        db.commit()
        write_page_file(pid)
        flash("페이지 저장 완료", "ok")
        return redirect(url_for("page_view", pid=pid))
    # GET
    sel_domain = request.args.get("domain", "")
    sel_template = request.args.get("template", "")
    prefill_title = request.args.get("title", "")
    draft_token = request.args.get("draft", "")
    draft_body = DRAFT_CACHE.pop(draft_token, "") if draft_token else ""
    tpl = None
    sections = []
    if sel_template:
        tpl = db.execute("SELECT * FROM templates WHERE id=?", (sel_template,)).fetchone()
        if tpl:
            sections = json.loads(tpl["sections"])
    return render_template("page_form.html", domains=domains, templates=templates,
                           sel_domain=sel_domain, tpl=tpl, sections=sections,
                           draft_body=draft_body, prefill_title=prefill_title)


@app.route("/page/<int:pid>")
def page_view(pid):
    db = get_db()
    p = db.execute("SELECT p.*, d.name dname, d.slug dslug FROM pages p "
                   "JOIN domains d ON d.id=p.domain_id WHERE p.id=?", (pid,)).fetchone()
    if not p:
        abort(404)
    backlinks = [b for b in find_backlinks(p["title"]) if b["id"] != pid]
    revcnt = db.execute("SELECT COUNT(*) c FROM revisions WHERE page_id=?", (pid,)).fetchone()["c"]
    return render_template("page_view.html", p=p, backlinks=backlinks, revcnt=revcnt)


@app.route("/page/t/<path:title>")
def page_by_title(title):
    db = get_db()
    p = db.execute("SELECT id FROM pages WHERE title=?", (title.strip(),)).fetchone()
    if p:
        return redirect(url_for("page_view", pid=p["id"]))
    flash(f"'{title}' 페이지가 아직 없다. 새로 만들어라.", "err")
    return redirect(url_for("page_new", title=title))


@app.route("/page/<int:pid>/edit", methods=["GET", "POST"])
def page_edit(pid):
    db = get_db()
    p = db.execute("SELECT * FROM pages WHERE id=?", (pid,)).fetchone()
    if not p:
        abort(404)
    domains = db.execute("SELECT * FROM domains ORDER BY id").fetchall()
    if request.method == "POST":
        title = request.form["title"].strip() or p["title"]
        domain_id = int(request.form["domain_id"])
        slug = unique_page_slug(domain_id, title, exclude_id=pid)
        now = now_str()
        db.execute(
            "UPDATE pages SET domain_id=?,title=?,slug=?,tags=?,summary=?,body_md=?,author=?,updated_at=? WHERE id=?",
            (domain_id, title, slug, request.form.get("tags", "").strip(),
             request.form.get("summary", "").strip(), request.form.get("body_md", ""),
             request.form.get("author", "").strip(), now, pid))
        db.execute("INSERT INTO revisions(page_id,title,body_md,author,saved_at) VALUES(?,?,?,?,?)",
                   (pid, title, request.form.get("body_md", ""), request.form.get("author", ""), now))
        db.commit()
        write_page_file(pid)
        flash("수정 저장 완료", "ok")
        return redirect(url_for("page_view", pid=pid))
    return render_template("page_edit.html", p=p, domains=domains)


@app.route("/page/<int:pid>/delete", methods=["POST"])
def page_delete(pid):
    db = get_db()
    p = db.execute("SELECT p.*, d.slug dslug FROM pages p JOIN domains d ON d.id=p.domain_id "
                   "WHERE p.id=?", (pid,)).fetchone()
    if p:
        db.execute("DELETE FROM revisions WHERE page_id=?", (pid,))
        db.execute("DELETE FROM pages WHERE id=?", (pid,))
        db.commit()
        f = WIKI_DIR / p["dslug"] / f"{p['slug']}.md"
        if f.exists():
            f.unlink()
        flash("페이지 삭제됨", "ok")
    return redirect(url_for("index"))


@app.route("/page/<int:pid>/history")
def page_history(pid):
    db = get_db()
    p = db.execute("SELECT * FROM pages WHERE id=?", (pid,)).fetchone()
    if not p:
        abort(404)
    revs = db.execute("SELECT * FROM revisions WHERE page_id=? ORDER BY id DESC", (pid,)).fetchall()
    return render_template("page_history.html", p=p, revs=revs)


@app.route("/page/<int:pid>/rev/<int:rid>")
def page_rev(pid, rid):
    db = get_db()
    p = db.execute("SELECT * FROM pages WHERE id=?", (pid,)).fetchone()
    r = db.execute("SELECT * FROM revisions WHERE id=? AND page_id=?", (rid, pid)).fetchone()
    if not p or not r:
        abort(404)
    return render_template("page_rev.html", p=p, r=r)


@app.route("/page/<int:pid>/raw")
def page_raw(pid):
    db = get_db()
    p = db.execute("SELECT p.*, d.name dname FROM pages p JOIN domains d ON d.id=p.domain_id "
                   "WHERE p.id=?", (pid,)).fetchone()
    if not p:
        abort(404)
    content = page_frontmatter(p, p["dname"]) + (p["body_md"] or "")
    return Response(content, mimetype="text/markdown; charset=utf-8",
                    headers={"Content-Disposition": f"attachment; filename={p['slug']}.md"})


# ---------------------------------------------------------------- 라우트: 소스 (업로드/인제스트)
@app.route("/upload", methods=["POST"])
def upload():
    db = get_db()
    domain_id = int(request.form["domain_id"])
    d = db.execute("SELECT * FROM domains WHERE id=?", (domain_id,)).fetchone()
    if not d:
        abort(400)
    files = request.files.getlist("file")
    ok, skip = 0, []
    for f in files:
        if not f or not f.filename:
            continue
        orig = f.filename
        ext = Path(orig).suffix.lower()
        if ext not in ALLOWED_EXT:
            skip.append(f"{orig} (지원 안 하는 형식)")
            continue
        safe = secure_filename(orig)
        if not Path(safe).stem:
            safe = "file" + ext
        ddir = SRC_DIR / d["slug"]
        ddir.mkdir(parents=True, exist_ok=True)
        cur = db.execute(
            "INSERT INTO sources(domain_id,filename,stored_name,filetype,description,uploader,created_at) "
            "VALUES(?,?,?,?,?,?,?)",
            (domain_id, orig, "", "", request.form.get("description", "").strip(),
             request.form.get("uploader", "").strip(), now_str()))
        sid = cur.lastrowid
        stored = f"{sid}_{safe}"
        path = ddir / stored
        f.save(str(path))
        ftype, text, warn = extract_source(path)
        db.execute("UPDATE sources SET stored_name=?, filetype=?, extracted_text=? WHERE id=?",
                   (stored, ftype, text or "", sid))
        db.commit()
        if warn:
            flash(f"{orig}: {warn}", "err")
        ok += 1
    if ok:
        flash(f"소스 {ok}건 업로드 완료", "ok")
    for s in skip:
        flash(s, "err")
    return redirect(url_for("domain_view", slug=d["slug"]))


@app.route("/source/<int:sid>")
def source_view(sid):
    db = get_db()
    s = db.execute("SELECT s.*, d.name dname, d.slug dslug FROM sources s "
                   "JOIN domains d ON d.id=s.domain_id WHERE s.id=?", (sid,)).fetchone()
    if not s:
        abort(404)
    templates = db.execute("SELECT * FROM templates ORDER BY id").fetchall()
    return render_template("source_view.html", s=s, templates=templates)


@app.route("/source/<int:sid>/file")
def source_file(sid):
    db = get_db()
    s = db.execute("SELECT s.*, d.slug dslug FROM sources s JOIN domains d ON d.id=s.domain_id "
                   "WHERE s.id=?", (sid,)).fetchone()
    if not s:
        abort(404)
    path = SRC_DIR / s["dslug"] / s["stored_name"]
    if not path.exists():
        abort(404)
    return send_file(str(path), download_name=s["filename"])


@app.route("/source/<int:sid>/desc", methods=["POST"])
def source_desc(sid):
    db = get_db()
    db.execute("UPDATE sources SET description=? WHERE id=?",
               (request.form.get("description", "").strip(), sid))
    db.commit()
    flash("설명 저장됨", "ok")
    return redirect(url_for("source_view", sid=sid))


@app.route("/source/<int:sid>/delete", methods=["POST"])
def source_delete(sid):
    db = get_db()
    s = db.execute("SELECT s.*, d.slug dslug FROM sources s JOIN domains d ON d.id=s.domain_id "
                   "WHERE s.id=?", (sid,)).fetchone()
    if s:
        path = SRC_DIR / s["dslug"] / s["stored_name"]
        if path.exists():
            path.unlink()
        db.execute("DELETE FROM sources WHERE id=?", (sid,))
        db.commit()
        flash("소스 삭제됨", "ok")
        return redirect(url_for("domain_view", slug=s["dslug"]))
    return redirect(url_for("index"))


@app.route("/source/<int:sid>/draft", methods=["POST"])
def source_draft(sid):
    """LLM으로 소스 → 위키 초안 생성"""
    db = get_db()
    s = db.execute("SELECT s.*, d.slug dslug FROM sources s JOIN domains d ON d.id=s.domain_id "
                   "WHERE s.id=?", (sid,)).fetchone()
    if not s:
        abort(404)
    tpl = db.execute("SELECT * FROM templates WHERE id=?",
                     (int(request.form["template_id"]),)).fetchone()
    sections = json.loads(tpl["sections"]) if tpl else []
    try:
        draft = llm_draft_from_source(s, sections)
    except RuntimeError as e:
        flash(str(e), "err")
        return redirect(url_for("source_view", sid=sid))
    token = secrets.token_hex(8)
    DRAFT_CACHE[token] = f"{draft}\n\n---\n\n> 참고 소스: #{s['id']} {s['filename']} (LLM 초안 — 검토 필수)"
    flash("LLM 초안 생성 완료. 검토 후 저장해라.", "ok")
    return redirect(url_for("page_new", domain=s["dslug"], draft=token,
                            title=Path(s["filename"]).stem))


# ---------------------------------------------------------------- 라우트: 담당 노트북 대화 (Open Notebook 스타일)
@app.route("/domain/<slug>/ask", methods=["POST"])
def domain_ask(slug):
    """선택한 소스 + 담당 위키를 근거로 질문 (NotebookLM/Open Notebook 방식)"""
    db = get_db()
    d = db.execute("SELECT * FROM domains WHERE slug=?", (slug,)).fetchone()
    if not d:
        abort(404)
    question = request.form.get("question", "").strip()
    sel_ids = [int(x) for x in request.form.getlist("src") if x.isdigit()]
    answer = None
    if question:
        ctx_parts = []
        if sel_ids:
            marks = ",".join("?" * len(sel_ids))
            for s in db.execute(
                    f"SELECT * FROM sources WHERE id IN ({marks}) AND domain_id=?",
                    (*sel_ids, d["id"])):
                body = (s["extracted_text"] or s["description"] or "")[:4000]
                ctx_parts.append((1.0, {"kind": "source", "id": s["id"],
                                        "title": s["filename"], "domain": d["name"],
                                        "text": body}))
        # 담당 위키 페이지도 BM25로 보강
        for sc, doc in bm25_search(question, all_search_docs(domain_id=d["id"],
                                                            include_sources=not sel_ids), k=3):
            ctx_parts.append((sc, doc))
        try:
            answer = llm_answer(question, ctx_parts[:8])
        except RuntimeError as e:
            flash(str(e), "err")
    pages = db.execute("SELECT * FROM pages WHERE domain_id=? ORDER BY updated_at DESC",
                       (d["id"],)).fetchall()
    sources = db.execute("SELECT * FROM sources WHERE domain_id=? ORDER BY id DESC",
                         (d["id"],)).fetchall()
    templates = db.execute(
        "SELECT * FROM templates WHERE domain_id IS NULL OR domain_id=? ORDER BY id",
        (d["id"],)).fetchall()
    return render_template("domain.html", d=d, pages=pages, sources=sources,
                           templates=templates, question=question, answer=answer,
                           sel_ids=sel_ids)


@app.route("/domain/<slug>/save-note", methods=["POST"])
def domain_save_note(slug):
    """대화 답변을 노트(위키 페이지) 초안으로 저장 — 검토 후 확정"""
    db = get_db()
    d = db.execute("SELECT * FROM domains WHERE slug=?", (slug,)).fetchone()
    if not d:
        abort(404)
    question = request.form.get("question", "").strip()
    answer = request.form.get("answer", "").strip()
    if not answer:
        flash("저장할 답변이 없다", "err")
        return redirect(url_for("domain_view", slug=slug))
    if len(DRAFT_CACHE) > 200:
        DRAFT_CACHE.clear()
    token = secrets.token_hex(8)
    DRAFT_CACHE[token] = (f"> 질문: {question}\n\n{answer}\n\n---\n\n"
                          f"> LLM 대화에서 저장된 노트 — 담당자 검토 필수")
    return redirect(url_for("page_new", domain=slug, draft=token,
                            title=question[:60]))


# ---------------------------------------------------------------- 라우트: 검색/QA/린트
@app.route("/search")
def search():
    q = request.args.get("q", "").strip()
    results = []
    if q:
        results = bm25_search(q, all_search_docs(), k=20)
    return render_template("search.html", q=q, results=results)


@app.route("/ask", methods=["GET", "POST"])
def ask():
    answer, question, used = None, "", []
    if request.method == "POST":
        question = request.form.get("question", "").strip()
        if question:
            docs = bm25_search(question, all_search_docs(), k=5)
            used = docs
            try:
                answer = llm_answer(question, docs)
            except RuntimeError as e:
                flash(str(e), "err")
    return render_template("ask.html", question=question, answer=answer, used=used)


@app.route("/lint")
def lint():
    issues = run_lint()
    return render_template("lint.html", issues=issues, llm_report=None)


@app.route("/lint/llm", methods=["POST"])
def lint_llm():
    db = get_db()
    pages = db.execute("SELECT p.id,p.title,p.summary,d.name dname FROM pages p "
                       "JOIN domains d ON d.id=p.domain_id").fetchall()
    listing = "\n".join(f"- [page#{p['id']}] ({p['dname']}) {p['title']}: {p['summary']}"
                        for p in pages)
    try:
        report = llm_chat([
            {"role": "system", "content":
                "너는 사내 지식위키 품질 검수자다. 아래 페이지 목록(제목+한줄요약)을 보고 "
                "① 서로 모순되어 보이는 페이지 쌍 ② 중복 주제로 통합이 필요한 페이지 "
                "③ 비어 보이는 주제(있어야 하는데 없는 페이지)를 한국어로 간결하게 보고해라."},
            {"role": "user", "content": listing or "(페이지 없음)"}], max_tokens=1500)
    except RuntimeError as e:
        flash(str(e), "err")
        return redirect(url_for("lint"))
    issues = run_lint()
    return render_template("lint.html", issues=issues, llm_report=report)


# ---------------------------------------------------------------- 라우트: schema
@app.route("/schema")
def schema_view():
    return render_template("schema.html", content=schema_text())


@app.route("/schema/edit", methods=["GET", "POST"])
def schema_edit():
    if request.method == "POST":
        SCHEMA_FILE.parent.mkdir(parents=True, exist_ok=True)
        SCHEMA_FILE.write_text(request.form.get("content", ""), encoding="utf-8")
        flash("작성 규칙 저장됨", "ok")
        return redirect(url_for("schema_view"))
    return render_template("schema_edit.html", content=schema_text())


# ---------------------------------------------------------------- 라우트: 설정
@app.route("/settings", methods=["GET", "POST"])
def settings_view():
    db = get_db()
    if request.method == "POST":
        for k in ("site_name", "llm_base_url", "llm_model", "llm_api_key"):
            if k in request.form:
                set_setting(k, request.form[k].strip())
        flash("설정 저장됨", "ok")
        return redirect(url_for("settings_view"))
    domains = db.execute(
        "SELECT d.*, (SELECT COUNT(*) FROM pages p WHERE p.domain_id=d.id) pcnt, "
        "(SELECT COUNT(*) FROM sources s WHERE s.domain_id=d.id) scnt "
        "FROM domains d ORDER BY d.id").fetchall()
    templates = db.execute("SELECT * FROM templates ORDER BY id").fetchall()
    tpl_lines = {}
    for t in templates:
        secs = json.loads(t["sections"])
        tpl_lines[t["id"]] = "\n".join(f"{s['title']} :: {s['guide']}" for s in secs)
    return render_template("settings.html", domains=domains, templates=templates,
                           tpl_lines=tpl_lines,
                           s={k: get_setting(k) for k in
                              ("site_name", "llm_base_url", "llm_model", "llm_api_key")})


@app.route("/settings/test-llm", methods=["POST"])
def settings_test_llm():
    try:
        out = llm_chat([{"role": "user", "content": "연결 확인. '연결 정상'이라고만 답해라."}],
                       max_tokens=20)
        flash(f"LLM 연결 성공: {out[:80]}", "ok")
    except RuntimeError as e:
        flash(f"LLM 연결 실패: {e}", "err")
    return redirect(url_for("settings_view"))


def _parse_tpl_lines(raw):
    sections = []
    for ln in raw.splitlines():
        ln = ln.strip()
        if not ln:
            continue
        if "::" in ln:
            t, gd = ln.split("::", 1)
        else:
            t, gd = ln, ""
        sections.append({"title": t.strip(), "guide": gd.strip()})
    return sections


@app.route("/settings/domain/add", methods=["POST"])
def domain_add():
    db = get_db()
    name = request.form.get("name", "").strip()
    if name:
        slug = slugify(name)
        try:
            db.execute("INSERT INTO domains(slug,name,description,created_at) VALUES(?,?,?,?)",
                       (slug, name, request.form.get("description", "").strip(), now_str()))
            db.commit()
            flash(f"담당 '{name}' 추가됨", "ok")
        except sqlite3.IntegrityError:
            flash("같은 이름(슬러그)의 담당이 이미 있다", "err")
    return redirect(url_for("settings_view"))


@app.route("/settings/domain/<int:did>/edit", methods=["POST"])
def domain_edit(did):
    db = get_db()
    db.execute("UPDATE domains SET name=?, description=? WHERE id=?",
               (request.form.get("name", "").strip(),
                request.form.get("description", "").strip(), did))
    db.commit()
    flash("담당 수정됨", "ok")
    return redirect(url_for("settings_view"))


@app.route("/settings/domain/<int:did>/delete", methods=["POST"])
def domain_delete(did):
    db = get_db()
    cnt = db.execute("SELECT (SELECT COUNT(*) FROM pages WHERE domain_id=?) + "
                     "(SELECT COUNT(*) FROM sources WHERE domain_id=?) c", (did, did)).fetchone()["c"]
    if cnt:
        flash("페이지/소스가 남아있는 담당은 삭제 불가. 먼저 옮기거나 삭제해라.", "err")
    else:
        db.execute("DELETE FROM domains WHERE id=?", (did,))
        db.commit()
        flash("담당 삭제됨", "ok")
    return redirect(url_for("settings_view"))


@app.route("/settings/template/add", methods=["POST"])
def template_add():
    db = get_db()
    name = request.form.get("name", "").strip()
    sections = _parse_tpl_lines(request.form.get("sections", ""))
    if name and sections:
        db.execute("INSERT INTO templates(domain_id,name,sections,created_at) VALUES(NULL,?,?,?)",
                   (name, json.dumps(sections, ensure_ascii=False), now_str()))
        db.commit()
        flash(f"양식 '{name}' 추가됨", "ok")
    else:
        flash("양식 이름과 섹션(한 줄에 '섹션명 :: 가이드')을 입력해라", "err")
    return redirect(url_for("settings_view"))


@app.route("/settings/template/<int:tid>/edit", methods=["POST"])
def template_edit(tid):
    db = get_db()
    sections = _parse_tpl_lines(request.form.get("sections", ""))
    if sections:
        db.execute("UPDATE templates SET name=?, sections=? WHERE id=?",
                   (request.form.get("name", "").strip(),
                    json.dumps(sections, ensure_ascii=False), tid))
        db.commit()
        flash("양식 수정됨", "ok")
    return redirect(url_for("settings_view"))


@app.route("/settings/template/<int:tid>/delete", methods=["POST"])
def template_delete(tid):
    db = get_db()
    db.execute("DELETE FROM templates WHERE id=?", (tid,))
    db.commit()
    flash("양식 삭제됨", "ok")
    return redirect(url_for("settings_view"))


# ---------------------------------------------------------------- 라우트: export
@app.route("/export")
def export_view():
    return render_template("export.html")


@app.route("/export/zip")
def export_zip():
    sync_all_wiki_files()
    buf = io.BytesIO()
    db = get_db()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(WIKI_DIR.rglob("*.md")):
            z.write(f, f"wiki/{f.relative_to(WIKI_DIR)}")
        if SCHEMA_FILE.exists():
            z.write(SCHEMA_FILE, "schema/schema.md")
        # 소스 목록 CSV
        sio = io.StringIO()
        w = csv.writer(sio)
        w.writerow(["id", "domain", "filename", "filetype", "description", "uploader", "created_at"])
        for s in db.execute("SELECT s.*, d.name dname FROM sources s JOIN domains d ON d.id=s.domain_id"):
            w.writerow([s["id"], s["dname"], s["filename"], s["filetype"],
                        s["description"], s["uploader"], s["created_at"]])
        z.writestr("sources_index.csv", sio.getvalue())
        z.writestr("combined.md", _combined_md())
    buf.seek(0)
    return send_file(buf, download_name=f"llm-wiki-export-{datetime.now():%Y%m%d}.zip",
                     as_attachment=True, mimetype="application/zip")


def _combined_md():
    db = get_db()
    parts = ["# LLM-WIKI 전체 결합본 (LLM 학습/컨텍스트 주입용)",
             f"\n생성: {now_str()}\n", "---\n", "## 작성 규칙\n", schema_text(), "\n---\n"]
    for d in db.execute("SELECT * FROM domains ORDER BY id"):
        pages = db.execute("SELECT * FROM pages WHERE domain_id=? ORDER BY title", (d["id"],)).fetchall()
        if not pages:
            continue
        parts.append(f"\n# 담당: {d['name']}\n")
        for p in pages:
            parts.append(f"\n## {p['title']}\n")
            if p["summary"]:
                parts.append(f"> 요약: {p['summary']}\n")
            parts.append((p["body_md"] or "") + "\n")
    return "\n".join(parts)


@app.route("/export/combined")
def export_combined():
    return Response(_combined_md(), mimetype="text/markdown; charset=utf-8",
                    headers={"Content-Disposition":
                             f"attachment; filename=llm-wiki-combined-{datetime.now():%Y%m%d}.md"})


# ---------------------------------------------------------------- JSON API (MCP 연동용)
@app.route("/api/health")
def api_health():
    return jsonify({"status": "ok", "time": now_str()})


@app.route("/api/domains")
def api_domains():
    db = get_db()
    rows = db.execute(
        "SELECT d.*, (SELECT COUNT(*) FROM pages p WHERE p.domain_id=d.id) pcnt, "
        "(SELECT COUNT(*) FROM sources s WHERE s.domain_id=d.id) scnt FROM domains d ORDER BY d.id").fetchall()
    return jsonify({"domains": [
        {"id": r["id"], "slug": r["slug"], "name": r["name"],
         "description": r["description"], "pageCount": r["pcnt"], "sourceCount": r["scnt"]}
        for r in rows]})


@app.route("/api/pages")
def api_pages():
    db = get_db()
    dom = request.args.get("domain")
    q = ("SELECT p.id,p.title,p.slug,p.tags,p.summary,p.author,p.updated_at,d.slug dslug,d.name dname "
         "FROM pages p JOIN domains d ON d.id=p.domain_id")
    args = []
    if dom:
        q += " WHERE d.slug=?"
        args.append(dom)
    q += " ORDER BY p.updated_at DESC"
    rows = db.execute(q, args).fetchall()
    return jsonify({"pages": [
        {"id": r["id"], "title": r["title"], "slug": r["slug"], "tags": r["tags"],
         "summary": r["summary"], "author": r["author"], "updatedAt": r["updated_at"],
         "domain": r["dname"], "domainSlug": r["dslug"]} for r in rows]})


@app.route("/api/page/<int:pid>")
def api_page(pid):
    db = get_db()
    r = db.execute("SELECT p.*, d.name dname, d.slug dslug FROM pages p "
                   "JOIN domains d ON d.id=p.domain_id WHERE p.id=?", (pid,)).fetchone()
    if not r:
        return jsonify({"isError": True, "message": "page not found"}), 404
    return jsonify({"id": r["id"], "title": r["title"], "slug": r["slug"],
                    "domain": r["dname"], "domainSlug": r["dslug"], "tags": r["tags"],
                    "summary": r["summary"], "author": r["author"],
                    "createdAt": r["created_at"], "updatedAt": r["updated_at"],
                    "bodyMd": r["body_md"]})


@app.route("/api/search")
def api_search():
    q = request.args.get("q", "").strip()
    k = min(int(request.args.get("k", 5)), 20)
    if not q:
        return jsonify({"isError": True, "message": "q required"}), 400
    results = bm25_search(q, all_search_docs(), k=k)
    return jsonify({"query": q, "results": [
        {"score": round(s, 3), "kind": d["kind"], "id": d["id"], "title": d["title"],
         "domain": d["domain"], "summary": d.get("summary", "")} for s, d in results]})


@app.route("/api/sources")
def api_sources():
    db = get_db()
    dom = request.args.get("domain")
    q = ("SELECT s.id,s.filename,s.filetype,s.description,s.uploader,s.created_at,d.slug dslug,d.name dname "
         "FROM sources s JOIN domains d ON d.id=s.domain_id")
    args = []
    if dom:
        q += " WHERE d.slug=?"
        args.append(dom)
    q += " ORDER BY s.id DESC"
    rows = db.execute(q, args).fetchall()
    return jsonify({"sources": [
        {"id": r["id"], "filename": r["filename"], "filetype": r["filetype"],
         "description": r["description"], "uploader": r["uploader"],
         "createdAt": r["created_at"], "domain": r["dname"], "domainSlug": r["dslug"]}
        for r in rows]})


@app.route("/api/source/<int:sid>")
def api_source(sid):
    db = get_db()
    r = db.execute("SELECT s.*, d.name dname, d.slug dslug FROM sources s "
                   "JOIN domains d ON d.id=s.domain_id WHERE s.id=?", (sid,)).fetchone()
    if not r:
        return jsonify({"isError": True, "message": "source not found"}), 404
    return jsonify({"id": r["id"], "filename": r["filename"], "filetype": r["filetype"],
                    "domain": r["dname"], "domainSlug": r["dslug"],
                    "description": r["description"], "uploader": r["uploader"],
                    "createdAt": r["created_at"],
                    "extractedText": (r["extracted_text"] or "")[:30000]})


@app.route("/api/ask", methods=["POST"])
def api_ask():
    data = request.get_json(silent=True) or {}
    question = (data.get("question") or "").strip()
    if not question:
        return jsonify({"isError": True, "message": "question required"}), 400
    docs = bm25_search(question, all_search_docs(), k=5)
    try:
        answer = llm_answer(question, docs)
    except RuntimeError as e:
        return jsonify({"isError": True, "message": str(e)}), 502
    return jsonify({"question": question, "answer": answer,
                    "usedDocs": [{"kind": d["kind"], "id": d["id"], "title": d["title"]}
                                 for _, d in docs]})


# ---------------------------------------------------------------- 템플릿 (인라인, 외부 CDN 없음)
TPL = {}

TPL["layout.html"] = '''<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{{ site_name }}</title>
<style>
:root{--bg:#f4f5f7;--card:#fff;--bd:#e2e4ea;--tx:#1f2430;--mut:#69707d;
 --acc:#3b5bdb;--acc2:#eef1fb;--ok:#0a7d33;--err:#c0342b;--warn:#b7791f;}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--tx);
 font-family:'Malgun Gothic','Apple SD Gothic Neo','Noto Sans KR',system-ui,sans-serif;
 font-size:14.5px;line-height:1.65}
a{color:var(--acc);text-decoration:none} a:hover{text-decoration:underline}
header{position:sticky;top:0;z-index:10;background:var(--card);border-bottom:1px solid var(--bd);
 display:flex;align-items:center;gap:14px;padding:10px 20px;flex-wrap:wrap}
header .logo{font-weight:800;font-size:17px;color:var(--tx)}
header .logo b{color:var(--acc)}
header nav{display:flex;gap:2px;flex-wrap:wrap}
header nav a{padding:6px 10px;border-radius:8px;color:var(--tx);font-weight:600;font-size:13.5px}
header nav a:hover{background:var(--acc2);text-decoration:none}
.searchbox{margin-left:auto;display:flex;gap:6px}
.searchbox input{width:220px}
main{max-width:1240px;margin:22px auto;padding:0 20px}
.card{background:var(--card);border:1px solid var(--bd);border-radius:14px;padding:18px 20px;margin-bottom:16px}
.grid{display:grid;gap:14px}
.g3{grid-template-columns:repeat(auto-fill,minmax(260px,1fr))}
.g4{grid-template-columns:repeat(auto-fill,minmax(200px,1fr))}
.nb-grid{display:grid;grid-template-columns:300px 1fr 320px;gap:14px;align-items:start}
@media(max-width:1000px){.nb-grid{grid-template-columns:1fr}}
.stat{text-align:center;padding:14px}
.stat .num{font-size:26px;font-weight:800;color:var(--acc)}
.stat .lbl{color:var(--mut);font-size:13px}
h1{font-size:22px;margin:4px 0 14px} h2{font-size:17px;margin:0 0 10px}
h3{font-size:15px;margin:14px 0 6px}
.mut{color:var(--mut);font-size:13px}
.chip{display:inline-block;background:var(--acc2);color:var(--acc);border-radius:20px;
 padding:1px 10px;font-size:12px;font-weight:700;margin-right:4px}
.chip.gray{background:#eee;color:#555}
.badge{display:inline-block;border-radius:6px;padding:0 7px;font-size:11.5px;font-weight:700;color:#fff}
.badge.page{background:var(--acc)} .badge.source{background:#7048b6}
.badge.text{background:#4a7} .badge.csv{background:#2a8} .badge.pdf{background:#c55}
.badge.image{background:#c81} .badge.other{background:#888}
input[type=text],input[type=password],select,textarea{width:100%;padding:8px 10px;border:1px solid var(--bd);
 border-radius:9px;font:inherit;background:#fff;color:var(--tx)}
textarea{resize:vertical}
label{font-weight:700;font-size:13px;display:block;margin:10px 0 4px}
label .g{font-weight:400;color:var(--mut)}
button,.btn{display:inline-block;background:var(--acc);color:#fff;border:0;border-radius:9px;
 padding:8px 16px;font:inherit;font-weight:700;cursor:pointer;font-size:13.5px}
button:hover,.btn:hover{opacity:.9;text-decoration:none}
.btn.sec{background:#fff;color:var(--tx);border:1px solid var(--bd)}
.btn.warn{background:var(--err)}
.btn.sm{padding:4px 10px;font-size:12.5px;border-radius:7px}
table.list{width:100%;border-collapse:collapse}
table.list th{color:var(--mut);font-size:12.5px;text-align:left;border-bottom:1px solid var(--bd);padding:6px 8px}
table.list td{border-bottom:1px solid #f0f1f4;padding:8px}
.flash{border-radius:10px;padding:10px 14px;margin-bottom:12px;font-weight:600}
.flash.ok{background:#e7f5ec;color:var(--ok)} .flash.err{background:#fdeceb;color:var(--err)}
.md h1,.md h2{border-bottom:1px solid var(--bd);padding-bottom:4px}
.md h2{font-size:18px;margin:22px 0 8px} .md h3{font-size:15.5px}
.md pre{background:#282c34;color:#e6e6e6;border-radius:10px;padding:12px 14px;overflow-x:auto;font-size:13px}
.md code{background:#eef0f4;border-radius:5px;padding:1px 5px;font-size:13px}
.md pre code{background:none;padding:0}
.md blockquote{border-left:4px solid var(--acc);background:var(--acc2);margin:10px 0;
 padding:8px 14px;border-radius:0 8px 8px 0}
.md table{border-collapse:collapse;font-size:13px}
.md th,.md td{border:1px solid var(--bd);padding:5px 9px}
.md th{background:#f2f3f6}
.tablewrap{overflow-x:auto}
.wikilink{font-weight:700}
.srcitem{display:flex;gap:8px;align-items:flex-start;padding:7px 4px;border-bottom:1px solid #f0f1f4}
.srcitem input{margin-top:4px}
.answer{background:var(--acc2);border:1px solid #d5dcf5;border-radius:12px;padding:14px 16px;margin-top:12px}
footer{max-width:1240px;margin:10px auto 30px;padding:0 20px;color:var(--mut);font-size:12.5px}
.right{text-align:right}
details summary{cursor:pointer;font-weight:700}
</style>
</head>
<body>
<header>
  <a class="logo" href="/">📚 <b>{{ site_name }}</b></a>
  <nav>
    <a href="/">대시보드</a>
    {% for d in nav_domains %}<a href="/domain/{{ d.slug }}">{{ d.name }}</a>{% endfor %}
    <a href="/ask">전체 질문</a>
    <a href="/lint">린트</a>
    <a href="/schema">작성규칙</a>
    <a href="/export">내보내기</a>
    <a href="/settings">설정</a>
  </nav>
  <form class="searchbox" action="/search" method="get">
    <input type="text" name="q" placeholder="위키/소스 검색 (BM25)" value="{{ request.args.get('q','') }}">
    <button>검색</button>
  </form>
</header>
<main>
{% with msgs = get_flashed_messages(with_categories=true) %}
  {% for cat, m in msgs %}<div class="flash {{ cat }}">{{ m }}</div>{% endfor %}
{% endwith %}
{% if not llm_ok %}<div class="flash err">⚠ LLM 미설정 — <a href="/settings">설정</a>에서 사내 OpenAI 호환 API 주소/모델을 입력하면 초안 생성·질문 기능이 켜진다. (위키 작성/검색은 LLM 없이도 동작)</div>{% endif %}
{% block content %}{% endblock %}
</main>
<footer>LLM-WIKI · 3-layer(sources/wiki/schema) · MCP 연동: <code>mcp_server.py</code> 실행 → streamable-http :8020 · JSON API: <code>/api/*</code></footer>
<script>
(function(){
 try{
  var k='llmwiki_author';
  document.querySelectorAll('input[name=author],input[name=uploader]').forEach(function(el){
    if(!el.value) el.value = localStorage.getItem(k)||'';
    el.addEventListener('change',function(){ localStorage.setItem(k, el.value); });
  });
 }catch(e){}
 document.querySelectorAll('form.danger').forEach(function(f){
  f.addEventListener('submit',function(e){ if(!confirm('정말 삭제할까? 되돌릴 수 없다.')) e.preventDefault(); });
 });
})();
</script>
</body></html>'''

TPL["index.html"] = '''{% extends "layout.html" %}{% block content %}
<h1>대시보드</h1>
<div class="grid g4">
 <div class="card stat"><div class="num">{{ stats.domains }}</div><div class="lbl">담당(노트북)</div></div>
 <div class="card stat"><div class="num">{{ stats.pages }}</div><div class="lbl">위키 페이지</div></div>
 <div class="card stat"><div class="num">{{ stats.sources }}</div><div class="lbl">소스 자료</div></div>
 <div class="card stat"><div class="num">{{ stats.revisions }}</div><div class="lbl">리비전</div></div>
</div>
<h2 style="margin-top:20px">담당별 노트북</h2>
<div class="grid g3">
{% for d in dom_rows %}
 <div class="card">
   <h2><a href="/domain/{{ d.slug }}">{{ d.name }}</a></h2>
   <div class="mut">{{ d.description }}</div>
   <div style="margin-top:8px"><span class="chip">페이지 {{ d.pcnt }}</span><span class="chip gray">소스 {{ d.scnt }}</span></div>
 </div>
{% endfor %}
</div>
<div class="grid" style="grid-template-columns:1fr 1fr;margin-top:6px">
 <div class="card">
  <h2>최근 수정 페이지</h2>
  {% for p in recent_pages %}
    <div class="srcitem"><span class="badge page">{{ p.dname }}</span>
    <div><a href="/page/{{ p.id }}">{{ p.title }}</a><div class="mut">{{ p.updated_at }} · {{ p.author or '-' }}</div></div></div>
  {% else %}<div class="mut">아직 없음 — 담당 노트북에서 양식으로 작성해라</div>{% endfor %}
 </div>
 <div class="card">
  <h2>최근 소스</h2>
  {% for s in recent_sources %}
    <div class="srcitem"><span class="badge {{ s.filetype }}">{{ s.filetype }}</span>
    <div><a href="/source/{{ s.id }}">{{ s.filename }}</a><div class="mut">{{ s.dname }} · {{ s.created_at }}</div></div></div>
  {% else %}<div class="mut">아직 없음 — MD/PDF/이미지/TXT/CSV를 업로드해라</div>{% endfor %}
 </div>
</div>
{% endblock %}'''

TPL["domain.html"] = '''{% extends "layout.html" %}{% block content %}
{% set sel = sel_ids|default([]) %}
<h1>{{ d.name }} <span class="mut" style="font-size:14px">{{ d.description }}</span></h1>
<div class="nb-grid">
 <!-- 좌: 소스 패널 -->
 <div>
  <div class="card">
   <h2>소스 <span class="mut">({{ sources|length }})</span></h2>
   {% for s in sources %}
    <div class="srcitem">
     <input type="checkbox" name="src" value="{{ s.id }}" form="askform"
       {% if s.id in sel %}checked{% endif %}>
     <div><span class="badge {{ s.filetype }}">{{ s.filetype }}</span>
      <a href="/source/{{ s.id }}">{{ s.filename }}</a>
      <div class="mut">{{ s.created_at }}{% if s.uploader %} · {{ s.uploader }}{% endif %}</div></div>
    </div>
   {% else %}<div class="mut">소스 없음</div>{% endfor %}
  </div>
  <div class="card">
   <h2>소스 업로드</h2>
   <form action="/upload" method="post" enctype="multipart/form-data">
    <input type="hidden" name="domain_id" value="{{ d.id }}">
    <label>파일 <span class="g">(MD/PDF/이미지/TXT/CSV, 복수 선택 가능)</span></label>
    <input type="file" name="file" multiple required>
    <label>설명 <span class="g">(무슨 자료인지 한 줄)</span></label>
    <input type="text" name="description">
    <label>업로더</label>
    <input type="text" name="uploader">
    <div style="margin-top:10px"><button>업로드</button></div>
   </form>
  </div>
 </div>
 <!-- 중: 대화 패널 (Open Notebook 방식) -->
 <div class="card">
  <h2>💬 소스에게 질문</h2>
  <div class="mut">왼쪽에서 소스를 체크하고 질문해라. 체크 안 하면 이 담당의 위키·소스 전체에서 BM25로 찾아 답한다.</div>
  <form id="askform" action="/domain/{{ d.slug }}/ask" method="post">
   <label>질문</label>
   <textarea name="question" rows="3" placeholder="예: OO 알람 발생 시 조치 절차는?">{{ question|default('') }}</textarea>
   <div style="margin-top:10px"><button {% if not llm_ok %}disabled title="LLM 설정 필요"{% endif %}>질문하기</button></div>
  </form>
  {% if answer %}
   <div class="answer md">{{ answer|md|safe }}</div>
   <form action="/domain/{{ d.slug }}/save-note" method="post" style="margin-top:8px">
    <input type="hidden" name="question" value="{{ question }}">
    <textarea name="answer" style="display:none">{{ answer }}</textarea>
    <button class="btn sec">📝 이 답변을 노트(위키 초안)로 저장</button>
   </form>
  {% endif %}
 </div>
 <!-- 우: 노트(위키) 패널 -->
 <div>
  <div class="card">
   <h2>노트 / 위키 페이지 <span class="mut">({{ pages|length }})</span></h2>
   <form action="/page/new" method="get" style="display:flex;gap:6px;margin-bottom:10px">
    <input type="hidden" name="domain" value="{{ d.slug }}">
    <select name="template">
     {% for t in templates %}<option value="{{ t.id }}">{{ t.name }}</option>{% endfor %}
    </select>
    <button class="btn sm">양식으로 작성</button>
   </form>
   {% for p in pages %}
    <div class="srcitem"><div>
      <a href="/page/{{ p.id }}"><b>{{ p.title }}</b></a>
      {% if p.summary %}<div class="mut">{{ p.summary }}</div>{% endif %}
      <div class="mut">{{ p.updated_at }}{% if p.author %} · {{ p.author }}{% endif %}</div>
    </div></div>
   {% else %}<div class="mut">아직 노트 없음</div>{% endfor %}
  </div>
 </div>
</div>
{% endblock %}'''

TPL["page_form.html"] = '''{% extends "layout.html" %}{% block content %}
<h1>새 페이지 작성</h1>
<div class="card">
 <form method="get" action="/page/new" style="display:flex;gap:8px;align-items:end;flex-wrap:wrap">
  <div><label>담당</label>
   <select name="domain">
    {% for dm in domains %}<option value="{{ dm.slug }}" {% if dm.slug==sel_domain %}selected{% endif %}>{{ dm.name }}</option>{% endfor %}
   </select></div>
  <div><label>양식 <span class="g">(비우면 자유 작성)</span></label>
   <select name="template">
    <option value="">— 자유 작성 —</option>
    {% for t in templates %}<option value="{{ t.id }}" {% if tpl and tpl.id==t.id %}selected{% endif %}>{{ t.name }}</option>{% endfor %}
   </select></div>
  <button class="btn sec">양식 불러오기</button>
 </form>
</div>
<div class="card">
 <form method="post" action="/page/new">
  <input type="hidden" name="mode" value="{{ 'form' if tpl else 'free' }}">
  {% if tpl %}<input type="hidden" name="template_id" value="{{ tpl.id }}">{% endif %}
  <div class="grid" style="grid-template-columns:2fr 1fr 1fr">
   <div><label>제목 *</label><input type="text" name="title" required value="{{ prefill_title }}"></div>
   <div><label>담당 *</label>
    <select name="domain_id">
     {% for dm in domains %}<option value="{{ dm.id }}" {% if dm.slug==sel_domain %}selected{% endif %}>{{ dm.name }}</option>{% endfor %}
    </select></div>
   <div><label>작성자</label><input type="text" name="author"></div>
  </div>
  <label>한줄요약 * <span class="g">(검색·LLM 컨텍스트에 그대로 쓰인다)</span></label>
  <input type="text" name="summary">
  <label>태그 <span class="g">(쉼표 구분)</span></label>
  <input type="text" name="tags">
  {% if tpl %}
   <h3>📋 {{ tpl.name }}</h3>
   {% for sec in sections %}
    <label>{{ sec.title }} <span class="g">— {{ sec.guide }}</span></label>
    <textarea name="sec_{{ loop.index0 }}" rows="5" placeholder="{{ sec.guide }}"></textarea>
   {% endfor %}
  {% else %}
   <label>본문 (마크다운) <span class="g">— [[페이지제목]] 으로 위키링크</span></label>
   <textarea name="body_md" rows="20">{{ draft_body }}</textarea>
  {% endif %}
  <div style="margin-top:14px"><button>저장</button>
   <a class="btn sec" href="/schema">작성규칙 보기</a></div>
 </form>
</div>
{% endblock %}'''

TPL["page_view.html"] = '''{% extends "layout.html" %}{% block content %}
<div class="card">
 <div style="display:flex;justify-content:space-between;align-items:start;gap:10px;flex-wrap:wrap">
  <div>
   <h1 style="margin-bottom:6px">{{ p.title }}</h1>
   <span class="chip">{{ p.dname }}</span>
   {% for t in p.tags.split(',') if t.strip() %}<span class="chip gray">{{ t.strip() }}</span>{% endfor %}
   <div class="mut" style="margin-top:6px">작성 {{ p.created_at }} · 갱신 {{ p.updated_at }}{% if p.author %} · {{ p.author }}{% endif %}</div>
  </div>
  <div style="display:flex;gap:6px;flex-wrap:wrap">
   <a class="btn sec sm" href="/page/{{ p.id }}/edit">편집</a>
   <a class="btn sec sm" href="/page/{{ p.id }}/history">이력({{ revcnt }})</a>
   <a class="btn sec sm" href="/page/{{ p.id }}/raw">MD 다운로드</a>
   <form class="danger" action="/page/{{ p.id }}/delete" method="post" style="display:inline">
    <button class="btn warn sm">삭제</button></form>
  </div>
 </div>
 {% if p.summary %}<div class="answer" style="margin-top:10px"><b>요약</b> — {{ p.summary }}</div>{% endif %}
 <div class="md" style="margin-top:14px">{{ p.body_md|md|safe }}</div>
</div>
{% if backlinks %}
<div class="card"><h2>🔗 이 페이지를 참조하는 페이지</h2>
 {% for b in backlinks %}<div><span class="chip">{{ b.dname }}</span> <a href="/page/{{ b.id }}">{{ b.title }}</a></div>{% endfor %}
</div>
{% endif %}
{% endblock %}'''

TPL["page_edit.html"] = '''{% extends "layout.html" %}{% block content %}
<h1>페이지 편집 — {{ p.title }}</h1>
<div class="card">
 <form method="post">
  <div class="grid" style="grid-template-columns:2fr 1fr 1fr">
   <div><label>제목 *</label><input type="text" name="title" required value="{{ p.title }}"></div>
   <div><label>담당</label>
    <select name="domain_id">
     {% for dm in domains %}<option value="{{ dm.id }}" {% if dm.id==p.domain_id %}selected{% endif %}>{{ dm.name }}</option>{% endfor %}
    </select></div>
   <div><label>작성자</label><input type="text" name="author" value="{{ p.author }}"></div>
  </div>
  <label>한줄요약</label><input type="text" name="summary" value="{{ p.summary }}">
  <label>태그</label><input type="text" name="tags" value="{{ p.tags }}">
  <label>본문 (마크다운)</label>
  <textarea name="body_md" rows="24">{{ p.body_md }}</textarea>
  <div style="margin-top:12px"><button>저장</button>
   <a class="btn sec" href="/page/{{ p.id }}">취소</a></div>
 </form>
</div>
{% endblock %}'''

TPL["page_history.html"] = '''{% extends "layout.html" %}{% block content %}
<h1>이력 — <a href="/page/{{ p.id }}">{{ p.title }}</a></h1>
<div class="card">
 <table class="list">
  <tr><th>#</th><th>저장 시각</th><th>작성자</th><th>제목</th><th></th></tr>
  {% for r in revs %}
   <tr><td>{{ r.id }}</td><td>{{ r.saved_at }}</td><td>{{ r.author or '-' }}</td>
   <td>{{ r.title }}</td><td><a href="/page/{{ p.id }}/rev/{{ r.id }}">보기</a></td></tr>
  {% endfor %}
 </table>
</div>
{% endblock %}'''

TPL["page_rev.html"] = '''{% extends "layout.html" %}{% block content %}
<h1>리비전 #{{ r.id }} — {{ r.title }} <span class="mut">({{ r.saved_at }})</span></h1>
<div class="card"><div class="md">{{ r.body_md|md|safe }}</div></div>
<a class="btn sec" href="/page/{{ p.id }}/history">← 이력으로</a>
{% endblock %}'''

TPL["source_view.html"] = '''{% extends "layout.html" %}{% block content %}
<div class="card">
 <div style="display:flex;justify-content:space-between;align-items:start;gap:10px;flex-wrap:wrap">
  <div>
   <h1 style="margin-bottom:6px"><span class="badge {{ s.filetype }}">{{ s.filetype }}</span> {{ s.filename }}</h1>
   <div class="mut">담당 <a href="/domain/{{ s.dslug }}">{{ s.dname }}</a> · 업로드 {{ s.created_at }}{% if s.uploader %} · {{ s.uploader }}{% endif %}</div>
  </div>
  <div style="display:flex;gap:6px">
   <a class="btn sec sm" href="/source/{{ s.id }}/file">원본 다운로드</a>
   <form class="danger" action="/source/{{ s.id }}/delete" method="post"><button class="btn warn sm">삭제</button></form>
  </div>
 </div>
 <form action="/source/{{ s.id }}/desc" method="post" style="margin-top:10px;display:flex;gap:8px">
  <input type="text" name="description" value="{{ s.description }}" placeholder="이 자료가 무엇인지 설명 (이미지 소스는 필수 — LLM이 이 설명을 근거로 쓴다)">
  <button class="btn sec sm">설명 저장</button>
 </form>
</div>
<div class="card">
 <h2>🤖 LLM으로 위키 초안 생성</h2>
 <div class="mut">이 소스 내용을 근거로 양식에 맞는 위키 페이지 초안을 만든다. 생성 후 반드시 검토·수정해서 저장해라.</div>
 <form action="/source/{{ s.id }}/draft" method="post" style="display:flex;gap:8px;margin-top:8px">
  <select name="template_id">
   {% for t in templates %}<option value="{{ t.id }}">{{ t.name }}</option>{% endfor %}
  </select>
  <button {% if not llm_ok %}disabled title="LLM 설정 필요"{% endif %}>초안 생성</button>
 </form>
</div>
{% if s.filetype == 'image' %}
<div class="card"><h2>미리보기</h2><img src="/source/{{ s.id }}/file" style="max-width:100%;border-radius:10px"></div>
{% endif %}
<div class="card">
 <h2>추출 텍스트 {% if s.extracted_text %}<span class="mut">({{ s.extracted_text|length }}자)</span>{% endif %}</h2>
 {% if s.filetype == 'csv' %}
  <div class="md">{{ s.extracted_text|md|safe }}</div>
 {% elif s.extracted_text %}
  <pre style="white-space:pre-wrap;background:#f7f8fa;border:1px solid var(--bd);border-radius:10px;padding:12px;max-height:480px;overflow:auto">{{ s.extracted_text[:8000] }}{% if s.extracted_text|length > 8000 %}\n... (이하 생략){% endif %}</pre>
 {% else %}
  <div class="mut">추출된 텍스트 없음{% if s.filetype=='image' %} — 이미지는 위 설명란에 내용을 적어라{% endif %}</div>
 {% endif %}
</div>
{% endblock %}'''

TPL["search.html"] = '''{% extends "layout.html" %}{% block content %}
<h1>검색{% if q %}: "{{ q }}"{% endif %}</h1>
<div class="card">
 {% for score, doc in results %}
  <div class="srcitem">
   <span class="badge {{ doc.kind }}">{{ doc.kind }}</span>
   <div>
    {% if doc.kind == 'page' %}<a href="/page/{{ doc.id }}"><b>{{ doc.title }}</b></a>
    {% else %}<a href="/source/{{ doc.id }}"><b>{{ doc.title }}</b></a>{% endif %}
    <span class="chip">{{ doc.domain }}</span> <span class="mut">score {{ '%.2f'|format(score) }}</span>
    {% if doc.summary %}<div class="mut">{{ doc.summary }}</div>{% endif %}
   </div>
  </div>
 {% else %}<div class="mut">{% if q %}결과 없음{% else %}검색어를 입력해라{% endif %}</div>{% endfor %}
</div>
{% endblock %}'''

TPL["ask.html"] = '''{% extends "layout.html" %}{% block content %}
<h1>전체 위키에 질문</h1>
<div class="card">
 <div class="mut">전체 담당의 위키·소스에서 BM25로 근거를 찾아 LLM이 답한다. 특정 담당 소스만 골라 묻는 건 각 담당 노트북 화면에서.</div>
 <form method="post" style="margin-top:8px">
  <textarea name="question" rows="3" placeholder="예: OHT 정체 발생 시 확인해야 할 지표는?">{{ question }}</textarea>
  <div style="margin-top:10px"><button {% if not llm_ok %}disabled title="LLM 설정 필요"{% endif %}>질문하기</button></div>
 </form>
 {% if answer %}
  <div class="answer md">{{ answer|md|safe }}</div>
  <h3>참고한 문서</h3>
  {% for score, d in used %}
   <div><span class="badge {{ d.kind }}">{{ d.kind }}</span>
    {% if d.kind=='page' %}<a href="/page/{{ d.id }}">{{ d.title }}</a>{% else %}<a href="/source/{{ d.id }}">{{ d.title }}</a>{% endif %}
    <span class="mut">({{ d.domain }})</span></div>
  {% endfor %}
 {% endif %}
</div>
{% endblock %}'''

TPL["lint.html"] = '''{% extends "layout.html" %}{% block content %}
<h1>린트 — 위키 품질 점검</h1>
<div class="card">
 <h2>규칙 기반 점검 <span class="mut">({{ issues|length }}건)</span></h2>
 <table class="list">
  <tr><th>페이지</th><th>수준</th><th>내용</th></tr>
  {% for i in issues %}
   <tr><td><a href="/page/{{ i.page_id }}">{{ i.title }}</a></td>
   <td>{% if i.level=='warn' %}<span class="chip" style="background:#fdf3e0;color:var(--warn)">주의</span>{% else %}<span class="chip gray">참고</span>{% endif %}</td>
   <td>{{ i.msg }}</td></tr>
  {% else %}<tr><td colspan="3" class="mut">문제 없음 👍</td></tr>{% endfor %}
 </table>
</div>
<div class="card">
 <h2>LLM 심층 점검 <span class="mut">(모순·중복·누락 주제)</span></h2>
 <form action="/lint/llm" method="post">
  <button {% if not llm_ok %}disabled title="LLM 설정 필요"{% endif %}>LLM으로 점검 실행</button>
 </form>
 {% if llm_report %}<div class="answer md" style="margin-top:10px">{{ llm_report|md|safe }}</div>{% endif %}
</div>
{% endblock %}'''

TPL["schema.html"] = '''{% extends "layout.html" %}{% block content %}
<h1>작성 규칙 (schema.md) <a class="btn sec sm" href="/schema/edit">편집</a></h1>
<div class="card md">{{ content|md|safe }}</div>
{% endblock %}'''

TPL["schema_edit.html"] = '''{% extends "layout.html" %}{% block content %}
<h1>작성 규칙 편집</h1>
<div class="card">
 <form method="post">
  <textarea name="content" rows="26">{{ content }}</textarea>
  <div style="margin-top:10px"><button>저장</button> <a class="btn sec" href="/schema">취소</a></div>
 </form>
</div>
{% endblock %}'''

TPL["settings.html"] = '''{% extends "layout.html" %}{% block content %}
<h1>설정</h1>
<div class="card">
 <h2>🤖 LLM 연동 (OpenAI 호환 API)</h2>
 <div class="mut">사내 게이트웨이/추론서버의 OpenAI 호환 주소를 입력해라. 예: <code>http://서버주소:포트/v1</code> — 끝에 /v1까지. Claude 아님, 어떤 OpenAI 호환 엔드포인트든 붙는다.</div>
 <form method="post">
  <div class="grid" style="grid-template-columns:1fr 1fr">
   <div><label>위키 이름</label><input type="text" name="site_name" value="{{ s.site_name }}"></div>
   <div></div>
   <div><label>API Base URL</label><input type="text" name="llm_base_url" value="{{ s.llm_base_url }}" placeholder="http://내부서버:포트/v1"></div>
   <div><label>모델명</label><input type="text" name="llm_model" value="{{ s.llm_model }}" placeholder="서버에 로드된 모델 ID"></div>
   <div><label>API Key <span class="g">(없으면 비워둠)</span></label><input type="password" name="llm_api_key" value="{{ s.llm_api_key }}"></div>
  </div>
  <div style="margin-top:10px"><button>저장</button></div>
 </form>
 <form action="/settings/test-llm" method="post" style="margin-top:8px">
  <button class="btn sec">연결 테스트</button>
 </form>
</div>
<div class="card">
 <h2>👥 담당 관리</h2>
 {% for d in domains %}
  <form action="/settings/domain/{{ d.id }}/edit" method="post" style="display:flex;gap:8px;margin-bottom:6px;align-items:center">
   <input type="text" name="name" value="{{ d.name }}" style="width:140px">
   <input type="text" name="description" value="{{ d.description }}">
   <span class="mut" style="white-space:nowrap">P{{ d.pcnt }}/S{{ d.scnt }}</span>
   <button class="btn sec sm">저장</button>
  </form>
  {% if d.pcnt==0 and d.scnt==0 %}
  <form class="danger" action="/settings/domain/{{ d.id }}/delete" method="post" style="margin:-4px 0 8px"><button class="btn warn sm">삭제</button></form>
  {% endif %}
 {% endfor %}
 <h3>담당 추가</h3>
 <form action="/settings/domain/add" method="post" style="display:flex;gap:8px">
  <input type="text" name="name" placeholder="담당 이름" style="width:160px" required>
  <input type="text" name="description" placeholder="설명">
  <button class="btn sm">추가</button>
 </form>
</div>
<div class="card">
 <h2>📋 양식 관리 <span class="mut">— 한 줄에 「섹션명 :: 작성 가이드」</span></h2>
 {% for t in templates %}
  <form action="/settings/template/{{ t.id }}/edit" method="post" style="margin-bottom:14px">
   <input type="text" name="name" value="{{ t.name }}" style="width:240px;font-weight:700">
   <textarea name="sections" rows="6" style="margin-top:6px">{{ tpl_lines[t.id] }}</textarea>
   <div style="margin-top:6px"><button class="btn sec sm">저장</button></div>
  </form>
  <form class="danger" action="/settings/template/{{ t.id }}/delete" method="post" style="margin:-8px 0 14px"><button class="btn warn sm">양식 삭제</button></form>
 {% endfor %}
 <h3>양식 추가</h3>
 <form action="/settings/template/add" method="post">
  <input type="text" name="name" placeholder="양식 이름" style="width:240px" required>
  <textarea name="sections" rows="4" placeholder="개요 :: 이 주제가 무엇인지 3~5문장&#10;핵심 용어 정의 :: '- 용어: 정의' 형태로"></textarea>
  <div style="margin-top:6px"><button class="btn sm">추가</button></div>
 </form>
</div>
<div class="card">
 <h2>🔌 MCP 연동 안내</h2>
 <div class="md">
  <p>이 위키는 MCP로 바로 노출할 수 있게 준비돼 있다.</p>
  <ul>
   <li><b>동봉된 MCP 서버</b>: <code>python mcp_server.py</code> → streamable-http, 기본 포트 8020. 도구: listDomains / searchWiki / readPage / listSources / readSource</li>
   <li><b>JSON API 직접 사용</b>: <code>/api/domains</code>, <code>/api/pages</code>, <code>/api/page/&lt;id&gt;</code>, <code>/api/search?q=</code>, <code>/api/sources</code>, <code>/api/source/&lt;id&gt;</code>, <code>POST /api/ask</code></li>
   <li><b>학습 데이터 추출</b>: [내보내기]의 combined.md / zip — 담당별 MD 파일이 그대로 지식 자산</li>
  </ul>
 </div>
</div>
{% endblock %}'''

TPL["export.html"] = '''{% extends "layout.html" %}{% block content %}
<h1>내보내기 — 지식 자산화</h1>
<div class="card">
 <h2>📦 전체 ZIP</h2>
 <div class="mut">wiki/담당별 MD 파일(프론트매터 포함) + schema.md + combined.md + 소스 목록 CSV. RAG/파인튜닝/타 시스템 이관용.</div>
 <div style="margin-top:8px"><a class="btn" href="/export/zip">ZIP 다운로드</a></div>
</div>
<div class="card">
 <h2>📄 결합 MD 한 장</h2>
 <div class="mut">전체 위키를 한 파일로 — LLM 컨텍스트에 통째로 넣거나 학습 코퍼스로 쓸 때.</div>
 <div style="margin-top:8px"><a class="btn sec" href="/export/combined">combined.md 다운로드</a></div>
</div>
{% endblock %}'''

app.jinja_loader = DictLoader(TPL)


# ---------------------------------------------------------------- 실행
init_db()

if __name__ == "__main__":
    host = os.environ.get("LLM_WIKI_HOST", "0.0.0.0")
    port = int(os.environ.get("LLM_WIKI_PORT", "8100"))
    print(f"* LLM-WIKI 시작: http://{host}:{port}  (데이터: {DATA_DIR})")
    app.run(host=host, port=port, debug=False)
