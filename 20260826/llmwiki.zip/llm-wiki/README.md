# LLM-WIKI — LLM 도메인 학습용 사내 지식 위키

Karpathy의 [llm-wiki 개념](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f)
([긱뉴스 소개](https://news.hada.io/topic?id=28208)) 기반.
담당자들이 **양식에 맞게 작성**하고, MD/PDF/이미지/TXT/CSV 원본을 모아서
**LLM이 학습/검색/QA에 바로 쓸 수 있는 지식 자산**으로 쌓는 웹 시스템이다.

- Python + HTML (Flask 모놀리식 단일 파일, 외부 CDN 없음) — 브라우저로 접속해서 쓴다
- LLM은 **Claude가 아니라 OpenAI 호환 API** 기준 — 사내 게이트웨이/추론서버 주소를 설정 화면에 입력
- 폐쇄망 기준: pip-only, Node/Docker 불필요
- Open Notebook(NotebookLM) 방식 UX: 담당 노트북마다 **소스 선택 → 질문 → 답변을 노트로 저장**

## 1. 설치 / 실행

```bash
pip install flask          # 필수
pip install pypdf          # 선택: PDF 텍스트 추출
python app.py              # 기본 http://0.0.0.0:8100
```

환경변수:

| 변수 | 기본값 | 설명 |
|---|---|---|
| `LLM_WIKI_PORT` | 8100 | 웹 포트 |
| `LLM_WIKI_HOST` | 0.0.0.0 | 바인드 주소 |
| `LLM_WIKI_DATA` | ./data | 데이터 디렉토리 |
| `LLM_WIKI_SECRET` | (랜덤) | 세션 키 — 운영 시 고정값 권장 |

폐쇄망 반입: 이 폴더 전체를 zip → base64 → 내부망 전송 → 압축 해제.
flask/pypdf는 내부 pip 미러에서 설치 (전부 순수 파이썬 계열이라 휠 반입도 간단).

## 2. 구조 (3-layer)

```
data/
├─ sources/<담당>/     원본 파일 (불변 — 근거 자료)
├─ wiki/<담당>/*.md    위키 페이지 미러 (YAML 프론트매터 포함 → 그대로 지식 자산)
├─ schema/schema.md    작성 규칙 (웹에서 편집 가능)
└─ wiki.db             SQLite (페이지·소스·리비전·설정)
```

## 3. 운영 흐름 (담당자 배포용)

1. **설정**에서 담당(부서/파트)과 양식을 조직에 맞게 조정
2. 담당자에게 URL 배포 → 각자 담당 노트북에서:
   - 자료 업로드 (MD/PDF/이미지/TXT/CSV) → 자동 텍스트 추출
   - **양식으로 작성** 버튼 → 섹션별 폼 채우기 → 저장
   - 소스 상세에서 **LLM 초안 생성** → 검토 후 저장
   - 소스 체크 → **질문** → 좋은 답변은 **노트로 저장**
3. **린트**로 품질 점검 (깨진 링크·고아 페이지·빈 요약 + LLM 모순 점검)
4. **내보내기**로 지식 자산화: 담당별 MD zip / combined.md 한 장

## 4. LLM 설정

설정 화면에 OpenAI 호환 주소 입력 (끝에 `/v1`까지):

```
API Base URL: http://<사내 추론서버 또는 게이트웨이>/v1
모델명:       <서버에 로드된 모델 ID>
API Key:      (필요한 경우만)
```

`/v1/chat/completions`만 쓰므로 vLLM, llama.cpp server, 사내 게이트웨이 등
OpenAI 호환이면 전부 붙는다. LLM 없이도 작성·검색·내보내기는 전부 동작한다.

## 5. MCP 연동

두 가지 경로:

**① 동봉된 MCP 서버** (웹앱이 꺼져 있어도 동작 — DB 직접 읽음)

```bash
pip install "mcp>=1.27,<2"
python mcp_server.py        # streamable-http, http://<주소>:8020/mcp
```

도구: `listDomains` / `searchWiki(query, topK)` / `readPage(pageId)` /
`listSources(domainSlug)` / `readSource(sourceId)`

**② JSON API 직접 호출** (웹앱 실행 중일 때)

```
GET  /api/health
GET  /api/domains
GET  /api/pages?domain=<slug>
GET  /api/page/<id>
GET  /api/search?q=<검색어>&k=5
GET  /api/sources?domain=<slug>
GET  /api/source/<id>
POST /api/ask   {"question": "..."}   (LLM 설정 필요)
```

## 6. 파일 구성

| 파일 | 설명 |
|---|---|
| `app.py` | 웹앱 전체 (Flask + 템플릿 + BM25 + 마크다운 렌더러 + LLM 클라이언트) |
| `mcp_server.py` | MCP 서버 (FastMCP, streamable-http :8020) |
| `requirements.txt` | 의존성 |

## 7. 작성 규칙 핵심 (schema.md 요약)

- 1주제 1페이지, 한줄요약 필수
- 용어는 `- 용어: 정의` 목록으로 (LLM이 그대로 학습)
- 사실/추정 구분 — 추정이면 `(추정)` 표기
- 근거 소스 번호 기재, `[[페이지제목]]` 위키링크로 상호 연결
- LLM 초안·답변은 반드시 담당자 검토 후 저장
