# -*- coding: utf-8 -*-
"""서윤이 MCP 서버에 붙는 쪽 — 표준 라이브러리만 쓴다 (폐쇄망).

왜 SDK 가 아닌가
    qa/mcp_server.py 머리말과 같은 이유다. 공식 mcp SDK 는 30개 남짓을 끌고
    오는데 폐쇄망 배포물에 넣을 수 없다. MCP 는 JSON-RPC 2.0 이라 직접 짠다.
    (규격은 공식 SDK 서버에 붙여 확인했다 — 우리 서버·SDK 서버 양쪽 통과.)

무엇을 하나
    Client  서버 하나를 stdio 로 띄우고 도구를 부른다.
    Hub     config.MCP_SERVERS 를 보고, **질문에 걸리는 서버만** 띄워서
            도구를 부르고, 결과를 서윤 프롬프트에 넣을 글로 만든다.

★이 파일 이름을 mcp.py 로 하지 않는다. avatar 패키지 안에 mcp.py 가 있으면
  나중에 누가 공식 SDK 를 깔았을 때 `from . import mcp` 와 헷갈린다 —
  이 프로젝트에서 config 모듈이 함수 이름에 가려 관제 주소를 못 읽은 적이
  있다. 같은 사고를 두 번 내지 않는다.
"""
import json
import os
import re
import subprocess
import sys
import threading
import time

PROTO = "2025-06-18"


class McpError(Exception):
    """규격 오류 — 서버가 JSON-RPC error 를 돌려줬거나 끊겼다."""


class Client:
    """MCP 서버 하나. stdio 로 자식 프로세스를 띄운다."""

    def __init__(self, command, args=None, env=None, cwd=None, timeout=20):
        self.timeout = float(timeout)
        self._id = 0
        self._lock = threading.RLock()
        e = dict(os.environ)
        e.update(env or {})
        self.proc = subprocess.Popen(
            [command] + list(args or []),
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL, env=e, cwd=cwd,
            text=True, encoding="utf-8", errors="replace", bufsize=1)
        self.server = {}
        self.proto = ""
        self._handshake()

    # ── 낮은 층 ──────────────────────────────────────────────────────────
    def _write(self, obj):
        if self.proc.poll() is not None or self.proc.stdin is None:
            raise McpError("서버가 이미 끝났다")
        try:
            self.proc.stdin.write(json.dumps(obj, ensure_ascii=False) + "\n")
            self.proc.stdin.flush()
        except (OSError, ValueError) as e:
            # ★같은 사고인데 예외 이름이 다르다:
            #     윈도우  OSError [Errno 22] Invalid argument
            #     리눅스  ValueError: I/O operation on closed file
            #   둘 다 안 잡으면 대화 한 줄이 통째로 실패한다.
            #   규격 오류로 바꿔 위에서 다시 붙게 한다.
            raise McpError("서버에 못 썼다 ({})".format(e))

    def _rpc(self, method, params=None):
        with self._lock:
            self._id += 1
            mid = self._id
            self._write({"jsonrpc": "2.0", "id": mid, "method": method,
                         "params": params or {}})
            while True:
                try:
                    line = self.proc.stdout.readline()
                except (OSError, ValueError) as e:
                    raise McpError("서버에서 못 읽었다 ({})".format(e))
                if not line:
                    raise McpError("서버가 끊겼다 ({})".format(method))
                try:
                    msg = json.loads(line)
                except ValueError:
                    continue          # 서버가 흘린 잡음은 버린다
                if msg.get("id") != mid:
                    continue          # 알림·남의 응답은 지나친다
                if "error" in msg:
                    er = msg["error"] or {}
                    raise McpError("{} ({})".format(er.get("message"),
                                                    er.get("code")))
                return msg.get("result") or {}

    def _notify(self, method, params=None):
        with self._lock:
            self._write({"jsonrpc": "2.0", "method": method,
                         "params": params or {}})

    # ── 규격 ─────────────────────────────────────────────────────────────
    def _handshake(self):
        r = self._rpc("initialize", {
            "protocolVersion": PROTO,
            "capabilities": {},
            "clientInfo": {"name": "seoyun-avatar", "version": "1.0.0"}})
        self.server = r.get("serverInfo") or {}
        self.proto = r.get("protocolVersion") or ""
        self._notify("notifications/initialized")

    def tools(self):
        return (self._rpc("tools/list") or {}).get("tools") or []

    def call(self, name, args=None):
        """도구 하나 → (글, 실패인가).

        ★없는 도구를 두 가지로 돌려준다: JSON-RPC error(우리 서버) 거나
          isError 결과(공식 SDK 서버). 둘 다 받아야 한다.
        """
        try:
            r = self._rpc("tools/call", {"name": name,
                                         "arguments": args or {}})
        except McpError as e:
            return str(e), True
        txt = "\n".join(c.get("text") or "" for c in (r.get("content") or [])
                        if c.get("type") == "text").strip()
        if not txt and r.get("structuredContent") is not None:
            txt = json.dumps(r["structuredContent"], ensure_ascii=False)
        return txt, bool(r.get("isError"))

    def close(self):
        for f in (self.proc.stdin, self.proc.stdout):
            try:
                if f:
                    f.close()
            except Exception:  # noqa: BLE001
                pass
        try:
            self.proc.wait(timeout=3)
        except Exception:  # noqa: BLE001
            try:
                self.proc.kill()
            except Exception:  # noqa: BLE001
                pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


# ── 여러 서버를 묶어 근거 글로 ────────────────────────────────────────────
def _hits(text, words, when_re=None):
    """질문에 이 서버를 부를 말이 들어 있나.

    ★when_re 도 본다. "AVGTOTALTIME1MIN 왜 썼어?" 처럼 **컬럼·룰 이름만**
      나오는 질문이 있다 — 그 답이 요청이력(보류 건)에 그대로 있는데,
      '요청' 이라는 낱말이 없다고 안 걸려서 못 찾아 줬다.
    """
    t = str(text or "")
    got = [w for w in (words or []) if w and w in t]
    if not got and when_re:
        m = re.search(when_re, t)
        if m:
            got = [m.group(0)]
    return got


def _arg_of(text, spec):
    """질문에서 인자 하나를 뽑는다. spec 은 config 의 'pick'/'pick_opt' 항목."""
    kind = spec.get("kind")
    if kind == "regex":
        m = re.search(spec["re"], text or "")
        if not m:
            return None
        v = m.group(spec.get("group", 1))
        return int(v) if spec.get("int") else v
    if kind == "oneof":
        # ★긴 것부터 본다. ["M14","M14B"] 순서면 "M14B" 질문에서 M14 가
        #   먼저 걸려 엉뚱한 FAB 을 찾는다.
        for v in sorted(spec.get("values") or [], key=len, reverse=True):
            if v in (text or ""):
                return v
        return None
    if kind == "any":
        # 여러 규칙을 차례로 시도한다 (코드명 먼저, 없으면 사람 이름 …)
        for one in spec.get("of") or []:
            v = _arg_of(text, one)
            if v is not None:
                return v
    return None


def _looks_dead(msg):
    """이 실패가 '연결이 끊긴 것' 인가 (도구 자체의 실패가 아니라)."""
    m = str(msg or "")
    return any(w in m for w in ("못 썼다", "못 읽었다", "끊겼다", "이미 끝났다"))


class Hub:
    """config.MCP_SERVERS 를 보고 필요한 것만 띄워 쓴다.

    · 질문에 걸리는 서버가 없으면 **아무것도 안 띄운다** (평소엔 비용 0).
    · 한 번 띄운 서버는 살려 두고 다시 쓴다. 죽으면 다음 질문에 다시 띄운다.
    · 서버가 죽어 있어도 대화는 계속돼야 한다 — 실패는 글로 적어 넘긴다.
    """

    # ★같은 질문을 짧은 시간에 여러 번 묻는다. 화면의 컨텍스트 계측이
    #   **타이핑을 멈출 때마다**(500ms) /api/ctx 를 부르고, 보내면 대화가
    #   또 부른다 — 한 문장에 도구가 여러 번 돌아 눈에 띄게 느려졌다.
    #   같은 글은 이 시간 안에서 한 번만 실제로 조회한다.
    CACHE_S = 15.0

    def __init__(self, servers=None, say=None):
        self.servers = [s for s in (servers or []) if s.get("enabled", True)]
        self._live = {}
        self._lock = threading.RLock()
        self._say = say or (lambda *_a: None)
        self._cache = {}          # {질문: (잰 시각, 글, 도구 수)}
        # ★서버마다 자물쇠 하나. 아바타 서버는 스레드로 도는데, 화면의
        #   컨텍스트 계측(/api/ctx)과 대화(/api/chat)가 **동시에** 같은 MCP
        #   프로세스를 쓴다. 한쪽이 "죽었네" 하고 닫는 순간 다른 쪽은 닫힌
        #   파이프에 쓴다 — 윈도우는 거기서 [Errno 22] Invalid argument 를
        #   낸다 (실제 증상). 한 서버의 조회는 한 번에 하나만 돌게 한다.
        self._srv_locks = {}

    def _srv_lock(self, key):
        with self._lock:
            lk = self._srv_locks.get(key)
            if lk is None:
                lk = self._srv_locks[key] = threading.RLock()
            return lk

    def _all_alive(self):
        """띄워 둔 서버가 전부 살아 있나.

        ★캐시가 **죽은 서버를 가리면 안 된다**. 서버가 끝났는데 15초 동안
          옛 답을 그대로 주면, 그 사이에 '요청이력은 이렇다' 고 말한다 —
          실은 아무것도 못 보고 있는데. 하나라도 죽었으면 캐시를 건너뛰고
          다시 붙어 본다 (그때 실패하면 실패라고 적어 넘긴다).
        """
        with self._lock:
            return all(c.proc.poll() is None for c in self._live.values())

    def matched(self, text):
        """이 질문에 걸리는 서버 목록 (화면 계측·시험용)."""
        return [s for s in self.servers
                if _hits(text, s.get("when"), s.get("when_re"))]

    def _run_calls(self, s, c, text, lines):
        """한 서버의 도구들을 차례로 부른다 → 부른 횟수.
        ★_srv_lock 안에서만 부른다 (동시 접근이 파이프를 깬다)."""
        used = 0
        for call in s.get("calls") or []:
            args = dict(call.get("args") or {})
            for k, spec in (call.get("pick") or {}).items():
                v = _arg_of(text, spec)
                if v is None:
                    args = None
                    break
                args[k] = v
            if args is None:
                continue      # 질문에서 인자를 못 뽑았다 — 이 도구는 건너뛴다
            # ★있으면 좁히고, 없으면 그냥 전체를 본다. 이걸 required 로
            #   두면 안 된다 — 등록된 요청의 대상이 전부 'ALL' 이라
            #   FAB 이름으로만 좁히게 해 놨더니 **목록이 한 번도 안 나왔다**.
            #   건수만 오고 "그래서 그 5건이 뭔데" 에 답을 못 했다.
            for k, spec in (call.get("pick_opt") or {}).items():
                v = _arg_of(text, spec)
                if v is not None:
                    args[k] = v
            txt, bad = self._call_retry(s, c, call["tool"], args)
            c = self._live.get(s["key"], c)      # 다시 붙었을 수 있다
            used += 1
            if txt:
                lines.append("· {}{}\n{}".format(
                    call.get("label") or call["tool"],
                    " (실패)" if bad else "", txt))
        return used

    def _call_retry(self, s, c, tool, args):
        """도구 하나 — 파이프가 끊겼으면 **한 번만** 다시 붙어 재시도한다.

        ★윈도우에서 자식이 죽으면(인코딩·강제종료 등) 부모는 [Errno 22]
          Invalid argument 를 맞는다. 한 번 죽었다고 그 질문을 통째로
          버릴 이유가 없다 — 새로 띄우면 대개 그대로 된다.
        """
        txt, bad = c.call(tool, args)
        if not bad:
            return txt, bad
        if not _looks_dead(txt) or c.proc.poll() is None:
            return txt, bad          # 진짜 도구 실패다 — 다시 걸어도 같다
        self._say("     ↳ MCP 끊겨서 다시 붙는다 ({})".format(txt[:60]))
        try:
            with self._lock:
                self._live.pop(s["key"], None)
            c2 = self._client(s)
        except Exception as e:  # noqa: BLE001
            return "다시 붙지 못했다: {}".format(e), True
        return c2.call(tool, args)

    def _client(self, s):
        with self._lock:
            c = self._live.get(s["key"])
            if c is not None and c.proc.poll() is None:
                return c
            if c is not None:
                c.close()
                self._live.pop(s["key"], None)
            c = Client(s.get("command") or sys.executable,
                       s.get("args"), s.get("env"), s.get("cwd"),
                       s.get("timeout", 20))
            self._live[s["key"]] = c
            self._say("     ↳ MCP 연결: {} ({} {})".format(
                s.get("name") or s["key"], c.server.get("name") or "?",
                c.server.get("version") or ""))
            return c

    def gather(self, text, use_cache=True):
        """질문에 걸리는 서버들을 불러 근거 글을 만든다 → (글, 부른 도구 수).

        ★같은 글이면 CACHE_S 안에서는 다시 안 조회한다 (계측 + 대화가
          같은 질문으로 두 번 부른다). 캐시로 준 것은 도구 수 0 으로 알린다 —
          "몇 번 돌았나" 를 부풀리면 안 된다.
        """
        key = str(text or "")
        now = time.time()
        if use_cache and self._all_alive():
            with self._lock:
                hit = self._cache.get(key)
                if hit and now - hit[0] < self.CACHE_S:
                    return hit[1], 0
        out, used = [], 0
        for s in self.matched(text):
            lines = []
            # ★이 서버에 대한 조회는 한 번에 하나만 (위 _srv_locks 설명 참조)
            with self._srv_lock(s["key"]):
                try:
                    c = self._client(s)
                except Exception as e:  # noqa: BLE001
                    out.append("[{}] 붙지 못했다 ({}). 이 자료는 확인 못 한다."
                               .format(s.get("name") or s["key"], e))
                    continue
                used += self._run_calls(s, c, text, lines)
            if lines:
                out.append("[{}]\n".format(s.get("name") or s["key"])
                           + "\n".join(lines))
        got = "\n\n".join(out)
        if use_cache and got:
            with self._lock:
                self._cache[key] = (now, got, used)
                if len(self._cache) > 64:      # 오래된 것부터 버린다
                    for k in sorted(self._cache,
                                    key=lambda k: self._cache[k][0])[:32]:
                        self._cache.pop(k, None)
        return got, used

    def status(self):
        """지금 MCP 가 어떤 상태인가 — 화면·진단용.

        ★"MCP 안 되는 것 같은데" 를 반복하지 않으려면, **눈으로 볼 수 있는
          자리**가 있어야 한다. 어떤 주소를 보는지, 붙었는지, 왜 못 붙었는지.
        """
        out = []
        for s in self.servers:
            key = s["key"]
            c = self._live.get(key)
            alive = bool(c is not None and c.proc.poll() is None)
            row = {"key": key, "name": s.get("name") or key,
                   "addr": (s.get("env") or {}).get("QA_BASE") or "",
                   "script": (s.get("args") or [""])[0],
                   "started": c is not None, "alive": alive,
                   "server": (c.server if c else {}) or {},
                   "tools": [], "err": ""}
            # 실제로 한 번 두들겨 본다 — 떠 있다고 붙는다는 뜻은 아니다
            try:
                cc = c if alive else self._client(s)
                row["started"] = True
                row["alive"] = True
                row["server"] = cc.server
                row["tools"] = [t["name"] for t in cc.tools()]
                txt, bad = cc.call("qa_meta") if "qa_meta" in row["tools"] \
                    else ("", False)
                row["ok"] = not bad
                row["sample"] = (txt or "").splitlines()[:1]
                if bad:
                    row["err"] = txt[:200]
            except Exception as e:  # noqa: BLE001
                row["ok"] = False
                row["err"] = str(e)[:200]
            out.append(row)
        return {"ok": True, "servers": out,
                "none": not self.servers}

    def close(self):
        with self._lock:
            for c in self._live.values():
                c.close()
            self._live.clear()
