#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AWS_IDC_DATA_HIS — 일자 선택 raw 다운로드 (v4.2 · 265 + PIO 12 = 277 컬럼)
================================================================
aws_idc_realtime_collector.py 의 일자 선택 버전.

- 매분 루프 X → **지정한 날짜의 24시간 raw 한 번에** 다운로드
- 265개 IDC 컬럼 인라인 내장 (단일 파일 독립 실행 — 다른 파일 불필요)
- ★ PIO_ERROR 12개 컬럼 추가 (2026-09-16) — 경로별 DEPOSIT 반송실패 1분 건수
- 단일 일자 → ./raw/M16A_HUBROOM_PR.CSV  (원본 수집기와 동일 파일명)
- 범위    → ./raw/M16A_HUBROOM_PR_YYYYMMDD.CSV  (일자별 파일)

v4.1 → v4.2  (2026-09-16)
======================
★ PIO_ERROR 12개 컬럼 추가
    출처 : STA_TRANS_TIMEOUT_FAIL_HIS  (PIO_DATA_MAKE.py 의 SQL_FAIL 과 동일한 CASE)
    컬럼 : {경로}_PIOERROR_DEPOSITED  × 12

  · 기존 265개 컬럼의 순서·이름·값은 **하나도 바뀌지 않는다**. PIO 12개는 맨 뒤에만 붙는다.
  · PIO 조회가 실패해도 265컬럼 저장은 그대로 진행된다 (값만 0으로 채움).
  · 끄려면 환경변수  PIO_ENABLE=0  또는 옵션  --no-pio
  · 실패 없는 분은 0 이다 (빈칸이 아니다).
  · CASE 는 2026-09-16 수정본 — 예전엔 12경로 중 5개가 0건이었다.
    (FAC_ID/FAB_ID 정규화 · M14A→M14 · M10A→M10 · M16HUB->M16A 보정 · ORA-00904 수정)
  · 과거 날짜도 그대로 재조회된다 — STA_TRANS_TIMEOUT_FAIL_HIS 에 원본이 남아 있다.

사용:
  python aws_idc_일자다운로드.py <YYYYMMDD> [<YYYYMMDD>] [-o <출력폴더>] [--no-pio]

예:
  python aws_idc_일자다운로드.py 20260907             # 9/7 1일 → M16A_HUBROOM_PR.CSV
  python aws_idc_일자다운로드.py 2026-09-07           # 하이픈 OK
  python aws_idc_일자다운로드.py 20260907 -o ./raw    # 출력 폴더 지정
  python aws_idc_일자다운로드.py 20260907 20260915    # 9/7~9/15 범위 → 일자별 9개 파일
  python aws_idc_일자다운로드.py 20260907 20260915 --no-pio   # PIO 없이 265컬럼만

DB 접속 정보 (환경변수로 오버라이드 가능):
  ORA_USER   (기본 STAREAD)
  ORA_PASS   (기본 Stareadadmin123!)
  ORA_DSN    (기본 10.40.41.103:1521/ICASTARPP)
  PIO_ENABLE (0 이면 PIO 조회 안 함 — 컬럼은 0 으로 채워 유지)
"""
import csv
import logging
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

# ★ 265개 IDC 컬럼 (raw_columns.py 와 동일 — 단일 파일 독립 실행용 인라인)
RAW_COLS_265 = [
    "M16HUB.CNV.SENDFAB.TO_M14A_CURRENTQCNT", "M16HUB.LFT.6ABL0111.2F_TO_3F_CURRENTQCNT", "M16HUB.LFT.6ABL0111.2F_TO_6F_CURRENTQCNT",
    "M16HUB.LFT.6ABL0111.3F_TO_2F_CURRENTQCNT", "M16HUB.LFT.6ABL0111.3F_TO_6F_CURRENTQCNT", "M16HUB.LFT.6ABL0111.6F_TO_2F_CURRENTQCNT",
    "M16HUB.LFT.6ABL0111.6F_TO_3F_CURRENTQCNT", "M16HUB.LFT.6ABL0111.TOTAL_CURRENTQCNT", "M16HUB.LFT.6ABL0112.2F_TO_3F_CURRENTQCNT",
    "M16HUB.LFT.6ABL0112.2F_TO_6F_CURRENTQCNT", "M16HUB.LFT.6ABL0112.3F_TO_2F_CURRENTQCNT", "M16HUB.LFT.6ABL0112.3F_TO_6F_CURRENTQCNT",
    "M16HUB.LFT.6ABL0112.6F_TO_2F_CURRENTQCNT", "M16HUB.LFT.6ABL0112.6F_TO_3F_CURRENTQCNT", "M16HUB.LFT.6ABL0112.TOTAL_CURRENTQCNT",
    "M16HUB.LFT.6ABL0121.2F_TO_3F_CURRENTQCNT", "M16HUB.LFT.6ABL0121.2F_TO_6F_CURRENTQCNT", "M16HUB.LFT.6ABL0121.3F_TO_2F_CURRENTQCNT",
    "M16HUB.LFT.6ABL0121.3F_TO_6F_CURRENTQCNT", "M16HUB.LFT.6ABL0121.6F_TO_2F_CURRENTQCNT", "M16HUB.LFT.6ABL0121.TOTAL_CURRENTQCNT",
    "M16HUB.LFT.6ABL0122.2F_TO_6F_CURRENTQCNT", "M16HUB.LFT.6ABL0122.3F_TO_2F_CURRENTQCNT", "M16HUB.LFT.6ABL0122.3F_TO_6F_CURRENTQCNT",
    "M16HUB.LFT.6ABL0122.6F_TO_2F_CURRENTQCNT", "M16HUB.LFT.6ABL0122.6F_TO_3F_CURRENTQCNT", "M16HUB.LFT.6ABL0122.TOTAL_CURRENTQCNT",
    "M16HUB.LFT.6ABL6011.2F_TO_3F_CURRENTQCNT", "M16HUB.LFT.6ABL6011.2F_TO_6F_CURRENTQCNT", "M16HUB.LFT.6ABL6011.3F_TO_2F_CURRENTQCNT",
    "M16HUB.LFT.6ABL6011.6F_TO_2F_CURRENTQCNT", "M16HUB.LFT.6ABL6011.6F_TO_3F_CURRENTQCNT", "M16HUB.LFT.6ABL6011.TOTAL_CURRENTQCNT",
    "M16HUB.LFT.6ABL6012.2F_TO_3F_CURRENTQCNT", "M16HUB.LFT.6ABL6012.2F_TO_6F_CURRENTQCNT", "M16HUB.LFT.6ABL6012.3F_TO_2F_CURRENTQCNT",
    "M16HUB.LFT.6ABL6012.3F_TO_6F_CURRENTQCNT", "M16HUB.LFT.6ABL6012.6F_TO_2F_CURRENTQCNT", "M16HUB.LFT.6ABL6012.6F_TO_3F_CURRENTQCNT",
    "M16HUB.LFT.6ABL6012.TOTAL_CURRENTQCNT", "M16HUB.LFT.6ABL6021.2F_TO_3F_CURRENTQCNT", "M16HUB.LFT.6ABL6021.2F_TO_6F_CURRENTQCNT",
    "M16HUB.LFT.6ABL6021.3F_TO_2F_CURRENTQCNT", "M16HUB.LFT.6ABL6021.3F_TO_6F_CURRENTQCNT", "M16HUB.LFT.6ABL6021.6F_TO_2F_CURRENTQCNT",
    "M16HUB.LFT.6ABL6021.6F_TO_3F_CURRENTQCNT", "M16HUB.LFT.6ABL6021.TOTAL_CURRENTQCNT", "M16HUB.LFT.6ABL6022.2F_TO_3F_CURRENTQCNT",
    "M16HUB.LFT.6ABL6022.2F_TO_6F_CURRENTQCNT", "M16HUB.LFT.6ABL6022.3F_TO_2F_CURRENTQCNT", "M16HUB.LFT.6ABL6022.3F_TO_6F_CURRENTQCNT",
    "M16HUB.LFT.6ABL6022.6F_TO_2F_CURRENTQCNT", "M16HUB.LFT.6ABL6022.6F_TO_3F_CURRENTQCNT", "M16HUB.LFT.6ABL6022.TOTAL_CURRENTQCNT",
    "M16HUB.LFT.6ABL6031.2F_TO_3F_CURRENTQCNT", "M16HUB.LFT.6ABL6031.2F_TO_6F_CURRENTQCNT", "M16HUB.LFT.6ABL6031.3F_TO_2F_CURRENTQCNT",
    "M16HUB.LFT.6ABL6031.3F_TO_6F_CURRENTQCNT", "M16HUB.LFT.6ABL6031.6F_TO_2F_CURRENTQCNT", "M16HUB.LFT.6ABL6031.6F_TO_3F_CURRENTQCNT",
    "M16HUB.LFT.6ABL6031.TOTAL_CURRENTQCNT", "M16HUB.LFT.6ABL6032.2F_TO_3F_CURRENTQCNT", "M16HUB.LFT.6ABL6032.3F_TO_2F_CURRENTQCNT",
    "M16HUB.LFT.6ABL6032.3F_TO_6F_CURRENTQCNT", "M16HUB.LFT.6ABL6032.6F_TO_2F_CURRENTQCNT", "M16HUB.LFT.6ABL6032.6F_TO_3F_CURRENTQCNT",
    "M16HUB.LFT.6ABL6032.TOTAL_CURRENTQCNT", "M16HUB.LFT.SENDFAB.TO_M14B_CURRENTQCNT", "M16HUB.LFT.SENDFAB.TO_M16A_CURRENTQCNT",
    "M16HUB.LFT.SENDFAB.TO_M16E_CURRENTQCNT", "M16HUB.OHT.ALERT.OHTMCPALARMCNT", "M16HUB.QUE.ABN.AOTRANSDELAY",
    "M16HUB.QUE.ALL.3F_CMD", "M16HUB.QUE.ALL.3F_TO_3F_MLUD_JOB", "M16HUB.QUE.ALL.3F_TO_M14A_3F_JOB",
    "M16HUB.QUE.ALL.3F_TO_M14B_7F_JOB", "M16HUB.QUE.ALL.3F_TO_M16A_2F_JOB", "M16HUB.QUE.ALL.3F_TO_M16A_6F_JOB",
    "M16HUB.QUE.ALL.CURRENTQCNT", "M16HUB.QUE.ALL.CURRENTQCOMPLETED", "M16HUB.QUE.ALL.CURRENTQCREATED",
    "M16HUB.QUE.ALL.CURRENT_M16A_3F_JOB", "M16HUB.QUE.ALL.CURRENT_M16A_3F_JOB_2", "M16HUB.QUE.ALL.FABTRANSJOBCNT",
    "M16HUB.QUE.ALL.M16HUBTOM14MANUAL_CURRENTQCNT", "M16HUB.QUE.ALL.TRANSPORT4MINOVERCNT", "M16HUB.QUE.ALL.TRANSPORT4MINOVERRATIO",
    "M16HUB.QUE.ALL.TRANSPORT4MINOVERTIMEAVG", "M16HUB.QUE.CNV.3F_CNV_MAXCAPA", "M16HUB.QUE.CNV.3F_TO_M14A_CNV_AI_CMD",
    "M16HUB.QUE.LFT.3F_LFT_MAXCAPA", "M16HUB.QUE.LFT.3F_M14BLFT_MAXCAPA", "M16HUB.QUE.LFT.3F_TO_M14B_LFT_AI_CMD",
    "M16HUB.QUE.LFT.3F_TO_M16A_LFT_AI_CMD", "M16HUB.QUE.LOAD.AVGLOADTIME", "M16HUB.QUE.M14ATOM16.MESCURRENTQCNT",
    "M16HUB.QUE.M14BTOM16.MESCURRENTQCNT", "M16HUB.QUE.M14TOM16.MESCURRENTQCNT", "M16HUB.QUE.M16TOM14.MESCURRENTQCNT",
    "M16HUB.QUE.M16TOM14A.MESCURRENTQCNT", "M16HUB.QUE.M16TOM14B.MESCURRENTQCNT", "M16HUB.QUE.MLUD.3F_TO_M16A_MLUD_AI_CMD",
    "M16HUB.QUE.OHT.CURRENTOHTQCNT", "M16HUB.QUE.OHT.OHTUTIL", "M16HUB.QUE.STB.3F_TO_M16A_3F_STB_CMD",
    "M16HUB.QUE.TIME.AVGTOTALTIME", "M16HUB.QUE.TIME.AVGTOTALTIME1MIN", "M16HUB.STRATE.ALL.FABSTORAGERATIO",
    "M16HUB.STRATE.STB.3F_STORAGE_UTIL", "M16HUB.STRATE.STK.STORAGERATIO", "M14.CNV.SENDFAB.TO_M16HUB_CURRENTQCNT",
    "M14.OHT.STATECNT.ABNORMAL", "M14.OHT.STATECNT.CONGESTED", "M14.OHT.STATECNT.HTSTOP",
    "M14.OHT.STATECNT.OBSANDBZSTOP", "M14.QUE.ABN.AOTRANSDELAY", "M14.QUE.ALL.3F_TO_HUB_JOB",
    "M14.QUE.ALL.3F_TO_HUB_JOB_ALT", "M14.QUE.ALL.CURRENTQCNT", "M14.QUE.ALL.CURRENTQCOMPLETED",
    "M14.QUE.ALL.CURRENTQCREATED", "M14.QUE.ALL.TOTALCNVCURRENTQCNT", "M14.QUE.ALL.TRANSPORT4MINOVERCNT",
    "M14.QUE.ALL.TRANSPORT4MINOVERRATIO", "M14.QUE.ALL.TRANSPORT4MINOVERTIMEAVG", "M14.QUE.CNV.3F_CNV_MAXCAPA",
    "M14.QUE.CNV.ALLTONORTHCNVCURRENTQCNT", "M14.QUE.CNV.ALLTOSOUTHCNVCURRENTQCNT", "M14.QUE.CNV.M14ATOM16ACURRNETQCNT",
    "M14.QUE.CNV.M14ATOM16CURRNETQCNT", "M14.QUE.CNV.M14ATONORTHCURRENTQCNT", "M14.QUE.CNV.M14ATOSOUTHCURRENTQCNT",
    "M14.QUE.CNV.NORTHCNVTOALLCURRENTQCNT", "M14.QUE.CNV.NORTHCNVTOM14TIME", "M14.QUE.CNV.NORTHCNVTOM14TIME1MIN",
    "M14.QUE.CNV.NORTHCURRENTQCNT", "M14.QUE.CNV.NORTHM14TOCNVTIME", "M14.QUE.CNV.NORTHM14TOCNVTIME1MIN",
    "M14.QUE.CNV.SOUTHCNVTOALLCURRENTQCNT", "M14.QUE.CNV.SOUTHCNVTOM14TIME", "M14.QUE.CNV.SOUTHCNVTOM14TIME1MIN",
    "M14.QUE.CNV.SOUTHCURRENTQCNT", "M14.QUE.CNV.SOUTHM14TOCNVTIME", "M14.QUE.CNV.SOUTHM14TOCNVTIME1MIN",
    "M14.QUE.LOAD.AVGLOADTIME", "M14.QUE.LOAD.AVGLOADTIME1MIN", "M14.QUE.OHT.3F_TO_HUB_CMD",
    "M14.QUE.OHT.OHTUTIL", "M14.QUE.SFAB.SENDTOM16", "M14.SORTER.ABN.CUSORTERWAITCOUNTOVER",
    "M14.SORTER.ABN.SORTERWAITCOUNTOVER", "M14B.LFT.4ABLD111.4F_TO_7F_CURRENTQCNT", "M14B.LFT.4ABLD111.7F_TO_4F_CURRENTQCNT",
    "M14B.LFT.4ABLD111.TOTAL_CURRENTQCNT", "M14B.LFT.4ABLD112.4F_TO_7F_CURRENTQCNT", "M14B.LFT.4ABLD112.7F_TO_4F_CURRENTQCNT",
    "M14B.LFT.4ABLD112.TOTAL_CURRENTQCNT", "M14B.LFT.4ABLD121.4F_TO_7F_CURRENTQCNT", "M14B.LFT.4ABLD121.7F_TO_4F_CURRENTQCNT",
    "M14B.LFT.4ABLD121.TOTAL_CURRENTQCNT", "M14B.LFT.4ABLD122.4F_TO_7F_CURRENTQCNT", "M14B.LFT.4ABLD122.7F_TO_4F_CURRENTQCNT",
    "M14B.LFT.4ABLD122.TOTAL_CURRENTQCNT", "M14B.LFT.4ABLD131.4F_TO_7F_CURRENTQCNT", "M14B.LFT.4ABLD131.7F_TO_4F_CURRENTQCNT",
    "M14B.LFT.4ABLD131.TOTAL_CURRENTQCNT", "M14B.LFT.4ABLD132.4F_TO_7F_CURRENTQCNT", "M14B.LFT.4ABLD132.7F_TO_4F_CURRENTQCNT",
    "M14B.LFT.4ABLD132.TOTAL_CURRENTQCNT", "M14B.LFT.SENDFAB.TO_M14A_CURRENTQCNT", "M14B.LFT.SENDFAB.TO_M16HUB_CURRENTQCNT",
    "M14B.OHT.ALERT.OHTMCPALARMCNT", "M14B.QUE.ABN.AOTRANSDELAY", "M14B.QUE.ALL.7F_TO_HUB_JOB",
    "M14B.QUE.ALL.7F_TO_HUB_JOB_ALT", "M14B.QUE.ALL.CURRENTQCNT", "M14B.QUE.ALL.CURRENTQCOMPLETED",
    "M14B.QUE.ALL.CURRENTQCREATED", "M14B.QUE.LFT.ALLTOLFTCURRENTQCNT", "M14B.QUE.LFT.LFTTOALLCURRENTQCNT",
    "M14B.QUE.LFT.M14BTOM16ACURRNETQCNT", "M14B.QUE.LOAD.AVGLOADTIME", "M14B.QUE.LOAD.AVGLOADTIME1MIN",
    "M14B.QUE.LOAD.CURRENTLOADQCNT", "M14B.QUE.OHT.7F_TO_HUB_CMD", "M14B.QUE.OHT.CURRENTOHTQCNT",
    "M14B.QUE.OHT.OHTUTIL", "M14B.QUE.SENDFAB.VERTICALQUEUECOUNT", "M14B.QUE.TIME.AVGTOTALTIME",
    "M14B.QUE.TIME.AVGTOTALTIME1MIN", "M14B.SORTER.ABN.CUSORTERWAITCOUNTOVER", "M14B.SORTER.ABN.SORTERWAITCOUNTOVER",
    "M14B.SORTER.ABN.SORTERWAITCOUNTOVER_B01", "M16A.LFT.SENDFAB.TO_M16B_CURRENTQCNT", "M16A.LFT.SENDFAB.TO_M16E_CURRENTQCNT",
    "M16A.LFT.SENDFAB.TO_M16HUB_CURRENTQCNT", "M16A.QUE.ABN.AOTRANSDELAY", "M16A.QUE.ALL.2F_TO_6F_JOB",
    "M16A.QUE.ALL.2F_TO_HUB_JOB", "M16A.QUE.ALL.2F_TO_HUB_JOB_ALT", "M16A.QUE.ALL.6F_TO_2F_JOB",
    "M16A.QUE.ALL.6F_TO_HUB_JOB", "M16A.QUE.ALL.6F_TO_HUB_JOB_ALT", "M16A.QUE.ALL.CURRENTQCNT",
    "M16A.QUE.ALL.CURRENTQCOMPLETED", "M16A.QUE.ALL.CURRENTQCREATED", "M16A.QUE.ALL.TRANSPORT4MINOVERCNT",
    "M16A.QUE.ALL.TRANSPORT4MINOVERRATIO", "M16A.QUE.ALL.TRANSPORT4MINOVERTIMEAVG", "M16A.QUE.CNV.ALLTONORTHCNVCURRENTQCNT",
    "M16A.QUE.CNV.ALLTOSOUTHCNVCURRENTQCNT", "M16A.QUE.CNV.M16ATOM14ACURRNETQCNT", "M16A.QUE.CNV.M16ATOM14BCURRNETQCNT",
    "M16A.QUE.CNV.M16TOM14ACURRNETQCNT", "M16A.QUE.CNV.M16TOM14BCURRNETQCNT", "M16A.QUE.CNV.NORTHCNVTOALLCURRENTQCNT",
    "M16A.QUE.CNV.SOUTHCNVTOALLCURRENTQCNT", "M16A.QUE.LFT.2F_LFT_MAXCAPA", "M16A.QUE.LFT.6F_LFT_MAXCAPA",
    "M16A.QUE.LFT.ALLTOLFTCURRENTQCNT", "M16A.QUE.LFT.LFTTOALLCURRENTQCNT", "M16A.QUE.LOAD.AVGFOUPLOADTIME",
    "M16A.QUE.LOAD.AVGLOADTIME1MIN", "M16A.QUE.LOAD.CURRENTLOADQCNT", "M16A.QUE.OHT.2F_TO_HUB_CMD",
    "M16A.QUE.OHT.6F_TO_HUB_CMD", "M16A.QUE.OHT.CURRENTOHTQCNT", "M16A.QUE.OHT.OHTUTIL",
    "M16A.SORTER.ABN.CUSORTERWAITCOUNTOVER", "M16A.SORTER.ABN.SORTERWAITCOUNTOVER", "M16B.LFT.SENDFAB.TO_M16A_CURRENTQCNT",
    "M16B.QUE.ABN.AOTRANSDELAY", "M16B.QUE.ALL.10F_TO_HUB_JOB", "M16B.QUE.ALL.CURRENTQCNT",
    "M16B.QUE.ALL.CURRENTQCOMPLETED", "M16B.QUE.ALL.CURRENTQCREATED", "M16B.QUE.ALL.TRANSPORT4MINOVERCNT",
    "M16B.QUE.ALL.TRANSPORT4MINOVERRATIO", "M16B.QUE.ALL.TRANSPORT4MINOVERTIMEAVG", "M16B.QUE.LOAD.AVGFOUPLOADTIME",
    "M16B.QUE.LOAD.AVGLOADTIME1MIN", "M16B.QUE.LOAD.CURRENTLOADQCNT", "M16B.QUE.OHT.CURRENTOHTQCNT",
    "M16B.QUE.OHT.OHTUTIL", "M16B.SORTER.ABN.CUSORTERWAITCOUNTOVER", "M16B.SORTER.ABN.SORTERWAITCOUNTOVER",
    "M16.CNV.SENDFAB.TO_M16WT_CURRENTQCNT", "M16.QUE.SFAB.COMPLETEQUEUETOTAL", "M16.QUE.SFAB.COMPLETETOM10",
    "M16.QUE.SFAB.COMPLETETOM14", "M16.QUE.SFAB.RECEIVEQUEUETOTAL", "M16.QUE.SFAB.RETURNQUEUETOTAL",
    "M16.QUE.SFAB.RETURNTOM10", "M16.QUE.SFAB.RETURNTOM14", "M16.QUE.SFAB.SENDQUEUETOTAL",
    "M16.QUE.SFAB.SENDTOM10", "M16.QUE.SFAB.SENDTOM14", "M16_PKT.OHT.ALERT.OHTMCPALARMCNT",
    "M16_PKT.QUE.ABN.AOTRANSDELAY", "M16_PKT.QUE.OHT.OHTUTIL", "M16_PKT.QUE.TIME.AVGTOTALTIME1MIN",
    "M16_WT.OHT.ALERT.OHTMCPALARMCNT", "M16_WT.QUE.ABN.AOTRANSDELAY", "M16_WT.QUE.OHT.OHTUTIL",
    "M16_WT.QUE.TIME.AVGTOTALTIME1MIN",
]

try:
    import oracledb
except ImportError:
    print("❌ oracledb 미설치 — pip install oracledb")
    sys.exit(1)

ORACLE_USER     = os.getenv("ORA_USER", "STAREAD")
ORACLE_PASSWORD = os.getenv("ORA_PASS", "Stareadadmin123!")
ORACLE_DSN      = os.getenv("ORA_DSN",  "10.40.41.103:1521/ICASTARPP")

# ==========================================================
# ★ v4.2 PIO_ERROR
# ==========================================================
#   PIO_ENABLE=0 이면 조회를 아예 하지 않는다.
#   그래도 12개 컬럼은 0 으로 채워 나간다 — 하류(예측기/영역분리)의 컬럼 수가 변하지 않게.
PIO_ENABLE = os.getenv("PIO_ENABLE", "1") != "0"

# 컬럼 순서 = PIO_DATA_MAKE.py 의 GUBUNS 와 동일 (고객 요청 순서)
PIO_GUBUNS = [
    'M16HUB->MLUD', 'M16HUB->M14B', 'M16HUB<-M14B',
    'M16HUB->M14A', 'M16HUB<-M14A',
    'M16HUB->M16A', 'M16HUB<-M16A',
    'M16A->M16B', 'M16B->M16A',
    'M14A->M14B', 'M14A<-M14B',
    'M14A->M10A',
]
PIO_SUFFIX  = '_PIOERROR_DEPOSITED'          # PIO_DATA_MAKE.py 와 같은 이름 규칙
PIO_COLUMNS = [g + PIO_SUFFIX for g in PIO_GUBUNS]

# PIO_DATA_MAKE.py 의 SQL_FAIL 그대로 (2026-09-16 CASE 수정본).
#   · EQP 컬럼은 쓰지 않으므로 뺐다 — GUBUN × 분 집계만 한다
#   · 구간은 COMPLT_TM 문자열(YYYYMMDDHH24MISS) 비교 — 인덱스를 그대로 탄다
#   · FC/FB/PN 별칭은 반드시 한 단계 아래 SELECT 에서 만든다.
#     같은 SELECT 안에서는 방금 만든 별칭을 참조할 수 없다 (ORA-00904).
SQL_PIO = """
SELECT GUBUN,
       TO_CHAR(GROUP1, 'YYYY-MM-DD HH24:MI') AS GROUP1,
       SUM(CASE WHEN FT = 'DEPOSIT' THEN 1 ELSE 0 END) AS DEPOSITED_FAIL_CNT
FROM (
    SELECT GROUP1, FT,
           CASE
               WHEN FC='M16' AND FB='M16HUB'             AND PN LIKE '6FIOB%' THEN 'M16HUB->MLUD'
               WHEN FC='M16' AND FB='M16HUB'             AND PN LIKE '4ABLD%' THEN 'M16HUB->M14B'
               WHEN FC='M14' AND FB='M14B'               AND PN LIKE '4ABLD%' THEN 'M16HUB<-M14B'
               WHEN FC='M16' AND FB='M16HUB'             AND PN LIKE '4AFC%'  THEN 'M16HUB->M14A'
               WHEN FC='M14' AND FB IN ('M14A','M14')    AND PN LIKE '4AFC%'  THEN 'M16HUB<-M14A'
               WHEN FC='M16' AND FB IN ('M16HUB','M14B') AND PN LIKE '6ABL%'  THEN 'M16HUB->M16A'
               WHEN FC='M16' AND FB='M16A'               AND PN LIKE '6ABL%'  THEN 'M16HUB<-M16A'
               WHEN FC='M16' AND FB='M16A'               AND PN LIKE '6ALF%'  THEN 'M16A->M16B'
               WHEN FC='M16' AND FB='M16B'               AND PN LIKE '6ALF%'  THEN 'M16B->M16A'
               WHEN FC='M14' AND FB IN ('M14A','M14')    AND PN LIKE '4ALF%'  THEN 'M14A->M14B'
               WHEN FC='M14' AND FB='M14B'               AND PN LIKE '4ALF%'  THEN 'M14A<-M14B'
               WHEN FC='M14' AND FB IN ('M10A','M10')    AND PN LIKE '4ABL%'  THEN 'M14A->M10A'
           END AS GUBUN
    FROM (
        SELECT TO_DATE(SUBSTR(A.COMPLT_TM, 1, 12), 'YYYYMMDDHH24MI') AS GROUP1,
               UPPER(TRIM(A.FAIL_TYP)) AS FT,
               UPPER(TRIM(A.FAC_ID))   AS FC,
               UPPER(TRIM(A.FAB_ID))   AS FB,
               UPPER(TRIM(A.PORT_NM))  AS PN
        FROM STA_TRANS_TIMEOUT_FAIL_HIS A
        WHERE A.COMPLT_TM >= :t_from
          AND A.COMPLT_TM <  :t_to
          AND A.FAC_ID IN ('M14', 'M16')
    )
)
WHERE GUBUN IS NOT NULL
GROUP BY GUBUN, GROUP1
ORDER BY GROUP1, GUBUN
"""

# ★ v4.2 — PIO 12개를 맨 뒤에만 붙인다. 기존 265개 위치는 그대로다.
CSV_HEADER  = ["CRT_TM"] + RAW_COLS_265 + PIO_COLUMNS
OUTPUT_NAME = "M16A_HUBROOM_PR.CSV"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("idc_일자다운로드")


def build_sql():
    pivot_cols = ",\n  ".join(
        f"MAX(CASE WHEN IDC_NM='{nm}' THEN IDC_VAL END) AS \"{nm}\""
        for nm in RAW_COLS_265
    )
    in_list = ",\n    ".join(f"'{nm}'" for nm in RAW_COLS_265)
    return f"""
SELECT
  TO_CHAR(CRT_TM, 'YYYY-MM-DD HH24:MI:SS') AS CRT_TM,
  {pivot_cols}
FROM AWS_IDC_DATA_HIS
WHERE CRT_TM >= TO_DATE(:t_start, 'YYYY-MM-DD HH24:MI:SS')
  AND CRT_TM <  TO_DATE(:t_end,   'YYYY-MM-DD HH24:MI:SS')
  AND IDC_NM IN (
    {in_list}
  )
GROUP BY CRT_TM
ORDER BY CRT_TM
""".strip()


SQL_QUERY = build_sql()


def parse_yyyymmdd(s):
    s = s.strip()
    if len(s) == 8 and s.isdigit():
        return datetime.strptime(s, '%Y%m%d')
    if len(s) == 10:
        return datetime.strptime(s, '%Y-%m-%d')
    raise ValueError(f"날짜 형식 오류: {s} (YYYYMMDD 또는 YYYY-MM-DD)")


def fetch_pio(conn, day_dt, use_pio=True):
    """
    ★ v4.2 — 그 날 24시간의 경로별 DEPOSIT 실패 건수를 읽는다.

      반환 : {'YYYY-MM-DD HH:MM': {경로: 건수}}
             실패 없는 분은 키 자체가 없다 (호출부에서 0 으로 채운다)

    ★ 이 함수는 어떤 경우에도 예외를 밖으로 내보내지 않는다.
       PIO 쪽 문제로 265컬럼 다운로드가 멈추면 안 되기 때문이다.
       조회가 안 되면 빈 dict 를 돌려주고, 그 날 PIO 값은 전부 0 이 된다.
    """
    if not (use_pio and PIO_ENABLE):
        return {}

    cur = None
    try:
        t_from = day_dt.strftime('%Y%m%d000000')
        t_to = (day_dt + timedelta(days=1)).strftime('%Y%m%d000000')
        cur = conn.cursor()
        cur.execute(SQL_PIO, {'t_from': t_from, 't_to': t_to})
        out = {}
        n = 0
        for gubun, gmin, cnt in cur.fetchall():
            if not gubun or not gmin:
                continue
            out.setdefault(str(gmin)[:16], {})[str(gubun)] = int(cnt or 0)
            n += 1
        tot = sum(sum(v.values()) for v in out.values())
        log.info(f"  PIO: 실패 있는 (분×경로) {n}건 · 합계 {tot}건 · {len(out)}분")
        return out
    except Exception as e:
        # 여기서 삼킨다. 절대 위로 던지지 않는다.
        log.warning(f"  PIO 조회 실패 — 이 날 PIO 값은 0 으로 둔다: {e}")
        return {}
    finally:
        try:
            if cur is not None:
                cur.close()
        except Exception:
            pass


def fetch_day(conn, day_dt, out_dir, fname, use_pio=True):
    t_start = day_dt.strftime('%Y-%m-%d 00:00:00')
    t_end = (day_dt + timedelta(days=1)).strftime('%Y-%m-%d 00:00:00')
    log.info(f"쿼리: {t_start} ≤ CRT_TM < {t_end}")

    with conn.cursor() as cur:
        cur.execute(SQL_QUERY, t_start=t_start, t_end=t_end)
        rows = cur.fetchall()
    log.info(f"수신: {len(rows)}행")

    # 분 단위 머지
    merged = {}
    for r in rows:
        if not r or r[0] is None: continue
        t_str = str(r[0])
        minute_key = t_str[:16] + ':00' if len(t_str) >= 16 else t_str
        if minute_key not in merged:
            merged[minute_key] = [minute_key] + [None] * (len(r) - 1)
        for i, v in enumerate(r[1:], 1):
            if v is not None and v != '':
                merged[minute_key][i] = v
    sorted_keys = sorted(merged.keys())

    # ★ v4.2 — PIO 12칸을 각 행 뒤에 붙인다. 조회 실패 시엔 전부 0.
    pio_by_min = fetch_pio(conn, day_dt, use_pio)
    sorted_rows = []
    for k in sorted_keys:
        per = pio_by_min.get(k[:16]) or {}
        sorted_rows.append(merged[k] + [per.get(g, 0) for g in PIO_GUBUNS])

    out_path = Path(out_dir) / fname
    with open(out_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
        writer.writerow(CSV_HEADER)
        for r in sorted_rows:
            writer.writerow(["" if v is None else v for v in r])
    log.info(f"✅ 저장: {out_path}  ({len(sorted_rows)}분 / "
             f"{len(RAW_COLS_265)} + PIO {len(PIO_COLUMNS)} 컬럼)")
    return len(sorted_rows)


def main():
    if len(sys.argv) < 2:
        print(__doc__); return

    date_args = []
    out_dir = './raw'
    use_pio = True
    i = 1
    while i < len(sys.argv):
        a = sys.argv[i]
        if a == '-o' and i+1 < len(sys.argv):
            out_dir = sys.argv[i+1]; i += 2; continue
        if a == '--no-pio':                      # ★ v4.2
            use_pio = False; i += 1; continue
        date_args.append(a)
        i += 1

    if not date_args:
        print(__doc__); return

    # 단일 일자 또는 시작~끝 범위
    if len(date_args) == 1:
        d_start = d_end = parse_yyyymmdd(date_args[0])
        is_range = False
    else:
        d_start = parse_yyyymmdd(date_args[0])
        d_end = parse_yyyymmdd(date_args[1])
        if d_end < d_start:
            d_start, d_end = d_end, d_start
        is_range = (d_start != d_end)

    os.makedirs(out_dir, exist_ok=True)
    n_days = (d_end - d_start).days + 1

    log.info("=" * 60)
    log.info("AWS_IDC_DATA_HIS — 일자 다운로드 v4.2")
    log.info(f"  DSN     : {ORACLE_DSN}")
    log.info(f"  USER    : {ORACLE_USER}")
    if is_range:
        log.info(f"  기간    : {d_start.strftime('%Y-%m-%d')} ~ {d_end.strftime('%Y-%m-%d')} ({n_days}일)")
        log.info(f"  출력    : {out_dir}/M16A_HUBROOM_PR_YYYYMMDD.CSV (일자별)")
    else:
        log.info(f"  날짜    : {d_start.strftime('%Y-%m-%d')}")
        log.info(f"  출력    : {out_dir}/{OUTPUT_NAME}")
    log.info(f"  컬럼    : {len(RAW_COLS_265)}개 IDC + CRT_TM + PIO {len(PIO_COLUMNS)}개")
    log.info(f"  PIO     : {'ON' if (use_pio and PIO_ENABLE) else 'OFF'} "
             f"— STA_TRANS_TIMEOUT_FAIL_HIS")
    log.info("=" * 60)

    log.info("Oracle 연결 시도...")
    conn = oracledb.connect(user=ORACLE_USER, password=ORACLE_PASSWORD, dsn=ORACLE_DSN)
    log.info("Oracle 연결 성공")

    total_min = 0
    d = d_start
    try:
        while d <= d_end:
            # 단일이면 고정 파일명, 범위면 날짜 붙여서 일자별 저장
            fname = OUTPUT_NAME if not is_range else f"M16A_HUBROOM_PR_{d.strftime('%Y%m%d')}.CSV"
            log.info(f"━━ {d.strftime('%Y-%m-%d')} ━━")
            try:
                total_min += fetch_day(conn, d, out_dir, fname, use_pio)
            except Exception as e:
                log.exception(f"  실패: {e}")
            d += timedelta(days=1)
    finally:
        try: conn.close()
        except: pass
    log.info(f"🎉 완료 — 총 {total_min}분 / {n_days}일")


if __name__ == '__main__':
    main()
