package com.skhynix.smartatlas.data;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ConcurrentMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.logpresso.client.Tuple;
import com.skhynix.smartatlas.data.eq.AmpUnit;
import com.skhynix.smartatlas.data.eq.Conveyor;
import com.skhynix.smartatlas.data.eq.Eqp;
import com.skhynix.smartatlas.data.eq.Fio;
import com.skhynix.smartatlas.data.eq.Oht;
import com.skhynix.smartatlas.data.eq.StbGroup;
import com.skhynix.smartatlas.data.eq.Stocker;
import com.skhynix.smartatlas.db.logpresso.LogpressoAPI;
import com.skhynix.smartatlas.map.AbstractEdge;
import com.skhynix.smartatlas.map.AbstractNode;
import com.skhynix.smartatlas.map.CarrierContainable;
import com.skhynix.smartatlas.map.CarrierTransportable;
import com.skhynix.smartatlas.map.Label;
import com.skhynix.smartatlas.map.Vhl;
import com.skhynix.smartatlas.map.edge.AgvEdge;
import com.skhynix.smartatlas.map.edge.BranchJoinEdge;
import com.skhynix.smartatlas.map.edge.CnvEdge;
import com.skhynix.smartatlas.map.edge.LongEdge;
import com.skhynix.smartatlas.map.edge.RailEdge;
import com.skhynix.smartatlas.map.edge.Station;
import com.skhynix.smartatlas.map.edge.StkRmEdge;
import com.skhynix.smartatlas.map.edge.TransferEdge;
import com.skhynix.smartatlas.map.node.CnvPortNode;
import com.skhynix.smartatlas.map.node.EqpPortNode;
import com.skhynix.smartatlas.map.node.FioPortNode;
import com.skhynix.smartatlas.map.node.RailNode;
import com.skhynix.smartatlas.map.node.StbNode;
import com.skhynix.smartatlas.map.node.StkPortNode;
import com.skhynix.smartatlas.map.node.StkPortNode.SubPort;
import com.skhynix.smartatlas.map.node.StkRmNode;
import com.skhynix.smartatlas.map.node.StkShelfNode;
import com.skhynix.smartatlas.util.JsonUtil;

public class DataSet {
	private ConcurrentHashMap<String, RailEdge> railEdgeMap 			= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, StkRmEdge> stkRmEdgeMap 			= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, CnvEdge> cnvEdgeMap 				= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, TransferEdge> transferEdgeMap 	= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, AbstractEdge> edgeMap 			= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, LongEdge> longEdgeMap 			= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Vhl> vhlMap 						= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, BranchJoinEdge> branchJoinEdgeMap = new ConcurrentHashMap<>();

	//Station ID별 Station
	private ConcurrentHashMap<String, Station> stationMap 				= new ConcurrentHashMap<>();
	//PortName별 Station
	private ConcurrentHashMap<String, Station> stationPortMap 			= new ConcurrentHashMap<>();
	// 모든 Node Id별 Node
	private ConcurrentHashMap<String, AbstractNode> nodeMap 			= new ConcurrentHashMap<>();
	// 모든 Node Name별 Node
	private ConcurrentHashMap<String, AbstractNode> nodePortMap 		= new ConcurrentHashMap<>();
	// Carrier가 위치할 수 있는 fabId +:+ Name별 Node/Vhl
	private ConcurrentHashMap<String, CarrierContainable> carrierContainableMap 	= new ConcurrentHashMap<>();
	// Carrier를 이동시킬 수 있는 fabId +:+ Name별 Rm/Vhl
	private ConcurrentHashMap<String, CarrierTransportable> carrierTransportableMap	= new ConcurrentHashMap<>();
	// 생산장비 ID별
	private ConcurrentHashMap<String, Eqp> eqpMap 						= new ConcurrentHashMap<>();
	// FIO ID별
	private ConcurrentHashMap<String, Fio> fioMap 						= new ConcurrentHashMap<>();
	// OHT MCP
	private ConcurrentHashMap<String, Oht> ohtMap 						= new ConcurrentHashMap<>();
	// 모든 장비 ID별
	private ConcurrentHashMap<String, Eqp> allEqpMap 					= new ConcurrentHashMap<>();
	// 모든 장비 Name별
	private ConcurrentHashMap<String, Eqp> allEqpNameMap 				= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, StbGroup> stbGroupMap 			= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Stocker> stockerMap 				= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Conveyor> conveyorMap 			= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Set<String>> portAliasSetMap 		= new ConcurrentHashMap<>();
	private final ConcurrentHashMap<String, List<String>> portAliasListMap 	= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Command> commandMap 				= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Carrier> carrierMap 				= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Job> jobMap 						= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, CnvTask> cnvTaskMap 				= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, RouteItem> routeItemMap 			= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Label> labelMap 					= new ConcurrentHashMap<>();

	// The map to look for a branch or join quickly.
	private ConcurrentHashMap<String,List<AbstractEdge>> fromNode2Edge 	= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String,List<AbstractEdge>> toNode2Edge 	= new ConcurrentHashMap<>();

	private ConcurrentHashMap<String, Double> vhlStateMap 				= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Double> vhlDetStateMap 			= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Double> vhlCycleMap 				= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Double> vhlRunCycleMap 			= new ConcurrentHashMap<>();

	private ConcurrentHashMap<String, Double> areaVhlCountMap 			= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Integer> edgeInOutCountMap 		= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Area> areaMap 					= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, Bay> bayMap 						= new ConcurrentHashMap<>();

	private final ConcurrentHashMap<String, CnvPortNode> cnvPortNodeNoMap 	= new ConcurrentHashMap<>();		
	private ConcurrentHashMap<String, AgvEdge> agvEdgeMap 					= new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, AmpUnit> agvAmpAgvMap 				= new ConcurrentHashMap<>();
	
	private final ConcurrentLinkedQueue<Map.Entry<String, LongEdge>> cnvLongEdgeBufferMap 	= new ConcurrentLinkedQueue<>();
	private final ConcurrentLinkedQueue<Map.Entry<String, CnvTask>> cnvTaskBufferMap 		= new ConcurrentLinkedQueue<>();		
	private final ConcurrentLinkedQueue<Map.Entry<String, AgvEdge>> agvEdgeBufferMap 		= new ConcurrentLinkedQueue<>();
	private final ConcurrentLinkedQueue<Map.Entry<String, AmpUnit>> ampAgvBufferMap 		= new ConcurrentLinkedQueue<>();
	private final ConcurrentLinkedQueue<Map.Entry<String, AmpUnit>> ampCnvBufferMap 		= new ConcurrentLinkedQueue<>();

	public static final String STK_PREFIX 				= "STK";
	public static final String STB_GROUP_PREFIX 		= "SBG";
	public static final String EQP_PREFIX 				= "EQP";
	public static final String FIO_PREFIX 				= "FIO";
	public static final String OHT_PREFIX 				= "OHT";
	public static final String VHL_PREFIX 				= "VHL";
	public static final String CNV_PREFIX 				= "CNV";
	public static final String RAIL_NODE_PREFIX 		= "RN";
	public static final String RAIL_EDGE_PREFIX 		= "RE";
	public static final String TRANS_EDGE_PREFIX 		= "TE";
	public static final String STK_RM_EDGE_PREFIX 		= "SRE";
	public static final String CNV_EDGE_PREFIX 			= "CE";
	public static final String LONG_EDGE_PREFIX 		= "LE";
	public static final String BRANCHJOIN_EDGE_PREFIX 	= "BJE";
	public static final String STK_PORT_NODE_PREFIX 	= "SPN";
	public static final String CNV_PORT_NODE_PREFIX 	= "CPN";
	public static final String STK_RM_NODE_PREFIX 		= "SRN";
	public static final String STK_SHELF_NODE_PREFIX 	= "SSN";
	public static final String STB_PORT_NODE_PREFIX 	= "SBN";
	public static final String EQP_PORT_NODE_PREFIX 	= "EPN";
	public static final String FIO_PORT_NODE_PREFIX 	= "FPN";
	public static final String STATION_PREFIX 			= "ST";
	public static final String CARRIER_PREFIX 			= "CARRIER";
	public static final String COMMAND_PREFIX 			= "CMD";
	public static final String JOB_PREFIX 				= "JOB";
	public static final String ROUTE_ITEM_PREFIX 		= "RI";
	public static final String LABEL_PREFIX 			= "LB";
	public static final String AREA_PREFIX 				= "AR";
	public static final String BAY_PREFIX 				= "BA";
	public static final String AGV_PREFIX 				= "AGV";

	//	key:hid, val:vehicle count
//	private final ConcurrentHashMap<String, Integer> hidVehicleCnt = new ConcurrentHashMap<>();

	// HID 값을 키로 하는 OHT 에러 저장 값 --- key : {fabId}:{hidId}
	private final ConcurrentMap<String, HidOffRecordItem> hidOffRecordMap = new ConcurrentHashMap<>();
	private final ConcurrentMap<String, VhlOffRecordItem> vhlOffRecordMap = new ConcurrentHashMap<>();

	// key: {fabId}:{fromAddress}-{toAddress}
	private ConcurrentMap<String, RailCutRecordItem> railCutRecordMap = new ConcurrentHashMap<>();

	private ConcurrentMap<String, List<String>> railEdge4HidMap = new ConcurrentHashMap<>();
	private ConcurrentMap<String, List<String>> hid2PortMap = new ConcurrentHashMap<>();

	// stage command monitoring key: {fabId}:{machineId} / val: 제적수
	private ConcurrentMap<String, StageCommandRecordItem> stageCommandMap = new ConcurrentHashMap<>();

	// monitoring batch 에 사용
	private ConcurrentMap<String, VhlOffRecordItem> vhlOffMonitoringMap = new ConcurrentHashMap<>();
//	private ConcurrentMap<String, List<String>> stageCommandMonitoringMap = new ConcurrentHashMap<>();

	// vhl cnt, key: {fabId}:{hidId}
	private ConcurrentMap<String, List<String>> vehicleCountMap = new ConcurrentHashMap<>();
	private ConcurrentMap<String, Integer> hidVehicleCountMap = new ConcurrentHashMap<>();

	// rail vibration, key: {fabId}:{address}
	private ConcurrentMap<String, RailVibrationRecordItem> railVibrationRecordMap = new ConcurrentHashMap<>();
	
	// Alarm 기준정보 Map, key: {fbcId}:{limit}
	private ConcurrentMap<String, Integer> alarmLimitMap = new ConcurrentHashMap<>();

	public DataSet(
			Map<String, RailEdge> railEdgeMap, 			//	1
			Map<String, StkRmEdge> stkRmEdgeMap,		//	2
			Map<String, Station> stationMap, 			//	3
			Map<String, TransferEdge> transferEdgeMap,	// 	4
			Map<String, AbstractNode> nodeMap, 			//	5
			Map<String, Eqp> eqpMap, 					//	6
			Map<String, Fio> fioMap,					//	7
			Map<String, Oht> ohtMap, 					//	8
			Map<String, StbGroup> stbGroupMap, 			//	9
			Map<String, Stocker> stockerMap,			//	10
			Map<String, List<String>> portAliasListMap,	//	11
			Map<String, Vhl> vhlMap,					//	12
			Map<String, LongEdge> longEdgeMap,			//	13
			Map<String, Conveyor> conveyorMap,			//	14
			Map<String, CnvEdge> cnvEdgeMap,			//	15
			Map<String, Label> labelMap,				//	16
			Map<String, Area> areaMap,					//	17
			Map<String, Bay> bayMap,					//	18
			Map<String,List<AbstractEdge>> fromNode2Edge, 	//	19
			Map<String,List<AbstractEdge>> toNode2Edge,		//	20
			Map<String, BranchJoinEdge> branchJoinMap,		//	21
			Map<String, RailCutRecordItem> tmpRailCutMap,	//	22
			Map<String, Integer> vhlCntMap,				//	23
			Map<String, AgvEdge> agvEdgeMap,			//	24
			Map<String, AmpUnit> agvAmpAgvMap,				//	25
			Map<String, Integer> alarmLimitMap			//	26
	) {
		super();

		this.hidVehicleCountMap.putAll(vhlCntMap);
		this.railEdgeMap.putAll(railEdgeMap);

		for (RailEdge re : this.railEdgeMap.values()) {
			if (re.getVelocity() <= 0) {
				re.setVelocity(re.getMaxVelocity());
			}
		}

		this.areaMap.putAll(areaMap);
		this.bayMap.putAll(bayMap);
		this.stkRmEdgeMap.putAll(stkRmEdgeMap);
		this.cnvEdgeMap.putAll(cnvEdgeMap);
		this.transferEdgeMap.putAll(transferEdgeMap);
		this.longEdgeMap.putAll(longEdgeMap);
		this.conveyorMap.putAll(conveyorMap);
		this.agvEdgeMap.putAll(agvEdgeMap);
		this.edgeMap.putAll(railEdgeMap);
		this.edgeMap.putAll(stkRmEdgeMap);
		this.edgeMap.putAll(transferEdgeMap);
		this.edgeMap.putAll(cnvEdgeMap);		
		this.edgeMap.putAll(agvEdgeMap);
		this.vhlMap.putAll(vhlMap);
		this.stationMap.putAll(stationMap);
		this.nodeMap.putAll(nodeMap);
		this.eqpMap.putAll(eqpMap);
		this.fioMap.putAll(fioMap);
		this.ohtMap.putAll(ohtMap);
		this.stbGroupMap.putAll(stbGroupMap);
		this.stockerMap.putAll(stockerMap);
		this.agvAmpAgvMap.putAll(agvAmpAgvMap);
		this.allEqpMap.putAll(eqpMap);
		this.allEqpMap.putAll(fioMap);
		this.allEqpMap.putAll(ohtMap);
		this.allEqpMap.putAll(stbGroupMap);
		this.allEqpMap.putAll(stockerMap);
		this.allEqpMap.putAll(conveyorMap);		
		this.allEqpMap.putAll(agvAmpAgvMap);
		

		this.allEqpMap.values().parallelStream().forEach(eqp -> this.allEqpNameMap.put(eqp.getName(), eqp));

		this.railCutRecordMap.putAll(tmpRailCutMap);
		
		this.alarmLimitMap.putAll(alarmLimitMap);

		for (Station st : this.stationMap.values()) {
			if (
					StringUtils.isNotEmpty(st.getPortId())
							&& !st.getPortId().startsWith("ST-")
			) {
				this.stationPortMap.put(st.getPortId(), st);
			}
		}

		for (AbstractNode n : this.nodeMap.values()) {
			if(n instanceof StkPortNode) {
				StkPortNode spn = (StkPortNode)n;

				this.nodePortMap.put(spn.getName(), spn);

				for (SubPort ssp : spn.getSubPortList()) {
					this.nodePortMap.put(ssp.name, spn);
				}
			} else if (n instanceof FioPortNode) {
				FioPortNode fpn = (FioPortNode)n;

				this.nodePortMap.put(fpn.getName(), fpn);

				for (FioPortNode.SubPort fsp : fpn.getSubPortList()) {
					this.nodePortMap.put(fsp.name, fpn);
				}
			} else if (n instanceof EqpPortNode) {
				EqpPortNode epn = (EqpPortNode)n;

				this.nodePortMap.put(epn.getName(), epn);
			} else if (n instanceof StbNode) {
				StbNode sbn = (StbNode)n;

				this.nodePortMap.put(sbn.getName(), sbn);
			} else if (n instanceof StkRmNode) {
				StkRmNode  srn = (StkRmNode)n;

				this.nodePortMap.put(srn.getName(), srn);

				this.carrierTransportableMap.put(srn.getFabId() + ":" + srn.getName(), srn);
			} else if (n instanceof StkShelfNode) {
				StkShelfNode  ssn = (StkShelfNode)n;

				this.nodePortMap.put(ssn.getName(), ssn);
			} else if (n instanceof CnvPortNode) {
				CnvPortNode  cpn = (CnvPortNode)n;

				this.nodePortMap.put(cpn.getName(), cpn);
				this.cnvPortNodeNoMap.put(cpn.getEqpId() + ":" + cpn.getZoneNo(), cpn);
			}
		}

		this.nodePortMap.keySet().parallelStream().forEach(key -> this.carrierContainableMap.put(
				this.nodePortMap.get(key).getFabId() + ":" + key,
				(CarrierContainable)this.nodePortMap.get(key)
		));

		this.vhlMap.values().parallelStream().forEach(v -> {
			this.carrierContainableMap.put(v.getFabId() + ":" + v.getName(), v);

			this.carrierTransportableMap.put(v.getFabId() + ":" + v.getName(), v);
		});

		for (Entry<String,List<String>> entry : portAliasListMap.entrySet()) {
			this.portAliasSetMap.put(entry.getKey(), new HashSet<>(entry.getValue()));
		}

		this.portAliasListMap.putAll(portAliasListMap);
		this.labelMap.putAll(labelMap);
		this.fromNode2Edge.putAll(fromNode2Edge);
		this.toNode2Edge.putAll(toNode2Edge);
		this.branchJoinEdgeMap.putAll(branchJoinMap);

		this._initDataByRailEdgeMap(this.railEdgeMap);
	}

	public void addDataSet(
			Map<String, RailEdge> railEdgeMap,
			Map<String, StkRmEdge> stkRmEdgeMap,
			Map<String, Station> stationMap,
			Map<String, TransferEdge> transferEdgeMap,
			Map<String, AbstractNode> nodeMap,
			Map<String, Eqp> eqpMap,
			Map<String, Fio> fioMap,
			Map<String, Oht> ohtMap,
			Map<String, StbGroup> stbGroupMap,
			Map<String, Stocker> stockerMap,
			Map<String, List<String>> portAliasListMap,
			Map<String, Vhl> vhlMap,
			Map<String, LongEdge> longEdgeMap,
			Map<String, Conveyor> conveyorMap,
			Map<String, CnvEdge> cnvEdgeMap,
			Map<String, Label> labelMap,
			Map<String, Area> areaMap,
			Map<String, Bay> bayMap,
			Map<String,List<AbstractEdge>> fromNode2Edge,
			Map<String,List<AbstractEdge>> toNode2Edge,
			Map<String, BranchJoinEdge> branchJoinMap,
			Map<String, RailCutRecordItem> railCutMap,
			Map<String, Integer> vhlCntMap,
			Map<String, AgvEdge> agvEdgeMap,
			Map<String, AmpUnit> agvAmpAgvMap,
			Map<String, Integer> alarmLimitMap
	) {
		for (RailEdge re : railEdgeMap.values()) {
			if (re.getVelocity() <= 0) {
				re.setVelocity(re.getMaxVelocity());
			}
		}
		
		this.areaMap.putAll(areaMap);
		this.bayMap.putAll(bayMap);
		this.railEdgeMap.putAll(railEdgeMap);
		this.stkRmEdgeMap.putAll(stkRmEdgeMap);
		this.cnvEdgeMap.putAll(cnvEdgeMap);
		this.transferEdgeMap.putAll(transferEdgeMap);
		this.longEdgeMap.putAll(longEdgeMap);
		this.agvEdgeMap.putAll(agvEdgeMap);
		this.edgeMap.putAll(railEdgeMap);
		this.edgeMap.putAll(stkRmEdgeMap);
		this.edgeMap.putAll(transferEdgeMap);
		this.edgeMap.putAll(cnvEdgeMap);
		this.edgeMap.putAll(agvEdgeMap);
		this.vhlMap.putAll(vhlMap);
		this.stationMap.putAll(stationMap);
		this.nodeMap.putAll(nodeMap);
		this.eqpMap.putAll(eqpMap);
		this.fioMap.putAll(fioMap);
		this.ohtMap.putAll(ohtMap);
		this.stbGroupMap.putAll(stbGroupMap);
		this.stockerMap.putAll(stockerMap);
		this.conveyorMap.putAll(conveyorMap);
		this.agvAmpAgvMap.putAll(agvAmpAgvMap);
		this.allEqpMap.putAll(eqpMap);
		this.allEqpMap.putAll(fioMap);
		this.allEqpMap.putAll(ohtMap);
		this.allEqpMap.putAll(stbGroupMap);
		this.allEqpMap.putAll(stockerMap);
		this.allEqpMap.putAll(conveyorMap);
		this.allEqpMap.putAll(agvAmpAgvMap);
		this.hidVehicleCountMap.putAll(vhlCntMap);

		this.allEqpMap.values().parallelStream().forEach(eqp -> this.allEqpNameMap.put(eqp.getName(), eqp));

		this.branchJoinEdgeMap.putAll(branchJoinMap);

		this.railCutRecordMap.putAll(railCutMap);
		
		this.alarmLimitMap.putAll(alarmLimitMap);

		for (String key : this.stationMap.keySet()) {
			Station s = this.stationMap.get(key);

			if (StringUtils.isNotEmpty(s.getPortId())) {
				this.stationPortMap.put(s.getPortId(), s);
			}
		}

		for (AbstractNode n : this.nodeMap.values()) {
			if (n instanceof StkPortNode) {
				StkPortNode spn = (StkPortNode)n;

				this.nodePortMap.put(spn.getName(), spn);

				for (SubPort ssp : spn.getSubPortList()) {
					this.nodePortMap.put(ssp.name, spn);
				}
			} else if (n instanceof FioPortNode) {
				FioPortNode fpn = (FioPortNode)n;

				if (fpn.getName() != null) {
					this.nodePortMap.put(fpn.getName(), fpn);

					for (FioPortNode.SubPort fsp : fpn.getSubPortList()) {
						this.nodePortMap.put(fsp.name, fpn);
					}
				} else {
					LoggerFactory.getLogger(getClass()).error("FPN Name is null : {}", n.getId());
				}
			} else if (n instanceof EqpPortNode) {
				EqpPortNode epn = (EqpPortNode)n;

				this.nodePortMap.put(epn.getName(), epn);
			} else if (n instanceof StbNode) {
				StbNode sbn = (StbNode)n;

				this.nodePortMap.put(sbn.getName(), sbn);
			} else if (n instanceof StkRmNode) {
				StkRmNode  srn = (StkRmNode)n;

				this.nodePortMap.put(srn.getName(), srn);

				this.carrierTransportableMap.put(srn.getFabId()+":"+srn.getName(), srn);
			} else if (n instanceof StkShelfNode) {
				StkShelfNode  ssn = (StkShelfNode)n;

				this.nodePortMap.put(ssn.getName(), ssn);
			} else if (n instanceof CnvPortNode) {
				CnvPortNode  cpn = (CnvPortNode)n;

				this.nodePortMap.put(cpn.getName(), cpn);
				this.cnvPortNodeNoMap.put(cpn.getEqpId() + ":" + cpn.getZoneNo(), cpn);
				LoggerFactory.getLogger(getClass()).info(":::::::::: DataSet CnvPortNode:  {}, {},	{}", cpn.getName(), cpn.getEqpId() + ":" + cpn.getZoneNo(), cpn);
			}
		}

		this.nodePortMap.keySet().parallelStream().forEach(key -> this.carrierContainableMap.put(
				this.nodePortMap.get(key).getFabId() + ":" + key,
				(CarrierContainable)this.nodePortMap.get(key)
		));

		this.vhlMap.values().parallelStream().forEach(v -> {
			this.carrierContainableMap.put(v.getFabId() + ":" + v.getName(),v);

			this.carrierTransportableMap.put(v.getFabId() + ":" + v.getName(),v);
		});

		for (Entry<String,List<String>> entry : portAliasListMap.entrySet()) {
			this.portAliasSetMap.put(entry.getKey(), new HashSet<>(entry.getValue()));
		}

		this.portAliasListMap.putAll(portAliasListMap);
		this.labelMap.putAll(labelMap);
		this.fromNode2Edge.putAll(fromNode2Edge);
		this.toNode2Edge.putAll(toNode2Edge);

		this._initDataByRailEdgeMap(this.railEdgeMap);

	}

	private void _initDataByRailEdgeMap (Map<String, RailEdge> railEdgeMap) {
		ConcurrentMap<String, List<String>> railEdge4HidMap = new ConcurrentHashMap<>();
		ConcurrentMap<String, List<String>> hid2PortMap = new ConcurrentHashMap<>();

		for (RailEdge railEdge : railEdgeMap.values()) {
			String fabId = railEdge.getFabId();
			String mcpName = railEdge.getMcpName();
			int hidId = railEdge.getHIDId();

			if (hidId < 0) continue;

			String key = fabId + ":" + mcpName + ":" + String.format("%03d", hidId);

			List<String> portIdList = railEdge.getPortIdList();

			// #1
			if (!railEdge4HidMap.containsKey(key)) {
				railEdge4HidMap.put(key, new ArrayList<>());
			}

			railEdge4HidMap.get(key).add(railEdge.getId());

			// #2
			if (!hid2PortMap.containsKey(key)) {
				hid2PortMap.put(key, new ArrayList<>());
			}

			hid2PortMap.get(key).addAll(portIdList);
		}

		for (String key : hid2PortMap.keySet()) {
			List<String> list = hid2PortMap.get(key);

			hid2PortMap.put(key, DataSet.summarizePorts(list));
		}

		this.railEdge4HidMap = railEdge4HidMap;
		this.hid2PortMap = hid2PortMap;
	}

	public static List<String> summarizePorts(List<String> portIdList) {
		// 입력 리스트 정렬
		List<String> sortedList = portIdList.stream()
				.sorted()
				.collect(Collectors.toList());

		// 그룹화 작업
		List<String> ungroup = new ArrayList<>();
		Map<String, List<Integer>> group = new HashMap<>();

		for (String portId : sortedList) {
//			Matcher matcher = Pattern.compile("(.*?_)([A-Z]*)(\\d+)$").matcher(portId);
			Matcher matcher = Pattern.compile("(.*?)(\\d+)$").matcher(portId);

			if (matcher.find()) {
				String key = matcher.group(1);
				String suffix = matcher.group(2);

				// 문자가 없는 경우 기본값 설정
				if (suffix != null) {
					if (!group.containsKey(key)) {
						group.put(key, new ArrayList<>());
					}

					group.get(key).add(Integer.parseInt(suffix));
				}
			} else {
				ungroup.add(portId);
			}
		}

		// 숫자 그룹 정리 및 축약
		List<String> result = new ArrayList<>();

		List<String> groupKeysSorted = group.keySet().stream()
				.sorted()
				.collect(Collectors.toList());

		for (String key : groupKeysSorted) {
			List<Integer> values = group.get(key);

			result.add(key + _getPortNoSummary(values));
		}

		result.addAll(ungroup);

		return result;
	}

	private static String _getPortNoSummary (List<Integer> portNoList) {
		List<String> list = new ArrayList<>();
		List<Integer> bundleList = new ArrayList<>();

		for (int i = 0; i < portNoList.size(); i++) {
			if (i == portNoList.size() - 1 || (portNoList.get(i) + 1 == portNoList.get(i + 1))) {
				bundleList.add(portNoList.get(i));

				if (i == portNoList.size() - 1) {
					String item;

					if (bundleList.size() > 1) {
						item = String.format("%d~%d", bundleList.get(0), bundleList.get(bundleList.size() - 1));
					} else {
						item = bundleList.get(0).toString();
					}

					list.add(item);
				}
			} else if (!bundleList.isEmpty()) {
				String item;

				if (bundleList.size() > 1) {
					item = String.format("%d~%d", bundleList.get(0), bundleList.get(bundleList.size() - 1));
				} else {
					item = bundleList.get(0).toString();
				}

				list.add(item);
				bundleList.clear();
			}
		}

		return String.join(",", list);
	}

	public ConcurrentHashMap<String, RailEdge> getRailEdgeMap() {
		return railEdgeMap;
	}

	public RailEdge getRailEdgeMap(String key) {
		return railEdgeMap.getOrDefault(key, null);
	}

	public void setRailEdgeMap(ConcurrentHashMap<String, RailEdge> railEdgeMap) {
		this.railEdgeMap = railEdgeMap;
	}

	public ConcurrentHashMap<String, StkRmEdge> getStkRmEdgeMap() {
		return stkRmEdgeMap;
	}

	public void setStkRmEdgeMap(ConcurrentHashMap<String, StkRmEdge> stkRmEdgeMap) {
		this.stkRmEdgeMap = stkRmEdgeMap;
	}

	public ConcurrentHashMap<String, Station> getStationMap() {
		return stationMap;
	}

	public void setStationMap(ConcurrentHashMap<String, Station> stationMap) {
		this.stationMap = stationMap;
	}

	public ConcurrentHashMap<String, Station> getStationPortMap() {
		return stationPortMap;
	}

	public void setStationPortMap(ConcurrentHashMap<String, Station> stationPortMap) {
		this.stationPortMap = stationPortMap;
	}

	public ConcurrentHashMap<String, TransferEdge> getTransferEdgeMap() {
		return transferEdgeMap;
	}

	public void setTransferEdgeMap(ConcurrentHashMap<String, TransferEdge> transferEdgeMap) {
		this.transferEdgeMap = transferEdgeMap;
	}

	public ConcurrentHashMap<String, AbstractNode> getNodeMap() {
		return nodeMap;
	}

	public void setNodeMap(ConcurrentHashMap<String, AbstractNode> nodeMap) {
		this.nodeMap = nodeMap;
	}

	public ConcurrentHashMap<String, Eqp> getEqpMap() {
		return eqpMap;
	}

	public void setEqpMap(ConcurrentHashMap<String, Eqp> eqpMap) {
		this.eqpMap = eqpMap;
	}

	public ConcurrentHashMap<String, Fio> getFioMap() {
		return fioMap;
	}

	public void setFioMap(ConcurrentHashMap<String, Fio> fioMap) {
		this.fioMap = fioMap;
	}

	public ConcurrentHashMap<String, Oht> getOhtMap() {
		return ohtMap;
	}

	public void setOhtMap(ConcurrentHashMap<String, Oht> ohtMap) {
		this.ohtMap = ohtMap;
	}

	public ConcurrentHashMap<String, StbGroup> getStbGroupMap() {
		return stbGroupMap;
	}

	public void setStbGroupMap(ConcurrentHashMap<String, StbGroup> stbGroupMap) {
		this.stbGroupMap = stbGroupMap;
	}

	public ConcurrentHashMap<String, Stocker> getStockerMap() {
		return stockerMap;
	}

	public void setStockerMap(ConcurrentHashMap<String, Stocker> stockerMap) {
		this.stockerMap = stockerMap;
	}

	public ConcurrentHashMap<String, AbstractNode> getNodePortMap() {
		return nodePortMap;
	}

	public void setNodePortMap(ConcurrentHashMap<String, AbstractNode> nodePortMap) {
		this.nodePortMap = nodePortMap;
	}

	public ConcurrentHashMap<String, Command> getCommandMap() {
		if (this.commandMap == null) {
			this.commandMap = new ConcurrentHashMap<>();
		}

		return commandMap;
	}

	public void setCommandMap(ConcurrentHashMap<String, Command> commandMap) {
		this.commandMap = commandMap;
	}

	public ConcurrentHashMap<String, Carrier> getCarrierMap() {
		if (this.carrierMap == null) {
			this.carrierMap = new ConcurrentHashMap<>();
		}

		return carrierMap;
	}

	public void setCarrierMap(ConcurrentHashMap<String, Carrier> carrierMap) {
		this.carrierMap = carrierMap;
	}

	public ConcurrentHashMap<String, Job> getJobMap() {
		if (this.jobMap == null) {
			this.jobMap = new ConcurrentHashMap<>();
		}

		return jobMap;
	}

	public void setJobMap(ConcurrentHashMap<String, Job> jobMap) {
		this.jobMap = jobMap;
	}

	public ConcurrentHashMap<String, Set<String>> getPortAliasSetMap() {
		return portAliasSetMap;
	}

	public void setPortAliasSetMap(ConcurrentHashMap<String, Set<String>> portAliasSetMap) {
		this.portAliasSetMap = portAliasSetMap;
	}

	public ConcurrentHashMap<String, AbstractEdge> getEdgeMap() {
		return edgeMap;
	}

	public void setEdgeMap(ConcurrentHashMap<String, AbstractEdge> edgeMap) {
		this.edgeMap = edgeMap;
	}

	public ConcurrentHashMap<String, Vhl> getVhlMap() {
		return vhlMap;
	}

	public void setVhlMap(ConcurrentHashMap<String, Vhl> vhlMap) {
		this.vhlMap = vhlMap;
	}

	public ConcurrentHashMap<String, LongEdge> getLongEdgeMap() {
		return longEdgeMap;
	}

	public void setLongEdgeMap(ConcurrentHashMap<String, LongEdge> longEdgeMap) {
		this.longEdgeMap = longEdgeMap;
	}

	public ConcurrentHashMap<String, Eqp> getAllEqpMap() {
		return allEqpMap;
	}

	public void setAllEqpMap(ConcurrentHashMap<String, Eqp> allEqpMap) {
		this.allEqpMap = allEqpMap;
	}

	public ConcurrentHashMap<String, Eqp> getAllEqpNameMap() {
		return allEqpNameMap;
	}

	public void setAllEqpNameMap(ConcurrentHashMap<String, Eqp> allEqpNameMap) {
		this.allEqpNameMap = allEqpNameMap;
	}

	public ConcurrentHashMap<String, CarrierContainable> getCarrierContainableMap() {
		return carrierContainableMap;
	}

	public void setCarrierContainableMap(ConcurrentHashMap<String, CarrierContainable> carrierContainableMap) {
		this.carrierContainableMap = carrierContainableMap;
	}

	public ConcurrentHashMap<String, CarrierTransportable> getCarrierTransportableMap() {
		return carrierTransportableMap;
	}

	public void setCarrierTransportableMap(ConcurrentHashMap<String, CarrierTransportable> carrierTransportableMap) {
		this.carrierTransportableMap = carrierTransportableMap;
	}

	public ConcurrentHashMap<String, RouteItem> getRouteItemMap() {
		if(this.routeItemMap == null) {
			this.routeItemMap = new ConcurrentHashMap<>();
		}

		return routeItemMap;
	}

	public void setRouteItemMap(ConcurrentHashMap<String, RouteItem> routeItemMap) {
		this.routeItemMap = routeItemMap;
	}

	/**
	 * Returns a map having all the Label
	 * @return ConcurrentHashMap<String, Label>
	 */
	public ConcurrentHashMap<String, Label> getLabelMap() {
		return this.labelMap;
	}

	/**
	 * Set a new map having all the Label
	 * @param labelMap a map to set
	 */
	public void setLabelMap(ConcurrentHashMap<String, Label> labelMap) {
		this.labelMap = labelMap;
	}

	public ConcurrentHashMap<String, CnvEdge> getCnvEdgeMap() {
		return cnvEdgeMap;
	}

	public void setCnvEdgeMap(ConcurrentHashMap<String, CnvEdge> cnvEdgeMap) {
		this.cnvEdgeMap = cnvEdgeMap;
	}

	public ConcurrentHashMap<String, Conveyor> getConveyorMap() {
		return conveyorMap;
	}

	public void setConveyorMap(ConcurrentHashMap<String, Conveyor> conveyorMap) {
		this.conveyorMap = conveyorMap;
	}

	public CarrierContainable getCarrierContainableByCarrierLoc(String carrierLocId, String vhlFabId) {
		AbstractNode abstractNode = this.getNodePortMap().get(carrierLocId);

		if (abstractNode != null) {
			return (CarrierContainable) abstractNode;
		} else {
			return this.getCarrierContainableMap().get(vhlFabId + ":" + carrierLocId);
		}
	}

	/**
	 * Returns a map converting a from-node to edge.
	 * @return ConcurrentHashMap<String, List<AbstractEdge>>
	 */
	public ConcurrentHashMap<String, List<AbstractEdge>> getFromNode2EdgeMap() {
		return this.fromNode2Edge;
	}

	/**
	 * Set a new map converting a from-node to edge.
	 * @param fromNode2Edge a map to set
	 */
	public void setFromNode2EdgeMap(ConcurrentHashMap<String, List<AbstractEdge>> fromNode2Edge) {
		this.fromNode2Edge = fromNode2Edge;
	}

	/**
	 * Returns a map converting a to-node to edge.
	 * @return ConcurrentHashMap<String, List<AbstractEdge>>
	 */
	public ConcurrentHashMap<String, List<AbstractEdge>> getToNode2EdgeMap() {
		return this.toNode2Edge;
	}

	/**
	 * Set a new map converting a to-node to edge.
	 */
	public void setToNode2EdgeMap(ConcurrentHashMap<String, List<AbstractEdge>> fromNode2Edge) {
		this.toNode2Edge = fromNode2Edge;
	}

	/**
	 * Just helper method to re-use for converting a raw-rail-node-Id to a rail-node-Id.
	 * @return String;
	 */
	/*
		주소 값을 통해 railNodeId 값을 형성
	 	- 방식:	{fabId}:RN:{mcpName}:{주소 값}
	 	- 예시:	M14A:RN:A:1000
	 */
	public static String address2RailNodeId(
			final String fabId,
			final String mcpName,
			final int rawRailAddress
	) {
		return fabId + ":" + DataSet.RAIL_NODE_PREFIX + ":" + mcpName + ":" + String.format("%05d", rawRailAddress);
	}

	/*
		주소 값을 통해 railEdgeId 값을 형성
	 	- 방식:	{fabId}:RE:{mcpName}:{fromNodeId}-{toNodeId}
	 	- 예시:	M14A:RE:A:M14A:RN:A:1000-M14A:RN:A:1001
	*/
	public static String address2RailEdgeId(
			final String fabId,
			final String mcpName,
			final int fromRawRailAddress,
			final int toRawRailNodeAddress
	) {
		return String.format("%s:%s:%s:%s-%s",
				fabId,
				DataSet.RAIL_EDGE_PREFIX,
				mcpName,
				address2RailNodeId(fabId, mcpName, fromRawRailAddress),
				address2RailNodeId(fabId, mcpName, toRawRailNodeAddress)
		);
	}

	public static String address2RailEdgeId(
			final String fabId,
			final String mcpName,
			final String fromRailNodeId,
			final String toRailNodeId
	) {
		return String.format("%s:%s:%s:%s-%s",
				fabId,
				DataSet.RAIL_EDGE_PREFIX,
				mcpName,
				fromRailNodeId,
				toRailNodeId
		);
	}

	public ConcurrentHashMap<String, Double> getVhlStateMap() {
		if (vhlStateMap == null) {
			vhlStateMap = new ConcurrentHashMap<>();
		}

		return vhlStateMap;
	}

	public void setVhlStateMap(ConcurrentHashMap<String, Double> vhlStateMap) {
		this.vhlStateMap = vhlStateMap;
	}

	public ConcurrentHashMap<String, Double> getVhlDetStateMap() {
		if (vhlDetStateMap == null) {
			vhlDetStateMap = new ConcurrentHashMap<>();
		}

		return vhlDetStateMap;
	}

	public void setVhlDetStateMap(ConcurrentHashMap<String, Double> vhlDetStateMap) {
		this.vhlDetStateMap = vhlDetStateMap;
	}

	public ConcurrentHashMap<String, Double> getAreaVhlCountMap() {
		if (areaVhlCountMap == null ) {
			areaVhlCountMap = new ConcurrentHashMap<>();
		}

		return areaVhlCountMap;
	}

	public void setAreaVhlCountMap(ConcurrentHashMap<String, Double> areaVhlCountMap) {
		this.areaVhlCountMap = areaVhlCountMap;
	}
	
	public ConcurrentHashMap<String, Integer> getEdgeInOutCountMap() {
		if (edgeInOutCountMap == null) {
			edgeInOutCountMap = new ConcurrentHashMap<>();
		}

		return edgeInOutCountMap;
	}
	
	public ConcurrentLinkedQueue<Map.Entry<String, CnvTask>> getCnvTaskBufferMap() {
		return cnvTaskBufferMap;
	}
	
	public ConcurrentLinkedQueue<Map.Entry<String, LongEdge>> getCnvLongEdgeBufferMap() {		
		return cnvLongEdgeBufferMap;
	}
	
	public ConcurrentLinkedQueue<Map.Entry<String, AmpUnit>> getAmpAgvBufferMap() {
		return ampAgvBufferMap;
	}
	
	public ConcurrentLinkedQueue<Map.Entry<String, AmpUnit>> getAmpCnvBufferMap() {
		return ampCnvBufferMap;
	}
	
	public ConcurrentLinkedQueue<Map.Entry<String, AgvEdge>> getAgvEdgeBufferMap() {		
		return agvEdgeBufferMap;
	}
	
	public void setEdgeInOutCountMap(ConcurrentHashMap<String, Integer> edgeInOutCountMap) {
		this.edgeInOutCountMap = edgeInOutCountMap;
	}

	public ConcurrentHashMap<String, Double> getVhlCycleMap() {
		if (vhlCycleMap == null) {
			vhlCycleMap = new ConcurrentHashMap<>();
		}

		return vhlCycleMap;
	}

	public void setVhlCycleMap(ConcurrentHashMap<String, Double> vhlCycleMap) {
		this.vhlCycleMap = vhlCycleMap;
	}

	public ConcurrentHashMap<String, Double> getVhlRunCycleMap() {
		if(vhlRunCycleMap == null ) vhlRunCycleMap = new ConcurrentHashMap<>();
		return vhlRunCycleMap;
	}

	public void setVhlRunCycleMap(ConcurrentHashMap<String, Double> vhlRunCycleMap) {
		this.vhlRunCycleMap = vhlRunCycleMap;
	}

	public ConcurrentHashMap<String, Area> getAreaMap() {
		if(areaMap==null) areaMap = new ConcurrentHashMap<>();
		return areaMap;
	}

	public void setAreaMap(ConcurrentHashMap<String, Area> areaMap) {
		this.areaMap = areaMap;
	}

	/**
	 * Returns a branch join edge map.
	 * @return ConcurrentHashMap<String, BranchJoinEdge>
	 */
	public ConcurrentHashMap<String, BranchJoinEdge> getBranchJoinEdgeMap() {
		return this.branchJoinEdgeMap;
	}

	/**
	 * Sets a branch-join edge map.
	 * @param branchJoinEdgeMap
	 */
	public void setBranchJoinEdgeMap(final ConcurrentHashMap<String, BranchJoinEdge> branchJoinEdgeMap) {
		this.branchJoinEdgeMap = branchJoinEdgeMap;
	}
	
	public ConcurrentHashMap<String, AmpUnit> getAmpAgvMap() {
		if (this.agvAmpAgvMap == null) {
			this.agvAmpAgvMap = new ConcurrentHashMap<>();
		}

		return this.agvAmpAgvMap;
	}
		
	public ConcurrentHashMap<String, AgvEdge> getAgvEdgeMap() {
		if (this.agvEdgeMap == null) {
			this.agvEdgeMap = new ConcurrentHashMap<>();
		}

		return this.agvEdgeMap;
	}
	
	// limit(수량) 이내인 경우 ja에 je를 추가하여 logpresso에 적재, 새로운 JsonArray return, 아니면 추가만 해서 return.
	private JsonArray insertBufferdJsonData(JsonArray ja, JsonElement je, long limit, boolean flushFlag) {
		if (je != null) {
			ja.add(je);
		}

		if (ja != null && (ja.size() >= limit || flushFlag)) {
			String tblNm = "";

			if (ja.size() > 0) {
				List<Tuple> dataList = new ArrayList<>();
				for (JsonElement jee : ja) {
					Tuple tpl = JsonUtil.getTupleByJsonElement(jee);

					String t_tblNm = (String) Objects.requireNonNull(tpl).get("TBLNM");
					if (StringUtils.isNotEmpty(tblNm) && !tblNm.equals(t_tblNm)) {
						LogpressoAPI.setInsertTuples(tblNm, dataList, 100);
						dataList = new ArrayList<>();
					}
					dataList.add(tpl);
					tblNm = t_tblNm;
				}
				LogpressoAPI.setInsertTuples(tblNm, dataList, 100);
				ja = new JsonArray();
			}
		}
		return ja;
	}

	public void exportAllLayoutToLogpresso() {
		Gson gson 				= new Gson();
		int bufferSize 			= 50;
		int longEdgeBufferSize 	= 20;

		try {
			DateFormat dateFormat 	= new SimpleDateFormat("yyyyMMddHHmm");
			String dtStr 			= dateFormat.format(new Date(System.currentTimeMillis()));
			JsonArray ja 			= new JsonArray();

			for(RailEdge re : this.railEdgeMap.values()) {
				JsonElement je 	= gson.toJsonTree(re);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_EDGE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja 				= insertBufferdJsonData(ja, je, bufferSize, false);
			}

			for(StkRmEdge re : this.stkRmEdgeMap.values()) {
				JsonElement je 	= gson.toJsonTree(re);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_EDGE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja 				= insertBufferdJsonData(ja, je, bufferSize, false);
			}

			for(CnvEdge re : this.cnvEdgeMap.values()) {
				JsonElement je 	= gson.toJsonTree(re);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_EDGE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja 				= insertBufferdJsonData(ja, je, bufferSize, false);
			}

			for(TransferEdge re : this.transferEdgeMap.values()) {
				JsonElement je 	= gson.toJsonTree(re);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_EDGE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja 				= insertBufferdJsonData(ja, je, bufferSize, false);
			}
			ja = insertBufferdJsonData(ja, null, bufferSize, true);
			for(LongEdge re : this.longEdgeMap.values()) {
				JsonElement je 	= gson.toJsonTree(re);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_LONGEDGE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja 				= insertBufferdJsonData(ja, je, longEdgeBufferSize, false);
			}
			ja = insertBufferdJsonData(ja, null, longEdgeBufferSize, true);
			for(BranchJoinEdge re : this.branchJoinEdgeMap.values()) {
				JsonElement je 	= gson.toJsonTree(re);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_BRANCHJOINEDGE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja 				= insertBufferdJsonData(ja, je, bufferSize, false);
			}
			ja = insertBufferdJsonData(ja, null, 1024*1024*10, true);
			for(Vhl re : this.vhlMap.values()) {
				JsonElement je 	= gson.toJsonTree(re);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_VHL");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja 				= insertBufferdJsonData(ja, je, bufferSize, false);
			}
			ja = insertBufferdJsonData(ja, null, 1024*1024*10, true);
			for (Station re : this.stationMap.values()) {
				JsonElement je 	= gson.toJsonTree(re);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_STATION");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja 				= insertBufferdJsonData(ja, je, bufferSize, false);
			}
			ja 									= insertBufferdJsonData(ja, null, bufferSize, true);
			List<RailNode> railNodeList 		= new ArrayList<>();
			List<StbNode> stbNodeList 			= new ArrayList<>();
			List<EqpPortNode> eqpPortNodeList 	= new ArrayList<>();
			List<StkPortNode> stkPortNodeList 	= new ArrayList<>();
			List<CnvPortNode> cnvPortNodeList 	= new ArrayList<>();
			List<StkRmNode> stkRmNodeList 		= new ArrayList<>();
			List<StkShelfNode> stkShelfNodeList	= new ArrayList<>();
			List<FioPortNode> fioPortNodeList 	= new ArrayList<>();

			for (AbstractNode node : this.nodeMap.values()) {
				if (node instanceof RailNode) {
					railNodeList.add((RailNode)node);
				} else if (node instanceof StbNode) {
					stbNodeList.add((StbNode)node);
				} else if (node instanceof EqpPortNode) {
					eqpPortNodeList.add((EqpPortNode)node);
				} else if (node instanceof StkPortNode) {
					stkPortNodeList.add((StkPortNode)node);
				} else if (node instanceof CnvPortNode) {
					cnvPortNodeList.add((CnvPortNode)node);
				} else if (node instanceof StkRmNode) {
					stkRmNodeList.add((StkRmNode)node);
				} else if (node instanceof StkShelfNode) {
					stkShelfNodeList.add((StkShelfNode)node);
				} else if (node instanceof FioPortNode) {
					fioPortNodeList.add((FioPortNode)node);
				}
			}
			ja = insertBufferdJsonData(ja, null, bufferSize, true);
			for(RailNode rn : railNodeList) {
				JsonElement je = gson.toJsonTree(rn);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_NODE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			for(StbNode rn : stbNodeList) {
				JsonElement je = gson.toJsonTree(rn);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_NODE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			for(EqpPortNode rn : eqpPortNodeList) {
				JsonElement je = gson.toJsonTree(rn);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_NODE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			for(StkPortNode rn : stkPortNodeList) {
				JsonElement je = gson.toJsonTree(rn);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_NODE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			for(CnvPortNode rn : cnvPortNodeList) {
				JsonElement je = gson.toJsonTree(rn);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_NODE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			for(StkRmNode rn : stkRmNodeList) {
				JsonElement je = gson.toJsonTree(rn);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_NODE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			for(StkShelfNode rn : stkShelfNodeList) {
				JsonElement je = gson.toJsonTree(rn);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_NODE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			for(FioPortNode rn : fioPortNodeList) {
				JsonElement je = gson.toJsonTree(rn);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_NODE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			for(FioPortNode rn : fioPortNodeList) {
				JsonElement je = gson.toJsonTree(rn);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_NODE");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			ja = insertBufferdJsonData(ja, null, 30, true);
			for (Eqp eq : eqpMap.values()) {
				JsonElement je = gson.toJsonTree(eq);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_EQP");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			for(Fio eq : fioMap.values()) {
				JsonElement je = gson.toJsonTree(eq);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_EQP");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			for(Oht eq : ohtMap.values()) {
				JsonElement je = gson.toJsonTree(eq);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_EQP");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			for(StbGroup eq : stbGroupMap.values()) {
				JsonElement je = gson.toJsonTree(eq);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_EQP");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			for(Stocker eq : stockerMap.values()) {
				JsonElement je = gson.toJsonTree(eq);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_EQP");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			for(Conveyor eq : conveyorMap.values()) {
				JsonElement je = gson.toJsonTree(eq);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_EQP");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			ja = insertBufferdJsonData(ja, null, 30, true);
			for(Area ar : areaMap.values()) {
				JsonElement je = gson.toJsonTree(ar);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_AREA");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			ja = insertBufferdJsonData(ja, null, bufferSize, true);
			for (Bay ar : bayMap.values()) {
				JsonElement je = gson.toJsonTree(ar);
				((JsonObject)je).addProperty("TBLNM", "ATLAS_MAS_BAY");
				((JsonObject)je).addProperty("INSERT_TM", dtStr);
				ja = insertBufferdJsonData(ja, je, bufferSize, false);
			}
			insertBufferdJsonData(ja, null, bufferSize, true);
		} catch (Exception e) {
			LoggerFactory.getLogger(getClass()).error("",e);
		}
	}

	public ConcurrentHashMap<String, Bay> getBayMap() {
		if(bayMap==null) bayMap = new ConcurrentHashMap<>();
		return bayMap;
	}

	public ConcurrentHashMap<String, CnvTask> getCnvTaskMap() {
		if(this.cnvTaskMap == null) this.cnvTaskMap = new ConcurrentHashMap<>();
		return cnvTaskMap;
	}
	
	public ConcurrentHashMap<String, CnvPortNode> getCnvPortNodeNoMap() {
		return cnvPortNodeNoMap;
	}

//	public void setCnvPortNodeNoMap(ConcurrentHashMap<String, CnvPortNode> cnvPortNodeNoMap) {
//		this.cnvPortNodeNoMap = cnvPortNodeNoMap;
//	}

	public ConcurrentHashMap<String, List<String>> getPortAliasListMap() {
		return portAliasListMap;
	}

	public ConcurrentMap<String, HidOffRecordItem> getHidOffRecordMap () {
		return hidOffRecordMap;
	}

	public ConcurrentMap<String, VhlOffRecordItem> getVhlOffRecordMap () {
		return vhlOffRecordMap;
	}

	public ConcurrentMap<String, RailCutRecordItem> getRailCutRecordMap () {
		return railCutRecordMap;
	}

	public ConcurrentMap<String, RailCutRecordItem> getRailCutRecordMap (String key) {
		if (key.isEmpty() || railCutRecordMap.isEmpty()) {
			return new ConcurrentHashMap<>();
		}

		ConcurrentMap<String, RailCutRecordItem> result = new ConcurrentHashMap<>();

		for (Map.Entry<String, RailCutRecordItem> entry : railCutRecordMap.entrySet()) {
			String k = entry.getKey();

			if (k.startsWith(key)) {
				result.put(k, entry.getValue());
			}
		}

		return result;
	}

	public void setRailCutRecordMap(ConcurrentMap<String, RailCutRecordItem> railCutRecordMap) {
		this.railCutRecordMap = railCutRecordMap;
	}

//	public ConcurrentMap<String, RailVibrationRecordItem> getRailVibrationRecordMap() {
//		return railVibrationRecordMap;
//	}

//	public void setRailVibrationRecordMap(ConcurrentMap<String, RailVibrationRecordItem> railVibrationRecordMap) {
//		this.railVibrationRecordMap = railVibrationRecordMap;
//	}

	public ConcurrentMap<String, List<String>> getRailEdge4HidMap () {
		return railEdge4HidMap;
	}

	public ConcurrentMap<String, List<String>> getHid2PortMap () {
		return hid2PortMap;
	}

	public ConcurrentMap<String, StageCommandRecordItem> getStageCommandMap() {
		return stageCommandMap;
	}

	public ConcurrentMap<String, VhlOffRecordItem> getVhlOffMonitoringMap () {
		return vhlOffMonitoringMap;
	}

	public ConcurrentMap<String, RailVibrationRecordItem> getRailVibrationRecordMap() {
		return railVibrationRecordMap;
	}

	// vehicle 수 계산
	public ConcurrentMap<String, Integer> getHidVehicleCountMap() {
		return hidVehicleCountMap;
	}

	// alarm 기준정보 
	public ConcurrentMap<String, Integer> getAlarmLimitMap() {
		return alarmLimitMap;
	}

	public void increaseHidVehicleCnt(String key) {
		int count;

		if (hidVehicleCountMap.containsKey(key)) {
			count = hidVehicleCountMap.get(key);

			hidVehicleCountMap.put(key, ++count);
		} else {
			count = 1;

			hidVehicleCountMap.put(key, count);
		}

	}

	public void decreaseHidVehicleCnt(String key) {
		int count;

		if (hidVehicleCountMap.containsKey(key)) {
			count = hidVehicleCountMap.get(key);

			if (count > 0) {
				hidVehicleCountMap.put(key, --count);
			}
		}

	}
	//~VHL 제적수 계산
}