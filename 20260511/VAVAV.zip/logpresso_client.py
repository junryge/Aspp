"""
로그프레소 조회 + 저장 클라이언트
logpresso_client.py
- query_logpresso : LPQL 쿼리 조회 (기존)
- insert_logpresso : 단건/다건 INSERT (신규)
- insert_dataframe : DataFrame 배치 저장 (신규)
- verify_recent : 저장 검증용 최근 N건 조회 (신규)

INSERT 방식: json "..." | import test_table
- 기존 조회용 httpexport API 그대로 사용 (8888 포트, 동일 API_KEY)
- 별도 입력기 설정 불필요
- API_KEY에 쓰기 권한이 부여되어 있어야 함
- 저장 대상 테이블은 사전에 생성되어 있어야 함
"""
import requests
import urllib.parse
import json
import time
import pandas as pd
from io import StringIO
from datetime import datetime
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

HOST    = "10.40.42.27"
PORT    = 8888
API_KEY = "db1d2335-49cf-e859-3519-1ca132922e38"


# ═══════════════════════════════════════════════════════════════
#  조회 (기존 그대로)
# ═══════════════════════════════════════════════════════════════

def query_logpresso(query: str, timeout: int = 180):
    """
    LPQL 쿼리 실행 → (DataFrame, None) 또는 (None, error_info)

    app.py에서 호출:
        from logpresso_client import query_logpresso
        df, err = query_logpresso("table xxx | limit 5")
    """
    clean_q = " ".join(query.split())
    encoded = urllib.parse.quote(clean_q, safe="")
    url = f"http://{HOST}:{PORT}/logpresso/httpexport/query.csv?_apikey={API_KEY}&_q={encoded}"

    print(f"[Logpresso] ▶ 쿼리: {clean_q[:300]}")

    max_retries = 3
    last_error = None

    for attempt in range(max_retries):
        try:
            resp = requests.get(url, verify=False, timeout=timeout)

            if resp.status_code == 200 and resp.text.strip():
                # HTML 에러 페이지 체크
                if resp.text.strip().startswith("<!"):
                    return None, {
                        "reason": "HTTP 200 (HTML 에러 페이지 반환)",
                        "response_preview": resp.text[:500],
                        "query_sent": clean_q,
                    }
                df = pd.read_csv(StringIO(resp.text))
                print(f"[Logpresso] ✅ {len(df)}건 조회됨" + (f" (재시도 {attempt}회)" if attempt > 0 else ""))
                return df, None

            # 500/502/503 → 서버 불안정, 재시도
            if resp.status_code >= 500 and attempt < max_retries - 1:
                wait = 2 * (attempt + 1)
                print(f"[Logpresso] ⚠️ HTTP {resp.status_code} → {wait}초 후 재시도 ({attempt+1}/{max_retries})...")
                time.sleep(wait)
                last_error = f"HTTP {resp.status_code}"
                continue

            # 빈 응답 또는 비정상 상태코드
            reason = f"HTTP {resp.status_code}"
            if not resp.text.strip():
                reason += " (빈 응답)"
            if resp.text.strip().startswith("<!"):
                reason += " (HTML 에러 페이지 반환)"
            return None, {
                "reason": reason,
                "response_preview": resp.text[:500] if resp.text else "(빈 응답)",
                "query_sent": clean_q,
            }

        except (requests.exceptions.ConnectTimeout, requests.exceptions.ConnectionError) as e:
            if attempt < max_retries - 1:
                wait = 2 * (attempt + 1)
                print(f"[Logpresso] ⚠️ 연결 실패 → {wait}초 후 재시도 ({attempt+1}/{max_retries})...")
                time.sleep(wait)
                last_error = str(e)
                continue
            print(f"[Logpresso] ❌ 연결 실패 (재시도 소진): {e}")
            return None, {"reason": f"서버 연결 실패 ({e})", "query_sent": clean_q}
        except requests.exceptions.ReadTimeout:
            print(f"[Logpresso] ❌ 읽기 타임아웃 ({timeout}초)")
            return None, {"reason": f"읽기 타임아웃 ({timeout}초 초과)", "query_sent": clean_q}
        except Exception as e:
            print(f"[Logpresso] ❌ 예외: {e}")
            return None, {"reason": f"예외 발생: {type(e).__name__}: {e}", "query_sent": clean_q}

    # 모든 재시도 실패
    return None, {"reason": f"재시도 {max_retries}회 실패 ({last_error})", "query_sent": clean_q}


# ═══════════════════════════════════════════════════════════════
#  저장 (신규)
# ═══════════════════════════════════════════════════════════════

def _escape_for_json_cmd(obj) -> str:
    """
    로그프레소 json 명령에 들어갈 JSON 문자열 escape
    쿼리에서 json "..." 안의 큰따옴표를 \" 로 변환
    """
    raw = json.dumps(obj, ensure_ascii=False, default=str)
    # backslash 먼저, 그다음 큰따옴표
    return raw.replace('\\', '\\\\').replace('"', '\\"')


def insert_logpresso(table: str, data, set_time: bool = True,
                     timeout: int = 60):
    """
    레코드를 로그프레소 테이블에 저장 (단건 또는 다건)

    Parameters
    ----------
    table : str
        저장 대상 테이블명 (사전에 생성되어 있어야 함)
    data : dict | list[dict]
        dict이면 단건, list이면 다건 저장
    set_time : bool
        True이면 _time 필드가 없을 때 현재 시각으로 자동 세팅
    timeout : int
        HTTP 타임아웃 (초)

    Returns
    -------
    (적재 건수, None) 또는 (None, error_info)

    예시:
        # 단건
        inserted, err = insert_logpresso("test_table", {"metric": "hub", "value": 285})

        # 다건
        records = [{"metric": "hub", "value": 285}, {"metric": "cmd", "value": 215}]
        inserted, err = insert_logpresso("test_table", records)
    """
    # 입력 정규화
    if isinstance(data, dict):
        records = [data]
    elif isinstance(data, list):
        records = data
    else:
        return None, {"reason": f"data는 dict 또는 list만 가능 (현재: {type(data).__name__})"}

    if not records:
        return 0, None

    # JSON payload 생성 (단건이어도 배열로 통일)
    payload = _escape_for_json_cmd(records if len(records) > 1 else records[0])

    # _time 자동 세팅 절: isnull 체크로 기존 _time이 있으면 우선
    time_clause = '| eval _time = if(isnull(_time), now(), _time) ' if set_time else ''

    q = f'json "{payload}" {time_clause}| import {table}'
    clean_q = " ".join(q.split())
    encoded = urllib.parse.quote(clean_q, safe="")
    url = f"http://{HOST}:{PORT}/logpresso/httpexport/query.csv?_apikey={API_KEY}&_q={encoded}"

    # URL 길이 사전 체크 (HTTP GET 제한 회피)
    if len(url) > 7500:
        return None, {
            "reason": f"URL too long ({len(url)} bytes) - batch_size를 줄이거나 insert_dataframe() 사용",
            "record_count": len(records),
            "query_sent": clean_q[:300],
        }

    print(f"[Logpresso] ▶ INSERT {table} ({len(records)}건)")

    max_retries = 3
    last_error = None

    for attempt in range(max_retries):
        try:
            resp = requests.get(url, verify=False, timeout=timeout)

            if resp.status_code == 200 and resp.text.strip():
                # HTML 에러 페이지 체크
                if resp.text.strip().startswith("<!"):
                    return None, {
                        "reason": "HTTP 200 (HTML 에러 페이지 - 권한 또는 쿼리 오류 가능성)",
                        "response_preview": resp.text[:500],
                        "query_sent": clean_q[:300],
                    }
                # import는 적재된 레코드를 그대로 출력하므로 응답 행 수 = 적재 건수
                df = pd.read_csv(StringIO(resp.text))
                inserted = len(df)
                print(f"[Logpresso] ✅ INSERT {inserted}건 완료" + (f" (재시도 {attempt}회)" if attempt > 0 else ""))
                return inserted, None

            # 500/502/503 → 재시도
            if resp.status_code >= 500 and attempt < max_retries - 1:
                wait = 2 * (attempt + 1)
                print(f"[Logpresso] ⚠️ HTTP {resp.status_code} → {wait}초 후 재시도 ({attempt+1}/{max_retries})...")
                time.sleep(wait)
                last_error = f"HTTP {resp.status_code}"
                continue

            # 비정상 상태
            reason = f"HTTP {resp.status_code}"
            if not resp.text.strip():
                reason += " (빈 응답 - 권한 부족 가능성)"
            if resp.text.strip().startswith("<!"):
                reason += " (HTML 에러 페이지 반환)"
            return None, {
                "reason": reason,
                "response_preview": resp.text[:500] if resp.text else "(빈 응답)",
                "query_sent": clean_q[:300],
            }

        except (requests.exceptions.ConnectTimeout, requests.exceptions.ConnectionError) as e:
            if attempt < max_retries - 1:
                wait = 2 * (attempt + 1)
                print(f"[Logpresso] ⚠️ 연결 실패 → {wait}초 후 재시도 ({attempt+1}/{max_retries})...")
                time.sleep(wait)
                last_error = str(e)
                continue
            print(f"[Logpresso] ❌ 연결 실패 (재시도 소진): {e}")
            return None, {"reason": f"서버 연결 실패 ({e})", "query_sent": clean_q[:300]}
        except requests.exceptions.ReadTimeout:
            print(f"[Logpresso] ❌ 읽기 타임아웃 ({timeout}초)")
            return None, {"reason": f"읽기 타임아웃 ({timeout}초 초과)", "query_sent": clean_q[:300]}
        except Exception as e:
            print(f"[Logpresso] ❌ 예외: {e}")
            return None, {"reason": f"예외 발생: {type(e).__name__}: {e}", "query_sent": clean_q[:300]}

    return None, {"reason": f"재시도 {max_retries}회 실패 ({last_error})", "query_sent": clean_q[:300]}


def insert_dataframe(table: str, df: pd.DataFrame,
                     time_col: str = None,
                     batch_size: int = 100,
                     timeout: int = 60):
    """
    DataFrame을 배치 단위로 분할 저장

    Parameters
    ----------
    table : str
        저장 대상 테이블명
    df : pd.DataFrame
        저장할 데이터프레임
    time_col : str, optional
        _time으로 매핑할 컬럼명 (예: 'CRT_TM').
        None이면 현재 시각이 자동 세팅됨.
        yyyyMMddHHmm 형식 우선 시도 → 실패 시 일반 파싱
    batch_size : int
        한 배치당 행 수 (URL 길이 제한 회피, 50~200 권장)
    timeout : int
        HTTP 타임아웃 (초)

    Returns
    -------
    (총 적재 행수, None) 또는 (None, error_info)
        - 부분 실패 시 error_info에 partial_inserted 포함

    예시:
        # 1분 집계 DataFrame 저장 (CRT_TM 기준)
        inserted, err = insert_dataframe("test_table", df, time_col="CRT_TM")
    """
    if df.empty:
        return 0, None

    df2 = df.copy()
    set_time_in_query = True  # 쿼리 안에서 _time 자동 세팅 여부

    # time_col → _time 컬럼 변환
    if time_col and time_col in df2.columns:
        try:
            # yyyyMMddHHmm 형식 우선
            df2['_time'] = pd.to_datetime(df2[time_col], format='%Y%m%d%H%M',
                                          errors='coerce').dt.strftime('%Y-%m-%dT%H:%M:%S')
            if df2['_time'].isnull().all():
                # 형식 안 맞으면 자유 파싱
                df2['_time'] = pd.to_datetime(df2[time_col], errors='coerce').dt.strftime('%Y-%m-%dT%H:%M:%S')
        except Exception:
            df2['_time'] = pd.to_datetime(df2[time_col], errors='coerce').dt.strftime('%Y-%m-%dT%H:%M:%S')
        set_time_in_query = False  # 직접 세팅했으므로

    # NaN → None (JSON 직렬화 호환)
    records = df2.where(pd.notnull(df2), None).to_dict(orient='records')

    total_rows = len(records)
    total = 0
    n_batches = (total_rows + batch_size - 1) // batch_size

    print(f"[Logpresso] ▶ INSERT_DF {table} (총 {total_rows}건, {n_batches}배치)")

    for i in range(0, total_rows, batch_size):
        chunk = records[i:i + batch_size]
        inserted, err = insert_logpresso(table, chunk,
                                          set_time=set_time_in_query,
                                          timeout=timeout)
        if err:
            return None, {**err, "partial_inserted": total,
                         "failed_batch_index": i // batch_size}
        total += inserted or 0

    print(f"[Logpresso] ✅ INSERT_DF 완료 (총 {total}건)")
    return total, None


def verify_recent(table: str, n: int = 5):
    """
    저장 검증용: 최근 N건 조회

    예시:
        df, err = verify_recent("test_table", n=10)
    """
    q = f'table {table} | sort -_time | limit 0 {n}'
    return query_logpresso(q)


# ═══════════════════════════════════════════════════════════════
#  기존 캐리어 조회 함수 (변경 없음)
# ═══════════════════════════════════════════════════════════════

def query_carrier(from_dt: str, to_dt: str, carrier: str = "", text: str = "") -> pd.DataFrame:
    """
    캐리어/TEXT 조회 전용 함수
    """
    c = carrier.strip()
    t = text.strip()

    if not c and not t:
        raise ValueError("carrier 또는 text 중 하나는 반드시 입력해야 합니다.")

    if c and t:
        cond = f'((CARRIER=="{c}") or (TEXT=="{t}"))'
    elif c:
        cond = f'((CARRIER=="{c}") or (TEXT=="{c}"))'
    else:
        cond = f'((TEXT=="{t}"))'

    q = (
        f'fulltext from={from_dt} to={to_dt} '
        f'(LEVEL=="WELL" or LEVEL=="WARN" or LEVEL=="ERROR" or LEVEL=="FATAL") '
        f'and {cond} '
        f'from ts_data_view_m14a, ts_data_view_m14b, ts_data_view_m16, ts_data_view_m16b '
        f'| fields _time, TIME_EX, MACHINENAME, MACHINETYPE, UNITNAME, CARRIER, COMMANDID, COMMAND, OPERATION_NAME, MESSAGENAME, PROCESS, TRANSACTIONID, TEXT, THREAD, LEVEL, XML, SECSII, RESULTCODE '
        f'| sort _time '
        f'| limit 0 1000 '
        f'| eval No = seq() + 0'
    )

    df, err = query_logpresso(q)
    if err:
        raise RuntimeError(f"조회 실패: {err['reason']}")
    return df


# ═══════════════════════════════════════════════════════════════
#  테스트 (target: test_table)
# ═══════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys

    TABLE = "test_table"

    # 모드: query (기존 조회) / insert / verify / all
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"

    if mode in ("query", "조회"):
        # 기존 조회 테스트
        today = datetime.now().strftime("%Y%m%d")
        lpql = f"table from={today}000000 to={today}235959 ts_data_view_m14a | limit 5"
        print(f"\n[테스트] 쿼리 조회: {lpql}\n")
        df, err = query_logpresso(lpql)
        print(f"❌ 실패: {err}" if err else f"✅ {len(df)}건\n{df.head()}")

    elif mode == "insert":
        # ── 1. 단건 ─────────────────────────────
        print("\n[1] 단건 저장 테스트")
        rec = {"metric": "hub_value", "value": 285, "fab": "M16A", "tag": "single"}
        inserted, err = insert_logpresso(TABLE, rec)
        print(f"❌ {err}" if err else f"✅ {inserted}건 적재")

        # ── 2. 다건 ─────────────────────────────
        print("\n[2] 다건 저장 테스트")
        batch = [
            {"metric": "hub_value",  "value": 285, "fab": "M16A"},
            {"metric": "cmd_total",  "value": 215, "fab": "M16A"},
            {"metric": "fs_storage", "value": 10,  "fab": "M16A"},
        ]
        inserted, err = insert_logpresso(TABLE, batch)
        print(f"❌ {err}" if err else f"✅ {inserted}건 적재")

        # ── 3. DataFrame (CRT_TM 기준 시각 매핑) ─
        print("\n[3] DataFrame 저장 테스트")
        df = pd.DataFrame({
            'CRT_TM':  ['202605181400', '202605181401', '202605181402'],
            'metric': ['hub_value', 'hub_value', 'hub_value'],
            'value':  [285, 290, 288],
            'fab':    ['M16A', 'M16A', 'M16A'],
        })
        inserted, err = insert_dataframe(TABLE, df, time_col='CRT_TM')
        print(f"❌ {err}" if err else f"✅ {inserted}건 적재")

    elif mode == "verify":
        print(f"\n[검증] {TABLE} 최근 10건 조회")
        df, err = verify_recent(TABLE, n=10)
        print(f"❌ {err}" if err else f"✅ {len(df)}건\n{df}")

    else:  # all
        print("="*60)
        print(" INSERT → VERIFY 통합 테스트")
        print("="*60)

        # INSERT
        print("\n[1] 단건 저장")
        inserted, err = insert_logpresso(TABLE,
            {"metric": "test", "value": 100, "tag": "integration"})
        print(f"❌ {err}" if err else f"✅ {inserted}건")

        # 잠시 대기 후 VERIFY
        time.sleep(2)

        print(f"\n[2] 검증 - {TABLE} 최근 5건")
        df, err = verify_recent(TABLE, n=5)
        if err:
            print(f"❌ {err}")
        else:
            print(f"✅ {len(df)}건 조회됨")
            print(df.to_string(max_rows=5))
