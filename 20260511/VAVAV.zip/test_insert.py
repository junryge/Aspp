"""1건만 들어가는지 확인"""
from logpresso_client import insert_logpresso

record = {
    "file": "M16A_HUBROOM_PR.csv",
    "datetime": "2026-05-18 00:00",
    "date": "2026-05-18",
    "time": "00:00",
    "stage": 1,
    "stage_name": "1단계 조기경보",
    "prev_stage": 1,
    "transition": "",
    "reason": "1MIN ≥9분이 8회",
    "relation": "[R-A' Y] QUE.TIME.AVGTOTALTIME1MIN=7.99분 (≥9분 10분창 8회, 지속Y) | [R-B N] QUE.M14TOM16.MESCURRENTQCNT 30분Δ=-7 (≥100), 10분Δ=-14 (≥30 fast) | [R-C' N] 역증가 6개 (≥2): LFT.6ABL6011.TOTAL_CURRENTQCNT, LFT.6ABL6021.TOTAL_CURRENTQCNT, LFT.6ABL6031.TOTAL_CURRENTQCNT, LFT.6ABL6032.TOTAL_CURRENTQCNT, LFT.6ABL0111.TOTAL_CURRENTQCNT, LFT.6ABL0121.TOTAL_CURRENTQCNT; trend=31",
    "hub_storage_util": 72.2,
    "inflow_total": 536,
    "re_trig": 0,
    "rf_trig": 0,
    "rf_fast": 0,
    "risk_score": 80,
    "risk_level": "매우위험",
    "risk_factors": "ra_sustained;ra_count=8;ra=8.0분;rev=6(준위험);rd=24%(준위험)",
}

inserted, err = insert_logpresso("test_table", record)

if err:
    print(f"❌ 실패: {err['reason']}")
    print(f"응답: {str(err.get('response_preview', ''))[:300]}")
else:
    print(f"✅ {inserted}건 들어감")
