# -*- coding: utf-8 -*-
"""
Prediction_ml.py
HUBROOM 예측 통합 실행 마스터

흐름 (매 분 정각 00초):
  1) M16BR_hubroom_data_make.py  → 데이터 수집 (CSV 갱신)
  2) V8_Categorical_Real_time_10min.py
  3) V8_Categorical_Real_time_15min.py
  4) V8_Categorical_Real_time_25min.py
  5) V8_Numerical_Real_time_10min.py
  6) V8_Numerical_Real_time_15min.py
  7) V8_Numerical_Real_time_25min.py

특징:
  - 매 분 정각(00초)에 시작
  - 1개 스크립트 실패해도 다음 스크립트 계속 진행
  - 사이클 통째 예외도 잡고 다음 사이클 진행
  - 콘솔 + logs/Prediction_ml.log 동시 기록 (일자별 로테이션)

위치:  job/Prediction_ml.py
대상:  job/M16A_BR/*.py
"""
import os
import sys
import time
import subprocess
import logging
from logging.handlers import TimedRotatingFileHandler
from datetime import datetime


# ─── 설정 ──────────────────────────────────────
HERE = os.path.dirname(os.path.abspath(__file__))
TARGET_DIR = os.path.join(HERE, "M16A_BR")
LOG_DIR = os.path.join(HERE, "logs")
INTERVAL = 60

SCRIPTS = [
    "M16BR_hubroom_data_make.py --once",
    "V8_Categorical_Real_time_10min.py",
    "V8_Categorical_Real_time_15min.py",
    "V8_Categorical_Real_time_25min.py",
    "V8_Numerical_Real_time_10min.py",
    "V8_Numerical_Real_time_15min.py",
    "V8_Numerical_Real_time_25min.py",
]

SCRIPT_TIMEOUT = 300  # 1개당 최대 5분


# ─── 로거 ──────────────────────────────────────
os.makedirs(LOG_DIR, exist_ok=True)

logger = logging.getLogger("Prediction_ml")
logger.setLevel(logging.INFO)
logger.propagate = False

fmt = logging.Formatter(
    "%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

# 파일: 일자별 로테이션 (Prediction_ml.log → .2026-05-20 백업)
log_path = os.path.join(LOG_DIR, "Prediction_ml.log")
fh = TimedRotatingFileHandler(log_path, when="midnight", backupCount=30, encoding="utf-8")
fh.suffix = "%Y-%m-%d"
fh.setFormatter(fmt)
logger.addHandler(fh)

# 콘솔
ch = logging.StreamHandler(sys.stdout)
ch.setFormatter(fmt)
logger.addHandler(ch)


# ─── 1개 스크립트 실행 ─────────────────────────
def run_script(script_cmd: str) -> bool:
    parts = script_cmd.split()
    script_name = parts[0]
    script_path = os.path.join(TARGET_DIR, script_name)

    if not os.path.exists(script_path):
        logger.error(f"  ❌ 파일 없음: {script_path}")
        return False

    cmd = [sys.executable, script_name] + parts[1:]
    try:
        t0 = time.time()
        result = subprocess.run(
            cmd,
            cwd=TARGET_DIR,
            capture_output=True,
            text=True,
            timeout=SCRIPT_TIMEOUT,
            encoding="utf-8",
        )
        elapsed = time.time() - t0
        ok = result.returncode == 0

        if ok:
            logger.info(f"  ✅ [{script_name}] {elapsed:.1f}초")
        else:
            logger.error(f"  ❌ [{script_name}] {elapsed:.1f}초 (returncode={result.returncode})")

        if result.stdout:
            for line in result.stdout.strip().splitlines():
                if line.strip():
                    logger.info(f"     {line}")

        if not ok and result.stderr:
            for line in result.stderr.strip().splitlines()[:20]:
                logger.error(f"     stderr: {line}")

        return ok

    except subprocess.TimeoutExpired:
        logger.error(f"  ❌ [{script_name}] 타임아웃 ({SCRIPT_TIMEOUT}초)")
        return False
    except Exception as e:
        logger.error(f"  ❌ [{script_name}] {type(e).__name__}: {e}")
        return False


# ─── 1회 사이클 ─────────────────────────────────
def run_cycle():
    """1 사이클 = 7개 스크립트 순차 실행.
    중간 실패해도 다음 스크립트 계속 진행."""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logger.info("=" * 70)
    logger.info(f"  [{ts}] 사이클 시작")
    logger.info("=" * 70)

    success = 0
    fail = 0
    for s in SCRIPTS:
        try:
            if run_script(s):
                success += 1
            else:
                fail += 1
        except Exception as e:
            fail += 1
            logger.exception(f"  ❌ [{s}] 사이클 내 예외: {e}")

    logger.info(f"  → 사이클 결과: 성공 {success} / 실패 {fail}")


# ─── 메인 ──────────────────────────────────────
if __name__ == "__main__":
    once = "--once" in sys.argv

    logger.info("=" * 70)
    logger.info(f"  Prediction_ml 마스터 시작")
    logger.info(f"  실행 폴더: {TARGET_DIR}")
    logger.info(f"  로그 폴더: {LOG_DIR}")
    logger.info(f"  주기:      {INTERVAL}초 (매 분 정각 동기화)")
    logger.info(f"  모드:      {'1회 (--once)' if once else 'Ctrl+C 중단'}")
    logger.info(f"  스크립트:  {len(SCRIPTS)}개")
    logger.info("=" * 70)

    if not os.path.isdir(TARGET_DIR):
        logger.error(f"❌ 대상 폴더 없음: {TARGET_DIR}")
        sys.exit(1)

    if once:
        try:
            run_cycle()
        except Exception as e:
            logger.exception(f"❌ once 사이클 예외: {e}")
        sys.exit(0)

    # 첫 시작 — 다음 정각까지 대기
    now = datetime.now()
    wait_first = 60 - now.second - now.microsecond / 1_000_000
    if wait_first < 1:
        wait_first += 60
    logger.info(f"  → 다음 정각(00초)까지 {wait_first:.1f}초 대기")
    time.sleep(wait_first)

    # 무한 루프 (어떤 예외도 루프 안 끊김)
    while True:
        try:
            t0 = time.time()
            run_cycle()
            elapsed = time.time() - t0

            now = datetime.now()
            sleep_sec = 60 - now.second - now.microsecond / 1_000_000
            if sleep_sec < 0.5:
                sleep_sec += 60

            logger.info(f"  → 사이클 {elapsed:.1f}초 / 다음 정각까지 {sleep_sec:.1f}초 대기\n")
            time.sleep(sleep_sec)

        except KeyboardInterrupt:
            logger.info("중단 (KeyboardInterrupt)")
            break

        except Exception as e:
            # 어떤 예외든 잡고 다음 사이클 계속
            logger.exception(f"❌ 메인 루프 예외 (계속 진행): {e}")
            try:
                now = datetime.now()
                sleep_sec = 60 - now.second - now.microsecond / 1_000_000
                if sleep_sec < 0.5:
                    sleep_sec += 60
                time.sleep(sleep_sec)
            except Exception:
                time.sleep(60)
