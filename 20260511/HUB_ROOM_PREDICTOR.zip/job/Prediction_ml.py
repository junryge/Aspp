# -*- coding: utf-8 -*-
"""
Prediction_ml.py
HUBROOM 예측 통합 실행 마스터

흐름 (1분 주기):
  1) M16BR_hubroom_data_make.py  → 데이터 수집 (CSV 갱신)
  2) V8_Categorical_Real_time_10min.py → 예측 + INSERT
  3) V8_Categorical_Real_time_15min.py
  4) V8_Categorical_Real_time_25min.py
  5) V8_Numerical_Real_time_10min.py
  6) V8_Numerical_Real_time_15min.py
  7) V8_Numerical_Real_time_25min.py

위치:  job/Prediction_ml.py
대상:  job/M16A_BR/*.py
"""
import os
import sys
import time
import subprocess
from datetime import datetime


# ─── 설정 ──────────────────────────────────────
HERE = os.path.dirname(os.path.abspath(__file__))
TARGET_DIR = os.path.join(HERE, "M16A_BR")
INTERVAL = 60  # 1분

# 실행 순서 (데이터 수집 → 예측 6개)
SCRIPTS = [
    "M16BR_hubroom_data_make.py --once",   # CSV 1회 갱신
    "V8_Categorical_Real_time_10min.py",
    "V8_Categorical_Real_time_15min.py",
    "V8_Categorical_Real_time_25min.py",
    "V8_Numerical_Real_time_10min.py",
    "V8_Numerical_Real_time_15min.py",
    "V8_Numerical_Real_time_25min.py",
]


# ─── 1개 스크립트 실행 ─────────────────────────
def run_script(script_cmd: str) -> bool:
    """M16A_BR 폴더에서 python <script>.py 실행"""
    parts = script_cmd.split()
    script_name = parts[0]
    script_path = os.path.join(TARGET_DIR, script_name)

    if not os.path.exists(script_path):
        print(f"  ❌ 파일 없음: {script_path}")
        return False

    # M16A_BR 폴더에서 실행 (config.json, api_key.txt, data/, model_*/ 다 거기)
    cmd = [sys.executable, script_name] + parts[1:]
    try:
        t0 = time.time()
        result = subprocess.run(
            cmd,
            cwd=TARGET_DIR,
            capture_output=True,
            text=True,
            timeout=300,
            encoding="utf-8",
        )
        elapsed = time.time() - t0

        ok = result.returncode == 0
        mark = "✅" if ok else "❌"
        print(f"  {mark} [{script_name}] {elapsed:.1f}초")

        # stdout 출력 (예측 결과 row + 저장 결과)
        if result.stdout:
            for line in result.stdout.strip().splitlines():
                print(f"     {line}")
        if not ok and result.stderr:
            print(f"     stderr: {result.stderr.strip()[:300]}")
        return ok

    except subprocess.TimeoutExpired:
        print(f"  ❌ [{script_name}] 타임아웃 (300초)")
        return False
    except Exception as e:
        print(f"  ❌ [{script_name}] {type(e).__name__}: {e}")
        return False


# ─── 1회 사이클 ─────────────────────────────────
def run_cycle():
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"\n{'='*70}")
    print(f"  [{ts}] 사이클 시작")
    print(f"{'='*70}")

    for s in SCRIPTS:
        run_script(s)


# ─── 메인 ──────────────────────────────────────
if __name__ == "__main__":
    once = "--once" in sys.argv

    print(f"{'='*70}")
    print(f"  Prediction_ml 마스터")
    print(f"  실행 폴더: {TARGET_DIR}")
    print(f"  주기:      {INTERVAL}초 {'(--once 1회만)' if once else '(Ctrl+C 중단)'}")
    print(f"  스크립트:  {len(SCRIPTS)}개")
    print(f"{'='*70}")

    # 대상 폴더 확인
    if not os.path.isdir(TARGET_DIR):
        print(f"\n❌ 대상 폴더 없음: {TARGET_DIR}")
        sys.exit(1)

    if once:
        run_cycle()
    else:
        while True:
            try:
                t0 = time.time()
                run_cycle()
                elapsed = time.time() - t0
                sleep_sec = max(1, INTERVAL - elapsed)
                print(f"\n  → {sleep_sec:.1f}초 대기")
                time.sleep(sleep_sec)
            except KeyboardInterrupt:
                print("\n\n중단")
                break
            except Exception as e:
                print(f"\n예외: {type(e).__name__}: {e}")
                time.sleep(60)
