# 영역별 분할 수집 SQL — 2026-05-26 (하루치)

ORA-01722 (수치 부적합) 우회용으로 269개 컬럼을 8개 영역으로 분할.

## 파일 목록
| 파일 | 영역 | 컬럼 수 | 출력 CSV |
|---|---|---|---|
| COLLECT_M16HUB_20260526.sql | M16HUB | 104 | AWS_IDC_M16HUB_20260526.csv |
| COLLECT_M14_20260526.sql | M14 | 41 | AWS_IDC_M14_20260526.csv |
| COLLECT_M14B_20260526.sql | M14B | 41 | AWS_IDC_M14B_20260526.csv |
| COLLECT_M16A_20260526.sql | M16A | 39 | AWS_IDC_M16A_20260526.csv |
| COLLECT_M16B_20260526.sql | M16B | 25 | AWS_IDC_M16B_20260526.csv |
| COLLECT_M16_20260526.sql | M16 | 11 | AWS_IDC_M16_20260526.csv |
| COLLECT_M16_PKT_20260526.sql | M16_PKT | 4 | AWS_IDC_M16_PKT_20260526.csv |
| COLLECT_M16_WT_20260526.sql | M16_WT | 4 | AWS_IDC_M16_WT_20260526.csv |
| **합계** | | **269** | 8개 CSV |

## 사용법
1. SQL*Plus 접속 후 작은 영역(M16_PKT, M16_WT, M16)부터 실행:
   ```
   SQL> @COLLECT_M16_PKT_20260526.sql
   SQL> @COLLECT_M16_WT_20260526.sql
   SQL> @COLLECT_M16_20260526.sql
   ...
   ```
2. 어느 영역에서 ORA-01722 나오면 그 영역에 비숫자 IDC_VAL 컬럼 있음 → 추가 진단 필요
3. 모두 성공하면 8개 CSV를 `CRT_TM` 기준으로 join 해서 1개로 합치면 됨

## 출력 경로
모든 CSV는 `D:\data\` 에 생성됨. 폴더 없으면 `mkdir D:\data` 먼저.

## 기간
2026-05-26 00:00:00 ~ 2026-05-26 23:59:59 (하루치, 1440분 × 8개 영역)
