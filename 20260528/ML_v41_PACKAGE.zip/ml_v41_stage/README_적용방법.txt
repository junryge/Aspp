ML v4.1 (XGBoost) 학습 + 운영 패키지
====================================

[폴더 구조 그대로 회사 PC 에 복사]
  ml/                            (학습/추론 모듈)
    make_incidents_risk65.py     ★ 신규 (라벨 C)
    feature_builder_v41.py       ★ 신규 (피처 빌더)
    ml_predict_runner_v41.py     ★ 신규 (실시간 추론)
    train_xgboost.py             ★ 수정 (drop_cols 확장)
    make_incidents.py            (기존, 라벨 A)
    ml_predictor.py              (기존, XGBoost 로더)
    evaluate.py                  (기존, 평가)

  Rulebase_prediction/           (운영 연동)
    ML_LO.py                     ★ 신규 (Logpresso 적재 test_table4)
    run_ml.py                    ★ 수정 (ML 활성화)
    config.json                  ★ 수정 (ml_table_name 등 추가)
    ML_출력_컬럼설명.md           ★ 신규 (운영자 매뉴얼)
    Rule_LO.py                   (기존, 룰 적재)
    hubroom_predictor.py         (기존, Phase 1 백테스트용)
    aws_idc_realtime_collector.py (기존)

==========================================
실행 순서 (총 2~3 시간)
==========================================

[Phase 0] 백업 (5분) ★ 필수
  set TS=%date:~0,4%%date:~5,2%%date:~8,2%
  xcopy Rulebase_prediction _BACKUP_pre_ml_v41_%TS%\Rulebase_prediction /E /I /Y
  xcopy ml _BACKUP_pre_ml_v41_%TS%\ml /E /I /Y

[Phase 1] 룰베이스 백테스트 (~20분)
  cd Rulebase_prediction
  REM 합본 1월~5월 단일 CSV 권장
  python hubroom_predictor.py C:\rawdata\2026_01_05_all.csv -o .\predict_tobe
  REM 검증: dir predict_tobe\*_발동이벤트.csv (146 파일 기대)

[Phase 2] 라벨 (~5분)
  cd ..\ml
  python make_incidents.py --dir ..\Rulebase_prediction\predict_tobe --out incidents_A_s3.json
  python make_incidents_risk65.py --dir ..\Rulebase_prediction\predict_tobe --out incidents_C_risk65.json

[Phase 3] 피처 (~10분)
  python feature_builder_v41.py ^
      --raw C:\rawdata\2026_01_05_all.csv ^
      --events_dir ..\Rulebase_prediction\predict_tobe ^
      --out features_v41.csv ^
      --from 2026-03-24 ^
      --to 2026-05-31

[Phase 4] XGBoost 학습 (~45분 × 3 모델)
  python train_xgboost.py --features features_v41.csv --incidents incidents_A_s3.json --out model_v41_15m.json --lead_min 15
  python train_xgboost.py --features features_v41.csv --incidents incidents_A_s3.json --out model_v41_30m.json --lead_min 30
  python train_xgboost.py --features features_v41.csv --incidents incidents_A_s3.json --out model_v41_60m.json --lead_min 60

[Phase 5] 평가 (~15분)
  python evaluate.py --features features_v41.csv --model model_v41_30m.json --incidents incidents_A_s3.json

[Phase 6] 운영 (모델 ml/ 폴더 두고)
  cd ..\Rulebase_prediction
  python run_ml.py
  REM 3 스레드: 수집기 + 룰베이스 + ML (하이브리드 미실행)

==========================================
주의
==========================================
1. Logpresso config.json 의 enabled=false 로 백테스트
   - Phase 1 시작 전에 반드시!
   - Phase 6 시작 시 다시 true
2. 학습 데이터는 2026-03-24 ~ 2026-05-31 (~68일) 만 사용
   - 그 이전은 MAXCAPA/HUB I/O 등 22컬럼 NULL
3. api_key.txt 회사 PC 에 있어야 Logpresso 적재 동작
4. model_v41_*.json + model_v41_*_features.json 둘 다 ml/ 에 있어야 함

==========================================
검증
==========================================
  Phase 1: predict_tobe/*_발동이벤트.csv 146 파일
  Phase 2: incidents_A_s3.json 사건 ≥ 50
  Phase 3: features_v41.csv shape (~210k 행, ~700 컬럼)
  Phase 4: model_v41_30m_report.txt PR-AUC ≥ 0.4 (CV)
  Phase 5: 사전인지 평균 ≥ 25 분
  Phase 6: ml_predict/{오늘}_predictions.csv 매분 추가

==========================================
ML 출력 운영자 가이드
==========================================
  Rulebase_prediction/ML_출력_컬럼설명.md 참조
  - ml_score_30m ≥ 0.85 → CRITICAL (즉시 대응)
  - 룰 stage=3 + ML 강신호 = 확정 위험
  - 룰 stage<3 + ML 강신호 = ML 선행 알람 (사전 대응)
