Rule_LO Logpresso 적재 통합 — 4개 파일
========================================

[파일]
  Rule_LO.py              : 적재기 모듈
  config.json             : 설정 (host/table/file_label)
  api_key.txt.example     : api_key.txt 템플릿
  hubroom_predictor.py    : Rule_LO import 추가된 버전

[적용 순서]
  1. 위 4개 파일을 Rulebase_prediction 폴더에 복사
  2. api_key.txt.example 를 api_key.txt 로 복사 후 실제 API 키 1줄 작성
  3. config.json 확인 (host: 10.40.42.27:8888, table: test_table3)
  4. python3 hubroom_predictor.py [--watch] 실행 → 자동 적재

[동작]
  - hubroom_predictor 가 발동이벤트 1행 만들 때마다
    Rule_LO.upload() 호출 → 비동기 큐 → Logpresso 적재
  - file 컬럼: 무조건 "Rule_system" (config.json 의 file_label)
  - CSV 적재(predict_tobe/) 는 그대로 진행 (Logpresso 적재와 별도)

[안전 장치]
  - api_key.txt 없으면 경고만 출력 (predictor 는 정상 동작)
  - Logpresso 연결 실패해도 CSV 적재는 정상
  - 재시도 3회 + FAIL_SILENT
