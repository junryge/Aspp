"""
demos_v1/report_graphs.py — 리포트 자동 그래프 (재사용 레지스트리)

설계
  - 렌더러 하나당 (detect, render) 한 쌍.  detect(headers)=이 CSV에 이 그래프가 맞나,
    render(rows)=인라인 SVG 문자열.  리포트 종류가 늘면 RENDERERS 에 추가만 하면 된다.
  - build_report_graph(headers, rows) → 본문에 그대로 붙일 마크다운 블록(<div>…SVG…</div>)
    또는 None.  LLM 이 못 그리는 그래프를 백엔드가 만들어 응답 끝에 자동 삽입한다.
  - 기본은 인라인 SVG(의존성 0, 브라우저·다운로드 HTML 에서 렌더).  서버에 headless
    크로미움이 있고 DEMOS_GRAPH_PNG=1 이면 PNG(base64)로 자동 전환(svg_to_png_data_uri).

발동이벤트 24h 그래프(hub_evt_24h)
  ① 종합 위험점수 24h + 등급 배경 + 최고점
  ② 최고점 reason 이 '실제로 발동시킨' 컬럼만 골라 지표별 패널 — 실제 raw 컬럼명 표기
     (raw 컬럼 매핑은 hubroom_predictor_V2.py 원본 그대로)
"""
from __future__ import annotations
import os
import re
from datetime import datetime, timedelta

# ── 실제 raw 컬럼 매핑 (hubroom_predictor_V2.py 원본) ──────────────────────
_RA_RAW = {
    'M16HUB': 'M16HUB.QUE.TIME.AVGTOTALTIME1MIN',
    'M14':    'M14.QUE.LOAD.AVGLOADTIME1MIN',
    'M14B':   'M14B.QUE.TIME.AVGTOTALTIME1MIN',
    'M16A':   'M16A.QUE.LOAD.AVGLOADTIME1MIN',
    'M16B':   'M16B.QUE.LOAD.AVGLOADTIME1MIN',
}
_OHT_RAW = {a: f'{a}.QUE.OHT.OHTUTIL' for a in ('M16HUB', 'M14', 'M14B', 'M16A', 'M16B')}
_SLA_RAW = {a: f'{a}.QUE.ALL.TRANSPORT4MINOVERRATIO' for a in ('M16HUB', 'M14', 'M16A', 'M16B')}
_SORTER_RAW = {a: f'{a}.SORTER.ABN.SORTERWAITCOUNTOVER'
               for a in ('M14', 'M14B', 'M16A', 'M16B', 'M16HUB')}
_FAB_RAW = 'M16HUB.STRATE.ALL.FABSTORAGERATIO'
_STB_RAW = 'M16HUB.STRATE.STB.3F_STORAGE_UTIL'
_REV_RAW = 'M16HUB.QUE.LFT.3F_LFT_REVERSALCNT'

_BANDS = [
    (0, 100, "#f1f5f9"), (100, 120, "#dcfce7"), (120, 130, "#fef9c3"),
    (130, 160, "#ffedd5"), (160, 220, "#fee2e2"), (220, 99999, "#fde2e2"),
]
_SCORE_COLOR = "#2563eb"
_KIND_COLOR = {
    "반송시간": "#dc2626", "FAB저장율": "#ea580c", "STB저장율": "#d97706",
    "OHT가동률": "#7c3aed", "4분초과율": "#0891b2", "소터대기": "#16a34a",
    "리프터막힘": "#be185d",
}
_PALETTE = ["#dc2626", "#ea580c", "#d97706", "#16a34a", "#0891b2",
            "#2563eb", "#7c3aed", "#be185d", "#0d9488", "#b45309"]


def _esc(s):
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _metric_color(label, idx):
    for kind, col in _KIND_COLOR.items():
        if kind in label:
            return col
    return _PALETTE[idx % len(_PALETTE)]


def _parse_dt(s):
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            return datetime.strptime((s or "")[:19], fmt)
        except ValueError:
            pass
    return None


def parse_reason_metrics(reason):
    """peak reason → [{col, raw, label, unit}] (영역별, reason 등장 순서, 중복 제거)."""
    out, seen = [], set()

    def add(col, raw, label, unit):
        if col and col not in seen:
            seen.add(col)
            out.append({"col": col, "raw": raw, "label": label, "unit": unit})

    body = (reason or "").split("발동:", 1)[-1]
    body = re.split(r"흐름:|운영자조치:", body)[0]
    for m in re.finditer(r"(M16HUB|M14B|M16A|M16B|M14)\s*\[(.*?)\]", body):
        area, inner = m.group(1), m.group(2)
        if "AVGTOTALTIME1MIN" in inner or "AVGLOADTIME1MIN" in inner:
            add(f"{area}_ra", _RA_RAW.get(area, f"{area}.QUE.TIME.AVGTOTALTIME1MIN"),
                f"{area} 반송시간", "분")
        if "FAB저장" in inner:
            add("M16HUB_rd_fab", _FAB_RAW, "M16HUB FAB저장율", "%")
        if re.search(r"\bSTB", inner):
            add("M16HUB_stb_util", _STB_RAW, "M16HUB STB저장율", "%")
        if "OHT=" in inner or "OHT가동" in inner:
            add(f"{area}_rd_oht", _OHT_RAW.get(area, f"{area}.QUE.OHT.OHTUTIL"),
                f"{area} OHT가동률", "%")
        if "R-C" in inner:
            add("M16HUB_rev_count", _REV_RAW, "M16HUB 리프터막힘", "회")
        if "SLA(" in inner or "4분초과" in inner:
            add(f"sla_{area}", _SLA_RAW.get(area, f"{area}.QUE.ALL.TRANSPORT4MINOVERRATIO"),
                f"{area} 4분초과율", "%")
        if "SORT(" in inner or "소터" in inner:
            add(f"sorter_{area}", _SORTER_RAW.get(area, f"{area}.SORTER.ABN.SORTERWAITCOUNTOVER"),
                f"{area} 소터대기", "건")
    return out


def _downsample(pts, step_min=2):
    """좌표 수 절감(localStorage·바이트 절약): step_min 간격 + 마지막점 보존."""
    if len(pts) <= 2:
        return pts
    out, last_key = [], None
    for t, v in pts:
        key = int(t.timestamp() // (step_min * 60))
        if key != last_key:
            out.append((t, v))
            last_key = key
    if out[-1] != pts[-1]:
        out.append(pts[-1])
    return out


def render_hub_evt_24h(rows, title=None, width=900):
    """발동이벤트 rows → (점수 패널 + 발동지표 스택 패널) 인라인 SVG."""
    rows = [{(k or "").lstrip("﻿"): v for k, v in r.items()} for r in rows]
    data = []
    for r in rows:
        t = _parse_dt(r.get("datetime") or "")
        if t is None:
            continue
        try:
            sc = float(r.get("unified_risk_score") or 0)
        except (TypeError, ValueError):
            sc = 0.0
        data.append((t, sc, r))
    if len(data) < 2:
        return None
    data.sort(key=lambda x: x[0])
    t0, t1 = data[0][0], data[-1][0]
    span = (t1 - t0).total_seconds() or 1.0

    peak_t, peak_v, peak_r = max(data, key=lambda x: x[1])
    if peak_v <= 0:
        return None
    metrics_def = parse_reason_metrics(peak_r.get("reason") or "")

    series = []
    for md in metrics_def:
        pts = []
        for t, _sc, r in data:
            v = (r.get(md["col"]) or "").strip()
            if not v:
                continue
            try:
                pts.append((t, float(v)))
            except ValueError:
                pass
        if pts and any(v != 0 for _, v in pts):
            series.append({**md, "pts": pts})

    if title is None:
        day = (rows[0].get("date") or (rows[0].get("datetime") or "")[:10])
        title = f"📅 {day} M16 HUBROOM 발동이벤트 24시간 종합"

    L, R = 172, 18
    pw = width - L - R
    TITLE_H = 32
    H_SCORE = 150
    PH, PGAP = 62, 9
    top = TITLE_H + 4
    y = top + H_SCORE + 16
    height = int(y + (len(series) * (PH + PGAP) if series else 0) + 22)

    def X(t):
        return round(L + pw * ((t - t0).total_seconds() / span))

    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" '
           f'font-family="-apple-system,\'Malgun Gothic\',sans-serif" '
           f'style="max-width:100%;height:auto;background:#fff;border:1px solid #e2e8f0;border-radius:10px;">']
    out.append(f'<text x="{L}" y="20" font-size="15" font-weight="800" fill="#16213e">{_esc(title)}</text>')

    def xticks(ptop, h, labels=False):
        hr = t0.replace(minute=0, second=0, microsecond=0)
        k = 0
        while True:
            cur = hr + timedelta(hours=k * 2)
            if cur > t1:
                break
            if cur >= t0:
                x = X(cur)
                out.append(f'<line x1="{x}" y1="{ptop}" x2="{x}" y2="{ptop+h}" stroke="#eef2f7" stroke-width=".7"/>')
                if labels:
                    out.append(f'<text x="{x}" y="{ptop+h+14}" font-size="9" fill="#64748b" text-anchor="middle">{cur.strftime("%H시")}</text>')
            k += 1

    # ① 점수 패널
    ymax = max(220.0, max(s for _, s, _ in data) * 1.08)

    def Y1(v):
        return round(top + H_SCORE * (1 - min(v, ymax) / ymax))

    for lo, hi, color in _BANDS:
        if lo >= ymax:
            continue
        yh, yl = Y1(min(hi, ymax)), Y1(lo)
        out.append(f'<rect x="{L}" y="{yh}" width="{pw}" height="{yl-yh}" fill="{color}"/>')
    for v in (100, 120, 130, 160, 220):
        if v > ymax:
            continue
        yy = Y1(v)
        out.append(f'<line x1="{L}" y1="{yy}" x2="{L+pw}" y2="{yy}" stroke="#e2e8f0" stroke-width=".5" stroke-dasharray="2 3"/>')
        out.append(f'<text x="{L-6}" y="{yy+3}" font-size="9" fill="#94a3b8" text-anchor="end">{v}</text>')
    xticks(top, H_SCORE)
    px = X(peak_t)
    out.append(f'<text x="{L}" y="{top-6}" font-size="11" font-weight="700" fill="#334155">① 종합 위험점수 (24시간)</text>')
    sd = _downsample([(t, s) for t, s, _ in data])
    d = "M" + " L".join(f"{X(t)},{Y1(s)}" for t, s in sd)
    out.append(f'<path d="{d}" fill="none" stroke="{_SCORE_COLOR}" stroke-width="1.7"/>')
    out.append(f'<line x1="{px}" y1="{top}" x2="{px}" y2="{top+H_SCORE}" stroke="#dc2626" stroke-width="1" stroke-dasharray="4 3"/>')
    out.append(f'<circle cx="{px}" cy="{Y1(peak_v)}" r="4" fill="#dc2626"/>')
    la = "end" if px > L + pw * 0.7 else "start"
    lx = px - 7 if la == "end" else px + 7
    out.append(f'<text x="{lx}" y="{Y1(peak_v)-7}" font-size="11" font-weight="800" fill="#dc2626" '
               f'text-anchor="{la}" style="paint-order:stroke;stroke:#fff;stroke-width:3.2px;stroke-linejoin:round">'
               f'▲ 최고 {int(peak_v)}점 · {peak_t.strftime("%H:%M")} · {_esc(peak_r.get("hot_area") or "")}</text>')

    if series:
        out.append(f'<text x="{L}" y="{y-3}" font-size="11" font-weight="700" fill="#334155">'
                   f'② 최고점({peak_t.strftime("%H:%M")}) 발동 지표 — 실제 raw 컬럼 24시간 추이</text>')

    # ② 지표 스택 패널
    for i, s in enumerate(series):
        ptop = round(y + i * (PH + PGAP))
        pc = _metric_color(s["label"], i)
        pts = s["pts"]
        vmax = max(v for _, v in pts)
        vmin = min(v for _, v in pts)
        rng = (vmax - vmin) or 1.0
        last = i == len(series) - 1

        def Yp(v, _ptop=ptop):
            return round(_ptop + (PH - 12) * (1 - (v - vmin) / rng) + 4)

        out.append(f'<rect x="{L}" y="{ptop}" width="{pw}" height="{PH}" fill="#fcfdfe" stroke="#eef2f7"/>')
        out.append(f'<rect x="0" y="{ptop}" width="{L}" height="{PH}" fill="#fff"/>')
        out.append(f'<rect x="{L-4}" y="{ptop}" width="3.5" height="{PH}" fill="{pc}"/>')
        xticks(ptop, PH, labels=last)
        out.append(f'<text x="7" y="{ptop+16}" font-size="10.5" font-weight="700" fill="{pc}">{_esc(s["label"])} ({_esc(s["unit"])})</text>')
        out.append(f'<text x="7" y="{ptop+30}" font-size="7" fill="#64748b" font-family="ui-monospace,Consolas,monospace">{_esc(s["raw"])}</text>')
        out.append(f'<text x="7" y="{ptop+44}" font-size="8.5" fill="#94a3b8">범위 {vmin:g}~{vmax:g}{_esc(s["unit"])}</text>')
        dpts = _downsample(pts)
        dd = "M" + " L".join(f"{X(t)},{Yp(v)}" for t, v in dpts)
        out.append(f'<path d="{dd}" fill="none" stroke="{pc}" stroke-width="1.6"/>')
        area_d = dd + f" L{X(dpts[-1][0])},{ptop+PH-2} L{X(dpts[0][0])},{ptop+PH-2} Z"
        out.append(f'<path d="{area_d}" fill="{pc}" opacity="0.07"/>')
        out.append(f'<line x1="{px}" y1="{ptop}" x2="{px}" y2="{ptop+PH}" stroke="#dc2626" stroke-width="1" stroke-dasharray="4 3"/>')
        pv = next((v for t, v in pts if t == peak_t), None)
        if pv is not None:
            out.append(f'<circle cx="{px}" cy="{Yp(pv)}" r="3" fill="#dc2626"/>')
            pa = "end" if px > L + pw * 0.7 else "start"
            pxx = px - 6 if pa == "end" else px + 6
            out.append(f'<text x="{pxx}" y="{Yp(pv)-5}" font-size="9.5" font-weight="800" fill="#dc2626" '
                       f'text-anchor="{pa}" style="paint-order:stroke;stroke:#fff;stroke-width:3px;stroke-linejoin:round">{pv:g}{_esc(s["unit"])}</text>')

    out.append('</svg>')
    return "".join(out)


# ── 렌더러 레지스트리 ───────────────────────────────────────────────────
def _detect_hub_evt(headers):
    h = set(headers or [])
    return ("unified_risk_score" in h) and ("reason" in h) and ("datetime" in h)


RENDERERS = [
    {"name": "hub_evt_24h", "detect": _detect_hub_evt, "render": render_hub_evt_24h},
]


def svg_to_png_data_uri(svg, width=900):
    """headless 크로미움이 있으면 SVG→PNG(base64 data URI). 없으면 None."""
    import base64
    import shutil
    import subprocess
    import tempfile
    cand = [os.environ.get("DEMOS_GRAPH_CHROMIUM"),
            "/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell",
            shutil.which("chromium"), shutil.which("chromium-browser"),
            shutil.which("google-chrome"), shutil.which("headless_shell")]
    binp = next((c for c in cand if c and os.path.exists(c)), None)
    if not binp:
        return None
    m = re.search(r'viewBox="0 0 (\d+) (\d+)"', svg)
    w, h = (int(m.group(1)), int(m.group(2))) if m else (width, 1000)
    try:
        with tempfile.TemporaryDirectory() as td:
            hp = os.path.join(td, "g.html")
            pp = os.path.join(td, "g.png")
            with open(hp, "w", encoding="utf-8") as f:
                f.write(f'<!doctype html><meta charset="utf-8"><body style="margin:0;background:#fff">{svg}</body>')
            subprocess.run([binp, "--headless", "--no-sandbox", "--disable-gpu",
                            "--force-device-scale-factor=2", "--hide-scrollbars",
                            f"--window-size={w},{h}", f"--screenshot={pp}", f"file://{hp}"],
                           capture_output=True, timeout=30)
            if os.path.exists(pp):
                b = base64.b64encode(open(pp, "rb").read()).decode("ascii")
                return f"data:image/png;base64,{b}"
    except Exception:
        return None
    return None


def build_report_graph(headers, rows, prefer_png=None):
    """헤더로 렌더러 자동 감지 → 본문에 붙일 마크다운 블록(<div>…</div>) 또는 None."""
    if not headers or not rows:
        return None
    renderer = next((r for r in RENDERERS if r["detect"](headers)), None)
    if not renderer:
        return None
    try:
        svg = renderer["render"](rows)
    except Exception:
        return None
    if not svg:
        return None
    if prefer_png is None:
        prefer_png = os.environ.get("DEMOS_GRAPH_PNG", "") in ("1", "true", "yes")
    inner = svg
    if prefer_png:
        uri = svg_to_png_data_uri(svg)
        if uri:
            inner = f'<img src="{uri}" alt="리포트 그래프" style="max-width:100%;border-radius:10px;"/>'
    # 블록 레벨 <div> 로 감싸 python-markdown/marked 통과 보장
    return f'\n\n<div class="hub-report-graph" style="margin:14px 0;">{inner}</div>\n\n'
