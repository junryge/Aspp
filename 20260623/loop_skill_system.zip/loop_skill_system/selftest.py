#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
selftest.py — LLM 없이 엔진 전체가 정상인지 확인 (mock 사용, 외부 연결 0)

실행:
    python selftest.py

오픈소스 LLM 을 아직 안 띄웠어도, 이 스크립트로 엔진/루프/검증/도구/스킬생성이
정상 동작하는지 즉시 확인할 수 있다. (네트워크 호출 없음)
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import loop_engine.llm as L
from loop_engine import (LoopSystem, LoopConfig, LLMConfig, Generator, VerifierAgent,
    CheckSuite, LoopSpec, LoopMode, Loop, Rubric, Skill,
    check_contains, check_min_length, check_no_placeholder)

GOOD_SKILL = """---
name: lifter_hid_capacity
description: M16A_BR OHT 리프터 HID 포화도와 병목 원인을 분석하는 스킬
---
## 절차
1. LOGPRESSO_HID_INOUT 로그를 1분 단위로 집계한다.
2. 포화도 상위 리프터를 병목 후보로 뽑고 수치 근거를 붙인다.
3. [요약]/[병목]/[원인] 3단으로 보고한다.
"""

def main():
    st = {"n": 0}
    def mock(url, h, payload, to, v):
        sysc = payload["messages"][0]["content"]
        if "평가자" in sysc:                                   # 검사 AI(루브릭)
            score = 9 if "name:" in payload["messages"][-1]["content"] else 3
            return {"choices": [{"message": {"content": '{"score":%d,"reasons":"x"}' % score}}]}
        st["n"] += 1                                            # 짓는 AI
        return {"choices": [{"message": {"content": GOOD_SKILL if st["n"] >= 2 else "초안 TODO"}}]}

    L._urllib_transport = mock   # ★ 네트워크 대신 mock 주입

    sysm = LoopSystem(LoopConfig(llm=LLMConfig(
        endpoint="LOCAL", generator_model="qwen-mock", verifier_model="glm-mock")))
    checks = CheckSuite([
        check_contains("---"), check_contains("name:"), check_contains("description:"),
        check_min_length(80), check_no_placeholder(),
    ])
    verifier = VerifierAgent(sysm.client, check_suite=checks,
        rubric=Rubric("스킬 실무성 엄격 채점", pass_score=8.0),
        generator_model="qwen-mock", verifier_model="glm-mock")
    spec = LoopSpec(name="skill_maker", goal="리프터 HID 분석 SKILL.md 작성",
        generator=Generator(sysm.client), verifier=verifier,
        mode=LoopMode.CLOSED, max_rounds=5)

    print("=== 루프 엔지니어링 → 스킬 생성 셀프테스트 (LLM 없이 mock) ===")
    r = Loop(spec).run()
    for rd in r.rounds:
        fails = [c.name for c in rd.verdict.critical_failures]
        print(f"  라운드 {rd.index}: done={rd.verdict.done} 실패={fails or '없음'} 점수={rd.verdict.rubric.score}")
    print(f"  최종: {r.status.value} ({r.n_rounds}라운드)")

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "MADE_SKILL.md")
    open(out, "w", encoding="utf-8").write(r.final_artifact)
    sk = Skill.from_file(out)
    assert r.status.value == "shipped" and sk.name == "lifter_hid_capacity"
    print(f"  생성 스킬 로드 OK: name={sk.name}")
    print("\n[PASS] 엔진/루프/검증/스킬생성 정상. 이제 connect_test.py 로 실제 LLM 연결을 확인하라.")

if __name__ == "__main__":
    main()
