#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
connect_test.py — 당신의 오픈소스 LLM(OpenAI 호환)에 실제로 붙는지 확인

사용:
    python connect_test.py http://127.0.0.1:8000/v1 <model_name> [token]

예:
    python connect_test.py http://127.0.0.1:8000/v1 qwen2.5-7b-instruct
    python connect_test.py http://127.0.0.1:11434/v1 llama3.1            # Ollama
    python connect_test.py http://127.0.0.1:8000/v1 my-model sk-abc123   # 토큰 필요시

성공하면 'CONNECT OK' 와 모델 응답이 출력된다.
이게 되면 loop_skill_builder.html 에서 같은 base_url/model 을 넣고 러너를 생성하면 된다.
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from loop_engine import LLMClient, LLMConfig, LLMError

def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    base_url = sys.argv[1]
    model = sys.argv[2]
    token = sys.argv[3] if len(sys.argv) > 3 else None

    print(f"→ base_url = {base_url}")
    print(f"→ model    = {model}")
    print(f"→ token    = {'(설정됨)' if token else '(없음 — TOKEN.TXT/LLM_TOKEN 사용)'}")
    client = LLMClient(LLMConfig(base_url=base_url, token=token,
                                 generator_model=model, verify_ssl=False))
    try:
        resp = client.chat([
            {"role": "system", "content": "한 문장으로만 답한다."},
            {"role": "user", "content": "연결 테스트. '연결 성공'이라고만 답하라."},
        ], max_tokens=64)
        print("\n[CONNECT OK] 모델 응답:")
        print("  ", resp.text)
        if resp.usage:
            print("   usage:", resp.usage)
    except LLMError as e:
        print("\n[CONNECT FAIL]", e)
        print("점검: 1) 서버가 떠 있나  2) base_url 에 /v1 포함했나  "
              "3) 모델명 정확한가  4) 토큰 필요한 서버인가")
        sys.exit(2)

if __name__ == "__main__":
    main()
