# drawio-skill → DEMOS 연동 가이드 (폐쇄망)

출처: https://github.com/Agents365-ai/drawio-skill (MIT, v1.14.0)
용도: `.drawio` XML 생성 + PNG/SVG/PDF export. 아키텍처/ERD/UML/시퀀스/ML도/플로우차트.

---

## 1. 설치 — 폴더 통째로 던지면 끝

DEMOS skills 디렉토리에 `drawio-skill/` 폴더 그대로 복사.
SKILL.md frontmatter 형식 동일(name/description/metadata)이라 별도 등록 코드 없이 스캔된다.

```
DEMOS/skills/drawio-skill/        ← 여기 통째로
├── SKILL.md                      ← 진입점 (486줄, 워크플로우)
├── references/  (6개 .md)         ← on-demand 로드 (앞에 안 깔림)
├── scripts/     (11개 .py)        ← 전부 순수 stdlib
├── data/        (shape-index.json.gz 426K = 1만+ 도형 오프라인 인덱스)
└── styles/      (built-in 프리셋 3종)
```

frontmatter에 `metadata.hermes.tags` 이미 박혀있다(`drawio/diagram/flowchart/...`).
Hermes Agent 연동이면 그대로 카테고리(`design`) 잡힌다.

---

## 2. 폐쇄망 호환표 — 중요

| 기능 | 폐쇄망 | 의존성 | 비고 |
|---|---|---|---|
| `.drawio` XML 생성 | ✅ 완전동작 | 없음 | 코어. pip 0개 |
| `shapesearch.py` (1만+ 도형) | ✅ 완전동작 | 없음 | 로컬 gz 인덱스 |
| `validate.py` (구조 린트) | ✅ 완전동작 | 없음 | dangling edge/중복 id/overlap 검출 |
| `repair_png.py` | ✅ 완전동작 | 없음 | -e PNG IEND 복구 |
| `autolayout.py` + importers | ⚠️ 조건부 | Graphviz `dot`/`tred` | 오프라인 설치 가능 (아래) |
| PNG/SVG/PDF export | ⚠️ 조건부 | draw.io desktop CLI | 오프라인 설치 가능 (아래) |
| `aiicons.py` (AI 브랜드 로고) | ❌ 안됨 | unpkg/simpleicons CDN | 렌더타임 인터넷 필요 → 빈 박스 |
| `encode_drawio_url.py` (브라우저 폴백) | ❌ 의미없음 | diagrams.net 접속 | 폐쇄망 미접속. desktop에서 .drawio 직접 열어라 |

**결론**: export 바이너리 없어도 코어(XML 생성+검증+도형검색)는 pip 0개로 100% 돈다.
생성된 `.drawio`를 사내 draw.io desktop으로 열면 그만.

---

## 3. 시스템 바이너리 오프라인 설치 (export 필요할 때만)

### draw.io desktop CLI — PNG/SVG/PDF용
GitHub releases에서 오프라인 패키지 받아 반입:
- Linux: `.deb`/`.rpm` (https://github.com/jgraph/drawio-desktop/releases) — **snap 쓰지 마라**(AppArmor가 keyring 막아서 서버에서 크래시)
- Windows: installer `.exe`
- 서버(헤드리스): `xvfb-run -a drawio -x -f png ... --disable-gpu`, root면 맨 끝에 `--no-sandbox`

확인: `drawio --version` (바이너리명이 `draw.io` 점 버전인 경우도 있음 — SKILL.md Step 1이 자동판별)

### Graphviz — autolayout/importers용 (선택)
노드 15개 넘는 큰 그림 자동배치할 때만. 없으면 hand-place로 degrade.
- `apt download graphviz` 로 .deb 미리 받아 반입 → `dpkg -i`

---

## 4. aiicons CDN 한계 대응

`aiicons.py`는 로고를 CDN URL로 참조 → 폐쇄망 렌더 시 빈 박스.
`--embed`도 SVG를 그때 fetch하므로 폐쇄망 생성단계에서도 실패.

대응 3가지:
1. **그냥 안 씀** — AI 로고 대신 일반 라벨 박스. 가장 깔끔.
2. **사전 캐싱** — 인터넷 되는 머신에서 `aiicons.py "openai" --embed` 등으로 data URI 뽑아 미리 박아두고 반입.
3. 필요하면 말해라 — lobe-icons를 GitHub raw에서 긁어 **오프라인 아이콘팩**으로 만들어 줄 수 있다(DEMOS/Hermes 모델카드용 로고셋).

---

## 5. DEMOS 안에서 호출 흐름

SKILL.md 워크플로우가 경로를 `<this-skill-dir>/scripts/...` 상대참조로 쓴다.
DEMOS 스킬 로더가 스킬 루트를 잡아주면 그대로 동작. 핵심 7단계:

```
Step0 프리셋 해석 → 1 deps 확인 → 2 plan → 3 .drawio 생성(+validate.py)
→ 4 미리보기 PNG(-e 빼고, --width 2000) → 5 비전 self-check → 6 리뷰루프
→ 7 최종 export(-e 붙이고 repair_png.py)
```

폐쇄망 + export 바이너리 없는 경우: Step 4~7 스킵, Step 3에서 `.drawio` + `validate.py`까지만.

---

## 6. 빠른 검증 (반입 후 1줄씩)

```bash
cd DEMOS/skills/drawio-skill
python3 scripts/shapesearch.py "kubernetes pod"     # 오프라인 도형검색 OK?
python3 scripts/validate.py your.drawio             # "0 error(s)" 떠야 정상
drawio --version                                    # export 쓸거면
```

동봉 `amhs_oht_flow.drawio` 가 검증 통과 샘플(AMHS OHT 반송 흐름, 한글 라벨).
`validate.py`로 돌려보면 `0 error(s), 0 warning(s)`.
