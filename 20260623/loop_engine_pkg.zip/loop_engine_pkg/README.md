# loop_engine — 폐쇄망용 루프 엔지니어링 프레임워크

> "AI한테 매번 시키지 말고, AI를 시키는 시스템을 짜라."
> 프롬프트를 짜던 자리에서 빠져나와, 루프(트랙)를 설계한다.

**외부 의존성 0개 (Python stdlib only).** Docker / Git / Node 불필요. pip 설치도 필요 없음.
base64 파일 한 덩어리로 폐쇄망에 옮겨 바로 `import` 하면 끝.

---

## 루프 엔지니어링 6부품 → 코드 매핑

| 부품 | 설명 | 이 프레임워크의 구현 |
|---|---|---|
| ① 오토메이션 | 정해진 주기에 '시작' 버튼을 알아서 누름 | `triggers.Scheduler` / `CronTrigger` / `IntervalTrigger` / `ManualTrigger` |
| ② 워크트리 | 실행마다 독립 작업공간 (충돌 방지) | `state.RunContext` — `runs/<id>/` 디렉토리 격리 (git worktree 불필요) |
| ③ 스킬 | 매번 처음부터 설명 안 하게 박아둔 인수인계 노트 | `skills.SkillRegistry` / `Skill` (SKILL.md + 프론트매터 파싱) |
| ④ 커넥터 | LLM·외부도구에 손발 달기 | `llm.LLMClient` (OpenAI 호환) + `tools.Tool`/`ToolRegistry`/`ToolAgent` (도구 사용 루프, 모델 무관 텍스트 프로토콜) |
| ⑤ 서브에이전트 | '짓는 AI' vs '검사하는 AI' 분리 | `agents.Generator` / `VerifierAgent` (+ self-bias 자동 감지) / 선택적 `LoopSpec.planner` |
| ⑥ 상태/기억 | "에이전트는 잊어도 저장소는 안 잊는다" | `state.ArtifactStore` / `Signal` / `WorkLog` / `Contract` |

핵심 명제: **verifier 가 병목이다.** generator(모델)는 충분히 좋고 거의 공짜로 반복된다.
그 결과가 가치 있는지 판정하는 verifier 가 루프의 전부다. verifier = reward function.

---

## 폐쇄망 적합도 (SK Hynix 내부 환경 기준)

| 부품 | 폐쇄망 판정 | 비고 |
|---|---|---|
| ① 오토메이션 | ✅ | 내장 threading 스케줄러. 외부 cron 불필요 |
| ② 워크트리 | ✅ | `runs/<id>/` 폴더 격리로 대체 (Git 없어도 됨) |
| ③ 스킬 | ✅ | SKILL.md 패턴 그대로 |
| ④ 커넥터 | ✅ | 내부 LLM(dev.hcp/common) OpenAI 호환 연결 + 도구는 파이썬 콜러블(Logpresso/내부API/파일). native 미지원 모델도 텍스트 프로토콜로 도구 사용 |
| ⑤ 서브에이전트 | ✅ | generator/verifier 다른 모델 + self-bias 경고 |
| ⑥ 상태/기억 | ✅ | 마크다운/JSON 파일. 제로 디펜던시 |

---

## 빠른 시작

### 오프라인 시연 (엔드포인트 없이 목 LLM)
```bash
python -m loop_engine.cli demo
python examples/skillharness_loop.py --mock
```

### 실제 내부 LLM 에 붙이기
1. `TOKEN.TXT` 를 실행 CWD 에 둔다 (없으면 환경변수 `LLM_TOKEN`).
2. `loop_engine/config.py` 의 `DEFAULT_ENDPOINTS` 를 사내 URL 로 확인/수정.
3. 코드에서:

```python
from loop_engine import (LoopSystem, LoopConfig, LLMConfig,
                         Generator, VerifierAgent, CheckSuite, Rubric,
                         LoopSpec, LoopMode, Loop,
                         check_min_length, check_contains, check_no_placeholder)

cfg = LoopConfig(llm=LLMConfig(
    endpoint="DEV",                 # dev.hcp.llm.skhynix.com
    generator_model="qwen3.5-397b",
    verifier_model="glm-5",         # ★ 다른 모델 = self-bias 회피
    verify_ssl=False,
))
system = LoopSystem(cfg)
client = system.client

gen = Generator(client)
verifier = VerifierAgent(
    client,
    check_suite=CheckSuite([            # closed loop '바닥'(하드 패스)
        check_min_length(300),
        check_contains("AMHS"),
        check_no_placeholder(),
    ]),
    rubric=Rubric("정확성/명료성/실무성 엄격 채점", pass_score=8.0),  # 품질 바
    generator_model=cfg.llm.generator_model,
    verifier_model=cfg.llm.verifier_model,
)
spec = LoopSpec(name="amhs", goal="...(측정 가능하게)...",
                generator=gen, verifier=verifier,
                mode=LoopMode.CLOSED, max_rounds=4)

result = Loop(spec).run()
print(result.report())
print(result.final_artifact)
```

---

## Open vs Closed 루프

- **Closed** : 성공기준을 미리 못박고 매 스텝 평가 + 명시적 stop. 예측 가능/안전.
- **Open** : 목표 + 느슨한 조건 → 넓게 탐색. 참신하지만 토큰 태우고 슬롭 위험.
- **실전 트릭** : closed 하드체크를 '바닥'으로 깔고 그 위에 `open_instruction` 하나 얹기
  → 기준 밑으로는 안 떨어지는 탐색.

```python
spec = LoopSpec(..., mode=LoopMode.OPEN,
                open_instruction="제목은 알아서 더 도발적으로 바꿔봐라")
```

---

## 멀티 루프 = 공유 두뇌(복리)

여러 루프가 같은 `artifacts/signals/` 를 읽고 쓰면 서로의 발견을 이어받아 복리로 쌓인다.

```python
system.register(spec_a); system.register(spec_b)
system.schedule_cron("loop_a", "0 9 * * 1-5")   # 평일 9시
system.schedule_every("loop_b", 1800)           # 30분마다
system.start()                                   # 백그라운드 스케줄러

# 한 루프가 발견을 시그널로 → 다른 루프가 픽업
system.emit_signal("이 키워드 전환되는데 콘텐츠 없음", kind="opportunity")
```

---

## stop 조건 (무한루프 방지)

`(모든 critical 체크 통과 AND 루브릭 통과)` **OR** `max_rounds 도달`.
미달이어도 `keep_best_by_rubric=True` 면 최고점 라운드를 보존한다.

---

## 냉정한 현실 (Addy Osmani)

1. **검증은 여전히 사람 몫.** 루프는 사람이 안 볼 때 실수한다.
2. **이해도는 노력 안 하면 떨어진다.** 산출물을 읽는 건 선택이 아니다.
3. **가장 큰 위험은 인지적 항복.** 같은 루프도 쓰는 사람에 따라 정반대 결과.

이 프레임워크가 `self_bias_warning` 을 강제로 다는 이유: 자기채점은 부풀려진다(실측 9.04 vs 7.43).
verifier 를 generator 와 분리하지 않으면, 후한 점수만 믿고 부족한 결과를 출시하게 된다.

---

## 도구 쓰는 루프 (에이전트가 '실제 일'을 함)

LLM 이 글만 쓰는 게 아니라 내부 API 호출/Logpresso 쿼리/파일 작업을 하게 한다.
native function-calling 미지원 모델(내부 gpt-oss/GLM 등)도 **텍스트 JSON 프로토콜**로 동작.

```python
from loop_engine import ToolRegistry, ToolUsingGenerator

tools = ToolRegistry()

@tools.tool("query_logpresso", "Logpresso 쿼리 실행", {"lpql": "쿼리문"})
def query_logpresso(args):
    # 실제 내부 호출로 교체
    return run_internal_lpql(args["lpql"])

# generator 자리에 끼우면 도구 쓰는 루프가 된다 (Loop/LoopSpec 그대로)
gen = ToolUsingGenerator(client, tools, model="gpt-oss-20b",
                         max_steps=6, native=False)  # native=True 면 서버 tools= 사용
```

## discover 단계 — 스킬/시그널/워크로그/triage 자동 주입

```python
spec = LoopSpec(..., context_provider=system.discover_context(
    skill_names=["logpresso_query"],     # 스킬 자동 주입
    include_open_signals=True,           # 공유 두뇌 시그널
    worklog_tail=8,                      # 세션 간 기억
    triage_provider=lambda: my_triage_items,   # 할 일 우선순위
).as_provider())
```

## plan 단계 분리 (선택)

generator 가 plan+execute 를 동시에 하지만, 명시적 Planner 를 끼울 수 있다(article 의 Planner→Writer 체인).

```python
planner = Agent("planner", "너는 계획가다", client, model="glm-5")
spec = LoopSpec(..., planner=planner, plan_once=True)   # plan_once=False 면 매 라운드 재계획
```

---

## 모듈 구조

```
loop_engine/
  config.py        # 설정/토큰(TOKEN.TXT 우선)/엔드포인트 레지스트리
  llm.py           # ④ 커넥터: OpenAI 호환 클라이언트(urllib, 목 transport)
  tools.py         # ④ 보강: Tool/ToolRegistry/ToolAgent(도구 사용 루프)/ToolUsingGenerator
  state.py         # ② RunContext + ⑥ Artifact/Signal/WorkLog/Contract
  skills.py        # ③ SKILL.md 로더/레지스트리
  discover.py      # discover 배선: 스킬+시그널+워크로그+triage -> context
  verifier.py      # 병목: Check(하드) + Rubric(LLM) + Verdict
  agents.py        # ⑤ Generator / VerifierAgent (self-bias 감지)
  loop.py          # 코어: discover→plan(선택)→execute→verify→반복
  triggers.py      # ① cron 파서 + Scheduler(threading) + triage
  orchestrator.py  # LoopSystem: 전부 연결 + 공유 두뇌 + 도구/스킬 헬퍼
  cli.py           # 명령행 진입점
examples/
  simple_loop.py        # 최소 closed loop
  skillharness_loop.py  # DEMOS SkillHarness 재구성(전체)
  tool_loop.py          # 도구 쓰는 루프 + 스킬 주입
```
