"""
examples/tool_loop.py — 도구 쓰는 루프 (외부 커넥터 보강분 시연)

LLM 이 글만 쓰는 게 아니라 '실제 일'을 하는 루프.
폐쇄망 도구 예시:
  - query_idc   : 내부 데이터 조회(여기선 목 테이블; 실제론 Logpresso/DB 호출로 교체)
  - save_report : 산출물 파일로 저장

ToolUsingGenerator 를 Loop 의 generator 자리에 끼우면, 루프가 도구를 쓰며 돈다.
DiscoverContext 로 스킬도 자동 주입한다.

실행:
    python examples/tool_loop.py --mock     # 오프라인
    python examples/tool_loop.py            # 실제 내부 LLM (native 미지원 모델도 텍스트 프로토콜로 동작)
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from loop_engine import (LoopSystem, LoopConfig, LLMConfig, LLMClient,
                         Tool, ToolRegistry, ToolUsingGenerator,
                         VerifierAgent, CheckSuite, Rubric, Skill,
                         LoopSpec, LoopMode, Loop, RunContext, new_run_id,
                         check_min_length, check_contains,
                         make_mock_transport)


# --- 내부 도구 (실제론 Logpresso/Oracle/내부 API 로 교체) ---
IDC_TABLE = {"M16A_3F": 23, "M14": 31, "M14B": 18, "M16HUB": 12}


def build_tools(workspace: Path) -> ToolRegistry:
    reg = ToolRegistry()

    @reg.tool("query_idc", "FAB 구역의 IDC 개수를 조회한다", {"zone": "구역명(예: M16A_3F)"})
    def query_idc(args):
        z = args.get("zone", "")
        return f"{z} 의 IDC = {IDC_TABLE.get(z, '알수없음')}"

    @reg.tool("save_report", "보고서를 파일로 저장한다",
              {"filename": "파일명", "content": "본문"})
    def save_report(args):
        out = workspace / "reports"
        out.mkdir(parents=True, exist_ok=True)
        p = out / args.get("filename", "report.txt")
        p.write_text(args.get("content", ""), encoding="utf-8")
        return f"저장됨: {p}"

    return reg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mock", action="store_true")
    ap.add_argument("--zone", default="M16A_3F")
    args = ap.parse_args()

    ws = Path("loop_workspace_tool")

    if args.mock:
        # 목: query_idc 호출 -> save_report 호출 -> final
        st = {"n": 0}

        def resp(msgs, model):
            sysmsg = msgs[0]["content"]
            if "평가자" in sysmsg:
                return '{"score": 8.5, "reasons": "도구로 사실 확인됨"}'
            st["n"] += 1
            if st["n"] == 1:
                return ('{"thought":"IDC 조회","tool":"query_idc",'
                        '"args":{"zone":"M16A_3F"}}')
            if st["n"] == 2:
                return ('{"thought":"보고서 저장","tool":"save_report",'
                        '"args":{"filename":"idc_report.md",'
                        '"content":"# IDC 보고서\\nM16A_3F IDC=23. AMHS 혼잡 모니터링 대상."}}')
            return ('{"thought":"완료","final":"# IDC 보고서\\n'
                    'M16A_3F 구역 IDC=23 (도구로 확인). AMHS OHT 혼잡 모니터링 대상."}')

        client = LLMClient(LLMConfig(endpoint="LOCAL"),
                           transport=make_mock_transport(resp))
        gen_model, ver_model = "qwen-mock", "glm-mock"
    else:
        client = LLMClient(LLMConfig(endpoint="LOCAL",
                                     generator_model="gpt-oss-20b",
                                     verifier_model="glm-5"))
        gen_model, ver_model = "gpt-oss-20b", "glm-5"

    system = LoopSystem(LoopConfig(base_dir=ws), client=client)

    # 스킬 등록(자동 주입용)
    system.skills.add(Skill.from_text("idc_reporting",
        "---\ndescription: IDC 보고는 query_idc 로 사실 확인 후 save_report 로 저장\n---\n"
        "# IDC 보고 절차\n1) query_idc 로 수치 확인 2) save_report 로 저장 3) 요약 반환"))

    # 도구 등록
    system.tools = build_tools(ws)

    # 도구 쓰는 generator
    gen = ToolUsingGenerator(client, system.tools, model=gen_model,
                             max_steps=6, native=False)  # native=True 면 서버 tools= 사용

    # 검사자 (다른 모델)
    verifier = VerifierAgent(
        client,
        check_suite=CheckSuite([check_min_length(20), check_contains("IDC")]),
        rubric=Rubric("도구로 사실 확인했는가 / 보고가 명료한가", pass_score=8.0),
        generator_model=gen_model, verifier_model=ver_model,
    )

    spec = LoopSpec(
        name="idc_report",
        goal=f"'{args.zone}' 구역의 IDC 현황 보고서를 작성하라. "
             f"반드시 query_idc 도구로 수치를 확인하고 save_report 로 저장한 뒤 요약하라.",
        generator=gen,
        verifier=verifier,
        mode=LoopMode.CLOSED,
        max_rounds=3,
        context_provider=system.discover_context(skill_names=["idc_reporting"]).as_provider(),
    )

    run = RunContext(system.cfg.runs_dir, run_id=new_run_id("idc_report"))
    result = Loop(spec, worklog=system.worklog,
                  on_round=lambda r: print(
                      f"  [{r.index}] done={r.verdict.done} "
                      f"score={r.verdict.rubric.score if r.verdict.rubric else '-'}")
                  ).run(run)

    print("\n" + result.report())
    print("\n=== 최종 보고서 ===\n" + result.final_artifact)
    reports = list((ws / "reports").glob("*")) if (ws / "reports").exists() else []
    print("\n도구가 저장한 파일:", [str(p) for p in reports])


if __name__ == "__main__":
    main()
