"""
examples/skillharness_loop.py — DEMOS SkillHarness 를 루프 엔지니어링으로 재구성

형의 SkillHarness(Draft -> Test -> Evaluate -> Improve)를 6부품으로 구현한 완성 예제.
핵심: Evaluate 를 generator 와 '다른 모델'로 분리 + self-bias 경고 강제.
산출물은 수정금지 체인으로 디스크에 박는다:
    spec.json -> draft.md -> qa_report.json -> final.md

추가로:
  - LoopSystem 으로 작업공간/스킬/시그널/워크로그/스케줄러 전부 연결
  - cron 으로 자동 트리거(주석 처리; 수동 1회도 가능)
  - 결과 미달 시 개선 시그널을 공유 두뇌에 emit

실행:
    python examples/skillharness_loop.py            # 1회 실행
    python examples/skillharness_loop.py --serve    # 스케줄러 상주(데모는 10초 간격)
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from loop_engine import (LoopSystem, LoopConfig, LLMConfig, LLMClient,
                         Generator, VerifierAgent, CheckSuite, Rubric,
                         LoopSpec, LoopMode, Contract, RunContext,
                         check_min_length, check_contains, check_no_placeholder,
                         make_mock_transport)


# ---------------------------------------------------------------------------
# 스킬 생성용 generator 의 역할 프롬프트
# ---------------------------------------------------------------------------
SKILL_AUTHOR_SYSTEM = (
    "너는 SKILL.md 작성 전문가다. 주어진 주제로 재사용 가능한 '인수인계 노트'를 쓴다. "
    "형식: 첫 줄 '# <스킬명>', 이어서 '## 목적', '## 사용 시점', '## 절차(단계)', "
    "'## 예시', '## 주의'. 추측으로 빈칸을 메우지 말고 구체적으로. "
    "미완성 표현(TODO, 생략, ...전체) 금지. SKILL.md 본문만 출력."
)


def build_skillharness_loop(system: LoopSystem, topic: str,
                            gen_model: str, ver_model: str) -> LoopSpec:
    client = system.client

    # 짓는 AI (Draft / Improve 담당)
    gen = Generator(client, name="skill_author",
                    role_system=SKILL_AUTHOR_SYSTEM, model=gen_model)

    # 검사하는 AI (Test = 하드체크 + Evaluate = 루브릭). 반드시 다른 모델.
    suite = CheckSuite([
        check_min_length(400),
        check_contains("## 절차"),
        check_contains("## 예시"),
        check_no_placeholder(),
    ])
    rubric = Rubric(
        criteria=("① 절차가 그대로 따라할 만큼 구체적인가 "
                  "② 사용 시점이 명확한가 ③ 예시가 실제로 동작 가능한가. 엄격 채점."),
        pass_score=8.0,
    )
    verifier = VerifierAgent(client, check_suite=suite, rubric=rubric,
                             verifier_model=ver_model, generator_model=gen_model)

    spec = LoopSpec(
        name="skillharness",
        goal=f"주제 '{topic}' 에 대한 SKILL.md 를 작성하라. "
             f"절차/예시 섹션 필수, 400자 이상, 미완성 표현 금지.",
        generator=gen,
        verifier=verifier,
        mode=LoopMode.CLOSED,
        max_rounds=4,
    )
    return spec


def run_once(system: LoopSystem, topic: str, gen_model: str, ver_model: str):
    spec = build_skillharness_loop(system, topic, gen_model, ver_model)

    # 계약서 등록 (매 실행 전 읽힘)
    contract = Contract(
        loop_name="skillharness",
        goal=spec.goal,
        workflow="Draft(gen) -> Test(checks) -> Evaluate(rubric, 다른모델) -> Improve(gen) 반복",
        boundaries="평가자는 generator 와 다른 모델. self-bias 경고시 사람이 최종 확인.",
        backlog=[f"topic: {topic}"],
    )
    system.register(spec, contract=contract)

    # 산출물 체인을 격리 run 디렉토리에 박기 위해 직접 RunContext 사용
    from loop_engine import Loop, new_run_id
    run = RunContext(system.cfg.runs_dir, run_id=new_run_id("skillharness"))
    run.write_json("spec.json", {"topic": topic, "goal": spec.goal,
                                 "gen_model": gen_model, "ver_model": ver_model})

    result = Loop(spec, worklog=system.worklog,
                  on_round=lambda r: print(
                      f"  [{r.index}] done={r.verdict.done} "
                      f"score={r.verdict.rubric.score if r.verdict.rubric else '-'} "
                      f"{'⚠self-bias' if r.verdict.self_bias_warning else ''}")
                  ).run(run)

    # 수정금지 체인 마무리
    run.write_text("draft.md", result.final_artifact)
    last = result.rounds[-1].verdict if result.rounds else None
    run.write_json("qa_report.json", {
        "status": result.status.value,
        "rounds": result.n_rounds,
        "final_score": (last.rubric.score if last and last.rubric else None),
        "self_bias_warning": (last.self_bias_warning if last else None),
        "critical_failures": [str(r) for r in (last.critical_failures if last else [])],
    })
    if result.status.value == "shipped":
        run.write_text("final.md", result.final_artifact)
        # 합격한 스킬을 skills/ 에 등록(공유 두뇌)
        skill_path = system.cfg.skills_dir / f"{topic.replace(' ', '_')}.md"
        skill_path.write_text(result.final_artifact, encoding="utf-8")
        print(f"\n[SHIPPED] 스킬 등록: {skill_path}")
    else:
        # 미달 → 개선 시그널을 공유 두뇌로
        system.emit_signal(
            summary=f"SKILL '{topic}' 품질 미달 — verifier 기준 재검토 필요",
            kind="friction", created_by="skillharness")
        print(f"\n[{result.status.value.upper()}] 개선 시그널 emit")

    print("\n" + result.report())
    print(f"RUN_DIR: {run.dir}")
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--serve", action="store_true", help="스케줄러 상주(데모 10초 간격)")
    ap.add_argument("--topic", default="Logpresso 캐리어 필터 쿼리 작성법")
    ap.add_argument("--mock", action="store_true",
                    help="엔드포인트 없이 목 LLM 으로 동작(오프라인 테스트)")
    args = ap.parse_args()

    # 작업공간 + 커넥터
    if args.mock:
        # 라운드마다 점점 좋아지는 목
        st = {"n": 0}

        def responder(messages, model):
            sys_txt = messages[0]["content"] if messages else ""
            if "평가자" in sys_txt:
                st["n"] += 1
                return '{"score": %.1f, "reasons": "목 평가"}' % min(9.0, 6.5 + st["n"])
            return ("# 데모 스킬\n## 목적\n데모.\n## 사용 시점\n언제든.\n"
                    "## 절차\n1) 먼저 한다 2) 다음 한다 3) 확인한다.\n"
                    "## 예시\n`example()` 처럼.\n## 주의\n폐쇄망 주의.\n" * 5)

        client = LLMClient(LLMConfig(endpoint="LOCAL"),
                           transport=make_mock_transport(responder))
        system = LoopSystem(LoopConfig(base_dir=Path("loop_workspace_demo")),
                            client=client)
        gen_model, ver_model = "qwen-mock", "glm-mock"
    else:
        cfg = LoopConfig(
            base_dir=Path("loop_workspace"),
            llm=LLMConfig(endpoint="LOCAL",          # DEV / COMMON 으로 교체
                          generator_model="gpt-oss-20b",
                          verifier_model="glm-5"),
        )
        system = LoopSystem(cfg)
        gen_model, ver_model = cfg.llm.generator_model, cfg.llm.verifier_model

    if args.serve:
        # 자동 트리거: 데모는 10초 간격. 실제론 cron 예: 매일 9시 -> "0 9 * * *"
        system.register(build_skillharness_loop(system, args.topic, gen_model, ver_model))
        # 간격 트리거로 run_once 를 감싸 등록
        system.scheduler.every("skillharness", 10,
                               lambda: run_once(system, args.topic, gen_model, ver_model))
        print("[SERVE] 스케줄러 시작 (Ctrl+C 종료). 10초마다 1회 실행.")
        try:
            system.start(background=False)
        except KeyboardInterrupt:
            system.stop()
            print("\n[STOP]")
    else:
        run_once(system, args.topic, gen_model, ver_model)


if __name__ == "__main__":
    main()
