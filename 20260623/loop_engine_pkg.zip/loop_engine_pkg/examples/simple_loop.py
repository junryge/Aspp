"""
examples/simple_loop.py — 가장 작은 closed loop 예제

실제 내부 LLM 엔드포인트(DEV/COMMON/LOCAL)에 붙여서 한 번 돌린다.
TOKEN.TXT 가 CWD 에 있으면 자동 로딩.

실행:
    python examples/simple_loop.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from loop_engine import (LLMClient, LLMConfig, Generator, VerifierAgent,
                         CheckSuite, Rubric, Loop, LoopSpec, LoopMode,
                         check_min_length, check_contains, check_no_placeholder)


def main():
    # 1) 커넥터 — 내부 LLM (가능하면 generator 와 verifier 모델을 다르게!)
    cfg = LLMConfig(
        endpoint="LOCAL",                 # "DEV" / "COMMON" 으로 교체
        generator_model="gpt-oss-20b",
        verifier_model="glm-5",           # 다른 모델 = self-bias 회피
        temperature=0.7,
        verifier_temperature=0.0,
    )
    client = LLMClient(cfg)

    # 2) 짓는 AI
    gen = Generator(client)

    # 3) 검사하는 AI = 하드체크(바닥) + 루브릭(품질바)
    suite = CheckSuite([
        check_min_length(300),
        check_contains("AMHS"),
        check_no_placeholder(),
    ])
    rubric = Rubric(
        criteria="① 사실 정확성 ② 구조 명료성 ③ 실무 적용성. 각 항목 엄격 채점.",
        pass_score=8.0,
    )
    verifier = VerifierAgent(
        client, check_suite=suite, rubric=rubric,
        verifier_model=cfg.verifier_model,
        generator_model=cfg.generator_model,
    )

    # 4) 루프 정의 — done 을 '측정 가능'하게
    spec = LoopSpec(
        name="amhs_brief",
        goal=("반도체 FAB 의 AMHS(OHT/AGV/CNV) 물류 혼잡 예측 개념을 "
              "현업 보고용으로 300자 이상 요약. 'AMHS' 단어 포함, 미완성 표현 금지."),
        generator=gen,
        verifier=verifier,
        mode=LoopMode.CLOSED,
        max_rounds=4,
    )

    # 5) 실행
    result = Loop(spec, on_round=lambda r: print(
        f"  round {r.index}: done={r.verdict.done} "
        f"score={r.verdict.rubric.score if r.verdict.rubric else '-'}")).run()

    print("\n" + result.report())
    print("\n=== 최종 산출물 ===\n")
    print(result.final_artifact)


if __name__ == "__main__":
    main()
