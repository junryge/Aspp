/**
 * layout_map_cre.js - layout.xml에서 노드/연결 JSON 생성
 *
 * Python layout_map_cre.py의 JavaScript/React 마이그레이션
 *
 * 사용법:
 *   // 브라우저 (File input 또는 fetch)
 *   import { parseLayoutXml, parseLayoutZip } from './layout_map_cre';
 *   const { nodes, connections } = parseLayoutXml(xmlString);
 *
 *   // Node.js
 *   const fs = require('fs');
 *   const xml = fs.readFileSync('layout.xml', 'utf-8');
 *   const result = parseLayoutXml(xml);
 *   fs.writeFileSync('layout.json', JSON.stringify(result));
 *
 * 출력 형식:
 *   {
 *     nodes: [{ no: int, x: float, y: float, stations: [] }, ...],
 *     connections: [[from_no, to_no], ...],
 *     meta: { nodeCount, connectionCount, parseTime }
 *   }
 */

// ============================================================
// XML 라인 단위 파싱 (원본 Python과 동일한 로직)
// ============================================================
export function parseLayoutXml(xmlContent) {
  console.log('XML 파싱 시작...');
  const startTime = performance.now();

  const nodes = {};
  const connections = [];

  let currentAddr = null;
  let currentAddrParams = {};
  let inNextAddr = false;
  let nextAddrParams = {};

  const lines = xmlContent.split('\n');
  const totalLines = lines.length;
  console.log(`  총 라인 수: ${totalLines.toLocaleString()}`);

  for (let lineNo = 0; lineNo < totalLines; lineNo++) {
    if (lineNo % 500000 === 0 && lineNo > 0) {
      console.log(`  처리 중: ${lineNo.toLocaleString()}/${totalLines.toLocaleString()} (${Math.floor(lineNo * 100 / totalLines)}%)`);
    }

    const line = lines[lineNo].trim();

    // Addr 그룹 시작
    if (line.includes('<group name="Addr') && line.includes('class=') && line.includes('address.Addr"')) {
      // 이전 Addr 저장
      if (currentAddr !== null && currentAddrParams.address) {
        const addrNo = parseInt(currentAddrParams.address, 10);
        if (addrNo > 0) {
          const x = parseFloat(currentAddrParams['draw-x'] || 0);
          const y = parseFloat(currentAddrParams['draw-y'] || 0);
          nodes[addrNo] = { no: addrNo, x: Math.round(x * 100) / 100, y: Math.round(y * 100) / 100, stations: [] };
        }
      }
      currentAddrParams = {};
      currentAddr = line;
      inNextAddr = false;
      continue;
    }

    // NextAddr 그룹 시작
    if (line.includes('<group name="NextAddr') && line.includes('class=') && line.includes('NextAddr"')) {
      inNextAddr = true;
      nextAddrParams = {};
      continue;
    }

    // NextAddr 그룹 종료
    if (inNextAddr && line.includes('</group>')) {
      if (currentAddrParams.address && nextAddrParams['next-address']) {
        const fromAddr = parseInt(currentAddrParams.address, 10);
        const toAddr = parseInt(nextAddrParams['next-address'], 10);
        if (fromAddr > 0 && toAddr > 0) {
          connections.push([fromAddr, toAddr]);
        }
      }
      inNextAddr = false;
      continue;
    }

    // 파라미터 파싱
    if (line.includes('<param ') && line.includes('key="') && line.includes('value="')) {
      const keyMatch = line.match(/key="([^"]+)"/);
      const valueMatch = line.match(/value="([^"]*)"/);

      if (keyMatch && valueMatch) {
        const key = keyMatch[1];
        const value = valueMatch[1];

        if (inNextAddr) {
          nextAddrParams[key] = value;
        } else if (currentAddr !== null) {
          currentAddrParams[key] = value;
        }
      }
    }
  }

  // 마지막 Addr 저장
  if (currentAddr !== null && currentAddrParams.address) {
    const addrNo = parseInt(currentAddrParams.address, 10);
    if (addrNo > 0) {
      const x = parseFloat(currentAddrParams['draw-x'] || 0);
      const y = parseFloat(currentAddrParams['draw-y'] || 0);
      nodes[addrNo] = { no: addrNo, x: Math.round(x * 100) / 100, y: Math.round(y * 100) / 100, stations: [] };
    }
  }

  const nodeList = Object.values(nodes);
  const parseTime = Math.round(performance.now() - startTime);

  console.log(`  총 노드: ${nodeList.length}개`);
  console.log(`  총 연결: ${connections.length}개`);
  console.log(`  파싱 시간: ${parseTime}ms`);

  return {
    nodes: nodeList,
    connections,
    meta: {
      nodeCount: nodeList.length,
      connectionCount: connections.length,
      parseTime
    }
  };
}

// ============================================================
// ZIP 파일에서 layout.xml 추출 후 파싱
// JSZip 라이브러리 필요: npm install jszip
// ============================================================
export async function parseLayoutZip(zipArrayBuffer) {
  // dynamic import for JSZip (브라우저/Node.js 호환)
  let JSZip;
  try {
    JSZip = (await import('jszip')).default;
  } catch {
    throw new Error('JSZip 라이브러리가 필요합니다: npm install jszip');
  }

  console.log('layout.zip에서 XML 추출 중...');
  const zip = await JSZip.loadAsync(zipArrayBuffer);

  // XML 파일 찾기 (우선순위: layout/layout.xml > layout.xml > *.xml)
  let xmlFile = null;
  const fileNames = Object.keys(zip.files);
  console.log(`  ZIP 내 파일 수: ${fileNames.length}개`);

  for (const name of fileNames) {
    const lower = name.toLowerCase();
    if (lower === 'layout/layout.xml') { xmlFile = name; break; }
    if (lower === 'layout.xml' && !xmlFile) xmlFile = name;
    if (lower.endsWith('.xml') && lower.includes('layout') && !xmlFile) xmlFile = name;
  }

  if (!xmlFile) {
    const xmlFiles = fileNames.filter(f => f.toLowerCase().endsWith('.xml'));
    throw new Error(`ZIP 파일 내에 layout.xml이 없습니다. XML 파일들: ${xmlFiles.join(', ')}`);
  }

  console.log(`  사용할 XML 파일: ${xmlFile}`);
  const xmlContent = await zip.file(xmlFile).async('string');
  console.log(`  XML 크기: ${xmlContent.length.toLocaleString()} bytes`);

  return parseLayoutXml(xmlContent);
}

// ============================================================
// layout.html 형식의 JSON 생성 (기존 호환)
// 기존 layout.html의 const A=[...]; const C=[...]; 형태
// ============================================================
export function generateLayoutHtml(nodes, connections) {
  const nodesJson = JSON.stringify(nodes);
  const connectionsJson = JSON.stringify(connections);

  return `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>OHT Layout Data</title>
    <script>
const A=${nodesJson};
const C=${connectionsJson};
    </script>
</head>
<body>
    <p>Nodes: ${nodes.length}, Connections: ${connections.length}</p>
</body>
</html>`;
}

// ============================================================
// layout.json 파일 생성 (React 호환 - JSON 형식)
// ============================================================
export function generateLayoutJson(nodes, connections) {
  return JSON.stringify({
    nodes,
    connections,
    meta: {
      nodeCount: nodes.length,
      connectionCount: connections.length,
      generatedAt: new Date().toISOString()
    }
  }, null, 2);
}

// ============================================================
// FAB 경로 헬퍼 (Node.js 환경용)
// ============================================================
export function getFabPaths(baseDir, fabName, layoutPrefix = 'A') {
  const prefix = layoutPrefix.toUpperCase();
  const fabDir = `${baseDir}/MAP/${fabName}`;
  const extractedDir = `${fabDir}/${prefix}.layout`;

  return {
    layoutZip: `${fabDir}/${prefix}.layout.zip`,
    layoutXml: `${extractedDir}/layout/layout.xml`,
    layoutHtml: `${fabDir}/${prefix}.layout.html`,
    layoutJson: `${fabDir}/${prefix}.layout.json`
  };
}

// ============================================================
// 브라우저용: File 객체에서 파싱
// <input type="file"> 에서 사용
// ============================================================
export async function parseLayoutFromFile(file) {
  const name = file.name.toLowerCase();

  if (name.endsWith('.zip')) {
    const arrayBuffer = await file.arrayBuffer();
    return parseLayoutZip(arrayBuffer);
  } else if (name.endsWith('.xml')) {
    const text = await file.text();
    return parseLayoutXml(text);
  } else if (name.endsWith('.html')) {
    // 기존 layout.html에서 A, C 배열 추출
    const text = await file.text();
    const aMatch = text.match(/const A=(\[.*?\]);/s);
    const cMatch = text.match(/const C=(\[.*?\]);/s);
    if (aMatch && cMatch) {
      const nodes = JSON.parse(aMatch[1]);
      const connections = JSON.parse(cMatch[1]);
      return {
        nodes,
        connections,
        meta: { nodeCount: nodes.length, connectionCount: connections.length, parseTime: 0 }
      };
    }
    throw new Error('layout.html에서 노드/연결 데이터를 찾을 수 없습니다');
  }

  throw new Error(`지원하지 않는 파일 형식: ${name}`);
}

// ============================================================
// Node.js CLI 실행
// ============================================================
// node layout_map_cre.js <input.xml|.zip> [output.json]
if (typeof process !== 'undefined' && process.argv && process.argv[1]?.includes('layout_map_cre')) {
  (async () => {
    const fs = await import('fs');
    const path = await import('path');

    const args = process.argv.slice(2);
    const inputPath = args[0];
    const outputPath = args[1];

    if (!inputPath) {
      console.log('사용법: node layout_map_cre.js <input.xml|.zip> [output.json]');
      console.log('  --fab M14A --layout A   FAB 모드');
      process.exit(1);
    }

    // FAB 모드
    if (args.includes('--fab')) {
      const fabIdx = args.indexOf('--fab');
      const fabName = args[fabIdx + 1] || 'M14A';
      let layoutPrefix = 'A';
      if (args.includes('--layout')) {
        const layoutIdx = args.indexOf('--layout');
        layoutPrefix = args[layoutIdx + 1] || 'A';
      }

      const scriptDir = path.dirname(new URL(import.meta.url).pathname);
      const paths = getFabPaths(scriptDir, fabName, layoutPrefix);

      let result;
      if (fs.existsSync(paths.layoutXml)) {
        const xml = fs.readFileSync(paths.layoutXml, 'utf-8');
        result = parseLayoutXml(xml);
      } else if (fs.existsSync(paths.layoutZip)) {
        const buf = fs.readFileSync(paths.layoutZip);
        result = await parseLayoutZip(buf.buffer);
      } else {
        console.error(`파일을 찾을 수 없음: ${paths.layoutXml} 또는 ${paths.layoutZip}`);
        process.exit(1);
      }

      // JSON 출력
      const jsonPath = paths.layoutJson;
      fs.writeFileSync(jsonPath, generateLayoutJson(result.nodes, result.connections));
      console.log(`JSON 저장: ${jsonPath}`);

      // HTML 호환 출력
      fs.writeFileSync(paths.layoutHtml, generateLayoutHtml(result.nodes, result.connections));
      console.log(`HTML 저장: ${paths.layoutHtml}`);
      return;
    }

    // 직접 경로 모드
    let result;
    if (inputPath.endsWith('.zip')) {
      const buf = fs.readFileSync(inputPath);
      result = await parseLayoutZip(buf.buffer);
    } else {
      const xml = fs.readFileSync(inputPath, 'utf-8');
      result = parseLayoutXml(xml);
    }

    const outPath = outputPath || inputPath.replace(/\.(xml|zip)$/, '.json');
    fs.writeFileSync(outPath, generateLayoutJson(result.nodes, result.connections));
    console.log(`JSON 저장: ${outPath} (${result.meta.nodeCount}노드, ${result.meta.connectionCount}연결)`);
  })();
}

export default parseLayoutXml;
