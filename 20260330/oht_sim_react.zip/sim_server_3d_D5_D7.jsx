/**
 * sim_server_3d_D5_D7.jsx - OHT 실시간 시뮬레이터 React 프론트엔드
 *
 * Python sim_server_3d_D5_D7.py 내장 HTML/CSS/JS의 React 마이그레이션
 * FastAPI 백엔드에 WebSocket/REST로 연결하여 사용
 *
 * 사용법:
 *   import OHTSimulator from './sim_server_3d_D5_D7';
 *   <OHTSimulator serverUrl="ws://localhost:8000" />
 *
 * 의존성:
 *   - react, react-dom
 *   - three (Three.js 3D 모드용)
 *   - layout_map_cre.js, hid_zone_csv_cre.js (XML 파싱)
 */

import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';

// ============================================================
// Constants
// ============================================================
const ISO_SCALE_Y = 0.6;
const RAIL_HEIGHT = 8;
const OHT_HEIGHT = 12;
const PATH_COLORS = ['#00ffff', '#ff00ff', '#ffff00', '#00ff00', '#ff8800', '#8800ff'];
const STATE_NAMES = { 1: '운행', 2: '정지', 3: '이상', 4: '수동', 5: '제거중', 6: 'OBS정지', 7: '정체', 8: 'HT정지', 9: 'E84타임아웃' };
const STATION_COLORS = { MAINTENANCE: '#ff6600', ACQUIRE: '#00ff00', DEPOSIT: '#ff00ff', DUMMY: '#666666' };

// ============================================================
// Utility Functions
// ============================================================
function toIso(x, y, z = 0, pseudo3D = true) {
  if (!pseudo3D) return { x, y };
  return { x, y: y * ISO_SCALE_Y - z };
}

function adjustColor(hex, factor) {
  if (!hex || hex.length < 4) return hex;
  const c = hex.replace('#', '');
  const r = Math.min(255, Math.max(0, Math.round(parseInt(c.substr(0, 2), 16) * factor)));
  const g = Math.min(255, Math.max(0, Math.round(parseInt(c.substr(2, 2), 16) * factor)));
  const b = Math.min(255, Math.max(0, Math.round(parseInt(c.substr(4, 2), 16) * factor)));
  return '#' + [r, g, b].map(v => v.toString(16).padStart(2, '0')).join('');
}

function lightenColor(color, amount) {
  const c = color.replace('#', '');
  return '#' + [0, 2, 4].map(i => Math.min(255, parseInt(c.substr(i, 2), 16) + amount).toString(16).padStart(2, '0')).join('');
}

function darkenColor(color, amount) {
  const c = color.replace('#', '');
  return '#' + [0, 2, 4].map(i => Math.max(0, parseInt(c.substr(i, 2), 16) - amount).toString(16).padStart(2, '0')).join('');
}

function heatColor(ratio) {
  ratio = Math.max(0, Math.min(1, ratio));
  let r, g, b;
  if (ratio < 0.25) { const t = ratio / 0.25; r = Math.round(255 * t); g = 180; b = 0; }
  else if (ratio < 0.5) { const t = (ratio - 0.25) / 0.25; r = 255; g = Math.round(180 - t * 44); b = 0; }
  else if (ratio < 0.75) { const t = (ratio - 0.5) / 0.25; r = 255; g = Math.round(136 - t * 68); b = 0; }
  else { const t = (ratio - 0.75) / 0.25; r = 255; g = Math.round(68 - t * 68); b = 0; }
  return '#' + [r, g, b].map(v => v.toString(16).padStart(2, '0')).join('');
}

function normalize(v) { const l = Math.hypot(v.x, v.y); return l > 0 ? { x: v.x / l, y: v.y / l } : { x: 0, y: 0 }; }
function angleBetween(v1, v2) { return Math.atan2(Math.abs(v1.x * v2.y - v1.y * v2.x), v1.x * v2.x + v1.y * v2.y); }

function getCurveControlPoints(nodeId, fromId, toId, nodeMap, radius) {
  const n = nodeMap[nodeId], f = nodeMap[fromId], t = nodeMap[toId];
  if (!n || !f || !t) return null;
  const v1 = { x: f.x - n.x, y: f.y - n.y }, v2 = { x: t.x - n.x, y: t.y - n.y };
  const angle = angleBetween(v1, v2);
  if (angle > Math.PI * 0.95) return null;
  const d1 = Math.hypot(v1.x, v1.y), d2 = Math.hypot(v2.x, v2.y);
  const off = Math.min(radius, d1 * 0.4, d2 * 0.4);
  const n1 = normalize(v1), n2 = normalize(v2);
  return { start: { x: n.x + n1.x * off, y: n.y + n1.y * off }, end: { x: n.x + n2.x * off, y: n.y + n2.y * off }, control: { x: n.x, y: n.y }, angle };
}

function getOhtStateClass(v) {
  if (String(v.state) === '7') return 'jam';
  if (String(v.state) === '2') return 'stopped';
  if (v.isLoaded === 1) return 'loaded';
  if (String(v.state) === '1') return 'running';
  return 'other';
}

function getZoneStateClass(zone) {
  const cnt = zone.vehicleCount || 0, max = zone.vehicleMax || 1, prec = zone.vehiclePrecaution || Math.ceil(max * 0.7);
  if (cnt >= max) return 'full';
  if (cnt >= prec) return 'precaution';
  return 'normal';
}

// ============================================================
// API Helper
// ============================================================
async function apiCall(path, method = 'GET') {
  const res = await fetch(path, { method });
  return res.json();
}

// ============================================================
// STYLES
// ============================================================
const STYLES = {
  dark: {
    bg: '#0a0a1a', text: '#eee', headerBg: 'linear-gradient(90deg, #1a1a3e, #2a2a5e)',
    accent: '#00d4ff', sidebarBg: 'rgba(20,20,40,0.95)', sectionBg: '#1a1a2e',
    border: '#333', valColor: '#00d4ff', inputBg: '#1a1a3e', tooltipBg: 'rgba(10,10,30,0.95)'
  },
  light: {
    bg: '#f0f2f5', text: '#222', headerBg: 'linear-gradient(90deg, #e8eaf0, #d0d4e0)',
    accent: '#0066cc', sidebarBg: 'rgba(240,242,248,0.97)', sectionBg: '#e4e8f0',
    border: '#ccc', valColor: '#0066cc', inputBg: '#fff', tooltipBg: 'rgba(255,255,255,0.97)'
  }
};

// ============================================================
// MAIN COMPONENT
// ============================================================
export default function OHTSimulator({ serverUrl }) {
  // ---- State ----
  const [theme, setTheme] = useState('dark');
  const [layout, setLayout] = useState(null);
  const [vehicles, setVehicles] = useState({});
  const [stats, setStats] = useState({ total: 0, running: 0, loaded: 0, stopped: 0, jammed: 0 });
  const [velocityStats, setVelocityStats] = useState({ avg: 0, max: 0, min: 0, abs: 0 });
  const [inOutStats, setInOutStats] = useState({ totalIn: 0, totalOut: 0, ratio: 0, deadlockRiskCount: 0 });
  const [zoneStats, setZoneStats] = useState({ totalZones: 0, normalZones: 0, precautionZones: 0, fullZones: 0, overallOccupancy: 0 });
  const [jamStats, setJamStats] = useState({ jam_vehicle_count: 0, high_risk_edges: 0, medium_risk_edges: 0 });
  const [hidZones, setHidZones] = useState([]);
  const [stations, setStations] = useState([]);
  const [stkList, setStkList] = useState([]);
  const [zoneStatusMap, setZoneStatusMap] = useState({});
  const [edgeHeatmapData, setEdgeHeatmapData] = useState({});
  const [deadlockEdges, setDeadlockEdges] = useState([]);
  const [fullZoneList, setFullZoneList] = useState([]);
  const [precautionZoneList, setPrecautionZoneList] = useState([]);

  // Settings
  const [isPseudo3D, setIsPseudo3D] = useState(false);
  const [is3DMode, setIs3DMode] = useState(false);
  const [enableCurves, setEnableCurves] = useState(true);
  const [curveRadius, setCurveRadius] = useState(30);
  const [heatmapMode, setHeatmapMode] = useState('off');
  const [showZones, setShowZones] = useState(false);
  const [showStations, setShowStations] = useState(false);
  const [showStationIds, setShowStationIds] = useState(false);
  const [showStationNames, setShowStationNames] = useState(false);
  const [showZoneMarkers, setShowZoneMarkers] = useState(true);
  const [showSTK, setShowSTK] = useState(true);
  const [stkPlaceMode, setStkPlaceMode] = useState(false);
  const [stkDeleteMode, setStkDeleteMode] = useState(false);
  const [stkExpanded, setStkExpanded] = useState({});
  const [vehicleCount, setVehicleCount] = useState(450);
  const [vehicleMsg, setVehicleMsg] = useState('');
  const [deadlockMsg, setDeadlockMsg] = useState('');

  // Selection
  const [selectedVehicles, setSelectedVehicles] = useState(new Set());
  const [selectedZoneId, setSelectedZoneId] = useState(null);

  // Sidebars
  const [leftOpen, setLeftOpen] = useState(false);
  const [rightOpen, setRightOpen] = useState(false);
  const [rightTab, setRightTab] = useState('oht');
  const [ohtFilter, setOhtFilter] = useState('all');
  const [ohtSearch, setOhtSearch] = useState('');
  const [zoneFilter, setZoneFilter] = useState('all');
  const [zoneSearch, setZoneSearch] = useState('');
  const [expandedOhtId, setExpandedOhtId] = useState(null);

  // FAB
  const [fabInfo, setFabInfo] = useState(null);
  const [currentFab, setCurrentFab] = useState('M14A');
  const [currentLayout, setCurrentLayout] = useState('A');
  const [fabSelectValue, setFabSelectValue] = useState('M14A');
  const [layoutSelectValue, setLayoutSelectValue] = useState('A');

  // Refs
  const canvasRef = useRef(null);
  const wsRef = useRef(null);
  const nodeMapRef = useRef({});
  const viewRef = useRef({ offsetX: 0, offsetY: 0, scale: 1 });
  const dragRef = useRef({ isDragging: false, lastX: 0, lastY: 0 });
  const vehicleDispRef = useRef({});
  const nodeConnectionsRef = useRef({});
  const startTimeRef = useRef(Date.now());
  const animRef = useRef(null);
  const zoneManualOffRef = useRef(false);
  const stationIdManualOffRef = useRef(false);

  const T = STYLES[theme];

  // ---- Node Map ----
  const nodeMap = nodeMapRef.current;

  // ============================================================
  // WebSocket Connection
  // ============================================================
  useEffect(() => {
    const wsUrl = serverUrl || `ws://${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onmessage = (e) => {
      const msg = JSON.parse(e.data);

      if (msg.type === 'layout') {
        setLayout(msg.data);
        const nm = {};
        msg.data.nodes.forEach(n => nm[n.no] = n);
        nodeMapRef.current = nm;

        setHidZones(msg.data.hidZones || []);
        setStations(msg.data.stations || []);
        setStkList(msg.data.stkList || []);

        // Build node connections for curves
        const conns = {};
        (msg.data.edges || []).forEach(e => {
          if (!conns[e.from]) conns[e.from] = [];
          if (!conns[e.to]) conns[e.to] = [];
          conns[e.from].push({ to: e.to });
          conns[e.to].push({ to: e.from });
        });
        nodeConnectionsRef.current = conns;

        // Fit view
        setTimeout(() => fitView(), 100);
      }

      if (msg.type === 'update') {
        const vehMap = { ...vehicleDispRef.current };
        (msg.data.vehicles || []).forEach(v => {
          if (!vehMap[v.vehicleId]) {
            vehMap[v.vehicleId] = { ...v, dispX: v.x, dispY: v.y };
          } else {
            Object.assign(vehMap[v.vehicleId], v);
          }
        });
        vehicleDispRef.current = vehMap;
        setVehicles({ ...vehMap });

        // Stats
        const s = msg.data.stats || {};
        setStats({ total: s.total || 0, running: s.running || 0, loaded: s.loaded || 0, stopped: s.stopped || 0, jammed: s.jammed || 0 });

        // Velocity stats
        const running = (msg.data.vehicles || []).filter(v => v.state === 1 && v.velocity > 0);
        if (running.length > 0) {
          const vels = running.map(v => v.velocity);
          const avg = vels.reduce((a, b) => a + b, 0) / vels.length;
          setVelocityStats({ avg: avg.toFixed(1), max: Math.max(...vels).toFixed(1), min: Math.min(...vels).toFixed(1), abs: ((avg / 300) * 100).toFixed(1) });
        }

        // In/Out
        if (msg.data.inOutStats) setInOutStats(msg.data.inOutStats);

        // Zone stats
        if (msg.data.zoneStats) setZoneStats(msg.data.zoneStats);

        // Deadlock edges
        setDeadlockEdges(msg.data.deadlockEdges || []);

        // Zone status map
        if (msg.data.zoneStatusMap) {
          setZoneStatusMap(msg.data.zoneStatusMap);
          // Update hidZones with real-time data
          setHidZones(prev => prev.map(z => {
            const st = msg.data.zoneStatusMap[z.zoneId];
            return st ? { ...z, vehicleCount: st.vehicleCount, occupancyRate: st.occupancyRate, status: st.status } : z;
          }));
        }

        // Edge heatmap
        if (msg.data.edgeHeatmap) {
          const hd = {};
          msg.data.edgeHeatmap.forEach(e => { hd[e.f + '-' + e.t] = e; });
          setEdgeHeatmapData(hd);
        }

        // Full/Precaution zone lists
        setFullZoneList(msg.data.fullZoneList || []);
        setPrecautionZoneList(msg.data.precautionZoneList || []);

        // STK update
        if (msg.data.stkList) {
          setStkList(prev => prev.map(s => {
            const ns = msg.data.stkList.find(n => n.stkId === s.stkId);
            return ns ? { ...s, usedSlots: ns.usedSlots, freeSlots: ns.freeSlots, usageRate: ns.usageRate, status: ns.status } : s;
          }));
        }
      }
    };

    ws.onclose = () => console.log('WebSocket 연결 해제');
    ws.onerror = (e) => console.error('WebSocket 오류:', e);

    return () => ws.close();
  }, [serverUrl]);

  // ============================================================
  // FAB Info Load
  // ============================================================
  useEffect(() => {
    apiCall('/api/fab/list').then(data => {
      setFabInfo(data);
      setCurrentFab(data.current_fab);
      setCurrentLayout(data.current_layout);
      setFabSelectValue(data.current_fab);
      setLayoutSelectValue(data.current_layout);
    }).catch(() => {});

    // JAM stats polling
    const jamInterval = setInterval(() => {
      apiCall('/api/jam-stats').then(data => setJamStats(data)).catch(() => {});
    }, 5000);
    apiCall('/api/jam-stats').then(data => setJamStats(data)).catch(() => {});

    return () => clearInterval(jamInterval);
  }, []);

  // ============================================================
  // Fit View
  // ============================================================
  const fitView = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !layout?.nodes?.length) return;
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    layout.nodes.forEach(n => {
      minX = Math.min(minX, n.x); maxX = Math.max(maxX, n.x);
      minY = Math.min(minY, n.y); maxY = Math.max(maxY, n.y);
    });
    const pad = 50, w = maxX - minX, h = maxY - minY;
    const sx = (canvas.width - pad * 2) / w, sy = (canvas.height - pad * 2) / h;
    const scale = Math.min(sx, sy);
    viewRef.current = {
      offsetX: pad - minX * scale + (canvas.width - pad * 2 - w * scale) / 2,
      offsetY: pad - minY * scale + (canvas.height - pad * 2 - h * scale) / 2,
      scale
    };
  }, [layout]);

  // ============================================================
  // ESC key handler
  // ============================================================
  useEffect(() => {
    const handler = (e) => {
      if (e.key === 'Escape') {
        setStkPlaceMode(false);
        setStkDeleteMode(false);
      }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, []);

  // ============================================================
  // Canvas Resize
  // ============================================================
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const resize = () => {
      const container = canvas.parentElement;
      canvas.width = container.clientWidth;
      canvas.height = container.clientHeight;
    };
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [leftOpen, rightOpen]);

  // ============================================================
  // RENDER ENGINE (Canvas 2D)
  // ============================================================
  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const { offsetX, offsetY, scale } = viewRef.current;
    const isWhite = theme === 'light';
    const p3d = isPseudo3D;

    // Clear
    ctx.fillStyle = isWhite ? '#f0f2f5' : '#0a0a1a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    if (!layout) return;

    ctx.save();
    ctx.translate(offsetX, offsetY);
    ctx.scale(scale, scale);

    const nm = nodeMapRef.current;
    const railColor = isWhite ? '#8899aa' : '#2a4a6a';

    // ---- DRAW RAILS ----
    if (heatmapMode === 'off' || heatmapMode === 'zone') {
      // Curved or straight rails
      if (enableCurves && layout.edges) {
        // Find corner nodes
        const conns = nodeConnectionsRef.current;
        const cornerNodes = new Set();
        const cornerCurves = {};

        layout.nodes.forEach(node => {
          const c = conns[node.no];
          if (!c || c.length !== 2) return;
          const curve = getCurveControlPoints(node.no, c[0].to, c[1].to, nm, curveRadius);
          if (curve && curve.angle < Math.PI * 0.83) {
            cornerNodes.add(node.no);
            cornerCurves[node.no] = { curve, fromId: c[0].to, toId: c[1].to };
          }
        });

        // Straight segments (shortened at corners)
        layout.edges.forEach(e => {
          const from = nm[e.from], to = nm[e.to];
          if (!from || !to) return;
          let sx = from.x, sy = from.y, ex = to.x, ey = to.y;
          const len = Math.hypot(to.x - from.x, to.y - from.y);
          if (cornerNodes.has(e.from)) {
            const d = normalize({ x: to.x - from.x, y: to.y - from.y });
            const off = Math.min(curveRadius, len * 0.4);
            sx = from.x + d.x * off; sy = from.y + d.y * off;
          }
          if (cornerNodes.has(e.to)) {
            const d = normalize({ x: from.x - to.x, y: from.y - to.y });
            const off = Math.min(curveRadius, len * 0.4);
            ex = to.x + d.x * off; ey = to.y + d.y * off;
          }
          if (p3d) {
            draw3DRailHelper(ctx, sx, sy, ex, ey, railColor, scale, p3d);
          } else {
            ctx.strokeStyle = railColor; ctx.lineWidth = 2 / scale;
            ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(ex, ey); ctx.stroke();
          }
        });

        // Corner curves
        cornerNodes.forEach(nid => {
          const info = cornerCurves[nid]; if (!info) return;
          const c = info.curve;
          if (p3d) {
            const s = toIso(c.start.x, c.start.y, RAIL_HEIGHT / scale, p3d);
            const e = toIso(c.end.x, c.end.y, RAIL_HEIGHT / scale, p3d);
            const cp = toIso(c.control.x, c.control.y, RAIL_HEIGHT / scale, p3d);
            ctx.strokeStyle = adjustColor(railColor, 1.2); ctx.lineWidth = 3 / scale; ctx.lineCap = 'round';
            ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.quadraticCurveTo(cp.x, cp.y, e.x, e.y); ctx.stroke();
          } else {
            ctx.strokeStyle = railColor; ctx.lineWidth = 2 / scale; ctx.lineCap = 'round';
            ctx.beginPath(); ctx.moveTo(c.start.x, c.start.y); ctx.quadraticCurveTo(c.control.x, c.control.y, c.end.x, c.end.y); ctx.stroke();
          }
        });
      } else if (layout.edges) {
        layout.edges.forEach(e => {
          const from = nm[e.from], to = nm[e.to];
          if (!from || !to) return;
          if (p3d) draw3DRailHelper(ctx, from.x, from.y, to.x, to.y, railColor, scale, p3d);
          else { ctx.strokeStyle = railColor; ctx.lineWidth = 2 / scale; ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke(); }
        });
      }
    } else {
      // Heatmap rails (traffic/density/velocity)
      drawHeatmapRails(ctx, layout, nm, edgeHeatmapData, heatmapMode, scale, p3d);
    }

    // ---- NODES ----
    const nodeSize = Math.max(1.5, 3 / scale);
    layout.nodes.forEach(n => {
      if (p3d) {
        const pos = toIso(n.x, n.y, RAIL_HEIGHT / scale, p3d);
        ctx.fillStyle = isWhite ? '#6688aa' : '#4a6a8a';
        ctx.beginPath(); ctx.ellipse(pos.x, pos.y, nodeSize, nodeSize * 0.5, 0, 0, Math.PI * 2); ctx.fill();
      } else {
        ctx.fillStyle = isWhite ? '#99aabb' : '#4a4a6a';
        ctx.beginPath(); ctx.arc(n.x, n.y, nodeSize, 0, Math.PI * 2); ctx.fill();
      }
    });

    // ---- HID ZONE LANES ----
    if (hidZones.length > 0) {
      const zoneZ = RAIL_HEIGHT / scale + 2;
      hidZones.forEach(zone => {
        const status = zoneStatusMap[zone.zoneId];
        const isSelected = selectedZoneId === zone.zoneId;
        if (!isSelected && !showZones) return;

        let zoneColor = '#00ff88', zoneAlpha = 0.3;
        if (status?.status === 'FULL') { zoneColor = '#ff3366'; zoneAlpha = 0.8; }
        else if (status?.status === 'PRECAUTION') { zoneColor = '#ffaa00'; zoneAlpha = 0.6; }

        ctx.strokeStyle = zoneColor; ctx.lineWidth = Math.max(3, 5 / scale); ctx.globalAlpha = zoneAlpha; ctx.setLineDash([]);
        let firstMid = null;

        // IN lanes (solid)
        (zone.inLanes || []).forEach((lane, idx) => {
          const from = nm[lane.from], to = nm[lane.to];
          if (!from || !to) return;
          const fi = toIso(from.x, from.y, zoneZ, p3d), ti = toIso(to.x, to.y, zoneZ, p3d);
          ctx.beginPath(); ctx.moveTo(fi.x, fi.y); ctx.lineTo(ti.x, ti.y); ctx.stroke();
          if (idx === 0) firstMid = toIso((from.x + to.x) / 2, (from.y + to.y) / 2, zoneZ, p3d);
          // Arrow
          const angle = Math.atan2(ti.y - fi.y, ti.x - fi.x);
          const al = 15 / scale;
          const mi = toIso((from.x + to.x) / 2, (from.y + to.y) / 2, zoneZ, p3d);
          ctx.beginPath();
          ctx.moveTo(mi.x, mi.y); ctx.lineTo(mi.x - al * Math.cos(angle - 0.4), mi.y - al * Math.sin(angle - 0.4));
          ctx.moveTo(mi.x, mi.y); ctx.lineTo(mi.x - al * Math.cos(angle + 0.4), mi.y - al * Math.sin(angle + 0.4));
          ctx.stroke();
        });

        // OUT lanes (dashed)
        ctx.setLineDash([6 / scale, 3 / scale]);
        (zone.outLanes || []).forEach(lane => {
          const from = nm[lane.from], to = nm[lane.to];
          if (!from || !to) return;
          const fi = toIso(from.x, from.y, zoneZ, p3d), ti = toIso(to.x, to.y, zoneZ, p3d);
          ctx.beginPath(); ctx.moveTo(fi.x, fi.y); ctx.lineTo(ti.x, ti.y); ctx.stroke();
        });

        // Zone ID label
        if (firstMid) {
          ctx.globalAlpha = 1.0; ctx.setLineDash([]);
          const fs = Math.max(8, 10 / scale);
          const labelY = firstMid.y - 20 / scale;
          const label = 'HID ' + zone.zoneId;
          ctx.font = 'bold ' + fs + 'px sans-serif';
          const tw = ctx.measureText(label).width;
          const pad = 3 / scale;
          ctx.fillStyle = 'rgba(0,0,0,0.7)';
          ctx.fillRect(firstMid.x - tw / 2 - pad, labelY - fs / 2 - pad, tw + pad * 2, fs + pad * 2);
          ctx.fillStyle = zoneColor; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.fillText(label, firstMid.x, labelY);
          // Vehicle count
          if (status) {
            const cLabel = status.vehicleCount + '/' + zone.vehicleMax;
            const cY = labelY + fs + pad * 2;
            const cfs = Math.max(8, 11 / scale);
            ctx.font = cfs + 'px sans-serif';
            const cw = ctx.measureText(cLabel).width;
            ctx.fillStyle = 'rgba(0,0,0,0.7)';
            ctx.fillRect(firstMid.x - cw / 2 - pad, cY - cfs / 2 - pad, cw + pad * 2, cfs + pad * 2);
            ctx.fillStyle = '#ffffff'; ctx.fillText(cLabel, firstMid.x, cY);
          }
        }

        // Selected zone highlight
        if (isSelected) {
          let mnX = Infinity, mxX = -Infinity, mnY = Infinity, mxY = -Infinity;
          [...(zone.inLanes || []), ...(zone.outLanes || [])].forEach(l => {
            const f = nm[l.from], t = nm[l.to];
            if (f) { mnX = Math.min(mnX, f.x); mxX = Math.max(mxX, f.x); mnY = Math.min(mnY, f.y); mxY = Math.max(mxY, f.y); }
            if (t) { mnX = Math.min(mnX, t.x); mxX = Math.max(mxX, t.x); mnY = Math.min(mnY, t.y); mxY = Math.max(mxY, t.y); }
          });
          if (mnX !== Infinity) {
            mnX -= 50; mxX += 50; mnY -= 50; mxY += 50;
            const tl = toIso(mnX, mnY, zoneZ, p3d), tr = toIso(mxX, mnY, zoneZ, p3d);
            const br = toIso(mxX, mxY, zoneZ, p3d), bl = toIso(mnX, mxY, zoneZ, p3d);
            ctx.strokeStyle = '#ffff00'; ctx.lineWidth = Math.max(3, 4 / scale); ctx.globalAlpha = 1; ctx.setLineDash([10 / scale, 5 / scale]);
            ctx.beginPath(); ctx.moveTo(tl.x, tl.y); ctx.lineTo(tr.x, tr.y); ctx.lineTo(br.x, br.y); ctx.lineTo(bl.x, bl.y); ctx.closePath(); ctx.stroke();
            ctx.fillStyle = 'rgba(255,255,0,0.15)'; ctx.fill(); ctx.setLineDash([]);
          }
        }
      });
      ctx.globalAlpha = 1; ctx.setLineDash([]);
    }

    // ---- STATIONS ----
    if (stations.length > 0 && (showStations || showStationIds || showStationNames)) {
      const stZ = RAIL_HEIGHT / scale + 1;
      stations.forEach(st => {
        if (!st.hasCoords) return;
        const pos = toIso(st.x, st.y, stZ, p3d);
        const sz = Math.max(3, 5 / scale);
        const sc = STATION_COLORS[st.stationType] || '#00aaff';
        ctx.globalAlpha = 0.8; ctx.fillStyle = sc;
        if (st.equipType === 'ZFS_RIGHT' || st.equipType === 'ZFS_LEFT') {
          ctx.fillRect(pos.x - sz / 2, pos.y - sz / 2, sz, sz);
        } else if (st.equipType === 'UNIVERSAL') {
          ctx.beginPath(); ctx.arc(pos.x, pos.y, sz / 2, 0, Math.PI * 2); ctx.fill();
        } else {
          ctx.beginPath(); ctx.moveTo(pos.x, pos.y - sz / 2); ctx.lineTo(pos.x + sz / 2, pos.y); ctx.lineTo(pos.x, pos.y + sz / 2); ctx.lineTo(pos.x - sz / 2, pos.y); ctx.closePath(); ctx.fill();
        }
        if (showStationIds || showStationNames) {
          ctx.globalAlpha = 1;
          const fs = Math.max(8, 10 / scale), pad = 2 / scale;
          let oy = sz / 2 + 2 / scale;
          ctx.font = fs + 'px sans-serif';
          if (showStationIds) {
            const lbl = String(st.stationId), tw = ctx.measureText(lbl).width;
            ctx.fillStyle = 'rgba(0,0,0,0.7)'; ctx.fillRect(pos.x - tw / 2 - pad, pos.y + oy, tw + pad * 2, fs + pad * 2);
            ctx.fillStyle = '#ffff00'; ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillText(lbl, pos.x, pos.y + oy + pad);
            oy += fs + pad * 2 + 1 / scale;
          }
          if (showStationNames) {
            const lbl = st.stationName, tw = ctx.measureText(lbl).width;
            ctx.fillStyle = 'rgba(0,0,0,0.7)'; ctx.fillRect(pos.x - tw / 2 - pad, pos.y + oy, tw + pad * 2, fs + pad * 2);
            ctx.fillStyle = sc; ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillText(lbl, pos.x, pos.y + oy + pad);
          }
        }
      });
      ctx.globalAlpha = 1;
    }

    // ---- OHT VEHICLES ----
    const vehSize = Math.max(2.5, 4.5 / scale);

    // Selected vehicle paths
    let colorIdx = 0;
    selectedVehicles.forEach(vid => {
      const sv = vehicleDispRef.current[vid]; if (!sv) return;
      const path = sv.path || [], color = PATH_COLORS[colorIdx++ % PATH_COLORS.length];
      const pathZ = RAIL_HEIGHT / scale + 5;
      if (path.length > 0) {
        ctx.strokeStyle = color; ctx.lineWidth = 4 / scale; ctx.setLineDash([8 / scale, 4 / scale]);
        const si = toIso(sv.dispX, sv.dispY, pathZ, p3d);
        ctx.beginPath(); ctx.moveTo(si.x, si.y);
        path.forEach(nno => { const n = nm[nno]; if (n) { const ni = toIso(n.x, n.y, pathZ, p3d); ctx.lineTo(ni.x, ni.y); } });
        ctx.stroke(); ctx.setLineDash([]);
        ctx.fillStyle = color;
        path.forEach(nno => { const n = nm[nno]; if (n) { const ni = toIso(n.x, n.y, pathZ, p3d); ctx.beginPath(); ctx.arc(ni.x, ni.y, 4 / scale, 0, Math.PI * 2); ctx.fill(); } });
        const dn = nm[sv.destination];
        if (dn) {
          const di = toIso(dn.x, dn.y, pathZ, p3d);
          ctx.fillStyle = '#ff0066'; ctx.beginPath(); ctx.arc(di.x, di.y, 12 / scale, 0, Math.PI * 2); ctx.fill();
          ctx.strokeStyle = '#fff'; ctx.lineWidth = 2 / scale; ctx.stroke();
          ctx.fillStyle = '#fff'; ctx.font = `bold ${14 / scale}px sans-serif`; ctx.textAlign = 'center'; ctx.fillText(vid, di.x, di.y - 18 / scale);
        }
      }
      const oZ = RAIL_HEIGHT / scale + OHT_HEIGHT / scale;
      const si = toIso(sv.dispX, sv.dispY, oZ, p3d);
      ctx.strokeStyle = color; ctx.lineWidth = 3 / scale; ctx.beginPath();
      if (p3d) ctx.ellipse(si.x, si.y, vehSize + 8 / scale, (vehSize + 8 / scale) * 0.6, 0, 0, Math.PI * 2);
      else ctx.arc(sv.dispX, sv.dispY, vehSize + 5 / scale, 0, Math.PI * 2);
      ctx.stroke();
    });

    // Draw all vehicles
    Object.values(vehicleDispRef.current).forEach(v => {
      let color = '#00ff88';
      if (v.state === 7) color = '#ff0000';
      else if (v.state === 2) color = '#ff3366';
      else if (v.isLoaded === 1) color = '#ff9900';

      if (p3d) {
        // Pseudo-3D OHT box
        const oW = vehSize * 2.5, oH = vehSize * 1.5, oD = OHT_HEIGHT / scale;
        const baseZ = RAIL_HEIGHT / scale + oD * 0.3;
        // Shadow
        const shd = toIso(v.dispX + 3 / scale, v.dispY + 3 / scale, 0, p3d);
        ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.beginPath(); ctx.ellipse(shd.x, shd.y, oW * 0.7, oH * 0.4, 0, 0, Math.PI * 2); ctx.fill();
        // Connection rod
        const rt = toIso(v.dispX, v.dispY, RAIL_HEIGHT / scale, p3d);
        const ob = toIso(v.dispX, v.dispY, baseZ, p3d);
        ctx.strokeStyle = '#556677'; ctx.lineWidth = 3 / scale; ctx.beginPath(); ctx.moveTo(rt.x, rt.y); ctx.lineTo(ob.x, ob.y); ctx.stroke();
        // Top face
        const tFL = toIso(v.dispX - oW / 2, v.dispY + oH / 2, baseZ + oD, p3d);
        const tFR = toIso(v.dispX + oW / 2, v.dispY + oH / 2, baseZ + oD, p3d);
        const tBR = toIso(v.dispX + oW / 2, v.dispY - oH / 2, baseZ + oD, p3d);
        const tBL = toIso(v.dispX - oW / 2, v.dispY - oH / 2, baseZ + oD, p3d);
        ctx.fillStyle = adjustColor(color, 1.3);
        ctx.beginPath(); ctx.moveTo(tFL.x, tFL.y); ctx.lineTo(tFR.x, tFR.y); ctx.lineTo(tBR.x, tBR.y); ctx.lineTo(tBL.x, tBL.y); ctx.closePath(); ctx.fill();
        // Front face
        const fBL = toIso(v.dispX - oW / 2, v.dispY + oH / 2, baseZ, p3d);
        const fBR = toIso(v.dispX + oW / 2, v.dispY + oH / 2, baseZ, p3d);
        ctx.fillStyle = color;
        ctx.beginPath(); ctx.moveTo(tFL.x, tFL.y); ctx.lineTo(tFR.x, tFR.y); ctx.lineTo(fBR.x, fBR.y); ctx.lineTo(fBL.x, fBL.y); ctx.closePath(); ctx.fill();
        // Right face
        const rBR = toIso(v.dispX + oW / 2, v.dispY - oH / 2, baseZ, p3d);
        ctx.fillStyle = adjustColor(color, 0.6);
        ctx.beginPath(); ctx.moveTo(tFR.x, tFR.y); ctx.lineTo(tBR.x, tBR.y); ctx.lineTo(rBR.x, rBR.y); ctx.lineTo(fBR.x, fBR.y); ctx.closePath(); ctx.fill();
        // JAM blink
        if (v.state === 7) {
          const ba = 0.3 + 0.5 * Math.abs(Math.sin(Date.now() / 200));
          const gp = toIso(v.dispX, v.dispY, baseZ + oD / 2, p3d);
          ctx.fillStyle = `rgba(255,50,50,${ba})`; ctx.beginPath(); ctx.ellipse(gp.x, gp.y, oW * 0.8, oH * 0.5, 0, 0, Math.PI * 2); ctx.fill();
        }
        // Loaded cargo
        if (v.isLoaded === 1) {
          const cZ = baseZ + oD + 3 / scale;
          const ct = toIso(v.dispX - oW * 0.3, v.dispY + oH * 0.3, cZ + 5 / scale, p3d);
          const cb = toIso(v.dispX + oW * 0.3, v.dispY + oH * 0.3, cZ, p3d);
          ctx.fillStyle = '#ffffff';
          ctx.beginPath(); ctx.moveTo(ct.x, ct.y); ctx.lineTo(cb.x, ct.y); ctx.lineTo(cb.x, cb.y); ctx.lineTo(ct.x, cb.y); ctx.closePath(); ctx.fill();
        }
      } else {
        // 2D OHT with glow
        const vx = v.dispX, vy = v.dispY, time = Date.now();
        // Glow
        const gs = vehSize * 1.8;
        ctx.fillStyle = `rgba(${parseInt(color.substr(1, 2), 16)},${parseInt(color.substr(3, 2), 16)},${parseInt(color.substr(5, 2), 16)},0.15)`;
        ctx.beginPath(); ctx.arc(vx, vy, gs, 0, Math.PI * 2); ctx.fill();
        // Body gradient
        const bg = ctx.createRadialGradient(vx - vehSize * 0.3, vy - vehSize * 0.3, 0, vx, vy, vehSize * 1.2);
        bg.addColorStop(0, lightenColor(color, 60)); bg.addColorStop(0.3, lightenColor(color, 30)); bg.addColorStop(0.7, color); bg.addColorStop(1, darkenColor(color, 40));
        ctx.fillStyle = bg; ctx.beginPath(); ctx.arc(vx, vy, vehSize, 0, Math.PI * 2); ctx.fill();
        // Outline
        ctx.strokeStyle = 'rgba(255,255,255,0.5)'; ctx.lineWidth = 2 / scale; ctx.stroke();
        // JAM pulse
        if (v.state === 7) {
          const pp = Math.sin(time / 150) * 0.5 + 0.5;
          ctx.strokeStyle = `rgba(255,100,100,${0.5 + pp * 0.5})`; ctx.lineWidth = 3 / scale;
          ctx.beginPath(); ctx.arc(vx, vy, vehSize * 1.3, 0, Math.PI * 2); ctx.stroke();
        }
        // Loaded indicator
        if (v.isLoaded === 1) {
          ctx.fillStyle = 'rgba(255,255,255,0.8)'; ctx.beginPath(); ctx.arc(vx, vy, vehSize * 0.35, 0, Math.PI * 2); ctx.fill();
        }
      }
    });

    ctx.restore();

    // Zone heatmap overlay
    if (heatmapMode === 'zone') drawZoneHeatmapOverlay(ctx, hidZones, nm, zoneStatusMap, viewRef.current, scale, p3d);
    // Zone markers
    if (showZoneMarkers && heatmapMode !== 'zone') drawZoneMarkersOverlay(ctx, hidZones, nm, zoneStatusMap, viewRef.current, scale, p3d);
    // STK
    if (showSTK) drawSTKOverlay(ctx, stkList, stkExpanded, stkPlaceMode, stkDeleteMode, viewRef.current, scale, p3d, isWhite);

    // Zoom level (bottom-right is in sidebar)
  }, [layout, vehicles, theme, isPseudo3D, enableCurves, curveRadius, heatmapMode, showZones,
    showStations, showStationIds, showStationNames, showZoneMarkers, showSTK,
    stkPlaceMode, stkDeleteMode, stkExpanded, hidZones, stations, stkList,
    zoneStatusMap, edgeHeatmapData, selectedVehicles, selectedZoneId]);

  // ============================================================
  // Animation Loop
  // ============================================================
  useEffect(() => {
    const animate = () => {
      // Lerp vehicle positions
      const vd = vehicleDispRef.current;
      Object.values(vd).forEach(v => {
        v.dispX = v.dispX + (v.x - v.dispX) * 0.15;
        v.dispY = v.dispY + (v.y - v.dispY) * 0.15;
      });
      render();
      animRef.current = requestAnimationFrame(animate);
    };
    animRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animRef.current);
  }, [render]);

  // ============================================================
  // Mouse Handlers
  // ============================================================
  const handleMouseDown = useCallback((e) => {
    dragRef.current = { isDragging: true, lastX: e.clientX, lastY: e.clientY };
  }, []);

  const handleMouseMove = useCallback((e) => {
    if (dragRef.current.isDragging) {
      viewRef.current.offsetX += e.clientX - dragRef.current.lastX;
      viewRef.current.offsetY += e.clientY - dragRef.current.lastY;
      dragRef.current.lastX = e.clientX;
      dragRef.current.lastY = e.clientY;
    }
  }, []);

  const handleMouseUp = useCallback(() => { dragRef.current.isDragging = false; }, []);

  const handleWheel = useCallback((e) => {
    e.preventDefault();
    const rect = canvasRef.current.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    const zoom = e.deltaY < 0 ? 1.15 : 0.87;
    const v = viewRef.current;
    const ns = Math.max(0.02, Math.min(15, v.scale * zoom));
    v.offsetX = mx - (mx - v.offsetX) * (ns / v.scale);
    v.offsetY = my - (my - v.offsetY) * (ns / v.scale);
    v.scale = ns;
    // Auto toggles
    const zp = ns * 100;
    if (zp >= 55 && !zoneManualOffRef.current && !showZones) setShowZones(true);
    else if (zp < 55 && showZones) { setShowZones(false); zoneManualOffRef.current = false; }
    if (zp >= 50 && !showStationIds && !stationIdManualOffRef.current) setShowStationIds(true);
    else if (zp < 50 && showStationIds) { setShowStationIds(false); stationIdManualOffRef.current = false; }
  }, [showZones, showStationIds]);

  const handleDblClick = useCallback((e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const v = viewRef.current;
    const mx = (e.clientX - rect.left - v.offsetX) / v.scale;
    const my = (e.clientY - rect.top - v.offsetY) / v.scale;
    let clicked = null, minDist = 25 / v.scale;
    Object.values(vehicleDispRef.current).forEach(vh => {
      const d = isPseudo3D
        ? (() => { const p = toIso(vh.dispX, vh.dispY, (RAIL_HEIGHT + OHT_HEIGHT * 0.5) / v.scale, true); return Math.hypot(p.x - mx, p.y - my); })()
        : Math.hypot(vh.dispX - mx, vh.dispY - my);
      if (d < minDist) { minDist = d; clicked = vh.vehicleId; }
    });
    if (clicked) {
      setSelectedVehicles(prev => {
        const next = new Set(prev);
        if (next.has(clicked)) next.delete(clicked); else next.add(clicked);
        return next;
      });
    }
  }, [isPseudo3D]);

  const handleCanvasClick = useCallback(async (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const v = viewRef.current;
    const mx = (e.clientX - rect.left - v.offsetX) / v.scale;
    const my = (e.clientY - rect.top - v.offsetY) / v.scale;

    if (stkPlaceMode) {
      try {
        const data = await apiCall(`/api/stk/add?x=${mx.toFixed(1)}&y=${my.toFixed(1)}`, 'POST');
        if (data.status === 'ok') setStkList(prev => [...prev, data.stk]);
      } catch (err) { console.error('STK 추가 실패:', err); }
      return;
    }
    if (stkDeleteMode) {
      const hit = stkList.find(stk => {
        const sz = toIso(stk.x, stk.y, (RAIL_HEIGHT / v.scale + 5), isPseudo3D);
        return Math.abs(mx - sz.x) < 40 / v.scale && Math.abs(my - sz.y) < 14 / v.scale;
      });
      if (hit) {
        try {
          const data = await apiCall(`/api/stk/delete?stk_id=${encodeURIComponent(hit.stkId)}`, 'POST');
          if (data.status === 'ok') setStkList(prev => prev.filter(s => s.stkId !== hit.stkId));
        } catch (err) { console.error('STK 삭제 실패:', err); }
      }
      return;
    }
    // STK expand/collapse
    if (showSTK && stkList.length > 0) {
      stkList.forEach(stk => {
        const sz = toIso(stk.x, stk.y, (RAIL_HEIGHT / v.scale + 5), isPseudo3D);
        const isExp = stkExpanded[stk.stkId];
        const hw = (isExp ? 160 : 80) / v.scale / 2;
        const hh = (isExp ? 120 : 28) / v.scale / 2;
        if (Math.abs(mx - sz.x) < hw && Math.abs(my - sz.y) < hh) {
          setStkExpanded(prev => ({ ...prev, [stk.stkId]: !prev[stk.stkId] }));
        }
      });
    }
  }, [stkPlaceMode, stkDeleteMode, isPseudo3D, stkList, stkExpanded, showSTK]);

  // ============================================================
  // Action Handlers
  // ============================================================
  const handleSetVehicles = async (count) => {
    try {
      const data = await apiCall(`/api/set-vehicle-count?count=${count}`, 'POST');
      setVehicleMsg(data.status === 'ok' ? `${count}대로 변경` : data.message);
    } catch (e) { setVehicleMsg('Error: ' + e.message); }
  };

  const handleCreateDeadlock = async () => {
    try {
      const data = await apiCall('/api/create-deadlock', 'POST');
      setDeadlockMsg(data.status === 'ok' ? `노드 ${data.targetNode}에 ${data.movedVehicles}대 집중!` : data.message);
    } catch (e) { setDeadlockMsg('Error: ' + e.message); }
  };

  const handleResetInOut = async () => {
    try { await apiCall('/api/reset-inout', 'POST'); setDeadlockMsg('In/Out 카운터 초기화됨'); } catch (e) { setDeadlockMsg('Error: ' + e.message); }
  };

  const handleSwitchFab = async () => {
    try {
      const data = await apiCall(`/api/fab/switch?fab_name=${fabSelectValue}&layout_prefix=${layoutSelectValue}`, 'POST');
      if (data.status === 'ok') { setCurrentFab(fabSelectValue); setCurrentLayout(layoutSelectValue); }
    } catch (e) { console.error(e); }
  };

  // ============================================================
  // Simulation time
  // ============================================================
  const [simTime, setSimTime] = useState('00:00:00');
  useEffect(() => {
    const iv = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTimeRef.current) / 1000);
      const h = String(Math.floor(elapsed / 3600)).padStart(2, '0');
      const m = String(Math.floor((elapsed % 3600) / 60)).padStart(2, '0');
      const s = String(elapsed % 60).padStart(2, '0');
      setSimTime(`${h}:${m}:${s}`);
    }, 1000);
    return () => clearInterval(iv);
  }, []);

  const zoomPercent = Math.round((viewRef.current.scale || 1) * 100);

  // Available layouts for selected FAB
  const availableLayouts = useMemo(() => {
    if (!fabInfo?.fabs?.[fabSelectValue]) return [];
    return fabInfo.fabs[fabSelectValue].available_layouts || [];
  }, [fabInfo, fabSelectValue]);

  // ============================================================
  // RENDER JSX
  // ============================================================
  return (
    <div style={{ width: '100vw', height: '100vh', overflow: 'hidden', background: T.bg, color: T.text, fontFamily: "'Segoe UI', sans-serif" }}>
      {/* ======== HEADER ======== */}
      <div style={{ position: 'fixed', top: 0, left: 0, right: 0, height: 50, background: T.headerBg, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 20px', zIndex: 1000, boxShadow: '0 2px 10px rgba(0,0,0,0.5)' }}>
        <h1 style={{ fontSize: 18, color: T.accent, margin: 0 }}>
          SK Hynix OHT Simulator <span style={{ fontSize: 14, color: '#00ff88' }}>[{currentFab}/{currentLayout}]</span>
        </h1>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', fontSize: 12, flexWrap: 'wrap' }}>
          {/* FAB select */}
          <select value={fabSelectValue} onChange={e => { setFabSelectValue(e.target.value); }} style={{ padding: '4px 8px', background: T.inputBg, color: T.accent, border: `1px solid ${T.accent}`, borderRadius: 4, fontSize: 12 }}>
            {fabInfo && Object.keys(fabInfo.fabs || {}).map(f => <option key={f} value={f}>{f}</option>)}
          </select>
          <select value={layoutSelectValue} onChange={e => setLayoutSelectValue(e.target.value)} style={{ padding: '4px 8px', background: T.inputBg, color: '#ff9900', border: '1px solid #ff9900', borderRadius: 4, fontSize: 12 }}>
            {availableLayouts.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
          <button onClick={handleSwitchFab} style={{ padding: '4px 12px', background: '#00ff88', color: '#000', border: 'none', borderRadius: 4, cursor: 'pointer', fontWeight: 'bold', fontSize: 12 }}>적용</button>

          {/* Theme */}
          <button onClick={() => setTheme(t => t === 'dark' ? 'light' : 'dark')} style={{ padding: '4px 12px', background: theme === 'dark' ? '#fff' : '#333', color: theme === 'dark' ? '#000' : '#fff', border: '1px solid #888', borderRadius: 4, cursor: 'pointer', fontSize: 12 }}>
            {theme === 'dark' ? '☀ 화이트' : '🌙 다크'}
          </button>

          {/* 3D toggle */}
          <button onClick={() => setIsPseudo3D(v => !v)} style={{ padding: '4px 12px', background: isPseudo3D ? '#00d4ff' : '#ff9900', color: '#000', border: 'none', borderRadius: 4, cursor: 'pointer', fontSize: 12, fontWeight: 'bold' }}>
            3D {isPseudo3D ? 'ON' : 'OFF'}
          </button>

          {/* Curve toggle */}
          <button onClick={() => setEnableCurves(v => !v)} style={{ padding: '4px 12px', background: enableCurves ? '#00d4ff' : '#666', color: enableCurves ? '#000' : '#fff', border: 'none', borderRadius: 4, cursor: 'pointer', fontSize: 12, fontWeight: 'bold' }}>
            곡선 {enableCurves ? 'ON' : 'OFF'}
          </button>

          {/* Zone markers checkbox */}
          <label style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 11, color: '#ff6666', fontWeight: 'bold', cursor: 'pointer' }}>
            <input type="checkbox" checked={showZoneMarkers} onChange={e => setShowZoneMarkers(e.target.checked)} style={{ cursor: 'pointer', accentColor: '#ff3366' }} />Zone 마커
          </label>

          {/* STK checkbox */}
          <label style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 11, color: '#00ccff', fontWeight: 'bold', cursor: 'pointer' }}>
            <input type="checkbox" checked={showSTK} onChange={e => setShowSTK(e.target.checked)} style={{ cursor: 'pointer', accentColor: '#00ccff' }} />STK
          </label>

          {/* STK place/delete */}
          <button onClick={() => { setStkPlaceMode(v => !v); setStkDeleteMode(false); }} style={{ padding: '3px 8px', background: stkPlaceMode ? '#00ccff' : T.inputBg, color: stkPlaceMode ? '#000' : '#00ccff', border: '1px solid #00ccff', borderRadius: 4, cursor: 'pointer', fontSize: 11, fontWeight: 'bold' }}>+STK</button>
          <button onClick={() => { setStkDeleteMode(v => !v); setStkPlaceMode(false); }} style={{ padding: '3px 8px', background: stkDeleteMode ? '#ff4444' : T.inputBg, color: stkDeleteMode ? '#fff' : '#ff4444', border: '1px solid #ff4444', borderRadius: 4, cursor: 'pointer', fontSize: 11, fontWeight: 'bold' }}>-STK</button>

          {/* Heatmap */}
          <select value={heatmapMode} onChange={e => setHeatmapMode(e.target.value)} style={{ padding: '4px 8px', background: T.inputBg, color: '#ff6600', border: '1px solid #ff6600', borderRadius: 4, fontSize: 12 }}>
            <option value="off">히트맵 OFF</option>
            <option value="zone">Zone 히트맵</option>
            <option value="traffic">통과량</option>
            <option value="density">밀도</option>
            <option value="velocity">속도</option>
          </select>

          {/* Curve radius slider */}
          <input type="range" min={5} max={100} value={curveRadius} onChange={e => setCurveRadius(parseInt(e.target.value))} style={{ width: 60, cursor: 'pointer' }} title="곡률반경" />
          <span style={{ color: T.accent, fontSize: 11, minWidth: 28 }}>{curveRadius}</span>

          {/* Live indicator */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 10, height: 10, background: '#00ff88', borderRadius: '50%', animation: 'pulse 1s infinite' }} /> LIVE
          </div>
          <div>노드: <span style={{ color: T.accent, fontWeight: 'bold' }}>{layout?.nodes?.length?.toLocaleString() || '-'}</span></div>
          <div>OHT: <span style={{ color: T.accent, fontWeight: 'bold' }}>{stats.total}</span></div>
          <div>운행: <span style={{ color: T.accent, fontWeight: 'bold' }}>{stats.running}</span></div>
          <div>적재: <span style={{ color: T.accent, fontWeight: 'bold' }}>{stats.loaded}</span></div>
        </div>
      </div>

      {/* ======== LEFT SIDEBAR TOGGLE ======== */}
      <div onClick={() => setLeftOpen(v => !v)} style={{ position: 'fixed', top: 55, left: leftOpen ? 240 : 0, zIndex: 950, width: 24, height: 50, background: T.sidebarBg, border: `1px solid ${T.border}`, borderLeft: 'none', borderRadius: '0 8px 8px 0', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: T.accent, fontSize: 14, transition: 'left 0.3s' }}>
        {leftOpen ? '◀' : '▶'}
      </div>

      {/* ======== LEFT SIDEBAR ======== */}
      <div style={{ position: 'fixed', top: 50, left: 0, bottom: 0, width: 240, background: T.sidebarBg, padding: 15, borderRight: `1px solid ${T.border}`, zIndex: 900, overflowY: 'auto', transform: leftOpen ? 'translateX(0)' : 'translateX(-240px)', transition: 'transform 0.3s', fontSize: 12 }}>
        {/* OHT 대수 설정 */}
        <SidebarSection title="OHT 대수 설정" T={T}>
          <div style={{ display: 'flex', gap: 4 }}>
            <input type="number" min={1} max={2000} value={vehicleCount} onChange={e => setVehicleCount(parseInt(e.target.value) || 1)}
              onKeyPress={e => { if (e.key === 'Enter') handleSetVehicles(vehicleCount); }}
              style={{ flex: 1, padding: '5px 8px', background: T.inputBg, color: T.text, border: `1px solid ${T.border}`, borderRadius: 4, fontSize: 12 }} />
            <button onClick={() => handleSetVehicles(vehicleCount)} style={btnStyle('#00d4ff')}>적용</button>
            {[50, 100, 500].map(n => <button key={n} onClick={() => { setVehicleCount(n); handleSetVehicles(n); }} style={btnStyle('#333', '#fff')}>{n}</button>)}
          </div>
          {vehicleMsg && <div style={{ marginTop: 6, fontSize: 10, color: '#888' }}>{vehicleMsg}</div>}
        </SidebarSection>

        {/* 실시간 통계 */}
        <SidebarSection title="실시간 통계" T={T}>
          <StatRow label="총 OHT" value={stats.total} T={T} />
          <StatRow label="운행중" value={stats.running} T={T} />
          <StatRow label="적재중" value={stats.loaded} T={T} />
          <StatRow label="정지" value={stats.stopped} T={T} />
          <StatRow label="정체(JAM)" value={stats.jammed} T={T} color="#ff0000" />
        </SidebarSection>

        {/* 속도 정보 */}
        <SidebarSection title="속도 정보" T={T}>
          <StatRow label="평균 속도" value={`${velocityStats.avg} m/min`} T={T} />
          <StatRow label="최대 속도" value={`${velocityStats.max} m/min`} T={T} />
          <StatRow label="최소 속도" value={`${velocityStats.min} m/min`} T={T} />
          <StatRow label="절대속도" value={`${velocityStats.abs} %`} T={T} />
        </SidebarSection>

        {/* In/Out (데드락) */}
        <SidebarSection title="In/Out (데드락)" T={T}>
          <StatRow label="Total In" value={inOutStats.totalIn} T={T} />
          <StatRow label="Total Out" value={inOutStats.totalOut} T={T} />
          <StatRow label="In/Out 비율" value={inOutStats.ratio} T={T} />
          <StatRow label="위험 구간" value={inOutStats.deadlockRiskCount} T={T} color="#ff3366" />
          <div style={{ display: 'flex', gap: 4, marginTop: 6 }}>
            <button onClick={handleCreateDeadlock} style={btnStyle('#ff3366', '#fff')}>상황만들기</button>
            <button onClick={handleResetInOut} style={btnStyle('#555', '#fff')}>초기화</button>
          </div>
          {deadlockMsg && <div style={{ marginTop: 8, fontSize: 10, color: '#888' }}>{deadlockMsg}</div>}
        </SidebarSection>

        {/* HID Zone 현황 */}
        <SidebarSection title="HID Zone 현황" T={T}>
          <StatRow label="총 Zone" value={zoneStats.totalZones} T={T} />
          <StatRow label="정상" value={zoneStats.normalZones} T={T} color="#00ff88" />
          <StatRow label="주의" value={zoneStats.precautionZones} T={T} color="#ffaa00" />
          <StatRow label="포화" value={zoneStats.fullZones} T={T} color="#ff3366" />
          <StatRow label="전체 점유율" value={`${zoneStats.overallOccupancy} %`} T={T} />
          <button onClick={() => { setShowZones(v => { zoneManualOffRef.current = !v ? false : true; return !v; }); }}
            style={{ ...btnStyle(showZones ? '#00d4ff' : '#555', showZones ? '#000' : '#fff'), width: '100%', marginTop: 6 }}>
            Zone 표시 {showZones ? 'ON' : 'OFF'}
          </button>
          <div style={{ display: 'flex', gap: 4, marginTop: 6 }}>
            <button onClick={() => setShowStations(v => !v)} style={btnStyle(showStations ? '#00aaff' : '#555', showStations ? '#000' : '#fff', { flex: 1, fontSize: 9 })}>Station {showStations ? 'ON' : 'OFF'}</button>
            <button onClick={() => { setShowStationIds(v => { stationIdManualOffRef.current = !v ? false : true; return !v; }); }} style={btnStyle(showStationIds ? '#ffff00' : '#555', showStationIds ? '#000' : '#fff', { flex: 1, fontSize: 9 })}>ID {showStationIds ? 'ON' : 'OFF'}</button>
            <button onClick={() => setShowStationNames(v => !v)} style={btnStyle(showStationNames ? '#00aaff' : '#555', showStationNames ? '#000' : '#fff', { flex: 1, fontSize: 9 })}>이름 {showStationNames ? 'ON' : 'OFF'}</button>
          </div>
          {/* Zone alert list */}
          <div style={{ marginTop: 8, fontSize: 10, maxHeight: 60, overflowY: 'auto' }}>
            {fullZoneList.map(z => <div key={z.zoneId} style={{ color: '#ff3366' }}>Zone {z.zoneId}: {z.vehicleCount}/{z.vehicleMax}</div>)}
            {precautionZoneList.map(z => <div key={z.zoneId} style={{ color: '#ffaa00' }}>Zone {z.zoneId}: {z.vehicleCount}/{z.vehicleMax} ({z.occupancyRate}%)</div>)}
            {!fullZoneList.length && !precautionZoneList.length && <span style={{ color: '#888' }}>정상 운영 중</span>}
          </div>
        </SidebarSection>

        {/* JAM 현황 */}
        <SidebarSection title="정체(JAM) 현황" T={T}>
          <StatRow label="현재 JAM 차량" value={jamStats.jam_vehicle_count || 0} T={T} color="#ff0000" />
          <StatRow label="HIGH 위험" value={jamStats.high_risk_edges || 0} T={T} color="#ff3366" />
          <StatRow label="MEDIUM 위험" value={jamStats.medium_risk_edges || 0} T={T} color="#ffaa00" />
        </SidebarSection>

        {/* 시스템 정보 */}
        <SidebarSection title="시스템 정보" T={T}>
          <StatRow label="FAB ID" value="M14Q" T={T} />
          <StatRow label="차량 길이" value="1084mm" T={T} />
          <StatRow label="최대속도" value="300 m/min" T={T} />
          <StatRow label="거리단위" value="100mm" T={T} />
        </SidebarSection>

        {/* 범례 */}
        <SidebarSection title="범례" T={T}>
          <LegendDot color="#00ff88" label="운행중 (공차)" />
          <LegendDot color="#ff9900" label="운행중 (적재)" />
          <LegendDot color="#ff3366" label="정지" />
          <LegendDot color="#ff0000" label="정체 (JAM)" blink />
          {heatmapMode !== 'off' && (
            <div style={{ marginTop: 12, borderTop: `1px solid ${T.border}`, paddingTop: 10 }}>
              <div style={{ color: '#ff6600', fontWeight: 'bold', marginBottom: 6, fontSize: 11 }}>히트맵 범례</div>
              <div style={{ fontSize: 10, color: '#aaa' }}>
                {heatmapMode === 'zone' && 'HID Zone 주의/포화 구역'}
                {heatmapMode === 'traffic' && '레일 통과 횟수'}
                {heatmapMode === 'density' && '엣지 차량 밀도'}
                {heatmapMode === 'velocity' && '평균 속도 (느릴수록 빨강)'}
              </div>
              <div style={{ marginTop: 6, height: 12, borderRadius: 3, background: 'linear-gradient(90deg, #FFB400, #FF8800, #FF4400, #FF0000, #CC0000)' }} />
            </div>
          )}
        </SidebarSection>

        {/* 컨트롤 */}
        <SidebarSection title="컨트롤" T={T}>
          <StatRow label="줌" value={`${zoomPercent}%`} T={T} />
          <div style={{ fontSize: 11, color: '#888', marginTop: 8 }}>
            마우스 휠: 줌<br />드래그: 이동<br />더블클릭: 경로표시<br />호버: 상세정보
          </div>
        </SidebarSection>
      </div>

      {/* ======== RIGHT SIDEBAR TOGGLE ======== */}
      <div onClick={() => setRightOpen(v => !v)} style={{ position: 'fixed', top: 55, right: rightOpen ? 280 : 0, zIndex: 950, width: 24, height: 50, background: T.sidebarBg, border: `1px solid ${T.border}`, borderRight: 'none', borderRadius: '8px 0 0 8px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: T.accent, fontSize: 14, transition: 'right 0.3s' }}>
        {rightOpen ? '▶' : '◀'}
      </div>

      {/* ======== RIGHT SIDEBAR ======== */}
      <div style={{ position: 'fixed', top: 50, right: 0, bottom: 0, width: 280, background: T.sidebarBg, borderLeft: `1px solid ${T.border}`, zIndex: 900, overflowY: 'auto', transform: rightOpen ? 'translateX(0)' : 'translateX(280px)', transition: 'transform 0.3s', fontSize: 12 }}>
        {/* Tabs */}
        <div style={{ display: 'flex', borderBottom: `1px solid ${T.border}` }}>
          {['oht', 'zone'].map(tab => (
            <button key={tab} onClick={() => setRightTab(tab)}
              style={{ flex: 1, padding: '10px 0', background: rightTab === tab ? T.accent : 'transparent', color: rightTab === tab ? '#000' : T.text, border: 'none', cursor: 'pointer', fontWeight: 'bold', fontSize: 12 }}>
              {tab === 'oht' ? 'OHT 상태' : 'HID Zone'}
            </button>
          ))}
        </div>

        {/* OHT Tab */}
        {rightTab === 'oht' && (
          <div style={{ padding: 10 }}>
            <div style={{ display: 'flex', gap: 4, marginBottom: 8, flexWrap: 'wrap' }}>
              {['all', 'running', 'loaded', 'stopped', 'jam'].map(f => (
                <button key={f} onClick={() => setOhtFilter(f)}
                  style={{ padding: '4px 8px', background: ohtFilter === f ? T.accent : '#555', color: ohtFilter === f ? '#000' : '#fff', border: 'none', borderRadius: 4, cursor: 'pointer', fontSize: 10 }}>
                  {{ all: '전체', running: '운행', loaded: '적재', stopped: '정지', jam: 'JAM' }[f]}
                </button>
              ))}
            </div>
            <input placeholder="OHT ID 검색..." value={ohtSearch} onChange={e => setOhtSearch(e.target.value)}
              style={{ width: '100%', padding: '6px 8px', background: T.inputBg, color: T.text, border: `1px solid ${T.border}`, borderRadius: 4, fontSize: 11, marginBottom: 8 }} />
            <div style={{ maxHeight: 'calc(100vh - 250px)', overflowY: 'auto' }}>
              {Object.values(vehicles).filter(v => {
                if (ohtFilter !== 'all' && getOhtStateClass(v) !== ohtFilter) return false;
                if (ohtSearch && !v.vehicleId?.toLowerCase().includes(ohtSearch.toLowerCase())) return false;
                return true;
              }).sort((a, b) => (a.state === 7 ? 0 : 1) - (b.state === 7 ? 0 : 1) || (a.vehicleId || '').localeCompare(b.vehicleId || ''))
                .map(v => {
                  const sc = getOhtStateClass(v);
                  const colors = { running: '#00ff88', loaded: '#ff9900', stopped: '#ff3366', jam: '#ff0000', other: '#888' };
                  return (
                    <div key={v.vehicleId} onClick={() => setExpandedOhtId(prev => prev === v.vehicleId ? null : v.vehicleId)}
                      onDoubleClick={() => setSelectedVehicles(prev => { const n = new Set(prev); n.has(v.vehicleId) ? n.delete(v.vehicleId) : n.add(v.vehicleId); return n; })}
                      style={{ padding: '6px 8px', marginBottom: 4, background: T.sectionBg, borderRadius: 4, borderLeft: `3px solid ${colors[sc] || '#888'}`, cursor: 'pointer' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <span style={{ color: T.accent, fontWeight: 'bold' }}>{v.vehicleId}</span>
                        <span style={{ color: colors[sc], fontSize: 10 }}>{STATE_NAMES[v.state] || '?'}</span>
                      </div>
                      {expandedOhtId === v.vehicleId && (
                        <div style={{ marginTop: 4, fontSize: 10, color: '#aaa' }}>
                          <div>속도: {v.velocity} m/min | 적재: {v.isLoaded === 1 ? `O (${v.carrierId})` : 'X'}</div>
                          <div>번지: {v.currentNode} → {v.nextNode || '-'} | 목적지: {v.destination || '-'}</div>
                          <div>Zone: {v.hidZoneId >= 0 ? `HID ${v.hidZoneId}` : '-'} | {v.runCycleName} / {v.vhlCycleName}</div>
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* Zone Tab */}
        {rightTab === 'zone' && (
          <div style={{ padding: 10 }}>
            <div style={{ display: 'flex', gap: 4, marginBottom: 8, flexWrap: 'wrap' }}>
              {['all', 'full', 'precaution', 'normal'].map(f => (
                <button key={f} onClick={() => setZoneFilter(f)}
                  style={{ padding: '4px 8px', background: zoneFilter === f ? T.accent : '#555', color: zoneFilter === f ? '#000' : '#fff', border: 'none', borderRadius: 4, cursor: 'pointer', fontSize: 10 }}>
                  {{ all: '전체', full: '포화', precaution: '주의', normal: '정상' }[f]}
                </button>
              ))}
            </div>
            <input placeholder="Zone ID 검색..." value={zoneSearch} onChange={e => setZoneSearch(e.target.value)}
              style={{ width: '100%', padding: '6px 8px', background: T.inputBg, color: T.text, border: `1px solid ${T.border}`, borderRadius: 4, fontSize: 11, marginBottom: 8 }} />
            <div style={{ maxHeight: 'calc(100vh - 250px)', overflowY: 'auto' }}>
              {hidZones.filter(z => z?.zoneId > 0).filter(z => {
                if (zoneFilter !== 'all' && getZoneStateClass(z) !== zoneFilter) return false;
                if (zoneSearch && !String(z.zoneId).includes(zoneSearch) && !(z.fullName || '').toLowerCase().includes(zoneSearch.toLowerCase())) return false;
                return true;
              }).sort((a, b) => {
                const order = { full: 0, precaution: 1, normal: 2 };
                return (order[getZoneStateClass(a)] || 2) - (order[getZoneStateClass(b)] || 2);
              }).map(z => {
                const sc = getZoneStateClass(z);
                const colors = { full: '#ff3366', precaution: '#ffaa00', normal: '#00ff88' };
                return (
                  <div key={z.zoneId} onClick={() => setSelectedZoneId(prev => prev === z.zoneId ? null : z.zoneId)}
                    style={{ padding: '6px 8px', marginBottom: 4, background: selectedZoneId === z.zoneId ? adjustColor(colors[sc], 0.3) : T.sectionBg, borderRadius: 4, borderLeft: `3px solid ${colors[sc]}`, cursor: 'pointer' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: T.accent, fontWeight: 'bold' }}>HID {z.zoneId}</span>
                      <span style={{ color: colors[sc], fontSize: 10 }}>
                        {z.vehicleCount || 0}/{z.vehicleMax || 0} ({z.occupancyRate ? Math.round(z.occupancyRate) : 0}%)
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* ======== CANVAS ======== */}
      <div style={{ position: 'fixed', top: 50, left: leftOpen ? 240 : 0, right: rightOpen ? 280 : 0, bottom: 0, transition: 'left 0.3s, right 0.3s' }}>
        <canvas ref={canvasRef} style={{ display: 'block', width: '100%', height: '100%', cursor: stkPlaceMode ? 'crosshair' : stkDeleteMode ? 'not-allowed' : 'default' }}
          onMouseDown={handleMouseDown} onMouseMove={handleMouseMove} onMouseUp={handleMouseUp} onMouseLeave={handleMouseUp}
          onWheel={handleWheel} onDoubleClick={handleDblClick} onClick={handleCanvasClick} />
      </div>

      {/* ======== INFO PANEL ======== */}
      <div style={{ position: 'fixed', bottom: 20, left: '50%', transform: 'translateX(-50%)', background: 'rgba(0,0,0,0.7)', padding: '8px 16px', borderRadius: 8, border: `1px solid ${T.accent}`, zIndex: 500 }}>
        <div style={{ fontSize: 10, color: '#888' }}>시뮬레이션 시간</div>
        <div style={{ fontSize: 18, color: T.accent, fontWeight: 'bold', fontFamily: 'monospace' }}>{simTime}</div>
      </div>

      {/* ======== GLOBAL STYLES ======== */}
      <style>{`
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
        @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0.3; } }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: ${T.sectionBg}; }
        ::-webkit-scrollbar-thumb { background: #444; border-radius: 3px; }
      `}</style>
    </div>
  );
}

// ============================================================
// Sub-components
// ============================================================
function SidebarSection({ title, T, children }) {
  return (
    <div style={{ background: T.sectionBg, padding: 12, borderRadius: 8, marginBottom: 12 }}>
      <h3 style={{ color: T.accent, fontSize: 13, margin: '0 0 10px' }}>{title}</h3>
      {children}
    </div>
  );
}

function StatRow({ label, value, T, color }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: 12 }}>
      <span>{label}</span>
      <span style={{ color: color || T.valColor, fontWeight: 'bold' }}>{value}</span>
    </div>
  );
}

function LegendDot({ color, label, blink }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '2px 0', fontSize: 11 }}>
      <div style={{ width: 8, height: 8, background: color, borderRadius: '50%', animation: blink ? 'blink 0.5s infinite' : undefined }} />
      {label}
    </div>
  );
}

function btnStyle(bg, color = '#000', extra = {}) {
  return { padding: '6px 8px', background: bg, color, border: 'none', borderRadius: 4, cursor: 'pointer', fontSize: 11, fontWeight: 'bold', ...extra };
}

// ============================================================
// Helper draw functions (overlays drawn after ctx.restore)
// ============================================================
function draw3DRailHelper(ctx, fromX, fromY, toX, toY, railColor, scale, p3d) {
  const rH = RAIL_HEIGHT / scale;
  const dx = toX - fromX, dy = toY - fromY, len = Math.hypot(dx, dy);
  if (len < 0.1) return;
  const nx = (-dy / len) * (1.5 / scale), ny = (dx / len) * (1.5 / scale);
  const ft = toIso(fromX, fromY, rH, p3d), tt = toIso(toX, toY, rH, p3d);
  ctx.fillStyle = adjustColor(railColor, 1.4);
  ctx.beginPath();
  ctx.moveTo(ft.x + nx, ft.y + ny * ISO_SCALE_Y); ctx.lineTo(tt.x + nx, tt.y + ny * ISO_SCALE_Y);
  ctx.lineTo(tt.x - nx, tt.y - ny * ISO_SCALE_Y); ctx.lineTo(ft.x - nx, ft.y - ny * ISO_SCALE_Y);
  ctx.closePath(); ctx.fill();
  const fb = toIso(fromX, fromY, 0, p3d), tb = toIso(toX, toY, 0, p3d);
  ctx.fillStyle = adjustColor(railColor, 0.6);
  ctx.beginPath();
  ctx.moveTo(ft.x + nx, ft.y + ny * ISO_SCALE_Y); ctx.lineTo(tt.x + nx, tt.y + ny * ISO_SCALE_Y);
  ctx.lineTo(tb.x + nx, tb.y + ny * ISO_SCALE_Y); ctx.lineTo(fb.x + nx, fb.y + ny * ISO_SCALE_Y);
  ctx.closePath(); ctx.fill();
}

function drawHeatmapRails(ctx, layout, nodeMap, edgeHeatmapData, heatmapMode, scale, p3d) {
  if (!layout?.edges) return;
  let maxVal = 1;
  if (heatmapMode === 'traffic') Object.values(edgeHeatmapData).forEach(e => { if (e.p > maxVal) maxVal = e.p; });
  else if (heatmapMode === 'density') maxVal = 100;
  else if (heatmapMode === 'velocity') maxVal = 300;

  layout.edges.forEach(e => {
    const from = nodeMap[e.from], to = nodeMap[e.to];
    if (!from || !to) return;
    const key = e.from + '-' + e.to, data = edgeHeatmapData[key];
    let ratio = 0, hasData = false;
    if (data) {
      hasData = true;
      if (heatmapMode === 'traffic') ratio = data.p / maxVal;
      else if (heatmapMode === 'density') ratio = data.d / 100;
      else if (heatmapMode === 'velocity') ratio = data.v > 0 ? 1 - (data.v / maxVal) : 0;
    }
    const ec = hasData ? heatColor(ratio) : '#1a2a3a';
    if (p3d) { draw3DRailHelper(ctx, from.x, from.y, to.x, to.y, ec, scale, p3d); }
    else {
      ctx.strokeStyle = ec; ctx.lineWidth = hasData ? Math.max(2, 1.5 + ratio * 4) / scale : 1 / scale;
      ctx.globalAlpha = hasData ? 0.6 + ratio * 0.4 : 0.3;
      ctx.beginPath(); ctx.moveTo(from.x, from.y); ctx.lineTo(to.x, to.y); ctx.stroke();
      ctx.globalAlpha = 1;
    }
  });
}

function drawZoneHeatmapOverlay(ctx, hidZones, nodeMap, zoneStatusMap, view, scale, p3d) {
  ctx.save(); ctx.translate(view.offsetX, view.offsetY); ctx.scale(scale, scale);
  hidZones.forEach(zone => {
    const status = zoneStatusMap[zone.zoneId];
    if (!status || (status.status !== 'PRECAUTION' && status.status !== 'FULL')) return;
    let mnX = Infinity, mxX = -Infinity, mnY = Infinity, mxY = -Infinity;
    [...(zone.inLanes || []), ...(zone.outLanes || [])].forEach(l => {
      const f = nodeMap[l.from], t = nodeMap[l.to];
      if (f) { mnX = Math.min(mnX, f.x); mxX = Math.max(mxX, f.x); mnY = Math.min(mnY, f.y); mxY = Math.max(mxY, f.y); }
      if (t) { mnX = Math.min(mnX, t.x); mxX = Math.max(mxX, t.x); mnY = Math.min(mnY, t.y); mxY = Math.max(mxY, t.y); }
    });
    if (mnX === Infinity) return;
    mnX -= 25; mxX += 25; mnY -= 25; mxY += 25;
    const zZ = RAIL_HEIGHT / scale + 2;
    const tl = toIso(mnX, mnY, zZ, p3d), tr = toIso(mxX, mnY, zZ, p3d), br = toIso(mxX, mxY, zZ, p3d), bl = toIso(mnX, mxY, zZ, p3d);
    const isFull = status.status === 'FULL';
    const occ = status.occupancyRate;
    const fa = isFull ? 0.3 : 0.15;
    const clr = isFull ? `rgba(255,40,0,${fa})` : `rgba(255,150,0,${fa})`;
    ctx.fillStyle = clr;
    ctx.beginPath(); ctx.moveTo(tl.x, tl.y); ctx.lineTo(tr.x, tr.y); ctx.lineTo(br.x, br.y); ctx.lineTo(bl.x, bl.y); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = isFull ? 'rgba(255,40,0,0.6)' : 'rgba(255,150,0,0.4)';
    ctx.lineWidth = (isFull ? 2.5 : 1.5) / scale; ctx.setLineDash(isFull ? [] : [6 / scale, 3 / scale]); ctx.stroke(); ctx.setLineDash([]);
    // Label
    const cx = (mnX + mxX) / 2, cy = (mnY + mxY) / 2, lp = toIso(cx, cy, zZ, p3d);
    const fs = Math.max(8, 11 / scale);
    ctx.font = 'bold ' + fs + 'px sans-serif';
    const lbl = (isFull ? '⚠ ' : '') + 'HID ' + zone.zoneId + '  ' + Math.round(occ) + '%';
    const tw = ctx.measureText(lbl).width, pad = 3 / scale;
    ctx.fillStyle = isFull ? 'rgba(180,0,0,0.85)' : 'rgba(180,90,0,0.8)';
    ctx.fillRect(lp.x - tw / 2 - pad, lp.y - fs / 2 - pad, tw + pad * 2, fs + pad * 2);
    ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(lbl, lp.x, lp.y);
  });
  ctx.restore();
}

function drawZoneMarkersOverlay(ctx, hidZones, nodeMap, zoneStatusMap, view, scale, p3d) {
  ctx.save(); ctx.translate(view.offsetX, view.offsetY); ctx.scale(scale, scale);
  hidZones.forEach(zone => {
    const status = zoneStatusMap[zone.zoneId];
    if (!status) return;
    const isFull = status.status === 'FULL', isPrec = status.status === 'PRECAUTION';
    if (!isFull && !isPrec) return;
    let mnX = Infinity, mxX = -Infinity, mnY = Infinity, mxY = -Infinity;
    [...(zone.inLanes || []), ...(zone.outLanes || [])].forEach(l => {
      const f = nodeMap[l.from], t = nodeMap[l.to];
      if (f) { mnX = Math.min(mnX, f.x); mxX = Math.max(mxX, f.x); mnY = Math.min(mnY, f.y); mxY = Math.max(mxY, f.y); }
      if (t) { mnX = Math.min(mnX, t.x); mxX = Math.max(mxX, t.x); mnY = Math.min(mnY, t.y); mxY = Math.max(mxY, t.y); }
    });
    if (mnX === Infinity) return;
    mnX -= 30; mxX += 30; mnY -= 30; mxY += 30;
    const zZ = RAIL_HEIGHT / scale + 3;
    const tl = toIso(mnX, mnY, zZ, p3d), tr = toIso(mxX, mnY, zZ, p3d), br = toIso(mxX, mxY, zZ, p3d), bl = toIso(mnX, mxY, zZ, p3d);
    ctx.strokeStyle = isFull ? '#ff2222' : '#ff8800';
    ctx.lineWidth = (isFull ? 3 : 2) / scale;
    ctx.globalAlpha = isFull ? 0.9 : 0.7;
    ctx.setLineDash(isFull ? [] : [8 / scale, 4 / scale]);
    ctx.beginPath(); ctx.moveTo(tl.x, tl.y); ctx.lineTo(tr.x, tr.y); ctx.lineTo(br.x, br.y); ctx.lineTo(bl.x, bl.y); ctx.closePath(); ctx.stroke();
    ctx.fillStyle = isFull ? 'rgba(255,34,34,0.12)' : 'rgba(255,136,0,0.08)'; ctx.globalAlpha = 1; ctx.fill(); ctx.setLineDash([]);
    // Label
    const cx = (mnX + mxX) / 2, cy = (mnY + mxY) / 2, lp = toIso(cx, cy, zZ, p3d);
    const fs = Math.max(9, 12 / scale);
    ctx.font = 'bold ' + fs + 'px sans-serif';
    const occ = status.occupancyRate;
    const lbl = (isFull ? '⚠ ' : '') + 'HID ' + zone.zoneId + ' ' + Math.round(occ) + '%';
    const tw = ctx.measureText(lbl).width, pad = 4 / scale;
    ctx.fillStyle = isFull ? 'rgba(200,0,0,0.85)' : 'rgba(180,100,0,0.8)';
    ctx.fillRect(lp.x - tw / 2 - pad, lp.y - fs / 2 - pad, tw + pad * 2, fs + pad * 2);
    ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(lbl, lp.x, lp.y);
    ctx.globalAlpha = 1;
  });
  ctx.restore();
}

function drawSTKOverlay(ctx, stkList, stkExpanded, stkPlaceMode, stkDeleteMode, view, scale, p3d, isWhite) {
  if (!stkList.length) return;
  ctx.save(); ctx.translate(view.offsetX, view.offsetY); ctx.scale(scale, scale);
  stkList.forEach(stk => {
    const sZ = RAIL_HEIGHT / scale + 5;
    const pos = toIso(stk.x, stk.y, sZ, p3d);
    let sc;
    switch (stk.status) { case 'RUNNING': sc = '#00cc44'; break; case 'STOP': sc = '#ff4444'; break; case 'ERROR': sc = '#ff0000'; break; case 'MAINT': sc = '#ffaa00'; break; default: sc = '#888'; }
    const isExp = stkExpanded[stk.stkId];
    if (!isExp) {
      const iW = Math.max(60, 80 / scale), iH = Math.max(22, 28 / scale), fs = Math.max(7, 9 / scale);
      ctx.fillStyle = isWhite ? 'rgba(60,60,80,0.9)' : 'rgba(30,30,50,0.92)';
      ctx.strokeStyle = sc; ctx.lineWidth = 1.5 / scale;
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(pos.x - iW / 2, pos.y - iH / 2, iW, iH, 3 / scale);
      else { ctx.rect(pos.x - iW / 2, pos.y - iH / 2, iW, iH); }
      ctx.fill(); ctx.stroke();
      ctx.fillStyle = sc; ctx.beginPath(); ctx.arc(pos.x - iW / 2 + 8 / scale, pos.y, 3 / scale, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.font = 'bold ' + fs + 'px sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(stk.stkId, pos.x - iW / 2 + 15 / scale, pos.y);
      // Mini bar
      const bx = pos.x + iW / 2 - 20 / scale, by = pos.y - 4 / scale, bw = 15 / scale, bh = 8 / scale;
      const usage = stk.totalSlots > 0 ? stk.usedSlots / stk.totalSlots : 0;
      ctx.fillStyle = '#333'; ctx.fillRect(bx, by, bw, bh);
      ctx.fillStyle = usage > 0.8 ? '#ff4444' : usage > 0.5 ? '#ffaa00' : '#00cc44';
      ctx.fillRect(bx, by, bw * usage, bh);
    } else {
      // Expanded panel
      const pW = Math.max(120, 160 / scale), fs = Math.max(7, 9 / scale), hH = Math.max(18, 22 / scale);
      const sAH = Math.max(40, 55 / scale), iH = Math.max(30, 40 / scale), pH = hH + sAH + iH;
      const pX = pos.x - pW / 2, pY = pos.y - pH / 2;
      ctx.fillStyle = isWhite ? 'rgba(70,70,90,0.95)' : 'rgba(25,25,45,0.95)';
      ctx.strokeStyle = sc; ctx.lineWidth = 2 / scale;
      ctx.beginPath(); ctx.rect(pX, pY, pW, pH); ctx.fill(); ctx.stroke();
      // Header
      ctx.fillStyle = sc; ctx.beginPath(); ctx.arc(pX + 10 / scale, pY + hH / 2, 3.5 / scale, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.font = 'bold ' + fs + 'px sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(stk.stkId, pX + 18 / scale, pY + hH / 2);
      // Slot grid
      const cols = 6, rows = Math.ceil((stk.totalSlots || 12) / cols);
      const gX = pX + 5 / scale, gY = pY + hH + 3 / scale, gW = pW - 10 / scale, gH = sAH - 6 / scale;
      const cW = gW / cols, cH = gH / Math.max(rows, 1), cp = 1 / scale;
      for (let i = 0; i < (stk.totalSlots || 12); i++) {
        const col = i % cols, row = Math.floor(i / cols);
        ctx.fillStyle = i < (stk.usedSlots || 0) ? '#cc8800' : 'rgba(0,180,80,0.3)';
        ctx.fillRect(gX + col * cW + cp, gY + row * cH + cp, cW - cp * 2, cH - cp * 2);
      }
      // Info
      const infoY = pY + hH + sAH + 2 / scale;
      ctx.font = (fs * 0.9) + 'px sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'top';
      ctx.fillStyle = '#aaa'; ctx.fillText('슬롯:', pX + 5 / scale, infoY);
      const ur = stk.usageRate || 0;
      ctx.fillStyle = ur > 80 ? '#ff4444' : ur > 50 ? '#ffaa00' : '#00cc44';
      ctx.fillText(`${stk.usedSlots || 0}/${stk.totalSlots || 0} (${Math.round(ur)}%)`, pX + 28 / scale, infoY);
    }
  });

  // Mode overlay banners
  if (stkPlaceMode || stkDeleteMode) {
    ctx.restore();
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0);
    const canvas = ctx.canvas;
    ctx.fillStyle = stkPlaceMode ? 'rgba(0,204,255,0.15)' : 'rgba(255,68,68,0.15)';
    ctx.fillRect(0, canvas.height - 40, canvas.width, 40);
    ctx.fillStyle = stkPlaceMode ? '#00ccff' : '#ff4444';
    ctx.font = 'bold 14px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(
      stkPlaceMode ? '🔧 STK 배치 모드: 맵 클릭으로 추가 | +STK 다시 눌러 종료' : '🗑️ STK 삭제 모드: STK 클릭으로 삭제 | -STK 다시 눌러 종료',
      canvas.width / 2, canvas.height - 20
    );
    ctx.restore();
    return;
  }

  ctx.restore();
}
