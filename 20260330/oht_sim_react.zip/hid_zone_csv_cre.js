/**
 * hid_zone_csv_cre.js - layout.xml에서 HID Zone 데이터 JSON 생성
 *
 * Python hid_zone_csv_cre.py의 JavaScript/React 마이그레이션
 *
 * 사용법:
 *   import { createHidZoneData, parseFromFile } from './hid_zone_csv_cre';
 *
 *   // XML 문자열에서 직접 파싱
 *   const result = createHidZoneData(xmlContent, 'M14 Project Ph-1');
 *
 *   // File input에서 파싱
 *   const result = await parseFromFile(file, 'M14 Project');
 *
 * 출력 형식:
 *   {
 *     zones: [{
 *       Zone_ID, HID_No, Bay_Zone, Sub_Region, Full_Name, Territory, Type,
 *       IN_Count, OUT_Count, IN_Lanes, OUT_Lanes, Vehicle_Max, Vehicle_Precaution,
 *       Project, ZCU, HID_Type, HID_ID, Zone_ID2, Addr_No, Station_No
 *     }, ...],
 *     addresses: { addr_no: { x, y, stations: [] } },
 *     stations: { stn_no: { port_id, type } },
 *     mcpZones: { zone_id: { mcp_id, zone_id, vehicle_max, ... } },
 *     meta: { zoneCount, rowCount, parseTime }
 *   }
 */

// ============================================================
// 안전한 정수 변환
// ============================================================
function safeInt(value, defaultVal = 0) {
  const n = parseInt(value, 10);
  return isNaN(n) ? defaultVal : n;
}

// ============================================================
// Address/Station 파싱 (DOMParser 사용 - 브라우저 호환)
// ============================================================
export function parseAddressesAndStations(xmlContent) {
  console.log('Address/Station 파싱 중...');
  const startTime = performance.now();

  const addresses = {};
  const stations = {};

  let currentAddr = null;
  let currentAddrNo = null;
  let currentStation = null;
  let currentStationNo = null;
  let currentNextAddr = false;
  let addrData = {};
  let stationData = {};
  let count = 0;

  const lines = xmlContent.split('\n');
  const total = lines.length;

  for (let i = 0; i < total; i++) {
    if (i % 500000 === 0 && i > 0) {
      console.log(`  ${i.toLocaleString()}/${total.toLocaleString()} (${Math.floor(i * 100 / total)}%)`);
    }

    const line = lines[i].trim();

    // ---- group 시작 ----
    if (line.includes('<group ')) {
      const nameMatch = line.match(/name="([^"]+)"/);
      const clsMatch = line.match(/class="([^"]+)"/);
      const name = nameMatch ? nameMatch[1] : '';
      const cls = clsMatch ? clsMatch[1] : '';

      // Address 그룹 (NextAddr 제외)
      if (name.includes('Addr') && cls.includes('address.Addr') && !name.includes('NextAddr')) {
        const m = name.match(/Addr(\d+)/);
        if (m) {
          currentAddrNo = parseInt(m[1], 10);
          addrData = { x: 0, y: 0, stations: [] };
          currentAddr = true;
        }
        continue;
      }

      // Station 그룹
      if (name.includes('Station') && cls.includes('Station')) {
        const m = name.match(/Station(\d+)/);
        if (m) {
          currentStationNo = parseInt(m[1], 10);
          stationData = { port_id: '', type: 0 };
          currentStation = true;
        }
        continue;
      }

      // NextAddr 그룹
      if (name.includes('NextAddr') && cls.includes('NextAddr')) {
        currentNextAddr = true;
        continue;
      }
    }

    // ---- param 파싱 ----
    if (line.includes('<param ') && line.includes('key="') && line.includes('value="')) {
      const keyMatch = line.match(/key="([^"]+)"/);
      const valueMatch = line.match(/value="([^"]*)"/);
      if (!keyMatch || !valueMatch) continue;

      const key = keyMatch[1];
      const value = valueMatch[1];

      if (currentAddr && !currentStation && !currentNextAddr) {
        if (key === 'draw-x') addrData.x = parseFloat(value) || 0;
        else if (key === 'draw-y') addrData.y = parseFloat(value) || 0;
      } else if (currentStation) {
        if (key === 'port-id') stationData.port_id = value;
        else if (key === 'type') stationData.type = safeInt(value, 0);
      }
    }

    // ---- group 종료 ----
    if (line.includes('</group>')) {
      const nameMatch = line.match(/name="([^"]+)"/);
      // group 종료 태그에는 name이 없으므로 상태 기반 처리

      if (currentNextAddr) {
        currentNextAddr = false;
        continue;
      }

      if (currentStation) {
        if (currentStationNo) {
          stations[currentStationNo] = { ...stationData };
          if (currentAddrNo) {
            addrData.stations.push(currentStationNo);
          }
        }
        currentStation = false;
        currentStationNo = null;
        continue;
      }

      if (currentAddr) {
        if (currentAddrNo !== null) {
          addresses[currentAddrNo] = { ...addrData };
          count++;
          if (count % 5000 === 0) console.log(`  ${count.toLocaleString()} addresses...`);
        }
        currentAddr = false;
        currentAddrNo = null;
        continue;
      }
    }
  }

  const elapsed = Math.round(performance.now() - startTime);
  console.log(`  완료: ${Object.keys(addresses).length.toLocaleString()} addresses, ${Object.keys(stations).length.toLocaleString()} stations (${elapsed}ms)`);
  return { addresses, stations };
}

// ============================================================
// McpZone 파싱 (라인 단위 - Python과 동일 로직)
// ============================================================
export function parseMcpZones(xmlContent) {
  console.log('McpZone 파싱 중...');

  const mcpZones = {};

  let currentMcpZone = null;
  let currentMcpId = null;
  let currentZoneId = null;
  let currentZoneParams = {};
  let currentEntries = [];
  let currentExits = [];
  let currentZcu = '';

  let inEntry = false;
  let inExit = false;
  let entryStart = null;
  let entryEnd = null;
  let entryZcu = '';
  let exitStart = null;
  let exitEnd = null;
  let zoneDepth = 0;

  const lines = xmlContent.split('\n');
  const total = lines.length;

  for (let i = 0; i < total; i++) {
    if (i % 500000 === 0 && i > 0) {
      console.log(`  ${i.toLocaleString()}/${total.toLocaleString()} (${Math.floor(i * 100 / total)}%)`);
    }

    const line = lines[i].trim();

    // McpZone 그룹 시작
    if (line.includes('<group name="McpZone') && line.includes('mcpzone.McpZone"')) {
      // 이전 zone 저장
      if (currentMcpZone !== null && currentZoneId !== null) {
        mcpZones[currentZoneId] = {
          mcp_id: currentMcpId,
          zone_id: currentZoneId,
          vehicle_max: safeInt(currentZoneParams['vehicle-max'], 0),
          vehicle_precaution: safeInt(currentZoneParams['vehicle-precaution'], 0),
          type: safeInt(currentZoneParams.type, 0),
          entries: [...currentEntries],
          exits: [...currentExits],
          zcu: currentZcu
        };
      }

      const match = line.match(/McpZone(\d+)/);
      currentMcpId = match ? parseInt(match[1], 10) : null;
      currentMcpZone = true;
      currentZoneId = null;
      currentZoneParams = {};
      currentEntries = [];
      currentExits = [];
      currentZcu = '';
      inEntry = false;
      inExit = false;
      zoneDepth = 1;
      continue;
    }

    if (currentMcpZone === null) continue;

    // Entry 그룹 시작
    if (line.includes('<group name="Entry') && line.includes('mcpzone.Entry"')) {
      inEntry = true;
      entryStart = null;
      entryEnd = null;
      entryZcu = '';
      zoneDepth++;
      continue;
    }

    // Exit 그룹 시작
    if (line.includes('<group name="Exit') && line.includes('mcpzone.Exit"')) {
      inExit = true;
      exitStart = null;
      exitEnd = null;
      zoneDepth++;
      continue;
    }

    // CutLane 그룹 시작
    if (line.includes('<group name="CutLane') && line.includes('mcpzone.CutLane"')) {
      zoneDepth++;
      continue;
    }

    // 다른 그룹 시작
    if (line.includes('<group ') && line.includes('>') && !line.includes('/>')) {
      zoneDepth++;
      continue;
    }

    // 파라미터 파싱
    if (line.includes('<param ') && line.includes('key="') && line.includes('value="')) {
      const keyMatch = line.match(/key="([^"]+)"/);
      const valueMatch = line.match(/value="([^"]*)"/);

      if (keyMatch && valueMatch) {
        const key = keyMatch[1];
        const value = valueMatch[1];

        if (inEntry) {
          if (key === 'start') entryStart = safeInt(value);
          else if (key === 'end') entryEnd = safeInt(value);
          else if (key === 'stop-zcu') entryZcu = value;
        } else if (inExit) {
          if (key === 'start') exitStart = safeInt(value);
          else if (key === 'end') exitEnd = safeInt(value);
        } else if (zoneDepth === 1) {
          if (key === 'id') currentZoneId = safeInt(value);
          else currentZoneParams[key] = value;
        }
      }
    }

    // 그룹 종료
    if (line.includes('</group>')) {
      if (inEntry) {
        if (entryStart !== null && entryEnd !== null) {
          currentEntries.push([entryStart, entryEnd]);
        }
        if (entryZcu && !currentZcu) currentZcu = entryZcu;
        inEntry = false;
        zoneDepth--;
        continue;
      }

      if (inExit) {
        if (exitStart !== null && exitEnd !== null) {
          currentExits.push([exitStart, exitEnd]);
        }
        inExit = false;
        zoneDepth--;
        continue;
      }

      zoneDepth--;

      // McpZone 그룹 종료
      if (zoneDepth === 0) {
        if (currentZoneId !== null) {
          mcpZones[currentZoneId] = {
            mcp_id: currentMcpId,
            zone_id: currentZoneId,
            vehicle_max: safeInt(currentZoneParams['vehicle-max'], 0),
            vehicle_precaution: safeInt(currentZoneParams['vehicle-precaution'], 0),
            type: safeInt(currentZoneParams.type, 0),
            entries: [...currentEntries],
            exits: [...currentExits],
            zcu: currentZcu
          };
        }
        currentMcpZone = null;
      }
    }
  }

  console.log(`  완료: ${Object.keys(mcpZones).length.toLocaleString()} zones`);
  return mcpZones;
}

// ============================================================
// Address → Zone 매핑 생성
// ============================================================
export function buildAddrToZoneMapping(mcpZones) {
  console.log('Address ↔ Zone 매핑 생성 중...');
  const addrToZone = {};

  for (const [zoneId, zoneData] of Object.entries(mcpZones)) {
    const mcpId = zoneData.mcp_id;

    for (const [start, end] of (zoneData.entries || [])) {
      addrToZone[start] = { zone_id: parseInt(zoneId), mcp_id: mcpId };
      addrToZone[end] = { zone_id: parseInt(zoneId), mcp_id: mcpId };
    }
    for (const [start, end] of (zoneData.exits || [])) {
      addrToZone[start] = { zone_id: parseInt(zoneId), mcp_id: mcpId };
      addrToZone[end] = { zone_id: parseInt(zoneId), mcp_id: mcpId };
    }
  }

  console.log(`  ${Object.keys(addrToZone).length.toLocaleString()}개 주소 매핑됨`);
  return addrToZone;
}

// ============================================================
// Zone → HID 매핑 생성
// ============================================================
export function buildZoneHidMapping(addresses, stations, addrToZone) {
  console.log('Zone ↔ HID 매핑 생성 중...');
  const zoneHidMap = {};

  for (const [addrNoStr, addrData] of Object.entries(addresses)) {
    const addrNo = parseInt(addrNoStr, 10);
    if (!(addrNo in addrToZone)) continue;

    const zoneInfo = addrToZone[addrNo];
    const zoneId = zoneInfo.zone_id;

    for (const stnNo of (addrData.stations || [])) {
      if (!(stnNo in stations)) continue;
      const hidId = stations[stnNo].port_id;
      if (!hidId) continue;

      if (!zoneHidMap[zoneId]) zoneHidMap[zoneId] = [];
      zoneHidMap[zoneId].push({
        HID_ID: hidId,
        Addr_No: String(addrNo),
        Station_No: String(stnNo)
      });
    }
  }

  const totalHids = Object.values(zoneHidMap).reduce((sum, v) => sum + v.length, 0);
  console.log(`  ${Object.keys(zoneHidMap).length.toLocaleString()}개 Zone, ${totalHids.toLocaleString()}개 HID 매핑됨`);
  return zoneHidMap;
}

// ============================================================
// Bay Zone 추정
// ============================================================
function deriveBayZone(zoneNo) {
  const bayMapping = { 1: 'B01', 2: 'B01', 3: 'B02', 4: 'B03', 5: 'B04', 6: 'B05', 7: 'B05', 8: 'B06', 9: 'B06' };
  if (zoneNo in bayMapping) return bayMapping[zoneNo];
  const bayNum = Math.floor(zoneNo / 10) + 1;
  return `B${String(bayNum).padStart(2, '0')}`;
}

// ============================================================
// HID Zone 데이터 생성 (JSON rows)
// ============================================================
export function generateHidZoneRows(mcpZones, zoneHidMap, projectName = 'M14 Project Ph-1') {
  console.log('HID Zone 데이터 생성 중...');

  const rows = [];
  const sortedZoneIds = Object.keys(mcpZones).map(Number).sort((a, b) => a - b);

  for (const zoneId of sortedZoneIds) {
    const zoneData = mcpZones[zoneId];
    const entries = zoneData.entries || [];
    const exits = zoneData.exits || [];

    const inLanes = entries.map(e => `${e[0]}→${e[1]}`).join('; ');
    const outLanes = exits.map(e => `${e[0]}→${e[1]}`).join('; ');
    const zcu = zoneData.zcu || '';
    const bayZone = deriveBayZone(zoneId);
    const subRegion = ((zoneId - 1) % 2) + 1;

    const hidTypeMap = { 1: 'HID4', 2: 'HID3', 3: 'HID2' };
    const hidType = hidTypeMap[zoneData.type] || 'HID4';

    const hidList = zoneHidMap[zoneId] || [];

    const baseRow = {
      Zone_ID: zoneId,
      HID_No: `HID-OHT-${String(zoneId).padStart(3, '0')}`,
      Bay_Zone: bayZone,
      Sub_Region: subRegion,
      Full_Name: `HID-${bayZone}-${subRegion}(${String(zoneId).padStart(3, '0')})`,
      Territory: 1,
      Type: 'HID',
      IN_Count: entries.length,
      OUT_Count: exits.length,
      IN_Lanes: inLanes,
      OUT_Lanes: outLanes,
      Vehicle_Max: zoneData.vehicle_max || 0,
      Vehicle_Precaution: zoneData.vehicle_precaution || 0,
      Project: projectName,
      ZCU: zcu,
      HID_Type: hidType
    };

    if (hidList.length > 0) {
      for (const hid of hidList) {
        rows.push({
          ...baseRow,
          HID_ID: hid.HID_ID,
          Zone_ID2: zoneId,
          Addr_No: hid.Addr_No,
          Station_No: hid.Station_No
        });
      }
    } else {
      rows.push({
        ...baseRow,
        HID_ID: '',
        Zone_ID2: '',
        Addr_No: '',
        Station_No: ''
      });
    }
  }

  console.log(`  완료: ${rows.length.toLocaleString()}개 행`);
  return rows;
}

// ============================================================
// CSV 문자열 생성 (utf-8-sig BOM 포함)
// ============================================================
export function generateCsvString(rows) {
  const headers = [
    'Zone_ID', 'HID_No', 'Bay_Zone', 'Sub_Region', 'Full_Name',
    'Territory', 'Type', 'IN_Count', 'OUT_Count', 'IN_Lanes', 'OUT_Lanes',
    'Vehicle_Max', 'Vehicle_Precaution', 'Project', 'ZCU', 'HID_Type',
    'HID_ID', 'Zone_ID2', 'Addr_No', 'Station_No'
  ];

  const csvLines = [headers.join(',')];
  for (const row of rows) {
    const values = headers.map(h => {
      const val = String(row[h] ?? '');
      return val.includes(',') || val.includes('"') || val.includes('\n')
        ? `"${val.replace(/"/g, '""')}"` : val;
    });
    csvLines.push(values.join(','));
  }

  // UTF-8 BOM
  return '\uFEFF' + csvLines.join('\n');
}

// ============================================================
// 메인: XML 내용에서 전체 HID Zone 데이터 생성
// ============================================================
export function createHidZoneData(xmlContent, projectName = 'M14 Project Ph-1') {
  console.log('============================================================');
  console.log('HID Zone 데이터 생성');
  console.log('============================================================');

  const startTime = performance.now();

  // 1. Address/Station 파싱
  const { addresses, stations } = parseAddressesAndStations(xmlContent);

  // 2. McpZone 파싱
  const mcpZones = parseMcpZones(xmlContent);

  // 3. Address → Zone 매핑
  const addrToZone = buildAddrToZoneMapping(mcpZones);

  // 4. Zone → HID 매핑
  const zoneHidMap = buildZoneHidMapping(addresses, stations, addrToZone);

  // 5. 행 생성
  const rows = generateHidZoneRows(mcpZones, zoneHidMap, projectName);

  const parseTime = Math.round(performance.now() - startTime);
  console.log(`총 처리 시간: ${parseTime}ms`);
  console.log('============================================================');

  return {
    zones: rows,
    addresses,
    stations,
    mcpZones,
    addrToZone,
    zoneHidMap,
    meta: {
      zoneCount: Object.keys(mcpZones).length,
      rowCount: rows.length,
      addressCount: Object.keys(addresses).length,
      stationCount: Object.keys(stations).length,
      parseTime
    }
  };
}

// ============================================================
// 브라우저용: File 객체에서 파싱
// ============================================================
export async function parseFromFile(file, projectName = 'M14 Project') {
  const name = file.name.toLowerCase();

  let xmlContent;

  if (name.endsWith('.zip')) {
    let JSZip;
    try {
      JSZip = (await import('jszip')).default;
    } catch {
      throw new Error('JSZip 라이브러리가 필요합니다: npm install jszip');
    }

    const arrayBuffer = await file.arrayBuffer();
    const zip = await JSZip.loadAsync(arrayBuffer);

    let xmlFile = null;
    for (const fn of Object.keys(zip.files)) {
      const lower = fn.toLowerCase();
      if (lower === 'layout/layout.xml') { xmlFile = fn; break; }
      if (lower === 'layout.xml' && !xmlFile) xmlFile = fn;
      if (lower.endsWith('.xml') && lower.includes('layout') && !xmlFile) xmlFile = fn;
    }

    if (!xmlFile) throw new Error('ZIP 내에 layout.xml이 없습니다');
    xmlContent = await zip.file(xmlFile).async('string');
  } else if (name.endsWith('.xml')) {
    xmlContent = await file.text();
  } else {
    throw new Error(`지원하지 않는 파일 형식: ${name}`);
  }

  return createHidZoneData(xmlContent, projectName);
}

// ============================================================
// FAB 경로 헬퍼
// ============================================================
export function getFabPaths(baseDir, fabName, layoutPrefix = 'A') {
  const prefix = layoutPrefix.toUpperCase();
  const fabDir = `${baseDir}/MAP/${fabName}`;
  const extractedDir = `${fabDir}/${prefix}.layout`;

  return {
    layoutZip: `${fabDir}/${prefix}.layout.zip`,
    layoutXml: `${extractedDir}/layout/layout.xml`,
    stationDat: `${fabDir}/${prefix}.station.dat`,
    hidZoneCsv: `${fabDir}/HID_Zone_Master_${fabName}_${prefix}.csv`,
    hidZoneJson: `${fabDir}/HID_Zone_Master_${fabName}_${prefix}.json`
  };
}

// ============================================================
// CSV 다운로드 (브라우저)
// ============================================================
export function downloadCsv(rows, filename = 'HID_ZONE_Master.csv') {
  const csvString = generateCsvString(rows);
  const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ============================================================
// JSON 다운로드 (브라우저)
// ============================================================
export function downloadJson(data, filename = 'HID_ZONE_Master.json') {
  const jsonString = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ============================================================
// Node.js CLI 실행
// ============================================================
if (typeof process !== 'undefined' && process.argv && process.argv[1]?.includes('hid_zone_csv_cre')) {
  (async () => {
    const fs = await import('fs');
    const path = await import('path');

    const args = process.argv.slice(2);

    // FAB 모드
    if (args.includes('--fab')) {
      const fabIdx = args.indexOf('--fab');
      const fabName = args[fabIdx + 1] || 'M14A';
      let layoutPrefix = 'A';
      if (args.includes('--layout')) {
        const layoutIdx = args.indexOf('--layout');
        layoutPrefix = args[layoutIdx + 1] || 'A';
      }
      let projectName = null;
      if (args.includes('--project')) {
        const projectIdx = args.indexOf('--project');
        projectName = args[projectIdx + 1];
      }

      const scriptDir = path.dirname(new URL(import.meta.url).pathname);
      const paths = getFabPaths(scriptDir, fabName, layoutPrefix);

      let xmlContent;
      if (fs.existsSync(paths.layoutXml)) {
        xmlContent = fs.readFileSync(paths.layoutXml, 'utf-8');
      } else if (fs.existsSync(paths.layoutZip)) {
        let JSZip;
        try { JSZip = (await import('jszip')).default; } catch { throw new Error('npm install jszip'); }
        const buf = fs.readFileSync(paths.layoutZip);
        const zip = await JSZip.loadAsync(buf.buffer);
        const xmlFile = Object.keys(zip.files).find(f => f.toLowerCase().includes('layout.xml'));
        if (!xmlFile) throw new Error('ZIP 내 layout.xml 없음');
        xmlContent = await zip.file(xmlFile).async('string');
      } else {
        console.error(`파일을 찾을 수 없음: ${paths.layoutXml}`);
        process.exit(1);
      }

      const result = createHidZoneData(xmlContent, projectName || `${fabName} Project`);

      // CSV 저장
      fs.writeFileSync(paths.hidZoneCsv, generateCsvString(result.zones));
      console.log(`CSV 저장: ${paths.hidZoneCsv}`);

      // JSON 저장
      fs.writeFileSync(paths.hidZoneJson, JSON.stringify(result, null, 2));
      console.log(`JSON 저장: ${paths.hidZoneJson}`);
      return;
    }

    // 직접 경로 모드
    const inputPath = args[0];
    const outputPath = args[1];

    if (!inputPath) {
      console.log('사용법: node hid_zone_csv_cre.js <input.xml|.zip> [output.csv]');
      console.log('  --fab M14A --layout A --project "M14 Project"');
      process.exit(1);
    }

    const xmlContent = fs.readFileSync(inputPath, 'utf-8');
    const result = createHidZoneData(xmlContent);

    const csvPath = outputPath || inputPath.replace(/\.(xml|zip)$/, '_HID_ZONE.csv');
    fs.writeFileSync(csvPath, generateCsvString(result.zones));
    console.log(`CSV 저장: ${csvPath}`);

    const jsonPath = csvPath.replace('.csv', '.json');
    fs.writeFileSync(jsonPath, JSON.stringify(result, null, 2));
    console.log(`JSON 저장: ${jsonPath}`);
  })();
}

export default createHidZoneData;
