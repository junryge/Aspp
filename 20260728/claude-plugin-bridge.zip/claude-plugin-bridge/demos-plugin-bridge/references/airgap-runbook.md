# 폐쇄망 반입 런북

한 사이클 = 외부망 30분 + 반입 + 폐쇄망 30분. 처음이면 `--internal` 38개로 시작해라.

## 사전 준비

| 구분 | 요구사항 |
|---|---|
| 외부망 PC | python3.8+, 인터넷 (github.com / codeload.github.com / raw.githubusercontent.com) |
| 폐쇄망 | python3.8+, DEMOS 스킬 디렉토리 쓰기 권한 |
| 공통 | pip 설치 불필요. stdlib 만 쓴다 |

`demos.config.json` 을 먼저 만들어라 (`assets/demos.config.sample.json` 복사 후 경로 수정).

---

## STEP 1 — 외부망: 미러링

```bash
python3 scripts/mirror.py --internal --out ./mirror
```

**확인할 것**
- [ ] `채택 N / 반려 M` 출력에서 반려 사유가 납득되는가
- [ ] `mirror_manifest.json` 의 `accepted[].pinned` 가 전부 true 인가
      (false 면 sha 없이 받은 것 → 재현 불가. 해당 항목은 빼는 게 낫다)
- [ ] 반려된 것 중 꼭 필요한 게 있으면 `--keep-rejected` 로 다시 받아 개별 검토

**자주 나오는 실패**
- `subpath 비어있음` → 업스트림에서 디렉토리 구조가 바뀐 것. 해당 플러그인 스킵
- HTTP 403/429 → GitHub 레이트리밋. 잠시 후 재시도 (백오프 내장)

## STEP 2 — 외부망: 반입 패키징

```bash
python3 scripts/airgap_pack.py ./mirror --out ./pack --split 45
```

**확인할 것**
- [ ] `sha256` 값을 **별도 경로로 따로 기록** (아카이브와 같이 다니면 검증 의미가 없다)
- [ ] 분할 크기가 반입 매체/시스템 제한에 맞는가
- [ ] `PACK_MANIFEST.json` 의 `mirror_summary.accepted` 목록이 승인받은 목록과 일치하는가

base64 반입 라인을 쓴다면 `--b64` 후 기존 encoder.py/decoder.py 로 이어 붙인다.

## STEP 3 — 반입 및 복원

`pack/RESTORE.md` 에 절차가 자동 생성돼 있다. 요지:

```bash
cat demos-plugins-*.tar.gz.part* > demos-plugins-*.tar.gz
sha256sum -c demos-plugins-*.tar.gz.sha256      # 여기서 틀리면 그 자리에서 중단
tar -xzf demos-plugins-*.tar.gz
```

**해시 불일치 시 절대 진행하지 마라.** 전송 손상 아니면 변조다. 둘 다 진행 사유가 안 된다.

## STEP 4 — 폐쇄망: 검증 게이트

```bash
python3 scripts/verify_import.py ./mirror --report VERIFY.md
echo $?      # 0=GO, 2=NO-GO
```

**NO-GO 유형별 대응**

| 사유 | 대응 |
|---|---|
| 트리 해시 불일치 | 재반입. 절대 우회 금지 |
| 매니페스트에 없는 플러그인 | 반입 경로 점검. 누가 중간에 끼워넣었는지 확인 |
| MCP 서버 의존 | 해당 플러그인 제외. 꼭 필요하면 `.mcp.json` 제거 후 스킬만 반입 |
| hooks 포함 | 훅 파일을 사람이 읽고 판단. 승인 시 `--allow hooks` (승인자 기록됨) |
| 위험도 초과 | `VERIFY.md` 의 위험 항목 직접 확인 후 개별 판단 |
| 프롬프트 인젝션 의심 | **반드시 사람이 원문을 읽는다.** 오탐도 많지만 진짜면 치명적 |
| 비밀정보 패턴 | 반입물에 있으면 안 된다. 출처 역추적 |

`VERIFY.md` 는 승인 근거 문서다. 보관해라.

## STEP 5 — 폐쇄망: 변환

```bash
python3 scripts/to_demos.py ./mirror --out ./staging \
    --config demos.config.json --existing /opt/demos/skills
```

**확인할 것**
- [ ] `CONVERSION.md` 의 분류 배분이 DEMOS 카테고리 체계와 맞는가
- [ ] 이름 충돌 스킵 목록이 있으면 의도한 것인가 (아니면 `--prefix` 조정)
- [ ] 커맨드→스킬 변환분의 `description` 을 **읽고 다듬어라**. 기계 생성 문장이다
- [ ] `requires_mcp` 달린 스킬이 남아있으면 뺄지 결정

## STEP 6 — 폐쇄망: 등록

```bash
python3 scripts/register.py ./staging --config demos.config.json --dry-run
python3 scripts/register.py ./staging --config demos.config.json --apply
```

**확인할 것**
- [ ] dry-run 의 신규/덮어씀 개수가 예상과 같은가
- [ ] 재색인 명령이 실제로 실행되고 성공했는가
- [ ] **백업 ID 를 기록** (롤백 티켓이다)
- [ ] `--status` 로 반입 스킬 목록 확인
- [ ] DEMOS UI/라우터에서 실제 검색·호출 테스트 2~3건

## STEP 7 — 사후

- 재색인 실패했는데 스킬은 들어간 경우 → 수동 재색인, 안 되면 즉시 롤백
- 사용자 문의로 "스킬이 안 먹는다"가 오면 십중팔구 `requires_mcp` 스킬이다. `--status` 로 확인
- 30일 지난 백업은 정리 (`backup_dir`)

---

## 재반입 (업스트림 업데이트 반영)

```bash
# 외부망
python3 scripts/mirror.py --internal --out ./mirror.new
python3 -c "
import json
a=json.load(open('mirror/mirror_manifest.json'))['accepted']
b=json.load(open('mirror.new/mirror_manifest.json'))['accepted']
A={x['name']:x['tree_sha256'] for x in a}; B={x['name']:x['tree_sha256'] for x in b}
print('변경:', [k for k in B if k in A and A[k]!=B[k]])
print('신규:', [k for k in B if k not in A])
print('사라짐:', [k for k in A if k not in B])
"
```

변경분만 반입하면 트래픽이 줄어든다. 변경된 플러그인은 **처음 반입과 동일하게 STEP 4~6 전부**
다시 탄다. "이미 한 번 봤으니까"는 사유가 안 된다 — 플러그인은 언제든 바뀔 수 있고
그게 공식 README 가 경고하는 바로 그 지점이다.

## 장애 대응 요약

| 증상 | 원인 | 조치 |
|---|---|---|
| 등록 후 라우터가 새 스킬을 못 찾음 | 재색인 미실행/실패 | `reindex_cmd` 확인 후 수동 재색인 |
| 스킬은 뜨는데 실행 실패 | MCP 의존 | `--status` 로 확인 후 해당 스킬 제거 |
| 기존 스킬 동작이 바뀜 | 덮어쓰기 발생 | 백업 ID 로 롤백, `--prefix` 조정 후 재등록 |
| 롤백 후 색인에 유령 스킬 | 색인 파일 미정리 | 최신 버전은 자동 처리됨. 구버전이면 수동 정리 |
| 검증은 GO 인데 이상한 동작 | 프롬프트 레벨 문제 | 해당 SKILL.md 본문 정독. 게이트는 패턴 매칭일 뿐이다 |
