# DEMOS 통합 매핑

## 1. 분류 매핑

공식 카탈로그의 카테고리는 13종 + 미지정이다 (284건 실측):

| 공식 category | 건수 | 기본 매핑 |
|---|--:|---|
| development | 119 | 개발 |
| productivity | 49 | 생산성 |
| database | 37 | 데이터베이스 |
| monitoring | 20 | 모니터링 |
| security | 18 | 보안 |
| (미지정) | 14 | 기타 |
| deployment | 8 | 배포 |
| design | 7 | 디자인 |
| automation | 3 | 자동화 |
| learning | 3 | 학습 |
| location | 2 | 기타 |
| testing | 2 | 테스트 |
| migration | 1 | 마이그레이션 |
| math | 1 | 수학 |

**DEMOS 카테고리 체계에 맞춰 `demos.config.json` 의 `category_map` 을 반드시 수정해라.**
기본값은 한국어 직역이라 기존 분류 체계와 안 맞을 가능성이 높다.

매핑 원칙:
- 기존 DEMOS 카테고리에 **없는 이름을 새로 만들지 마라.** 분류가 늘면 라우팅이 흐려진다
- 애매하면 `기타`로 보내고 나중에 사용 로그 보고 재분류
- 반입 스킬을 한 카테고리(예: `외부도입`)에 몰아넣는 것도 방법이다.
  라우팅 품질보다 **관리 가시성**이 중요하면 그게 낫다

## 2. 네이밍과 충돌

DEMOS 는 이미 스킬이 수백 개다. 이름 충돌은 예외가 아니라 기본값이라고 봐야 한다.

**접두사 필수.** `prefix: "cc"` → `cc-code-reviewer`, `cc-claude-md-improver`.
접두사가 하는 일 셋:
1. 기존 스킬과 충돌 방지
2. "이건 외부에서 온 것"이라는 시각적 표시
3. 나중에 일괄 제거/갱신할 때 필터 키

충돌 정책 3종:

| 정책 | 동작 | 언제 |
|---|---|---|
| `suffix` (기본) | `-2`, `-3` 자동 부여 | 둘 다 살리고 싶을 때 |
| `skip` | 기존 것 유지, 신규 버림 | **운영 안정 최우선. 대량 반입 시 권장** |
| `overwrite` | 신규로 덮어씀 | 같은 플러그인 업데이트 반영 시 |

`--existing /opt/demos/skills` 를 주면 운영 디렉토리를 스캔해서 **등록 전에** 충돌을
탐지한다. 폴더명과 frontmatter `name` 둘 다 본다.

## 3. 하이브리드 색인 통합

`skills_index.jsonl` 한 줄 = 스킬 하나.

```json
{
  "name": "cc-claude-md-improver",
  "kind": "skill",
  "category": "생산성",
  "plugin": "claude-md-management",
  "description": "Audit and improve CLAUDE.md files ...",
  "requires_mcp": [],
  "risk": 2,
  "routing_text": "cc claude md improver cc-claude-md-improver Audit and improve ... 플러그인:claude-md-management 유형:skill 분류:생산성 claude code plugin skill"
}
```

`routing_text` 설계 의도 — **임베딩과 BM25 는 필요한 게 다르다.**

- BGE-M3 같은 임베딩은 자연어 의미를 잡는다 → 하이픈 푼 자연어(`cc claude md improver`)
- BM25 는 정확한 토큰을 잡는다 → 원본 슬러그(`cc-claude-md-improver`), 플러그인명, 분류

둘 다 넣어야 하이브리드 라우터가 양쪽에서 걸린다. 한쪽만 넣으면
"이름으로 찾으면 되는데 뜻으로 찾으면 안 되는" (또는 반대) 스킬이 된다.

**주의**: 영문 description 이 대부분이다. 한국어 질의 비중이 높으면 반입 후
주요 스킬의 description 에 한국어 트리거 문장을 추가해라. 임베딩이 다국어를 어느 정도
넘어가긴 하지만 BM25 는 토큰이 안 맞으면 그냥 못 잡는다.

```yaml
description: "Audit and improve CLAUDE.md files ... 사용자가 CLAUDE.md 점검, 프로젝트 메모리 정리, 문서 품질 감사를 요청하면 이 스킬을 켠다."
```

## 4. 레지스트리 스키마

`register.py` 가 `registry_path` 에 upsert 하는 레코드:

```json
{
  "name": "cc-claude-md-improver",
  "category": "생산성",
  "description": "...",
  "kind": "skill",
  "origin_plugin": "claude-md-management",
  "risk": 2,
  "requires_mcp": [],
  "imported_at": "2026-08-10",
  "source": "claude-plugins"
}
```

`name` 기준 upsert다. 기존 레지스트리가 배열이면 `{"skills":[...]}` 로 감싸서 읽는다.
DEMOS 레지스트리 스키마가 다르면 `register.py` 의 `rec` 딕셔너리만 고치면 된다.
**`source: "claude-plugins"` 는 지우지 마라** — 나중에 반입분만 골라낼 유일한 키다.

## 5. SKILL.md 주입 메타

| 키 | 용도 |
|---|---|
| `demos_category` | DEMOS 분류 |
| `origin_plugin` | 원본 플러그인명 |
| `origin_repo` | `owner/repo` |
| `origin_ref` | 커밋 sha 앞 12자 — **업데이트 판정 기준** |
| `origin_author` | 원작자 (라이선스·문의) |
| `origin_kind` | skill / command / agent |
| `origin_path` | 원본 내부 경로 |
| `origin_risk` | 반입 시점 위험도 |
| `requires_mcp` | MCP 의존 목록 (있으면 폐쇄망 실행 불가) |
| `demos_runnable` | MCP 의존 시 false |
| `imported_at` | 반입일 |

`register.py --status` 가 이 메타를 읽어서 반입 스킬 현황을 뽑는다.
메타를 지우면 추적 불가 상태가 되니 편집할 때 건드리지 마라.

## 6. 라이프사이클

| 시점 | 할 일 |
|---|---|
| 반입 | STEP 1~6 (런북) |
| 월 1회 | 재반입 diff 확인 → 변경분만 갱신 |
| 분기 1회 | 사용 로그 기반 미사용 스킬 정리. 안 쓰는 스킬은 라우팅 노이즈다 |
| 상시 | `requires_mcp` 스킬이 남아있는지 `--status` 로 점검 |
| 사고 시 | 백업 ID 롤백 → 원인 분석 → 재등록 |

**미사용 스킬 정리가 생각보다 중요하다.** 355개 + 반입분이면 라우터가 고를 후보가
너무 많아진다. 하이브리드 검색이 좋아도 후보 풀이 넓으면 정확도가 떨어진다.
"있으면 좋겠지" 로 넣지 말고 **쓸 것만** 넣어라.

## 7. 역방향 배포 시 마스킹 대상

`export_demos.py` 가 걸러내는 패턴. 사내 환경에 맞게 `LEAK` 리스트를 조정해라.

| 패턴 | 예 |
|---|---|
| 사내 IP | `10.30.11.133` |
| 시스템 식별자 | `M16MCSPP`, `NT_L_LOGMESSAGE`, `dev.hcp.llm...` |
| API 토큰 | `sk-...`, `ghp_...` |
| 비밀번호 | `password = "..."` |
| 자격증명 파일 | `TOKEN.TXT` |
| 사번/설비ID | `AB123456` 형태 |

걸리면 그 스킬은 **자동 제외**되고 `EXPORT_AUDIT.json` 에 사유가 남는다.
`--allow-leaks` 가 있긴 하지만 쓰지 마라. 마스킹하거나 스킬을 고치는 게 맞다.
