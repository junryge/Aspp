---
name: demos-plugin-bridge
description: 공식 Claude Code 플러그인 마켓플레이스(anthropics/claude-plugins-official, 284개)를 폐쇄망 DEMOS 플랫폼에 반입하고, 반대로 DEMOS 스킬을 사내에 배포하는 양방향 브리지. 외부망 미러링 → 결정론적 tar+SHA256 반입 패키징 → 폐쇄망 검증 게이트(무결성/MCP/hooks/프롬프트 인젝션/사내정보) → DEMOS 스킬 변환 및 분류 매핑 → 레지스트리·하이브리드 색인 등록 → 원클릭 롤백까지 전 구간을 담당한다. 사용자가 플러그인 반입, 폐쇄망 스킬 도입, DEMOS 스킬 등록, marketplace.json, 스킬 배포/공유, 외부 스킬 가져오기, 반입 검증, 스킬 롤백, 사내 마켓플레이스 같은 얘기를 꺼내면 반드시 이 스킬을 켠다. 인터넷 되는 일반 환경이면 claude-plugin-kit 쪽을 쓴다.
---

# DEMOS Plugin Bridge

공식 플러그인 생태계 ↔ 폐쇄망 DEMOS 를 잇는 양방향 브리지.
**stdlib only.** pip 설치, Docker, Node 전부 필요 없다. python3 만 있으면 된다.

## 0. 설계 근거 (2026-08 카탈로그 실측)

284개 전수 파싱 결과:

- 원격 소스 **231건 전부 github.com**, 비-github 0건
- 원격 소스 **231/231 전부 커밋 sha 고정**
- Anthropic 자체 38개 / 서드파티 246개
- 소스 타입: url 146, git-subdir 83, self-repo 53, github 2

→ **git 없이 `codeload.github.com/{owner}/{repo}/tar.gz/{sha}` 만으로 카탈로그 100%를
재현 가능하게 받을 수 있다.** 폐쇄망 반입의 전제 조건이 이걸로 성립한다.
같은 sha 면 언제 받아도 같은 트리 → 반입물 무결성을 해시로 증명할 수 있다.

## 1. 전체 파이프라인

```
[외부망 PC]                         [반입]              [폐쇄망 DEMOS]
mirror.py ──→ airgap_pack.py ──→ (매체/base64) ──→ verify_import.py
   선별·정책 필터    결정론 tar+SHA256                     GO/NO-GO 게이트
                                                              ↓
                                                        to_demos.py
                                                      변환·분류·충돌해결
                                                              ↓
                                                        register.py
                                                   백업→등록→재색인→롤백
                                                              ↓
                                     export_demos.py ←─ (역방향) 사내 배포
```

**단계를 건너뛰지 마라.** 특히 `verify_import.py` 가 NO-GO 면 등록으로 넘어가지 않는다.

## 2. [외부망] 미러링 — `scripts/mirror.py`

```bash
python3 scripts/mirror.py --internal --out ./mirror          # Anthropic 자체 38개 (권장 시작점)
python3 scripts/mirror.py --policy safe --category development,productivity --out ./mirror
python3 scripts/mirror.py --name claude-md-management --name skill-creator --out ./mirror
python3 scripts/mirror.py --all --out ./mirror               # 284개 전량 (수 GB)
```

`--policy safe`(기본값)가 자동으로 걸러내는 것:

| 제외 대상 | 이유 |
|---|---|
| MCP 서버 의존 | 폐쇄망에서 **100% 실패한다.** 스킬은 보이는데 도구가 없다 |
| hooks 포함 | 사용자 확인 없이 자동 실행 |
| 위험도 > 30 | `--max-risk` 로 조절 |

제외 사유는 전부 `mirror_manifest.json` 에 남는다. `--keep-rejected` 로 격리 보관 후
검토할 수 있다. 산출물: `plugins/`, `mirror_manifest.json`(sha·트리해시·정책),
`marketplace.json`(폐쇄망 조회용 카탈로그 스냅샷).

## 3. [외부망] 반입 패키징 — `scripts/airgap_pack.py`

```bash
python3 scripts/airgap_pack.py ./mirror --out ./pack --split 45      # 45MB 분할
python3 scripts/airgap_pack.py ./mirror --out ./pack --split 45 --b64
```

**결정론적 tar** 를 만든다. mtime/uid/gid/uname/gname 을 0으로 고정하고
gzip 헤더 mtime 까지 0으로 박아서 경로 정렬로 담는다.
→ 같은 미러면 몇 번을 말아도 sha256 이 동일하다. 재반입 때 "바뀐 게 있나"를
해시 한 줄로 판정할 수 있다. (검증 완료: 서로 다른 시각 2회 실행 → 동일 해시)

`--b64` 는 기존 base64 반입 파이프라인(encoder.py/decoder.py)에 그대로 물리라고 있는 것이다.
산출물에 `RESTORE.md`(폐쇄망 복원 절차서)가 자동 포함된다.

## 4. [폐쇄망] 검증 게이트 — `scripts/verify_import.py`

```bash
python3 scripts/verify_import.py ./mirror --report VERIFY.md
python3 scripts/verify_import.py ./mirror --json
python3 scripts/verify_import.py ./mirror --allow hooks     # 예외 승인(사유가 기록됨)
```

5개 항목을 본다. 종료코드 0=GO, 2=NO-GO.

1. **트리 무결성** — 매니페스트의 `tree_sha256` vs 현재 트리 재계산. 누락·초과 파일도 잡는다
2. **정책 위반** — MCP / hooks / 위험도
3. **외부 의존** — 외부 다운로드, 패키지 설치, `curl | sh`
4. **프롬프트 위생** — 지시 무력화("ignore previous instructions"), 유출 유도, 시스템 프롬프트 탈취
5. **비밀정보** — 사내 IP(10.30.x), 토큰, 비밀번호 패턴

4번을 특히 봐라. 스킬 본문은 **에이전트에게 주는 지시문**이다. 남이 쓴 프롬프트가
그대로 우리 에이전트의 명령이 된다.

## 5. [폐쇄망] DEMOS 변환 — `scripts/to_demos.py`

```bash
python3 scripts/to_demos.py ./mirror --out ./staging --config demos.config.json \
    --existing /opt/demos/skills          # 운영 스킬과 이름 충돌 사전 탐지
python3 scripts/to_demos.py ./mirror --out ./staging --dry-run
```

**운영 디렉토리를 절대 건드리지 않는다.** 전부 스테이징에만 쓴다.

| 원본 | 처리 |
|---|---|
| `skills/*/SKILL.md` | 이식 + DEMOS 메타 주입 (리소스 폴더 동반) |
| `commands/*.md` | 스킬 승격 + **트리거 문장 생성** |
| `agents/*.md` | 스킬 승격 (도구 제약·권장모델 본문 명시) |
| `.mcp.json` | 변환 안 함. `requires_mcp`/`demos_runnable:false` 로 표시만 |
| `hooks/` | 이식 안 함 |

주입되는 메타: `demos_category`, `origin_plugin`, `origin_repo`, `origin_ref`,
`origin_author`, `origin_risk`, `origin_kind`, `origin_path`, `imported_at`.
"이 스킬 어디서 왔냐"는 질문에 이걸로 답한다.

산출물:
- `staging/skills/<prefix>-<name>/SKILL.md`
- `staging/skills_index.jsonl` — **하이브리드 라우팅 재색인 입력**. `routing_text` 에
  임베딩용 자연어와 BM25용 고유명사를 같이 넣는다 (BGE-M3 는 의미로, BM25 는 토큰으로 잡는다)
- `staging/demos_registry_delta.json` — 레지스트리 병합 델타
- `staging/CONVERSION.md` — 사람이 읽는 보고서

**커맨드 변환이 왜 중요한가**: 슬래시 커맨드는 "불러야 도는" 물건이라 *언제 쓰는지*가 없다.
그냥 복사하면 DEMOS 라우터가 영원히 안 고르는 죽은 스킬이 된다.
그래서 변환기가 트리거 문장을 만들어 붙인다. 그래도 **최종 description 은 사람이 한 번 다듬어라.**

## 6. [폐쇄망] 등록·롤백 — `scripts/register.py`

```bash
python3 scripts/register.py ./staging --config demos.config.json --dry-run   # 계획만
python3 scripts/register.py ./staging --config demos.config.json --apply     # 등록
python3 scripts/register.py --config demos.config.json --status              # 반입 현황
python3 scripts/register.py --config demos.config.json --list                # 백업 목록
python3 scripts/register.py --config demos.config.json --rollback 20260810-0122
```

`--apply` 순서: **백업 → 스킬 복사 → 레지스트리 upsert → 색인 입력 병합 → 재색인 실행.**
백업 ID 하나로 전부 원복된다. 등록 전에 없던 파일(registry/index)은 롤백 시 복원이 아니라
**삭제**한다 — 안 그러면 색인이 유령 스킬을 물고 있게 된다.

설정은 `assets/demos.config.sample.json` 복사해서 경로 채워 쓴다:
`skills_dir`, `registry_path`, `index_jsonl`, `backup_dir`, `reindex_cmd`,
`prefix`, `collision`, `category_map`.

> `reindex_cmd` 는 DEMOS 색인 빌더 경로다. 환경에 맞게 반드시 채워라. 비워두면 재색인이
> 생략되고 스킬은 들어갔는데 라우터가 못 찾는 상태가 된다.

## 7. [역방향] 사내 배포 — `scripts/export_demos.py`

DEMOS 스킬을 다른 사람이 `/plugin install` 로 쓰게 만든다.

```bash
python3 scripts/export_demos.py /opt/demos/skills --out ./export \
    --name amhs-skills --owner "존" --repo https://git.internal/amhs/skills.git \
    --exclude-imported

python3 scripts/export_demos.py /opt/demos/skills --out ./export --name amhs --audit-only
```

**유출 검사가 기본이고, 걸리면 그 스킬은 자동 제외된다.** 검사 대상:
사내 IP(10.x), 시스템 식별자(M16MCSPP / NT_L_LOGMESSAGE / dev.hcp.llm 등),
API 토큰, 비밀번호, TOKEN.TXT 참조, 사번/설비ID 패턴.
`--exclude-imported` 는 외부에서 반입한 스킬을 재배포 대상에서 뺀다 (라이선스 문제).

산출물: `.claude-plugin/marketplace.json`(strict:false 스킬번들 패턴), 스킬 복사본,
`README.md`(설치 안내), `EXPORT_AUDIT.json`(내보낸 것/제외한 것과 사유).

상대방은:
```
/plugin marketplace add https://git.internal/amhs/skills.git
/plugin install amhs-skills@amhs-skills
```

## 8. 반드시 지킬 것

1. **`name` 은 불변 슬러그다.** 배포 후 바꾸면 남의 설치가 `plugin-not-found` 로 깨진다.
   표시명은 `displayName`, 불가피하면 마켓 최상위 `renames` 맵.
2. **MCP 의존 플러그인은 폐쇄망에 넣지 마라.** 스킬 목록엔 뜨는데 실행이 반드시 실패한다.
   라우터가 그걸 고르면 사용자는 "DEMOS 가 고장났다"고 느낀다.
3. **hooks 는 이식 금지.** 자동 실행이라 통제 불능.
4. **sha 고정으로만 받아라.** `ref: main` 은 어제와 오늘이 다르다.
5. **등록 전 항상 `--dry-run`**, 등록 후 백업 ID 를 기록해 둬라.
6. **재배포 시 원본 LICENSE 동봉.** 마켓 레포는 Apache-2.0 이지만 각 플러그인은 자기 라이선스를 따른다.

## 9. 참고 문서

- `references/airgap-runbook.md` — 반입 런북 (체크리스트·장애 대응·재반입 절차)
- `references/demos-mapping.md` — 분류 매핑, 네이밍/충돌 정책, 색인 통합, 라이프사이클
- `references/plugin-spec.md` — plugin.json / marketplace.json 스키마 실측 정리

## 10. 파일 구성

```
demos-plugin-bridge/
├── SKILL.md
├── scripts/
│   ├── _core.py           공용 코어 (마켓 파싱·source 해석·안전 tar 전개·frontmatter·인벤토리·위험도)
│   ├── mirror.py          [외부망] 선별 미러링 + 정책 필터
│   ├── airgap_pack.py     [외부망] 결정론 tar + SHA256 + 분할 + base64 + 복원절차서
│   ├── verify_import.py   [폐쇄망] GO/NO-GO 검증 게이트
│   ├── to_demos.py        [폐쇄망] DEMOS 스킬 변환 + 분류 매핑 + 충돌 해결
│   ├── register.py        [폐쇄망] 백업·등록·재색인·롤백
│   └── export_demos.py    [역방향] 사내 마켓플레이스 배포 (유출검사 포함)
├── assets/
│   └── demos.config.sample.json
└── references/
    ├── airgap-runbook.md
    ├── demos-mapping.md
    └── plugin-spec.md
```
