#!/usr/bin/env python3
"""
export_demos.py - [역방향] DEMOS 스킬을 사내 마켓플레이스로 내보낸다.

목적: 우리가 만든 스킬(AMHS/MCS/HUBROOM 등)을 다른 사람이
`/plugin install <name>@<사내마켓>` 으로 쓰게 만든다.

기본 동작이 "안전 우선"이다. 유출 검사에 걸리면 그 스킬은 **자동 제외**된다.
사내 IP(10.x), 토큰, 서비스명/TNS, 사번 패턴이 대상이다.

사용:
  python3 export_demos.py /opt/demos/skills --out ./export \
      --name amhs-skills --owner "존" --repo https://git.internal/amhs/skills.git

  python3 export_demos.py /opt/demos/skills --out ./export --name amhs \
      --category-filter AMHS,물류 --exclude-imported

  python3 export_demos.py /opt/demos/skills --out ./export --name amhs --audit-only
"""
import argparse
import json
import re
import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _core import parse_frontmatter, slugify  # noqa: E402

LEAK = [
    (r"\b10\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", "사내 IP"),
    (r"(?i)\b(M16MCSPP|NT_L_LOGMESSAGE|dev\.hcp\.llm)\S*", "사내 시스템 식별자"),
    (r"\bsk-[A-Za-z0-9]{20,}|ghp_[A-Za-z0-9]{30,}", "API 토큰"),
    (r"(?i)(password|passwd)\s*[=:]\s*['\"][^'\"]{3,}", "비밀번호"),
    (r"(?i)\b(TOKEN\.TXT)\b", "자격증명 파일 참조"),
    (r"\b[A-Z]{2}\d{6,}\b", "사번/설비ID 의심"),
]
SCAN_EXT = {".md", ".py", ".sh", ".json", ".yaml", ".yml", ".txt", ".sql"}
CATEGORIES = ["development", "productivity", "database", "monitoring", "security",
              "deployment", "design", "automation", "learning", "testing",
              "migration", "math"]


def scan_leaks(d):
    hits = []
    for f in Path(d).rglob("*"):
        if not f.is_file() or f.suffix.lower() not in SCAN_EXT:
            continue
        try:
            t = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for rx, label in LEAK:
            for m in re.finditer(rx, t):
                hits.append({"label": label, "file": str(f.relative_to(d)),
                             "line": t.count("\n", 0, m.start()) + 1,
                             "match": m.group(0)[:40]})
                break
    return hits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("skills_dir")
    ap.add_argument("--out", default="./export")
    ap.add_argument("--name", required=True, help="마켓플레이스/번들 슬러그 (불변)")
    ap.add_argument("--owner", default="DEMOS")
    ap.add_argument("--email", default=None)
    ap.add_argument("--description", default=None)
    ap.add_argument("--category", default="productivity", choices=CATEGORIES)
    ap.add_argument("--repo", default=None)
    ap.add_argument("--path", default="skills")
    ap.add_argument("--ref", default="main")
    ap.add_argument("--include", help="쉼표구분 스킬명 화이트리스트")
    ap.add_argument("--category-filter", help="쉼표구분 DEMOS 분류")
    ap.add_argument("--exclude-imported", action="store_true",
                    help="origin_plugin 있는(=외부에서 반입한) 스킬 제외")
    ap.add_argument("--allow-leaks", action="store_true", help="유출 검사 무시(비권장)")
    ap.add_argument("--audit-only", action="store_true")
    args = ap.parse_args()

    src = Path(args.skills_dir)
    if not src.is_dir():
        sys.exit("스킬 디렉토리 없음: %s" % src)
    inc = {x.strip() for x in args.include.split(",")} if args.include else None
    catf = {x.strip() for x in args.category_filter.split(",")} if args.category_filter else None

    picked, dropped = [], []
    for d in sorted(src.iterdir()):
        f = d / "SKILL.md"
        if not d.is_dir() or not f.exists():
            continue
        meta, body = parse_frontmatter(f.read_text(encoding="utf-8", errors="replace"))
        name = str(meta.get("name") or d.name)
        if inc and name not in inc:
            continue
        if catf and str(meta.get("demos_category", "")) not in catf:
            continue
        if args.exclude_imported and meta.get("origin_plugin"):
            dropped.append({"name": name, "why": "외부 반입 스킬(재배포 라이선스 확인 필요)"})
            continue
        desc = str(meta.get("description", "")).strip()
        leaks = scan_leaks(d)
        if leaks and not args.allow_leaks:
            dropped.append({"name": name, "why": "유출 검사 위반",
                            "hits": [{"label": h["label"], "file": h["file"],
                                      "line": h["line"]} for h in leaks[:6]]})
            continue
        problems = []
        if len(desc) < 60:
            problems.append("description 이 짧다(%d자) — 트리거 약함" % len(desc))
        if not desc:
            problems.append("description 없음")
        picked.append({"dir": d, "name": name, "description": desc,
                       "category": meta.get("demos_category"),
                       "leaks": len(leaks), "problems": problems})

    print("대상 %d개 / 제외 %d개" % (len(picked), len(dropped)))
    for x in dropped:
        print("  - 제외 %-32s %s" % (x["name"][:32], x["why"]))
    for p in picked:
        for pr in p["problems"]:
            print("  ! %-32s %s" % (p["name"][:32], pr))
    if args.audit_only:
        return
    if not picked:
        sys.exit("내보낼 스킬이 없다.")

    out = Path(args.out)
    sdir = out / args.path
    sdir.mkdir(parents=True, exist_ok=True)
    for p in picked:
        dst = sdir / p["name"]
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(p["dir"], dst,
                        ignore=shutil.ignore_patterns(".git", "__pycache__", "*.pyc"))

    entry = {
        "name": slugify(args.name),
        "description": args.description or
        ("DEMOS 스킬 묶음 (%d개): %s" %
         (len(picked), ", ".join(p["name"] for p in picked[:6]))),
        "author": {"name": args.owner, **({"email": args.email} if args.email else {})},
        "category": args.category,
        "source": ({"source": "git-subdir", "url": args.repo,
                    "path": args.path, "ref": args.ref}
                   if args.repo else "./" + args.path),
        "strict": False,
        "skills": ["./%s" % p["name"] for p in picked],
    }
    mk = {"$schema": "https://anthropic.com/claude-code/marketplace.schema.json",
          "name": slugify(args.name),
          "description": "%s 사내 마켓플레이스" % args.owner,
          "owner": {"name": args.owner, **({"email": args.email} if args.email else {})},
          "plugins": [entry]}
    md = out / ".claude-plugin"
    md.mkdir(parents=True, exist_ok=True)
    (md / "marketplace.json").write_text(
        json.dumps(mk, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    (out / "README.md").write_text("\n".join([
        "# %s" % args.name, "",
        entry["description"], "",
        "## 설치", "", "```",
        "/plugin marketplace add %s" % (args.repo or "<이 레포 경로>"),
        "/plugin install %s@%s" % (entry["name"], mk["name"]), "```", "",
        "## 포함 스킬 (%d)" % len(picked), "",
        "| 스킬 | 설명 |", "|---|---|"] +
        ["| `%s` | %s |" % (p["name"], p["description"][:120].replace("|", "/"))
         for p in picked] +
        ["", "---", "생성 %s / 유출검사 통과" % time.strftime("%Y-%m-%d %H:%M"),
         "", "> `name` 은 불변 슬러그다. 배포 후 바꾸면 설치가 깨진다.",
         "> 표시명만 바꾸려면 displayName, 불가피하면 renames 맵을 쓴다."]),
        encoding="utf-8")

    (out / "EXPORT_AUDIT.json").write_text(json.dumps(
        {"generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
         "exported": [p["name"] for p in picked],
         "dropped": dropped}, ensure_ascii=False, indent=2), encoding="utf-8")

    print("\n내보내기 완료: %s" % out)
    print("  스킬 %d개 / marketplace.json / README.md / EXPORT_AUDIT.json" % len(picked))
    print("  설치: /plugin marketplace add %s" % (args.repo or "<레포>"))
    print("        /plugin install %s@%s" % (entry["name"], mk["name"]))


if __name__ == "__main__":
    main()
