#!/usr/bin/env python3
"""
to_demos.py - [폐쇄망] 검증 통과한 미러를 DEMOS 스킬로 변환해 스테이징한다.

register.py 로 넘기기 전 단계다. 여기서는 DEMOS 스킬 디렉토리를 절대 건드리지 않는다.
전부 스테이징 폴더에만 쓴다. 실패해도 운영에 흠집이 안 난다.

변환 규칙
  skills/*/SKILL.md -> 이식 + DEMOS 메타 주입
  commands/*.md     -> 스킬 승격 + 트리거 문장 생성
  agents/*.md       -> 스킬 승격 (DEMOS 에이전트로 쓸 거면 --agents-out 지정)
  .mcp.json         -> 변환 안 함. 폐쇄망 미동작. requires_mcp 로 표시만
  hooks/            -> 이식 안 함

DEMOS 통합 산출물
  <out>/skills/<prefix>-<name>/SKILL.md      스킬 본체
  <out>/skills_index.jsonl                   하이브리드 라우팅 재색인 입력(BGE-M3/BM25)
  <out>/demos_registry_delta.json            레지스트리 병합용 델타
  <out>/CONVERSION.md                        사람이 읽는 변환 보고서

사용:
  python3 to_demos.py ./mirror --out ./staging --config demos.config.json
  python3 to_demos.py ./mirror --out ./staging --existing /opt/demos/skills   # 충돌 사전탐지
  python3 to_demos.py ./mirror --out ./staging --dry-run
"""
import argparse
import json
import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _core import (dump_frontmatter, inventory, parse_frontmatter,  # noqa: E402
                   risk_score, slugify)

SKIP = {".git", "node_modules", "__pycache__", ".github", ".federated.json"}

DEFAULT_CATEGORY_MAP = {
    "development": "개발", "productivity": "생산성", "database": "데이터베이스",
    "monitoring": "모니터링", "security": "보안", "deployment": "배포",
    "design": "디자인", "automation": "자동화", "learning": "학습",
    "testing": "테스트", "migration": "마이그레이션", "math": "수학",
    "location": "기타", None: "기타",
}


def load_cfg(p):
    cfg = {"prefix": "cc", "category_map": DEFAULT_CATEGORY_MAP,
           "default_category": "기타", "collision": "suffix"}
    if p and Path(p).exists():
        cfg.update(json.loads(Path(p).read_text(encoding="utf-8")))
    cm = dict(DEFAULT_CATEGORY_MAP)
    cm.update(cfg.get("category_map") or {})
    cfg["category_map"] = cm
    return cfg


def existing_names(path):
    if not path:
        return set()
    root = Path(path)
    if not root.is_dir():
        return set()
    out = set()
    for d in root.iterdir():
        if d.is_dir():
            out.add(d.name)
            f = d / "SKILL.md"
            if f.exists():
                meta, _ = parse_frontmatter(f.read_text(encoding="utf-8", errors="replace"))
                if meta.get("name"):
                    out.add(str(meta["name"]))
    return out


def uniq(base, used, policy, prefix):
    name = slugify("%s-%s" % (prefix, base) if prefix else base)
    if name not in used:
        return name
    if policy == "skip":
        return None
    if policy == "overwrite":
        return name
    i = 2
    while "%s-%d" % (name, i) in used:
        i += 1
    return "%s-%d" % (name, i)


def routing_text(name, desc, plugin, kind, category):
    """하이브리드 라우팅(BGE-M3 임베딩 + BM25)용 색인 텍스트.
    임베딩엔 의미가, BM25엔 고유명사가 필요하다. 둘 다 넣는다."""
    return " ".join(filter(None, [
        name.replace("-", " "), name, desc,
        "플러그인:%s" % plugin, "유형:%s" % kind, "분류:%s" % category,
        "claude code plugin skill",
    ]))


def convert(pdir, meta_src, cfg, out_skills, used, args, report):
    plugin = pdir.name
    inv = inventory(pdir)
    cat = cfg["category_map"].get(meta_src.get("category"), cfg["default_category"])
    made = []
    common = {
        "demos_category": cat,
        "origin_plugin": plugin,
        "origin_repo": meta_src.get("repo"),
        "origin_ref": (meta_src.get("ref") or "")[:12],
        "origin_author": (meta_src.get("author") or {}).get("name"),
        "origin_risk": risk_score(inv),
        "imported_at": time.strftime("%Y-%m-%d"),
    }
    if inv["mcp_servers"]:
        common["requires_mcp"] = [s["name"] for s in inv["mcp_servers"]]
        common["demos_runnable"] = False

    def emit(name, meta, body, kind, srcdir=None, rel=""):
        dst = out_skills / name
        if not args.dry_run:
            if srcdir is not None:
                if dst.exists():
                    shutil.rmtree(dst)
                shutil.copytree(srcdir, dst, ignore=shutil.ignore_patterns(*SKIP))
            else:
                dst.mkdir(parents=True, exist_ok=True)
            m = dict(meta)
            m.update(common)
            m["origin_kind"] = kind
            m["origin_path"] = rel
            (dst / "SKILL.md").write_text(dump_frontmatter(m, body), encoding="utf-8")
        used.add(name)
        rec = {"name": name, "kind": kind, "category": cat, "plugin": plugin,
               "description": meta.get("description", ""),
               "requires_mcp": common.get("requires_mcp", []),
               "risk": common["origin_risk"],
               "routing_text": routing_text(name, meta.get("description", ""),
                                            plugin, kind, cat)}
        made.append(rec)

    # 1) 스킬
    for sk in inv["skills"]:
        src = pdir / sk["dir"] if sk["dir"] != "." else pdir
        name = uniq(sk["name"] or src.name, used, cfg["collision"], cfg["prefix"])
        if not name:
            report["collisions"].append({"plugin": plugin, "name": sk["name"]})
            continue
        meta, body = parse_frontmatter((src / "SKILL.md").read_text(encoding="utf-8",
                                                                   errors="replace"))
        meta["name"] = name
        meta.setdefault("description", sk["description"])
        emit(name, meta, body, "skill", src, sk["dir"])

    # 2) 커맨드 -> 스킬
    for c in inv["commands"]:
        name = uniq(c["name"], used, cfg["collision"], cfg["prefix"])
        if not name:
            report["collisions"].append({"plugin": plugin, "name": c["name"]})
            continue
        meta, body = parse_frontmatter((pdir / c["file"]).read_text(encoding="utf-8",
                                                                   errors="replace"))
        base = c["description"] or "%s 플러그인의 /%s 커맨드" % (plugin, c["name"])
        meta = dict(meta)
        meta["name"] = name
        meta["description"] = ("%s. 사용자가 '%s' 관련 작업을 요청하거나 /%s 를 "
                               "언급하면 이 스킬을 켠다." %
                               (base.rstrip("."), c["name"].replace("-", " "), c["name"]))
        pre = []
        if c["allowed_tools"]:
            pre.append("**허용 도구(원본 제약)**: `%s`" % c["allowed_tools"])
        if c["argument_hint"]:
            pre.append("**인자**: `%s` — 대화에서 못 받았으면 먼저 물어본다." % c["argument_hint"])
        pre.append("> 원본: `%s` 플러그인의 슬래시 커맨드 `/%s`. "
                   "`$ARGUMENTS`/`$1` 자리표시자는 사용자의 실제 요청으로 치환해 읽는다."
                   % (plugin, c["name"]))
        emit(name, meta, "# %s\n\n%s\n\n---\n\n%s" % (name, "\n\n".join(pre), body.strip()),
             "command", None, c["file"])

    # 3) 에이전트 -> 스킬
    if not args.skip_agents:
        for a in inv["agents"]:
            name = uniq(a["name"], used, cfg["collision"], cfg["prefix"])
            if not name:
                report["collisions"].append({"plugin": plugin, "name": a["name"]})
                continue
            meta, body = parse_frontmatter((pdir / a["file"]).read_text(encoding="utf-8",
                                                                       errors="replace"))
            meta = dict(meta)
            meta["name"] = name
            meta["description"] = a["description"] or "%s 플러그인의 %s 에이전트" % (plugin, name)
            pre = ["**역할**: 서브에이전트 정의를 옮긴 스킬이다. DEMOS 멀티에이전트로 "
                   "위임할 수 있으면 위임하고, 아니면 아래 지침대로 직접 수행한다."]
            if a["allowed_tools"]:
                pre.append("**허용 도구(원본 제약)**: `%s`" % a["allowed_tools"])
            if a["model"]:
                pre.append("**원본 권장 모델**: `%s` — DEMOS 라우팅 정책에 맞춰 치환한다." % a["model"])
            emit(name, meta, "# %s\n\n%s\n\n---\n\n%s" % (name, "\n\n".join(pre), body.strip()),
                 "agent", None, a["file"])

    if inv["hooks"]:
        report["dropped_hooks"].append({"plugin": plugin, "files": inv["hooks"][:10]})
    if inv["mcp_servers"]:
        report["mcp"].append({"plugin": plugin,
                              "servers": [s["name"] for s in inv["mcp_servers"]]})
    return made


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mirror")
    ap.add_argument("--out", default="./staging")
    ap.add_argument("--config", default="demos.config.json")
    ap.add_argument("--existing", default=None,
                    help="운영 DEMOS 스킬 디렉토리 (충돌 사전 탐지)")
    ap.add_argument("--prefix", default=None)
    ap.add_argument("--collision", choices=["suffix", "skip", "overwrite"], default=None)
    ap.add_argument("--skip-agents", action="store_true")
    ap.add_argument("--include-mcp", action="store_true",
                    help="MCP 의존 플러그인도 변환 (기본은 제외 — 폐쇄망 미동작)")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    cfg = load_cfg(args.config)
    if args.prefix is not None:
        cfg["prefix"] = args.prefix
    if args.collision:
        cfg["collision"] = args.collision

    root = Path(args.mirror)
    pdir = root / "plugins" if (root / "plugins").is_dir() else root
    man_path = root / "mirror_manifest.json"
    man = json.loads(man_path.read_text(encoding="utf-8")) if man_path.exists() else {}
    meta_by_name = {a["name"]: a for a in man.get("accepted", [])}

    out = Path(args.out)
    out_skills = out / "skills"
    if not args.dry_run:
        out_skills.mkdir(parents=True, exist_ok=True)

    used = existing_names(args.existing or cfg.get("skills_dir"))
    pre_existing = len(used)
    report = {"collisions": [], "dropped_hooks": [], "mcp": [], "excluded": []}
    all_made = []

    for d in sorted(pdir.iterdir()):
        if not d.is_dir() or d.name.startswith((".", "_")):
            continue
        inv = inventory(d)
        if inv["mcp_servers"] and not args.include_mcp:
            report["excluded"].append({"plugin": d.name, "why": "MCP 의존(폐쇄망 미동작)"})
            continue
        all_made += convert(d, meta_by_name.get(d.name, {}), cfg, out_skills,
                            used, args, report)

    kinds, cats = {}, {}
    for m in all_made:
        kinds[m["kind"]] = kinds.get(m["kind"], 0) + 1
        cats[m["category"]] = cats.get(m["category"], 0) + 1

    if not args.dry_run:
        with open(out / "skills_index.jsonl", "w", encoding="utf-8") as f:
            for m in all_made:
                f.write(json.dumps(m, ensure_ascii=False) + "\n")
        delta = {"kind": "demos-registry-delta", "version": 1,
                 "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                 "source_marketplace": man.get("marketplace"),
                 "prefix": cfg["prefix"], "collision": cfg["collision"],
                 "counts": {"skills": len(all_made), "by_kind": kinds, "by_category": cats},
                 "entries": [{k: v for k, v in m.items() if k != "routing_text"}
                             for m in all_made],
                 **report}
        (out / "demos_registry_delta.json").write_text(
            json.dumps(delta, ensure_ascii=False, indent=2), encoding="utf-8")

        L = ["# DEMOS 변환 보고서", "",
             "- 시각: %s" % time.strftime("%Y-%m-%d %H:%M"),
             "- 접두사: `%s` / 충돌정책: `%s`" % (cfg["prefix"], cfg["collision"]),
             "- 기존 스킬 %d개 인지 → 신규 %d개 추가 예정" % (pre_existing, len(all_made)),
             "", "## 유형별", ""]
        L += ["- %s: %d" % (k, v) for k, v in kinds.items()]
        L += ["", "## 분류별", ""] + ["- %s: %d" % (k, v) for k, v in sorted(cats.items())]
        L += ["", "## 스킬 목록", "", "| 스킬 | 유형 | 분류 | 원본 플러그인 | 위험도 |",
              "|---|---|---|---|--:|"]
        for m in all_made:
            L.append("| `%s` | %s | %s | %s | %d |" %
                     (m["name"], m["kind"], m["category"], m["plugin"], m["risk"]))
        if report["excluded"]:
            L += ["", "## 제외", ""] + ["- `%s` — %s" % (x["plugin"], x["why"])
                                        for x in report["excluded"]]
        if report["dropped_hooks"]:
            L += ["", "## hooks 미이식(의도적)", ""] + \
                 ["- `%s`" % x["plugin"] for x in report["dropped_hooks"]]
        if report["collisions"]:
            L += ["", "## 이름 충돌 스킵", ""] + \
                 ["- `%s` (%s)" % (x["name"], x["plugin"]) for x in report["collisions"]]
        L += ["", "## 다음 단계", "",
              "```bash",
              "python3 register.py %s --config %s --dry-run" % (out, args.config),
              "python3 register.py %s --config %s --apply" % (out, args.config),
              "```"]
        (out / "CONVERSION.md").write_text("\n".join(L), encoding="utf-8")

    print("변환 %d개 (%s)" % (len(all_made),
                             ", ".join("%s %d" % kv for kv in kinds.items())))
    print("분류: %s" % ", ".join("%s %d" % kv for kv in sorted(cats.items())))
    if report["excluded"]:
        print("제외 %d개 (MCP 의존): %s" %
              (len(report["excluded"]), ", ".join(x["plugin"] for x in report["excluded"][:6])))
    if report["collisions"]:
        print("충돌 스킵 %d개" % len(report["collisions"]))
    if not args.dry_run:
        print("스테이징: %s" % out)


if __name__ == "__main__":
    main()
