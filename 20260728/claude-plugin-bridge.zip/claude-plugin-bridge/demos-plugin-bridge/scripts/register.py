#!/usr/bin/env python3
"""
register.py - [폐쇄망] 스테이징된 스킬을 DEMOS 운영에 등록/철회한다.

설계 원칙: 되돌릴 수 있게. 등록 전 항상 백업을 뜨고, 백업 ID 하나로 원복한다.

사용:
  python3 register.py ./staging --config demos.config.json --dry-run   # 계획만
  python3 register.py ./staging --config demos.config.json --apply     # 실제 등록
  python3 register.py --config demos.config.json --list                # 백업 목록
  python3 register.py --config demos.config.json --rollback 20260810-0132
  python3 register.py --config demos.config.json --status              # 반입 스킬 현황

demos.config.json 예시:
{
  "skills_dir":   "/opt/demos/skills",
  "registry_path":"/opt/demos/skills/registry.json",
  "index_jsonl":  "/opt/demos/index/skills_index.jsonl",
  "backup_dir":   "/opt/demos/.skill_backups",
  "reindex_cmd":  "python3 /opt/demos/tools/build_index.py --input {index_jsonl}",
  "prefix": "cc"
}
reindex_cmd 는 --apply 시 실행한다(--no-reindex 로 생략 가능).
DEMOS 색인 빌더 경로는 환경에 맞게 채워 넣어야 한다.
"""
import argparse
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _core import parse_frontmatter  # noqa: E402


def load_cfg(p):
    if not Path(p).exists():
        sys.exit("설정 파일 없음: %s (README 의 예시로 만들어라)" % p)
    return json.loads(Path(p).read_text(encoding="utf-8"))


def read_registry(path):
    p = Path(path)
    if not p.exists():
        return {"skills": []}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        sys.exit("레지스트리 JSON 파손: %s" % path)
    if isinstance(d, list):
        d = {"skills": d}
    d.setdefault("skills", [])
    return d


def plan(staging, cfg):
    delta = json.loads((Path(staging) / "demos_registry_delta.json")
                       .read_text(encoding="utf-8"))
    sdir = Path(cfg["skills_dir"])
    add, overwrite, bad = [], [], []
    for e in delta["entries"]:
        src = Path(staging) / "skills" / e["name"]
        if not (src / "SKILL.md").exists():
            bad.append(e["name"])
            continue
        (overwrite if (sdir / e["name"]).exists() else add).append(e)
    return delta, add, overwrite, bad


def backup(cfg, names):
    bid = time.strftime("%Y%m%d-%H%M")
    bdir = Path(cfg["backup_dir"]) / bid
    bdir.mkdir(parents=True, exist_ok=True)
    sdir = Path(cfg["skills_dir"])
    saved = []
    for n in names:
        d = sdir / n
        if d.exists():
            shutil.copytree(d, bdir / "skills" / n)
            saved.append(n)
    files, absent = [], []
    for key in ("registry_path", "index_jsonl"):
        p = cfg.get(key)
        if not p:
            continue
        if Path(p).exists():
            shutil.copy2(p, bdir / Path(p).name)
            files.append(key)
        else:
            # 등록 전엔 없던 파일이다. 롤백 때는 "복원"이 아니라 "삭제"가 정답이다.
            absent.append(key)
    (bdir / "BACKUP.json").write_text(json.dumps(
        {"id": bid, "at": time.strftime("%Y-%m-%dT%H:%M:%S"),
         "overwritten_skills": saved, "files": files, "absent": absent},
        ensure_ascii=False, indent=2), encoding="utf-8")
    return bid, bdir


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("staging", nargs="?")
    ap.add_argument("--config", default="demos.config.json")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--rollback")
    ap.add_argument("--no-reindex", action="store_true")
    args = ap.parse_args()
    cfg = load_cfg(args.config)

    # --- 백업 목록 ---
    if args.list:
        bd = Path(cfg["backup_dir"])
        if not bd.exists():
            return print("백업 없음")
        for d in sorted(bd.iterdir(), reverse=True):
            f = d / "BACKUP.json"
            if f.exists():
                b = json.loads(f.read_text(encoding="utf-8"))
                print("%s  덮어쓴 스킬 %d개  %s" %
                      (b["id"], len(b["overwritten_skills"]), b["at"]))
        return

    # --- 현황 ---
    if args.status:
        sdir = Path(cfg["skills_dir"])
        rows = []
        for d in sorted(sdir.iterdir()) if sdir.exists() else []:
            f = d / "SKILL.md"
            if not f.exists():
                continue
            m, _ = parse_frontmatter(f.read_text(encoding="utf-8", errors="replace"))
            if m.get("origin_plugin"):
                rows.append((m.get("name", d.name), m.get("origin_kind", "?"),
                             m.get("demos_category", "?"), m.get("origin_plugin"),
                             m.get("imported_at", "?")))
        print("반입 스킬 %d개" % len(rows))
        for r in rows:
            print("  %-34s %-8s %-10s %-24s %s" % r)
        return

    # --- 롤백 ---
    if args.rollback:
        bdir = Path(cfg["backup_dir"]) / args.rollback
        if not bdir.exists():
            sys.exit("백업 없음: %s" % args.rollback)
        b = json.loads((bdir / "BACKUP.json").read_text(encoding="utf-8"))
        sdir = Path(cfg["skills_dir"])
        # 이 백업 이후 새로 들어간 스킬 제거
        delta_f = bdir / "APPLIED.json"
        if delta_f.exists():
            for n in json.loads(delta_f.read_text(encoding="utf-8")).get("added", []):
                shutil.rmtree(sdir / n, ignore_errors=True)
        for n in b["overwritten_skills"]:
            shutil.rmtree(sdir / n, ignore_errors=True)
            shutil.copytree(bdir / "skills" / n, sdir / n)
        for key in b.get("files", ["registry_path", "index_jsonl"]):
            p = cfg.get(key)
            if p and (bdir / Path(p).name).exists():
                shutil.copy2(bdir / Path(p).name, p)
        for key in b.get("absent", []):
            p = cfg.get(key)
            if p and Path(p).exists():
                Path(p).unlink()   # 등록 전엔 없던 파일 -> 지운다
        print("롤백 완료: %s (복원 %d, 제거 %s)" % (
            args.rollback, len(b["overwritten_skills"]),
            len(json.loads(delta_f.read_text(encoding="utf-8")).get("added", []))
            if delta_f.exists() else 0))
        # 색인 입력이 사라진 상태면 재색인을 돌리면 안 된다(빌더가 터진다).
        idx = cfg.get("index_jsonl")
        if not args.no_reindex and cfg.get("reindex_cmd") and (not idx or Path(idx).exists()):
            subprocess.run(cfg["reindex_cmd"].format(**cfg), shell=True, check=False)
        elif idx:
            print("색인 입력이 롤백으로 제거됨 — 재색인 생략. "
                  "운영 색인은 비어있는 상태가 정상이다.")
        return

    if not args.staging:
        ap.error("staging 경로 필요 (또는 --list/--status/--rollback)")
    delta, add, over, bad = plan(args.staging, cfg)

    print("=" * 60)
    print(" 등록 계획")
    print("=" * 60)
    print("신규   : %d개" % len(add))
    print("덮어씀 : %d개  %s" % (len(over), ", ".join(e["name"] for e in over[:8])))
    if bad:
        print("불량   : %d개 (SKILL.md 없음) %s" % (len(bad), ", ".join(bad[:8])))
    mcp = [e for e in delta["entries"] if e.get("requires_mcp")]
    if mcp:
        print("경고   : MCP 의존 %d개 — 폐쇄망에서 실행 실패한다: %s"
              % (len(mcp), ", ".join(e["name"] for e in mcp[:6])))
    print("분류   : %s" % json.dumps(delta["counts"]["by_category"], ensure_ascii=False))

    if not args.apply or args.dry_run:
        print("\n(dry-run) --apply 를 줘야 실제로 쓴다.")
        return
    if bad:
        sys.exit("불량 항목이 있어 중단. to_demos.py 부터 다시 해라.")

    bid, bdir = backup(cfg, [e["name"] for e in over])
    print("\n백업 생성: %s" % bdir)

    sdir = Path(cfg["skills_dir"])
    sdir.mkdir(parents=True, exist_ok=True)
    added = []
    for e in add + over:
        src = Path(args.staging) / "skills" / e["name"]
        dst = sdir / e["name"]
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(src, dst)
        added.append(e["name"])

    # 레지스트리 병합 (name 기준 upsert)
    if cfg.get("registry_path"):
        reg = read_registry(cfg["registry_path"])
        idx = {s.get("name"): i for i, s in enumerate(reg["skills"])}
        for e in delta["entries"]:
            rec = {"name": e["name"], "category": e["category"],
                   "description": e["description"], "kind": e["kind"],
                   "origin_plugin": e["plugin"], "risk": e["risk"],
                   "requires_mcp": e.get("requires_mcp", []),
                   "imported_at": time.strftime("%Y-%m-%d"), "source": "claude-plugins"}
            if e["name"] in idx:
                reg["skills"][idx[e["name"]]] = rec
            else:
                reg["skills"].append(rec)
        Path(cfg["registry_path"]).write_text(
            json.dumps(reg, ensure_ascii=False, indent=2), encoding="utf-8")
        print("레지스트리 갱신: %s (총 %d)" % (cfg["registry_path"], len(reg["skills"])))

    # 색인 입력 병합
    if cfg.get("index_jsonl"):
        ip = Path(cfg["index_jsonl"])
        ip.parent.mkdir(parents=True, exist_ok=True)
        keep = []
        if ip.exists():
            names = {e["name"] for e in delta["entries"]}
            for line in ip.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    o = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if o.get("name") not in names:
                    keep.append(line)
        new = (Path(args.staging) / "skills_index.jsonl").read_text(encoding="utf-8")
        ip.write_text("\n".join(keep + new.strip().splitlines()) + "\n", encoding="utf-8")
        print("색인 입력 갱신: %s" % ip)

    (bdir / "APPLIED.json").write_text(json.dumps(
        {"added": [n for n in added if n not in
                   {e["name"] for e in over}], "overwritten":
         [e["name"] for e in over]}, ensure_ascii=False, indent=2), encoding="utf-8")

    if not args.no_reindex and cfg.get("reindex_cmd"):
        cmd = cfg["reindex_cmd"].format(**cfg)
        print("재색인 실행: %s" % cmd)
        r = subprocess.run(cmd, shell=True)
        if r.returncode != 0:
            print("재색인 실패(코드 %d). 스킬 파일은 들어갔다. "
                  "수동 재색인하거나 --rollback %s 해라." % (r.returncode, bid))

    print("\n등록 완료. 롤백하려면: python3 register.py --config %s --rollback %s"
          % (args.config, bid))


if __name__ == "__main__":
    main()
