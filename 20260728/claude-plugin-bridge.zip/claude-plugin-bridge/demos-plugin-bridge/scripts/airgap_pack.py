#!/usr/bin/env python3
"""
airgap_pack.py - [외부망] 미러를 폐쇄망 반입용 단일 아티팩트로 묶는다.

기존 base64 반입 파이프라인(encoder.py / decoder.py, SHA256 검증)에 그대로 물린다.
여기서는 그 앞단인 "결정론적 tar.gz + 해시 + 분할"까지 책임진다.

사용:
  python3 airgap_pack.py ./mirror
  python3 airgap_pack.py ./mirror --out ./pack --split 45          # 45MB 분할
  python3 airgap_pack.py ./mirror --out ./pack --split 45 --b64    # base64 까지

출력:
  <out>/demos-plugins-YYYYMMDD.tar.gz          본체
  <out>/demos-plugins-YYYYMMDD.tar.gz.sha256   해시
  <out>/demos-plugins-YYYYMMDD.tar.gz.part000  분할본(--split)
  <out>/PACK_MANIFEST.json                     조각별 해시 + 원본 해시 + 파일수
  <out>/RESTORE.md                             폐쇄망 복원 절차서

결정론적 tar: mtime/uid/gid/uname/gname 을 0으로 고정하고 경로 정렬해서 담는다.
→ 같은 미러면 언제 말아도 같은 sha256 이 나온다. 재반입 시 diff 판단이 가능하다.
"""
import argparse
import base64
import gzip
import hashlib
import json
import os
import tarfile
import time
from pathlib import Path


def deterministic_tar(src, dst):
    src = Path(src)
    files = sorted([p for p in src.rglob("*") if p.is_file()],
                   key=lambda p: str(p.relative_to(src)))
    # gzip 헤더의 mtime 까지 0으로 고정해야 진짜 결정론이 된다.
    with open(dst, "wb") as raw, gzip.GzipFile(filename="", fileobj=raw, mode="wb",
                                               compresslevel=9, mtime=0) as gz, \
            tarfile.open(fileobj=gz, mode="w") as tf:
        for p in files:
            ti = tf.gettarinfo(str(p), arcname="%s/%s" % (src.name, p.relative_to(src)))
            ti.mtime, ti.uid, ti.gid = 0, 0, 0
            ti.uname, ti.gname = "", ""
            ti.mode = 0o644 if not os.access(p, os.X_OK) else 0o755
            with open(p, "rb") as f:
                tf.addfile(ti, f)
    return len(files)


def sha256(path, buf=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(buf)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def split(path, mb, out):
    parts, size, i = [], mb * 1024 * 1024, 0
    with open(path, "rb") as f:
        while True:
            chunk = f.read(size)
            if not chunk:
                break
            p = out / ("%s.part%03d" % (path.name, i))
            p.write_bytes(chunk)
            parts.append({"file": p.name, "bytes": len(chunk), "sha256": sha256(p)})
            i += 1
    return parts


RESTORE = """# 폐쇄망 복원 절차

## 0. 반입물
- `{tar}` (또는 `.part000...` 분할본)
- `{tar}.sha256`
- `PACK_MANIFEST.json`

## 1. 분할본 합치기 (분할 반입한 경우)
```bash
cat {tar}.part* > {tar}
```

## 2. 무결성 확인 — **여기서 다르면 그 자리에서 중단한다**
```bash
sha256sum -c {tar}.sha256
```
Windows:
```
certutil -hashfile {tar} SHA256
```

## 3. 전개
```bash
tar -xzf {tar}
```

## 4. 검증 게이트 (폐쇄망 측 필수)
```bash
python3 scripts/verify_import.py ./{root} --policy safe --report VERIFY.md
```
GO 판정이 아니면 등록 단계로 넘어가지 않는다.

## 5. DEMOS 변환·등록
```bash
python3 scripts/to_demos.py  ./{root} --out ./staging --config demos.config.json
python3 scripts/register.py  ./staging --config demos.config.json --dry-run
python3 scripts/register.py  ./staging --config demos.config.json --apply
```

## 6. 롤백
```bash
python3 scripts/register.py --config demos.config.json --rollback <backup-id>
```

---
생성: {ts} / 원본 파일 {files}개 / {bytes} bytes / sha256 `{sha}`
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mirror")
    ap.add_argument("--out", default="./pack")
    ap.add_argument("--name", default=None)
    ap.add_argument("--split", type=int, default=0, help="분할 크기(MB), 0=분할안함")
    ap.add_argument("--b64", action="store_true", help="base64 텍스트도 생성")
    args = ap.parse_args()

    src = Path(args.mirror)
    if not src.is_dir():
        raise SystemExit("미러 디렉토리 없음: %s" % src)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    base = args.name or "demos-plugins-%s" % time.strftime("%Y%m%d")
    tar = out / ("%s.tar.gz" % base)
    n = deterministic_tar(src, tar)
    digest = sha256(tar)
    (out / (tar.name + ".sha256")).write_text("%s  %s\n" % (digest, tar.name),
                                              encoding="utf-8")

    parts = split(tar, args.split, out) if args.split else []
    b64 = None
    if args.b64:
        b64 = out / (tar.name + ".b64")
        b64.write_text(base64.b64encode(tar.read_bytes()).decode(), encoding="utf-8")

    mirror_man = src / "mirror_manifest.json"
    summary = json.loads(mirror_man.read_text(encoding="utf-8")) if mirror_man.exists() else {}

    man = {
        "kind": "demos-airgap-pack", "version": 1,
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "archive": tar.name, "sha256": digest,
        "bytes": tar.stat().st_size, "file_count": n,
        "root_dir": src.name,
        "parts": parts,
        "base64": b64.name if b64 else None,
        "mirror_summary": {"counts": summary.get("counts"),
                           "policy": summary.get("policy"),
                           "accepted": [a["name"] for a in summary.get("accepted", [])]},
    }
    (out / "PACK_MANIFEST.json").write_text(
        json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "RESTORE.md").write_text(RESTORE.format(
        tar=tar.name, root=src.name, ts=man["generated_at"], files=n,
        bytes=man["bytes"], sha=digest), encoding="utf-8")

    print("아카이브 : %s (%.1f MB, 파일 %d개)" % (tar, man["bytes"] / 1e6, n))
    print("sha256   : %s" % digest)
    if parts:
        print("분할     : %d조각" % len(parts))
    if b64:
        print("base64   : %s (%.1f MB) — 기존 decoder.py 로 복원 가능" %
              (b64, b64.stat().st_size / 1e6))
    print("절차서   : %s" % (out / "RESTORE.md"))


if __name__ == "__main__":
    main()
