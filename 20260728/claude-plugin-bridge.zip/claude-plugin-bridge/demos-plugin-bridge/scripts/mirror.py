#!/usr/bin/env python3
"""
mirror.py - [외부망 전용] 공식 마켓플레이스를 선별 미러링한다.

인터넷 되는 PC에서 돌린다. git 불필요(codeload tar.gz). 원격 소스 231건이
전부 github + 전부 sha 고정이라 재현 가능한 미러가 나온다.

사용:
  python3 mirror.py --internal --out ./mirror                  # Anthropic 자체 38개
  python3 mirror.py --policy safe --out ./mirror               # 폐쇄망 안전 정책 자동 선별
  python3 mirror.py --name claude-md-management --name skill-creator --out ./mirror
  python3 mirror.py --all --out ./mirror                       # 284개 전량 (수 GB)

--policy safe 가 하는 일 (폐쇄망 기본값 권장):
  · MCP 서버 있는 플러그인 제외      (폐쇄망에서 100% 실패한다)
  · hooks 있는 플러그인 제외         (무단 자동실행)
  · 위험도 임계 초과 제외            (--max-risk, 기본 30)
  제외 사유는 mirror_manifest.json 에 전부 남는다.

출력:
  <out>/plugins/<name>/...
  <out>/mirror_manifest.json     소스/sha/트리해시/제외사유/정책
  <out>/marketplace.json         원본 카탈로그 스냅샷 (폐쇄망 조회용)
"""
import argparse
import json
import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _core import (extract_subpath, fetch_tarball, human, inventory,  # noqa: E402
                   load_marketplace, resolve_source, risk_score,
                   sha256_dir, sha256_file)


def select(mk, args):
    P = mk.get("plugins", [])
    ren = mk.get("renames", {})
    if args.name:
        want = {ren.get(w, w) for w in args.name}
        P = [p for p in P if p["name"] in want]
        miss = want - {p["name"] for p in P}
        if miss:
            print("경고: 카탈로그에 없음 -> %s" % ", ".join(sorted(miss)), file=sys.stderr)
    if args.internal:
        P = [p for p in P if "anthropic" in json.dumps(p.get("author", {})).lower()]
    if args.category:
        cats = {c.strip() for c in args.category.split(",")}
        P = [p for p in P if p.get("category") in cats]
    if args.exclude:
        ex = {e.strip() for e in args.exclude.split(",")}
        P = [p for p in P if p["name"] not in ex]
    if args.limit:
        P = P[:args.limit]
    return P


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--marketplace", default=None)
    ap.add_argument("--cache", default=".cache/marketplace.json")
    ap.add_argument("--tarcache", default=".cache/tarballs")
    ap.add_argument("--name", action="append")
    ap.add_argument("--category")
    ap.add_argument("--exclude", help="쉼표구분 제외 목록")
    ap.add_argument("--internal", action="store_true")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--limit", type=int)
    ap.add_argument("--out", default="./mirror")
    ap.add_argument("--policy", choices=["safe", "none"], default="safe")
    ap.add_argument("--max-risk", type=int, default=30)
    ap.add_argument("--keep-rejected", action="store_true",
                    help="정책 위반도 격리 폴더에 남긴다(검토용)")
    args = ap.parse_args()

    if not (args.name or args.category or args.internal or args.all):
        ap.error("--name / --category / --internal / --all 중 하나 필요")

    mk = load_marketplace(args.marketplace, args.cache)
    P = select(mk, args)
    out = Path(args.out)
    pdir = out / "plugins"
    rdir = out / "_rejected"
    pdir.mkdir(parents=True, exist_ok=True)
    print("대상 %d개 / 정책 %s (max-risk %d)" % (len(P), args.policy, args.max_risk),
          file=sys.stderr)

    accepted, rejected = [], []
    for i, p in enumerate(P, 1):
        name = p["name"]
        try:
            r = resolve_source(p)
            tb = fetch_tarball(r["owner"], r["repo"], r["ref"], args.tarcache)
            dest = pdir / name
            n = extract_subpath(tb, r["subpath"], dest)
            if n == 0:
                raise RuntimeError("subpath 비어있음: %s" % r["subpath"])

            inv = inventory(dest)
            score = risk_score(inv)
            reasons = []
            if args.policy == "safe":
                if inv["mcp_servers"]:
                    reasons.append("MCP 서버 의존(%s)" %
                                   ",".join(s["name"] for s in inv["mcp_servers"]))
                if inv["hooks"]:
                    reasons.append("hooks 포함(%d개)" % len(inv["hooks"]))
                if score > args.max_risk:
                    reasons.append("위험도 %d > %d" % (score, args.max_risk))
            if reasons:
                if args.keep_rejected:
                    rdir.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(dest), str(rdir / name))
                else:
                    shutil.rmtree(dest, ignore_errors=True)
                rejected.append({"name": name, "risk": score, "reasons": reasons,
                                 "repo": "%s/%s" % (r["owner"], r["repo"]), "ref": r["ref"]})
                print("[%3d/%3d] REJ  %-34s %s" % (i, len(P), name[:34],
                                                   "; ".join(reasons)), file=sys.stderr)
                continue

            accepted.append({
                "name": name, "category": p.get("category"),
                "description": p.get("description", ""),
                "author": p.get("author"), "homepage": p.get("homepage"),
                "strict": p.get("strict"), "declared_skills": p.get("skills"),
                "source_kind": r["kind"], "repo": "%s/%s" % (r["owner"], r["repo"]),
                "ref": r["ref"], "subpath": r["subpath"], "pinned": r["pinned"],
                "files": n, "risk": score,
                "counts": {"skills": len(inv["skills"]), "commands": len(inv["commands"]),
                           "agents": len(inv["agents"])},
                "tree_sha256": sha256_dir(dest), "tarball_sha256": sha256_file(tb),
            })
            print("[%3d/%3d] OK   %-34s s%-2d c%-2d a%-2d risk%3d" % (
                i, len(P), name[:34], len(inv["skills"]), len(inv["commands"]),
                len(inv["agents"]), score), file=sys.stderr)
        except Exception as e:  # noqa: BLE001
            rejected.append({"name": name, "reasons": ["오류: %s" % e]})
            print("[%3d/%3d] FAIL %-34s %s" % (i, len(P), name[:34], e), file=sys.stderr)

    (out / "marketplace.json").write_text(
        json.dumps(mk, ensure_ascii=False, indent=1), encoding="utf-8")
    total = sum(f.stat().st_size for f in pdir.rglob("*") if f.is_file())
    man = {
        "kind": "demos-plugin-mirror", "version": 1,
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "marketplace": mk.get("name"),
        "policy": {"mode": args.policy, "max_risk": args.max_risk},
        "counts": {"selected": len(P), "accepted": len(accepted),
                   "rejected": len(rejected)},
        "total_bytes": total,
        "accepted": accepted, "rejected": rejected,
    }
    (out / "mirror_manifest.json").write_text(
        json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8")

    shutil.rmtree(args.tarcache, ignore_errors=True)
    print("\n미러 완료: 채택 %d / 반려 %d / %s" % (len(accepted), len(rejected), human(total)),
          file=sys.stderr)
    print("다음: python3 airgap_pack.py %s" % out, file=sys.stderr)


if __name__ == "__main__":
    main()
