#!/usr/bin/env python3
"""
verify_import.py - [폐쇄망] 반입물 검증 게이트. GO / NO-GO 를 판정한다.

등록 전 마지막 관문이다. 여기서 GO 안 나오면 to_demos.py 로 넘어가지 않는다.

검사 항목
  1. 트리 무결성   미러 매니페스트의 tree_sha256 과 현재 트리 재계산값 대조
  2. 정책 위반     MCP 서버 / hooks / 위험도 임계
  3. 외부 의존     외부 호스트 하드코딩, 패키지 설치 명령, 원격 실행
  4. 프롬프트 위생 지시 무력화·유출 유도 문구
  5. 비밀정보      내부 IP / 토큰 패턴 (반입물에 섞여 들어오면 안 됨)

사용:
  python3 verify_import.py ./mirror --report VERIFY.md
  python3 verify_import.py ./mirror --policy safe --max-risk 30 --json
  python3 verify_import.py ./mirror --allow hooks         # 예외 승인(사유 기록됨)

종료코드: 0=GO, 2=NO-GO
"""
import argparse
import json
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _core import inventory, risk_score, sha256_dir  # noqa: E402

PROMPT_INJECTION = [
    (r"ignore\s+(all\s+)?(previous|above|prior)\s+(instructions|rules)", "지시 무력화"),
    (r"disregard\s+(the\s+)?(system|previous)", "지시 무력화"),
    (r"(exfiltrat|leak)\w*\s+(data|file|secret|key)", "유출 유도"),
    (r"send\s+(the\s+)?(file|content|data)\s+to\s+https?://", "외부 전송 유도"),
    (r"reveal\s+(your\s+)?(system\s+prompt|instructions)", "시스템 프롬프트 탈취"),
]
SECRETS = [
    (r"\bsk-[A-Za-z0-9]{20,}", "API 키 패턴"),
    (r"(?i)(password|passwd|pwd)\s*[=:]\s*['\"][^'\"]{4,}", "비밀번호 하드코딩"),
    (r"\b10\.30\.\d{1,3}\.\d{1,3}\b", "사내 IP 대역"),
    (r"(?i)ghp_[A-Za-z0-9]{30,}", "GitHub 토큰"),
]
EXT = {".md", ".py", ".sh", ".js", ".ts", ".json", ".yaml", ".yml", ".toml", ".txt"}


def scan_text(root):
    hits = []
    for f in Path(root).rglob("*"):
        if not f.is_file() or f.suffix.lower() not in EXT:
            continue
        try:
            if f.stat().st_size > 2_000_000:
                continue
            t = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for rx, label in PROMPT_INJECTION:
            m = re.search(rx, t, re.I)
            if m:
                hits.append({"type": "prompt", "label": label, "file": str(f),
                             "line": t.count("\n", 0, m.start()) + 1,
                             "snippet": t[m.start():m.start() + 100].replace("\n", " ")})
        for rx, label in SECRETS:
            m = re.search(rx, t)
            if m:
                hits.append({"type": "secret", "label": label, "file": str(f),
                             "line": t.count("\n", 0, m.start()) + 1,
                             "snippet": "***마스킹***"})
    return hits


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mirror")
    ap.add_argument("--policy", choices=["safe", "loose"], default="safe")
    ap.add_argument("--max-risk", type=int, default=30)
    ap.add_argument("--allow", action="append", default=[],
                    choices=["hooks", "mcp", "risk", "prompt"],
                    help="예외 승인 (사유가 리포트에 남는다)")
    ap.add_argument("--report", default=None)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    root = Path(args.mirror)
    pdir = root / "plugins" if (root / "plugins").is_dir() else root
    man_path = root / "mirror_manifest.json"
    man = json.loads(man_path.read_text(encoding="utf-8")) if man_path.exists() else None

    results, blockers = [], []

    # 1) 트리 무결성
    integrity = {"checked": 0, "ok": 0, "mismatch": [], "missing": [], "extra": []}
    if man:
        expected = {a["name"]: a["tree_sha256"] for a in man.get("accepted", [])}
        present = {d.name for d in pdir.iterdir() if d.is_dir()}
        integrity["missing"] = sorted(set(expected) - present)
        integrity["extra"] = sorted(present - set(expected))
        for name, exp in expected.items():
            d = pdir / name
            if not d.is_dir():
                continue
            integrity["checked"] += 1
            got = sha256_dir(d)
            if got == exp:
                integrity["ok"] += 1
            else:
                integrity["mismatch"].append({"name": name, "expected": exp[:16],
                                              "got": got[:16]})
        if integrity["mismatch"]:
            blockers.append("트리 해시 불일치 %d건 — 반입물이 변조되었거나 전송이 깨졌다"
                            % len(integrity["mismatch"]))
        if integrity["extra"]:
            blockers.append("매니페스트에 없는 플러그인 %d개 발견: %s"
                            % (len(integrity["extra"]), ", ".join(integrity["extra"][:5])))
    else:
        blockers.append("mirror_manifest.json 없음 — 출처 추적 불가")

    # 2) 플러그인별 정책
    for d in sorted(pdir.iterdir()):
        if not d.is_dir() or d.name.startswith((".", "_")):
            continue
        inv = inventory(d)
        score = risk_score(inv)
        v = []
        if inv["mcp_servers"] and "mcp" not in args.allow:
            v.append("MCP 서버 %s (폐쇄망 동작 불가)" %
                     ",".join(s["name"] for s in inv["mcp_servers"]))
        if inv["hooks"] and "hooks" not in args.allow:
            v.append("hooks %d개 (무단 자동실행)" % len(inv["hooks"]))
        if score > args.max_risk and "risk" not in args.allow:
            v.append("위험도 %d > %d" % (score, args.max_risk))
        results.append({"name": d.name, "risk": score,
                        "skills": len(inv["skills"]), "commands": len(inv["commands"]),
                        "agents": len(inv["agents"]),
                        "mcp": [s["name"] for s in inv["mcp_servers"]],
                        "hooks": len(inv["hooks"]), "violations": v,
                        "top_risks": inv["risks"][:5]})
        if v and args.policy == "safe":
            blockers.append("%s: %s" % (d.name, "; ".join(v)))

    # 3) 텍스트 위생
    hits = scan_text(pdir)
    prompt_hits = [h for h in hits if h["type"] == "prompt"]
    secret_hits = [h for h in hits if h["type"] == "secret"]
    if prompt_hits and "prompt" not in args.allow:
        blockers.append("프롬프트 인젝션 의심 %d건 — 사람이 직접 읽어야 한다" % len(prompt_hits))
    if secret_hits:
        blockers.append("비밀정보/사내정보 패턴 %d건 — 반입물에 있으면 안 된다" % len(secret_hits))

    verdict = "GO" if not blockers else "NO-GO"
    payload = {"verdict": verdict, "checked_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
               "policy": args.policy, "max_risk": args.max_risk,
               "exceptions": args.allow, "integrity": integrity,
               "blockers": blockers, "plugins": results,
               "prompt_hits": prompt_hits, "secret_hits": secret_hits}

    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print("=" * 66)
        print(" 반입 검증 결과: %s" % verdict)
        print("=" * 66)
        if man:
            print("무결성: %d/%d 일치, 누락 %d, 초과 %d"
                  % (integrity["ok"], integrity["checked"],
                     len(integrity["missing"]), len(integrity["extra"])))
        print("플러그인 %d개 / 위반 %d개 / 인젝션의심 %d / 비밀정보 %d"
              % (len(results), sum(1 for r in results if r["violations"]),
                 len(prompt_hits), len(secret_hits)))
        if blockers:
            print("\n[차단 사유]")
            for b in blockers[:20]:
                print("  ✗ %s" % b)
        if args.allow:
            print("\n[예외 승인] %s — 승인자가 책임진다" % ", ".join(args.allow))

    if args.report:
        L = ["# 반입 검증 리포트", "", "**판정: %s**" % verdict,
             "", "- 검증시각: %s" % payload["checked_at"],
             "- 정책: %s / 위험도 상한 %d" % (args.policy, args.max_risk),
             "- 예외 승인: %s" % (", ".join(args.allow) or "없음"), ""]
        if blockers:
            L += ["## 차단 사유", ""] + ["- %s" % b for b in blockers] + [""]
        L += ["## 플러그인별", "",
              "| 플러그인 | 스킬 | 커맨드 | 에이전트 | MCP | 훅 | 위험도 | 위반 |",
              "|---|--:|--:|--:|--:|--:|--:|---|"]
        for r in results:
            L.append("| %s | %d | %d | %d | %d | %d | %d | %s |" % (
                r["name"], r["skills"], r["commands"], r["agents"],
                len(r["mcp"]), r["hooks"], r["risk"],
                "; ".join(r["violations"]) or "-"))
        if prompt_hits:
            L += ["", "## 프롬프트 인젝션 의심", ""]
            for h in prompt_hits[:30]:
                L.append("- `%s:%d` [%s] `%s`" % (h["file"], h["line"], h["label"],
                                                  h["snippet"][:80]))
        if secret_hits:
            L += ["", "## 비밀정보 패턴", ""]
            for h in secret_hits[:30]:
                L.append("- `%s:%d` [%s]" % (h["file"], h["line"], h["label"]))
        Path(args.report).write_text("\n".join(L), encoding="utf-8")
        print("\n리포트: %s" % args.report)

    sys.exit(0 if verdict == "GO" else 2)


if __name__ == "__main__":
    main()
