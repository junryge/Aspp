# Claude Plugin Bridge 번들

Claude Code 공식 플러그인 마켓플레이스(`anthropics/claude-plugins-official`, 284개)를
**가져오고 · 바꾸고 · 내보내는** 툴킷. 2개 스킬이 들어있다.

의존성 0. python3.8+ 만 있으면 된다. pip / Docker / Node 전부 필요 없다.

---

## 뭘 써야 하나 — 인터넷 되냐 안 되냐로 갈린다

| | `claude-plugin-kit` (일반) | `demos-plugin-bridge` (DEMOS) |
|---|---|---|
| PC | 1대, 인터넷 됨 | 2대 (외부망 → 폐쇄망) |
| 결과물 | 내 폴더 / `.skill` / git | DEMOS skills_dir + registry + 색인 |
| 검사 | 위험도 리포트 (판단은 사람) | **GO/NO-GO 게이트** — 불합격이면 중단 |
| MCP·hooks | 알려만 줌 | **자동 제외** (폐쇄망에서 어차피 안 돔) |
| 되돌리기 | 폴더 지우면 끝 | 백업 ID 롤백 (색인·레지스트리까지) |

- 회사 폐쇄망 DEMOS에 넣는다 → **demos-plugin-bridge**
- 집 PC / 노트북 Claude Code → **claude-plugin-kit**
- 인터넷 되는 동료한테 스킬 준다 → **claude-plugin-kit**
- DEMOS 스킬을 사내 사람들이 쓰게 한다 → **demos-plugin-bridge 의 `export_demos.py`**

일반 버전이 원형이고, DEMOS 버전은 거기에 **반입 포장 + 검증 게이트 + 등록/롤백**
셋을 덧붙인 것이다. 그 셋은 폐쇄망 아니면 필요 없어서 따로 뺐다.

---

## 빠른 시작

### 일반 (3줄)

```bash
cd claude-plugin-kit
python3 scripts/market.py stats
python3 scripts/fetch_plugin.py --name claude-md-management --out ./vendor
python3 scripts/inspect_plugin.py ./vendor --all --format md > REPORT.md
```

### DEMOS (5줄)

```bash
cd demos-plugin-bridge
cp assets/demos.config.sample.json demos.config.json   # ★ 경로 먼저 채워라 (아래 참고)

# ── [외부망 PC] ──
python3 scripts/mirror.py --internal --out ./mirror
python3 scripts/airgap_pack.py ./mirror --out ./pack --split 45

# ── pack/ 을 폐쇄망으로 반입 (base64 라인 쓰면 --b64 추가) ──

# ── [폐쇄망] ──
cat pack/*.part* > x.tar.gz && sha256sum -c pack/*.sha256 && tar -xzf x.tar.gz
python3 scripts/verify_import.py ./mirror --report VERIFY.md      # 0=GO, 2=NO-GO
python3 scripts/to_demos.py ./mirror --out ./staging --config demos.config.json
python3 scripts/register.py ./staging --config demos.config.json --dry-run
python3 scripts/register.py ./staging --config demos.config.json --apply
```

`verify_import.py` 가 GO 안 주면 **거기서 멈춰라.** 그게 게이트가 있는 이유다.

---

## 시작 전 필수 설정 (DEMOS만)

`demos.config.json` 에서 두 가지를 반드시 고친다.

1. **경로** — `skills_dir`, `registry_path`, `index_jsonl`, `backup_dir`
2. **`reindex_cmd`** — DEMOS 색인 빌더 실행 명령.
   **비워두면 스킬은 들어가는데 라우터가 못 찾는다.**

`category_map` 은 지금 영문 직역이라 DEMOS 분류 체계에 맞게 손보면 좋다. 급하면 나중에.

---

## 스킬로 설치해서 쓰려면

깔아두면 "공식 마켓에서 productivity 받아서 DEMOS에 넣어줘" 식으로 시킬 수 있다.

| 어디에 | 방법 |
|---|---|
| claude.ai / Cowork | 동봉된 `.skill` 업로드 → **Save skill** |
| Claude Code | 폴더째 `.claude/skills/` (프로젝트) 또는 `~/.claude/skills/` (전역) |
| DEMOS | DEMOS 스킬 디렉토리에 폴더 복사 후 재색인 |

---

## 설계 근거 (2026-08-10 카탈로그 284건 전수 실측)

- 원격 소스 **231건 전부 github.com**, 비-github 0건
- 원격 소스 **231/231 전부 커밋 sha 고정**
- Anthropic 자체 38 / 서드파티 246
- source 타입: url 146, git-subdir 83, self-repo 53, github 2
- 카테고리: development 119, productivity 49, database 37, monitoring 20, security 18, 기타

→ **git 없이 `codeload.github.com/{owner}/{repo}/tar.gz/{sha}` 만으로 카탈로그 100%를
재현 가능하게 받을 수 있다.** 폐쇄망 반입이 성립하는 근거가 이거다.
같은 sha 면 언제 받아도 같은 트리라서 무결성을 해시로 증명할 수 있다.

---

## 검증 완료 항목

실제로 돌려서 확인한 것들이다.

- source 4종(str/git-subdir/url/github) 전부 다운로드 성공
- 플러그인 8개 → 스킬 34개 변환 (skill 17 / agent 14 / command 3)
- 결정론 tar: 서로 다른 시각 2회 실행 → sha256 동일
- 분할 → 합체 → 해시검증 → 전개 → GO 판정 전 구간
- 기존 동명 스킬 충돌 시 `cc-skill-creator-2` 자동 회피
- 17개 등록 → 롤백 → 원래 상태 완전 복구 (색인·레지스트리 포함)
- 사내정보(`10.30.11.133`, `M16MCSPP`) 박힌 스킬은 내보내기에서 자동 차단

작업 중 잡은 버그 3건: gzip 헤더 mtime 때문에 tar 가 비결정론적이던 것,
롤백 후 색인에 유령 스킬이 남던 것, `make_marketplace.py` 인자 dest 충돌. 셋 다 수정·재검증.

---

## 첫 실행 권장 순서

1. **`--internal` 38개로 시작.** 284개 전량은 수 GB고 서드파티 검토 부담이 크다
2. 반입 전에 `mirror_manifest.json` 의 반려 목록 훑기
3. 등록은 무조건 `--dry-run` 먼저
4. 등록 후 출력되는 **백업 ID 적어둘 것** — 롤백 티켓이다
5. DEMOS UI 에서 검색 2~3건 때려보고 라우터가 새 스킬 무는지 확인

---

## 반드시 지킬 것

1. **`name` 은 불변 슬러그.** 배포 후 바꾸면 남의 설치가 `plugin-not-found` 로 깨진다.
   표시명은 `displayName`, 불가피하면 마켓 최상위 `renames` 맵.
2. **MCP 의존 플러그인은 폐쇄망 반입 금지.** 목록엔 뜨는데 실행이 반드시 실패한다.
3. **hooks 는 이식 금지.** 사용자 확인 없이 자동 실행된다.
4. **sha 고정으로만 받아라.** `ref: main` 은 어제와 오늘이 다르다.
5. **재배포 시 원본 LICENSE 동봉.** 마켓 레포는 Apache-2.0 이지만 각 플러그인은 자기 라이선스를 따른다.

---

## 문서 위치

| 찾는 것 | 파일 |
|---|---|
| 반입 절차·체크리스트·장애 대응 | `demos-plugin-bridge/references/airgap-runbook.md` |
| 분류 매핑·이름 충돌·색인 통합 | `demos-plugin-bridge/references/demos-mapping.md` |
| plugin.json / marketplace.json 스키마 | `*/references/plugin-spec.md` |
| 스킬 작성·배포 가이드 | `claude-plugin-kit/references/authoring.md` |
| 설치 전 보안 점검 | `claude-plugin-kit/references/security.md` |

모든 스크립트에 `--help` 가 붙어있다. `python3 scripts/mirror.py --help`

---

## 전체 구성

```
claude-plugin-bridge/
├── README.md                      ← 지금 이 파일
├── claude-plugin-kit.skill        ← claude.ai 업로드용
├── demos-plugin-bridge.skill      ← claude.ai 업로드용
│
├── claude-plugin-kit/             [일반] 인터넷 환경
│   ├── SKILL.md
│   ├── scripts/
│   │   ├── _core.py               공용 코어
│   │   ├── market.py              탐색/검색/통계
│   │   ├── fetch_plugin.py        다운로드 (git 불필요)
│   │   ├── inspect_plugin.py      해부 + 위험도 리포트
│   │   ├── to_skills.py           플러그인 → 이식형 SKILL.md
│   │   ├── make_marketplace.py    → marketplace.json 배포
│   │   └── package_skill.py       린트 + .skill 패키징
│   └── references/{plugin-spec,authoring,security}.md
│
└── demos-plugin-bridge/           [DEMOS] 폐쇄망
    ├── SKILL.md
    ├── scripts/
    │   ├── _core.py               공용 코어
    │   ├── mirror.py              [외부망] 선별 미러 + 안전정책 필터
    │   ├── airgap_pack.py         [외부망] 결정론 tar + SHA256 + 분할 + base64
    │   ├── verify_import.py       [폐쇄망] GO/NO-GO 검증 게이트
    │   ├── to_demos.py            [폐쇄망] 변환 + 분류매핑 + 충돌해결
    │   ├── register.py            [폐쇄망] 백업·등록·재색인·롤백
    │   └── export_demos.py        [역방향] 사내 배포 (유출검사 포함)
    ├── assets/demos.config.sample.json
    └── references/{airgap-runbook,demos-mapping,plugin-spec}.md
```
