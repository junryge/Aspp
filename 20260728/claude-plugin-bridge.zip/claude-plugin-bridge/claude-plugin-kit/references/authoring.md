# 플러그인·스킬 작성 및 배포 가이드

## 1. 스킬이 실패하는 진짜 이유

로직이 아니라 **안 켜져서** 실패한다. 스킬은 3단 로딩이다.

| 단계 | 내용 | 항상 컨텍스트에? |
|---|---|---|
| 1 | name + description | ✅ 항상 |
| 2 | SKILL.md 본문 | 스킬이 켜졌을 때만 |
| 3 | references / scripts / assets | 필요할 때만 (스크립트는 안 읽고 실행 가능) |

1단계 100단어가 스킬의 운명을 결정한다. 본문을 아무리 잘 써도 description 이 약하면
영원히 2단계로 못 간다.

## 2. description 쓰는 법

**나쁨**
```
description: CLAUDE.md 파일을 관리합니다.
```

**좋음** (실제 공식 플러그인 것)
```
description: Audit and improve CLAUDE.md files in repositories. Use when user asks
to check, audit, update, improve, or fix CLAUDE.md files. Scans for all CLAUDE.md
files, evaluates quality against templates, outputs quality report, then makes
targeted updates. Also use when the user mentions 'CLAUDE.md maintenance' or
'project memory optimization'.
```

공식이 지키는 패턴:
1. **무엇을 하는지** 한 문장
2. **언제 켜는지** — "Use when user asks to ..." + 동사 나열 (check, audit, update, improve, fix)
3. **어떻게 하는지** 요약
4. **추가 트리거** — "Also use when the user mentions '...'"

모델은 스킬을 **과소 트리거**하는 경향이 있다. 그래서 description 은 좀 **밀어붙여 써야** 한다.
"~할 때 반드시 이 스킬을 쓴다" 같은 표현이 실제로 효과 있다.

길이 감각: 60자 미만이면 부족, 1024자 초과면 과하다. 200~400자가 스윗스팟.

## 3. SKILL.md 본문 규칙

- **500줄 이하.** 넘으면 `references/` 로 계층을 하나 더 판다.
- 참조 파일은 **언제 읽어야 하는지**를 본문에 명시한다. "필요하면 봐라"는 안 읽힌다.
- 300줄 넘는 참조 파일에는 목차를 단다.
- 도메인이 여러 개면 변형별로 쪼갠다:
  ```
  cloud-deploy/
  ├── SKILL.md          (워크플로 + 선택 기준)
  └── references/
      ├── aws.md
      ├── gcp.md
      └── azure.md
  ```
- 반복적·결정론적 작업은 **본문에 설명 말고 `scripts/` 에 실행파일로** 둔다.
  스크립트는 컨텍스트를 안 먹고 실행된다.

## 4. 놀라움 없음의 원칙

스킬 이름·설명·동작이 어긋나면 안 된다. `pdf-tools` 인데 워드 문서를 건드리거나,
"읽기 전용"이라 해놓고 파일을 쓰면 신뢰가 무너진다.
**파일을 쓰는 스킬은 description 에 그 사실을 밝힌다.**
공식 `claude-md-improver` 도 "This skill can write to CLAUDE.md files" 를 명시하고,
품질 리포트를 먼저 내고 승인받은 뒤에만 수정한다.

## 5. 커맨드 vs 에이전트 vs 스킬

| | 트리거 | 용도 |
|---|---|---|
| 슬래시 커맨드 | 사용자가 `/이름` 명시 호출 | 정해진 절차 실행 |
| 서브에이전트 | 오케스트레이터가 위임 | 격리된 컨텍스트에서 전문 작업 |
| 스킬 | 모델이 description 보고 자율 판단 | 능력 확장 |

**이식할 때의 함정**: 커맨드/에이전트는 "누가 불러줘서" 도는 물건이라 트리거 문장이 없다.
스킬로 옮기면 자율 판단 대상이 되므로 **트리거 문장을 새로 써 줘야** 한다.
`to_skills.py` 가 기계적으로 하나 붙여주지만, 사람이 다듬는 게 정답이다.

## 6. 버저닝·업데이트 전략

### 배포하는 쪽
- `plugin.json` 의 `version` 은 semver. 스킬 동작이 바뀌면 minor, 호환 깨지면 major.
- `name` 은 **절대 안 바꾼다**. 표시명은 `displayName`, 불가피하면 `renames`.
- 마켓 엔트리 `source` 에 **sha 를 박는다.** `ref: main` 만 두면 사용자가 받을 때마다
  다른 코드가 나온다. 공식 카탈로그가 231/231 전부 sha 를 박아둔 이유다.

### 가져다 쓰는 쪽
- `_fetch_manifest.json` 의 `ref` / `tree_sha256` 를 보관한다.
- 업데이트는 "다시 받아서 sha 비교" 로 한다:
  ```bash
  python3 scripts/fetch_plugin.py --name X --out ./vendor.new
  diff <(jq -S .plugins ./vendor/_fetch_manifest.json) \
       <(jq -S .plugins ./vendor.new/_fetch_manifest.json)
  ```
- 변환한 스킬에는 `origin_version` 이 박혀 있다. 원본이 올라갔는데 이게 옛날 버전이면
  재변환 대상이다.

## 7. 이름 짓기

- 슬러그: 소문자 + 하이픈. `[a-z0-9][a-z0-9-]*`
- **폴더명 == frontmatter `name`** 으로 맞춘다. 어긋나면 참조가 꼬인다.
- 남의 것을 가져와 섞을 때는 `--prefix` 로 네임스페이스를 준다.
  예: `cc-code-reviewer`, `amhs-hubroom-analyzer`
- 충돌 정책은 셋 중 하나를 의식적으로 고른다: `suffix`(자동 -2), `skip`, `overwrite`.
  기존 스킬 수백 개 있는 플랫폼에 붓는다면 `--prefix` + `skip` 이 안전하다.

## 8. 배포 형태 고르기

| 상황 | 방법 |
|---|---|
| 스킬만 여러 개, 커맨드/MCP 없음 | `--mode bundle` (strict:false + skills[]) — 제일 간단 |
| 커맨드·에이전트·MCP 포함 | `--mode plugins` (폴더별 plugin.json) |
| claude.ai / Cowork 개인 사용 | `package_skill.py` 로 `.skill` |
| 사내 폐쇄망 플랫폼 | DEMOS 브리지 버전 쓸 것 |

## 9. 배포 전 체크리스트

- [ ] `package_skill.py --all --lint-only` 통과
- [ ] description 에 "언제"가 들어있다
- [ ] 폴더명 == name
- [ ] 본문 500줄 이하, 참조 파일 전부 실존
- [ ] 파일을 쓰는 스킬이면 그 사실을 description 에 명시
- [ ] 자격증명·내부 호스트명·사번 등이 안 섞였다 (`grep -ri "sk-\|password\|10\.30\." .`)
- [ ] 라이선스 확인 — 남의 플러그인을 재배포하면 원본 LICENSE 를 동봉한다
      (공식 마켓은 Apache-2.0 이지만 **각 플러그인은 자기 라이선스를 따른다**)
