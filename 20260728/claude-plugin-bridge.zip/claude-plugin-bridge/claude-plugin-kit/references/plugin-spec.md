# plugin.json / marketplace.json 스펙

2026-08-10 기준 `anthropics/claude-plugins-official` **실제 카탈로그 284건을 파싱해서** 정리.
추측 아니라 실측이다.

## 목차
1. 플러그인 디렉토리 구조
2. plugin.json
3. marketplace.json
4. source 4종 (실제 예시)
5. 스킬 번들형 (strict:false)
6. renames — 이름 불변 규칙
7. 필드 사용 빈도 실측

---

## 1. 플러그인 디렉토리 구조

```
plugin-name/
├── .claude-plugin/
│   └── plugin.json      # 메타데이터 (필수)
├── .mcp.json            # MCP 서버 설정 (선택)
├── commands/            # 슬래시 커맨드 (선택)
├── agents/              # 서브에이전트 정의 (선택)
├── skills/              # 스킬 정의 (선택)
├── hooks/               # 훅 (선택, 자동실행 — 위험)
└── README.md
```

실측: 이 중 하나만 있어도 플러그인 성립한다. `plugin.json` 조차 없는
스킬 번들형이 15개 존재한다(§5).

## 2. plugin.json

```json
{
  "name": "claude-md-management",
  "description": "Tools to maintain and improve CLAUDE.md files ...",
  "version": "1.0.0",
  "author": { "name": "Anthropic", "email": "support@anthropic.com" }
}
```

추가로 관측되는 필드: `hooks`(훅 인라인 정의), `lspServers`(LSP 서버 — 카탈로그 12건).

## 3. marketplace.json

위치는 레포 루트의 `.claude-plugin/marketplace.json`.

```json
{
  "$schema": "https://anthropic.com/claude-code/marketplace.schema.json",
  "name": "claude-plugins-official",
  "description": "Directory of popular Claude Code extensions ...",
  "owner": { "name": "Anthropic", "email": "support@anthropic.com" },
  "renames": { "adlc": "agentforce-adlc" },
  "plugins": [ { ...엔트리... } ]
}
```

엔트리 필드:

| 필드 | 필수 | 설명 |
|---|---|---|
| `name` | ✅ | **불변 슬러그**. 설치 식별자 |
| `description` | ✅ | 카탈로그 노출 문구 |
| `source` | ✅ | 코드 위치. 4종 (§4) |
| `category` | 권장 | development / productivity / database / monitoring / security / deployment / design / automation / learning / location / testing / migration / math |
| `author` | 권장 | `{name, email?}` |
| `homepage` | 권장 | 소개 페이지 |
| `displayName` | 선택 | UI 표시명. **이름 바꾸고 싶을 때 여기를 바꾼다** |
| `version` | 선택 | |
| `strict` | 선택 | `false` 면 스킬 번들형 (§5) |
| `skills` | 선택 | `strict:false` 일 때 스킬 경로 배열 |
| `lspServers` | 선택 | LSP 통합 |
| `tags` / `keywords` | 선택 | |

## 4. source 4종 (실측 분포와 예시)

### (1) 문자열 — 마켓 레포 자체 (53건)
```json
"source": "./plugins/claude-md-management"
```
해석: 마켓플레이스 레포 자신의 상대 경로. Anthropic 자체 제작이 전부 이 방식.

### (2) `git-subdir` — 레포의 하위 디렉토리 (83건)
```json
"source": {
  "source": "git-subdir",
  "url": "https://github.com/42Crunch-AI/claude-plugins.git",
  "path": "plugins/api-security-testing",
  "ref": "v1.5.5",
  "sha": "30287f5e3f122a646d1ac5ca3ab96e130c52a3ad"
}
```
한 레포에 플러그인 여러 개 담을 때 쓴다.

### (3) `url` — 레포 루트 전체가 플러그인 (146건, 최다)
```json
"source": {
  "source": "url",
  "url": "https://github.com/SalesforceAIResearch/agentforce-adlc.git",
  "sha": "d16d14ac7f817336e21bf9392cf51b6cac6194d8"
}
```

### (4) `github` — owner/repo 축약형 (2건)
```json
"source": {
  "source": "github",
  "repo": "fullstorydev/fullstory-skills",
  "commit": "1ec5865e7ab1449f9a0859d164c4b6a8c53b6e2f",
  "sha": "b20614e2d08d7a7c70775bb62b5af640f60b024b"
}
```

### 실측 결론 (중요)

- 원격 소스 **231건 전부 github.com**. 비-github 호스트 0건.
- 원격 소스 **231/231 전부 sha 보유**. 미지정 0건.

→ `git clone` 없이 `https://codeload.github.com/{owner}/{repo}/tar.gz/{sha}` 로
  **카탈로그 100%를 재현 가능하게** 받을 수 있다. 폐쇄망 미러링의 근거.

## 5. 스킬 번들형 (strict:false) — 15건

소스 레포에 `SKILL.md` 만 있고 `plugin.json` 이 없을 때, 마켓 엔트리에서
스킬을 직접 선언한다.

```json
{
  "name": "amd-skills",
  "description": "AMD's verified Agent Skills in one plugin: ...",
  "author": { "name": "AMD" },
  "category": "development",
  "source": {
    "source": "git-subdir",
    "url": "https://github.com/amd/skills.git",
    "path": "skills", "ref": "main",
    "sha": "8d5332c8f9405588f6813169ba2268fdc9308fbf"
  },
  "strict": false,
  "skills": ["./local-ai-use", "./serving-llms-on-instinct", "..."]
}
```

- `skills` 의 각 경로는 `source.path` 기준 상대경로이고 `SKILL.md` 가 든 디렉토리를 가리킨다.
- 경로는 한 단계보다 깊어도 된다: `["./libA/skill-1", "./libB/skill-2"]` — 여러
  라이브러리에서 골라 담는 큐레이션이 가능하다.
- Claude Code 안에서는 `<plugin-name>:<skill-name>` 으로 등록된다.

**남에게 스킬만 배포할 때 제일 간단한 방법이 이거다.** `plugin.json` 안 만들어도 된다.

## 6. renames — 이름 불변 규칙

`name` 은 immutable 슬러그다. 이미 배포된 뒤 바꾸면 사용자 설치가
`plugin-not-found` 로 깨진다.

- 표시명만 바꾸려면 → `displayName`
- 진짜 이름을 바꿔야 하면 → 마켓 최상위 `renames` 맵에 등록

```json
"renames": {
  "adlc": "agentforce-adlc",
  "vals": "valtown",
  "wordpress.com": "build-with-wordpress"
}
```
로더가 다음 동기화 때 옛 슬러그를 새 슬러그로 투명하게 재작성한다.
공식 카탈로그 실측 9건.

## 7. 필드 사용 빈도 실측 (284건 기준)

| 필드 | 건수 |
|---|---|
| name / description / source | 284 (전수) |
| category | 270 |
| homepage | 268 |
| author | 200 |
| strict | 15 |
| version | 14 |
| lspServers | 12 |
| skills | 4 |
| tags | 3 |
| displayName | 3 |
| keywords | 1 |

읽는 법: `category`/`homepage` 는 사실상 필수 취급. `version` 은 마켓 엔트리보다
플러그인 쪽 `plugin.json` 에 두는 게 관행이다.

## 8. 설치 명령

```
/plugin marketplace add <git-url 또는 로컬 경로>
/plugin install <plugin-name>@<marketplace-name>
/plugin           # > Discover 로 탐색
```
