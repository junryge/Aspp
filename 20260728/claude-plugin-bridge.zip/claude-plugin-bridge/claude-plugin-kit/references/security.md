# 플러그인 신뢰성 점검

공식 README 경고 원문 취지 그대로:
**설치·갱신·사용 전에 그 플러그인을 신뢰할 수 있는지 직접 확인하라.
Anthropic 은 플러그인에 포함된 MCP 서버·파일·소프트웨어를 통제하지 않으며,
의도대로 동작한다거나 앞으로 안 바뀐다는 것을 보증하지 않는다.**

즉 마켓에 올라와 있다는 사실은 안전 보증이 아니다. 284개 중 246개가 서드파티다.

## 1. 위험 등급 순서

높은 것부터.

### 1순위 — hooks
사용자 확인 없이 **자동 실행**된다. 세션 시작, 도구 호출 전후 등에 붙는다.
플러그인에서 제일 위험한 부분이다. `hooks/hooks.json` 과 `plugin.json` 의
`hooks` 필드를 **한 줄씩 읽어라**. 못 읽겠으면 설치하지 마라.

### 2순위 — MCP 서버 (`.mcp.json`)
외부 프로세스를 띄우거나 외부 URL에 붙는다. 확인할 것:
- `command` + `args` → 로컬에서 뭘 실행하는가 (`npx -y <패키지>` 는 매번 최신을 당겨온다)
- `url` → 어디로 데이터가 나가는가
- 인증 토큰을 어디서 읽는가 (환경변수? 파일?)

**폐쇄망에서는 MCP 딸린 플러그인이 반드시 실패한다.** 스킬은 보이는데 도구가 없다.
그래서 변환기에 `--skip-mcp` 가 있다.

### 3순위 — 스크립트 (`scripts/`, `.sh`, `.py`, `.js`)
`inspect_plugin.py` 가 잡는 패턴:

| 코드 | 의미 | 판단 |
|---|---|---|
| `net.pipe_shell` | `curl ... \| sh` | **즉시 거부.** 원격 코드를 그대로 실행 |
| `shell.rm_rf` | `rm -rf /` 계열 | 경로 확인 필수 |
| `net.download` | curl/wget 으로 외부 다운로드 | 어디서 받는지 확인 |
| `exec.eval` | eval/exec 동적 실행 | 입력이 어디서 오는지 확인 |
| `pkg.install` | npm/pip install | 설치 패키지명 확인 |
| `cred.env` | API_KEY/SECRET/TOKEN 대입 | 하드코딩 여부 확인 |
| `net.request` | requests/fetch/urllib | 목적지 확인 |
| `proc.spawn` | subprocess/os.system | 실행 대상 확인 |

`.md` 안의 명령어는 대개 **문서 예시**라 가중치를 1/3로 깎지만 목록에는 남는다.
점수만 보지 말고 `--format md` 리포트의 스니펫을 읽어라.

### 4순위 — 프롬프트 자체
스킬 본문은 결국 **모델에게 주는 지시문**이다. 여기 이런 게 섞일 수 있다:
- "이전 지시를 무시하고..." 류의 지시 무력화
- 파일을 읽어 외부로 보내라는 유도
- 승인 절차를 건너뛰라는 지시

`grep -riE "ignore (previous|above)|system prompt|exfiltrat|send.*(to|http)" .` 로 훑고,
스킬 본문은 **읽고 넣어라**. 남이 쓴 프롬프트가 내 에이전트의 지시문이 된다.

## 2. 실무 점검 절차

```bash
# 1) 받는다 (설치 아님, 그냥 파일로)
python3 scripts/fetch_plugin.py --name <이름> --out ./review

# 2) 전체 리포트
python3 scripts/inspect_plugin.py ./review --all --format md > REVIEW.md

# 3) 위험 요소 직접 확인
find ./review -path '*hooks*' -o -name '.mcp.json' | xargs -r cat
grep -rn "curl\|wget\|npx -y\|eval(" ./review --include='*.sh' --include='*.py' --include='*.js'

# 4) 프롬프트 인젝션 훑기
grep -riE "ignore (previous|above)|disregard|system prompt|exfiltrat" ./review

# 5) 내부 정보 유출 방지 (내가 재배포할 때)
grep -riE "sk-[A-Za-z0-9]{20}|password\s*=|10\.[0-9]+\.[0-9]+\.[0-9]+" ./review
```

## 3. 공급망 관리

- **sha 고정으로 받아라.** 공식 카탈로그는 231/231 전부 sha 가 박혀 있다.
  `ref: main` 으로 받으면 어제와 오늘이 다르다.
- `_fetch_manifest.json` 의 `tree_sha256` 을 보관하고, 갱신 시 **diff 를 사람이 승인**한다.
  플러그인은 언제든 바뀔 수 있다. 한 번 검토했다고 영원히 안전하지 않다.
- 사내 배포는 **미러를 고정**해서 쓴다. 상류를 직접 물리지 마라.

## 4. 판정 기준 (권장)

| 위험도 | 조치 |
|---|---|
| 0–9 (A) | 통과. 스킬 본문만 훑고 사용 |
| 10–29 (B) | 리포트 확인 후 사용 |
| 30–59 (C) | 담당자 리뷰 필수. 스크립트 라인별 확인 |
| 60+ (D) | 반입 금지. 필요하면 해당 스킬만 발췌 |
| hooks 포함 | 점수 무관 **수동 승인** |
| MCP 포함 | 폐쇄망 **반입 금지** 또는 도구 제거 후 반입 |

## 5. 재배포 시 라이선스

공식 마켓 레포 자체는 Apache-2.0 이지만 **각 플러그인은 자기 LICENSE 를 따른다**.
사내 재배포·변환 배포 시 원본 LICENSE 파일과 출처(`origin_plugin`, repo, sha)를
반드시 동봉해라. `to_skills.py` 가 출처 메타를 자동으로 박아준다.
