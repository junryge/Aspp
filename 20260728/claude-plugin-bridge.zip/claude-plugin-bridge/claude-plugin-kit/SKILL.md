---
name: claude-plugin-kit
description: Claude Code 플러그인/스킬을 다루는 전천후 툴킷. 공식 마켓플레이스(anthropics/claude-plugins-official, 284개)를 검색·다운로드·해부하고, 플러그인을 이식형 SKILL.md 세트로 변환하고, 내 스킬을 남들이 /plugin install 할 수 있는 marketplace.json 으로 배포하고, .skill 로 패키징한다. 사용자가 플러그인, 마켓플레이스, marketplace.json, plugin.json, 슬래시 커맨드, 서브에이전트, 스킬 배포/공유/이식, "이 플러그인 뭐지", "우리 팀도 쓰게", "스킬로 바꿔줘", "설치해도 되나 안전한가" 같은 얘기를 꺼내면 반드시 이 스킬을 켠다. 스킬을 새로 창작하는 게 아니라 기존 플러그인/스킬을 가져오고·바꾸고·내보내는 일이면 전부 여기 해당한다.
---

# Claude Plugin Kit

Claude Code 플러그인 생태계를 **가져오고(import) → 바꾸고(convert) → 내보내는(export)** 툴킷.
모든 스크립트 stdlib only. pip 설치 없고 git 없어도 돈다.

## 0. 먼저 알아야 할 사실 (2026-08 실측)

공식 마켓플레이스 `anthropics/claude-plugins-official` 실제 구성:

| 항목 | 값 |
|---|---|
| 총 플러그인 | 284개 |
| Anthropic 자체(`/plugins`) | 38개 |
| 서드파티(`/external_plugins`) | 246개 |
| 카테고리 | development 119, productivity 49, database 37, monitoring 20, security 18, 기타 |
| `source` 타입 | url 146, git-subdir 83, self-repo 53, github 2 |
| **원격 소스 호스트** | **231개 전부 github.com** |
| **커밋 sha 고정** | **231/231 (100%)** |

마지막 두 줄이 이 툴킷의 설계 근거다. 전부 github + 전부 sha 고정이니까
**git 없이 codeload tar.gz 만으로 100% 재현 가능하게** 받을 수 있다.
폐쇄망 반입, CI 캐싱, 감사 추적이 전부 여기서 나온다.

## 1. 작업 흐름 선택

| 사용자가 원하는 것 | 가야 할 절 |
|---|---|
| "이런 플러그인 있나?" / "뭐가 있는지 보자" | §2 탐색 |
| "이거 설치해도 되나?" / "안전한가?" | §3 해부·점검 |
| "Claude Code 말고 우리 시스템에서 쓰고 싶다" | §4 스킬 변환 |
| "내 스킬을 팀이 설치하게 해줘" | §5 배포 |
| "claude.ai 에 올리고 싶다" | §6 패키징 |

## 2. 탐색 — `scripts/market.py`

```bash
python3 scripts/market.py stats                        # 카탈로그 전체 통계
python3 scripts/market.py list --internal              # Anthropic 자체 38개
python3 scripts/market.py list --category security
python3 scripts/market.py search "claude.md"
python3 scripts/market.py show claude-md-management    # 원본 JSON + 소스 해석 결과
```

`--marketplace <URL|경로>` 로 사내 미러나 다른 마켓을 볼 수 있다.
`--cache` 는 기본 `.cache/marketplace.json` — 한 번 받으면 재사용한다.

**rename 주의**: 카탈로그에 `renames` 맵이 9건 있다(`adlc`→`agentforce-adlc` 등).
옛 이름으로 찾으면 `fetch_plugin.py` 가 자동으로 새 이름으로 돌려준다.

## 3. 해부·점검 — `scripts/fetch_plugin.py` + `inspect_plugin.py`

공식 README 경고를 그대로 지킨다: **설치·갱신·사용 전에 신뢰할 수 있는지 직접 확인하라.
Anthropic 은 플러그인 안의 MCP 서버/파일/소프트웨어를 통제하지 않는다.**

```bash
# 받기 (git 불필요, sha 고정 재현)
python3 scripts/fetch_plugin.py --name claude-md-management --out ./vendor
python3 scripts/fetch_plugin.py --internal --out ./vendor        # 자체 제작 전량
python3 scripts/fetch_plugin.py --all --out ./mirror             # 284개 전량 미러

# 해부
python3 scripts/inspect_plugin.py ./vendor --all                 # 한 줄 요약
python3 scripts/inspect_plugin.py ./vendor --all --format md > REPORT.md
python3 scripts/inspect_plugin.py ./vendor --all --min-risk 30   # 위험한 것만
```

`_fetch_manifest.json` 에 repo/ref/subpath/tree_sha256/tarball_sha256 이 남는다.
나중에 "이 스킬 어디서 왔냐" 소리 나올 때 이게 답이다.

**위험도 읽는 법**: 0~100 점수는 *경보지 판결이 아니다*. `.md` 문서 안의 명령어 예시는
가중치 1/3로 깎지만 그래도 뜬다. 점수 높으면 리포트의 `risks` 항목을 **눈으로 봐라**.
특히 이 셋은 무조건 사람이 확인한다:

- **hooks** — 사용자 확인 없이 자동 실행된다. 가장 위험한 부분.
- **MCP 서버** — 외부 네트워크로 나간다. 폐쇄망이면 애초에 안 돈다.
- `net.pipe_shell` (`curl ... | sh`) — 원격 스크립트 즉시 실행. 무조건 거부.

## 4. 스킬 변환 — `scripts/to_skills.py`

플러그인은 skills + commands + agents + hooks + MCP 가 섞인 묶음이다.
Claude Code 밖(claude.ai, Cowork, 자체 에이전트, 사내 플랫폼)에서 쓰려면
전부 `SKILL.md` 한 포맷으로 눕혀야 한다.

| 원본 | 변환 결과 |
|---|---|
| `skills/*/SKILL.md` | 그대로 이식 + 리소스 폴더 동반 복사 + 출처 메타 주입 |
| `commands/*.md` | SKILL.md 로 승격. **트리거 문장을 새로 써서 붙인다** |
| `agents/*.md` | SKILL.md 로 승격. 역할/도구 제약을 본문 상단에 명시 |
| `.mcp.json` | 변환 안 함. `requires_mcp` 메타 + 리포트로만 남김 |
| `hooks/` | **이식 안 함**(자동 실행). 리포트에 경고 |

```bash
python3 scripts/to_skills.py ./vendor --all --out ./skills --index skills_index.jsonl
python3 scripts/to_skills.py ./vendor --all --out ./skills --prefix cc --skip-mcp
python3 scripts/to_skills.py ./vendor --all --out ./skills --dry-run    # 먼저 확인
```

주요 옵션: `--prefix`(네임스페이스), `--collision suffix|skip|overwrite`,
`--skip-mcp`, `--max-risk N`, `--skip-agents`.

**커맨드 변환이 왜 중요한가**: 슬래시 커맨드는 "호출되면 실행"이라 *언제 쓰는지*가 없다.
그냥 복사하면 영원히 안 켜지는 죽은 스킬이 된다. 그래서 변환기가
`"...관련 작업을 요청하거나 /xxx 를 언급하면 이 스킬을 쓴다"` 문장을 생성해 붙인다.
변환 후 `description` 은 **사람이 한 번 다듬어라**. 트리거 품질이 곧 스킬 품질이다.

주입되는 출처 메타 (감사·업데이트 추적용):
`origin_plugin` / `origin_kind` / `origin_path` / `origin_version` / `requires_mcp` / `converted_at`

## 5. 배포 — `scripts/make_marketplace.py`

내 스킬을 남이 `/plugin install` 하게 만든다.

```bash
# (A) 스킬 폴더들을 플러그인 하나로 묶기 — plugin.json 불필요한 공식 패턴
python3 scripts/make_marketplace.py ./skills --mode bundle \
    --name amhs-skills --owner "존" \
    --repo https://git.internal/john/skills.git --subpath skills

# (B) 하위 폴더마다 독립 플러그인으로
python3 scripts/make_marketplace.py ./plugins --mode plugins \
    --name team-market --owner "AMHS팀"
```

상대방은 이렇게 쓴다:
```
/plugin marketplace add https://git.internal/john/skills.git
/plugin install amhs-skills@amhs-skills
```

**절대 어기면 안 되는 규칙 — 이름은 불변이다.**
마켓 엔트리의 `name` 은 immutable 슬러그다. 배포 후 바꾸면 남의 설치가
`plugin-not-found` 로 깨진다. 표시만 바꾸려면 `displayName`,
정 불가피하면 마켓 최상위 `renames` 맵에 `{"옛이름": "새이름"}` 을 넣어라.
플러그인 로더가 다음 동기화 때 자동 이관한다.

## 6. 패키징 — `scripts/package_skill.py`

```bash
python3 scripts/package_skill.py ./skills --all --lint-only   # 린트만
python3 scripts/package_skill.py ./skills --all --out ./dist  # .skill(zip) 생성
```

린트가 잡는 것: frontmatter 누락, name 슬러그 규칙, 폴더명↔name 불일치,
description 길이(60자 미만/1024자 초과), **"언제 쓰는지"가 없는 description**,
본문 500줄 초과, 본문이 참조하는데 없는 파일, 10MB 초과 파일.

## 7. 자주 하는 실수

1. **description 에 "무엇을"만 쓰고 "언제"를 안 씀** → 스킬이 안 켜진다. 1순위 실패 원인.
2. **hooks 를 같이 복사** → 자동 실행이라 통제 불능. 변환기가 막지만 수동 복사 시 주의.
3. **sha 안 박고 `ref: main`** → 어제 받은 거랑 오늘 받은 게 다르다. 재현 불가.
4. **배포 후 name 변경** → 남의 설치 전부 깨짐.
5. **MCP 서버 딸린 플러그인을 폐쇄망에 반입** → 스킬은 보이는데 도구가 없어 반드시 실패한다.

## 8. 참고 문서

- `references/plugin-spec.md` — plugin.json / marketplace.json 스키마, source 4종 실측 예시
- `references/authoring.md` — 플러그인·스킬 작성 규칙, 네이밍, 버저닝, 업데이트 전략
- `references/security.md` — 설치 전 점검 체크리스트, 위험 패턴 사전

## 9. 파일 구성

```
claude-plugin-kit/
├── SKILL.md
├── scripts/
│   ├── _core.py             공용 코어(마켓 파싱, source 해석, tar 안전전개, frontmatter, 인벤토리)
│   ├── market.py            탐색/검색/통계
│   ├── fetch_plugin.py      다운로드(git 불필요) + 매니페스트
│   ├── inspect_plugin.py    해부 + 위험도 리포트
│   ├── to_skills.py         플러그인 → 이식형 SKILL.md
│   ├── make_marketplace.py  → marketplace.json 배포
│   └── package_skill.py     린트 + .skill 패키징
└── references/
    ├── plugin-spec.md
    ├── authoring.md
    └── security.md
```
