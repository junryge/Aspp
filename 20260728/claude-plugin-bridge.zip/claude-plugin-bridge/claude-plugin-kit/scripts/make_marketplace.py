#!/usr/bin/env python3
"""
make_marketplace.py - 내 스킬/플러그인을 "남들이 설치할 수 있는" 마켓플레이스로 만든다.

만들면 상대는 이렇게 쓴다:
  /plugin marketplace add <내-git-url>
  /plugin install <plugin-name>@<marketplace-name>

두 가지 모드
  --mode bundle   스킬 폴더들을 하나의 플러그인으로 묶는다.
                  plugin.json 없이 strict:false + skills[] 로 선언하는 공식 패턴.
                  스킬만 있고 커맨드/MCP 없을 때 제일 간단하다.
  --mode plugins  하위 폴더 각각을 독립 플러그인으로 만든다.
                  폴더마다 .claude-plugin/plugin.json 을 생성/보정한다.

사용:
  python3 make_marketplace.py ./skills --mode bundle \
      --name my-skills --owner "홍길동" --repo https://git.company.com/me/skills.git
  python3 make_marketplace.py ./plugins --mode plugins \
      --name team-market --owner "AMHS팀" --out .
"""
import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _core import inventory, parse_frontmatter, slugify  # noqa: E402

CATEGORIES = ["development", "productivity", "database", "monitoring", "security",
              "deployment", "design", "automation", "learning", "location",
              "testing", "migration", "math"]


def read_skill(d):
    f = d / "SKILL.md"
    if not f.exists():
        return None
    meta, _ = parse_frontmatter(f.read_text(encoding="utf-8", errors="replace"))
    return {"dir": d.name, "name": meta.get("name") or d.name,
            "description": meta.get("description", "")}


def mode_bundle(root, args):
    skills = [s for s in (read_skill(d) for d in sorted(root.iterdir()) if d.is_dir()) if s]
    if not skills:
        sys.exit("스킬을 못 찾음(SKILL.md 있는 하위 폴더 필요): %s" % root)
    entry = {
        "name": args.name,
        "description": args.description or
        ("%s 스킬 묶음 (%d개): %s" % (args.name, len(skills),
                                    ", ".join(s["name"] for s in skills[:6]))),
        "author": {"name": args.owner},
        "category": args.category,
        "source": ({"source": "git-subdir", "url": args.repo,
                    "path": args.subpath or root.name, "ref": args.ref}
                   if args.repo else "./" + root.name),
        "strict": False,
        "skills": ["./" + s["dir"] for s in skills],
    }
    if args.homepage:
        entry["homepage"] = args.homepage
    return [entry], skills


def mode_plugins(root, args):
    entries, skills = [], []
    for d in sorted(root.iterdir()):
        if not d.is_dir() or d.name.startswith((".", "_")):
            continue
        inv = inventory(d)
        if not (inv["skills"] or inv["commands"] or inv["agents"]):
            continue
        m = inv["manifest"] or {}
        name = slugify(m.get("name") or d.name)
        desc = m.get("description") or (
            inv["skills"][0]["description"] if inv["skills"] else
            "%s 플러그인" % name)
        # plugin.json 생성/보정
        if not args.no_write_manifest:
            mdir = d / ".claude-plugin"
            mdir.mkdir(exist_ok=True)
            man = {"name": name, "description": desc[:400],
                   "version": m.get("version") or args.version,
                   "author": m.get("author") or {"name": args.owner}}
            (mdir / "plugin.json").write_text(
                json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8")
        e = {"name": name, "description": desc[:400],
             "author": {"name": args.owner},
             "category": args.category,
             "source": ({"source": "git-subdir", "url": args.repo,
                         "path": "%s/%s" % (args.subpath or root.name, d.name),
                         "ref": args.ref}
                        if args.repo else "./%s/%s" % (root.name, d.name))}
        if args.homepage:
            e["homepage"] = args.homepage
        entries.append(e)
        skills += [{"name": s["name"], "dir": d.name} for s in inv["skills"]]
    return entries, skills


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root", help="스킬 폴더들의 상위 디렉토리")
    ap.add_argument("--mode", choices=["bundle", "plugins"], default="bundle")
    ap.add_argument("--name", required=True, help="마켓플레이스 이름 (= 설치시 @뒤 슬러그)")
    ap.add_argument("--owner", default="unknown")
    ap.add_argument("--email", default=None)
    ap.add_argument("--description", default=None)
    ap.add_argument("--category", default="productivity", choices=CATEGORIES)
    ap.add_argument("--repo", default=None, help="git URL (없으면 로컬 상대경로 소스)")
    ap.add_argument("--subpath", default=None, help="레포 내 서브경로")
    ap.add_argument("--ref", default="main")
    ap.add_argument("--homepage", default=None)
    ap.add_argument("--version", default="0.1.0")
    ap.add_argument("--out", default=".", help="마켓플레이스 루트 (.claude-plugin/ 생성 위치)")
    ap.add_argument("--no-write-manifest", action="store_true")
    args = ap.parse_args()

    root = Path(args.root)
    if not root.is_dir():
        sys.exit("디렉토리 없음: %s" % root)
    entries, skills = (mode_bundle if args.mode == "bundle" else mode_plugins)(root, args)

    mk = {
        "$schema": "https://anthropic.com/claude-code/marketplace.schema.json",
        "name": args.name,
        "description": args.description or "%s 마켓플레이스" % args.name,
        "owner": {"name": args.owner, **({"email": args.email} if args.email else {})},
        "plugins": entries,
    }
    outdir = Path(args.out) / ".claude-plugin"
    outdir.mkdir(parents=True, exist_ok=True)
    f = outdir / "marketplace.json"
    f.write_text(json.dumps(mk, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print("생성: %s" % f)
    print("  플러그인 엔트리 %d개 / 스킬 %d개" % (len(entries), len(skills)))
    print("\n설치 안내(상대방):")
    print("  /plugin marketplace add %s" % (args.repo or "<이 레포 경로/URL>"))
    for e in entries[:5]:
        print("  /plugin install %s@%s" % (e["name"], args.name))
    print("\n주의: name 은 불변 슬러그다. 이미 배포한 뒤 바꾸면 상대방 설치가 깨진다.")
    print("      표시명만 바꾸려면 displayName, 불가피하면 renames 맵을 쓴다.")
    print("      (생성 시각 %s)" % time.strftime("%Y-%m-%d %H:%M"))


if __name__ == "__main__":
    main()
