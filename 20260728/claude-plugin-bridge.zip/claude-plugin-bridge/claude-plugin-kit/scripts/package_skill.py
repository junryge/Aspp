#!/usr/bin/env python3
"""
package_skill.py - 스킬 폴더를 검증하고 .skill(zip) 로 묶는다.

claude.ai / Cowork 에 올릴 때 쓰는 배포 단위다. 묶기 전에 린트를 돌려서
"트리거 안 되는 스킬"을 미리 걸러낸다. 실제로 스킬이 실패하는 1순위 원인은
로직이 아니라 description 이 약해서 안 켜지는 거다.

사용:
  python3 package_skill.py ./skills/claude-md-improver
  python3 package_skill.py ./skills --all --out ./dist
  python3 package_skill.py ./skills --all --lint-only
"""
import argparse
import re
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _core import parse_frontmatter  # noqa: E402

EXCLUDE = {".git", "node_modules", "__pycache__", ".DS_Store", ".venv"}
TRIGGER_HINTS = ["use when", "use this", "trigger", "쓴다", "사용", "요청", "when the user",
                 "반드시", "whenever"]


def lint(d):
    """반환: (errors, warns)"""
    e, w = [], []
    f = d / "SKILL.md"
    if not f.exists():
        return ["SKILL.md 없음"], []
    txt = f.read_text(encoding="utf-8", errors="replace")
    meta, body = parse_frontmatter(txt)
    if not meta:
        e.append("frontmatter(---) 없음")
    name = meta.get("name", "")
    if not name:
        e.append("frontmatter.name 없음")
    elif not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,63}", str(name)):
        w.append("name 은 소문자-하이픈 슬러그 권장: '%s'" % name)
    if name and name != d.name:
        w.append("폴더명(%s)과 name(%s) 불일치 — 설치 후 참조가 꼬일 수 있다" % (d.name, name))
    desc = str(meta.get("description", ""))
    if not desc:
        e.append("frontmatter.description 없음 (트리거의 전부다)")
    else:
        if len(desc) < 60:
            w.append("description 이 %d자로 짧다 — 무엇을+언제 둘 다 넣어라" % len(desc))
        if len(desc) > 1024:
            w.append("description 이 %d자로 너무 길다" % len(desc))
        if not any(t in desc.lower() for t in TRIGGER_HINTS):
            w.append("description 에 '언제 쓰는지'가 없다 — 언더트리거 위험")
    nlines = body.count("\n") + 1
    if nlines > 500:
        w.append("본문 %d줄 — 500줄 넘으면 references/ 로 쪼개라" % nlines)
    for ref in re.findall(r"[\(\[`](\.?/?(?:references|scripts|assets)/[^\)\]`\s]+)", body):
        if not (d / ref.lstrip("./")).exists():
            w.append("본문이 참조하는 파일이 없다: %s" % ref)
    big = [p for p in d.rglob("*") if p.is_file() and p.stat().st_size > 10 * 1024 * 1024]
    for p in big:
        w.append("대용량 파일: %s (%.1fMB)" % (p.name, p.stat().st_size / 1e6))
    return e, w


def pack(d, out):
    out.mkdir(parents=True, exist_ok=True)
    z = out / ("%s.skill" % d.name)
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(d.rglob("*")):
            if p.is_dir() or any(x in p.parts for x in EXCLUDE):
                continue
            zf.write(p, "%s/%s" % (d.name, p.relative_to(d)))
    return z


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--out", default="./dist")
    ap.add_argument("--lint-only", action="store_true")
    ap.add_argument("--strict", action="store_true", help="경고도 실패로 처리")
    args = ap.parse_args()

    root = Path(args.path)
    targets = ([d for d in sorted(root.iterdir())
                if d.is_dir() and (d / "SKILL.md").exists()]
               if args.all else [root])
    if not targets:
        sys.exit("대상 없음")

    bad = 0
    for d in targets:
        e, w = lint(d)
        tag = "FAIL" if e else ("WARN" if w else "OK  ")
        print("[%s] %s" % (tag, d.name))
        for x in e:
            print("   ✗ %s" % x)
        for x in w:
            print("   ! %s" % x)
        if e or (args.strict and w):
            bad += 1
            continue
        if not args.lint_only:
            z = pack(d, Path(args.out))
            print("   → %s (%.1fKB)" % (z, z.stat().st_size / 1024))
    print("\n총 %d개 / 문제 %d개" % (len(targets), bad))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
