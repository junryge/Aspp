#!/usr/bin/env python3
"""
to_skills.py - 플러그인을 "이식형 스킬 세트"로 변환한다.

플러그인은 skills / commands / agents / hooks / MCP 가 섞인 묶음이다.
Claude Code 밖(자체 에이전트, claude.ai 스킬, 사내 플랫폼)에서 쓰려면
전부 SKILL.md 한 포맷으로 눕혀야 한다. 이 스크립트가 그걸 한다.

변환 규칙
  skills/*/SKILL.md  -> 그대로 이식 (리소스 폴더 동반 복사) + 출처 메타 주입
  commands/*.md      -> SKILL.md 로 승격 (호출부를 "사용 시점" 문장으로 재작성)
  agents/*.md        -> SKILL.md 로 승격 (역할/도구 제약을 본문에 명시)
  .mcp.json          -> 스킬로 안 만든다. requires_mcp 메타 + 리포트로만 남긴다.
  hooks              -> 이식 안 함(자동실행). 리포트에 경고로 남긴다.

사용:
  python3 to_skills.py ./vendor/claude-md-management --out ./skills
  python3 to_skills.py ./vendor --all --out ./skills --prefix cc
  python3 to_skills.py ./vendor --all --out ./skills --index skills_index.jsonl
  python3 to_skills.py ./vendor --all --out ./skills --skip-mcp --dry-run
"""
import argparse
import json
import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _core import (dump_frontmatter, inventory, parse_frontmatter,  # noqa: E402
                   risk_score, slugify)

SKIP_DIRS = {".git", "node_modules", "__pycache__", ".github"}


def _prov(meta, plugin, kind, rel, inv):
    """출처/성격 메타 주입. 나중에 감사·업데이트할 때 이게 생명줄이다."""
    m = inv.get("manifest") or {}
    meta["origin_plugin"] = plugin
    meta["origin_kind"] = kind          # skill | command | agent
    meta["origin_path"] = rel
    if m.get("version"):
        meta["origin_version"] = m["version"]
    if inv.get("mcp_servers"):
        meta["requires_mcp"] = [s["name"] for s in inv["mcp_servers"]]
    meta["converted_at"] = time.strftime("%Y-%m-%d")
    return meta


def _resolve_name(base, used, policy, prefix):
    name = "%s-%s" % (prefix, base) if prefix else base
    name = slugify(name)
    if name not in used:
        return name
    if policy == "skip":
        return None
    if policy == "overwrite":
        return name
    i = 2
    while "%s-%d" % (name, i) in used:
        i += 1
    return "%s-%d" % (name, i)


def convert_plugin(pdir, out, used, args, report):
    plugin = pdir.name
    inv = inventory(pdir)
    made = []

    # 1) 진짜 스킬 -------------------------------------------------------
    for sk in inv["skills"]:
        src = pdir / sk["dir"] if sk["dir"] != "." else pdir
        base = sk["name"] or src.name
        name = _resolve_name(base, used, args.collision, args.prefix)
        if not name:
            report["skipped"].append({"plugin": plugin, "name": base, "why": "이름 충돌"})
            continue
        dst = out / name
        if not args.dry_run:
            if dst.exists():
                shutil.rmtree(dst)
            shutil.copytree(src, dst, ignore=shutil.ignore_patterns(*SKIP_DIRS))
            f = dst / "SKILL.md"
            meta, body = parse_frontmatter(f.read_text(encoding="utf-8", errors="replace"))
            meta["name"] = name
            meta.setdefault("description", sk["description"])
            f.write_text(dump_frontmatter(_prov(meta, plugin, "skill", sk["dir"], inv), body),
                         encoding="utf-8")
        used.add(name)
        made.append({"name": name, "kind": "skill", "description": sk["description"],
                     "plugin": plugin, "resources": sk["resources"]})

    # 2) 슬래시 커맨드 -> 스킬 -------------------------------------------
    for c in inv["commands"]:
        f = pdir / c["file"]
        meta, body = parse_frontmatter(f.read_text(encoding="utf-8", errors="replace"))
        base = c["name"]
        name = _resolve_name(base, used, args.collision, args.prefix)
        if not name:
            report["skipped"].append({"plugin": plugin, "name": base, "why": "이름 충돌"})
            continue
        desc = c["description"] or "%s 플러그인의 /%s 커맨드" % (plugin, base)
        # 커맨드는 "호출되면 실행"이라 트리거 문장이 없다. 여기서 만들어 붙인다.
        desc = ("%s 사용자가 \"%s\" 관련 작업을 요청하거나 /%s 를 언급하면 이 스킬을 쓴다."
                % (desc.rstrip("."), base.replace("-", " "), base))
        nm = dict(meta)
        nm["name"] = name
        nm["description"] = desc
        if c["argument_hint"]:
            nm["argument_hint"] = c["argument_hint"]
        pre = []
        if c["allowed_tools"]:
            pre.append("**허용 도구(원본 제약)**: `%s`" % c["allowed_tools"])
        if c["argument_hint"]:
            pre.append("**인자**: `%s` — 대화에서 값을 못 받으면 먼저 물어본다." % c["argument_hint"])
        pre.append("> 원본: `%s` 플러그인의 슬래시 커맨드 `/%s` 를 스킬로 변환한 것. "
                   "`$ARGUMENTS`/`$1` 같은 자리표시자는 사용자의 실제 요청으로 치환해서 읽는다."
                   % (plugin, base))
        new_body = "# %s\n\n%s\n\n---\n\n%s" % (name, "\n\n".join(pre), body.strip())
        if not args.dry_run:
            d = out / name
            d.mkdir(parents=True, exist_ok=True)
            (d / "SKILL.md").write_text(
                dump_frontmatter(_prov(nm, plugin, "command", c["file"], inv), new_body),
                encoding="utf-8")
        used.add(name)
        made.append({"name": name, "kind": "command", "description": desc, "plugin": plugin})

    # 3) 에이전트 -> 스킬 ------------------------------------------------
    for a in inv["agents"]:
        if args.skip_agents:
            break
        f = pdir / a["file"]
        meta, body = parse_frontmatter(f.read_text(encoding="utf-8", errors="replace"))
        base = a["name"]
        name = _resolve_name(base, used, args.collision, args.prefix)
        if not name:
            report["skipped"].append({"plugin": plugin, "name": base, "why": "이름 충돌"})
            continue
        desc = a["description"] or "%s 플러그인의 %s 에이전트" % (plugin, base)
        nm = dict(meta)
        nm["name"] = name
        nm["description"] = desc
        pre = ["**역할**: 이 스킬은 서브에이전트 정의를 옮긴 것이다. "
               "서브에이전트를 못 쓰는 환경이면 아래 지침을 그대로 따라 직접 수행한다."]
        if a["allowed_tools"]:
            pre.append("**허용 도구(원본 제약)**: `%s`" % a["allowed_tools"])
        if a["model"]:
            pre.append("**권장 모델**: `%s`" % a["model"])
        new_body = "# %s\n\n%s\n\n---\n\n%s" % (name, "\n\n".join(pre), body.strip())
        if not args.dry_run:
            d = out / name
            d.mkdir(parents=True, exist_ok=True)
            (d / "SKILL.md").write_text(
                dump_frontmatter(_prov(nm, plugin, "agent", a["file"], inv), new_body),
                encoding="utf-8")
        used.add(name)
        made.append({"name": name, "kind": "agent", "description": desc, "plugin": plugin})

    # 4) 이식 못 하는 것 ---------------------------------------------------
    if inv["mcp_servers"]:
        report["mcp"].append({"plugin": plugin,
                              "servers": [s["name"] for s in inv["mcp_servers"]],
                              "detail": inv["mcp_servers"]})
    if inv["hooks"]:
        report["hooks"].append({"plugin": plugin, "files": inv["hooks"]})
    report["risk"][plugin] = risk_score(inv)
    return made


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--out", default="./skills")
    ap.add_argument("--prefix", default="", help="스킬 이름 접두사 (네임스페이스 충돌 방지)")
    ap.add_argument("--collision", choices=["suffix", "skip", "overwrite"], default="suffix")
    ap.add_argument("--skip-agents", action="store_true")
    ap.add_argument("--skip-mcp", action="store_true", help="MCP 필요한 플러그인은 통째로 제외")
    ap.add_argument("--max-risk", type=int, default=101, help="위험도 초과 플러그인 제외")
    ap.add_argument("--index", default=None, help="스킬 인덱스 JSONL 출력 경로")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    root = Path(args.path)
    targets = ([d for d in sorted(root.iterdir())
                if d.is_dir() and not d.name.startswith((".", "_"))]
               if args.all else [root])
    out = Path(args.out)
    if not args.dry_run:
        out.mkdir(parents=True, exist_ok=True)

    used, all_made = set(), []
    report = {"skipped": [], "mcp": [], "hooks": [], "risk": {}, "excluded": []}
    for t in targets:
        inv = inventory(t)
        if args.skip_mcp and inv["mcp_servers"]:
            report["excluded"].append({"plugin": t.name, "why": "MCP 서버 의존"})
            continue
        if risk_score(inv) > args.max_risk:
            report["excluded"].append({"plugin": t.name,
                                       "why": "위험도 %d 초과" % risk_score(inv)})
            continue
        all_made += convert_plugin(t, out, used, args, report)

    if args.index and not args.dry_run:
        with open(args.index, "w", encoding="utf-8") as f:
            for m in all_made:
                f.write(json.dumps(m, ensure_ascii=False) + "\n")

    rep = out / "_conversion_report.json"
    payload = {"generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
               "converted": len(all_made), "plugins": len(targets),
               "skills": all_made, **report}
    if not args.dry_run:
        rep.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    k = {}
    for m in all_made:
        k[m["kind"]] = k.get(m["kind"], 0) + 1
    print("변환 %d개 (%s)" % (len(all_made),
                             ", ".join("%s %d" % (a, b) for a, b in k.items())),
          file=sys.stderr)
    if report["mcp"]:
        print("MCP 필요 플러그인 %d개 — 폐쇄망이면 확인 필수: %s" % (
            len(report["mcp"]), ", ".join(x["plugin"] for x in report["mcp"][:8])),
            file=sys.stderr)
    if report["hooks"]:
        print("훅 포함(이식 제외) %d개: %s" % (
            len(report["hooks"]), ", ".join(x["plugin"] for x in report["hooks"][:8])),
            file=sys.stderr)
    if report["skipped"]:
        print("이름 충돌 스킵 %d개" % len(report["skipped"]), file=sys.stderr)
    if not args.dry_run:
        print("리포트: %s" % rep, file=sys.stderr)


if __name__ == "__main__":
    main()
