#!/usr/bin/env python3
"""
market.py - 공식 마켓플레이스(claude-plugins-official) 조회/검색/통계

사용:
  python3 market.py stats
  python3 market.py list --category productivity --internal
  python3 market.py search "claude.md"
  python3 market.py show claude-md-management
  python3 market.py list --json > all.json

옵션 공통:
  --marketplace URL|PATH   기본: 공식 raw URL (사내 미러 지정 가능)
  --cache PATH             기본: ./.cache/marketplace.json
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _core import load_marketplace, resolve_source  # noqa: E402

INTERNAL_AUTHOR = "anthropic"


def get_plugins(args):
    mk = load_marketplace(args.marketplace, args.cache)
    P = mk.get("plugins", [])
    if args.internal:
        P = [p for p in P if INTERNAL_AUTHOR in json.dumps(p.get("author", {})).lower()]
    if args.external:
        P = [p for p in P if INTERNAL_AUTHOR not in json.dumps(p.get("author", {})).lower()]
    if args.category:
        cats = {c.strip().lower() for c in args.category.split(",")}
        P = [p for p in P if (p.get("category") or "").lower() in cats]
    if args.author:
        P = [p for p in P
             if args.author.lower() in json.dumps(p.get("author", {})).lower()]
    if getattr(args, "query", None):
        q = args.query.lower()
        P = [p for p in P
             if q in p["name"].lower() or q in p.get("description", "").lower()
             or q in json.dumps(p.get("tags", []) + p.get("keywords", [])).lower()]
    return mk, P


def cmd_stats(args):
    mk, P = get_plugins(args)
    cat, src, auth = {}, {}, {}
    for p in P:
        cat[p.get("category") or "(none)"] = cat.get(p.get("category") or "(none)", 0) + 1
        s = p.get("source")
        k = "self-repo" if isinstance(s, str) else s.get("source")
        src[k] = src.get(k, 0) + 1
        a = (p.get("author") or {}).get("name", "(unknown)")
        auth[a] = auth.get(a, 0) + 1
    print("마켓플레이스: %s" % mk.get("name"))
    print("총 플러그인 : %d" % len(P))
    print("\n[카테고리]")
    for k, v in sorted(cat.items(), key=lambda x: -x[1]):
        print("  %-14s %3d" % (k, v))
    print("\n[소스 타입]")
    for k, v in sorted(src.items(), key=lambda x: -x[1]):
        print("  %-14s %3d" % (k, v))
    print("\n[상위 제작자]")
    for k, v in sorted(auth.items(), key=lambda x: -x[1])[:10]:
        print("  %-28s %3d" % (k[:28], v))
    pinned = sum(1 for p in P if isinstance(p.get("source"), dict)
                 and (p["source"].get("sha") or p["source"].get("commit")))
    print("\nsha 고정된 원격 소스: %d개 (재현 가능 미러링 가능)" % pinned)
    if mk.get("renames"):
        print("rename 매핑        : %d건" % len(mk["renames"]))


def cmd_list(args):
    _, P = get_plugins(args)
    if args.json:
        print(json.dumps(P, ensure_ascii=False, indent=2))
        return
    for p in sorted(P, key=lambda x: (x.get("category") or "zz", x["name"])):
        print("%-38s %-13s %s" % (
            p["name"][:38], (p.get("category") or "-")[:13],
            p.get("description", "")[:80].replace("\n", " ")))
    print("\n총 %d개" % len(P), file=sys.stderr)


def cmd_search(args):
    cmd_list(args)


def cmd_show(args):
    _, P = get_plugins(args)
    hit = [p for p in P if p["name"] == args.name]
    if not hit:
        hit = [p for p in P if args.name.lower() in p["name"].lower()]
    if not hit:
        print("못 찾음: %s" % args.name, file=sys.stderr)
        sys.exit(1)
    for p in hit[:5]:
        print(json.dumps(p, ensure_ascii=False, indent=2))
        try:
            r = resolve_source(p)
            print("→ 해석: %s/%s @ %s%s (sha고정=%s)" % (
                r["owner"], r["repo"], r["ref"][:12],
                "/" + r["subpath"] if r["subpath"] else "", r["pinned"]))
        except ValueError as e:
            print("→ 해석 불가: %s" % e)
        print("-" * 70)


def main():
    ap = argparse.ArgumentParser(description="공식 Claude Code 플러그인 마켓 조회")
    ap.add_argument("--marketplace", default=None, help="URL 또는 로컬 marketplace.json")
    ap.add_argument("--cache", default=".cache/marketplace.json")
    ap.add_argument("--category")
    ap.add_argument("--author")
    ap.add_argument("--internal", action="store_true", help="Anthropic 자체 제작만")
    ap.add_argument("--external", action="store_true", help="서드파티만")
    ap.add_argument("--json", action="store_true")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("stats")
    sub.add_parser("list")
    s = sub.add_parser("search")
    s.add_argument("query")
    s = sub.add_parser("show")
    s.add_argument("name")
    args = ap.parse_args()
    {"stats": cmd_stats, "list": cmd_list, "search": cmd_search,
     "show": cmd_show}[args.cmd](args)


if __name__ == "__main__":
    main()
