"""
_core.py - Claude Code 플러그인/스킬 처리 코어 (stdlib only)

외부 의존성 0. python3.8+ 어디서든 돈다. 폐쇄망 반입 안전.
marketplace.json 파싱, source 4종 해석, codeload tarball 다운로드,
frontmatter 파싱/직렬화, 플러그인 인벤토리, 위험도 스캔을 담당한다.
"""
import hashlib
import io
import json
import os
import re
import shutil
import sys
import tarfile
import time
import urllib.error
import urllib.request
from pathlib import Path

OFFICIAL_MARKETPLACE = (
    "https://raw.githubusercontent.com/anthropics/claude-plugins-official"
    "/main/.claude-plugin/marketplace.json"
)
SELF_REPO = ("anthropics", "claude-plugins-official")
UA = "claude-plugin-bridge/1.0 (+stdlib-urllib)"

# ---------------------------------------------------------------- 네트워크

def http_get(url, retries=3, timeout=60, backoff=2.0):
    """GET bytes. 429/5xx 백오프 재시도."""
    last = None
    for i in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            last = e
            if e.code in (403, 429) or e.code >= 500:
                time.sleep(backoff * (i + 1))
                continue
            raise
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(backoff * (i + 1))
    raise RuntimeError("GET 실패: %s (%s)" % (url, last))


def load_marketplace(src=None, cache=None):
    """marketplace.json 로드. src=URL|로컬경로|None(공식)."""
    src = src or OFFICIAL_MARKETPLACE
    if not str(src).startswith("http"):
        return json.loads(Path(src).read_text(encoding="utf-8"))
    if cache:
        c = Path(cache)
        if c.exists():
            return json.loads(c.read_text(encoding="utf-8"))
    raw = http_get(src)
    if cache:
        Path(cache).parent.mkdir(parents=True, exist_ok=True)
        Path(cache).write_bytes(raw)
    return json.loads(raw.decode("utf-8"))


# ---------------------------------------------------------------- source 해석

def resolve_source(plugin):
    """
    marketplace 엔트리의 source 를 (owner, repo, ref, subpath) 로 정규화.

    실제 카탈로그에 존재하는 4종:
      1) str            "./plugins/foo"          -> 공식 레포 자체
      2) git-subdir     url + path + ref + sha
      3) url            url + sha                 (레포 루트 전체가 플러그인)
      4) github         repo + commit + sha
    반환: dict(kind, owner, repo, ref, subpath, pinned)
    """
    s = plugin.get("source")
    if isinstance(s, str):
        return {
            "kind": "self", "owner": SELF_REPO[0], "repo": SELF_REPO[1],
            "ref": "main", "subpath": s.lstrip("./"), "pinned": False,
        }
    kind = s.get("source")
    sha = s.get("sha") or s.get("commit")
    if kind == "github":
        owner, repo = s["repo"].split("/", 1)
        ref = s.get("commit") or sha or "main"
        return {"kind": kind, "owner": owner, "repo": repo, "ref": ref,
                "subpath": s.get("path", "").lstrip("./"), "pinned": bool(sha)}
    url = s.get("url", "")
    m = re.match(r"https?://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$", url)
    if not m:
        raise ValueError("github 이외 소스는 미지원(수동 처리 필요): %s" % url)
    ref = sha or s.get("ref") or "main"
    return {"kind": kind, "owner": m.group(1), "repo": m.group(2), "ref": ref,
            "subpath": s.get("path", "").lstrip("./"), "pinned": bool(sha)}


def codeload_url(owner, repo, ref):
    return "https://codeload.github.com/%s/%s/tar.gz/%s" % (owner, repo, ref)


def fetch_tarball(owner, repo, ref, cache_dir):
    """codeload tar.gz 다운로드(캐시). git 불필요."""
    cache_dir = Path(cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)
    dst = cache_dir / ("%s__%s__%s.tar.gz" % (owner, repo, ref[:12]))
    if dst.exists() and dst.stat().st_size > 0:
        return dst
    data = http_get(codeload_url(owner, repo, ref))
    dst.write_bytes(data)
    return dst


def _safe_members(tf, root_prefix, subpath, dest):
    """path traversal 방지 + subpath 필터 + 상단 디렉토리 제거."""
    want = (root_prefix + "/" + subpath).rstrip("/") if subpath else root_prefix
    dest = Path(dest).resolve()
    for m in tf.getmembers():
        if m.issym() or m.islnk():
            continue
        name = m.name
        if not (name == want or name.startswith(want + "/")):
            continue
        rel = name[len(want):].lstrip("/")
        if not rel:
            continue
        target = (dest / rel).resolve()
        if not str(target).startswith(str(dest)):
            continue  # traversal 차단
        m.name = rel
        yield m


def extract_subpath(tar_path, subpath, dest):
    """tarball 안의 subpath 만 dest 로 전개. 반환: 파일 수."""
    dest = Path(dest)
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True, exist_ok=True)
    with tarfile.open(tar_path, "r:gz") as tf:
        first = tf.next()
        if first is None:
            return 0
        root = first.name.split("/")[0]
        members = list(_safe_members(tf, root, subpath, dest))
        tf.extractall(dest, members=members)
    return sum(1 for _ in dest.rglob("*") if _.is_file())


# ---------------------------------------------------------------- frontmatter

_FM = re.compile(r"^---\s*\n(.*?)\n---\s*\n?", re.S)


def parse_frontmatter(text):
    """SKILL.md / command / agent frontmatter 파서 (YAML 부분집합, stdlib only).
    지원: key: value, 따옴표, [a, b] 인라인 리스트, '- item' 블록 리스트, |/> 블록 스칼라."""
    m = _FM.match(text)
    if not m:
        return {}, text
    body = text[m.end():]
    meta, key, mode, buf = {}, None, None, []

    def flush():
        if key is None:
            return
        if mode == "block":
            meta[key] = "\n".join(buf).strip()
        elif mode == "list":
            meta[key] = list(buf)

    for line in m.group(1).split("\n"):
        if mode == "block":
            if line.startswith(("  ", "\t")) or not line.strip():
                buf.append(line.strip())
                continue
            flush()
            mode, buf = None, []
        if mode == "list" and line.strip().startswith("- "):
            buf.append(_scalar(line.strip()[2:]))
            continue
        if mode == "list":
            flush()
            mode, buf = None, []
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if ":" not in line:
            continue
        k, _, v = line.partition(":")
        key, v = k.strip(), v.strip()
        if v in ("|", ">", "|-", ">-"):
            mode, buf = "block", []
        elif v == "":
            mode, buf = "list", []
        elif v.startswith("[") and v.endswith("]"):
            meta[key] = [_scalar(x) for x in v[1:-1].split(",") if x.strip()]
            mode = None
        else:
            meta[key] = _scalar(v)
            mode = None
    flush()
    return meta, body


def _scalar(v):
    v = v.strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        return v[1:-1]
    if v.lower() in ("true", "false"):
        return v.lower() == "true"
    return v


def dump_frontmatter(meta, body):
    """frontmatter 직렬화. 콜론/개행 포함 값은 안전하게 따옴표 처리."""
    order = ["name", "description", "argument_hint", "allowed-tools", "model"]
    keys = [k for k in order if k in meta] + [k for k in meta if k not in order]
    out = ["---"]
    for k in keys:
        v = meta[k]
        if v is None or v == "" or v == []:
            continue
        if isinstance(v, list):
            out.append("%s: [%s]" % (k, ", ".join(_q(str(x)) for x in v)))
        elif isinstance(v, bool):
            out.append("%s: %s" % (k, "true" if v else "false"))
        else:
            out.append("%s: %s" % (k, _q(str(v))))
    out.append("---")
    return "\n".join(out) + "\n\n" + body.lstrip("\n")


def _q(s):
    s = s.replace("\r", " ").replace("\n", " ").strip()
    if re.search(r'[:#\[\]{}"\']|^\s|\s$', s):
        return '"%s"' % s.replace('"', "'")
    return s


# ---------------------------------------------------------------- 인벤토리/위험도

RISK_PATTERNS = [
    ("net.download", r"\b(curl|wget)\b[^\n]{0,120}https?://", "외부 다운로드"),
    ("net.pipe_shell", r"https?://[^\s]+\s*\|\s*(ba)?sh", "원격 스크립트 파이프 실행"),
    ("exec.eval", r"\b(eval|exec)\s*\(", "동적 실행"),
    ("shell.rm_rf", r"rm\s+-rf\s+[/~$]", "위험한 삭제"),
    ("pkg.install", r"\b(npm|pnpm|yarn)\s+(i|install|add)\b|pip\s+install\b", "패키지 설치"),
    ("cred.env", r"(API_KEY|SECRET|TOKEN|PASSWORD)\s*=", "자격증명 하드코딩 의심"),
    ("net.request", r"(requests\.(get|post)|fetch\(|urllib\.request)", "네트워크 호출"),
    ("proc.spawn", r"(subprocess\.|child_process|os\.system)", "프로세스 실행"),
]
SCAN_EXT = {".md", ".py", ".sh", ".js", ".ts", ".mjs", ".cjs", ".json", ".yaml", ".yml", ".toml"}


def inventory(plugin_dir):
    """플러그인 디렉토리 해부. 반환: dict(manifest, skills, commands, agents, hooks, mcp, files, risks)."""
    p = Path(plugin_dir)
    inv = {"path": str(p), "manifest": None, "skills": [], "commands": [],
           "agents": [], "hooks": [], "mcp_servers": [], "files": 0,
           "bytes": 0, "risks": [], "lsp": []}

    mf = p / ".claude-plugin" / "plugin.json"
    if mf.exists():
        try:
            inv["manifest"] = json.loads(mf.read_text(encoding="utf-8"))
        except Exception as e:  # noqa: BLE001
            inv["manifest"] = {"_parse_error": str(e)}

    mcp = p / ".mcp.json"
    if mcp.exists():
        try:
            data = json.loads(mcp.read_text(encoding="utf-8"))
            for nm, cfg in (data.get("mcpServers") or data).items():
                if not isinstance(cfg, dict):
                    continue
                inv["mcp_servers"].append({
                    "name": nm,
                    "transport": "http" if cfg.get("url") else "stdio",
                    "url": cfg.get("url"),
                    "command": cfg.get("command"),
                    "args": cfg.get("args", []),
                })
        except Exception as e:  # noqa: BLE001
            inv["mcp_servers"].append({"name": "_parse_error", "url": str(e)})

    for sk in sorted(p.rglob("SKILL.md")):
        meta, body = parse_frontmatter(sk.read_text(encoding="utf-8", errors="replace"))
        inv["skills"].append({
            "dir": str(sk.parent.relative_to(p)) or ".",
            "name": meta.get("name") or sk.parent.name,
            "description": meta.get("description", ""),
            "lines": body.count("\n") + 1,
            "resources": sorted({d.name for d in sk.parent.iterdir()
                                 if d.is_dir() and not d.name.startswith(".")}),
        })

    for d, key in (("commands", "commands"), ("agents", "agents")):
        for f in sorted((p / d).rglob("*.md")) if (p / d).exists() else []:
            meta, body = parse_frontmatter(f.read_text(encoding="utf-8", errors="replace"))
            inv[key].append({
                "file": str(f.relative_to(p)),
                "name": meta.get("name") or f.stem,
                "description": meta.get("description", ""),
                "allowed_tools": meta.get("allowed-tools") or meta.get("tools") or "",
                "argument_hint": meta.get("argument-hint", ""),
                "model": meta.get("model", ""),
                "lines": body.count("\n") + 1,
            })

    hooks_json = p / "hooks" / "hooks.json"
    if hooks_json.exists():
        inv["hooks"].append(str(hooks_json.relative_to(p)))
    for f in (p / "hooks").rglob("*") if (p / "hooks").exists() else []:
        if f.is_file():
            inv["hooks"].append(str(f.relative_to(p)))
    if inv["manifest"] and inv["manifest"].get("hooks"):
        inv["hooks"].append("plugin.json:hooks")
    if inv["manifest"] and inv["manifest"].get("lspServers"):
        inv["lsp"] = list(inv["manifest"]["lspServers"])

    for f in p.rglob("*"):
        if not f.is_file():
            continue
        inv["files"] += 1
        try:
            inv["bytes"] += f.stat().st_size
        except OSError:
            pass
        if f.suffix.lower() not in SCAN_EXT or f.stat().st_size > 2_000_000:
            continue
        txt = f.read_text(encoding="utf-8", errors="replace")
        for code, rx, desc in RISK_PATTERNS:
            for mm in re.finditer(rx, txt):
                ln = txt.count("\n", 0, mm.start()) + 1
                inv["risks"].append({"code": code, "desc": desc,
                                     "file": str(f.relative_to(p)), "line": ln,
                                     "doc": f.suffix.lower() == ".md",
                                     "snippet": txt[mm.start():mm.start() + 90]
                                     .replace("\n", " ")})
                break  # 파일당 패턴 1회만
    return inv


def risk_score(inv):
    """0(안전)~100(고위험). hooks/mcp/원격실행 가중."""
    w = {"net.pipe_shell": 30, "net.download": 12, "exec.eval": 10,
         "shell.rm_rf": 15, "pkg.install": 8, "cred.env": 10,
         "net.request": 5, "proc.spawn": 5}
    # .md 는 문서라 명령어 "예시"가 많다. 실행 파일(.py/.sh/.js)보다 가중치 1/3.
    s = sum(w.get(r["code"], 3) // (3 if r.get("doc") else 1) for r in inv["risks"])
    s += 20 * len(inv["hooks"][:1])
    s += 10 * len(inv["mcp_servers"])
    return min(100, s)


# ---------------------------------------------------------------- 유틸

def slugify(s, maxlen=64):
    s = re.sub(r"[^a-zA-Z0-9가-힣]+", "-", str(s)).strip("-").lower()
    return (s[:maxlen] or "unnamed").strip("-")


def sha256_file(path, bufsize=1 << 20):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(bufsize)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def sha256_dir(path):
    """디렉토리 재현가능 해시 (경로+내용 정렬)."""
    h = hashlib.sha256()
    for f in sorted(Path(path).rglob("*")):
        if f.is_file():
            h.update(str(f.relative_to(path)).encode())
            h.update(sha256_file(f).encode())
    return h.hexdigest()


def human(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return "%.1f%s" % (n, u)
        n /= 1024.0
    return "%.1fTB" % n


def eprint(*a):
    print(*a, file=sys.stderr)
