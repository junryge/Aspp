#!/usr/bin/env python3
"""
fetch_plugin.py - 마켓플레이스 플러그인을 로컬로 내려받는다. git 불필요.

원격 소스가 전부 github + sha 고정이라 codeload tar.gz 로 재현 가능하게 받는다.

사용:
  python3 fetch_plugin.py --name claude-md-management
  python3 fetch_plugin.py --name a --name b --out ./vendor
  python3 fetch_plugin.py --internal --out ./vendor          # Anthropic 자체 39개
  python3 fetch_plugin.py --category productivity --limit 10
  python3 fetch_plugin.py --all --out ./mirror --manifest mirror.json

출력:
  <out>/<plugin-name>/...        플러그인 트리
  <out>/_fetch_manifest.json     소스/커밋/해시 기록 (재현·감사용)
"""
import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _core import (extract_subpath, fetch_tarball, human, load_marketplace,  # noqa: E402
                   resolve_source, sha256_dir, sha256_file)


def select(mk, args):
    P = mk.get("plugins", [])
    if args.name:
        want = set(args.name)
        ren = mk.get("renames", {})
        want = {ren.get(w, w) for w in want}
        P = [p for p in P if p["name"] in want]
        missing = want - {p["name"] for p in P}
        if missing:
            print("경고: 카탈로그에 없음 -> %s" % ", ".join(sorted(missing)), file=sys.stderr)
    if args.internal:
        P = [p for p in P if "anthropic" in json.dumps(p.get("author", {})).lower()]
    if args.category:
        cats = {c.strip() for c in args.category.split(",")}
        P = [p for p in P if p.get("category") in cats]
    if args.limit:
        P = P[:args.limit]
    return P


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--marketplace", default=None)
    ap.add_argument("--cache", default=".cache/marketplace.json")
    ap.add_argument("--tarcache", default=".cache/tarballs")
    ap.add_argument("--name", action="append", help="플러그인 이름(복수 가능)")
    ap.add_argument("--category")
    ap.add_argument("--internal", action="store_true")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--limit", type=int)
    ap.add_argument("--out", default="./vendor")
    ap.add_argument("--manifest", default=None)
    ap.add_argument("--keep-tarballs", action="store_true")
    args = ap.parse_args()

    if not (args.name or args.category or args.internal or args.all):
        ap.error("--name / --category / --internal / --all 중 하나는 필요")

    mk = load_marketplace(args.marketplace, args.cache)
    P = select(mk, args)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    print("대상 %d개 -> %s" % (len(P), out), file=sys.stderr)

    recs, ok, fail = [], 0, 0
    for i, p in enumerate(P, 1):
        name = p["name"]
        try:
            r = resolve_source(p)
            tb = fetch_tarball(r["owner"], r["repo"], r["ref"], args.tarcache)
            dest = out / name
            n = extract_subpath(tb, r["subpath"], dest)
            if n == 0:
                raise RuntimeError("subpath 비어있음: %s" % r["subpath"])
            rec = {
                "name": name, "category": p.get("category"),
                "description": p.get("description", ""),
                "author": p.get("author"), "homepage": p.get("homepage"),
                "strict": p.get("strict"), "skills": p.get("skills"),
                "source_kind": r["kind"], "repo": "%s/%s" % (r["owner"], r["repo"]),
                "ref": r["ref"], "subpath": r["subpath"], "pinned": r["pinned"],
                "files": n, "tree_sha256": sha256_dir(dest),
                "tarball_sha256": sha256_file(tb),
            }
            recs.append(rec)
            ok += 1
            print("[%3d/%3d] OK   %-38s %4d files" % (i, len(P), name[:38], n),
                  file=sys.stderr)
        except Exception as e:  # noqa: BLE001
            fail += 1
            recs.append({"name": name, "error": str(e)})
            print("[%3d/%3d] FAIL %-38s %s" % (i, len(P), name[:38], e), file=sys.stderr)
        time.sleep(0.05)

    total = sum(f.stat().st_size for f in out.rglob("*") if f.is_file())
    man = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "marketplace": mk.get("name"),
        "selected": len(P), "ok": ok, "fail": fail,
        "total_bytes": total, "plugins": recs,
    }
    mpath = Path(args.manifest) if args.manifest else out / "_fetch_manifest.json"
    mpath.write_text(json.dumps(man, ensure_ascii=False, indent=2), encoding="utf-8")
    if not args.keep_tarballs:
        import shutil
        shutil.rmtree(args.tarcache, ignore_errors=True)
    print("\n완료: OK %d / FAIL %d / %s\n매니페스트: %s"
          % (ok, fail, human(total), mpath), file=sys.stderr)


if __name__ == "__main__":
    main()
