#!/usr/bin/env python3
"""
inspect_plugin.py - 플러그인 해부 + 신뢰도 점검

설치 전에 뭐가 들었는지 본다. 공식 README 경고 그대로다:
"플러그인을 설치·갱신·사용하기 전에 신뢰할 수 있는지 확인하라. Anthropic 은
플러그인에 포함된 MCP 서버/파일/소프트웨어를 통제하지 않는다."

사용:
  python3 inspect_plugin.py ./vendor/claude-md-management
  python3 inspect_plugin.py ./vendor --all --format md  > REPORT.md
  python3 inspect_plugin.py ./vendor --all --format json > report.json
  python3 inspect_plugin.py ./vendor --all --min-risk 30      # 위험한 것만
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from _core import human, inventory, risk_score  # noqa: E402


def grade(score):
    return ("A 안전" if score < 10 else "B 보통" if score < 30 else
            "C 주의" if score < 60 else "D 위험")


def render_md(items):
    L = ["# 플러그인 점검 리포트", ""]
    L += ["| 플러그인 | 스킬 | 커맨드 | 에이전트 | 훅 | MCP | 파일 | 위험도 |",
          "|---|--:|--:|--:|--:|--:|--:|---|"]
    for inv in items:
        s = risk_score(inv)
        L.append("| %s | %d | %d | %d | %d | %d | %d | %d %s |" % (
            Path(inv["path"]).name, len(inv["skills"]), len(inv["commands"]),
            len(inv["agents"]), len(inv["hooks"]), len(inv["mcp_servers"]),
            inv["files"], s, grade(s)))
    L.append("")
    for inv in items:
        nm = Path(inv["path"]).name
        s = risk_score(inv)
        L += ["## %s  (위험도 %d · %s)" % (nm, s, grade(s)), ""]
        m = inv["manifest"] or {}
        if m:
            L.append("- 매니페스트: `%s` v%s — %s" % (
                m.get("name", "?"), m.get("version", "?"),
                (m.get("description") or "")[:140]))
        L.append("- 규모: %d 파일 / %s" % (inv["files"], human(inv["bytes"])))
        if inv["skills"]:
            L += ["", "**스킬**", ""]
            for sk in inv["skills"]:
                L.append("- `%s` (%d줄%s) — %s" % (
                    sk["name"], sk["lines"],
                    ", 리소스: " + "/".join(sk["resources"]) if sk["resources"] else "",
                    sk["description"][:160]))
        if inv["commands"]:
            L += ["", "**슬래시 커맨드**", ""]
            for c in inv["commands"]:
                L.append("- `/%s` — %s%s" % (
                    c["name"], c["description"][:120],
                    "  ⚠ allowed-tools: `%s`" % c["allowed_tools"]
                    if c["allowed_tools"] else ""))
        if inv["agents"]:
            L += ["", "**에이전트**", ""]
            for a in inv["agents"]:
                L.append("- `%s` — %s" % (a["name"], a["description"][:120]))
        if inv["mcp_servers"]:
            L += ["", "**MCP 서버 (외부 통신·폐쇄망 주의)**", ""]
            for s2 in inv["mcp_servers"]:
                L.append("- `%s` [%s] %s" % (
                    s2["name"], s2["transport"],
                    s2.get("url") or "%s %s" % (s2.get("command"),
                                                " ".join(map(str, s2.get("args") or [])))))
        if inv["hooks"]:
            L += ["", "**훅 (자동 실행 — 반드시 눈으로 확인)**", ""]
            L += ["- `%s`" % h for h in inv["hooks"][:20]]
        if inv["lsp"]:
            L += ["", "**LSP 서버**: %s" % ", ".join(map(str, inv["lsp"]))]
        if inv["risks"]:
            L += ["", "**위험 패턴 탐지**", "",
                  "| 코드 | 설명 | 위치 | 스니펫 |", "|---|---|---|---|"]
            for r in inv["risks"][:40]:
                L.append("| `%s` | %s | `%s:%d` | `%s` |" % (
                    r["code"], r["desc"], r["file"], r["line"],
                    r["snippet"][:70].replace("|", "\\|")))
        L.append("")
    return "\n".join(L)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path")
    ap.add_argument("--all", action="store_true", help="하위 디렉토리 전부를 플러그인으로 간주")
    ap.add_argument("--format", choices=["md", "json", "text"], default="text")
    ap.add_argument("--min-risk", type=int, default=0)
    args = ap.parse_args()

    root = Path(args.path)
    targets = ([d for d in sorted(root.iterdir())
                if d.is_dir() and not d.name.startswith((".", "_"))]
               if args.all else [root])
    items = [inventory(t) for t in targets]
    items = [i for i in items if risk_score(i) >= args.min_risk]

    if args.format == "json":
        print(json.dumps([dict(i, risk_score=risk_score(i)) for i in items],
                         ensure_ascii=False, indent=2))
    elif args.format == "md":
        print(render_md(items))
    else:
        for inv in items:
            s = risk_score(inv)
            print("%-38s skills=%-3d cmds=%-3d agents=%-2d hooks=%-2d mcp=%-2d "
                  "files=%-4d risk=%3d %s" % (
                      Path(inv["path"]).name[:38], len(inv["skills"]),
                      len(inv["commands"]), len(inv["agents"]), len(inv["hooks"]),
                      len(inv["mcp_servers"]), inv["files"], s, grade(s)))


if __name__ == "__main__":
    main()
