# -*- coding: utf-8 -*-
"""
AMHS Daily Report System - 서버 (파이썬 표준 라이브러리만 사용 — 설치 불필요)
실행: python server.py  →  http://localhost:8000

폴더 구조:
  server.py
  config.json                      ← 암호/포트 설정 (없으면 자동 생성)
  reports_db.json                  ← 리포트 데이터 (자동 생성)
  INDEX/Daily_Report_System.html   ← 웹 화면
  INDEX/guide.html                 ← 작성 가이드 화면 (📘 가이드 버튼이 여는 페이지)
  INDEX/IMAGE/A1.PNG ~ A4.PNG      ← 가이드에 표시할 이미지

config.json:
  editPassword  : 완료 리포트 "수정" 암호
  adminPassword : 완료 리포트 "삭제" 관리자 암호
  host / port   : 서버 주소·포트
※ config.json 수정 후 서버 재시작하면 적용
"""
import json
import mimetypes
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote

BASE = Path(__file__).resolve().parent
INDEX_DIR = BASE / "INDEX"
HTML = INDEX_DIR / "Daily_Report_System.html"
IMAGE_DIR = INDEX_DIR / "IMAGE"
DB = BASE / "reports_db.json"
CONFIG = BASE / "config.json"
LOCK = threading.Lock()

DEFAULT_CONFIG = {
    "editPassword": "AMHS1234",
    "adminPassword": "AMHS1234",
    "host": "0.0.0.0",
    "port": 8000,
}


def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    if CONFIG.exists():
        try:
            user = json.loads(CONFIG.read_text(encoding="utf-8"))
            if isinstance(user, dict):
                cfg.update(user)
        except Exception as e:
            print(f"[경고] config.json 읽기 실패, 기본값 사용: {e}")
    else:
        CONFIG.write_text(json.dumps(DEFAULT_CONFIG, ensure_ascii=False, indent=2), encoding="utf-8")
        print("[안내] config.json 기본 파일을 생성했습니다.")
    return cfg


def load_db() -> dict:
    if DB.exists():
        try:
            data = json.loads(DB.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}
    return {}


def find_image(name: str):
    """INDEX/IMAGE 안에서 파일 찾기 (대소문자 구분 없이)."""
    if not IMAGE_DIR.is_dir():
        return None
    name = unquote(name)
    if "/" in name or "\\" in name or ".." in name:
        return None
    direct = IMAGE_DIR / name
    if direct.is_file():
        return direct
    low = name.lower()
    for f in IMAGE_DIR.iterdir():
        if f.is_file() and f.name.lower() == low:
            return f
    return None


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8", cache=False):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "max-age=86400" if cache else "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json_body(self):
        # 응답 전에 반드시 호출 (keep-alive 오염 방지)
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if n <= 0:
                return None
            if n > 128 * 1024 * 1024:
                self.close_connection = True
                return None
            raw = self.rfile.read(n)
            try:
                return json.loads(raw.decode("utf-8"))
            except Exception:
                return None
        except Exception:
            self.close_connection = True
            return None

    def do_GET(self):
        p = self.path.split("?")[0]

        if p == "/":
            if not HTML.exists():
                self._send(404, {"error": "INDEX/Daily_Report_System.html not found"})
                return
            self._send(200, HTML.read_bytes(), "text/html; charset=utf-8")
            return

        # 작성 가이드 페이지 (INDEX/guide.html)
        if p.lower() == "/guide.html":
            g = INDEX_DIR / "guide.html"
            if not g.exists():
                self._send(404, {"error": "INDEX/guide.html not found"})
                return
            self._send(200, g.read_bytes(), "text/html; charset=utf-8")
            return

        # 작성 가이드 이미지 (INDEX/IMAGE/*)
        if p.upper().startswith("/IMAGE/"):
            f = find_image(p[len("/IMAGE/"):])
            if not f:
                self._send(404, {"error": "image not found"})
                return
            ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
            self._send(200, f.read_bytes(), ctype, cache=True)
            return

        if p == "/api/config":
            cfg = load_config()  # 매 요청마다 읽음 → 새로고침만 해도 적용
            self._send(200, {"editPassword": cfg["editPassword"], "adminPassword": cfg["adminPassword"]})
            return

        if p == "/api/reports":
            with LOCK:
                self._send(200, load_db())
            return

        if p == "/health":
            self._send(200, {"ok": True, "reports": len(load_db()), "images": IMAGE_DIR.is_dir()})
            return

        self._send(404, {"ok": False, "error": "not found"})

    def do_PUT(self):
        data = self._json_body()
        p = self.path.split("?")[0]
        if p != "/api/reports":
            self._send(404, {"ok": False, "error": "not found"})
            return
        if not isinstance(data, dict):
            self._send(400, {"ok": False, "error": "object expected"})
            return
        with LOCK:
            DB.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        self._send(200, {"ok": True, "count": len(data)})


if __name__ == "__main__":
    cfg = load_config()
    print("=" * 54)
    print("  AMHS Daily Report System")
    print(f"  브라우저에서 열기 →  http://localhost:{cfg['port']}")
    print("  암호 설정: config.json")
    if (INDEX_DIR / "guide.html").exists():
        print("  가이드 페이지: INDEX/guide.html")
    else:
        print("  [주의] INDEX/guide.html 이 없습니다 — 📘 가이드가 안 열립니다")
    if IMAGE_DIR.is_dir():
        names = sorted(f.name for f in IMAGE_DIR.iterdir() if f.is_file())
        print(f"  가이드 이미지: INDEX/IMAGE ({len(names)}개) {', '.join(names[:8])}")
    else:
        print("  [주의] INDEX/IMAGE 폴더가 없습니다 — 📘 가이드 이미지가 안 보입니다")
    print("=" * 54)
    ThreadingHTTPServer((cfg["host"], int(cfg["port"])), Handler).serve_forever()
