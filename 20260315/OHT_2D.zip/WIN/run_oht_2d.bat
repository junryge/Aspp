@echo off
chcp 949 >nul
title OHT 2D Map Builder
echo ============================================================
echo   OHT 2D Map Builder (BAT + PowerShell)
echo   XML Parse - JSON - HTML 2D Map
echo   No Python Required
echo ============================================================
echo.

REM === Configuration ===
set "SCRIPT_DIR=%~dp0"
set "XML_PATH=%SCRIPT_DIR%layout\layout\layout.xml"
set "OUTPUT_DIR=%SCRIPT_DIR%output"
set "FAB_NAME=M14-Pro"

REM === Custom arguments ===
if not "%~1"=="" set "XML_PATH=%~1"
if not "%~2"=="" set "OUTPUT_DIR=%~2"
if not "%~3"=="" set "FAB_NAME=%~3"

echo [CONFIG]
echo   XML : %XML_PATH%
echo   OUT : %OUTPUT_DIR%
echo   FAB : %FAB_NAME%
echo.

REM === Validate ===
if not exist "%XML_PATH%" (
    echo [ERROR] layout.xml not found: %XML_PATH%
    echo.
    echo Usage: run_oht_2d.bat [xml_path] [output_dir] [fab_name]
    pause
    exit /b 1
)

if not exist "%OUTPUT_DIR%" mkdir "%OUTPUT_DIR%"

REM === Parse XML to JSON + Generate HTML (all in PowerShell) ===
echo Parsing XML and generating HTML...
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%parse_layout.ps1" -XmlPath "%XML_PATH%" -OutputDir "%OUTPUT_DIR%" -FabName "%FAB_NAME%"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Build failed!
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   BUILD COMPLETE!
echo.
echo   JSON : %OUTPUT_DIR%\layout_data.json
echo   HTML : %OUTPUT_DIR%\oht_2d_map.html
echo.
echo   Opening HTML in browser...
echo ============================================================
echo.

REM === Auto-open HTML ===
if exist "%OUTPUT_DIR%\oht_2d_map.html" (
    start "" "%OUTPUT_DIR%\oht_2d_map.html"
) else (
    echo [WARN] HTML not found. Open layout_data.json manually.
)

pause
