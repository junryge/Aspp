﻿#Requires -Version 5.1
<#
.SYNOPSIS
    OHT Layout XML Parser - PowerShell (Python 불필요)
    layout.xml → layout_data.json 변환

.DESCRIPTION
    반도체 FAB OHT layout.xml을 파싱하여 JSON 데이터를 생성합니다.
    Addr(노드), NextAddr(엣지), Station, McpZone, Vehicle 추출

.PARAMETER XmlPath
    layout.xml 파일 경로

.PARAMETER OutputDir
    출력 디렉토리 (기본: .\output)

.PARAMETER FabName
    FAB 이름 (기본: M14-Pro)
#>
param(
    [Parameter(Mandatory=$true)]
    [string]$XmlPath,

    [string]$OutputDir = ".\output",
    [string]$FabName = "M14-Pro"
)

$ErrorActionPreference = "Stop"
$sw = [System.Diagnostics.Stopwatch]::StartNew()

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  OHT Layout XML Parser (PowerShell)" -ForegroundColor Cyan
Write-Host "  XML -> JSON (Python 불필요)" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

# === Validate Input ===
if (-not (Test-Path $XmlPath)) {
    Write-Host "[ERROR] XML file not found: $XmlPath" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
}

$xmlFileSize = (Get-Item $XmlPath).Length / 1MB
Write-Host "[INFO] XML File: $XmlPath ($([math]::Round($xmlFileSize,1)) MB)" -ForegroundColor Yellow
Write-Host "[INFO] Output  : $OutputDir" -ForegroundColor Yellow
Write-Host "[INFO] FAB     : $FabName" -ForegroundColor Yellow
Write-Host ""

# ============================================================================
# STEP 1: Stream-based XML parsing (대용량 파일 대응)
# ============================================================================
Write-Host "[1/5] Loading XML (streaming)..." -ForegroundColor Green

$reader = [System.Xml.XmlReader]::Create($XmlPath, (New-Object System.Xml.XmlReaderSettings -Property @{
    DtdProcessing = [System.Xml.DtdProcessing]::Ignore
    IgnoreWhitespace = $true
}))

# Data containers
$nodes      = [System.Collections.ArrayList]::new()
$edges      = [System.Collections.ArrayList]::new()
$stations   = [System.Collections.ArrayList]::new()
$zones      = [System.Collections.ArrayList]::new()
$vehicles   = [System.Collections.ArrayList]::new()

# Layout params
$scale = 30.0
$drawAreaW = 11389
$drawAreaH = 4769
$railHeight = 2850

# Bounds tracking
$minX = [double]::MaxValue; $maxX = [double]::MinValue
$minY = [double]::MaxValue; $maxY = [double]::MinValue

# Temp variables for current element
$currentAddr = $null
$currentNextAddrs = [System.Collections.ArrayList]::new()
$currentStations = [System.Collections.ArrayList]::new()
$currentZone = $null
$currentVehicle = $null
$inAddr = $false
$inNextAddr = $false
$inStation = $false
$inZone = $false
$inVehicle = $false
$nextAddrIdx = -1

$addrCount = 0
$stationCount = 0
$zoneCount = 0
$vehicleCount = 0

# ============================================================================
# STEP 2: Parse XML stream
# ============================================================================
Write-Host "[2/5] Parsing XML elements..." -ForegroundColor Green

while ($reader.Read()) {
    if ($reader.NodeType -eq [System.Xml.XmlNodeType]::Element -and $reader.Name -eq "group") {
        $className = $reader.GetAttribute("class")
        $groupName = $reader.GetAttribute("name")

        switch ($className) {
            # --- Address Node ---
            "jp.co.daifuku.tsc.common.layoutdata.layout.address.Addr" {
                # Save previous addr if exists
                if ($currentAddr -ne $null) {
                    # Attach stations to node
                    $currentAddr["stations"] = $currentStations.ToArray()
                    # Process edges from NextAddrs
                    foreach ($na in $currentNextAddrs) {
                        if ($na["next_address"] -gt 0) {
                            [void]$edges.Add($na)
                        }
                    }
                    # Update bounds
                    $x = $currentAddr["x"]; $y = $currentAddr["y"]
                    if ($x -lt $minX) { $minX = $x }; if ($x -gt $maxX) { $maxX = $x }
                    if ($y -lt $minY) { $minY = $y }; if ($y -gt $maxY) { $maxY = $y }

                    [void]$nodes.Add($currentAddr)
                }

                $addrCount++
                $addrId = 0
                if ($groupName -match 'Addr(\d+)') { $addrId = [int]$Matches[1] }

                $currentAddr = @{
                    id         = $addrId
                    x          = 0.0
                    y          = 0.0
                    cad_x      = 0.0
                    cad_y      = 0.0
                    symbol     = ""
                    is_station = 0
                    branch     = $false
                    junction   = $false
                    hid_included = -1
                    stopzone   = 0
                    stations   = @()
                }
                $currentNextAddrs.Clear()
                $currentStations.Clear()
                $inAddr = $true
                $inNextAddr = $false
                $inStation = $false

                if ($addrCount % 1000 -eq 0) {
                    Write-Host "  Addr: $addrCount ..." -ForegroundColor DarkGray
                }
            }

            # --- NextAddr (Edge) ---
            "jp.co.daifuku.tsc.common.layoutdata.layout.address.NextAddr" {
                if ($groupName -match 'NextAddr(\d+)') { $nextAddrIdx = [int]$Matches[1] }
                $inNextAddr = $true
                $currentNextAddrData = @{
                    from_id       = if ($currentAddr) { $currentAddr["id"] } else { 0 }
                    to_id         = 0
                    next_address  = 0
                    distance      = 0
                    speed         = 0
                    direction     = $nextAddrIdx
                    branch_dir    = 0
                }
            }

            # --- Station ---
            "jp.co.daifuku.tsc.common.layoutdata.layout.address.Station" {
                $inStation = $true
                $stationCount++
                $currentStationData = @{
                    no        = 0
                    port_id   = ""
                    category  = 0
                    type      = 0
                    position  = 0
                    node_id   = if ($currentAddr) { $currentAddr["id"] } else { 0 }
                    x         = if ($currentAddr) { $currentAddr["x"] } else { 0 }
                    y         = if ($currentAddr) { $currentAddr["y"] } else { 0 }
                }
            }

            # --- McpZone ---
            "jp.co.daifuku.tsc.common.layoutdata.layout.mcpzone.McpZone" {
                if ($currentZone -ne $null) {
                    [void]$zones.Add($currentZone)
                }
                $zoneCount++
                $currentZone = @{
                    id           = 0
                    no           = 0
                    type         = 0
                    vehicle_max  = 0
                    entries      = [System.Collections.ArrayList]::new()
                    exits        = [System.Collections.ArrayList]::new()
                }
                $inZone = $true
            }

            # --- McpZone Entry ---
            "jp.co.daifuku.tsc.common.layoutdata.layout.mcpzone.Entry" {
                # Will capture params below
            }

            # --- McpZone Exit ---
            "jp.co.daifuku.tsc.common.layoutdata.layout.mcpzone.Exit" {
                # Will capture params below
            }

            # --- Vehicle ---
            "jp.co.daifuku.tsc.common.layoutdata.layout.vehicle.Vehicle" {
                $vehicleCount++
                $currentVehicle = @{
                    id      = 0
                    address = 0
                    type    = 0
                }
                $inVehicle = $true
            }
        }
    }
    elseif ($reader.NodeType -eq [System.Xml.XmlNodeType]::Element -and $reader.Name -eq "param") {
        $key   = $reader.GetAttribute("key")
        $value = $reader.GetAttribute("value")

        if ($inStation -and $currentStationData -ne $null) {
            switch ($key) {
                "no"        { $currentStationData["no"] = [int]$value }
                "port-id"   { $currentStationData["port_id"] = $value }
                "category"  { $currentStationData["category"] = [int]$value }
                "type"      { $currentStationData["type"] = [int]$value }
                "position"  { $currentStationData["position"] = [int]$value }
                "stopzone"  { $currentStationData["stopzone"] = [int]$value }
            }
        }
        elseif ($inNextAddr -and $currentNextAddrData -ne $null) {
            switch ($key) {
                "next-address"     { $currentNextAddrData["next_address"] = [int]$value; $currentNextAddrData["to_id"] = [int]$value }
                "distance-puls"    { $currentNextAddrData["distance"] = [int]$value }
                "speed"            { $currentNextAddrData["speed"] = [int]$value }
                "branch-direction" { $currentNextAddrData["branch_dir"] = [int]$value }
            }
        }
        elseif ($inAddr -and $currentAddr -ne $null) {
            switch ($key) {
                "address"     { $currentAddr["id"] = [int]$value }
                "draw-x"      { $currentAddr["x"] = [double]$value }
                "draw-y"      { $currentAddr["y"] = [double]$value }
                "cad-x"       { $currentAddr["cad_x"] = [double]$value }
                "cad-y"       { $currentAddr["cad_y"] = [double]$value }
                "symbol-name" { $currentAddr["symbol"] = $value }
                "isstation"   { $currentAddr["is_station"] = [int]$value }
                "branch"      { $currentAddr["branch"] = ($value -eq "true") }
                "junction"    { $currentAddr["junction"] = ($value -eq "true") }
                "stopzone"    { $currentAddr["stopzone"] = [int]$value }
            }
        }
        elseif ($inZone -and $currentZone -ne $null) {
            switch ($key) {
                "id"                { $currentZone["id"] = [int]$value }
                "no"                { $currentZone["no"] = [int]$value }
                "type"              { $currentZone["type"] = [int]$value }
                "vehicle-max"       { $currentZone["vehicle_max"] = [int]$value }
            }
        }
        elseif ($inVehicle -and $currentVehicle -ne $null) {
            switch ($key) {
                "id"       { $currentVehicle["id"] = [int]$value }
                "address"  { $currentVehicle["address"] = [int]$value }
                "type"     { $currentVehicle["type"] = [int]$value }
            }
        }

        # Layout-level params
        if (-not $inAddr -and -not $inZone -and -not $inVehicle) {
            switch ($key) {
                "scale"           { $scale = [double]$value }
                "draw-area-size-w" { $drawAreaW = [int]$value }
                "draw-area-size-h" { $drawAreaH = [int]$value }
                "name-project"    { if ($FabName -eq "M14-Pro") { $FabName = $value } }
            }
        }
    }
    elseif ($reader.NodeType -eq [System.Xml.XmlNodeType]::EndElement -and $reader.Name -eq "group") {
        if ($inStation) {
            # Station ended - update coordinates from parent addr
            if ($currentAddr) {
                $currentStationData["x"] = $currentAddr["x"]
                $currentStationData["y"] = $currentAddr["y"]
                $currentStationData["node_id"] = $currentAddr["id"]
            }
            [void]$currentStations.Add($currentStationData)
            [void]$stations.Add($currentStationData)
            $inStation = $false
        }
        elseif ($inNextAddr) {
            [void]$currentNextAddrs.Add($currentNextAddrData)
            $inNextAddr = $false
        }
        elseif ($inVehicle) {
            [void]$vehicles.Add($currentVehicle)
            $inVehicle = $false
        }
    }
}

# Save last addr
if ($currentAddr -ne $null) {
    $currentAddr["stations"] = $currentStations.ToArray()
    foreach ($na in $currentNextAddrs) {
        if ($na["next_address"] -gt 0) { [void]$edges.Add($na) }
    }
    $x = $currentAddr["x"]; $y = $currentAddr["y"]
    if ($x -lt $minX) { $minX = $x }; if ($x -gt $maxX) { $maxX = $x }
    if ($y -lt $minY) { $minY = $y }; if ($y -gt $maxY) { $maxY = $y }
    [void]$nodes.Add($currentAddr)
}

# Save last zone
if ($currentZone -ne $null) {
    [void]$zones.Add($currentZone)
}

$reader.Close()

Write-Host "  Nodes   : $($nodes.Count)" -ForegroundColor White
Write-Host "  Edges   : $($edges.Count)" -ForegroundColor White
Write-Host "  Stations: $($stations.Count)" -ForegroundColor White
Write-Host "  Zones   : $($zones.Count)" -ForegroundColor White
Write-Host "  Vehicles: $($vehicles.Count)" -ForegroundColor White

# ============================================================================
# STEP 3: Build JSON structure
# ============================================================================
Write-Host "[3/5] Building JSON..." -ForegroundColor Green

# Build edges as simplified array
$edgeList = [System.Collections.ArrayList]::new()
foreach ($e in $edges) {
    [void]$edgeList.Add(@{
        start      = $e["from_id"]
        end        = $e["to_id"]
        distance   = $e["distance"]
        speed      = $e["speed"]
        direction  = $e["direction"]
        branch_dir = $e["branch_dir"]
    })
}

# Build nodes with embedded stations
$nodeList = [System.Collections.ArrayList]::new()
foreach ($n in $nodes) {
    $stArr = [System.Collections.ArrayList]::new()
    foreach ($s in $n["stations"]) {
        [void]$stArr.Add(@{
            no       = $s["no"]
            port_id  = $s["port_id"]
            category = $s["category"]
            type     = $s["type"]
            position = $s["position"]
        })
    }
    [void]$nodeList.Add(@{
        id         = $n["id"]
        x          = $n["x"]
        y          = $n["y"]
        cad_x      = $n["cad_x"]
        cad_y      = $n["cad_y"]
        symbol     = $n["symbol"]
        is_station = $n["is_station"]
        branch     = $n["branch"]
        junction   = $n["junction"]
        hid_included = $n["hid_included"]
        stopzone   = $n["stopzone"]
        stations   = $stArr.ToArray()
    })
}

# Build zone list
$zoneList = [System.Collections.ArrayList]::new()
foreach ($z in $zones) {
    [void]$zoneList.Add(@{
        id          = $z["id"]
        no          = $z["no"]
        type        = $z["type"]
        vehicle_max = $z["vehicle_max"]
    })
}

# Build vehicle list
$vhlList = [System.Collections.ArrayList]::new()
foreach ($v in $vehicles) {
    [void]$vhlList.Add(@{
        id      = $v["id"]
        address = $v["address"]
        type    = $v["type"]
    })
}

# Build station list (flat)
$stationList = [System.Collections.ArrayList]::new()
foreach ($s in $stations) {
    [void]$stationList.Add(@{
        no       = $s["no"]
        port_id  = $s["port_id"]
        category = $s["category"]
        type     = $s["type"]
        position = $s["position"]
        node_id  = $s["node_id"]
        x        = $s["x"]
        y        = $s["y"]
    })
}

$result = @{
    fab_name        = $FabName
    oht_count       = $vehicles.Count
    rail_height     = $railHeight
    bounds          = @{
        min_x = $minX
        max_x = $maxX
        min_y = $minY
        max_y = $maxY
    }
    total_nodes     = $nodes.Count
    total_edges     = $edges.Count
    total_stations  = $stations.Count
    total_mcp_zones = $zones.Count
    nodes           = $nodeList.ToArray()
    edges           = $edgeList.ToArray()
    stations        = $stationList.ToArray()
    zones           = $zoneList.ToArray()
    hid_zones       = @()
    hid_master      = @()
    vehicles        = $vhlList.ToArray()
}

# ============================================================================
# STEP 4: Write JSON
# ============================================================================
Write-Host "[4/5] Writing JSON..." -ForegroundColor Green

$jsonPath = Join-Path $OutputDir "layout_data.json"

# Use .NET serializer for large data
Add-Type -AssemblyName System.Web.Extensions 2>$null
try {
    $serializer = New-Object System.Web.Script.Serialization.JavaScriptSerializer
    $serializer.MaxJsonLength = [int]::MaxValue
    $jsonString = $serializer.Serialize($result)
} catch {
    # Fallback: ConvertTo-Json (PS 5.1+)
    $jsonString = $result | ConvertTo-Json -Depth 10 -Compress
}

[System.IO.File]::WriteAllText($jsonPath, $jsonString, [System.Text.Encoding]::UTF8)

$jsonSize = (Get-Item $jsonPath).Length / 1MB
Write-Host "  JSON saved: $jsonPath ($([math]::Round($jsonSize,1)) MB)" -ForegroundColor White

# ============================================================================
# STEP 5: Generate HTML with embedded JSON data
# ============================================================================
Write-Host "[5/6] Generating HTML with embedded data..." -ForegroundColor Green

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$templateHtml = Join-Path $scriptDir "oht_2d_map.html"
$outputHtml = Join-Path $OutputDir "oht_2d_map.html"

if (Test-Path $templateHtml) {
    $htmlContent = [System.IO.File]::ReadAllText($templateHtml, [System.Text.Encoding]::UTF8)

    # Replace the auto-load fetch block with embedded data
    $oldBlock = @"
// ============================================================================
// AUTO-LOAD: Try to load layout_data.json from same directory
// ============================================================================
(async function init() {
    // Try multiple paths
    const paths = [
        'layout_data.json',
        'output/layout_data.json',
        'layout/layout/aaa.json',
        './aaa.json'
    ];
    for (const p of paths) {
        try {
            const res = await fetch(p);
            if (res.ok) {
                const json = await res.json();
                if (json.nodes && json.edges) {
                    loadJSON(json);
                    return;
                }
            }
        } catch(e) {}
    }
    // No auto-load - show app with file picker
    setLoad(100, 'JSON 파일을 선택하세요 (우측 패널)');
    setTimeout(() => {
        document.getElementById('loading').style.display = 'none';
        document.getElementById('app').style.display = 'flex';
    }, 500);
})();
"@

    $newBlock = @"
// ============================================================================
// EMBEDDED DATA - No fetch required, works with file:// protocol
// ============================================================================
const EMBEDDED_DATA = $jsonString;

(function init() {
    loadJSON(EMBEDDED_DATA);
})();
"@

    $htmlContent = $htmlContent.Replace($oldBlock.Trim(), $newBlock.Trim())
    [System.IO.File]::WriteAllText($outputHtml, $htmlContent, [System.Text.Encoding]::UTF8)

    $htmlSize = (Get-Item $outputHtml).Length / 1MB
    Write-Host "  HTML saved: $outputHtml ($([math]::Round($htmlSize,1)) MB)" -ForegroundColor White
} else {
    Write-Host "  [WARN] Template HTML not found: $templateHtml" -ForegroundColor Yellow
    Write-Host "  HTML generation skipped. Use layout_data.json manually." -ForegroundColor Yellow
}

# ============================================================================
# STEP 6: Summary
# ============================================================================
$sw.Stop()
Write-Host ""
Write-Host "[6/6] Parse Complete!" -ForegroundColor Green
Write-Host "  Time   : $([math]::Round($sw.Elapsed.TotalSeconds,1)) seconds" -ForegroundColor Cyan
Write-Host "  Nodes  : $($nodes.Count)" -ForegroundColor Cyan
Write-Host "  Edges  : $($edges.Count)" -ForegroundColor Cyan
Write-Host "  Station: $($stations.Count)" -ForegroundColor Cyan
Write-Host "  Zones  : $($zones.Count)" -ForegroundColor Cyan
Write-Host "  Vehicle: $($vehicles.Count)" -ForegroundColor Cyan
Write-Host "  Bounds : X[$minX ~ $maxX] Y[$minY ~ $maxY]" -ForegroundColor Cyan
Write-Host ""

exit 0
