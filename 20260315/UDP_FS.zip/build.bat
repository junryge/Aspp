@echo off
chcp 65001 >nul
echo ========================================
echo   OHT/AGV UDP 통신 도구 - EXE 빌드
echo ========================================
echo.

REM pyinstaller 설치 확인
pip show pyinstaller >nul 2>&1
if %errorlevel% neq 0 (
    echo [1/3] pyinstaller 설치 중...
    pip install pyinstaller
    echo.
) else (
    echo [1/3] pyinstaller 이미 설치됨
)

echo [2/3] EXE 빌드 시작...
echo.
pyinstaller --onefile --noconsole --name "UDP_OHT_AGV" udp_oht_agv.py

echo.
if exist "dist\UDP_OHT_AGV.exe" (
    echo ========================================
    echo   빌드 성공!
    echo   dist\UDP_OHT_AGV.exe
    echo ========================================
    echo.

    REM dist 폴더에서 현재 폴더로 복사
    copy "dist\UDP_OHT_AGV.exe" "UDP_OHT_AGV.exe" >nul
    echo   → UDP_OHT_AGV.exe 복사 완료
    echo.

    REM 빌드 찌꺼기 삭제
    rmdir /s /q build >nul 2>&1
    rmdir /s /q dist >nul 2>&1
    del UDP_OHT_AGV.spec >nul 2>&1
    echo   → 빌드 임시파일 정리 완료
) else (
    echo ========================================
    echo   빌드 실패! 오류를 확인하세요.
    echo ========================================
)

echo.
pause
