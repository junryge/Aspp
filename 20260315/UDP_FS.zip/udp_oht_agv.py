#!/usr/bin/env python3
"""
OHT / AGV UDP 송신 & 수신확인 도구
- 왼쪽: OHT/AGV 메시지 만들어서 바로 송신
- 오른쪽: 상대방이 보낸 응답/메시지 수신 확인
"""
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import socket
import threading
import time
import random


class UDPTool:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("OHT / AGV UDP 통신 도구")
        self.root.geometry("1100x720")
        self.root.configure(bg="#1a1a2e")

        self.sock_send = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock_recv = None
        self.recv_running = False
        self.recv_count = 0
        self.send_count = 0

        self.build_ui()

    # ========== UI 구성 ==========
    def build_ui(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure("Title.TLabel", background="#1a1a2e", foreground="#00d4ff", font=("맑은 고딕", 14, "bold"))
        style.configure("Sub.TLabel", background="#16213e", foreground="#aaa", font=("맑은 고딕", 9))
        style.configure("Val.TLabel", background="#16213e", foreground="#4cff4c", font=("Consolas", 12, "bold"))
        style.configure("Send.TButton", font=("맑은 고딕", 11, "bold"))
        style.configure("Recv.TButton", font=("맑은 고딕", 10, "bold"))

        # 타이틀
        tk.Label(self.root, text="OHT / AGV  UDP 통신 도구", bg="#1a1a2e", fg="#00d4ff",
                 font=("맑은 고딕", 16, "bold")).pack(pady=(10, 5))

        # 메인 프레임
        main = tk.Frame(self.root, bg="#1a1a2e")
        main.pack(fill="both", expand=True, padx=10, pady=5)

        # ===== 왼쪽: 송신 =====
        left = tk.LabelFrame(main, text="  송신 (SEND)  ", bg="#16213e", fg="#00d4ff",
                              font=("맑은 고딕", 11, "bold"), padx=10, pady=10)
        left.pack(side="left", fill="both", expand=True, padx=(0, 5))

        # IP / Port
        f1 = tk.Frame(left, bg="#16213e")
        f1.pack(fill="x", pady=(0, 8))
        tk.Label(f1, text="대상 IP", bg="#16213e", fg="#aaa", font=("맑은 고딕", 9)).pack(side="left")
        self.tx_ip = tk.Entry(f1, width=16, bg="#0d1b3e", fg="#eee", insertbackground="#eee",
                              font=("Consolas", 11))
        self.tx_ip.insert(0, "192.168.1.100")
        self.tx_ip.pack(side="left", padx=(5, 15))
        tk.Label(f1, text="포트", bg="#16213e", fg="#aaa", font=("맑은 고딕", 9)).pack(side="left")
        self.tx_port = tk.Entry(f1, width=7, bg="#0d1b3e", fg="#eee", insertbackground="#eee",
                                font=("Consolas", 11))
        self.tx_port.insert(0, "3600")
        self.tx_port.pack(side="left", padx=5)

        # OHT / AGV 탭
        tab_frame = tk.Frame(left, bg="#16213e")
        tab_frame.pack(fill="x", pady=(0, 5))
        self.tx_mode = tk.StringVar(value="OHT")
        for txt in ["OHT", "AGV"]:
            tk.Radiobutton(tab_frame, text=txt, variable=self.tx_mode, value=txt,
                           bg="#16213e", fg="#00d4ff", selectcolor="#0f3460",
                           font=("맑은 고딕", 10, "bold"), indicatoron=0, width=8, pady=4,
                           command=self.on_mode_change).pack(side="left", padx=2)

        # 메시지 종류
        f2 = tk.Frame(left, bg="#16213e")
        f2.pack(fill="x", pady=(0, 5))
        tk.Label(f2, text="메시지 종류", bg="#16213e", fg="#aaa", font=("맑은 고딕", 9)).pack(anchor="w")
        self.msg_type = ttk.Combobox(f2, state="readonly", font=("맑은 고딕", 10),
                                      values=["ID:2  Vehicle 상태 보고",
                                              "ID:1  MCP On-line 보고",
                                              "ID:4  기기 상태 보고",
                                              "ID:51 상태 보고 요구"])
        self.msg_type.current(0)
        self.msg_type.pack(fill="x", pady=2)
        self.msg_type.bind("<<ComboboxSelected>>", lambda e: self.build_fields())

        # 필드 입력 영역
        self.field_frame = tk.Frame(left, bg="#16213e")
        self.field_frame.pack(fill="both", expand=True)
        self.field_entries = {}

        # 미리보기 (build_fields보다 먼저 생성)
        tk.Label(left, text="생성 메시지 (CSV)", bg="#16213e", fg="#888", font=("맑은 고딕", 9)).pack(anchor="w", pady=(8, 0))
        self.preview = tk.Text(left, height=2, bg="#0a0f1e", fg="#00d4ff",
                               font=("Consolas", 10), wrap="word", state="disabled")
        self.preview.pack(fill="x", pady=(2, 5))

        self.build_fields()

        # 버튼 + 연속송신 개수
        btn_f = tk.Frame(left, bg="#16213e")
        btn_f.pack(fill="x")
        tk.Button(btn_f, text="📡 송신", bg="#00d4ff", fg="#000", font=("맑은 고딕", 12, "bold"),
                  width=10, command=self.do_send).pack(side="left", padx=(0, 5))
        tk.Button(btn_f, text="샘플", bg="#ff9800", fg="#000", font=("맑은 고딕", 9, "bold"),
                  command=self.load_sample).pack(side="left", padx=2)
        tk.Button(btn_f, text="초기화", bg="#444", fg="#ccc", font=("맑은 고딕", 9),
                  command=self.build_fields).pack(side="left", padx=2)

        # 랜덤 연속 송신
        btn_f2 = tk.Frame(left, bg="#16213e")
        btn_f2.pack(fill="x", pady=(6, 0))
        tk.Button(btn_f2, text="🎲 랜덤 연속 송신", bg="#e040fb", fg="#fff",
                  font=("맑은 고딕", 10, "bold"),
                  command=self.do_random_send).pack(side="left", padx=(0, 5))
        tk.Label(btn_f2, text="개수:", bg="#16213e", fg="#aaa",
                 font=("맑은 고딕", 9)).pack(side="left", padx=(10, 2))
        self.rand_count = tk.Entry(btn_f2, width=5, bg="#0d1b3e", fg="#eee",
                                    insertbackground="#eee", font=("Consolas", 11))
        self.rand_count.insert(0, "5")
        self.rand_count.pack(side="left")
        tk.Label(btn_f2, text="간격(ms):", bg="#16213e", fg="#aaa",
                 font=("맑은 고딕", 9)).pack(side="left", padx=(10, 2))
        self.rand_interval = tk.Entry(btn_f2, width=5, bg="#0d1b3e", fg="#eee",
                                       insertbackground="#eee", font=("Consolas", 11))
        self.rand_interval.insert(0, "100")
        self.rand_interval.pack(side="left")

        self.send_label = tk.Label(left, text="송신: 0건", bg="#16213e", fg="#00d4ff",
                                    font=("맑은 고딕", 9, "bold"))
        self.send_label.pack(anchor="e", pady=(5, 0))

        # ===== 오른쪽: 수신확인 =====
        right = tk.LabelFrame(main, text="  수신 확인 (RECEIVE)  ", bg="#16213e", fg="#4cff4c",
                               font=("맑은 고딕", 11, "bold"), padx=10, pady=10)
        right.pack(side="right", fill="both", expand=True, padx=(5, 0))

        # 수신 포트
        f3 = tk.Frame(right, bg="#16213e")
        f3.pack(fill="x", pady=(0, 8))
        tk.Label(f3, text="수신 포트", bg="#16213e", fg="#aaa", font=("맑은 고딕", 9)).pack(side="left")
        self.rx_port = tk.Entry(f3, width=7, bg="#0d1b3e", fg="#eee", insertbackground="#eee",
                                font=("Consolas", 11))
        self.rx_port.insert(0, "3600")
        self.rx_port.pack(side="left", padx=5)

        self.rx_status = tk.Label(f3, text="● 정지", bg="#16213e", fg="#f44336",
                                   font=("맑은 고딕", 10, "bold"))
        self.rx_status.pack(side="left", padx=10)

        self.rx_count_label = tk.Label(f3, text="수신: 0건", bg="#16213e", fg="#4cff4c",
                                        font=("맑은 고딕", 10, "bold"))
        self.rx_count_label.pack(side="right")

        # 수신 시작/정지
        btn_r = tk.Frame(right, bg="#16213e")
        btn_r.pack(fill="x", pady=(0, 8))
        tk.Button(btn_r, text="▶ 수신 시작", bg="#4caf50", fg="#fff",
                  font=("맑은 고딕", 10, "bold"), command=self.start_recv).pack(side="left", padx=(0, 5))
        tk.Button(btn_r, text="■ 정지", bg="#f44336", fg="#fff",
                  font=("맑은 고딕", 10, "bold"), command=self.stop_recv).pack(side="left", padx=2)
        tk.Button(btn_r, text="로그삭제", bg="#444", fg="#ccc", font=("맑은 고딕", 9),
                  command=self.clear_recv).pack(side="right")

        # 수신 로그
        self.rx_log = scrolledtext.ScrolledText(right, bg="#0a0f1e", fg="#ccc",
                                                 font=("Consolas", 10), state="disabled",
                                                 wrap="word")
        self.rx_log.pack(fill="both", expand=True)
        self.rx_log.tag_config("time", foreground="#666")
        self.rx_log.tag_config("rx", foreground="#4cff4c")
        self.rx_log.tag_config("data", foreground="#00d4ff")
        self.rx_log.tag_config("info", foreground="#888")
        self.rx_log.tag_config("warn", foreground="#ff9800")

    # ========== 필드 생성 ==========
    def build_fields(self):
        for w in self.field_frame.winfo_children():
            w.destroy()
        self.field_entries.clear()

        mode = self.tx_mode.get()
        idx = self.msg_type.current()
        msg_id = ["2", "1", "4", "51"][idx]

        fields = self.get_fields(msg_id, mode)

        canvas = tk.Canvas(self.field_frame, bg="#16213e", highlightthickness=0)
        scrollbar = tk.Scrollbar(self.field_frame, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg="#16213e")

        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        for i, (key, label, default, desc) in enumerate(fields):
            row = tk.Frame(inner, bg="#16213e")
            row.pack(fill="x", pady=1)
            lbl_text = f"{label}"
            if desc:
                lbl_text += f"  ({desc})"
            tk.Label(row, text=lbl_text, bg="#16213e", fg="#aaa", font=("맑은 고딕", 8),
                     width=30, anchor="w").pack(side="left")
            e = tk.Entry(row, bg="#0d1b3e", fg="#eee", insertbackground="#eee",
                         font=("Consolas", 10), width=20)
            e.insert(0, default)
            e.pack(side="left", fill="x", expand=True, padx=(5, 0))
            e.bind("<KeyRelease>", lambda ev: self.update_preview())
            self.field_entries[key] = e

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.update_preview()

    def get_fields(self, msg_id, mode):
        mcp = mode  # OHT or AGV
        vhl = "V001" if mode == "OHT" else "A001"

        if msg_id == "2":
            return [
                ("mcp", "MCP명칭", mcp, ""),
                ("vhl", "Vehicle명", vhl, ""),
                ("state", "상태", "1", "1:운전 2:정지 3:이상 4:수동"),
                ("cargo", "재하", "0", "0:없음 1:있음"),
                ("err", "에러코드", "0000", ""),
                ("comm", "통신", "1", "1:정상 2:단선"),
                ("addr", "현재번지", "1000", ""),
                ("dist", "거리", "0", ""),
                ("next", "다음번지", "1001", ""),
                ("cycle", "실행Cycle", "0", ""),
                ("prog", "진척", "0", ""),
                ("cid", "Carrier ID", "", ""),
                ("dest", "목적지", "", ""),
                ("em", "E/M상태", "00000000", ""),
                ("gid", "GroupID", "0000", ""),
                ("sp", "반송원Port", "", ""),
                ("dp", "반송처Port", "", ""),
                ("pri", "우선도", "0", ""),
                ("det", "상세", "0", ""),
                ("mil", "주행거리", "0", ""),
            ]
        elif msg_id == "1":
            return [
                ("mcp", "MCP명칭", mcp, ""),
                ("ctrl", "Control", "ON-LINE", "ON-LINE / OFF-LINE"),
                ("tsc", "TSC", "AUTO", "AUTO / PAUSED / PAUSING"),
                ("alarm", "Alarm", "NO ALARMS", "NO ALARMS / ALARMS"),
                ("st", "상태구분", "0", ""),
            ]
        elif msg_id == "4":
            return [
                ("mcp", "MCP명칭", mcp, ""),
                ("eqt", "기종번호", "10", "10:VHL 100:STK"),
                ("eqn", "기기명칭", vhl, ""),
                ("state", "상태", "1", "1:정상 2:이상 3:유지보수"),
                ("err", "에러코드", "0000", ""),
            ]
        elif msg_id == "51":
            return []
        return []

    # ========== 미리보기 ==========
    def update_preview(self):
        msg = self.build_message()
        self.preview.config(state="normal")
        self.preview.delete("1.0", "end")
        self.preview.insert("1.0", msg)
        self.preview.config(state="disabled")

    def build_message(self):
        idx = self.msg_type.current()
        msg_id = ["2", "1", "4", "51"][idx]
        if msg_id == "51":
            return "51"
        vals = [e.get() for e in self.field_entries.values()]
        return msg_id + "," + ",".join(vals)

    # ========== 송신 ==========
    def do_send(self):
        msg = self.build_message()
        ip = self.tx_ip.get().strip()
        port_str = self.tx_port.get().strip()

        if not ip or not port_str:
            messagebox.showwarning("경고", "IP와 포트를 입력하세요")
            return

        try:
            port = int(port_str)
            data = msg.encode('ascii')
            self.sock_send.sendto(data, (ip, port))
            self.send_count += 1
            self.send_label.config(text=f"송신: {self.send_count}건")

            # 수신 로그에도 TX 표시
            ts = time.strftime("%H:%M:%S")
            self.log_recv(f"[{ts}] ", "time")
            self.log_recv(f"TX → ", "warn")
            self.log_recv(f"{ip}:{port}  ", "info")
            self.log_recv(f"{msg}\n", "data")

        except Exception as e:
            messagebox.showerror("송신 오류", str(e))

    # ========== 랜덤 연속 송신 ==========
    def do_random_send(self):
        """개수만큼 랜덤 데이터 생성해서 연속 송신"""
        ip = self.tx_ip.get().strip()
        port_str = self.tx_port.get().strip()
        if not ip or not port_str:
            messagebox.showwarning("경고", "IP와 포트를 입력하세요")
            return
        try:
            port = int(port_str)
            count = int(self.rand_count.get().strip() or "5")
            interval_ms = int(self.rand_interval.get().strip() or "100")
        except ValueError:
            messagebox.showwarning("경고", "개수와 간격은 숫자로 입력하세요")
            return

        # 별도 스레드에서 연속 송신
        def send_loop():
            for i in range(count):
                # 매번 랜덤 샘플 생성 후 송신
                self.root.after(0, self._random_send_one, ip, port, i + 1, count)
                if i < count - 1:
                    time.sleep(interval_ms / 1000.0)

        t = threading.Thread(target=send_loop, daemon=True)
        t.start()

    def _random_send_one(self, ip, port, num, total):
        """랜덤 샘플 1건 생성 → 송신"""
        self.load_sample()  # 랜덤 샘플로 필드 채움
        msg = self.build_message()
        try:
            data = msg.encode('ascii')
            self.sock_send.sendto(data, (ip, port))
            self.send_count += 1
            self.send_label.config(text=f"송신: {self.send_count}건")

            ts = time.strftime("%H:%M:%S")
            self.log_recv(f"[{ts}] ", "time")
            self.log_recv(f"TX [{num}/{total}] → ", "warn")
            self.log_recv(f"{ip}:{port}  ", "info")
            self.log_recv(f"{msg}\n", "data")
        except Exception as e:
            self.log_recv(f"  오류: {e}\n", "warn")

    # ========== 랜덤 샘플 ==========
    def rand_vhl(self, mode):
        if mode == "OHT":
            return f"V{random.randint(1,200):03d}"
        return f"A{random.randint(1,50):03d}"

    def rand_addr(self, mode):
        if mode == "OHT":
            return str(random.randint(1000, 9999))
        return str(random.randint(5000, 6999))

    def rand_carrier(self):
        prefixes = ["PIN", "CST", "FPK", "LOT", "WFR"]
        return f"{random.choice(prefixes)}{random.randint(1000,9999)}"

    def rand_port(self, mode):
        if mode == "OHT":
            bays = ["IR3S", "IR5S", "IR7S", "EQ2N", "EQ4S", "STB"]
            return f"{random.choice(bays)}{random.randint(1,50):03d}{'S' if random.random()>0.5 else 'N'}_{random.randint(1,4)}"
        return f"LP{random.randint(1,20):02d}"

    def rand_dest(self, mode):
        if mode == "OHT":
            return str(random.randint(10000, 50000))
        return str(random.randint(6000, 7000))

    def rand_err(self):
        if random.random() < 0.7:
            return "0000"
        return f"{random.randint(1, 255):04X}"

    def load_sample(self):
        mode = self.tx_mode.get()
        idx = self.msg_type.current()
        msg_id = ["2", "1", "4", "51"][idx]

        if msg_id == "2":
            vhl = self.rand_vhl(mode)
            state = random.choice(["1", "1", "1", "2", "3", "4", "6", "7"])
            cargo = random.choice(["0", "1"])
            err = "0000" if state != "3" else self.rand_err()
            addr = self.rand_addr(mode)
            nxt = str(int(addr) + random.choice([-1, 1, 2, -2, 10, -10]))
            carrier = self.rand_carrier() if cargo == "1" else ""
            dest = self.rand_dest(mode) if cargo == "1" else ""
            cycle = random.choice(["0", "2", "3", "4", "5", "21"])
            prog = random.choice(["0", "1", "2", "3", "4", "5"])
            sp = self.rand_port(mode) if carrier else ""
            dp = self.rand_port(mode) if carrier else ""
            pri = str(random.choice([0, 1, 10, 50, 99]))
            mil = str(random.randint(0, 50000)) if state == "1" else "0"
            data = {"mcp": mode, "vhl": vhl, "state": state, "cargo": cargo,
                    "err": err, "comm": "1", "addr": addr, "dist": str(random.randint(0, 50)),
                    "next": nxt, "cycle": cycle, "prog": prog, "cid": carrier,
                    "dest": dest, "em": "00000000", "gid": "0000",
                    "sp": sp, "dp": dp, "pri": pri, "det": "0", "mil": mil}

        elif msg_id == "1":
            ctrl = random.choice(["ON-LINE", "ON-LINE", "ON-LINE", "OFF-LINE"])
            tsc = random.choice(["AUTO", "AUTO", "PAUSED", "PAUSING"])
            alarm = random.choice(["NO ALARMS", "NO ALARMS", "NO ALARMS", "ALARMS"])
            data = {"mcp": mode, "ctrl": ctrl, "tsc": tsc, "alarm": alarm, "st": "0"}

        elif msg_id == "4":
            vhl = self.rand_vhl(mode)
            state = random.choice(["1", "1", "1", "2", "3"])
            err = "0000" if state == "1" else self.rand_err()
            eqt = random.choice(["10", "10", "50", "60", "92"])
            data = {"mcp": mode, "eqt": eqt, "eqn": vhl, "state": state, "err": err}
        else:
            data = {}

        for key, val in data.items():
            if key in self.field_entries:
                self.field_entries[key].delete(0, "end")
                self.field_entries[key].insert(0, val)
        self.update_preview()

    def on_mode_change(self):
        self.build_fields()

    # ========== 수신 ==========
    def start_recv(self):
        if self.recv_running:
            return

        port_str = self.rx_port.get().strip()
        try:
            port = int(port_str)
        except:
            messagebox.showwarning("경고", "올바른 포트 번호를 입력하세요")
            return

        try:
            self.sock_recv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock_recv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock_recv.bind(("0.0.0.0", port))
            self.sock_recv.settimeout(0.5)
        except Exception as e:
            messagebox.showerror("수신 오류", f"포트 {port} 바인드 실패:\n{e}")
            return

        self.recv_running = True
        self.rx_status.config(text="● 수신중", fg="#4cff4c")

        ts = time.strftime("%H:%M:%S")
        self.log_recv(f"[{ts}] ", "time")
        self.log_recv(f"수신 시작 (포트: {port})\n", "rx")

        t = threading.Thread(target=self.recv_loop, daemon=True)
        t.start()

    def recv_loop(self):
        while self.recv_running:
            try:
                data, addr = self.sock_recv.recvfrom(1500)
                self.recv_count += 1
                msg = data.decode('ascii', errors='replace').strip()
                ts = time.strftime("%H:%M:%S")

                # UI 업데이트는 메인 스레드에서
                self.root.after(0, self.on_recv, ts, addr, msg)

            except socket.timeout:
                continue
            except OSError:
                break

    def on_recv(self, ts, addr, msg):
        self.rx_count_label.config(text=f"수신: {self.recv_count}건")

        self.log_recv(f"[{ts}] ", "time")
        self.log_recv(f"RX #{self.recv_count} ", "rx")
        self.log_recv(f"from {addr[0]}:{addr[1]}\n", "info")
        self.log_recv(f"  → {msg}\n", "data")

        # 간단 파싱
        parts = msg.split(',')
        mid = parts[0].strip()
        desc = {"1": "On-line보고", "2": "Vehicle상태", "3": "Station상태",
                "4": "기기상태", "51": "상태요구"}.get(mid, f"ID:{mid}")
        vhl_st = {"1": "운전", "2": "정지", "3": "이상", "4": "수동",
                  "5": "분리", "6": "OBS", "7": "삽체", "8": "HT", "9": "E84"}
        eq_st = {"1": "정상", "2": "이상", "3": "유지보수"}

        extra = ""
        if mid == "2" and len(parts) > 3:
            extra = f" | {parts[2]} {vhl_st.get(parts[3], parts[3])}"
            if len(parts) > 7:
                extra += f" 번지:{parts[7]}"
        elif mid == "4" and len(parts) > 4:
            extra = f" | {parts[3]} {eq_st.get(parts[4], parts[4])}"
        elif mid == "1" and len(parts) > 2:
            extra = f" | {parts[1]} {parts[2]}"

        self.log_recv(f"  [{desc}{extra}]\n\n", "info")

    def stop_recv(self, update_ui=True):
        self.recv_running = False
        if self.sock_recv:
            try:
                self.sock_recv.close()
            except:
                pass
            self.sock_recv = None

        if update_ui:
            try:
                self.rx_status.config(text="● 정지", fg="#f44336")
                ts = time.strftime("%H:%M:%S")
                self.log_recv(f"[{ts}] ", "time")
                self.log_recv(f"수신 정지\n", "warn")
            except:
                pass

    def log_recv(self, text, tag=None):
        try:
            self.rx_log.config(state="normal")
            if tag:
                self.rx_log.insert("end", text, tag)
            else:
                self.rx_log.insert("end", text)
            self.rx_log.see("end")
            self.rx_log.config(state="disabled")
        except:
            pass

    def clear_recv(self):
        self.rx_log.config(state="normal")
        self.rx_log.delete("1.0", "end")
        self.rx_log.config(state="disabled")
        self.recv_count = 0
        self.rx_count_label.config(text="수신: 0건")

    def run(self):
        self.root.mainloop()
        self.stop_recv(update_ui=False)
        try:
            self.sock_send.close()
        except:
            pass


if __name__ == "__main__":
    app = UDPTool()
    app.run()
