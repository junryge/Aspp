"""
MCS MCP  ↔  HCP LLM  tool-calling 어댑터
=======================================
사내 HCP LLM(OpenAI 호환, Qwen3)이 MCP 서버(:8010)의 조회 tool을 직접 호출하게 연결.

흐름:
    질문 → LLM(tools 스키마 포함 호출) → tool_calls 발생 → MCP로 디스패치
         → 결과 회신(tool 메시지) → LLM 재호출 → ... → 최종 답변

의존성(클라 쪽 — 서버와 별개 환경):
    pip download "mcp>=1.27,<2" openai -d ./wheels --only-binary=:all:
    pip install --no-index --find-links=./wheels "mcp>=1.27,<2" openai

설정:
    AGENT_CONF.json (AGENT_CONF.example.json 참고) + TOKEN.TXT 를 실행 디렉터리에.

실행:
    python mcp_llm_agent.py "M16A 3F 허브룸 최근 값 조회해줘"

DEMOS 등에 붙일 때:
    from mcp_llm_agent import run
    answer = asyncio.run(run("..."))   # run() 이 재사용 코어

주의:
    * 이 어댑터는 조회용 MCP(read-only)에 붙는다. 제어(반송/상태변경)는 미포함.
    * Qwen3 thinking이 tool 파싱 깨면 질문 앞에 '/no_think ' 프리픽스.
    * 사내 HTTPS 인증서 막히면 아래 SSL 노트 참고.
"""

import os
import sys
import json
import time
import asyncio
import logging

from openai import OpenAI, APIStatusError
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client


# ---------------------------------------------------------------------------
# 설정 (CWD-first)
# ---------------------------------------------------------------------------
CFG_PATH = os.path.join(os.getcwd(), "AGENT_CONF.json")
if not os.path.exists(CFG_PATH):
    raise SystemExit(f"[FATAL] 설정 없음: {CFG_PATH} (AGENT_CONF.example.json 참고)")

CFG = json.load(open(CFG_PATH, encoding="utf-8"))
LLM = CFG["llm"]                         # {"base_url","model","token_file"}
MCP_URL = CFG["mcp_url"]                 # "http://VM_IP:8010/mcp"
MAX_STEPS = int(CFG.get("max_steps", 8))

with open(LLM.get("token_file", "TOKEN.TXT"), encoding="utf-8") as f:
    TOKEN = f.read().strip()

# 사내 인증서 이슈 시:
#   import httpx
#   client = OpenAI(base_url=LLM["base_url"], api_key=TOKEN,
#                   http_client=httpx.Client(verify=False))   # 또는 사내 CA 등록
client = OpenAI(base_url=LLM["base_url"], api_key=TOKEN)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("mcp-agent")

SYSTEM = (
    "너는 SK Hynix AMHS MCS 데이터 조회 어시스턴트다. "
    "질문에 답하려면 제공된 tool로 실제 DB에서 조회한다. "
    "추측하지 말고 조회한 결과만 근거로 답한다. "
    "테이블/컬럼 구조가 불확실하면 list_tables / describe_table 를 먼저 호출한다."
)


# ---------------------------------------------------------------------------
# 429 지수 백오프 (HCP 게이트웨이 rate limit 대응)
# ---------------------------------------------------------------------------
def chat_with_backoff(**kw):
    delay = 2
    for attempt in range(6):
        try:
            return client.chat.completions.create(**kw)
        except APIStatusError as e:
            if getattr(e, "status_code", None) == 429 and attempt < 5:
                log.warning("429 rate limit — %ss 후 재시도 (%d/5)", delay, attempt + 1)
                time.sleep(delay)
                delay = min(delay * 2, 30)
                continue
            raise


# ---------------------------------------------------------------------------
# MCP tool 스키마 → OpenAI tools 포맷
# ---------------------------------------------------------------------------
def to_openai_tools(mcp_tools):
    return [
        {
            "type": "function",
            "function": {
                "name": t.name,
                "description": t.description or "",
                "parameters": t.inputSchema or {"type": "object", "properties": {}},
            },
        }
        for t in mcp_tools
    ]


def extract_result(tool_result):
    """MCP 결과에서 구조화 데이터 우선, 없으면 텍스트."""
    sc = getattr(tool_result, "structured_content", None)
    if sc is not None:
        return sc
    return "".join(getattr(c, "text", "") for c in (tool_result.content or []))


# ---------------------------------------------------------------------------
# 메인 루프 (재사용 코어)
# ---------------------------------------------------------------------------
async def run(question: str) -> str:
    async with streamablehttp_client(MCP_URL) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()

            listed = await session.list_tools()
            tools = to_openai_tools(listed.tools)
            log.info("MCP tools: %s", [t["function"]["name"] for t in tools])

            messages = [
                {"role": "system", "content": SYSTEM},
                {"role": "user", "content": question},
            ]

            for step in range(MAX_STEPS):
                resp = chat_with_backoff(
                    model=LLM["model"],
                    messages=messages,
                    tools=tools,
                    tool_choice="auto",
                    temperature=0,
                )
                msg = resp.choices[0].message

                # tool 호출 없으면 최종 답변
                if not msg.tool_calls:
                    return msg.content or ""

                # 어시스턴트 메시지(tool_calls 포함) 기록
                messages.append(msg.model_dump(exclude_none=True))

                # 각 tool_call 을 MCP 로 디스패치
                for tc in msg.tool_calls:
                    name = tc.function.name
                    try:
                        args = json.loads(tc.function.arguments or "{}")
                    except json.JSONDecodeError:
                        args = {}
                    log.info("→ MCP call %s(%s)", name, args)
                    result = extract_result(await session.call_tool(name, args))
                    messages.append({
                        "role": "tool",
                        "tool_call_id": tc.id,
                        "content": json.dumps(result, ensure_ascii=False, default=str),
                    })

            return "최대 스텝 도달 — tool 루프 종료"


if __name__ == "__main__":
    q = sys.argv[1] if len(sys.argv) > 1 else "health tool로 접속 상태 확인해줘"
    print(asyncio.run(run(q)))
