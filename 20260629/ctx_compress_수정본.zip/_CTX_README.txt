ctx_compress 컨텍스트 압축 가드 — 수정본 (커밋 50e3dac)
브랜치: claude/check-zoneinfo-areas-dpraG

[신규 파일]
  ctx_compress.py            압축 엔진 본체(stdlib only)
  context_guard.py           ★가드 (원본 불변 non-mutating 최종본)
  context_guard_v2.py        축출 검증본(참고)
  ctx_guard_verify.py        재현용 검증 스크립트

[배선된 기존 파일 - 각 한 줄 추가]
  demos_v1/routes_chat.py             : line 1197  api_messages = _ctx_guard_demos.maybe_compress(api_messages)
       → 데모스 / 개인에이전트 / UIO (같은 /api/chat 공유)
  code_assist_v1/routes_chat_stream.py: line 255   messages = _ctx_guard_code.maybe_compress(messages)
       → 코딩어시스턴트

[핵심 안전성]
  - 예산 여유(짧은 대화)면 입력 그대로 반환(무변형)
  - 원본 메시지 딕셔너리 절대 불변, 최근 keep_recent 턴 보존
  - 예외/부팅실패해도 no-op 폴백 → 채팅 안 끊김
  - 검증: 73턴→400턴+ 확장, 2000턴 128K bounded, 복구 OK
