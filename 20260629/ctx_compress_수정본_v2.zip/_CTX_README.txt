ctx_compress 컨텍스트 압축 가드 — 최신 수정본 (커밋 7fb4651)
브랜치: claude/check-zoneinfo-areas-dpraG

[신규 파일]
  ctx_compress.py            압축 엔진 본체(stdlib only)
  context_guard.py           ★가드 최종본
  context_guard_v2.py        축출 검증본(참고)
  ctx_guard_verify.py        재현용 검증 스크립트

[배선된 기존 파일 - 각 한 줄 추가]
  demos_v1/routes_chat.py             : line 1197  api_messages = _ctx_guard_demos.maybe_compress(api_messages)
       → 데모스 / 개인에이전트 / UIO (같은 /api/chat 공유)
  code_assist_v1/routes_chat_stream.py: line 255   messages = _ctx_guard_code.maybe_compress(messages)
       → 코딩어시스턴트

[이번 버전 핵심]
  - 원본 메시지 딕셔너리 절대 불변(non-mutating) → 기존 기능 무영향
  - system(스킬) 메시지는 접지·축출 안 함 → 스킬 무손실
  - 로그 출력:
      [ctx_compress] 데모스 압축: 131,224 → 3,145 토큰 (접음 59, 축출 0, 복구맵 59)
      [ctx_compress] 데모스 통과: 5,200 토큰 (발동선 22,400 미달 → 무압축)   ← debug=True
  - 예산 여유(짧은 대화)면 무변형 / 예외·부팅실패해도 no-op 폴백
  - 조용히 하려면 배선점의 debug=True → False

[검증] 73턴→400턴+ 확장, 2000턴 128K bounded, 원본/스킬 불변, 복구 OK
