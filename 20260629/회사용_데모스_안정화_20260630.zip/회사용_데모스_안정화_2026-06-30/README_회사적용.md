# [회사용] 데모스 안정화 적용 가이드 (2026-06-30)

## 대상: 회사 데모스 서버 scientific-assistant/demos_v1/

## 적용 순서
1. 아래 4개 파일을 회사 서버 `demos_v1/` 에 덮어쓰기 (index.html 은 templates/ 안)
   - demos_v1/__init__.py
   - demos_v1/routes_api.py
   - demos_v1/routes_chat.py
   - demos_v1/templates/index.html
2. (권장) 덮어쓰기 전 원본 백업
3. 데모스 재시작
4. 부팅 로그에서 `🧰 하네스 등록 완료 (389개 스킬...)` 확인

## 변경 요약
- 세션 전환 시 과거 세션 이동·소멸 버그 수정
- 하네스 스킬 라우터 켜짐(389스킬) + 추천량 축소 + 중복버그 수정
- 개인 에이전트는 하네스 완전 차단
- GGUF 12B 이하 n_ctx 32K→64K (26~35B·API는 유지) ※회사 GPU VRAM 확인 후

## 주의 (회사 환경)
- n_ctx 64K는 3090 24GB 기준. 회사 GPU VRAM 이 더 작으면
  routes_chat.py 의 `_gguf_default_n_ctx` 에서 65536 을 낮추거나 임계(<=12)를 조정.
- VRAM 넉넉하면 임계를 더 올려도 됨(예: <=27 까지).
