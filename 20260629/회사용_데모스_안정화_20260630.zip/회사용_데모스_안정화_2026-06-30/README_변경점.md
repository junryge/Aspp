# 데모스 안정화 변경점 (2026-06-30)

## 수정 파일 4개 (demos_v1/ 에 그대로 덮어쓰기)

| 파일 | 변경 내용 | 커밋 |
|---|---|---|
| `templates/index.html` | 세션 전환 시 과거 세션이 목록에서 이동·소멸하던 버그 수정 (saveCurrentSession(bump) — 메시지 추가 때만 updatedAt 갱신) | 0a48cfa |
| `__init__.py` | 하네스(harness) 스킬 라우터 시작 시 초기화 연결 (init_harness + register_harness_routes). 안 불려서 꺼져있던 것을 켬 (389스킬) | 4cc3086 |
| `routes_api.py` | 하네스 중복추가 버그 수정 + 추천량 축소(라우터5→2·Expert3→1·조합2→1) — 컨텍스트 과다 완화 | 12a45fa |
| `routes_chat.py` | ① 개인에이전트 하네스 완전 차단(_is_agent_chat) ② GGUF 12B↓ n_ctx 32K→64K(26~35B·API는 유지) | 12a45fa, 6913c31 |

## 적용
1. 4개 파일 demos_v1/ 에 덮어쓰기 (index.html 은 templates/ 안)
2. 데모스 재시작
3. 부팅 로그 확인:
   - `🧰 하네스 등록 완료 (389개 스킬...)` ← 하네스 켜짐
4. 9B/12B 모델로 스킬 많이 붙여 질문 → n_ctx 65536, 잘림 경고 사라짐

## 주의
- 개인 에이전트엔 하네스 영향 0 (차단됨)
- 26~35B 모델·API 모델은 기존과 동일(현상태 유지)
