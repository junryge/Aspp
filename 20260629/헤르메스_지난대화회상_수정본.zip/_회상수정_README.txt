헤르메스 "지난 대화 회상" 수정본
커밋: 8241cd0 → 70a419d → f68bf4d  (브랜치 claude/check-zoneinfo-areas-dpraG)

[문제]
  "지난 대화 기억해?" 물으면 못 기억함.
  ① build_system_prompt 가 세션(지난 대화 원문)을 채팅에 안 넣었음(기억 사실만 주입)
  ② BM25 검색이라 일반 회상질문은 0건 → 주입 0
  ③ 데모스는 자동 스킬 215KB에 회상 블록이 묻힘 (개인에이전트는 가벼워서 됨)

[수정 파일]
 1) demos_v1/hermes/engine.py   (커밋 8241cd0 + 70a419d)
    - build_system_prompt 에 sessions.search(질문) 결과 '지난 대화 관련 기록' 주입
    - 회상 의도 키워드(지난/이전/전에/기억/저번/아까/말했/얘기한/직전 등) 감지 시
      검색 매칭과 무관하게 sessions._load_all 최근 14개 '원문' 주입 +
      "이전 대화를 기억하지 못한다고 답하지 마라" 명시
 2) demos_v1/templates/index.html   (커밋 f68bf4d, A안)
    - 헤르메스 ON + 회상 질문이면 skillsToUse·autoLoaded 비워 무거운 자동스킬 스킵
      → 회상 블록이 안 묻히게

[안전]
  - engine: query 있을 때만·try/except 로 prep 안 깨짐, 데모스/개인에이전트만 영향
  - index: 헤르메스 ON + 회상 키워드일 때만 → 일반 질문·스킬 영향 0

[테스트]
  서버 재시작 → 데모스 헤르메스 켜고 "지난 대화 기억해? 말해줘"
  → '🧠 자동 스킬…' 안 뜨고 지난 대화 근거로 답하면 정상.
  (demos_data/agents/<user>/sessions/*.jsonl 에 대화 저장돼 있어야 함)
