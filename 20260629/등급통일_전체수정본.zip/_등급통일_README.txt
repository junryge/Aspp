등급 임계 통일 전체 수정본 (커밋 f0c34c8 → 5e13807 → 9ba2b6b)
브랜치: claude/check-zoneinfo-areas-dpraG

[통일된 등급 — 전 계층 동일]
  정상 <50 · 🟠경계 50~70 · 🔴위험 71~84 · ⛔초위험 85~100  (1~100 정규화)

[수정 파일]
 1) m16_hub_skills/발동이벤트_요약.py
      _level_from 85/71/50, MIN_SCORE 54→50, 컬럼 정체분(50+), 주석/로그
 2) m16_hub_skills/m16_hub_결과해석_도메인_고객인용V3.5.md
      §5 등급표 + 보고서 템플릿 등급표(3곳) + 가로표기 + 정체판정 54→50
 3) m16_hub_skills/m16_hub_카파시_v3.5.md
      §6 raw→min(100,round(raw/2.2)) 정규화 명시, §7 1~100 등급표로 교체,
      §2·§8 사건 floor 100→50
 4) m16_hub_skills/m16_hub_일반_v3.5.md
      사건 기록 '점수 100+'→'50+', 'max_risk_level=위험/발동'→'위험/초위험'
 5) M16_BR_개인지식/스크립트/hubroom_predictor.py  (엔진)
      unified_risk_score = min(100, round(raw/2.2)) 정규화,
      등급 4단계(정상<50/경계50~70/위험71~84/초위험85~100),
      사건 기록 floor 65→50 (2곳)
 6) rool_skill_test/hubroom_predictor.py  (엔진 동일 복사본, 5와 동일)

[검증]
  경계값: 49정상 / 50~70경계 / 71~84위험 / 85~100초위험
  raw→정규화: 110→50경계, 156→71위험, 187→85초위험. 전 파일 문법 OK.

[안 건드림]
  - flow의 주의/위험/심각 라벨(별개 분류)
  - WORD_MODEL/.../hubroom_predictor.py (741줄 구버전) — 프로덕션 엔진 확인 필요

[미해결]
  - 페르소나_통합.txt : 저장소에 없음(업로드 안 됨). 등급표 있으면 파일 주시면 같은 기준으로 수정.
