전체 수정본 (브랜치 claude/check-zoneinfo-areas-dpraG, main 대비)
커밋: 522dd7b→50e3dac→2832def→7fb4651→cd50815→f0c34c8→5e13807→9ba2b6b

═══ ① ctx_compress (긴 세션 컨텍스트 끊김 방지) ═══
  ctx_compress.py            압축 엔진
  context_guard.py           가드(원본 불변·스킬 보존·로그·debug)
  context_guard_v2.py        축출 검증본
  ctx_guard_verify.py        검증 스크립트
  ctx_compress_guide.html    가이드
  demos_v1/routes_chat.py           ← 데모스/개인에이전트/UIO 배선(maybe_compress)
  code_assist_v1/routes_chat_stream.py ← 코딩어시스턴트 배선

═══ ② 헤르메스 자동기억 (기억이 실제로 쌓이게) ═══
  demos_v1/__init__.py       ← review.set_completion() LLM 완성함수 주입
                                (백그라운드 전용, 다른 표면 무영향)

═══ ③ 등급 임계 통일 (1~100 / 정상<50·경계50~70·위험71~84·초위험85~100) ═══
  m16_hub_skills/발동이벤트_요약.py
  m16_hub_skills/m16_hub_결과해석_도메인_고객인용V3.5.md
  m16_hub_skills/m16_hub_카파시_v3.5.md
  m16_hub_skills/m16_hub_일반_v3.5.md
  M16_BR_개인지식/스크립트/hubroom_predictor.py   (엔진: raw→min(100,round/2.2) 정규화)
  rool_skill_test/hubroom_predictor.py            (엔진 동일 복사본)

[안 건드림] flow 라벨(주의/위험/심각), WORD_MODEL 741줄 구엔진
[미해결]   페르소나_통합.txt — 저장소에 없음(업로드 필요)
