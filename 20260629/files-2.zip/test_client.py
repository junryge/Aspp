"""
서버 생사 실측용 클라이언트.
MCP Inspector(Node/npx)는 폐쇄망에서 못 쓰니 이걸로 확인한다.

실행:
    python test_client.py
기대 출력:
    tools: ['health', 'list_tables', 'describe_table', 'oracle_query']
    health: {'ok': True, 'dsn': '...', 'mode': 'thin'}
안 나오면 서버가 죽은 것 (클라 문제 아님) — db_mcp.py 콘솔/mcp_audit.log 봐라.
"""

import asyncio

from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

URL = "http://127.0.0.1:8010/mcp"     # 원격 확인 시 VM_IP로 교체


async def main():
    async with streamablehttp_client(URL) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()

            tools = await session.list_tools()
            print("tools:", [t.name for t in tools.tools])

            h = await session.call_tool("health", {})
            print("health:", h.structured_content)

            # 스키마 확인 예시 (필요 시 주석 해제)
            # t = await session.call_tool("list_tables", {"name_like": "HUB"})
            # print("tables:", t.structured_content)


if __name__ == "__main__":
    asyncio.run(main())
