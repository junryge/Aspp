"""
MCS I/F MCP Gateway — 초기 코드 (Phase 1: DB 조회 전용, read-only)
================================================================
- oracledb THIN mode  : Oracle Client 불필요 (RHEL/Windows 공통)
- streamable-http     : http://VM_IP:8010/mcp  (여러 Agent/호스트 동시 접속)
- 읽기전용 가드        : SELECT/WITH 만 통과, 결과 상한 강제, 다중문장 차단

폐쇄망 설치:
    # 외부망에서 wheel 확보
    pip download "mcp>=1.27,<2" oracledb -d ./wheels --only-binary=:all:
    # 폐쇄망에서
    pip install --no-index --find-links=./wheels "mcp>=1.27,<2" oracledb

실행 (WorkingDirectory에 DB_CONF.json 필요 — CWD-first):
    python db_mcp.py         ->  http://VM_IP:8010/mcp

검증 (MCP Inspector는 Node라 폐쇄망 사용 불가):
    python test_client.py

주의:
    * 반송 명령/목적지/장비 상태 변경(제어=write)은 이 코드에 없다. Phase 2에서
      사람 승인 게이트 + 화이트리스트 + 감사로그 얹어서 별도로 붙인다.
    * 32비트 Oracle Client가 필요한 MCS 제어 I/F는 Windows Java8 브리지에서 처리.
      이 서버(조회)는 thin이라 64비트 Python으로 돌려도 무방.
"""

import os
import re
import json
import logging

import oracledb
from mcp.server.fastmcp import FastMCP


# ---------------------------------------------------------------------------
# 설정 로드 (CWD-first: 실행 디렉터리의 DB_CONF.json)
# ---------------------------------------------------------------------------
CFG_PATH = os.path.join(os.getcwd(), "DB_CONF.json")
if not os.path.exists(CFG_PATH):
    raise SystemExit(f"[FATAL] 설정 파일 없음: {CFG_PATH}  (DB_CONF.example.json 참고)")

with open(CFG_PATH, encoding="utf-8") as f:
    CFG = json.load(f)

ORA = CFG["oracle"]                 # {"user","pw","dsn"}  dsn 예: "scan-vip:1521/MCS_SVC"
PORT = int(CFG.get("port", 8010))
MAX_ROWS = int(CFG.get("max_rows", 500))


# ---------------------------------------------------------------------------
# 로깅 (요청/감사 분리 준비 — 파일 + 콘솔)
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[
        logging.FileHandler("mcp_audit.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("mcs-db-mcp")


# ---------------------------------------------------------------------------
# MCP 서버
# ---------------------------------------------------------------------------
mcp = FastMCP("mcs-db", host="0.0.0.0", port=PORT)


# ---------------------------------------------------------------------------
# 읽기전용 가드 (1차 방어 — 최종 방어는 DB 계정 권한)
# ---------------------------------------------------------------------------
_WRITE = re.compile(
    r"\b(insert|update|delete|drop|alter|truncate|merge|create|grant|revoke|"
    r"begin|declare|call|execute|exec|commit|rollback|savepoint)\b",
    re.IGNORECASE,
)


def _guard(sql: str) -> str:
    """SELECT/WITH 만 허용하고 결과 상한을 강제한다."""
    s = sql.strip().rstrip(";").strip()
    low = s.lower()

    if not (low.startswith("select") or low.startswith("with")):
        raise ValueError("SELECT/WITH 문만 허용된다 (조회 전용 게이트웨이)")
    if _WRITE.search(s):
        raise ValueError("쓰기/실행성 키워드가 감지되어 차단되었다")
    if ";" in s:
        raise ValueError("다중 문장은 허용되지 않는다")

    # 결과 상한 강제 (Oracle top-N 관용구: 인라인뷰 정렬 유지 후 ROWNUM 필터)
    if "rownum" not in low and "fetch first" not in low:
        s = f"SELECT * FROM (\n{s}\n) WHERE ROWNUM <= {MAX_ROWS}"
    return s


def _connect():
    # thin mode: init_oracle_client() 호출 안 함 = Oracle Client 라이브러리 불필요
    return oracledb.connect(user=ORA["user"], password=ORA["pw"], dsn=ORA["dsn"])


def _rows(cur):
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------
@mcp.tool()
def health() -> dict:
    """게이트웨이/DB 접속 상태 확인. SELECT 1 로 실측한다."""
    try:
        with _connect() as con:
            cur = con.cursor()
            cur.execute("SELECT 1 FROM dual")
            cur.fetchone()
        return {"ok": True, "dsn": ORA["dsn"], "mode": "thin"}
    except Exception as e:
        log.exception("health check 실패")
        return {"ok": False, "error": str(e)}


@mcp.tool()
def list_tables(owner: str = "", name_like: str = "") -> list[dict]:
    """조회 가능한 테이블/뷰 목록. owner=스키마, name_like=이름 부분일치 필터.
    Agent가 어떤 테이블이 있는지 파악할 때 먼저 호출한다."""
    base = (
        "SELECT owner, table_name AS obj_name, 'TABLE' AS obj_type FROM all_tables "
        "UNION ALL "
        "SELECT owner, view_name  AS obj_name, 'VIEW'  AS obj_type FROM all_views"
    )
    outer = f"SELECT * FROM ({base}) t WHERE 1=1"
    binds = {}
    if owner:
        outer += " AND UPPER(owner) = UPPER(:o)"
        binds["o"] = owner
    if name_like:
        outer += " AND UPPER(obj_name) LIKE UPPER(:n)"
        binds["n"] = f"%{name_like}%"
    outer += f" ORDER BY owner, obj_name FETCH FIRST {MAX_ROWS} ROWS ONLY"

    with _connect() as con:
        cur = con.cursor()
        cur.execute(outer, binds)
        return _rows(cur)


@mcp.tool()
def describe_table(table: str, owner: str = "") -> list[dict]:
    """테이블/뷰의 컬럼 스키마(이름/타입/길이/NULL여부). Agent가 쿼리 작성 전
    컬럼 구조를 확인하는 용도. IDC 컬럼처럼 많은 경우 필수."""
    q = (
        "SELECT column_name, data_type, data_length, nullable "
        "FROM all_tab_columns WHERE UPPER(table_name) = UPPER(:t)"
    )
    binds = {"t": table}
    if owner:
        q += " AND UPPER(owner) = UPPER(:o)"
        binds["o"] = owner
    q += " ORDER BY column_id"

    with _connect() as con:
        cur = con.cursor()
        cur.execute(q, binds)
        return _rows(cur)


@mcp.tool()
def oracle_query(sql: str) -> list[dict]:
    """MCS Oracle 조회 (읽기전용). SELECT/WITH 만 허용되며 결과 상한이
    자동 적용된다. 쓰기/제어 명령은 이 도구로 실행되지 않는다."""
    safe = _guard(sql)
    log.info("QUERY %s", safe.replace("\n", " "))
    with _connect() as con:
        cur = con.cursor()
        cur.execute(safe)
        return _rows(cur)


if __name__ == "__main__":
    log.info("MCS DB MCP 시작 (thin) :%s  ->  http://VM_IP:%s/mcp", PORT, PORT)
    mcp.run(transport="streamable-http")
