# MCS DB MCP Gateway — Phase 1 (조회 전용)

Agent ↔ MCS DB 조회용 MCP 서버. `oracledb` **thin 모드**라 Oracle Client 불필요.
전송은 **streamable-http** — 여러 Agent/호스트가 URL로 동시 접속.

## 구성

| 파일 | 역할 |
|---|---|
| `db_mcp.py` | MCP 서버 본체 (read-only 가드 + 조회 tool 4종) |
| `test_client.py` | 서버 생사 실측 (MCP Inspector는 폐쇄망 불가) |
| `DB_CONF.example.json` | 설정 예시 → `DB_CONF.json`으로 복사 |
| `requirements.txt` | 의존성 (`mcp>=1.27,<2`, `oracledb`) |

## 설치 (폐쇄망)

```bash
# 외부망 — 의존성까지 wheel로 확보 (OS/파이썬 버전 맞춰서)
pip download -r requirements.txt -d ./wheels --only-binary=:all:

# 폐쇄망 — 반입 후
pip install --no-index --find-links=./wheels -r requirements.txt
```

`--only-binary=:all:` 안 하면 sdist 딸려와 빌드 터진다. wheel만 받아라.

## 설정

```bash
cp DB_CONF.example.json DB_CONF.json
# user / pw / dsn 채우고
chmod 600 DB_CONF.json          # Windows면 ACL로 서비스 계정만
```
- `dsn` 예 (RAC SCAN): `scan-vip:1521/MCS_SVC`
- **DB 계정은 반드시 SELECT 전용.** 서버 정규식 가드는 2차 방어일 뿐, 계정 권한이 최종 벽.

## 실행

```bash
python db_mcp.py        # -> http://VM_IP:8010/mcp  (DB_CONF.json 있는 디렉터리에서)
```

상주화:
- **Linux** — systemd `Restart=always`, `WorkingDirectory`에 DB_CONF.json
- **Windows** — Windows Service (nssm 또는 `sc create`)

## 검증

```bash
python test_client.py
# tools: ['health', 'list_tables', 'describe_table', 'oracle_query']
# health: {'ok': True, 'dsn': '...', 'mode': 'thin'}
```
안 나오면 서버가 죽은 것 — `mcp_audit.log`/콘솔 확인. 추측 말고 로그로 본다.

## Tool 목록

| tool | 설명 |
|---|---|
| `health` | 게이트웨이/DB 접속 확인 (SELECT 1) |
| `list_tables(owner, name_like)` | 조회 가능한 테이블/뷰 목록 |
| `describe_table(table, owner)` | 컬럼 스키마 (Agent가 쿼리 짜기 전 구조 파악) |
| `oracle_query(sql)` | SELECT/WITH 조회 (결과 상한 자동) |

## 경계 (중요)

- **반송 명령 / 목적지 요청 / 장비 상태 변경 = 제어(write). 이 코드에 없다.**
- 제어는 Phase 2에서 **사람 승인 게이트 + 명령 화이트리스트 + 전량 감사로그** 얹어서 별도로.
- 제어 I/F는 32비트 Java8 레거시 → Windows 브리지에서. 이 조회 서버는 thin이라 무관.
