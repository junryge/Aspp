사건발생 보고서 샘플5 형식 + AMOS 이상감지 (커밋 5607d33)
브랜치: claude/check-zoneinfo-areas-dpraG

[반영된 것]
 발동이벤트.csv 신규 4컬럼: BOTTLENECK_downward/upward_anomaly_cols,
                            QUEUE_downward/upward_anomaly_cols
 보고서 = 샘플5.html 5섹션:
   1. 한 줄 총평(등급 기준 inline)
   2. AMOS 이상 감지 내역 — 번호/이상감지 시간(=사건 최고점)/구간(HID)/
      심각도[주의(확인필요)·경고(모니터링 필요)·심각(조치필요) ← 경계·위험·초위험 매핑]/
      항목(그래프 STAR 지표 + QUEUE 이상컬럼, <br> 줄바꿈)/실제 발생여부(체크박스)
   3. 실제 이상 발생내역 — 체크 시 행 자동 생성, 해제 시 제거, '+ 수동 기입' 항상 표시
   4. 위험 이벤트 상세 분석 — 그래프 + 이벤트별 현상/원인/인과 (기존 그대로)
   5. 에이전트 제안
 저장/복원: 💾저장(localStorage 자동복원)·📄파일로 저장 — 샘플5 JS 그대로 이식

[수정 파일]
 demos_v1/routes_chat.py        내장요약 ④ AMOS 추가 + 옛 임계 50/71/85 수정 + amosify 배선
 demos_v1/amos_report.py        ★신규 — 인터랙티브 주입 모듈(체크박스/수동기입/저장 JS)
 m16_hub_skills/페르소나_통합.txt              [B] 5섹션 + AMOS 규칙
 m16_hub_skills/m16_hub_결과해석_...V3.5.md    [B] 5섹션 + 신규 4컬럼 설명(§2)
 m16_hub_skills/m16_hub_일반_v3.5.md           컬럼 139 + 신규 컬럼 소개
 m16_hub_skills/m16_hub_카파시_v3.5.md         §8.5 AMOS 컬럼 + 심각도 매핑
 m16_hub_skills/발동이벤트_요약.py             ④ AMOS이상감지 CSV 출력 추가
 (m16_hub_임계값: anomaly 컬럼과 무관 — 변경 없음)

[동봉] 데모_20260709_사건발생보고서.html — 7/9 실데이터로 생성한 완성 예시
       (열어서 체크박스·수동기입·저장 동작 확인 가능)

[검증] 7/9 CSV 1440행: ④ 2건(10:27 82점→경고 / 15:40 54점→주의),
       인터랙티브 변환 9항목 전부 PASS. 서버 재시작 후 반영.
