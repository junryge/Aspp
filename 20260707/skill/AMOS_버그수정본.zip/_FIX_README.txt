AMOS 보고서 버그 3종 수정 (커밋 참조: git log)
[원인] 다운로드 HTML은 routes_api.py 별도 생성기가 만듦 → 인터랙티브 주입 누락
[수정]
 1) demos_v1/routes_api.py    ★핵심 — md→html 생성기에 amosify 배선
 2) demos_v1/amos_report.py   총평 등급표 자동 제거 추가
 3) demos_v1/routes_chat.py   ④ 항목 = raw 컬럼명만
 4) m16_hub_skills/발동이벤트_요약.py  ④ 항목 = raw 컬럼명만
 5) m16_hub_skills/페르소나_통합.txt   [B] 등급표 금지 + 항목 raw-only
 6) m16_hub_skills/m16_hub_결과해석_...V3.5.md  동일
[동봉] 수정후_20260709_보고서.html — 고객이 받았던 실패 HTML에 수정 적용한 결과
[적용] 파일 배포 후 서버 재시작 → 다시 '사건발생 분석' 하면 체크박스·수동기입 나옴
