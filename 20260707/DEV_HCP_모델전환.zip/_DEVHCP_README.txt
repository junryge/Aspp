모델 API DEV.HCP 7종 전환 (커밋 83676a7)
브랜치: claude/check-zoneinfo-areas-dpraG

[최종 7종 — 전부 http://dev.hcp.llm.skhynix.com/v1/chat/completions]
  1. Qwen3.5-397B-A17B-Thinking  (신규) env_id=q397-thinking
  2. Qwen3.5-397B-A17B-vlm                q397-vlm
  3. Qwen3.6-35B-A3B                      q36-hcp
  4. GLM-5.1                              glm51
  5. Qwen3.5-122B-A10B-mail               q122-mail
  6. gpt-oss-120b                         oss120
  7. Qwen3.5-397B-A17B                    q397
  → 스파크·common.llm·summary·FP8·중복 전부 제거. DEV.HCP 우선.

[수정 파일]
 1) api_config.json               (데모스) — models 7종 + tier/fallback/priority 재정렬
 2) code_assist_v1/api_config.json (코딩어시스턴트) — 동일
 3) uio/index.html                — recommendEnv 추천·대형모델 판정 새 env_id로
 4) uio/dashboard/index.html      — 모델 드롭다운·비용표(COST_RATES) 7종으로

[중요]
 - UIO 메인 드롭다운은 /api/config 동적 로드 → 백엔드 JSON 변경으로 자동 반영(스파크 자동 사라짐)
 - HCP 모델은 전역 토큰(TOKEN.TXT) 사용. 별도 토큰 필요하면 각 모델에 token_file 추가.
 - Thinking 모델 실제 게이트웨이 문자열이 다르면 model 값만 교체.

[확인] 서버 재시작 후 모델 목록에 7종만 뜨는지.
