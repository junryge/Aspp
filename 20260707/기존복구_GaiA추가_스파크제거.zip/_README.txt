기존 모델 복구 + GaiA 신규 추가 + 스파크 제거 (커밋 42249eb)
브랜치: claude/check-zoneinfo-areas-dpraG

[구성] 총 23모델 = GaiA 신규 9 + 기존 14 (스파크 0)

■ GaiA 신규 (gaia-* 팀허용 ID, dev.hcp 게이트웨이) — 기본 우선
  gaia-Qwen3.5-397B-A17B / gaia-GLM-5.2 / gaia-GLM-5.1 / gaia-Qwen3.6-35B-A3B /
  gpt-oss-120b / gaia-cc-gpt-oss-120b / gaia-lst-gpt-oss-120b /
  Qwen3.5-397B-A17B-vlm / GaiA-LLM-Latest
■ 기존 복구 14 (common.llm / summary / dev.hcp) — 그대로 유지
■ 스파크(spark-*) 6종 완전 제거

[수정 파일]
 1) api_config.json               (데모스)
 2) code_assist_v1/api_config.json (코딩어시스턴트)
 3) uio/index.html                (추천·대형판정 GaiA 우선)
 4) uio/dashboard/index.html      (드롭다운 GaiA 그룹 추가·스파크 없음, 비용표 GaiA 추가)

[중요]
 - UIO 메인 드롭다운은 /api/config 동적 로드 → 백엔드 변경 자동 반영
 - 기본 우선순위 = GaiA (팀 허용이라 403 안 남). 기존 common/summary 모델은
   팀 접근 권한에 따라 403 날 수 있음(원하셔서 복구만 해둠).
 - 서버 재시작 후 반영.
