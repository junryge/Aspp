[데모스 gemma 모델 HTTP 500 수정]
브랜치: claude/practical-carson-WKG6M (커밋 4ab7918)
※ 경로 그대로 레포 루트에 덮어쓰기 후 서버 재시작.

== 원인 ==
gemma 계열은 채팅 템플릿에 system 역할이 없음. 데모스는 항상
system_prompt(스킬/페르소나/지침)를 system 역할로 보내므로, gemma 선택 시
게이트웨이가 템플릿 적용 실패 → HTTP 500. (다른 모델 Qwen/gpt-oss 는 정상)

== 수정 ==
gemma 로 보낼 때만 system 내용을 첫 user 메시지 앞에 합쳐 전송. 그 외 모델 무변경.
모든 chat 호출(req.post)을 chat_post 로 교체해 전송 직전 자동 보정.

== 포함 파일 ==
  scientific-assistant/demos_v1/llm_compat.py    ← 신규(핵심): system→user 폴딩 + chat_post
  scientific-assistant/demos_v1/routes_chat.py   ← req.post 7곳 → chat_post
  scientific-assistant/demos_v1/engine.py        ← chat_post
  scientific-assistant/demos_v1/logpresso.py     ← chat_post
  scientific-assistant/demos_v1/skills.py        ← chat_post
  scientific-assistant/demos_v1/routes_api.py    ← chat_post

※ 이 수정은 앞서 보낸 'API 모델 5종 변경' 위에 얹는 것. (api_config.json 변경이 선행돼야 함)
