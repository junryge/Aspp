# -*- coding: utf-8 -*-
"""main.py - 파일 비서 (Gemma 4B / Vulkan)
실행: python main.py
필요: pip install llama-cpp-python(Vulkan wheel), watchdog
기능: ①파일찾기 ②경로보기 ③파일요약 ④텍스트요약 ⑤코드작성 ⑥코드리뷰 ⑦작업로그 ⑧실시간감시
+ 설정창에서 색상 테마 변경(즉시 적용, 저장됨)
"""
import os
import threading
import queue
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from config import load_config, save_config
from llm_engine import LLMEngine
from watcher import WorkLogger, FolderWatcher
from themes import THEMES, get_theme
import file_tools as ft

FONT   = ("Malgun Gothic", 10)
FONT_B = ("Malgun Gothic", 10, "bold")
FONT_S = ("Malgun Gothic", 9)


class App:
    def __init__(self, root):
        self.root = root
        root.title("파일 비서 — Gemma 4B (Vulkan)")
        root.geometry("1060x680")

        self.cfg = load_config()
        self.C = get_theme(self.cfg.get("theme"))
        self.engine = LLMEngine()
        self.logger = WorkLogger(self.cfg["log_path"])
        self.watcher = FolderWatcher(self.logger)

        self.history = []
        self.files = []
        self.q = queue.Queue()
        self.busy = False
        self._themed = []      # (widget, {tk옵션: 테마키}) — 테마 변경 시 일괄 적용

        self._build_ui()
        self._apply_theme()
        self._poll()
        self._refresh_files()
        self._load_model_async()
        self._start_watch()
        root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ════════════════ 테마 ════════════════
    def _reg(self, widget, mapping):
        """위젯을 테마 적용 대상으로 등록. mapping 예: {'bg':'PANEL','fg':'TEXT'}"""
        self._themed.append((widget, mapping))
        return widget

    def _apply_theme(self):
        """현재 self.C 테마를 등록된 모든 위젯에 적용."""
        for w, mp in self._themed:
            try:
                w.configure(**{opt: self.C[key] for opt, key in mp.items()})
            except tk.TclError:
                pass
        # 채팅 태그 색
        self.chat.tag_config("user", foreground=self.C["ACCENT"], font=FONT_B)
        self.chat.tag_config("bot", foreground=self.C["OK"], font=FONT_B)
        self.chat.tag_config("sys", foreground=self.C["DIM"])
        self.chat.tag_config("err", foreground=self.C["ERR"])
        # 리스트 선택색
        self.file_list.configure(selectbackground=self.C["ACCENT"],
                                 selectforeground=self.C["BG"])

    def _set_theme(self, name):
        self.cfg["theme"] = name
        self.C = get_theme(name)
        save_config(self.cfg)
        self._apply_theme()

    # ════════════════ UI 구성 ════════════════
    def _build_ui(self):
        self._reg(self.root, {"bg": "BG"})

        # ── 상단바 ──
        top = self._reg(tk.Frame(self.root), {"bg": "PANEL"})
        top.pack(fill="x")
        self._btn(top, "⚙ 설정", self._open_settings).pack(side="left", padx=8, pady=6)
        self._btn(top, "📂 폴더 변경", self._change_folder).pack(side="left", padx=2)
        self._btn(top, "🔄 새로고침", self._refresh_files).pack(side="left", padx=2)
        self.watch_lbl = self._reg(tk.Label(top, text="감시 ○ 꺼짐", font=FONT),
                                   {"bg": "PANEL", "fg": "DIM"})
        self.watch_lbl.pack(side="right", padx=10)
        self._btn(top, "감시 ON/OFF", self._toggle_watch).pack(side="right", padx=4)
        self.model_lbl = self._reg(tk.Label(top, text="모델 로딩중...", font=FONT),
                                   {"bg": "PANEL", "fg": "WARN"})
        self.model_lbl.pack(side="right", padx=10)

        # ── 본문 좌/우 ──
        body = self._reg(tk.Frame(self.root), {"bg": "BG"})
        body.pack(fill="both", expand=True, padx=8, pady=6)

        # 좌측 파일 패널
        left = self._reg(tk.Frame(body, width=340), {"bg": "PANEL"})
        left.pack(side="left", fill="y", padx=(0, 6))
        left.pack_propagate(False)

        self._reg(tk.Label(left, text="파일", font=FONT_B),
                  {"bg": "PANEL", "fg": "ACCENT"}).pack(anchor="w", padx=10, pady=(8, 2))
        srow = self._reg(tk.Frame(left), {"bg": "PANEL"})
        srow.pack(fill="x", padx=8)
        self.search_var = tk.StringVar()
        se = self._reg(tk.Entry(srow, textvariable=self.search_var, relief="flat", font=FONT),
                       {"bg": "INPUT", "fg": "TEXT", "insertbackground": "TEXT"})
        se.pack(side="left", fill="x", expand=True, ipady=4)
        se.bind("<Return>", lambda e: self._search())
        self._btn(srow, "검색", self._search).pack(side="left", padx=4)

        self.stats_lbl = self._reg(tk.Label(left, text="", font=FONT_S,
                                            wraplength=320, justify="left"),
                                   {"bg": "PANEL", "fg": "DIM"})
        self.stats_lbl.pack(anchor="w", padx=10, pady=2)

        lf = self._reg(tk.Frame(left), {"bg": "PANEL"})
        lf.pack(fill="both", expand=True, padx=8, pady=4)
        sb = tk.Scrollbar(lf)
        sb.pack(side="right", fill="y")
        self.file_list = self._reg(
            tk.Listbox(lf, relief="flat", font=FONT, activestyle="none",
                       yscrollcommand=sb.set),
            {"bg": "INPUT", "fg": "TEXT"})
        self.file_list.pack(fill="both", expand=True)
        sb.config(command=self.file_list.yview)
        self.file_list.bind("<<ListboxSelect>>", self._on_file_select)
        self.file_list.bind("<Double-Button-1>", lambda e: self._summarize_selected())

        self.path_lbl = self._reg(tk.Label(left, text="(파일 선택 시 경로 표시)",
                                           font=FONT_S, wraplength=320, justify="left"),
                                  {"bg": "PANEL", "fg": "DIM"})
        self.path_lbl.pack(anchor="w", padx=10, pady=2)
        brow = self._reg(tk.Frame(left), {"bg": "PANEL"})
        brow.pack(fill="x", padx=8, pady=(0, 8))
        self._btn(brow, "📝 선택 파일 요약", self._summarize_selected).pack(side="left")
        self._btn(brow, "🕘 작업 로그 보기", self._show_log).pack(side="left", padx=4)

        # 우측 채팅 패널
        right = self._reg(tk.Frame(body), {"bg": "PANEL"})
        right.pack(side="left", fill="both", expand=True)

        self._reg(tk.Label(right, text="채팅  (텍스트 요약 · 코드 작성 · 코드 리뷰 · 로그 질문)",
                           font=FONT_B), {"bg": "PANEL", "fg": "ACCENT"}
                  ).pack(anchor="w", padx=10, pady=(8, 2))

        cf = self._reg(tk.Frame(right), {"bg": "PANEL"})
        cf.pack(fill="both", expand=True, padx=8)
        csb = tk.Scrollbar(cf)
        csb.pack(side="right", fill="y")
        self.chat = self._reg(
            tk.Text(cf, relief="flat", wrap="word", font=FONT, state="disabled",
                    yscrollcommand=csb.set, padx=10, pady=8),
            {"bg": "BG", "fg": "TEXT", "insertbackground": "TEXT"})
        self.chat.pack(fill="both", expand=True)
        csb.config(command=self.chat.yview)

        irow = self._reg(tk.Frame(right), {"bg": "PANEL"})
        irow.pack(fill="x", padx=8, pady=8)
        self.entry = self._reg(tk.Text(irow, height=3, relief="flat", font=FONT),
                               {"bg": "INPUT", "fg": "TEXT", "insertbackground": "TEXT"})
        self.entry.pack(side="left", fill="x", expand=True, ipady=2)
        self.entry.bind("<Return>", self._on_enter)
        col = self._reg(tk.Frame(irow), {"bg": "PANEL"})
        col.pack(side="left", padx=4)
        self.send_btn = self._btn(col, "전송", self._send)
        self.send_btn.pack(fill="x")
        self._btn(col, "중지", self._stop_gen).pack(fill="x", pady=2)

        self.status = self._reg(tk.Label(self.root, text="준비", anchor="w", font=FONT),
                                {"bg": "BG", "fg": "DIM"})
        self.status.pack(fill="x", padx=10, pady=(0, 4))

    def _btn(self, parent, text, cmd):
        b = tk.Button(parent, text=text, command=cmd, relief="flat", font=FONT,
                      padx=10, pady=3, cursor="hand2")
        return self._reg(b, {"bg": "INPUT", "fg": "TEXT",
                             "activebackground": "ACCENT", "activeforeground": "BG"})

    # ════════════════ 채팅 출력 ════════════════
    def _append(self, text, tag=None):
        self.chat.config(state="normal")
        self.chat.insert("end", text, tag if tag else ())
        self.chat.see("end")
        self.chat.config(state="disabled")

    def _set_status(self, t):
        self.status.config(text=t)

    # ════════════════ 모델 ════════════════
    def _load_model_async(self):
        def work():
            try:
                self.engine.load(self.cfg["model_path"],
                                 n_ctx=self.cfg["n_ctx"],
                                 n_gpu_layers=self.cfg["n_gpu_layers"])
                self.q.put(("model_ok", os.path.basename(self.cfg["model_path"])))
            except Exception as e:
                self.q.put(("model_fail", str(e)))
        threading.Thread(target=work, daemon=True).start()

    # ════════════════ 파일 기능 (①②③) ════════════════
    def _refresh_files(self):
        self.files = ft.list_files(self.cfg["watch_dir"], self.cfg["recursive"])
        self._fill_list(self.files)
        self.stats_lbl.config(
            text=f"{self.cfg['watch_dir']}\n총 {len(self.files)}개 — {ft.ext_stats(self.files)}")

    def _fill_list(self, files):
        self.file_list.delete(0, "end")
        for fn, fp, size in files[:500]:
            self.file_list.insert("end", f" {fn}")
        if len(files) > 500:
            self.file_list.insert("end", f" ... 외 {len(files)-500}개")
        self._shown = files[:500]

    def _search(self):
        kw = self.search_var.get().strip()
        result = ft.search_files(self.cfg["watch_dir"], kw, self.cfg["recursive"])
        self._fill_list(result)
        self.logger.write("검색", self.cfg["watch_dir"], note=f"키워드={kw}, {len(result)}건")
        if kw and self.engine.ready and not self.busy:
            prompt = ft.build_search_result_prompt(kw, result)
            self._ask_llm_internal(prompt, show_user=f"[검색: {kw}]")

    def _on_file_select(self, _e):
        sel = self.file_list.curselection()
        if not sel or sel[0] >= len(getattr(self, "_shown", [])):
            return
        fn, fp, size = self._shown[sel[0]]
        self.path_lbl.config(text=f"📍 {fp}  ({size:,} bytes)")

    def _summarize_selected(self):
        sel = self.file_list.curselection()
        if not sel or sel[0] >= len(getattr(self, "_shown", [])):
            messagebox.showinfo("안내", "파일을 먼저 선택하세요.")
            return
        fn, fp, _ = self._shown[sel[0]]
        if not ft.is_text_file(fp, self.cfg["extensions"]):
            messagebox.showinfo("안내", f"텍스트로 읽을 수 없는 확장자입니다: {fn}")
            return
        content, truncated = ft.read_text_auto(fp)
        prompt = ft.build_summary_prompt(fn, content, truncated)
        self.logger.write("요약", fp)
        self._ask_llm_internal(prompt, show_user=f"[파일 요약: {fn}]")

    # ════════════════ 로그 (⑦) ════════════════
    def _show_log(self):
        lines = self.logger.read_lines(50)
        if not lines:
            self._append("[작업 로그 없음]\n\n", "sys")
            return
        self._append("=== 최근 작업 로그 ===\n", "sys")
        self._append("\n".join(lines[-30:]) + "\n\n", "sys")

    # ════════════════ 채팅 (④⑤⑥ + 로그질문) ════════════════
    _LOG_KW = ("뭐 했", "뭐했", "뭐 만들", "작업 내역", "작업내역", "로그", "기록 보여", "오늘 한", "어제 한")

    def _on_enter(self, e):
        if e.state & 0x0001:
            return
        self._send()
        return "break"

    def _send(self):
        if self.busy:
            return
        msg = self.entry.get("1.0", "end").strip()
        if not msg:
            return
        self.entry.delete("1.0", "end")

        if any(k in msg for k in self._LOG_KW):
            prompt = ft.build_log_prompt(msg, self.logger.read_lines(120))
            self._ask_llm_internal(prompt, show_user=msg)
            return

        if any(k in msg for k in ("코드 작성", "코드 짜", "만들어줘", "작성해줘")):
            self.logger.write("코드작성", "(채팅)", note=msg[:60])
        self._ask_llm(msg)

    def _ask_llm(self, user_msg):
        self.history.append({"role": "user", "content": user_msg})
        self._append("나  ", "user")
        self._append(user_msg + "\n\n")
        self._run_stream(self.history)

    def _ask_llm_internal(self, built_prompt, show_user=""):
        """파이썬이 만든 결과값(검색결과/파일내용/로그)을 LLM이 받아 처리."""
        if show_user:
            self._append("나  ", "user")
            self._append(show_user + "\n\n")
        self.history.append({"role": "user", "content": show_user or built_prompt})
        msgs = self.history[:-1] + [{"role": "user", "content": built_prompt}]
        self._run_stream(msgs)

    def _run_stream(self, msgs):
        if not self.engine.ready:
            self._append("[모델이 아직 로드되지 않았습니다]\n\n", "err")
            self.history.pop()
            return
        self.busy = True
        self.send_btn.config(state="disabled")
        self._set_status("생성 중...")
        self._append("AI  ", "bot")
        send = msgs[-10:]

        def on_token(t):
            self.q.put(("tok", t))

        def on_done(full):
            self.q.put(("done", full))

        threading.Thread(
            target=self.engine.stream_chat,
            args=(send, on_token, on_done),
            kwargs={"temperature": self.cfg["temperature"],
                    "max_tokens": self.cfg["max_tokens"]},
            daemon=True).start()

    def _stop_gen(self):
        self.engine.stop()

    # ════════════════ 감시 (⑧) ════════════════
    def _start_watch(self):
        ok, msg = self.watcher.start(self.cfg["watch_dir"],
                                     self.cfg["extensions"],
                                     self.cfg["recursive"])
        if ok:
            self.watch_lbl.config(text="감시 ● 작동중", fg=self.C["OK"])
        else:
            self.watch_lbl.config(text=f"감시 ○ {msg}", fg=self.C["WARN"])

    def _toggle_watch(self):
        if self.watcher.running:
            self.watcher.stop()
            self.watch_lbl.config(text="감시 ○ 꺼짐", fg=self.C["DIM"])
        else:
            self._start_watch()

    # ════════════════ 설정창 ════════════════
    def _change_folder(self):
        d = filedialog.askdirectory(title="감시/검색 폴더 선택")
        if d:
            self.cfg["watch_dir"] = d
            save_config(self.cfg)
            self._refresh_files()
            if self.watcher.running:
                self._start_watch()

    def _open_settings(self):
        win = tk.Toplevel(self.root)
        win.title("설정")
        win.configure(bg=self.C["PANEL"])
        win.geometry("580x380")
        win.grab_set()

        rows = [
            ("GGUF 모델 경로", "model_path"),
            ("감시/검색 폴더", "watch_dir"),
            ("로그 파일 경로", "log_path"),
            ("감시 확장자 (쉼표구분)", "extensions"),
        ]
        vars_ = {}
        for i, (label, key) in enumerate(rows):
            tk.Label(win, text=label, bg=self.C["PANEL"], fg=self.C["TEXT"], font=FONT).grid(
                row=i, column=0, sticky="w", padx=12, pady=8)
            val = self.cfg[key]
            if key == "extensions":
                val = ",".join(val)
            v = tk.StringVar(value=val)
            vars_[key] = v
            tk.Entry(win, textvariable=v, width=46, bg=self.C["INPUT"], fg=self.C["TEXT"],
                     insertbackground=self.C["TEXT"], relief="flat", font=FONT).grid(
                row=i, column=1, padx=6, ipady=3)

        rec_v = tk.BooleanVar(value=self.cfg["recursive"])
        tk.Checkbutton(win, text="하위 폴더 포함", variable=rec_v, bg=self.C["PANEL"],
                       fg=self.C["TEXT"], selectcolor=self.C["INPUT"], font=FONT,
                       activebackground=self.C["PANEL"]).grid(row=4, column=1, sticky="w", padx=6)

        tk.Label(win, text="temp", bg=self.C["PANEL"], fg=self.C["TEXT"], font=FONT).grid(
            row=5, column=0, sticky="w", padx=12)
        temp_v = tk.StringVar(value=str(self.cfg["temperature"]))
        tk.Entry(win, textvariable=temp_v, width=8, bg=self.C["INPUT"], fg=self.C["TEXT"],
                 insertbackground=self.C["TEXT"], relief="flat", font=FONT).grid(
            row=5, column=1, sticky="w", padx=6)

        # ── 색상 테마 선택 ──
        tk.Label(win, text="색상 테마", bg=self.C["PANEL"], fg=self.C["TEXT"], font=FONT).grid(
            row=6, column=0, sticky="w", padx=12, pady=8)
        theme_v = tk.StringVar(value=self.cfg.get("theme", "다크 블루"))
        theme_box = ttk.Combobox(win, textvariable=theme_v, state="readonly",
                                 values=list(THEMES.keys()), width=18, font=FONT)
        theme_box.grid(row=6, column=1, sticky="w", padx=6)
        # 고르는 즉시 미리보기 적용
        theme_box.bind("<<ComboboxSelected>>",
                       lambda e: self._set_theme(theme_v.get()) or
                                 win.configure(bg=self.C["PANEL"]))

        def do_save():
            old_model = self.cfg["model_path"]
            self.cfg["model_path"] = vars_["model_path"].get().strip()
            self.cfg["watch_dir"] = vars_["watch_dir"].get().strip()
            self.cfg["log_path"] = vars_["log_path"].get().strip()
            self.cfg["extensions"] = [e.strip() for e in vars_["extensions"].get().split(",") if e.strip()]
            self.cfg["recursive"] = rec_v.get()
            try:
                self.cfg["temperature"] = float(temp_v.get())
            except ValueError:
                pass
            self.cfg["theme"] = theme_v.get()
            save_config(self.cfg)
            self._set_theme(theme_v.get())
            self.logger.log_path = self.cfg["log_path"]
            self._refresh_files()
            if self.watcher.running:
                self._start_watch()
            if self.cfg["model_path"] != old_model:
                self.model_lbl.config(text="모델 로딩중...", fg=self.C["WARN"])
                self.engine.llm = None
                self._load_model_async()
            win.destroy()

        tk.Button(win, text="저장", command=do_save, bg=self.C["ACCENT"], fg=self.C["BG"],
                  relief="flat", font=FONT_B, padx=20, pady=4).grid(
            row=7, column=1, sticky="e", padx=6, pady=14)

    # ════════════════ 큐 폴링 ════════════════
    def _poll(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == "tok":
                    self._append(val)
                elif kind == "done":
                    self._append("\n\n")
                    self.history.append({"role": "assistant", "content": val})
                    self.busy = False
                    self.send_btn.config(state="normal")
                    self._set_status("준비")
                elif kind == "model_ok":
                    self.model_lbl.config(text=f"모델: {val} ✓", fg=self.C["OK"])
                    self._append(f"[모델 로드 완료: {val} — 콘솔에서 Vulkan 확인]\n\n", "sys")
                elif kind == "model_fail":
                    self.model_lbl.config(text="모델 로드 실패", fg=self.C["ERR"])
                    self._append(f"[모델 로드 실패] {val}\n설정에서 경로를 확인하세요.\n\n", "err")
        except queue.Empty:
            pass
        self.root.after(40, self._poll)

    def _on_close(self):
        self.watcher.stop()
        self.engine.stop()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
