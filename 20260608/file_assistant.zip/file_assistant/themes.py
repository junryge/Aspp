# -*- coding: utf-8 -*-
"""themes.py - 색상 테마 프리셋. 설정창에서 선택 → 즉시 적용."""

THEMES = {
    "다크 블루": {          # 기본 (Catppuccin 계열)
        "BG": "#1e1e2e", "PANEL": "#27273a", "INPUT": "#313244",
        "TEXT": "#cdd6f4", "DIM": "#7f849c", "ACCENT": "#89b4fa",
        "OK": "#a6e3a1", "WARN": "#f9e2af", "ERR": "#f38ba8",
    },
    "다크 그린": {
        "BG": "#101814", "PANEL": "#18241d", "INPUT": "#223328",
        "TEXT": "#d7e4da", "DIM": "#73907d", "ACCENT": "#5fd68b",
        "OK": "#8ee6a8", "WARN": "#e6d98e", "ERR": "#e68e8e",
    },
    "다크 퍼플": {
        "BG": "#191423", "PANEL": "#231c31", "INPUT": "#2f2542",
        "TEXT": "#dcd3ee", "DIM": "#8b7fa8", "ACCENT": "#b08aff",
        "OK": "#9be8b9", "WARN": "#f0d98c", "ERR": "#f08caa",
    },
    "블랙": {
        "BG": "#0d0d0d", "PANEL": "#171717", "INPUT": "#242424",
        "TEXT": "#e6e6e6", "DIM": "#7a7a7a", "ACCENT": "#4ea1ff",
        "OK": "#6fd66f", "WARN": "#e0c460", "ERR": "#e06060",
    },
    "라이트": {
        "BG": "#f4f4f7", "PANEL": "#ffffff", "INPUT": "#ebebf0",
        "TEXT": "#2b2b35", "DIM": "#8a8a99", "ACCENT": "#3b6fd4",
        "OK": "#2f9e57", "WARN": "#b8860b", "ERR": "#cc3b5d",
    },
}

DEFAULT_THEME = "다크 블루"


def get_theme(name):
    return THEMES.get(name, THEMES[DEFAULT_THEME])
