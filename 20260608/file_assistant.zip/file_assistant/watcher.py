# -*- coding: utf-8 -*-
"""watcher.py - 폴더 실시간 감시(watchdog) + JSONL 작업 로그"""
import os
import json
import datetime

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    WATCHDOG_OK = True
except ImportError:
    WATCHDOG_OK = False
    FileSystemEventHandler = object   # 더미


class WorkLogger:
    """JSONL 한 줄씩 append. {time, action, path}"""

    def __init__(self, log_path):
        self.log_path = log_path

    def write(self, action, path, note=""):
        rec = {
            "time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "action": action,          # 생성/수정/삭제/이동/요약/검색/코드작성
            "path": path,
            "note": note,
        }
        try:
            with open(self.log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def read_lines(self, max_lines=300):
        """최근 로그를 사람이 읽을 문자열 리스트로."""
        if not os.path.isfile(self.log_path):
            return []
        out = []
        try:
            with open(self.log_path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        r = json.loads(line)
                        s = f"[{r.get('time','')}] {r.get('action','')} {r.get('path','')}"
                        if r.get("note"):
                            s += f" — {r['note']}"
                        out.append(s)
                    except json.JSONDecodeError:
                        continue
        except Exception:
            return out
        return out[-max_lines:]


class _Handler(FileSystemEventHandler):
    """파일 이벤트 → 로그. 확장자 필터 적용."""

    def __init__(self, logger, extensions):
        self.logger = logger
        self.exts = [e.lower() for e in extensions]

    def _ok(self, path):
        return os.path.splitext(path)[1].lower() in self.exts

    def on_created(self, event):
        if not event.is_directory and self._ok(event.src_path):
            self.logger.write("생성", event.src_path)

    def on_modified(self, event):
        if not event.is_directory and self._ok(event.src_path):
            self.logger.write("수정", event.src_path)

    def on_deleted(self, event):
        if not event.is_directory and self._ok(event.src_path):
            self.logger.write("삭제", event.src_path)

    def on_moved(self, event):
        if not event.is_directory and self._ok(event.dest_path):
            self.logger.write("이동", f"{event.src_path} → {event.dest_path}")


class FolderWatcher:
    """감시 시작/중지. GUI에서 토글."""

    def __init__(self, logger):
        self.logger = logger
        self.observer = None

    @property
    def available(self):
        return WATCHDOG_OK

    @property
    def running(self):
        return self.observer is not None

    def start(self, watch_dir, extensions, recursive=True):
        if not WATCHDOG_OK:
            return False, "watchdog 미설치 (pip install watchdog)"
        if not os.path.isdir(watch_dir):
            return False, f"폴더 없음: {watch_dir}"
        self.stop()
        self.observer = Observer()
        self.observer.schedule(_Handler(self.logger, extensions),
                               watch_dir, recursive=recursive)
        self.observer.daemon = True
        self.observer.start()
        return True, "감시 시작"

    def stop(self):
        if self.observer:
            try:
                self.observer.stop()
                self.observer.join(timeout=2)
            except Exception:
                pass
            self.observer = None
