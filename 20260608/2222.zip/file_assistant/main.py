# -*- coding: utf-8 -*-
"""main.py - 파일 비서 (Gemma 4B / Vulkan) — Graphite 디자인
실행: python main.py
필요: pip install llama-cpp-python(Vulkan wheel), watchdog
디자인 원칙: 면 3단계로 깊이(BG<PANEL<SURF), 이모지 제거, 포인트색은 전송/선택 2곳,
            버튼 호버, 상태는 점(●)+텍스트, 채팅 영역은 BG로 분리.
"""
import os
import threading
import queue
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from config import load_config, save_config
from llm_engine import LLMEngine
from watcher import WorkLogger, FolderWatcher
from themes import THEMES, get_theme
import file_tools as ft

FONT    = ("Malgun Gothic", 10)
FONT_SM = ("Malgun Gothic", 9)
FONT_LBL= ("Malgun Gothic", 9, "bold")
FONT_MONO = ("Consolas", 10)
SEARCH_PLACEHOLDER = "파일명 검색..."
EXT_MARK = {".py": "  \u25b8 ", ".csv": "  \u25aa ", ".md": "  \u2500 "}


class App:
    def __init__(self, root):
        self.root = root
        root.title("파일 비서 — Gemma 4B (Vulkan)")
        root.geometry("1040x680")

        self.cfg = load_config()
        self.C = get_theme(self.cfg.get("theme"))
        self.engine = LLMEngine()
        self.logger = WorkLogger(self.cfg["log_path"])
        self.watcher = FolderWatcher(self.logger)

        self.history = []
        self.files = []
        self.q = queue.Queue()
        self.busy = False
        self._themed = []     # (widget, {opt: theme_key})
        self._hover = []      # (widget, normal_key, hover_key)
        self._search_active = False

        self._build_ui()
        self._apply_theme()
        self._poll()
        self._refresh_files()
        self._load_model_async()
        self._start_watch()
        root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ════════════════ 테마 ════════════════
    def _reg(self, widget, mapping):
        self._themed.append((widget, mapping))
        return widget

    def _hover_bind(self, widget, normal="SURF", hover="HOVER"):
        self._hover.append((widget, normal, hover))
        widget.bind("<Enter>", lambda e, w=widget, h=hover: w.config(bg=self.C[h]))
        widget.bind("<Leave>", lambda e, w=widget, n=normal: w.config(bg=self.C[n]))
        return widget

    def _apply_theme(self):
        for w, mp in self._themed:
            try:
                w.configure(**{opt: self.C[key] for opt, key in mp.items()})
            except tk.TclError:
                pass
        self.chat.tag_config("user", foreground=self.C["TEXT"], font=FONT_LBL)
        self.chat.tag_config("bot",  foreground=self.C["OK"], font=FONT_LBL)
        self.chat.tag_config("sys",  foreground=self.C["FAINT"])
        self.chat.tag_config("err",  foreground=self.C["ERR"])
        self.chat.tag_config("code", background=self.C["SURF"], font=FONT_MONO,
                             foreground=self.C["TEXT"])
        self.file_list.configure(selectbackground=self.C["ACCENT"],
                                 selectforeground=self.C["BG"])
        # placeholder 색 갱신
        if not self._search_active:
            self.search_entry.config(fg=self.C["DIM"])

    def _set_theme(self, name):
        self.cfg["theme"] = name
        self.C = get_theme(name)
        save_config(self.cfg)
        self._apply_theme()

    # ════════════════ UI ════════════════
    def _build_ui(self):
        self._reg(self.root, {"bg": "BG"})

        # ── 상단바 (h≈44) ──
        top = self._reg(tk.Frame(self.root, height=44), {"bg": "PANEL"})
        top.pack(fill="x")
        top.pack_propagate(False)
        # 좌측 포인트 도트 + 타이틀
        dot = self._reg(tk.Frame(top, width=10, height=10), {"bg": "ACCENT"})
        dot.place(x=16, y=17)
        self._reg(tk.Label(top, text="파일 비서", font=FONT_LBL),
                  {"bg": "PANEL", "fg": "TEXT"}).place(x=34, y=13)
        # 좌측 버튼들
        bx = self._reg(tk.Frame(top), {"bg": "PANEL"})
        bx.place(x=120, y=8)
        self._flat_btn(bx, "설정", self._open_settings).pack(side="left", padx=3)
        self._flat_btn(bx, "모델", self._change_model).pack(side="left", padx=3)
        self._flat_btn(bx, "폴더", self._change_folder).pack(side="left", padx=3)
        self._flat_btn(bx, "새로고침", self._refresh_files).pack(side="left", padx=3)
        # 우측 상태
        self.watch_lbl = self._reg(tk.Label(top, text="\u25cb 감시", font=FONT_SM),
                                   {"bg": "PANEL", "fg": "FAINT"})
        self.watch_lbl.place(relx=1.0, x=-260, y=14)
        self._flat_btn(top, "감시 전환", self._toggle_watch).place(relx=1.0, x=-200, y=8)
        self.model_lbl = self._reg(tk.Label(top, text="\u25cf 로딩중", font=FONT_SM),
                                   {"bg": "PANEL", "fg": "WARN"})
        self.model_lbl.place(relx=1.0, x=-110, y=14)

        # ── 본문 ──
        body = self._reg(tk.Frame(self.root), {"bg": "BG"})
        body.pack(fill="both", expand=True)

        # 좌측 패널 (고정 300)
        left = self._reg(tk.Frame(body, width=300), {"bg": "PANEL"})
        left.pack(side="left", fill="y")
        left.pack_propagate(False)

        self._reg(tk.Label(left, text="  파일", font=FONT_LBL, anchor="w"),
                  {"bg": "PANEL", "fg": "DIM"}).pack(fill="x", padx=12, pady=(12, 6))

        srow = self._reg(tk.Frame(left), {"bg": "PANEL"})
        srow.pack(fill="x", padx=12)
        self.search_entry = self._reg(
            tk.Entry(srow, relief="flat", font=FONT, bd=0,
                     highlightthickness=0),
            {"bg": "SURF", "fg": "DIM", "insertbackground": "TEXT"})
        self.search_entry.insert(0, SEARCH_PLACEHOLDER)
        self.search_entry.pack(side="left", fill="x", expand=True, ipady=6)
        self.search_entry.bind("<FocusIn>", self._search_focus_in)
        self.search_entry.bind("<FocusOut>", self._search_focus_out)
        self.search_entry.bind("<Return>", lambda e: self._search())
        self._flat_btn(srow, "검색", self._search).pack(side="left", padx=(6, 0))

        self.stats_lbl = self._reg(
            tk.Label(left, text="", font=FONT_SM, anchor="w", justify="left",
                     wraplength=276),
            {"bg": "PANEL", "fg": "DIM"})
        self.stats_lbl.pack(fill="x", padx=12, pady=(8, 6))

        lf = self._reg(tk.Frame(left), {"bg": "PANEL"})
        lf.pack(fill="both", expand=True, padx=12)
        self.file_list = self._reg(
            tk.Listbox(lf, relief="flat", font=FONT, activestyle="none",
                       bd=0, highlightthickness=0),
            {"bg": "SURF", "fg": "TEXT"})
        self.file_list.pack(fill="both", expand=True)
        self.file_list.bind("<<ListboxSelect>>", self._on_file_select)
        self.file_list.bind("<Double-Button-1>", lambda e: self._summarize_selected())

        self.path_lbl = self._reg(
            tk.Label(left, text="(파일 선택 시 경로 표시)", font=FONT_SM,
                     anchor="w", justify="left", wraplength=276),
            {"bg": "PANEL", "fg": "FAINT"})
        self.path_lbl.pack(fill="x", padx=12, pady=(8, 6))

        brow = self._reg(tk.Frame(left), {"bg": "PANEL"})
        brow.pack(fill="x", padx=12, pady=(0, 12))
        self._flat_btn(brow, "선택 파일 요약", self._summarize_selected).pack(side="left")
        self._flat_btn(brow, "로그", self._show_log).pack(side="left", padx=6)

        # 우측 채팅 (BG로 분리)
        right = self._reg(tk.Frame(body), {"bg": "BG"})
        right.pack(side="left", fill="both", expand=True)

        self._reg(tk.Label(right,
                  text="  채팅   ·  텍스트 요약  ·  코드 작성  ·  코드 리뷰  ·  로그 질문",
                  font=FONT_LBL, anchor="w"),
                  {"bg": "BG", "fg": "DIM"}).pack(fill="x", padx=16, pady=(12, 6))

        cf = self._reg(tk.Frame(right), {"bg": "BG"})
        cf.pack(fill="both", expand=True, padx=16)
        csb = tk.Scrollbar(cf, width=8)
        csb.pack(side="right", fill="y")
        self.chat = self._reg(
            tk.Text(cf, relief="flat", wrap="word", font=FONT, state="disabled",
                    bd=0, highlightthickness=0, padx=12, pady=10,
                    yscrollcommand=csb.set),
            {"bg": "BG", "fg": "TEXT", "insertbackground": "TEXT"})
        self.chat.pack(fill="both", expand=True)
        csb.config(command=self.chat.yview)

        # 입력바 (SURF로 묶기)
        ibar = self._reg(tk.Frame(right), {"bg": "SURF"})
        ibar.pack(fill="x", padx=16, pady=12)
        self.entry = self._reg(
            tk.Text(ibar, height=3, relief="flat", font=FONT, bd=0,
                    highlightthickness=0, padx=8, pady=6),
            {"bg": "SURF", "fg": "TEXT", "insertbackground": "TEXT"})
        self.entry.pack(side="left", fill="both", expand=True)
        self.entry.bind("<Return>", self._on_enter)
        col = self._reg(tk.Frame(ibar), {"bg": "SURF"})
        col.pack(side="left", padx=6, pady=6)
        self.send_btn = tk.Button(col, text="전송", command=self._send, relief="flat",
                                  font=FONT_LBL, bd=0, padx=16, pady=4, cursor="hand2")
        self._reg(self.send_btn, {"bg": "ACCENT", "fg": "BG",
                                  "activebackground": "ACCENT", "activeforeground": "BG"})
        self.send_btn.pack(fill="x")
        stop_btn = self._flat_btn(col, "중지", self._stop_gen)
        stop_btn.pack(fill="x", pady=(6, 0))

        # 하단 상태줄
        self.status = self._reg(
            tk.Label(self.root, text="준비", anchor="w", font=FONT_SM, height=1),
            {"bg": "BG", "fg": "FAINT"})
        self.status.pack(fill="x", padx=16, pady=(0, 4))

    def _flat_btn(self, parent, text, cmd):
        b = tk.Button(parent, text=text, command=cmd, relief="flat", font=FONT,
                      bd=0, padx=12, pady=4, cursor="hand2")
        self._reg(b, {"bg": "SURF", "fg": "TEXT",
                      "activebackground": "HOVER", "activeforeground": "TEXT"})
        self._hover_bind(b, "SURF", "HOVER")
        return b

    # ── 검색 placeholder ──
    def _search_focus_in(self, _e):
        if not self._search_active:
            self._search_active = True
            self.search_entry.delete(0, "end")
            self.search_entry.config(fg=self.C["TEXT"])

    def _search_focus_out(self, _e):
        if not self.search_entry.get().strip():
            self._search_active = False
            self.search_entry.delete(0, "end")
            self.search_entry.insert(0, SEARCH_PLACEHOLDER)
            self.search_entry.config(fg=self.C["DIM"])

    def _search_text(self):
        return "" if not self._search_active else self.search_entry.get().strip()

    # ════════════════ 채팅 출력 ════════════════
    def _append(self, text, tag=None):
        self.chat.config(state="normal")
        self.chat.insert("end", text, tag if tag else ())
        self.chat.see("end")
        self.chat.config(state="disabled")

    def _set_status(self, t):
        self.status.config(text=t)

    # ════════════════ 모델 ════════════════
    def _load_model_async(self):
        def work():
            try:
                self.engine.load(self.cfg["model_path"],
                                 n_ctx=self.cfg["n_ctx"],
                                 n_gpu_layers=self.cfg["n_gpu_layers"])
                self.q.put(("model_ok", os.path.basename(self.cfg["model_path"])))
            except Exception as e:
                self.q.put(("model_fail", str(e)))
        threading.Thread(target=work, daemon=True).start()

    # ════════════════ 파일 ════════════════
    def _refresh_files(self):
        self.files = ft.list_files(self.cfg["watch_dir"], self.cfg["recursive"])
        self._fill_list(self.files)
        self.stats_lbl.config(
            text=f"{self.cfg['watch_dir']}\n총 {len(self.files)}개  ·  {ft.ext_stats(self.files)}")

    def _fill_list(self, files):
        self.file_list.delete(0, "end")
        for fn, fp, size in files[:500]:
            ext = os.path.splitext(fn)[1].lower()
            self.file_list.insert("end", EXT_MARK.get(ext, "    ") + fn)
        if len(files) > 500:
            self.file_list.insert("end", f"    ... 외 {len(files)-500}개")
        self._shown = files[:500]

    def _search(self):
        kw = self._search_text()
        result = ft.search_files(self.cfg["watch_dir"], kw, self.cfg["recursive"])
        self._fill_list(result)
        self.logger.write("검색", self.cfg["watch_dir"], note=f"키워드={kw}, {len(result)}건")
        if kw and self.engine.ready and not self.busy:
            prompt = ft.build_search_result_prompt(kw, result)
            self._ask_llm_internal(prompt, show_user=f"[검색: {kw}]")

    def _on_file_select(self, _e):
        sel = self.file_list.curselection()
        if not sel or sel[0] >= len(getattr(self, "_shown", [])):
            return
        fn, fp, size = self._shown[sel[0]]
        self.path_lbl.config(text=f"{fp}\n{size:,} bytes")

    def _summarize_selected(self):
        sel = self.file_list.curselection()
        if not sel or sel[0] >= len(getattr(self, "_shown", [])):
            messagebox.showinfo("안내", "파일을 먼저 선택하세요.")
            return
        fn, fp, _ = self._shown[sel[0]]
        if not ft.is_text_file(fp, self.cfg["extensions"]):
            messagebox.showinfo("안내", f"텍스트로 읽을 수 없는 확장자입니다: {fn}")
            return
        content, truncated = ft.read_text_auto(fp)
        prompt = ft.build_summary_prompt(fn, content, truncated)
        self.logger.write("요약", fp)
        self._ask_llm_internal(prompt, show_user=f"[파일 요약: {fn}]")

    # ════════════════ 로그 ════════════════
    def _show_log(self):
        lines = self.logger.read_lines(50)
        if not lines:
            self._append("[작업 로그 없음]\n\n", "sys")
            return
        self._append("최근 작업 로그\n", "sys")
        self._append("\n".join(lines[-30:]) + "\n\n", "sys")

    # ════════════════ 채팅 ════════════════
    _LOG_KW = ("뭐 했", "뭐했", "뭐 만들", "작업 내역", "작업내역", "로그", "기록 보여", "오늘 한", "어제 한")

    def _on_enter(self, e):
        if e.state & 0x0001:
            return
        self._send()
        return "break"

    def _send(self):
        if self.busy:
            return
        msg = self.entry.get("1.0", "end").strip()
        if not msg:
            return
        self.entry.delete("1.0", "end")
        if any(k in msg for k in self._LOG_KW):
            prompt = ft.build_log_prompt(msg, self.logger.read_lines(120))
            self._ask_llm_internal(prompt, show_user=msg)
            return
        if any(k in msg for k in ("코드 작성", "코드 짜", "만들어줘", "작성해줘")):
            self.logger.write("코드작성", "(채팅)", note=msg[:60])
        self._ask_llm(msg)

    def _ask_llm(self, user_msg):
        self.history.append({"role": "user", "content": user_msg})
        self._append("나  ", "user")
        self._append(user_msg + "\n\n")
        self._run_stream(self.history)

    def _ask_llm_internal(self, built_prompt, show_user=""):
        if show_user:
            self._append("나  ", "user")
            self._append(show_user + "\n\n")
        self.history.append({"role": "user", "content": show_user or built_prompt})
        msgs = self.history[:-1] + [{"role": "user", "content": built_prompt}]
        self._run_stream(msgs)

    def _run_stream(self, msgs):
        if not self.engine.ready:
            self._append("[모델이 아직 로드되지 않았습니다]\n\n", "err")
            self.history.pop()
            return
        self.busy = True
        self.send_btn.config(state="disabled")
        self._set_status("생성 중...")
        self._append("AI  ", "bot")
        send = msgs[-10:]
        self.q  # noop
        threading.Thread(
            target=self.engine.stream_chat,
            args=(send, lambda t: self.q.put(("tok", t)),
                  lambda full: self.q.put(("done", full))),
            kwargs={"temperature": self.cfg["temperature"],
                    "max_tokens": self.cfg["max_tokens"]},
            daemon=True).start()

    def _stop_gen(self):
        self.engine.stop()

    # ════════════════ 감시 ════════════════
    def _start_watch(self):
        ok, msg = self.watcher.start(self.cfg["watch_dir"],
                                     self.cfg["extensions"],
                                     self.cfg["recursive"])
        if ok:
            self.watch_lbl.config(text="\u25cf 감시", fg=self.C["OK"])
        else:
            self.watch_lbl.config(text=f"\u25cb {msg}", fg=self.C["WARN"])

    def _toggle_watch(self):
        if self.watcher.running:
            self.watcher.stop()
            self.watch_lbl.config(text="\u25cb 감시", fg=self.C["FAINT"])
        else:
            self._start_watch()

    # ════════════════ 폴더 ════════════════
    def _change_folder(self):
        d = filedialog.askdirectory(title="감시/검색 폴더 선택")
        if d:
            self.cfg["watch_dir"] = d
            save_config(self.cfg)
            self._refresh_files()
            if self.watcher.running:
                self._start_watch()

    # ════════════════ 모델 변경 ════════════════
    def _change_model(self):
        if self.busy:
            messagebox.showinfo("안내", "생성 중에는 모델을 바꿀 수 없습니다.")
            return
        p = filedialog.askopenfilename(
            title="GGUF 모델 선택",
            filetypes=[("GGUF 모델", "*.gguf"), ("모든 파일", "*.*")])
        if not p:
            return
        self.cfg["model_path"] = p
        save_config(self.cfg)
        self.model_lbl.config(text="\u25cf 로딩중", fg=self.C["WARN"])
        self._append(f"[모델 교체: {os.path.basename(p)} 로딩 시작]\n\n", "sys")
        self.engine.llm = None
        self._load_model_async()

    # ════════════════ 설정창 ════════════════
    def _open_settings(self):
        C = self.C
        win = tk.Toplevel(self.root)
        win.title("설정")
        win.configure(bg=C["PANEL"])
        win.geometry("640x400")
        win.grab_set()

        rows = [("GGUF 모델 경로", "model_path"),
                ("감시/검색 폴더", "watch_dir"),
                ("로그 파일 경로", "log_path"),
                ("감시 확장자 (쉼표구분)", "extensions")]
        vars_ = {}
        for i, (label, key) in enumerate(rows):
            tk.Label(win, text=label, bg=C["PANEL"], fg=C["DIM"], font=FONT).grid(
                row=i, column=0, sticky="w", padx=14, pady=8)
            val = self.cfg[key]
            if key == "extensions":
                val = ",".join(val)
            v = tk.StringVar(value=val)
            vars_[key] = v
            tk.Entry(win, textvariable=v, width=42, bg=C["SURF"], fg=C["TEXT"],
                     insertbackground=C["TEXT"], relief="flat", bd=0,
                     highlightthickness=0, font=FONT).grid(
                row=i, column=1, padx=6, ipady=4, sticky="w")

        def picker(key, kind):
            def f():
                if kind == "open":
                    p = filedialog.askopenfilename(
                        parent=win, title="GGUF 모델 선택",
                        filetypes=[("GGUF 모델", "*.gguf"), ("모든 파일", "*.*")])
                elif kind == "dir":
                    p = filedialog.askdirectory(parent=win, title="폴더 선택")
                else:
                    p = filedialog.asksaveasfilename(
                        parent=win, title="로그 파일 위치",
                        defaultextension=".jsonl",
                        filetypes=[("JSONL", "*.jsonl"), ("모든 파일", "*.*")])
                if p:
                    vars_[key].set(p)
            return f

        for r, (key, kind) in enumerate([("model_path", "open"),
                                         ("watch_dir", "dir"),
                                         ("log_path", "save")]):
            tk.Button(win, text="찾기", command=picker(key, kind),
                      bg=C["SURF"], fg=C["TEXT"], relief="flat", bd=0,
                      activebackground=C["HOVER"], activeforeground=C["TEXT"],
                      font=FONT, padx=10, cursor="hand2").grid(
                row=r, column=2, padx=(0, 14))

        rec_v = tk.BooleanVar(value=self.cfg["recursive"])
        tk.Checkbutton(win, text="하위 폴더 포함", variable=rec_v, bg=C["PANEL"],
                       fg=C["TEXT"], selectcolor=C["SURF"], font=FONT,
                       activebackground=C["PANEL"], activeforeground=C["TEXT"]).grid(
            row=4, column=1, sticky="w", padx=6, pady=4)

        tk.Label(win, text="temp", bg=C["PANEL"], fg=C["DIM"], font=FONT).grid(
            row=5, column=0, sticky="w", padx=14)
        temp_v = tk.StringVar(value=str(self.cfg["temperature"]))
        tk.Entry(win, textvariable=temp_v, width=8, bg=C["SURF"], fg=C["TEXT"],
                 insertbackground=C["TEXT"], relief="flat", bd=0,
                 highlightthickness=0, font=FONT).grid(
            row=5, column=1, sticky="w", padx=6, ipady=3)

        tk.Label(win, text="색상 테마", bg=C["PANEL"], fg=C["DIM"], font=FONT).grid(
            row=6, column=0, sticky="w", padx=14, pady=8)
        theme_v = tk.StringVar(value=self.cfg.get("theme", "Graphite"))
        box = ttk.Combobox(win, textvariable=theme_v, state="readonly",
                           values=list(THEMES.keys()), width=18, font=FONT)
        box.grid(row=6, column=1, sticky="w", padx=6)
        box.bind("<<ComboboxSelected>>",
                 lambda e: (self._set_theme(theme_v.get()),
                            win.configure(bg=self.C["PANEL"])))

        def do_save():
            old_model = self.cfg["model_path"]
            self.cfg["model_path"] = vars_["model_path"].get().strip()
            self.cfg["watch_dir"] = vars_["watch_dir"].get().strip()
            self.cfg["log_path"] = vars_["log_path"].get().strip()
            self.cfg["extensions"] = [e.strip() for e in vars_["extensions"].get().split(",") if e.strip()]
            self.cfg["recursive"] = rec_v.get()
            try:
                self.cfg["temperature"] = float(temp_v.get())
            except ValueError:
                pass
            self.cfg["theme"] = theme_v.get()
            save_config(self.cfg)
            self._set_theme(theme_v.get())
            self.logger.log_path = self.cfg["log_path"]
            self._refresh_files()
            if self.watcher.running:
                self._start_watch()
            if self.cfg["model_path"] != old_model:
                self.model_lbl.config(text="\u25cf 로딩중", fg=self.C["WARN"])
                self.engine.llm = None
                self._load_model_async()
            win.destroy()

        tk.Button(win, text="저장", command=do_save, bg=C["ACCENT"], fg=C["BG"],
                  relief="flat", bd=0, font=FONT_LBL, padx=22, pady=5,
                  cursor="hand2").grid(row=7, column=1, sticky="e", padx=6, pady=16)

    # ════════════════ 큐 폴링 ════════════════
    def _poll(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == "tok":
                    self._append(val)
                elif kind == "done":
                    self._append("\n\n")
                    self.history.append({"role": "assistant", "content": val})
                    self.busy = False
                    self.send_btn.config(state="normal")
                    self._set_status("준비")
                elif kind == "model_ok":
                    self.model_lbl.config(text=f"\u25cf {val}", fg=self.C["OK"])
                    self._append(f"[모델 로드 완료: {val} — 콘솔에서 Vulkan 확인]\n\n", "sys")
                elif kind == "model_fail":
                    self.model_lbl.config(text="\u25cf 로드 실패", fg=self.C["ERR"])
                    self._append(f"[모델 로드 실패] {val}\n설정에서 경로를 확인하세요.\n\n", "err")
        except queue.Empty:
            pass
        self.root.after(40, self._poll)

    def _on_close(self):
        self.watcher.stop()
        self.engine.stop()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
