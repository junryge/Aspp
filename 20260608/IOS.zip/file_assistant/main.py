# -*- coding: utf-8 -*-
"""main.py - 파일 비서 (Gemma 4B / Vulkan) — Graphite 디자인
실행: python main.py
필요: pip install llama-cpp-python(Vulkan wheel), watchdog
디자인 원칙: 면 3단계로 깊이(BG<PANEL<SURF), 이모지 제거, 포인트색은 전송/선택 2곳,
            버튼 호버, 상태는 점(●)+텍스트, 채팅 영역은 BG로 분리.
"""
import os
import threading
import queue
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from config import load_config, save_config
from llm_engine import LLMEngine
from watcher import WorkLogger, FolderWatcher
from sessions import SessionStore
from themes import THEMES, get_theme
import file_tools as ft

FONT    = ("Malgun Gothic", 10)
FONT_SM = ("Malgun Gothic", 9)
FONT_LBL= ("Malgun Gothic", 9, "bold")
FONT_MONO = ("Consolas", 10)
SEARCH_PLACEHOLDER = "파일명 검색..."
EXT_MARK = {".py": "  \u25b8 ", ".csv": "  \u25aa ", ".md": "  \u2500 "}


class App:
    def __init__(self, root):
        self.root = root
        root.title("파일 비서 — Gemma 4B (Vulkan)")
        root.geometry("1040x680")

        self.cfg = load_config()
        self.C = get_theme(self.cfg.get("theme"))
        self.q = queue.Queue()
        self.engine = LLMEngine()
        # 구버전 config(log_path) 호환 → log_dir 보정
        if "log_dir" not in self.cfg:
            old = self.cfg.get("log_path", "")
            self.cfg["log_dir"] = os.path.join(os.path.dirname(old) or os.getcwd(), "worklogs")
        self.logger = WorkLogger(self.cfg["log_dir"],
                                 on_event=lambda t, a, p, n: self.q.put(("fsevent", (t, a, p, n))))
        self.watcher = FolderWatcher(self.logger)
        # 세션 저장소
        self.session_dir = self.cfg.get("session_dir") or os.path.join(os.getcwd(), "sessions")
        self.cfg["session_dir"] = self.session_dir
        self.sessions = SessionStore(self.session_dir)
        self.sid = SessionStore.new_id()

        self.history = []
        self.files = []
        self.busy = False
        self._themed = []     # (widget, {opt: theme_key})
        self._hover = []      # (widget, normal_key, hover_key)
        self._search_active = False

        self._build_ui()
        self._apply_theme()
        self._poll()
        self._refresh_files()
        self._load_model_async()
        self._start_watch()
        root.protocol("WM_DELETE_WINDOW", self._on_close)

    # ════════════════ 테마 ════════════════
    def _reg(self, widget, mapping):
        self._themed.append((widget, mapping))
        return widget

    def _hover_bind(self, widget, normal="SURF", hover="HOVER"):
        self._hover.append((widget, normal, hover))
        widget.bind("<Enter>", lambda e, w=widget, h=hover: w.config(bg=self.C[h]))
        widget.bind("<Leave>", lambda e, w=widget, n=normal: w.config(bg=self.C[n]))
        return widget

    def _apply_theme(self):
        for w, mp in self._themed:
            try:
                w.configure(**{opt: self.C[key] for opt, key in mp.items()})
            except tk.TclError:
                pass
        # ── 채팅 블록 스타일 (나 / AI 확실히 구분) ──
        self.chat.tag_config("user_name", foreground=self.C["ACCENT"], font=FONT_LBL,
                             justify="right", spacing1=10,
                             lmargin1=120, lmargin2=120, rmargin=8)
        self.chat.tag_config("user", foreground=self.C["TEXT"], font=FONT,
                             background=self.C["SURF"], justify="right",
                             lmargin1=120, lmargin2=120, rmargin=8,
                             spacing1=2, spacing3=10, wrap="word")
        self.chat.tag_config("bot_name", foreground=self.C["OK"], font=FONT_LBL,
                             justify="left", spacing1=10,
                             lmargin1=8, lmargin2=8, rmargin=120)
        self.chat.tag_config("bot", foreground=self.C["TEXT"], font=FONT,
                             background=self.C["PANEL"], justify="left",
                             lmargin1=8, lmargin2=8, rmargin=120,
                             spacing1=2, spacing3=10, wrap="word")
        self.chat.tag_config("sys",  foreground=self.C["FAINT"], justify="center",
                             spacing1=6, spacing3=6)
        self.chat.tag_config("err",  foreground=self.C["ERR"])
        # 코드 블록: 어두운 배경 + 고정폭 + 들여쓰기 (글과 확실히 구분)
        self.chat.tag_config("code", background=self.C["BG"], font=FONT_MONO,
                             foreground="#a6e3a1", lmargin1=20, lmargin2=20,
                             rmargin=20, spacing1=1, spacing3=1, wrap="none")
        self.chat.tag_config("code_head", background=self.C["BG"],
                             foreground=self.C["DIM"], font=FONT_SM,
                             lmargin1=20, lmargin2=20, spacing1=8)
        self.chat.tag_config("code_foot", background=self.C["BG"],
                             foreground=self.C["BG"], font=("Consolas", 3),
                             lmargin1=20, lmargin2=20, spacing3=8)
        # 인라인 코드 `이런거`
        self.chat.tag_config("icode", background=self.C["SURF"], font=FONT_MONO,
                             foreground=self.C["WARN"])
        self.file_list.configure(selectbackground=self.C["ACCENT"],
                                 selectforeground=self.C["BG"])
        # 이벤트 로그 색상: 생성=OK 수정=WARN 삭제=ERR 이동=ACCENT 기타=DIM
        if hasattr(self, "event_log"):
            self.event_log.tag_config("ts", foreground=self.C["FAINT"])
            self.event_log.tag_config("생성", foreground=self.C["OK"])
            self.event_log.tag_config("수정", foreground=self.C["WARN"])
            self.event_log.tag_config("삭제", foreground=self.C["ERR"])
            self.event_log.tag_config("이동", foreground=self.C["ACCENT"])
            self.event_log.tag_config("path", foreground=self.C["DIM"])
        # 이벤트 로그 색상: 생성=OK 수정=WARN 삭제=ERR 이동=ACCENT
        if hasattr(self, "event_log"):
            self.event_log.tag_config("ts", foreground=self.C["FAINT"])
            self.event_log.tag_config("생성", foreground=self.C["OK"])
            self.event_log.tag_config("수정", foreground=self.C["WARN"])
            self.event_log.tag_config("삭제", foreground=self.C["ERR"])
            self.event_log.tag_config("이동", foreground=self.C["ACCENT"])
            self.event_log.tag_config("path", foreground=self.C["DIM"])
        # placeholder 색 갱신
        if not self._search_active:
            self.search_entry.config(fg=self.C["DIM"])

    def _set_theme(self, name):
        self.cfg["theme"] = name
        self.C = get_theme(name)
        save_config(self.cfg)
        self._apply_theme()

    # ════════════════ UI ════════════════
    def _build_ui(self):
        self._reg(self.root, {"bg": "BG"})

        # ── 상단바 (h≈44) ──
        top = self._reg(tk.Frame(self.root, height=44), {"bg": "PANEL"})
        top.pack(fill="x")
        top.pack_propagate(False)
        # 좌측 포인트 도트 + 타이틀
        dot = self._reg(tk.Frame(top, width=10, height=10), {"bg": "ACCENT"})
        dot.place(x=16, y=17)
        self._reg(tk.Label(top, text="파일 비서", font=FONT_LBL),
                  {"bg": "PANEL", "fg": "TEXT"}).place(x=34, y=13)
        # 좌측 버튼들
        bx = self._reg(tk.Frame(top), {"bg": "PANEL"})
        bx.place(x=120, y=8)
        self._flat_btn(bx, "설정", self._open_settings).pack(side="left", padx=3)
        self._flat_btn(bx, "모델", self._change_model).pack(side="left", padx=3)
        self._flat_btn(bx, "폴더", self._change_folder).pack(side="left", padx=3)
        self._flat_btn(bx, "새로고침", self._refresh_files).pack(side="left", padx=3)
        self._flat_btn(bx, "새 세션", self._new_session).pack(side="left", padx=3)
        self._flat_btn(bx, "세션 목록", self._open_sessions).pack(side="left", padx=3)
        # 우측 상태
        self.watch_lbl = self._reg(tk.Label(top, text="\u25cb 감시", font=FONT_SM),
                                   {"bg": "PANEL", "fg": "FAINT"})
        self.watch_lbl.place(relx=1.0, x=-260, y=14)
        self._flat_btn(top, "감시 전환", self._toggle_watch).place(relx=1.0, x=-200, y=8)
        self.model_lbl = self._reg(tk.Label(top, text="\u25cf 로딩중", font=FONT_SM),
                                   {"bg": "PANEL", "fg": "WARN"})
        self.model_lbl.place(relx=1.0, x=-110, y=14)

        # ── 본문 ──
        body = self._reg(tk.Frame(self.root), {"bg": "BG"})
        body.pack(fill="both", expand=True)

        # 좌측 패널 (고정 300)
        left = self._reg(tk.Frame(body, width=300), {"bg": "PANEL"})
        left.pack(side="left", fill="y")
        left.pack_propagate(False)

        self._reg(tk.Label(left, text="  파일", font=FONT_LBL, anchor="w"),
                  {"bg": "PANEL", "fg": "DIM"}).pack(fill="x", padx=12, pady=(12, 6))

        srow = self._reg(tk.Frame(left), {"bg": "PANEL"})
        srow.pack(fill="x", padx=12)
        self.search_entry = self._reg(
            tk.Entry(srow, relief="flat", font=FONT, bd=0,
                     highlightthickness=0),
            {"bg": "SURF", "fg": "DIM", "insertbackground": "TEXT"})
        self.search_entry.insert(0, SEARCH_PLACEHOLDER)
        self.search_entry.pack(side="left", fill="x", expand=True, ipady=6)
        self.search_entry.bind("<FocusIn>", self._search_focus_in)
        self.search_entry.bind("<FocusOut>", self._search_focus_out)
        self.search_entry.bind("<Return>", lambda e: self._search())
        self._flat_btn(srow, "검색", self._search).pack(side="left", padx=(6, 0))

        self.stats_lbl = self._reg(
            tk.Label(left, text="", font=FONT_SM, anchor="w", justify="left",
                     wraplength=276),
            {"bg": "PANEL", "fg": "DIM"})
        self.stats_lbl.pack(fill="x", padx=12, pady=(8, 6))

        lf = self._reg(tk.Frame(left), {"bg": "PANEL"})
        lf.pack(fill="both", expand=True, padx=12)
        self.file_list = self._reg(
            tk.Listbox(lf, relief="flat", font=FONT, activestyle="none",
                       bd=0, highlightthickness=0),
            {"bg": "SURF", "fg": "TEXT"})
        self.file_list.pack(fill="both", expand=True)
        self.file_list.bind("<<ListboxSelect>>", self._on_file_select)
        self.file_list.bind("<Double-Button-1>", lambda e: self._summarize_selected())

        self.path_lbl = self._reg(
            tk.Label(left, text="(파일 선택 시 경로 표시)", font=FONT_SM,
                     anchor="w", justify="left", wraplength=276),
            {"bg": "PANEL", "fg": "FAINT"})
        self.path_lbl.pack(fill="x", padx=12, pady=(8, 6))

        brow = self._reg(tk.Frame(left), {"bg": "PANEL"})
        brow.pack(fill="x", padx=12, pady=(0, 12))
        self._flat_btn(brow, "선택 파일 요약", self._summarize_selected).pack(side="left")
        self._flat_btn(brow, "로그", self._show_log).pack(side="left", padx=6)

        # 우측 채팅 (BG로 분리)
        right = self._reg(tk.Frame(body), {"bg": "BG"})
        right.pack(side="left", fill="both", expand=True)

        self._reg(tk.Label(right,
                  text="  채팅   ·  텍스트 요약  ·  코드 작성  ·  코드 리뷰  ·  로그 질문",
                  font=FONT_LBL, anchor="w"),
                  {"bg": "BG", "fg": "DIM"}).pack(fill="x", padx=16, pady=(12, 6))

        cf = self._reg(tk.Frame(right), {"bg": "BG"})
        cf.pack(fill="both", expand=True, padx=16)
        csb = tk.Scrollbar(cf, width=8)
        csb.pack(side="right", fill="y")
        self.chat = self._reg(
            tk.Text(cf, relief="flat", wrap="word", font=FONT, state="disabled",
                    bd=0, highlightthickness=0, padx=12, pady=10,
                    yscrollcommand=csb.set),
            {"bg": "BG", "fg": "TEXT", "insertbackground": "TEXT"})
        self.chat.pack(fill="both", expand=True)
        csb.config(command=self.chat.yview)

        # 입력바 (SURF로 묶기)
        ibar = self._reg(tk.Frame(right), {"bg": "SURF"})
        ibar.pack(fill="x", padx=16, pady=12)
        self.entry = self._reg(
            tk.Text(ibar, height=3, relief="flat", font=FONT, bd=0,
                    highlightthickness=0, padx=8, pady=6),
            {"bg": "SURF", "fg": "TEXT", "insertbackground": "TEXT"})
        self.entry.pack(side="left", fill="both", expand=True)
        self.entry.bind("<Return>", self._on_enter)
        col = self._reg(tk.Frame(ibar), {"bg": "SURF"})
        col.pack(side="left", padx=6, pady=6)
        self.send_btn = tk.Button(col, text="전송", command=self._send, relief="flat",
                                  font=FONT_LBL, bd=0, padx=16, pady=4, cursor="hand2")
        self._reg(self.send_btn, {"bg": "ACCENT", "fg": "BG",
                                  "activebackground": "ACCENT", "activeforeground": "BG"})
        self.send_btn.pack(fill="x")
        stop_btn = self._flat_btn(col, "중지", self._stop_gen)
        stop_btn.pack(fill="x", pady=(6, 0))

        # ── 하단: 파일 이벤트 로그 패널 (접이식) ──
        logwrap = self._reg(tk.Frame(self.root), {"bg": "BG"})
        logwrap.pack(fill="x", side="bottom")

        bar = self._reg(tk.Frame(logwrap), {"bg": "PANEL"})
        bar.pack(fill="x")
        self.log_toggle = tk.Button(
            bar, text="\u25b8  파일 이벤트 로그", command=self._toggle_log,
            relief="flat", bd=0, font=FONT_LBL, anchor="w", padx=14, pady=5,
            cursor="hand2")
        self._reg(self.log_toggle, {"bg": "PANEL", "fg": "DIM",
                                    "activebackground": "PANEL", "activeforeground": "TEXT"})
        self.log_toggle.pack(side="left", fill="x", expand=True)
        self.log_count_lbl = self._reg(
            tk.Label(bar, text="0건", font=FONT_SM), {"bg": "PANEL", "fg": "FAINT"})
        self.log_count_lbl.pack(side="right", padx=8)
        self._flat_btn(bar, "지우기", self._clear_event_log).pack(side="right", padx=4, pady=3)

        self.log_panel = self._reg(tk.Frame(logwrap, height=150), {"bg": "BG"})
        lsb = tk.Scrollbar(self.log_panel, width=8)
        lsb.pack(side="right", fill="y")
        self.event_log = self._reg(
            tk.Text(self.log_panel, relief="flat", wrap="none", font=FONT_MONO,
                    state="disabled", bd=0, highlightthickness=0, padx=10, pady=6,
                    height=8, yscrollcommand=lsb.set),
            {"bg": "BG", "fg": "DIM", "insertbackground": "TEXT"})
        self.event_log.pack(fill="both", expand=True)
        lsb.config(command=self.event_log.yview)
        self._log_open = False
        self._event_n = 0

        # 하단 상태줄
        self.status = self._reg(
            tk.Label(self.root, text="준비", anchor="w", font=FONT_SM, height=1),
            {"bg": "BG", "fg": "FAINT"})
        self.status.pack(fill="x", side="bottom", padx=16, pady=(0, 4))

    def _flat_btn(self, parent, text, cmd):
        b = tk.Button(parent, text=text, command=cmd, relief="flat", font=FONT,
                      bd=0, padx=12, pady=4, cursor="hand2")
        self._reg(b, {"bg": "SURF", "fg": "TEXT",
                      "activebackground": "HOVER", "activeforeground": "TEXT"})
        self._hover_bind(b, "SURF", "HOVER")
        return b

    # ── 검색 placeholder ──
    def _search_focus_in(self, _e):
        if not self._search_active:
            self._search_active = True
            self.search_entry.delete(0, "end")
            self.search_entry.config(fg=self.C["TEXT"])

    def _search_focus_out(self, _e):
        if not self.search_entry.get().strip():
            self._search_active = False
            self.search_entry.delete(0, "end")
            self.search_entry.insert(0, SEARCH_PLACEHOLDER)
            self.search_entry.config(fg=self.C["DIM"])

    def _search_text(self):
        return "" if not self._search_active else self.search_entry.get().strip()

    # ════════════════ 채팅 출력 ════════════════
    def _append(self, text, tag=None):
        self.chat.config(state="normal")
        self.chat.insert("end", text, tag if tag else ())
        self.chat.see("end")
        self.chat.config(state="disabled")

    def _bubble_user(self, text):
        """내 메시지 블록 (오른쪽)."""
        self.chat.config(state="normal")
        self.chat.insert("end", "나 \u25b8\n", "user_name")
        self.chat.insert("end", text + "\n", "user")
        self.chat.see("end")
        self.chat.config(state="disabled")

    def _bubble_bot_start(self):
        """AI 답변 블록 시작 (라벨). 토큰은 스트리밍으로 흐르고, done에서 재렌더."""
        self.chat.config(state="normal")
        self.chat.insert("end", "AI \u25b8\n", "bot_name")
        self._bot_mark = self.chat.index("end-1c")   # 본문 시작 위치 기억
        self.chat.see("end")
        self.chat.config(state="disabled")

    def _render_bot_markdown(self, full_text):
        """스트리밍으로 흐른 raw 답변을 지우고, 코드/글 구분해서 다시 그림."""
        self.chat.config(state="normal")
        # 스트리밍 중 들어간 raw 본문 제거 (라벨 다음부터 끝까지)
        if hasattr(self, "_bot_mark"):
            self.chat.delete(self._bot_mark, "end")
        self._insert_markdown(full_text)
        self.chat.insert("end", "\n", "bot")
        self.chat.see("end")
        self.chat.config(state="disabled")

    def _insert_markdown(self, text):
        """```코드블록```, `인라인`, 일반 글을 각각 다른 태그로 삽입."""
        import re
        # ```lang\n ... ``` 분리
        parts = re.split(r"```", text)
        for i, part in enumerate(parts):
            if i % 2 == 1:
                # 코드 블록 (홀수 인덱스)
                body = part
                lang = ""
                if "\n" in body:
                    first, rest = body.split("\n", 1)
                    if len(first) <= 15 and " " not in first.strip():
                        lang, body = first.strip(), rest
                body = body.rstrip("\n")
                self.chat.insert("end", f"  {lang or 'code'}\n", "code_head")
                self.chat.insert("end", body + "\n", "code")
                self.chat.insert("end", " \n", "code_foot")
            else:
                # 일반 글 → `인라인 코드`만 따로
                self._insert_inline(part)

    def _insert_inline(self, text):
        import re
        for j, seg in enumerate(re.split(r"`", text)):
            tag = "icode" if j % 2 == 1 else "bot"
            if seg:
                self.chat.insert("end", seg, tag)

    def _set_status(self, t):
        self.status.config(text=t)

    # ════════════════ 파일 이벤트 로그 패널 ════════════════
    def _toggle_log(self):
        if self._log_open:
            self.log_panel.pack_forget()
            self.log_toggle.config(text="\u25b8  파일 이벤트 로그")
            self._log_open = False
        else:
            self.log_panel.pack(fill="both", expand=False)
            self.log_panel.configure(height=150)
            self.log_panel.pack_propagate(False)
            self.log_toggle.config(text="\u25be  파일 이벤트 로그", fg=self.C["DIM"])
            self._log_open = True

    def _clear_event_log(self):
        self.event_log.config(state="normal")
        self.event_log.delete("1.0", "end")
        self.event_log.config(state="disabled")
        self._event_n = 0
        self.log_count_lbl.config(text="0건")

    def _add_event(self, t, action, path, note):
        # 콘솔에도 한 줄 (디버깅용)
        try:
            print(f"[{t}] {action} {path}" + (f" — {note}" if note else ""))
        except Exception:
            pass
        clock = t.split(" ")[1] if " " in t else t
        tag = action if action in ("생성", "수정", "삭제", "이동") else "path"
        self.event_log.config(state="normal")
        self.event_log.insert("end", clock + "  ", "ts")
        self.event_log.insert("end", f"{action:<4}", tag)
        self.event_log.insert("end", "  " + path, "path")
        if note:
            self.event_log.insert("end", "  — " + note, "ts")
        self.event_log.insert("end", "\n")
        # 너무 길면 앞부분 잘라냄(2000줄 유지)
        if int(self.event_log.index("end-1c").split(".")[0]) > 2000:
            self.event_log.delete("1.0", "200.0")
        self.event_log.see("end")
        self.event_log.config(state="disabled")
        self._event_n += 1
        self.log_count_lbl.config(text=f"{self._event_n}건")
        # 접혀있고 파일이벤트면 토글 라벨에 표시
        if not self._log_open and action in ("생성", "수정", "삭제", "이동"):
            self.log_toggle.config(text="\u25b8  파일 이벤트 로그  \u25cf",
                                   fg=self.C["ACCENT"])

    # ════════════════ 모델 ════════════════
    def _load_model_async(self):
        def work():
            try:
                self.engine.load(self.cfg["model_path"],
                                 n_ctx=self.cfg["n_ctx"],
                                 n_gpu_layers=self.cfg["n_gpu_layers"])
                self.q.put(("model_ok", os.path.basename(self.cfg["model_path"])))
            except Exception as e:
                self.q.put(("model_fail", str(e)))
        threading.Thread(target=work, daemon=True).start()

    # ════════════════ 파일 ════════════════
    def _refresh_files(self):
        self.files = ft.list_files(self.cfg["watch_dir"], self.cfg["recursive"])
        self._fill_list(self.files)
        self.stats_lbl.config(
            text=f"{self.cfg['watch_dir']}\n총 {len(self.files)}개  ·  {ft.ext_stats(self.files)}")

    def _fill_list(self, files):
        self.file_list.delete(0, "end")
        for fn, fp, size in files[:500]:
            ext = os.path.splitext(fn)[1].lower()
            self.file_list.insert("end", EXT_MARK.get(ext, "    ") + fn)
        if len(files) > 500:
            self.file_list.insert("end", f"    ... 외 {len(files)-500}개")
        self._shown = files[:500]

    def _search(self):
        kw = self._search_text()
        result = ft.search_files(self.cfg["watch_dir"], kw, self.cfg["recursive"])
        self._fill_list(result)
        self.logger.write("검색", self.cfg["watch_dir"], note=f"키워드={kw}, {len(result)}건")
        if kw and self.engine.ready and not self.busy:
            prompt = ft.build_search_result_prompt(kw, result)
            self._ask_llm_internal(prompt, show_user=f"[검색: {kw}]")

    def _on_file_select(self, _e):
        sel = self.file_list.curselection()
        if not sel or sel[0] >= len(getattr(self, "_shown", [])):
            return
        fn, fp, size = self._shown[sel[0]]
        self.path_lbl.config(text=f"{fp}\n{size:,} bytes")

    def _summarize_selected(self):
        sel = self.file_list.curselection()
        if not sel or sel[0] >= len(getattr(self, "_shown", [])):
            messagebox.showinfo("안내", "파일을 먼저 선택하세요.")
            return
        fn, fp, _ = self._shown[sel[0]]
        if not ft.is_text_file(fp, self.cfg["extensions"]):
            messagebox.showinfo("안내", f"텍스트로 읽을 수 없는 확장자입니다: {fn}")
            return
        content, truncated = ft.read_text_auto(fp)
        prompt = ft.build_summary_prompt(fn, content, truncated)
        self.logger.write("요약", fp)
        self._ask_llm_internal(prompt, show_user=f"[파일 요약: {fn}]")

    # ════════════════ 로그 ════════════════
    def _show_log(self):
        import datetime as _dt
        today = _dt.datetime.now().strftime("%Y-%m-%d")
        lines = self.logger.read_lines(today, 50)
        if not lines:
            self._append(f"[{today} 작업 로그 없음]\n\n", "sys")
            return
        self._append(f"{today} 작업 로그\n", "sys")
        self._append("\n".join(lines[-30:]) + "\n\n", "sys")

    # ════════════════ 세션 저장/불러오기 ════════════════
    def _save_current_session(self):
        if self.history:
            self.sessions.save(self.sid, self.history)

    def _new_session(self):
        if self.busy:
            messagebox.showinfo("안내", "생성 중에는 세션을 바꿀 수 없습니다.")
            return
        self._save_current_session()
        self.history = []
        self.sid = SessionStore.new_id()
        self.chat.config(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.config(state="disabled")
        self._append("[새 세션 시작 — 이전 대화는 저장됨]\n\n", "sys")
        self._set_status("새 세션")

    def _open_sessions(self):
        self._save_current_session()
        C = self.C
        win = tk.Toplevel(self.root)
        win.title("세션 목록")
        win.configure(bg=C["PANEL"])
        win.geometry("560x420")
        win.grab_set()

        tk.Label(win, text="저장된 세션 (더블클릭으로 불러오기)", bg=C["PANEL"],
                 fg=C["DIM"], font=FONT_LBL).pack(anchor="w", padx=14, pady=(12, 6))

        frame = tk.Frame(win, bg=C["PANEL"])
        frame.pack(fill="both", expand=True, padx=14)
        sb = tk.Scrollbar(frame, width=8)
        sb.pack(side="right", fill="y")
        lb = tk.Listbox(frame, relief="flat", font=FONT, activestyle="none",
                        bd=0, highlightthickness=0, bg=C["SURF"], fg=C["TEXT"],
                        selectbackground=C["ACCENT"], selectforeground=C["BG"],
                        yscrollcommand=sb.set)
        lb.pack(fill="both", expand=True)
        sb.config(command=lb.yview)

        rows = self.sessions.list_sessions()
        for sid, title, saved, turns in rows:
            mark = "  \u25cf " if sid == self.sid else "    "
            lb.insert("end", f"{mark}{saved}  \u00b7  {turns}\ud134  \u00b7  {title}")
        if not rows:
            lb.insert("end", "    (저장된 세션 없음)")

        def do_load():
            sel = lb.curselection()
            if not sel or sel[0] >= len(rows):
                return
            sid = rows[sel[0]][0]
            if self.busy:
                messagebox.showinfo("안내", "생성 중에는 불러올 수 없습니다.", parent=win)
                return
            self._save_current_session()
            self.history = self.sessions.load(sid)
            self.sid = sid
            self._render_history()
            win.destroy()
            self._set_status(f"세션 불러옴: {sid}")

        def do_delete():
            sel = lb.curselection()
            if not sel or sel[0] >= len(rows):
                return
            sid = rows[sel[0]][0]
            if messagebox.askyesno("삭제", f"세션 {sid} 을(를) 삭제할까요?", parent=win):
                self.sessions.delete(sid)
                win.destroy()
                self._open_sessions()

        lb.bind("<Double-Button-1>", lambda e: do_load())
        brow = tk.Frame(win, bg=C["PANEL"])
        brow.pack(fill="x", padx=14, pady=12)
        for txt, cmd in [("불러오기", do_load), ("삭제", do_delete), ("닫기", win.destroy)]:
            b = tk.Button(brow, text=txt, command=cmd, relief="flat", bd=0, font=FONT,
                          bg=C["SURF"], fg=C["TEXT"], activebackground=C["HOVER"],
                          activeforeground=C["TEXT"], padx=14, pady=4, cursor="hand2")
            b.pack(side="left", padx=4)

    def _render_history(self):
        """history를 채팅창에 다시 그림."""
        self.chat.config(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.config(state="disabled")
        for m in self.history:
            if m["role"] == "user":
                self._bubble_user(m["content"])
            else:
                self._bubble_bot_start()
                self._render_bot_markdown(m["content"])

    # ════════════════ 채팅 ════════════════
    _LOG_KW = ("뭐 했", "뭐했", "뭐 만들", "작업 내역", "작업내역", "작업 로그", "작업로그",
               "로그", "기록 보여", "기록 찾", "오늘 한", "어제 한",
               "변경한 내용", "변경 내용", "변경내용", "변경된", "바뀐",
               "수정한", "수정된", "삭제한", "삭제된", "생성한", "생성된", "만든 파일",
               "파일 변경", "파일변경", "변경 이력", "변경이력", "수정 이력", "이력 찾",
               "무슨 작업", "무슨 파일", "어떤 파일", "한 일", "했는지")

    def _on_enter(self, e):
        if e.state & 0x0001:
            return
        self._send()
        return "break"

    def _is_log_question(self, msg):
        """로그 조회 질문인지 판정.
        ① 로그 키워드가 있거나
        ② 날짜(오늘/어제/N월N일/YYYY-MM-DD)가 있고 '찾/보여/알려/확인/내역' 류가 함께."""
        if any(k in msg for k in self._LOG_KW):
            return True
        dates = self.logger.available_dates()
        has_date = ft.parse_date_from_question(msg, dates) is not None
        verbs = ("찾아", "찾아봐", "찾아줘", "보여", "알려", "확인", "내역", "정리", "뭐")
        if has_date and any(v in msg for v in verbs):
            return True
        return False

    def _send(self):
        if self.busy:
            return
        msg = self.entry.get("1.0", "end").strip()
        if not msg:
            return
        self.entry.delete("1.0", "end")
        if self._is_log_question(msg):
            dates = self.logger.available_dates()
            date_str = ft.parse_date_from_question(msg, dates)
            if date_str is None:
                import datetime as _dt
                date_str = _dt.datetime.now().strftime("%Y-%m-%d")
            records = self.logger.read_records(date_str)
            prompt = ft.build_log_prompt(msg, records, date_str)
            self._ask_llm_internal(prompt, show_user=f"{msg}  ({date_str})")
            return
        if any(k in msg for k in ("코드 작성", "코드 짜", "만들어줘", "작성해줘")):
            self.logger.write("코드작성", "(채팅)", note=msg[:60])
        self._ask_llm(msg)

    def _ask_llm(self, user_msg):
        self.history.append({"role": "user", "content": user_msg})
        self._bubble_user(user_msg)
        self._run_stream(self.history)

    def _ask_llm_internal(self, built_prompt, show_user=""):
        if show_user:
            self._bubble_user(show_user)
        self.history.append({"role": "user", "content": show_user or built_prompt})
        msgs = self.history[:-1] + [{"role": "user", "content": built_prompt}]
        self._run_stream(msgs)

    def _run_stream(self, msgs):
        if not self.engine.ready:
            self._append("[모델이 아직 로드되지 않았습니다]\n\n", "err")
            self.history.pop()
            return
        self.busy = True
        self.send_btn.config(state="disabled")
        self._set_status("생성 중...")
        self._bubble_bot_start()
        send = msgs[-10:]
        self.q  # noop
        threading.Thread(
            target=self.engine.stream_chat,
            args=(send, lambda t: self.q.put(("tok", t)),
                  lambda full: self.q.put(("done", full))),
            kwargs={"temperature": self.cfg["temperature"],
                    "max_tokens": self.cfg["max_tokens"]},
            daemon=True).start()

    def _stop_gen(self):
        self.engine.stop()

    # ════════════════ 감시 ════════════════
    def _start_watch(self):
        ok, msg = self.watcher.start(self.cfg["watch_dir"],
                                     self.cfg["extensions"],
                                     self.cfg["recursive"])
        if ok:
            self.watch_lbl.config(text="\u25cf 감시", fg=self.C["OK"])
        else:
            self.watch_lbl.config(text=f"\u25cb {msg}", fg=self.C["WARN"])

    def _toggle_watch(self):
        if self.watcher.running:
            self.watcher.stop()
            self.watch_lbl.config(text="\u25cb 감시", fg=self.C["FAINT"])
        else:
            self._start_watch()

    # ════════════════ 폴더 ════════════════
    def _change_folder(self):
        d = filedialog.askdirectory(title="감시/검색 폴더 선택")
        if d:
            self.cfg["watch_dir"] = d
            save_config(self.cfg)
            self._refresh_files()
            if self.watcher.running:
                self._start_watch()

    # ════════════════ 모델 변경 ════════════════
    def _change_model(self):
        if self.busy:
            messagebox.showinfo("안내", "생성 중에는 모델을 바꿀 수 없습니다.")
            return
        p = filedialog.askopenfilename(
            title="GGUF 모델 선택",
            filetypes=[("GGUF 모델", "*.gguf"), ("모든 파일", "*.*")])
        if not p:
            return
        self.cfg["model_path"] = p
        save_config(self.cfg)
        self.model_lbl.config(text="\u25cf 로딩중", fg=self.C["WARN"])
        self._append(f"[모델 교체: {os.path.basename(p)} 로딩 시작]\n\n", "sys")
        self.engine.llm = None
        self._load_model_async()

    # ════════════════ 설정창 ════════════════
    def _open_settings(self):
        C = self.C
        win = tk.Toplevel(self.root)
        win.title("설정")
        win.configure(bg=C["PANEL"])
        win.geometry("640x400")
        win.grab_set()

        rows = [("GGUF 모델 경로", "model_path"),
                ("감시/검색 폴더", "watch_dir"),
                ("로그 폴더 (날짜별 저장)", "log_dir"),
                ("감시 확장자 (쉼표구분)", "extensions")]
        vars_ = {}
        for i, (label, key) in enumerate(rows):
            tk.Label(win, text=label, bg=C["PANEL"], fg=C["DIM"], font=FONT).grid(
                row=i, column=0, sticky="w", padx=14, pady=8)
            val = self.cfg[key]
            if key == "extensions":
                val = ",".join(val)
            v = tk.StringVar(value=val)
            vars_[key] = v
            tk.Entry(win, textvariable=v, width=42, bg=C["SURF"], fg=C["TEXT"],
                     insertbackground=C["TEXT"], relief="flat", bd=0,
                     highlightthickness=0, font=FONT).grid(
                row=i, column=1, padx=6, ipady=4, sticky="w")

        def picker(key, kind):
            def f():
                if kind == "open":
                    p = filedialog.askopenfilename(
                        parent=win, title="GGUF 모델 선택",
                        filetypes=[("GGUF 모델", "*.gguf"), ("모든 파일", "*.*")])
                else:
                    p = filedialog.askdirectory(parent=win, title="폴더 선택")
                if p:
                    vars_[key].set(p)
            return f

        for r, (key, kind) in enumerate([("model_path", "open"),
                                         ("watch_dir", "dir"),
                                         ("log_dir", "dir")]):
            tk.Button(win, text="찾기", command=picker(key, kind),
                      bg=C["SURF"], fg=C["TEXT"], relief="flat", bd=0,
                      activebackground=C["HOVER"], activeforeground=C["TEXT"],
                      font=FONT, padx=10, cursor="hand2").grid(
                row=r, column=2, padx=(0, 14))

        rec_v = tk.BooleanVar(value=self.cfg["recursive"])
        tk.Checkbutton(win, text="하위 폴더 포함", variable=rec_v, bg=C["PANEL"],
                       fg=C["TEXT"], selectcolor=C["SURF"], font=FONT,
                       activebackground=C["PANEL"], activeforeground=C["TEXT"]).grid(
            row=4, column=1, sticky="w", padx=6, pady=4)

        tk.Label(win, text="temp", bg=C["PANEL"], fg=C["DIM"], font=FONT).grid(
            row=5, column=0, sticky="w", padx=14)
        temp_v = tk.StringVar(value=str(self.cfg["temperature"]))
        tk.Entry(win, textvariable=temp_v, width=8, bg=C["SURF"], fg=C["TEXT"],
                 insertbackground=C["TEXT"], relief="flat", bd=0,
                 highlightthickness=0, font=FONT).grid(
            row=5, column=1, sticky="w", padx=6, ipady=3)

        tk.Label(win, text="색상 테마", bg=C["PANEL"], fg=C["DIM"], font=FONT).grid(
            row=6, column=0, sticky="w", padx=14, pady=8)
        theme_v = tk.StringVar(value=self.cfg.get("theme", "Graphite"))
        box = ttk.Combobox(win, textvariable=theme_v, state="readonly",
                           values=list(THEMES.keys()), width=18, font=FONT)
        box.grid(row=6, column=1, sticky="w", padx=6)
        box.bind("<<ComboboxSelected>>",
                 lambda e: (self._set_theme(theme_v.get()),
                            win.configure(bg=self.C["PANEL"])))

        def do_save():
            old_model = self.cfg["model_path"]
            self.cfg["model_path"] = vars_["model_path"].get().strip()
            self.cfg["watch_dir"] = vars_["watch_dir"].get().strip()
            self.cfg["log_dir"] = vars_["log_dir"].get().strip()
            self.cfg["extensions"] = [e.strip() for e in vars_["extensions"].get().split(",") if e.strip()]
            self.cfg["recursive"] = rec_v.get()
            try:
                self.cfg["temperature"] = float(temp_v.get())
            except ValueError:
                pass
            self.cfg["theme"] = theme_v.get()
            save_config(self.cfg)
            self._set_theme(theme_v.get())
            self.logger.log_dir = self.cfg["log_dir"]
            self._refresh_files()
            if self.watcher.running:
                self._start_watch()
            if self.cfg["model_path"] != old_model:
                self.model_lbl.config(text="\u25cf 로딩중", fg=self.C["WARN"])
                self.engine.llm = None
                self._load_model_async()
            win.destroy()

        tk.Button(win, text="저장", command=do_save, bg=C["ACCENT"], fg=C["BG"],
                  relief="flat", bd=0, font=FONT_LBL, padx=22, pady=5,
                  cursor="hand2").grid(row=7, column=1, sticky="e", padx=6, pady=16)

    # ════════════════ 큐 폴링 ════════════════
    def _poll(self):
        try:
            while True:
                kind, val = self.q.get_nowait()
                if kind == "fsevent":
                    self._add_event(*val)
                elif kind == "tok":
                    self._append(val, "bot")
                elif kind == "done":
                    self._render_bot_markdown(val)
                    self.history.append({"role": "assistant", "content": val})
                    self.busy = False
                    self.send_btn.config(state="normal")
                    self._set_status("준비")
                elif kind == "model_ok":
                    self.model_lbl.config(text=f"\u25cf {val}", fg=self.C["OK"])
                    self._append(f"[모델 로드 완료: {val} — 콘솔에서 Vulkan 확인]\n\n", "sys")
                elif kind == "model_fail":
                    self.model_lbl.config(text="\u25cf 로드 실패", fg=self.C["ERR"])
                    self._append(f"[모델 로드 실패] {val}\n설정에서 경로를 확인하세요.\n\n", "err")
        except queue.Empty:
            pass
        self.root.after(40, self._poll)

    def _on_close(self):
        self._save_current_session()
        self.watcher.stop()
        self.engine.stop()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
