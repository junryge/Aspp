[데모스 오늘(2026-06-08) 변경 전체 — 최신]
브랜치: claude/practical-carson-WKG6M
※ 경로 그대로 레포 루트에 덮어쓰기 후 ★서버 재시작★ (재배포 안 하면 옛 동작/옛 에러 그대로!)

== 1) API 모델 5종 (common 게이트웨이) ==
  ★ scientific-assistant/api_config.json (실제 로드 핵심)
  demos_v1/models.py / routes_chat.py / logpresso.py / router.py / routes_api.py / templates/index.html
  - Qwen3.6-35B-A3B(dev) / Qwen2.5-VL-72B(vl-72b) / Qwen3-VL-30B(vl-fast) / gemma-4-31B-it(gemma) / gpt-oss-20b(common)
  ※ gemma 는 영어 사고과정 누출 심함 → Qwen3.6-35B 권장

== 2) gemma HTTP 500 수정 ==  ★ demos_v1/llm_compat.py (신규) + chat_post

== 3) API max_tokens 상한 하향 ==

== 4) 컨텍스트 초과 자동 트림 (GGUF·API) ==  demos_v1/routes_chat.py
   - 큰 입력은 앞부분 잘라 한 번에 답(에러 방지)
   - 토큰 추정 하한 2.6/char + '하드 글자수' 안전장치(v3) → 밀집 CSV/토크나이저 실패에도 절대 초과 안 함
   - ※ 잘림 경고에 "[컨텍스트보호 v3]" 표식 → 이 문구가 보이면 새 코드가 적용된 것

== 5) GGUF '부분 N/20' 분할 비활성화 ==  단일 패스

== 6) 개인 에이전트 (agent_window.html) ==
   - ⏹ 중지 버튼
   - ⏭ 이어서 보기 버튼 (답이 잘리면 이어서 작성)
   - 한국어 답 + 영어 사고과정/<think> 차단 + 결론 위주 (보고서 스킬 형식은 유지)

※ 거대 데이터 전체 분석은 API(128K)+Qwen 권장. GGUF(32K)는 앞부분만(에러 안 남).
