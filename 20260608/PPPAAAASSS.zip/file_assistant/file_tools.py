# -*- coding: utf-8 -*-
"""file_tools.py - 파일 목록/검색/읽기 + LLM 프롬프트 빌더"""
import os
from collections import Counter

MAX_SUMMARY_CHARS = 6000   # 4B 컨텍스트 보호 - 요약 시 파일 앞부분만


def list_files(root, recursive=True):
    """폴더의 전체 파일 목록 [(이름, 전체경로, 크기)]."""
    out = []
    if not os.path.isdir(root):
        return out
    if recursive:
        for dirpath, dirnames, filenames in os.walk(root):
            # 숨김/시스템성 폴더 제외
            dirnames[:] = [d for d in dirnames
                           if not d.startswith(".") and d not in ("__pycache__", "node_modules")]
            for fn in filenames:
                fp = os.path.join(dirpath, fn)
                try:
                    out.append((fn, fp, os.path.getsize(fp)))
                except OSError:
                    pass
    else:
        for fn in os.listdir(root):
            fp = os.path.join(root, fn)
            if os.path.isfile(fp):
                try:
                    out.append((fn, fp, os.path.getsize(fp)))
                except OSError:
                    pass
    return out


def search_files(root, keyword, recursive=True):
    """파일명에 keyword(대소문자 무시) 포함된 것만."""
    kw = (keyword or "").lower().strip()
    files = list_files(root, recursive)
    if not kw:
        return files
    return [f for f in files if kw in f[0].lower()]


def ext_stats(files):
    """확장자별 개수 문자열. 예: '.py 30 | .csv 12 | .md 5'"""
    cnt = Counter(os.path.splitext(f[0])[1].lower() or "(없음)" for f in files)
    return " | ".join(f"{e} {n}" for e, n in cnt.most_common(10))


def read_text_auto(path, max_chars=MAX_SUMMARY_CHARS):
    """utf-8 → cp949 → euc-kr 자동감지로 텍스트 읽기. (내용, 잘렸는지)"""
    for enc in ("utf-8", "cp949", "euc-kr"):
        try:
            with open(path, encoding=enc) as f:
                text = f.read(max_chars + 1)
            truncated = len(text) > max_chars
            return text[:max_chars], truncated
        except (UnicodeDecodeError, LookupError):
            continue
        except OSError as e:
            return f"(읽기 실패: {e})", False
    return "(텍스트로 읽을 수 없는 파일)", False


def is_text_file(path, extensions):
    return os.path.splitext(path)[1].lower() in [e.lower() for e in extensions]


# ── LLM에 넘길 프롬프트 빌더 (결과값을 LLM이 받아 처리하는 구조) ──

def build_summary_prompt(filename, content, truncated):
    note = " (긴 파일이라 앞부분만 제공됨)" if truncated else ""
    return (f"다음은 파일 '{filename}'의 내용이다{note}. "
            f"무슨 파일인지, 핵심 내용이 뭔지 3~5줄로 요약해라.\n\n"
            f"=== 파일 내용 ===\n{content}")


def build_search_result_prompt(keyword, files):
    if not files:
        return f"'{keyword}' 검색 결과가 0건이다. 사용자에게 짧게 알려줘라."
    lines = "\n".join(f"- {fn} ({fp})" for fn, fp, _ in files[:30])
    more = f"\n(외 {len(files)-30}개 더)" if len(files) > 30 else ""
    return (f"'{keyword}' 파일명 검색 결과 {len(files)}건이다. "
            f"어떤 파일들인지 한두 줄로 정리해서 알려줘라.\n\n{lines}{more}")


import re as _re


def parse_date_from_question(question, available_dates):
    """질문에서 날짜를 추출. 못 찾으면 None.
    '6월 10일', '2026-06-10', '오늘', '어제' 지원."""
    import datetime as _dt
    today = _dt.date.today()
    q = question
    if "오늘" in q:
        return today.strftime("%Y-%m-%d")
    if "어제" in q:
        return (today - _dt.timedelta(days=1)).strftime("%Y-%m-%d")
    # 2026-06-10 형식
    m = _re.search(r"(20\d{2})[-./](\d{1,2})[-./](\d{1,2})", q)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return f"{y:04d}-{mo:02d}-{d:02d}"
    # 2026년 06월 11일 (년 글자는 오타 허용: 년/뇬/연 등 한 글자 무시)
    m = _re.search(r"(20\d{2})\s*.?\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일", q)
    if m:
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        return f"{y:04d}-{mo:02d}-{d:02d}"
    # N월 N일
    m = _re.search(r"(\d{1,2})\s*월\s*(\d{1,2})\s*일", q)
    if m:
        mo, d = int(m.group(1)), int(m.group(2))
        for ds in (available_dates or []):
            try:
                dd = _dt.datetime.strptime(ds, "%Y-%m-%d").date()
                if dd.month == mo and dd.day == d:
                    return ds
            except ValueError:
                continue
        return f"{today.year:04d}-{mo:02d}-{d:02d}"
    return None


def build_log_prompt(question, records, date_str=None):
    """records: dict 리스트({time,action,path,note}). 날짜별 작업 정리용."""
    if not records:
        when = date_str or "해당 날짜"
        return (f"사용자 질문: {question}\n"
                f"{when}의 작업 로그가 비어있다. 기록이 없다고 한 문장으로 알려줘라.")
    # 액션별 집계
    from collections import Counter
    cnt = Counter(r.get("action", "") for r in records)
    summary = ", ".join(f"{a} {n}건" for a, n in cnt.most_common())
    lines = []
    for r in records[-120:]:
        t = r.get("time", "")[11:]   # 시:분:초만
        s = f"{t} {r.get('action','')} {r.get('path','')}"
        if r.get("note"):
            s += f" — {r['note']}"
        lines.append(s)
    joined = "\n".join(lines)
    head = f"=== {date_str} 작업 로그 (총 {len(records)}건: {summary}) ===" if date_str \
        else f"=== 작업 로그 (총 {len(records)}건: {summary}) ==="
    return (f"다음은 그날의 파일 작업 로그다. 사용자 질문에 맞춰 무엇을 했는지\n"
            f"시간 흐름과 핵심 위주로 한국어로 간결히 정리해라. 파일을 묶어서 설명해도 좋다.\n"
            f"질문: {question}\n\n{head}\n{joined}")
