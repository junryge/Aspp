[데모스 API 모델 설정 변경 — 사용 가능 5종으로 교체]
브랜치: claude/practical-carson-WKG6M  (커밋 f36ecdf)
※ 경로 그대로 레포에 덮어쓰기. 서버 재시작하면 드롭다운 자동 갱신.

== 사용 가능 모델 5종 (전부 http://common.llm.skhynix.com/v1/chat/completions) ==
  Qwen3.6-35B-A3B         일반/코드 플래그십   (env_id=dev)
  Qwen2.5-VL-72B-Instruct 비전 대형            (env_id=vl-72b)
  Qwen3-VL-30B-A3B        비전 경량            (env_id=vl-fast)
  gemma-4-31B-it          일반                 (env_id=gemma)
  gpt-oss-20b             경량/빠름            (env_id=common)
  (폐기: GLM-5 / Coder-480B / Coder-Next / Next-80B / Coder-30B / dev.hcp)

== 포함 파일 (5개) ==
  scientific-assistant/demos_v1/models.py
    - MODEL_REGISTRY / API_MODEL_TIERS / FALLBACK_CHAINS 전면 교체 (핵심)
  scientific-assistant/demos_v1/routes_chat.py
    - 멀티에이전트 합성 기본 모델 qwen3-coder-480b -> qwen36-35b
  scientific-assistant/demos_v1/logpresso.py
    - 기본 텍스트 모델 glm-5 -> qwen36-35b
  scientific-assistant/demos_v1/router.py
    - 자동 라우팅 표시 문구 GLM-5 -> Qwen3.6-35B (env_id 유지: dev/vl-fast/common)
  scientific-assistant/demos_v1/routes_api.py
    - 예시 주석 정정

※ 모델 드롭다운은 /api/config(ENV_CONFIG)에서 자동 생성되므로 별도 UI 수정 불필요.
