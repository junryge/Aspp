# -*- coding: utf-8 -*-
"""watcher.py - 폴더 실시간 감시(watchdog) + JSONL 작업 로그"""
import os
import json
import datetime

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    WATCHDOG_OK = True
except ImportError:
    WATCHDOG_OK = False
    FileSystemEventHandler = object   # 더미


class WorkLogger:
    """날짜별 JSONL 작업 로그. worklogs/worklog_YYYY-MM-DD.jsonl 로 자동 분리.
    + 실시간 이벤트 콜백(on_event)."""

    def __init__(self, log_dir, on_event=None):
        self.log_dir = log_dir
        self.on_event = on_event
        try:
            os.makedirs(self.log_dir, exist_ok=True)
        except Exception:
            pass

    def _path_for(self, date_str):
        """date_str='2026-06-11' → 해당 날짜 파일 경로."""
        return os.path.join(self.log_dir, f"worklog_{date_str}.jsonl")

    def write(self, action, path, note=""):
        nowdt = datetime.datetime.now()
        today = nowdt.strftime("%Y-%m-%d")
        now = nowdt.strftime("%Y-%m-%d %H:%M:%S")
        rec = {"time": now, "action": action, "path": path, "note": note}
        try:
            os.makedirs(self.log_dir, exist_ok=True)
            with open(self._path_for(today), "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception:
            pass
        if self.on_event:
            try:
                self.on_event(now, action, path, note)
            except Exception:
                pass

    # ── 조회 ──
    def available_dates(self):
        """로그가 있는 날짜 목록(최신순)."""
        out = []
        try:
            for fn in os.listdir(self.log_dir):
                if fn.startswith("worklog_") and fn.endswith(".jsonl"):
                    out.append(fn[len("worklog_"):-len(".jsonl")])
        except Exception:
            pass
        return sorted(out, reverse=True)

    def read_records(self, date_str):
        """특정 날짜의 레코드 dict 리스트."""
        p = self._path_for(date_str)
        recs = []
        if not os.path.isfile(p):
            return recs
        try:
            with open(p, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        recs.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        except Exception:
            pass
        return recs

    def read_lines(self, date_str=None, max_lines=300):
        """사람이 읽을 문자열 리스트. date_str 없으면 오늘."""
        if date_str is None:
            date_str = datetime.datetime.now().strftime("%Y-%m-%d")
        out = []
        for r in self.read_records(date_str):
            s = f"[{r.get('time','')}] {r.get('action','')} {r.get('path','')}"
            if r.get("note"):
                s += f" — {r['note']}"
            out.append(s)
        return out[-max_lines:]


class _Handler(FileSystemEventHandler):
    """파일 이벤트 → 로그. 확장자 필터 적용."""

    def __init__(self, logger, extensions):
        self.logger = logger
        self.exts = [e.lower() for e in extensions]

    def _ok(self, path):
        return os.path.splitext(path)[1].lower() in self.exts

    def on_created(self, event):
        if not event.is_directory and self._ok(event.src_path):
            self.logger.write("생성", event.src_path)

    def on_modified(self, event):
        if not event.is_directory and self._ok(event.src_path):
            self.logger.write("수정", event.src_path)

    def on_deleted(self, event):
        if not event.is_directory and self._ok(event.src_path):
            self.logger.write("삭제", event.src_path)

    def on_moved(self, event):
        if not event.is_directory and self._ok(event.dest_path):
            self.logger.write("이동", f"{event.src_path} → {event.dest_path}")


class FolderWatcher:
    """감시 시작/중지. GUI에서 토글."""

    def __init__(self, logger):
        self.logger = logger
        self.observer = None

    @property
    def available(self):
        return WATCHDOG_OK

    @property
    def running(self):
        return self.observer is not None

    def start(self, watch_dir, extensions, recursive=True):
        if not WATCHDOG_OK:
            return False, "watchdog 미설치 (pip install watchdog)"
        if not os.path.isdir(watch_dir):
            return False, f"폴더 없음: {watch_dir}"
        self.stop()
        self.observer = Observer()
        self.observer.schedule(_Handler(self.logger, extensions),
                               watch_dir, recursive=recursive)
        self.observer.daemon = True
        self.observer.start()
        return True, "감시 시작"

    def stop(self):
        if self.observer:
            try:
                self.observer.stop()
                self.observer.join(timeout=2)
            except Exception:
                pass
            self.observer = None
