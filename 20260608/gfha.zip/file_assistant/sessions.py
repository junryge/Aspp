# -*- coding: utf-8 -*-
"""sessions.py - 대화 세션을 디스크에 저장/불러오기.
sessions/session_YYYY-MM-DD_HHMMSS.json 형태로 보관.
{ "id", "created", "title", "history": [{role, content}, ...] }
"""
import os
import json
import datetime


class SessionStore:
    def __init__(self, session_dir):
        self.dir = session_dir
        try:
            os.makedirs(self.dir, exist_ok=True)
        except Exception:
            pass

    def _path(self, sid):
        return os.path.join(self.dir, f"session_{sid}.json")

    @staticmethod
    def new_id():
        return datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")

    @staticmethod
    def make_title(history):
        """첫 사용자 발화에서 제목 추출(없으면 시간)."""
        for m in history:
            if m.get("role") == "user":
                t = m["content"].strip().replace("\n", " ")
                # 내부 프롬프트([검색:..], [파일 요약:..])는 그대로 짧게
                return t[:40] + ("…" if len(t) > 40 else "")
        return "빈 세션"

    def save(self, sid, history, title=None):
        """현재 history를 sid 파일로 저장(덮어쓰기). 비어있으면 저장 안 함."""
        if not history:
            return False
        try:
            os.makedirs(self.dir, exist_ok=True)
            data = {
                "id": sid,
                "created": sid.replace("_", " "),
                "saved": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "title": title or self.make_title(history),
                "history": history,
            }
            with open(self._path(sid), "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True
        except Exception:
            return False

    def load(self, sid):
        """sid 세션의 history 반환. 없으면 빈 리스트."""
        p = self._path(sid)
        if not os.path.isfile(p):
            return []
        try:
            with open(p, encoding="utf-8") as f:
                return json.load(f).get("history", [])
        except Exception:
            return []

    def list_sessions(self):
        """[(id, title, saved, turns)] 최신순."""
        out = []
        try:
            for fn in os.listdir(self.dir):
                if not (fn.startswith("session_") and fn.endswith(".json")):
                    continue
                p = os.path.join(self.dir, fn)
                try:
                    with open(p, encoding="utf-8") as f:
                        d = json.load(f)
                    out.append((d.get("id", fn[8:-5]),
                                d.get("title", "(제목없음)"),
                                d.get("saved", ""),
                                len(d.get("history", []))))
                except Exception:
                    continue
        except Exception:
            pass
        return sorted(out, key=lambda x: x[0], reverse=True)

    def delete(self, sid):
        try:
            os.remove(self._path(sid))
            return True
        except Exception:
            return False
