# -*- coding: utf-8 -*-
"""themes.py - 색상 테마 프리셋 (Graphite 기반, 업로드 디자인 색상 적용).
설정창에서 선택 → 즉시 적용.
역할 키: BG(배경) PANEL(패널) SURF(표면/입력/리스트) HOVER(호버)
         TEXT(본문) DIM(보조) FAINT(흐림) ACCENT(포인트) OK WARN ERR
"""

THEMES = {
    "Graphite": {   # 기본
        "BG": "#141417", "PANEL": "#1c1c21", "SURF": "#26262d", "HOVER": "#30303a",
        "TEXT": "#e8e8ec", "DIM": "#9a9aa6", "FAINT": "#5c5c66",
        "ACCENT": "#6c8cff", "OK": "#5fcf8a", "WARN": "#e8c468", "ERR": "#e87a7a",
    },
    "Ocean": {
        "BG": "#0f1419", "PANEL": "#161b22", "SURF": "#21262d", "HOVER": "#2d333b",
        "TEXT": "#e6edf3", "DIM": "#8b949e", "FAINT": "#545d68",
        "ACCENT": "#58a6ff", "OK": "#5fcf8a", "WARN": "#e8c468", "ERR": "#ff8a80",
    },
    "Forest": {
        "BG": "#11150f", "PANEL": "#181d15", "SURF": "#22281e", "HOVER": "#2e3528",
        "TEXT": "#e7ebe2", "DIM": "#9aa68f", "FAINT": "#5c6650",
        "ACCENT": "#7bc96f", "OK": "#5fcf8a", "WARN": "#e8c468", "ERR": "#e87a7a",
    },
    "Paper": {   # 라이트
        "BG": "#ececef", "PANEL": "#f7f7f9", "SURF": "#ffffff", "HOVER": "#e4e4ea",
        "TEXT": "#26262d", "DIM": "#6a6a78", "FAINT": "#9a9aa6",
        "ACCENT": "#3b6fd4", "OK": "#2f9e57", "WARN": "#b8860b", "ERR": "#cc3b5d",
    },
}

DEFAULT_THEME = "Graphite"


def get_theme(name):
    return THEMES.get(name, THEMES[DEFAULT_THEME])
