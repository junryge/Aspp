# 파일 비서 (Gemma 4B / Vulkan)

망 없는 환경에서 쓰는 로컬 파일 보조 도구.
파일 찾기 / 경로 확인 / 요약 / 코드 작성·리뷰 / 작업 로그 / 폴더 실시간 감시.

## 설치 (한 번만)

1) llama-cpp-python Vulkan wheel (AMD iGPU 가속):
   pip install llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/vulkan

2) 폴더 감시용:
   pip install watchdog

3) GGUF 모델 (Gemma 4 4B) 받아서 아무 데나 두기.

## 실행

   python main.py

- 첫 실행 시 CWD에 config.json 생성됨.
- ⚙설정에서 GGUF 모델 경로 / 감시 폴더 / 색상 테마 지정 → 저장.
- 콘솔(cmd)에서 실행하면 모델 로딩 로그에 Vulkan 잡혔는지 보임:
  "ggml_vulkan: Found 1 Vulkan devices: Vulkan0: AMD Radeon(TM) Graphics"

## 파일 구성

- main.py        : GUI 메인 (실행 진입점)
- config.py      : 설정 저장/로드 (config.json, CWD)
- llm_engine.py  : Gemma 로드 + 토큰 스트리밍 + think 제거 + 반복 폭주 방지
- file_tools.py  : 파일 목록/검색/읽기(utf-8→cp949→euc-kr 자동) + LLM 프롬프트 빌더
- watcher.py     : watchdog 폴더 감시 + JSONL 작업 로그
- themes.py      : 색상 테마 5종 (다크 블루/그린/퍼플, 블랙, 라이트)

## 사용법

- 왼쪽: 검색창에 키워드 → 파일명 검색. 파일 클릭 = 경로 표시, 더블클릭 = 요약.
- 오른쪽 채팅: 텍스트 붙여넣고 "요약해줘" / "코드 짜줘" / "이 코드 리뷰해줘".
- "오늘 뭐 했지?" "로그 보여줘" → 작업 로그를 읽어 정리해줌.
- 상단 "감시 ●" = 폴더 변경(생성/수정/삭제/이동)이 자동으로 work_log.jsonl에 기록 중.
- 모델/폴더/확장자/테마 변경: ⚙설정 → 저장 (재시작 불필요).

## 구조 (결과값을 LLM이 받아 처리)

검색·파일읽기·로그 = 파이썬이 수행 → 그 결과 텍스트를 LLM(Gemma 4B)에 주입 →
LLM은 받은 내용을 요약/정리해 한국어로 답변. (LLM이 직접 파일을 뒤지지 않음)
