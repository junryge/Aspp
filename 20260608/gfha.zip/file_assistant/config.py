# -*- coding: utf-8 -*-
"""config.py - 설정 저장/로드 (CWD의 config.json)"""
import os
import json

CONFIG_PATH = os.path.join(os.getcwd(), "config.json")

DEFAULTS = {
    "model_path": "./gemma-4-4b-it-Q4_K_M.gguf",   # GGUF 모델 경로
    "watch_dir": "C:\\work",                        # 감시/검색 폴더
    "log_dir": os.path.join(os.getcwd(), "worklogs"),  # 날짜별 로그 폴더
    "extensions": [".py", ".md", ".txt", ".csv", ".json", ".log", ".js", ".html"],
    "recursive": True,                              # 하위폴더 포함
    "n_ctx": 8192,
    "n_gpu_layers": -1,                             # -1 = 전부 GPU(Vulkan)
    "temperature": 0.4,
    "max_tokens": 1024,
    "theme": "Graphite",                            # 색상 테마
}


def load_config():
    """config.json 로드. 없으면 기본값으로 생성."""
    cfg = dict(DEFAULTS)
    if os.path.isfile(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, encoding="utf-8") as f:
                saved = json.load(f)
            cfg.update({k: v for k, v in saved.items() if k in DEFAULTS})
        except Exception:
            pass
    else:
        save_config(cfg)
    return cfg


def save_config(cfg):
    """config.json 저장."""
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False
