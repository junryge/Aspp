[데모스 API 모델 변경 — 사용 가능 5종으로 통일]
브랜치: claude/practical-carson-WKG6M (커밋 f36ecdf + 0b106ba)
※ 경로 그대로 레포 루트에 덮어쓰기 후 서버 재시작.

★★ 가장 중요 ★★
실제 런타임이 로드하는 설정은 scientific-assistant/api_config.json 이다.
(demos BASE_DIR = scientific-assistant/ = demos_v1 의 상위폴더)
이 파일이 있으면 demos_v1/models.py 의 기본값은 무시된다.
→ 따라서 api_config.json 을 반드시 덮어써야 실제 적용됨.

== 사용 가능 5종 (전부 http://common.llm.skhynix.com/v1/chat/completions) ==
  Qwen3.6-35B-A3B          일반/코드 플래그십  env_id=dev
  Qwen2.5-VL-72B-Instruct  비전 대형           env_id=vl-72b
  Qwen3-VL-30B-A3B         비전 경량           env_id=vl-fast
  gemma-4-31B-it           일반                env_id=gemma
  gpt-oss-20b              경량/빠름           env_id=common
  (폐기: GLM-5 / Coder-480B / Coder-Next / Next-80B / Coder-30B / dev.hcp)

== 포함 파일 ==
  scientific-assistant/api_config.json                      ← ★실제 로드되는 설정(핵심)
     - models / api_model_tiers / fallback_chains 전면 교체 + default_model_priority
  scientific-assistant/demos_v1/models.py                   ← 기본값(폴백) 5종 교체
  scientific-assistant/demos_v1/routes_chat.py              ← 합성 기본 모델 qwen36-35b
  scientific-assistant/demos_v1/logpresso.py                ← 기본 텍스트 모델 qwen36-35b
  scientific-assistant/demos_v1/router.py                   ← 자동 라우팅 표시 문구 정정
  scientific-assistant/demos_v1/routes_api.py               ← 예시 주석 정정
  scientific-assistant/demos_v1/templates/index.html        ← 모델 티어 분류(아이콘/고성능 그룹) UI

※ 모델 드롭다운은 /api/config(ENV_CONFIG)에서 자동 생성됨.
※ 개인에이전트 창은 코드 변경 없이 /api/config 자동 수신.
