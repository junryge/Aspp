#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HID_문제맵.py — 로그프레소에서 그 시각을 판정해 "문제맵"(HTML 지도) 만들기

  FAB · 시각만 주면 로그프레소에서 차량 보고를 받아 HID_병목구간.py 와 **같은 쿼리 · 같은 판정**으로
  그 1분(ALARM · 병목 HID 구역 1~3위 · missing · JAM · HT_STOP · ZONE_STOP …)을 구하고,
  월드모델파생 맵(OHT_MAP 레이아웃 + HID_Zone_Master) 위에 그린다 — 그 시각 어디가 막혔나.
    · 왼쪽 위 ALARM 칸   = 경계 / 위험 / 초위험 / 정상
    · 1위 구역(HID_ZONE) = ALARM 색, 2 · 3위 구역 = 파랑
    · OHT 차량            = 그 시각 위치 (운행 · JAM · HT_STOP · 미보고는 끊기기 직전 위치)
    · 오른쪽              = 그 1분 숫자 · 판정 근거
  결과 CSV 는 필요 없다. 시각 하나 = HTML 파일 하나 (브라우저로 열면 됨, 인터넷 · 서버 필요 없음).

  필요한 것 (같은 폴더)
    HID_병목구간.py      서버 · 쿼리 · 판정 · 주소 → HID 구역을 그대로 가져다 쓴다
    hdi_api_key.txt      로그프레소 키 (HID_병목구간.py 와 같은 것)
    HID_CONFIG.json      경계 · 위험 · 초위험 기준 (HID_병목구간.py 와 같은 것)
    OHT_MAP/             월드모델파생의 OHT_MAP 폴더 그대로

  실행
    python HID_문제맵.py M16HUB                              지금 (방금 끝난 1분)
    python HID_문제맵.py M16HUB 202609031348                 그 1분 (YYYYMMDDHHMM)
    python HID_문제맵.py M16HUB 202609031348 202609290813    여러 시각 — 시각마다 파일 하나
    python HID_문제맵.py M16HUB 20260929                     그 날 하루를 판정해서 알람 난 분마다 파일 하나
      → HID_병목/문제맵/{FAB}_{YYYYMMDD}/문제맵_{FAB}_{YYYYMMDD}_{HHMM}_{ALARM}.html
  판정은 그 시각 앞 100분(FLEET_AUTO_MIN)부터 받아서 한다 — 미보고(전체 차량) 셈이 HID_병목구간.py 와 같게.
"""
import argparse
import csv
import io
import json
import re
import sys
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import HID_병목구간 as HB                           # noqa: E402  (서버 · 쿼리 · 판정 · 맵을 그대로 쓴다)

LEVEL = {"경계": 1, "위험": 2, "초위험": 3}
RANK = {None: 0, "경계": 1, "위험": 2, "초위험": 3}
MAP_OUT = HB.OUT_DIR / "문제맵"
STEP = timedelta(seconds=HB.BUCKET_SEC)


def say(msg):
    print(msg, flush=True)


# ==========================================================
# 월드모델파생 맵 → 지도 그림 재료
# ==========================================================
def load_map(fab):
    """HID_병목구간.py 와 똑같이 주소 → 구역을 만들고, HID_병목구간.py 와 같은 HID_ZONE 번호를 붙인다."""
    cfg = HB.FABS[fab]
    st = HB.FabState(fab, cfg)
    if not st.ok:
        return None, st.map_msg
    states = {fab: st}
    if fab != "M16HUB":                              # 번호 칸(ZONE_ID/ZONE_ID2)은 M16HUB 참조표로 정해진다
        hub = HB.FabState("M16HUB", HB.FABS["M16HUB"])
        if hub.ok:
            states["M16HUB"] = hub
    HB.resolve_hid_zone(states)
    _, layout = HB._find_map_files(*cfg["map"])
    L = json.loads(Path(layout).read_text(encoding="utf-8"))
    return {"st": st, "layout": L, "layout_file": Path(layout).name, "msg": st.map_msg}, ""


def zone_number(st, z, use):
    if use == "ZONE_ID2":
        return str(st.info.get(z, ("", "", "", 0))[2] or 0)
    return str(z or 0)



def geometry(m, use):
    st, L = m["st"], m["layout"]
    nodes = L.get("nodes", {})
    num = {z: zone_number(st, z, use) for z in st.info}
    ids, xs, ys, index = [], [], [], {}

    def idx(a):
        a = str(a)
        if a not in index and a in nodes:
            index[a] = len(ids)
            ids.append(a)
            xs.append(round(float(nodes[a][0]), 1))
            ys.append(round(float(nodes[a][1]), 1))
        return index.get(a)

    zlist = sorted({n for n in num.values() if n != "0"}, key=lambda s: (len(s), s))
    zi = {n: i for i, n in enumerate(zlist)}
    edges = []
    for k in L.get("edges", {}):
        a, _, b = str(k).partition(",")
        ia, ib = idx(a), idx(b)
        if ia is None or ib is None:
            continue
        za, zb = st.zone_of.get(a), st.zone_of.get(b)
        z = num.get(za) if za is not None and za == zb else None
        edges += [ia, ib, zi.get(z, -1) if z else -1]
    # 구역 정보 · 가운데 점 (라벨 · 클릭)
    acc = {n: [0.0, 0.0, 0, 1e18, 1e18, -1e18, -1e18] for n in zlist}
    for a, z in st.zone_of.items():
        n = num.get(z)
        if n in acc and str(a) in nodes:
            x, y = float(nodes[str(a)][0]), float(nodes[str(a)][1])
            c = acc[n]
            c[0] += x
            c[1] += y
            c[2] += 1
            c[3], c[4], c[5], c[6] = min(c[3], x), min(c[4], y), max(c[5], x), max(c[6], y)
    meta = {}
    for z, (name, bay, _, vmax) in st.info.items():
        n = num[z]
        if n != "0" and n not in meta:
            meta[n] = (name, bay, vmax)
    zones = []
    for n in zlist:
        sx, sy, c, x0, y0, x1, y1 = acc[n]
        name, bay, vmax = meta.get(n, ("", "", 0))
        zones.append({"id": n, "name": name, "bay": bay, "vmax": vmax, "n": c,
                      "cx": round(sx / c, 1) if c else None, "cy": round(sy / c, 1) if c else None,
                      "box": [round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1)] if c else None})
    m["_ids"] = ids
    return {"x": xs, "y": ys, "e": edges, "zones": zones}



# ==========================================================
# 로그프레소에서 판정 — HID_병목구간.py 와 같은 쿼리 · 같은 판정 · 같은 1분 줄
# ==========================================================
def _parse(body, seen):
    """조회 결과 → seen[구간][차량] = (상태들, 주소)"""
    for x in csv.DictReader(io.StringIO(body.decode("utf-8-sig", "replace"))):
        v, tt = (x.get("VEHICLE") or "").strip(), HB.parse_time(x.get("_time"))
        if v and tt:
            sts = {(x.get("STATUS") or "").strip(), (x.get("STATUS_LAST") or "").strip()}
            seen[HB.bucket_floor(tt)][v] = (sts, (x.get("ADDRESS") or "").strip())


def _vehicles(seen, b):
    """구간 b 의 차량 → [[차량, 상태(0 운행 · 1 JAM · 2 HT · 3 미보고), 주소]]
       미보고 = 그 구간에 보고 없고, 최근 30분(IDLE_MIN) 안에 보였고, 구간 2개 이상에서 보인 차 (HID_병목구간.py 와 같은 조건)"""
    rep = seen.get(b, {})
    last, cnt = {}, defaultdict(int)
    for k in sorted(seen):
        if k > b:
            break
        for v, (_, a) in seen[k].items():
            last[v] = (k, a)
            cnt[v] += 1
    out = [[v, 1 if "7" in sts else 2 if "8" in sts else 0, a] for v, (sts, a) in rep.items()]
    idle = b - timedelta(minutes=HB.IDLE_MIN)
    out += [[v, 3, a] for v, (lb, a) in last.items() if v not in rep and lb >= idle and cnt[v] >= HB.FLEET_MIN_SEEN]
    return out


def _best_bucket(st, mm):
    """HID_병목구간.py minute_row 가 고르는 구간 (그 분 안에 끝난 구간 중 가장 높은 단계, 같으면 나중)"""
    best, level = None, None
    for k in st.buckets_of_minute(mm) or [st.bucket_of_minute(mm)]:
        lv, _ = st.alarm(k)
        if best is None or RANK[lv] >= RANK[level]:
            best, level = k, lv
    return best


def _row_dict(row):
    g = lambda i: str(row[i])
    return {"t": f"{row[0]} {row[1]}", "alarm": row[7], "z1": g(2), "z2": g(13), "z3": g(14), "sect": g(8),
            "n": row[3], "miss": row[4], "jam": row[5], "ht": row[6],
            "zstop": row[9], "zvhl": row[10], "vmax": row[11], "occ": row[12]}


def judge(m, frm, to, keep=lambda r: True):
    """frm ~ to(미포함) 의 1분들을 로그프레소에서 받아 판정 → [(줄, 차량, 구간)] (keep 이 참인 줄만)"""
    st = m["st"]
    st.buckets.clear(); st.last.clear(); st.first.clear(); st.nseen.clear()
    cur = HB.bucket_floor(frm - timedelta(minutes=HB.FLEET_AUTO_MIN))
    end = HB.bucket_floor(to) + STEP
    mins, mm = [], frm
    while mm < to:
        mins.append(mm)
        mm += timedelta(minutes=1)
    seen, out = defaultdict(dict), []
    while cur < end:
        nxt = min(HB.bucket_floor(cur + timedelta(minutes=HB.RANGE_CHUNK_MIN)), end)
        if nxt <= cur:
            nxt = cur + STEP
        body = st.fetch(cur, nxt, HB.RANGE_TIMEOUT)
        _parse(body, seen)
        st.ingest(body, cur, nxt)
        while mins and mins[0] + timedelta(seconds=60) <= nxt:
            mm = mins.pop(0)
            row, _ = st.minute_row(mm)
            r = _row_dict(row)
            if keep(r):
                b = _best_bucket(st, mm)
                out.append((r, _vehicles(seen, b) if b in seen else [], b))
        old = nxt - timedelta(minutes=HB.IDLE_MIN + 10)
        for k in [k for k in seen if k < old]:
            del seen[k]
        cur = nxt
    return out


def place(m, vs, r, b):
    """차량 주소 → 지도 노드. → (차량 목록, 설명)"""
    if b is None or not vs:
        return [], f"{r['t']} 구간 차량 보고 없음"
    idx = {a: i for i, a in enumerate(m["_ids"])}
    out, nopos = [], 0
    for v, c, a in vs:
        i = idx.get(str(a))
        if i is None:
            nopos += 1
            continue
        out.append([v, c, i, a])
    cnt = [sum(1 for x in vs if x[1] == c) for c in range(4)]
    return out, (f"{b:%H:%M:%S} 구간 · 운행 {cnt[0]} · JAM {cnt[1]} · HT_STOP {cnt[2]} · 미보고 {cnt[3]}"
                 + (f" · 맵에 없는 주소 {nopos}대" if nopos else ""))


# ==========================================================
# 판정 근거 — HID_CONFIG.json 기준 (판정에 쓴 그 기준)
# ==========================================================
def reasons(r, P):
    """그 줄 숫자가 어느 조건에 걸렸나 (높은 단계부터)"""
    out = []
    for lv in ("초위험", "위험", "경계"):
        p = P[lv]
        if p["missing"] and p["JAM"] and r["miss"] >= p["missing"] and r["jam"] >= p["JAM"]:
            out.append(f"{lv}: missing {r['miss']} + JAM {r['jam']} 같이 (기준 {p['missing']} + {p['JAM']})")
        if p["missing_ONLY"] and r["miss"] >= p["missing_ONLY"]:
            out.append(f"{lv}: missing {r['miss']} 단독 (기준 {p['missing_ONLY']})")
        if p["HT_STOP"] and r["ht"] >= p["HT_STOP"]:
            out.append(f"{lv}: HT_STOP {r['ht']} (기준 {p['HT_STOP']})")
        if p.get("ZONE_STOP") and r["zstop"] >= p["ZONE_STOP"]:
            out.append(f"{lv}: 구역 멈춘 차 {r['zstop']} (기준 {p['ZONE_STOP']})")
    return out


# ==========================================================
# HTML — 판정된 시간 한 줄 = 지도 하나
# ==========================================================
def build_html(fab, r, geo, info, why, oht=None, oht_desc=""):
    data = {"fab": fab, "info": info, "geo": geo, "why": why, "oht": oht, "ohtd": oht_desc,
            "r": {**r, "lv": LEVEL.get(r["alarm"], 0)}}
    js = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    title = f"HID 문제맵 · {fab} · {r['t']} · {r['alarm']}"
    return HTML.replace("__TITLE__", title).replace("__DATA__", js)


HTML = r"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title>
<style>
:root{--bg:#f6f7f9;--panel:#fff;--fg:#1d2330;--fg2:#5b6474;--line:#e3e6eb;--rail:#6f7889;--zone:#3c4556;
--l0:#3f9b5f;--l1:#e0a12e;--l2:#e2533a;--l3:#8f1d4f;--sub:#3b82c4;--chip:#eef1f5;
--v0:#1f9e89;--v1:#e8202a;--v2:#7b2cbf;--v3:#111827;--ring:#fff}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#11151c;--panel:#171c25;--fg:#e6e9ef;--fg2:#9aa3b2;
--line:#2a3140;--rail:#7a8497;--zone:#b3bccb;--l0:#5cc283;--l1:#f0b545;--l2:#ff6b52;--l3:#e0508f;--sub:#5aa7ef;--chip:#222a36;
--v0:#35c2ab;--v1:#ff4d55;--v2:#b67cff;--v3:#f3f4f6;--ring:#11151c}}
:root[data-theme="dark"]{--bg:#11151c;--panel:#171c25;--fg:#e6e9ef;--fg2:#9aa3b2;--line:#2a3140;--rail:#7a8497;--zone:#b3bccb;
--l0:#5cc283;--l1:#f0b545;--l2:#ff6b52;--l3:#e0508f;--sub:#5aa7ef;--chip:#222a36;
--v0:#35c2ab;--v1:#ff4d55;--v2:#b67cff;--v3:#f3f4f6;--ring:#11151c}
*{box-sizing:border-box}html,body{margin:0;height:100%}
body{background:var(--bg);color:var(--fg);font:13px/1.5 "Malgun Gothic","Apple SD Gothic Neo",system-ui,sans-serif;display:flex;flex-direction:column}
header{padding:10px 16px;border-bottom:1px solid var(--line);background:var(--panel);display:flex;flex-wrap:wrap;gap:6px 14px;align-items:center}
header h1{font-size:17px;margin:0}header .m{color:var(--fg2);font-size:12px}
.b{display:inline-block;border-radius:5px;padding:1px 10px;color:#fff;font-weight:700;font-size:14px}
.b0{background:var(--l0)}.b1{background:var(--l1);color:#222}.b2{background:var(--l2)}.b3{background:var(--l3)}
main{flex:1;display:flex;min-height:0}
#mapbox{flex:1;position:relative;min-width:0;min-height:320px}
canvas{display:block;width:100%;height:100%;cursor:grab}canvas.drag{cursor:grabbing}
#side{width:360px;max-width:100%;border-left:1px solid var(--line);background:var(--panel);overflow:auto;padding:12px 14px}
h2{font-size:13px;margin:14px 0 6px;color:var(--fg2);font-weight:600}h2:first-child{margin-top:0}
.zone{border:1px solid var(--line);border-radius:8px;padding:8px 10px;margin-bottom:8px;cursor:pointer}
.zone .t{font-weight:700;font-size:15px}.zone .s{color:var(--fg2);font-size:12px}
.zone.r1{border-left:6px solid var(--lv)}.zone.r2,.zone.r3{border-left:6px solid var(--sub)}
table{border-collapse:collapse;width:100%;font-size:12.5px}td{padding:4px 6px;border-bottom:1px solid var(--line)}td:first-child{color:var(--fg2)}td:last-child{text-align:right;font-weight:600}
ul{margin:4px 0;padding-left:18px}li{margin:2px 0}
.legend{position:absolute;left:10px;bottom:10px;background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:6px 8px;font-size:11.5px;color:var(--fg2)}
#abox{position:absolute;left:10px;top:10px;background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:8px 12px;box-shadow:0 2px 10px #0002}
#abox .lv{display:inline-block;font-size:22px;font-weight:800;border-radius:8px;padding:2px 14px;color:#fff}
#abox .lv.l0{background:var(--l0)}#abox .lv.l1{background:var(--l1);color:#222}#abox .lv.l2{background:var(--l2)}#abox .lv.l3{background:var(--l3)}
#abox .z{font-size:13px;font-weight:700;margin-top:4px}#abox .s{font-size:11.5px;color:var(--fg2)}
#abox .steps{display:flex;gap:3px;margin-top:6px}#abox .steps span{flex:1;font-size:10.5px;text-align:center;border-radius:4px;padding:1px 4px;color:#fff;opacity:.3}
#abox .steps span.on{opacity:1;outline:2px solid var(--fg);outline-offset:1px}
.legend i.d{width:9px;height:9px;border-radius:50%;margin-left:8px}
.legend i{display:inline-block;width:18px;height:5px;border-radius:2px;margin:0 4px 2px 8px;vertical-align:middle}
.tools{position:absolute;right:10px;top:10px;display:flex;gap:6px}.tools button{border:1px solid var(--line);background:var(--panel);color:var(--fg);border-radius:6px;padding:4px 9px;font:inherit;font-size:12px;cursor:pointer}
#tip{position:absolute;pointer-events:none;background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:5px 7px;font-size:12px;display:none;box-shadow:0 2px 8px #0003}
.warn{color:var(--l2);font-size:12px}.note{color:var(--fg2);font-size:11.5px}
@media (max-width:820px){main{flex-direction:column}#side{width:100%;border-left:0;border-top:1px solid var(--line);flex:none}#mapbox{height:60vh;flex:none}}
</style></head><body>
<header><h1 id="h1"></h1><span id="hb"></span><span class="m" id="hm"></span></header>
<main>
 <div id="mapbox"><canvas id="cv"></canvas>
  <div class="tools"><button id="bt-z">◎ 문제 구역</button><button id="bt-all">⤢ 전체</button></div>
  <div id="abox"></div><div class="legend" id="lg"></div><div id="tip"></div></div>
 <aside id="side"></aside>
</main>
<script>
const D=__DATA__, R=D.r, G=D.geo, Z=G.zones, ZI={}; Z.forEach((z,i)=>ZI[z.id]=i);
const LV=['정상','경계','위험','초위험'];
const css=n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const $=id=>document.getElementById(id);
const TOP=[[R.z1,1],[R.z2,2],[R.z3,3]].filter(([z])=>z&&z!=='0');
$('h1').textContent=`HID 문제맵 · ${D.fab} · ${R.t}`;
$('hb').innerHTML=`<span class="b b${R.lv}">${R.alarm}</span>`;
$('hm').textContent=`맵 ${D.info.layout} · ${D.info.src}`;
document.documentElement.style.setProperty('--lv',css('--l'+R.lv));
{const z1=Z[ZI[R.z1]];$('abox').innerHTML=`<span class="lv l${R.lv}">${R.alarm}</span>`+
 (R.z1&&R.z1!=='0'?`<div class="z">1위 HID ${R.z1}${z1&&z1.bay?' · '+z1.bay:''}</div><div class="s">구역 멈춘 차 ${R.zstop} · missing ${R.miss} · JAM ${R.jam} · HT ${R.ht}</div>`:'')+
 `<div class="steps">${[1,2,3].map(l=>`<span class="${l===R.lv?'on':''}" style="background:${css('--l'+l)};${l===1?'color:#222':''}">${LV[l]}</span>`).join('')}</div>`;}
// ---------- 좌표 ----------
let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity;
for(let i=0;i<G.x.length;i++){const x=G.x[i],y=G.y[i];if(x<minx)minx=x;if(x>maxx)maxx=x;if(y<miny)miny=y;if(y>maxy)maxy=y;}
const cv=$('cv'),ctx=cv.getContext('2d');let W=0,H=0,zoom=1,px=0,py=0,base=1;
function fit(){const r=cv.getBoundingClientRect(),d=devicePixelRatio||1;W=r.width;H=r.height;cv.width=W*d;cv.height=H*d;ctx.setTransform(d,0,0,d,0,0);
 base=Math.min((W-40)/Math.max(1,maxx-minx),(H-40)/Math.max(1,maxy-miny));}
const S=(x,y)=>{const s=base*zoom;return[20+(x-minx)*s+px,20+(y-miny)*s+py];};
const I=(sx,sy)=>{const s=base*zoom;return[(sx-20-px)/s+minx,(sy-20-py)/s+miny];};
function view(x0,y0,x1,y1){const w=Math.max(1,x1-x0),h=Math.max(1,y1-y0);zoom=Math.max(.5,Math.min(80,Math.min((W-80)/w,(H-80)/h)/base));
 const s=base*zoom;px=W/2-20-((x0+x1)/2-minx)*s;py=H/2-20-((y0+y1)/2-miny)*s;draw();}
const home=()=>view(minx,miny,maxx,maxy);
function focusTop(){const bs=TOP.map(([z])=>Z[ZI[z]]).filter(z=>z&&z.box);if(!bs.length)return home();
 const x0=Math.min(...bs.map(z=>z.box[0])),y0=Math.min(...bs.map(z=>z.box[1])),x1=Math.max(...bs.map(z=>z.box[2])),y1=Math.max(...bs.map(z=>z.box[3]));
 const pad=Math.max(x1-x0,y1-y0)*.35+50;view(x0-pad,y0-pad,x1+pad,y1+pad);}
function focusZone(id){const z=Z[ZI[id]];if(!z||!z.box)return;const pad=Math.max(z.box[2]-z.box[0],z.box[3]-z.box[1])*.6+50;view(z.box[0]-pad,z.box[1]-pad,z.box[2]+pad,z.box[3]+pad);}
// ---------- 그리기 ----------
function lines(test,col,w){ctx.strokeStyle=col;ctx.lineWidth=w;ctx.beginPath();
 for(let i=0;i<G.e.length;i+=3){if(!test(G.e[i+2]))continue;const a=S(G.x[G.e[i]],G.y[G.e[i]]),b=S(G.x[G.e[i+1]],G.y[G.e[i+1]]);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);}ctx.stroke();}
function draw(){ctx.clearRect(0,0,W,H);ctx.lineCap='round';
 const lw=Math.max(1.3,Math.min(3.2,1.1+zoom*.18)),hot={};TOP.forEach(([z,r])=>{if(ZI[z]!=null&&!(ZI[z] in hot))hot[ZI[z]]=r;});
 lines(z=>z<0,css('--rail'),lw);lines(z=>z>=0&&!(z in hot),css('--zone'),lw);
 [3,2].forEach(r=>lines(z=>hot[z]===r,css('--sub'),Math.max(5,lw*3)));
 lines(z=>hot[z]===1,css('--l'+(R.lv||0)),Math.max(8,lw*4.5));
 // OHT 차량 — 운행(작게) 먼저, 멈춘 차는 위에
 if(D.oht){const rr=Math.max(2.2,Math.min(6,1.6+zoom*.35));
  for(const c of [0,3,2,1])for(const [v,cc,i] of D.oht){if(cc!==c)continue;const [x,y]=S(G.x[i],G.y[i]);if(x<-9||y<-9||x>W+9||y>H+9)continue;
   if(c===3){ctx.strokeStyle=css('--v3');ctx.lineWidth=2;const q=rr*1.1;ctx.beginPath();ctx.moveTo(x-q,y-q);ctx.lineTo(x+q,y+q);ctx.moveTo(x+q,y-q);ctx.lineTo(x-q,y+q);ctx.stroke();continue;}
   ctx.beginPath();ctx.arc(x,y,c?rr*1.25:rr*.85,0,7);ctx.fillStyle=css('--v'+c);ctx.fill();if(c){ctx.lineWidth=1.5;ctx.strokeStyle=css('--ring');ctx.stroke();}}}
 // 라벨: 1위 · 2위 · 3위 먼저, 겹치면 뒤를 뺀다. 나머지 구역 번호는 확대하면
 ctx.textAlign='center';ctx.textBaseline='middle';const placed=[];
 const L=[...TOP.map(([z,r])=>[z,r]),...(zoom>=2.5?Z.map(z=>[z.id,9]):[])];const done={};
 for(const [id,r] of L){if(done[id])continue;done[id]=1;const z=Z[ZI[id]];if(!z||z.cx==null)continue;let [x,y]=S(z.cx,z.cy);if(x<-30||y<-30||x>W+30||y>H+30)continue;
  const big=r<=3,t=big?`${r}위 HID ${id}${z.bay?' · '+z.bay:''}${r===1&&R.lv?' · '+R.alarm:''}`:id;ctx.font=big?'700 12.5px system-ui,sans-serif':'600 10.5px system-ui,sans-serif';
  const w=ctx.measureText(t).width+10;x=Math.max(w/2+2,Math.min(W-w/2-2,x));if(big)y-=16;
  const hit=yy=>placed.some(p=>Math.abs(p[0]-x)<(p[2]+w)/2&&Math.abs(p[1]-yy)<20);
  if(hit(y)){if(!big)continue;const alt=[y+24,y-24,y+48,y-48].find(yy=>!hit(yy));if(alt==null)continue;y=alt;}  // 1·2·3위는 비켜서라도 보인다
  placed.push([x,y,w]);
  if(big){ctx.fillStyle=r===1?css('--l'+(R.lv||0)):css('--sub');ctx.fillRect(x-w/2,y-10,w,20);ctx.fillStyle=(r===1&&R.lv===1)?'#222':'#fff';}
  else ctx.fillStyle=css('--fg2');
  ctx.fillText(t,x,y);}
 const oc=D.oht?[0,1,2,3].map(c=>D.oht.filter(x=>x[1]===c).length):null;
 $('lg').innerHTML=`<b>${R.t}</b> 1위 구역 색:<i style="background:${css('--l1')}"></i>경계<i style="background:${css('--l2')}"></i>위험<i style="background:${css('--l3')}"></i>초위험`+
 `<i style="background:${css('--sub')}"></i>2·3위<i style="background:${css('--zone')}"></i>다른 HID 구역`+
 (oc?`<br>OHT:<i class="d" style="background:${css('--v0')}"></i>운행 ${oc[0]}<i class="d" style="background:${css('--v1')}"></i>JAM ${oc[1]}<i class="d" style="background:${css('--v2')}"></i>HT_STOP ${oc[2]}<b style="margin-left:8px;color:${css('--v3')}">✕</b> 미보고 ${oc[3]}`:`<br>OHT 차량 없음 — ${D.ohtd}`);}
// ---------- 조작 ----------
let drag=null;
cv.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,px,py};cv.setPointerCapture(e.pointerId);cv.classList.add('drag');});
cv.addEventListener('pointermove',e=>{if(drag){px=drag.px+e.clientX-drag.x;py=drag.py+e.clientY-drag.y;draw();}else hover(e);});
cv.addEventListener('pointerup',()=>{drag=null;cv.classList.remove('drag');});
cv.addEventListener('wheel',e=>{e.preventDefault();const r=cv.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top,[wx,wy]=I(mx,my);
 zoom=Math.max(.5,Math.min(80,zoom*(e.deltaY<0?1.2:1/1.2)));const [sx,sy]=S(wx,wy);px+=mx-sx;py+=my-sy;draw();},{passive:false});
cv.addEventListener('dblclick',home);
function seg(x,y,a,b){const dx=b[0]-a[0],dy=b[1]-a[1],l=dx*dx+dy*dy;let t=l?((x-a[0])*dx+(y-a[1])*dy)/l:0;t=Math.max(0,Math.min(1,t));const qx=a[0]+t*dx-x,qy=a[1]+t*dy-y;return qx*qx+qy*qy;}
const ZOF={};for(let i=0;i<G.e.length;i+=3){if(G.e[i+2]>=0){ZOF[G.e[i]]=G.e[i+2];ZOF[G.e[i+1]]=G.e[i+2];}}
const VC=['운행','JAM','HT_STOP','미보고 (끊기기 직전 위치)'];
function hover(e){const r=cv.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;let best=-1,bd=12*12;
 if(D.oht){let vb=null,vd=8*8;for(const o of D.oht){const [x,y]=S(G.x[o[2]],G.y[o[2]]);const d=(x-mx)**2+(y-my)**2;if(d<vd){vd=d;vb=o;}}
  if(vb){const tp=$('tip'),z=ZOF[vb[2]];tp.innerHTML=`<b>OHT ${vb[0]}</b> · ${VC[vb[1]]}<br>주소 ${vb[3]}${z!=null?` · HID ${Z[z].id}${Z[z].bay?' · '+Z[z].bay:''}`:''}`;
   tp.style.display='block';tp.style.left=Math.min(mx+12,W-240)+'px';tp.style.top=(my+12)+'px';return;}}
 for(let i=0;i<G.e.length;i+=3){const z=G.e[i+2];if(z<0)continue;const d=seg(mx,my,S(G.x[G.e[i]],G.y[G.e[i]]),S(G.x[G.e[i+1]],G.y[G.e[i+1]]));if(d<bd){bd=d;best=z;}}
 const tp=$('tip');if(best<0){tp.style.display='none';return;}const z=Z[best],rk=TOP.find(([id])=>id===z.id);
 tp.innerHTML=`<b>HID ${z.id}</b> ${z.name||''}${z.bay?' · '+z.bay:''}${rk?` — <b>${rk[1]}위</b>`:''}${z.vmax?`<br>정원(Vehicle_Max) ${z.vmax}`:''}`;
 tp.style.display='block';tp.style.left=Math.min(mx+12,W-240)+'px';tp.style.top=(my+12)+'px';}
$('bt-all').onclick=home;$('bt-z').onclick=focusTop;
// ---------- 오른쪽 ----------
const zname=id=>{const z=Z[ZI[id]];return z?`${z.name||''}${z.bay?' · '+z.bay:''}`:'⚠ 지도에 없는 구역';};
let h=`<h2>문제 구역 (그 1분)</h2>`;
if(!TOP.length)h+=`<div class="note">${R.lv?'구역 정보 없음':'정상 — 문제 구역 없음'}</div>`;
TOP.forEach(([id,r])=>{h+=`<div class="zone r${r}" data-z="${id}"><div class="t">${r}위 · HID ${id}</div><div class="s">${zname(id)}</div>`+
 (r===1?`<div class="s">구역 안 멈춘 차 <b>${R.zstop}</b> · 구역 안 차량 <b>${R.zvhl}</b> / 정원 ${R.vmax} · 점유율 <b>${R.occ}%</b></div>`:'')+`</div>`;});
h+=`<h2>그 1분 숫자</h2><table>
<tr><td>날짜 · 시간</td><td>${R.t}</td></tr><tr><td>ALARM</td><td>${R.alarm}</td></tr>
<tr><td>HID_ZONE · section</td><td>${R.z1} · ${R.sect}</td></tr>
<tr><td>OHT_report (보고 차량)</td><td>${R.n}</td></tr><tr><td>OHT_missing (미보고)</td><td>${R.miss}</td></tr>
<tr><td>OHT_JAM</td><td>${R.jam}</td></tr><tr><td>OHT_HT_STOP</td><td>${R.ht}</td></tr>
<tr><td>ZONE_STOP (구역 멈춘 차)</td><td>${R.zstop}</td></tr><tr><td>ZONE_VHL / VHL_MAX</td><td>${R.zvhl} / ${R.vmax}</td></tr>
<tr><td>ZONE_OCC (점유율)</td><td>${R.occ}%</td></tr><tr><td>HID_ZONE_2 · 3</td><td>${R.z2} · ${R.z3}</td></tr></table>`;
h+=`<h2>판정 근거 (HID_CONFIG.json 기준)</h2>`+(D.why.length?`<ul>${D.why.map(w=>`<li>${w}</li>`).join('')}</ul>`:`<div class="note">걸린 조건 없음 — 정상</div>`);
if(D.info.diff)h+=`<div class="warn">⚠ ${D.info.diff} — HID_Zone_Master 를 확인하세요.</div>`;
if(D.info.miss.length)h+=`<div class="warn">⚠ 지도에 없는 구역: ${D.info.miss.join(', ')} — HID_Zone_Master 를 확인하세요.</div>`;
h+=`<h2>OHT 차량</h2><div class="note">${D.ohtd}</div>`;
h+=`<h2>맵</h2><div class="note">${D.info.layout} · 구역 번호 ${D.info.use}<br>${D.info.msg}<br>휠 확대 · 드래그 이동 · 더블클릭 전체 · 구역에 마우스를 올리면 이름</div>`;
$('side').innerHTML=h;
document.querySelectorAll('.zone[data-z]').forEach(el=>el.onclick=()=>focusZone(el.dataset.z));
addEventListener('resize',()=>{fit();home();});fit();home();
</script></body></html>
"""


# ==========================================================
def main():
    ap = argparse.ArgumentParser(description="로그프레소에서 그 시각을 판정 → 문제맵(HTML)")
    ap.add_argument("fab", help=f"FAB ({' '.join(HB.FABS)})")
    ap.add_argument("when", nargs="*",
                    help="YYYYMMDDHHMM (그 1분, 여러 개 가능) 또는 YYYYMMDD (그 날 알람 난 분 전부). 없으면 지금")
    ap.add_argument("--out", help="저장할 폴더 (기본 HID_병목/문제맵)")
    a = ap.parse_args()

    fab = a.fab.upper()
    if fab not in HB.FABS:
        sys.exit(f"FAB 은 {' '.join(HB.FABS)} 중 하나")
    whens = [w.replace("-", "").replace(":", "").replace(" ", "") for w in a.when]
    if any(not re.fullmatch(r"\d{8}|\d{12}", w) for w in whens):
        sys.exit("시간은 YYYYMMDDHHMM (그 1분) 또는 YYYYMMDD (그 날 알람 난 분 전부)")

    say(f"■ {fab} 문제맵 — 로그프레소에서 판정")
    HB.load_config(first=True)
    m, err = load_map(fab)
    if not m:
        sys.exit(f"맵 없음 — {err}")
    use = HB.HID_ZONE_USE
    geo = geometry(m, use)
    have = {z["id"] for z in geo["zones"] if z["n"]}
    zbay = {z["id"]: z["bay"] for z in geo["zones"]}
    P = HB.policy(fab)

    jobs = []                                        # (frm, to, keep, 설명)
    if not whens:
        now = datetime.now() - timedelta(seconds=HB.LAG_SEC + 60)
        t = now.replace(second=0, microsecond=0)
        jobs.append((t, t + timedelta(minutes=1), lambda r: True, f"지금 {t:%H:%M}"))
    for w in whens:
        if len(w) == 12:
            t = datetime.strptime(w, "%Y%m%d%H%M")
            jobs.append((t, t + timedelta(minutes=1), lambda r: True, f"{t:%Y-%m-%d %H:%M}"))
        else:
            d = datetime.strptime(w, "%Y%m%d")
            jobs.append((d, d + timedelta(days=1), lambda r: r["alarm"] in LEVEL, f"{d:%Y-%m-%d} 하루 (알람 난 분만)"))

    out_base = Path(a.out) if a.out else MAP_OUT
    made = []
    for frm, to, keep, label in jobs:
        say(f"  {label} 판정 중 … (앞 {HB.FLEET_AUTO_MIN}분부터 받음)")
        try:
            res = judge(m, frm, to, keep)
        except Exception as ex:
            say(f"  ★{label} 로그프레소 조회 실패 — {str(ex)[:200]}")
            continue
        if not res:
            say(f"  {label}: 만들 분 없음")
        for r, vs, b in res:
            miss = [z for z in (r["z1"], r["z2"], r["z3"]) if z not in ("", "0") and z not in have]
            bay = zbay.get(r["z1"], "")
            diff = (f"판정 HID_section {r['sect']} ≠ 지도의 {bay} (HID {r['z1']})"
                    if r["z1"] in zbay and r["sect"] not in ("", "0") and bay and r["sect"] != bay else "")
            info = {"layout": m["layout_file"], "msg": m["msg"], "use": use, "miss": miss, "diff": diff,
                    "src": f"로그프레소 {HB.FABS[fab]['table']} ({HB.SERVERS[HB.FABS[fab]['server']]['host']})"}
            oht, od = place(m, vs, r, b)
            day, hm = r["t"][:10].replace("-", ""), r["t"][11:].replace(":", "")
            d = out_base / f"{fab}_{day}"
            d.mkdir(parents=True, exist_ok=True)
            p = d / f"문제맵_{fab}_{day}_{hm}_{r['alarm']}.html"
            p.write_text(build_html(fab, r, geo, info, reasons(r, P), oht, od), encoding="utf-8")
            made.append(p)
            say(f"  {r['t']} {r['alarm']:3} 1위 HID {r['z1']} ({r['sect']}) · 2·3위 {r['z2']} · {r['z3']}"
                f" · missing {r['miss']} JAM {r['jam']} HT {r['ht']} · 구역 멈춘 차 {r['zstop']}"
                f"{'  ⚠지도에 없음 ' + ','.join(miss) if miss else ''}{'  ⚠' + diff if diff else ''}")
            say(f"    OHT {od}")
    say(f"  맵 {m['layout_file']} · 구역 번호 {use}")
    for d in sorted({x.parent for x in made}):
        say(f"  → {d}  ({sum(1 for x in made if x.parent == d)}개)")


if __name__ == "__main__":
    main()
