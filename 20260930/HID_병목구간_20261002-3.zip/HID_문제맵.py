#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HID_문제맵.py — HID_병목구간 결과로 "문제맵"(HTML 지도) 만들기

  월드모델파생 맵(OHT_MAP 의 레이아웃 + HID_Zone_Master) 위에
  HID_병목구간.py 가 저장한 결과(ALARM · HID_ZONE · HID_ZONE_2/3 · ZONE_STOP …)를 칠한다.
    · 누적   : 기간 동안 병목 1위로 나온 HID 구역을 많이 나온 순으로 진하게
    · 사건   : 알람 사건을 고르면 분마다 1위 구역(ALARM 색) · 2·3위 구역(옅은 색)을 지도에 표시
  HTML 파일 하나로 나온다 (인터넷 · 서버 필요 없음, 브라우저로 열면 됨).

  필요한 것 (같은 폴더)
    HID_병목구간.py                 주소 → HID 구역 계산을 그대로 가져다 쓴다 (번호가 결과 파일과 같게)
    OHT_MAP/                        월드모델파생의 OHT_MAP 폴더 그대로 (HID_병목구간.py 와 같은 것)
    HID_병목/과거판정/{FAB}/…csv    HID_병목구간.py 과거 판정 결과 (또는 --csv 로 파일 지정)

  실행
    python HID_문제맵.py M16HUB 20260901 20260930        과거 판정 결과 (FAB · 날짜 구간)
    python HID_문제맵.py M16HUB 20260929                 하루
    python HID_문제맵.py M16HUB                          있는 날짜 다
    python HID_문제맵.py M16HUB 20261002 --src 실시간    실시간 결과(HID_병목/{FAB}/) 로
    python HID_문제맵.py M16HUB --csv 합침_M16HUB_20260901_20260930.csv   파일 직접 (합치기 결과도 됨)
      → HID_병목/문제맵/문제맵_{FAB}_{시작}_{끝}.html      지도
      → HID_병목/문제맵/문제구역_{FAB}_{시작}_{끝}.csv     구역별 집계 (지도 오른쪽 표와 같음)
"""
import argparse
import csv
import glob
import io
import json
import re
import sys
from collections import Counter, OrderedDict
from datetime import datetime, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import HID_병목구간 as HB                           # noqa: E402  (맵 · 구역 번호 계산을 그대로 쓴다)

GAP_MIN = 1                 # 알람 사이가 이 분보다 벌어지면 다른 사건 (HID_병목_알람합치기.py 와 같음)
LEVEL = {"경계": 1, "위험": 2, "초위험": 3}
MAP_OUT = HB.OUT_DIR / "문제맵"


def say(msg):
    print(msg, flush=True)


# ==========================================================
# 결과 읽기
# ==========================================================
def _files(fab, src):
    base = (HB.PAST_DIR if src == "과거" else HB.OUT_DIR) / fab
    return sorted(glob.glob(str(base / f"HID병목_{fab}_*.csv")))


def _int(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def read_rows(fab, files, d0=None, d1=None):
    """결과 CSV → 분 행 목록. 날짜별 파일 · 합치기 파일(FAB · OHT_missing 칸) 다 받는다. 같은 분은 한 번만."""
    rows = OrderedDict()
    for p in files:
        try:
            text = Path(p).read_text(encoding="utf-8-sig")
        except UnicodeDecodeError:
            text = Path(p).read_text(encoding="cp949")
        rd = csv.DictReader(io.StringIO(text))
        cols = rd.fieldnames or []
        if "ALARM" not in cols or "날짜" not in cols:
            say(f"  건너뜀 (결과 파일 아님): {Path(p).name}")
            continue
        pre = f"{fab}_OHT_" if f"{fab}_OHT_missing" in cols else "OHT_"
        n = 0
        for r in rd:
            if "FAB" in cols and (r.get("FAB") or "").strip() != fab:
                continue
            day, hm = (r.get("날짜") or "").strip(), (r.get("시간") or "").strip()
            if not day or not hm:
                continue
            dk = day.replace("-", "")
            if (d0 and dk < d0) or (d1 and dk > d1):
                continue
            k = f"{day} {hm}"
            if k in rows:
                continue
            rows[k] = {
                "t": k, "alarm": (r.get("ALARM") or "정상").strip(),
                "z1": (r.get("HID_ZONE") or "0").strip(), "z2": (r.get("HID_ZONE_2") or "0").strip(),
                "z3": (r.get("HID_ZONE_3") or "0").strip(), "sect": (r.get("HID_section") or "0").strip(),
                "n": _int(r.get(pre + "report")), "miss": _int(r.get(pre + "missing")),
                "jam": _int(r.get(pre + "JAM")), "ht": _int(r.get(pre + "HT_STOP")),
                "zstop": _int(r.get("ZONE_STOP")), "zvhl": _int(r.get("ZONE_VHL")),
                "vmax": _int(r.get("VHL_MAX")), "occ": _int(r.get("ZONE_OCC")),
            }
            n += 1
        say(f"  {Path(p).name}: {n}분")
    return sorted(rows.values(), key=lambda r: r["t"])


# ==========================================================
# 월드모델파생 맵 → 지도 그림 재료
# ==========================================================
def load_map(fab):
    """HID_병목구간.py 와 똑같이 주소 → 구역을 만들고, 결과 파일과 같은 HID_ZONE 번호를 붙인다."""
    cfg = HB.FABS[fab]
    st = HB.FabState(fab, cfg)
    if not st.ok:
        return None, st.map_msg
    states = {fab: st}
    if fab != "M16HUB":                              # 번호 칸(ZONE_ID/ZONE_ID2)은 M16HUB 참조표로 정해진다
        hub = HB.FabState("M16HUB", HB.FABS["M16HUB"])
        if hub.ok:
            states["M16HUB"] = hub
    HB.resolve_hid_zone(states)
    _, layout = HB._find_map_files(*cfg["map"])
    L = json.loads(Path(layout).read_text(encoding="utf-8"))
    return {"st": st, "layout": L, "layout_file": Path(layout).name, "msg": st.map_msg}, ""


def zone_number(st, z, use):
    if use == "ZONE_ID2":
        return str(st.info.get(z, ("", "", "", 0))[2] or 0)
    return str(z or 0)


def pick_numbering(st, rows):
    """결과 파일의 HID_ZONE 값과 더 많이 맞는 칸 — 기본은 HID_병목구간.py 가 고른 칸."""
    vals = {r[k] for r in rows for k in ("z1", "z2", "z3") if r[k] not in ("", "0")}
    use = HB.HID_ZONE_USE
    if not vals:
        return use, 0, 0
    other = "ZONE_ID" if use == "ZONE_ID2" else "ZONE_ID2"
    has = lambda u: len(vals & {zone_number(st, z, u) for z in st.info})
    a, b = has(use), has(other)
    if b > a:
        say(f"  ★결과 파일 번호가 {other} 와 더 맞음 ({b} > {a}) — {other} 로 그림")
        return other, b, len(vals)
    return use, a, len(vals)


def geometry(m, use):
    st, L = m["st"], m["layout"]
    nodes = L.get("nodes", {})
    num = {z: zone_number(st, z, use) for z in st.info}
    ids, xs, ys, index = [], [], [], {}

    def idx(a):
        a = str(a)
        if a not in index and a in nodes:
            index[a] = len(ids)
            ids.append(a)
            xs.append(round(float(nodes[a][0]), 1))
            ys.append(round(float(nodes[a][1]), 1))
        return index.get(a)

    zlist = sorted({n for n in num.values() if n != "0"}, key=lambda s: (len(s), s))
    zi = {n: i for i, n in enumerate(zlist)}
    edges = []
    for k in L.get("edges", {}):
        a, _, b = str(k).partition(",")
        ia, ib = idx(a), idx(b)
        if ia is None or ib is None:
            continue
        za, zb = st.zone_of.get(a), st.zone_of.get(b)
        z = num.get(za) if za is not None and za == zb else None
        edges += [ia, ib, zi.get(z, -1) if z else -1]
    # 구역 정보 · 가운데 점 (라벨 · 클릭)
    acc = {n: [0.0, 0.0, 0] for n in zlist}
    for a, z in st.zone_of.items():
        n = num.get(z)
        if n in acc and str(a) in nodes:
            x, y = nodes[str(a)]
            acc[n][0] += float(x)
            acc[n][1] += float(y)
            acc[n][2] += 1
    meta = {}
    for z, (name, bay, _, vmax) in st.info.items():
        n = num[z]
        if n != "0" and n not in meta:
            meta[n] = (name, bay, vmax)
    zones = []
    for n in zlist:
        sx, sy, c = acc[n]
        name, bay, vmax = meta.get(n, ("", "", 0))
        zones.append({"id": n, "name": name, "bay": bay, "vmax": vmax,
                      "cx": round(sx / c, 1) if c else None, "cy": round(sy / c, 1) if c else None, "n": c})
    return {"x": xs, "y": ys, "e": edges, "zones": zones}


# ==========================================================
# 사건 · 구역 집계
# ==========================================================
def events_of(rows):
    al = [r for r in rows if r["alarm"] in LEVEL]
    ev = []
    for r in al:
        t = datetime.strptime(r["t"], "%Y-%m-%d %H:%M")
        if ev and t - ev[-1]["_end"] <= timedelta(minutes=GAP_MIN):
            ev[-1]["rows"].append(r)
            ev[-1]["_end"] = t
        else:
            ev.append({"rows": [r], "_end": t})
    out = []
    for e in ev:
        rs = e["rows"]
        top = Counter(r["z1"] for r in rs if r["z1"] != "0").most_common(1)
        out.append({"s": rs[0]["t"], "e": rs[-1]["t"], "min": len(rs),
                    "lv": max(LEVEL[r["alarm"]] for r in rs),
                    "cnt": [sum(1 for r in rs if r["alarm"] == a) for a in ("경계", "위험", "초위험")],
                    "z0": rs[0]["z1"], "ztop": top[0][0] if top else "0",
                    "maxmiss": max(r["miss"] for r in rs), "maxjam": max(r["jam"] for r in rs),
                    "maxht": max(r["ht"] for r in rs), "maxzs": max(r["zstop"] for r in rs)})
    return out


def zone_table(rows, events, zmeta, mapped):
    t = {}
    for r in rows:
        if r["alarm"] not in LEVEL:
            continue
        for k, rank in (("z1", 1), ("z2", 2), ("z3", 3)):
            z = r[k]
            if z in ("", "0"):
                continue
            d = t.setdefault(z, {"id": z, "c": [0, 0, 0], "sub": 0, "ev": 0, "first": r["t"], "last": r["t"],
                                 "maxzs": 0})
            d["last"] = r["t"]
            if rank == 1:
                d["c"][LEVEL[r["alarm"]] - 1] += 1
                d["maxzs"] = max(d["maxzs"], r["zstop"])
            else:
                d["sub"] += 1
    for e in events:
        for z in {r["z1"] for r in rows_between(rows, e) if r["z1"] != "0"}:
            if z in t:
                t[z]["ev"] += 1
    out = []
    for z, d in t.items():
        name, bay = zmeta.get(z, ("", ""))
        d.update({"name": name, "bay": bay, "map": z in mapped, "tot": sum(d["c"])})
        out.append(d)
    out.sort(key=lambda d: (-(d["c"][2] * 3 + d["c"][1] * 2 + d["c"][0]), -d["tot"], -d["sub"], d["id"]))
    return out


def rows_between(rows, e):
    return [r for r in rows if e["s"] <= r["t"] <= e["e"] and r["alarm"] in LEVEL]


def write_zone_csv(path, table):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["순위", "HID_ZONE", "Full_Name", "HID_section", "지도에_있음",
                    "1위_경계분", "1위_위험분", "1위_초위험분", "1위_합계분", "2·3위_분", "사건수",
                    "1위때_최대_ZONE_STOP", "처음", "마지막"])
        for i, d in enumerate(table, 1):
            w.writerow([i, d["id"], d["name"], d["bay"], "Y" if d["map"] else "N", *d["c"], d["tot"], d["sub"],
                        d["ev"], d["maxzs"], d["first"], d["last"]])


# ==========================================================
# HTML
# ==========================================================
def build_html(fab, title_range, geo, rows, events, table, info):
    al = [r for r in rows if r["alarm"] in LEVEL]
    data = {
        "fab": fab, "range": title_range, "info": info, "geo": geo, "events": events, "table": table,
        "rows": [[r["t"], LEVEL[r["alarm"]], r["z1"], r["z2"], r["z3"], r["n"], r["miss"], r["jam"], r["ht"],
                  r["zstop"], r["zvhl"], r["vmax"], r["occ"], r["sect"]] for r in al],
        "cnt": {"all": len(rows), "al": len(al), "lv": [sum(1 for r in al if r["alarm"] == a)
                                                        for a in ("경계", "위험", "초위험")]},
    }
    js = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    return HTML.replace("__TITLE__", f"HID 문제맵 · {fab}").replace("__DATA__", js)


HTML = r"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title>
<style>
:root{--bg:#f6f7f9;--panel:#fff;--fg:#1d2330;--fg2:#5b6474;--line:#e3e6eb;--rail:#c4c9d2;--zone:#9aa3b2;
--l1:#e0a12e;--l2:#e2533a;--l3:#8f1d4f;--sub:#3b82c4;--hi:#111;--chip:#eef1f5;--sel:#fff4d6}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#11151c;--panel:#171c25;--fg:#e6e9ef;--fg2:#9aa3b2;
--line:#2a3140;--rail:#3a4252;--zone:#5d6778;--l1:#f0b545;--l2:#ff6b52;--l3:#e0508f;--sub:#5aa7ef;--hi:#fff;--chip:#222a36;--sel:#3a3320}}
:root[data-theme="dark"]{--bg:#11151c;--panel:#171c25;--fg:#e6e9ef;--fg2:#9aa3b2;--line:#2a3140;--rail:#3a4252;--zone:#5d6778;
--l1:#f0b545;--l2:#ff6b52;--l3:#e0508f;--sub:#5aa7ef;--hi:#fff;--chip:#222a36;--sel:#3a3320}
*{box-sizing:border-box}html,body{margin:0;height:100%}
body{background:var(--bg);color:var(--fg);font:13px/1.45 "Malgun Gothic","Apple SD Gothic Neo",system-ui,sans-serif;display:flex;flex-direction:column}
header{padding:10px 16px;border-bottom:1px solid var(--line);background:var(--panel);display:flex;flex-wrap:wrap;gap:6px 16px;align-items:baseline}
header h1{font-size:16px;margin:0}header .m{color:var(--fg2);font-size:12px}
main{flex:1;display:flex;min-height:0}
#mapbox{flex:1;position:relative;min-width:0;min-height:320px}
canvas{display:block;width:100%;height:100%;cursor:grab}canvas.drag{cursor:grabbing}
#side{width:380px;max-width:100%;border-left:1px solid var(--line);background:var(--panel);display:flex;flex-direction:column;min-height:0}
.tabs{display:flex;border-bottom:1px solid var(--line)}.tabs button{flex:1;padding:9px;border:0;background:none;color:var(--fg2);font:inherit;cursor:pointer;border-bottom:2px solid transparent}
.tabs button.on{color:var(--fg);border-bottom-color:var(--l2);font-weight:700}
.pane{flex:1;overflow:auto;padding:8px 10px;display:none}.pane.on{display:block}
table{border-collapse:collapse;width:100%;font-size:12px}th,td{padding:4px 5px;border-bottom:1px solid var(--line);text-align:right;white-space:nowrap}
th{position:sticky;top:0;background:var(--panel);color:var(--fg2);font-weight:600}td.l,th.l{text-align:left}
tbody tr{cursor:pointer}tbody tr:hover{background:var(--chip)}tr.sel{background:var(--sel)!important}
.b{display:inline-block;min-width:38px;text-align:center;border-radius:4px;padding:0 4px;color:#fff;font-size:11px}
.b1{background:var(--l1);color:#222}.b2{background:var(--l2)}.b3{background:var(--l3)}
.legend{position:absolute;left:10px;bottom:10px;background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:6px 8px;font-size:11px;color:var(--fg2)}
.legend i{display:inline-block;width:18px;height:4px;border-radius:2px;margin:0 4px 2px 8px;vertical-align:middle}
.tools{position:absolute;right:10px;top:10px;display:flex;gap:6px}.tools button{border:1px solid var(--line);background:var(--panel);color:var(--fg);border-radius:6px;padding:4px 8px;font:inherit;font-size:12px;cursor:pointer}
#tip{position:absolute;pointer-events:none;background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:5px 7px;font-size:12px;display:none;box-shadow:0 2px 8px #0003}
#play{border-top:1px solid var(--line);padding:8px 10px;display:none}#play.on{display:block}
#play input{width:100%}#play .row{display:flex;gap:8px;align-items:center;justify-content:space-between}
#play button{border:1px solid var(--line);background:var(--chip);color:var(--fg);border-radius:6px;padding:3px 9px;font:inherit;cursor:pointer}
.kv{display:grid;grid-template-columns:auto 1fr auto 1fr;gap:2px 8px;font-size:12px;margin-top:6px}.kv b{color:var(--fg2);font-weight:500}
.warn{color:var(--l2);font-size:12px;margin:6px 0}.note{color:var(--fg2);font-size:11.5px;margin:6px 0}
@media (max-width:820px){main{flex-direction:column}#side{width:100%;border-left:0;border-top:1px solid var(--line);height:48vh;flex:none}#mapbox{height:52vh;flex:none}}
</style></head><body>
<header><h1 id="h1"></h1><span class="m" id="hm"></span></header>
<main>
 <div id="mapbox"><canvas id="cv"></canvas>
  <div class="tools"><button id="bt-all">⤢ 전체</button><button id="bt-mode">누적 보기</button></div>
  <div class="legend" id="lg"></div><div id="tip"></div></div>
 <aside id="side">
  <div class="tabs"><button class="on" data-p="pz">문제 구역</button><button data-p="pe">알람 사건</button><button data-p="pi">설명</button></div>
  <div class="pane on" id="pz"></div><div class="pane" id="pe"></div><div class="pane" id="pi"></div>
  <div id="play"><div class="row"><button id="bp">▶</button><span id="pt"></span><button id="bx">✕ 사건 닫기</button></div>
   <input type="range" id="sl" min="0" value="0"><div class="kv" id="kv"></div></div>
 </aside>
</main>
<script>
const D=__DATA__;
const LV=['정상','경계','위험','초위험'];
const css=n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const $=id=>document.getElementById(id);
const G=D.geo, Z=G.zones, ZI={}; Z.forEach((z,i)=>ZI[z.id]=i);
const TB={}; D.table.forEach(d=>TB[d.id]=d);
$('h1').textContent=`HID 문제맵 · ${D.fab}`;
$('hm').textContent=`${D.range} · ${D.cnt.all.toLocaleString()}분 중 알람 ${D.cnt.al}분 (경계 ${D.cnt.lv[0]} · 위험 ${D.cnt.lv[1]} · 초위험 ${D.cnt.lv[2]}) · 사건 ${D.events.length}건 · 맵 ${D.info.layout}`;
// ---------- 지도 좌표 ----------
let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity;
for(let i=0;i<G.x.length;i++){const x=G.x[i],y=G.y[i];if(x<minx)minx=x;if(x>maxx)maxx=x;if(y<miny)miny=y;if(y>maxy)maxy=y;}
const cv=$('cv'),ctx=cv.getContext('2d');let W=0,H=0,zoom=1,px=0,py=0,base=1;
function fit(){const r=cv.getBoundingClientRect(),d=devicePixelRatio||1;W=r.width;H=r.height;cv.width=W*d;cv.height=H*d;ctx.setTransform(d,0,0,d,0,0);
 base=Math.min((W-40)/Math.max(1,maxx-minx),(H-40)/Math.max(1,maxy-miny));}
function S(x,y){const s=base*zoom;return[20+(x-minx)*s+px,20+(y-miny)*s+py];}
function I(sx,sy){const s=base*zoom;return[(sx-20-px)/s+minx,(sy-20-py)/s+miny];}
function home(){zoom=1;px=(W-40-(maxx-minx)*base)/2;py=(H-40-(maxy-miny)*base)/2;draw();}
function focus(zid){const z=Z[ZI[zid]];if(!z||z.cx==null)return;zoom=Math.max(zoom,4);const s=base*zoom;px=W/2-20-(z.cx-minx)*s;py=H/2-20-(z.cy-miny)*s;draw();}
// ---------- 색 ----------
let mode='sum', cur=null, selZone=null, ev=null, evRows=[], k=0, timer=null;
const maxScore=Math.max(1,...D.table.map(d=>d.c[2]*3+d.c[1]*2+d.c[0]));
function heat(v){const t=Math.min(1,v/maxScore);const a=css('--l1'),b=css('--l3');return mix(a,b,t);}
function mix(a,b,t){const p=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16));const A=p(a),B=p(b);return'#'+A.map((v,i)=>Math.round(v+(B[i]-v)*t).toString(16).padStart(2,'0')).join('');}
function zoneStyle(){ // 구역 id → [색, 굵기, 순위]
 const m={};
 if(cur){[[cur[2],1],[cur[3],2],[cur[4],3]].forEach(([z,r])=>{if(z&&z!=='0'&&!(z in m))m[z]=r===1?[css('--l'+cur[1]),5,1]:[css('--sub'),3.2,r];});}
 else{D.table.forEach(d=>{const sc=d.c[2]*3+d.c[1]*2+d.c[0];if(sc>0)m[d.id]=[heat(sc),2.5+4*Math.min(1,sc/maxScore),1];else if(d.sub>0)m[d.id]=[css('--sub'),2,3];});}
 return m;}
function draw(){
 ctx.clearRect(0,0,W,H);const rail=css('--rail'),zc=css('--zone');const st=zoneStyle();
 const lw=Math.max(.6,Math.min(2,.5+zoom*.15));
 ctx.lineCap='round';
 // 레일
 ctx.strokeStyle=rail;ctx.lineWidth=lw;ctx.beginPath();
 for(let i=0;i<G.e.length;i+=3){if(G.e[i+2]>=0)continue;const a=S(G.x[G.e[i]],G.y[G.e[i]]),b=S(G.x[G.e[i+1]],G.y[G.e[i+1]]);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);}
 ctx.stroke();
 // 구역 (칠하지 않는 구역은 조금 진한 회색)
 ctx.strokeStyle=zc;ctx.lineWidth=lw;ctx.beginPath();
 for(let i=0;i<G.e.length;i+=3){const z=G.e[i+2];if(z<0||st[Z[z].id])continue;const a=S(G.x[G.e[i]],G.y[G.e[i]]),b=S(G.x[G.e[i+1]],G.y[G.e[i+1]]);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);}
 ctx.stroke();
 // 문제 구역 — 2·3위 먼저, 1위 나중
 const order=Object.entries(st).sort((a,b)=>b[1][2]-a[1][2]);
 for(const [zid,[col,w]] of order){const zi=ZI[zid];if(zi==null)continue;ctx.strokeStyle=col;ctx.lineWidth=w*(selZone===zid?1.6:1);ctx.beginPath();
  for(let i=0;i<G.e.length;i+=3){if(G.e[i+2]!==zi)continue;const a=S(G.x[G.e[i]],G.y[G.e[i]]),b=S(G.x[G.e[i+1]],G.y[G.e[i+1]]);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);}ctx.stroke();}
 // 라벨
 ctx.font='600 11px system-ui,sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
 const placed=[];const TR={};D.table.forEach((d,i)=>TR[d.id]=i);
 const rank=z=>{const s=st[z.id];return selZone===z.id?-1:!s?1e6:cur?s[2]:(TR[z.id]??1e5);};   // 표 순위대로 라벨 (겹치면 뒤 순위를 뺀다)
 [...Z].sort((a,b)=>rank(a)-rank(b)).forEach(z=>{if(z.cx==null)return;const s=st[z.id];if(!s&&zoom<3&&selZone!==z.id)return;let [x,y]=S(z.cx,z.cy);if(x<-20||y<-20||x>W+20||y>H+20)return;
  const nm=z.bay?` · ${z.bay}`:'';const t=s&&s[2]===1&&cur?`HID ${z.id}${nm} ${LV[cur[1]]}`:(s||selZone===z.id?`HID ${z.id}${nm}`:z.id);const w=ctx.measureText(t).width+8;
  const x0=x;x=Math.max(w/2+2,Math.min(W-w/2-2,x0));
  if(placed.some(p=>Math.abs(p[0]-x)<(p[2]+w)/2&&Math.abs(p[1]-y)<16))return;placed.push([x,y,w]);  // 겹치면 순위 낮은 라벨은 뺀다 (확대하면 보임)
  ctx.fillStyle=s?css('--panel'):'transparent';if(s){ctx.globalAlpha=.85;ctx.fillRect(x-w/2,y-8,w,16);ctx.globalAlpha=1;}
  ctx.fillStyle=s?css('--fg'):css('--fg2');ctx.fillText(t,x,y);});
 legend();}
function legend(){
 if(cur)$('lg').innerHTML=`<b>${cur[0]}</b><i style="background:${css('--l'+cur[1])}"></i>1위 구역 (${LV[cur[1]]})<i style="background:${css('--sub')}"></i>2·3위 구역`;
 else $('lg').innerHTML=`누적 — 병목 1위로 나온 정도<i style="background:${css('--l1')}"></i>적음<i style="background:${css('--l3')}"></i>많음<i style="background:${css('--sub')}"></i>2·3위로만`;}
// ---------- 지도 조작 ----------
let drag=null;
cv.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,px,py,moved:false};cv.setPointerCapture(e.pointerId);cv.classList.add('drag');});
cv.addEventListener('pointermove',e=>{if(drag){const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.abs(dx)+Math.abs(dy)>3)drag.moved=true;px=drag.px+dx;py=drag.py+dy;draw();}else hover(e);});
cv.addEventListener('pointerup',e=>{cv.classList.remove('drag');if(drag&&!drag.moved){const z=pick(e);if(z){selZone=z;markRow(z);draw();}}drag=null;});
cv.addEventListener('wheel',e=>{e.preventDefault();const r=cv.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;const [wx,wy]=I(mx,my);
 zoom=Math.max(.5,Math.min(80,zoom*(e.deltaY<0?1.2:1/1.2)));const [sx,sy]=S(wx,wy);px+=mx-sx;py+=my-sy;draw();},{passive:false});
cv.addEventListener('dblclick',home);
function pick(e){const r=cv.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;let best=null,bd=14*14;
 for(let i=0;i<G.e.length;i+=3){const z=G.e[i+2];if(z<0)continue;const a=S(G.x[G.e[i]],G.y[G.e[i]]),b=S(G.x[G.e[i+1]],G.y[G.e[i+1]]);const d=seg(mx,my,a,b);if(d<bd){bd=d;best=Z[z].id;}}return best;}
function seg(x,y,a,b){const dx=b[0]-a[0],dy=b[1]-a[1],l=dx*dx+dy*dy;let t=l?((x-a[0])*dx+(y-a[1])*dy)/l:0;t=Math.max(0,Math.min(1,t));const qx=a[0]+t*dx-x,qy=a[1]+t*dy-y;return qx*qx+qy*qy;}
function hover(e){const z=pick(e),tp=$('tip');if(!z){tp.style.display='none';return;}const r=cv.getBoundingClientRect(),zz=Z[ZI[z]],d=TB[z];
 tp.innerHTML=`<b>HID ${z}</b> ${zz.name||''} ${zz.bay?'· '+zz.bay:''}<br>`+(d?`1위 경계 ${d.c[0]} · 위험 ${d.c[1]} · 초위험 ${d.c[2]}분 · 2·3위 ${d.sub}분 · 사건 ${d.ev}`:'알람 없음');
 tp.style.display='block';tp.style.left=Math.min(e.clientX-r.left+12,W-260)+'px';tp.style.top=(e.clientY-r.top+12)+'px';}
// ---------- 오른쪽 표 ----------
document.querySelectorAll('.tabs button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tabs button').forEach(x=>x.classList.toggle('on',x===b));
 document.querySelectorAll('.pane').forEach(p=>p.classList.toggle('on',p.id===b.dataset.p));});
const badge=l=>l?`<span class="b b${l}">${LV[l]}</span>`:'';
function zoneTable(){
 const miss=D.table.filter(d=>!d.map);
 let h=`<div class="note">기간 동안 <b>병목 1위(HID_ZONE)</b>로 나온 분 수 — 초위험×3 + 위험×2 + 경계 순. 줄을 누르면 지도에서 그 구역으로 갑니다.</div>`;
 if(miss.length)h+=`<div class="warn">지도에 없는 구역 ${miss.length}개: ${miss.slice(0,12).map(d=>d.id).join(', ')}${miss.length>12?' …':''} — 결과 파일과 OHT_MAP 마스터가 다른지 확인하세요.</div>`;
 h+=`<table><thead><tr><th>#</th><th class="l">HID</th><th class="l">구역</th><th>경계</th><th>위험</th><th>초위험</th><th>2·3위</th><th>사건</th></tr></thead><tbody>`;
 D.table.forEach((d,i)=>{h+=`<tr data-z="${d.id}"><td>${i+1}</td><td class="l"><b>${d.id}</b>${d.map?'':' ⚠'}</td><td class="l">${(d.bay||'')}</td><td>${d.c[0]||''}</td><td>${d.c[1]||''}</td><td>${d.c[2]||''}</td><td>${d.sub||''}</td><td>${d.ev||''}</td></tr>`;});
 if(!D.table.length)h+=`<tr><td colspan="8" class="l">이 기간 알람 없음</td></tr>`;
 $('pz').innerHTML=h+'</tbody></table>';
 $('pz').querySelectorAll('tbody tr[data-z]').forEach(tr=>tr.onclick=()=>{selZone=tr.dataset.z;markRow(selZone);focus(selZone);});}
function markRow(z){document.querySelectorAll('#pz tr[data-z]').forEach(tr=>tr.classList.toggle('sel',tr.dataset.z===z));}
function eventTable(){
 let h=`<div class="note">알람이 이어진 분을 한 사건으로 묶었습니다 (사이가 ${1}분 넘게 벌어지면 다른 사건). 누르면 그 사건을 분마다 지도에서 봅니다.</div>`;
 h+=`<table><thead><tr><th class="l">시작</th><th>끝</th><th>분</th><th>최고</th><th class="l">시작 HID</th><th class="l">최다 HID</th></tr></thead><tbody>`;
 D.events.forEach((e,i)=>{h+=`<tr data-i="${i}"><td class="l">${e.s.slice(5)}</td><td>${e.e.slice(11)}</td><td>${e.min}</td><td>${badge(e.lv)}</td><td class="l">${e.z0}</td><td class="l">${e.ztop}</td></tr>`;});
 if(!D.events.length)h+=`<tr><td colspan="6" class="l">이 기간 알람 없음</td></tr>`;
 $('pe').innerHTML=h+'</tbody></table>';
 $('pe').querySelectorAll('tbody tr[data-i]').forEach(tr=>tr.onclick=()=>{$('pe').querySelectorAll('tr').forEach(x=>x.classList.toggle('sel',x===tr));openEvent(+tr.dataset.i);});}
function openEvent(i){ev=D.events[i];evRows=D.rows.filter(r=>r[0]>=ev.s&&r[0]<=ev.e);k=0;$('sl').max=evRows.length-1;$('sl').value=0;$('play').classList.add('on');mode='ev';$('bt-mode').textContent='누적 보기';show(0,true);}
function show(j,center){k=j;cur=evRows[j];$('sl').value=j;$('pt').textContent=`${j+1} / ${evRows.length}분`;
 const r=cur;$('kv').innerHTML=`<b>시간</b><span>${r[0]}</span><b>ALARM</b><span>${badge(r[1])}</span>
 <b>HID_ZONE</b><span>${r[2]}</span><b>section</b><span>${r[13]}</span><b>2·3위</b><span>${r[3]} · ${r[4]}</span><b>report</b><span>${r[5]}</span>
 <b>missing</b><span>${r[6]}</span><b>JAM</b><span>${r[7]}</span><b>HT_STOP</b><span>${r[8]}</span><b>ZONE_STOP</b><span>${r[9]}</span>
 <b>ZONE_VHL</b><span>${r[10]}</span><b>점유율</b><span>${r[12]}%</span>`;
 if(center&&r[2]!=='0')focus(r[2]);else draw();}
$('sl').oninput=e=>show(+e.target.value);
$('bp').onclick=()=>{if(timer){clearInterval(timer);timer=null;$('bp').textContent='▶';return;}$('bp').textContent='❚❚';
 timer=setInterval(()=>{if(k>=evRows.length-1){clearInterval(timer);timer=null;$('bp').textContent='▶';return;}show(k+1);},700);};
$('bx').onclick=()=>{if(timer){clearInterval(timer);timer=null;$('bp').textContent='▶';}$('play').classList.remove('on');cur=null;ev=null;mode='sum';draw();};
$('bt-mode').onclick=()=>{if(cur){cur=null;$('bt-mode').textContent=ev?'사건 보기':'누적 보기';}else if(ev){cur=evRows[k];$('bt-mode').textContent='누적 보기';}draw();};
$('bt-all').onclick=home;
$('pi').innerHTML=`<div class="note" style="font-size:12.5px;line-height:1.6">
<b>무엇인가</b><br>HID_병목구간.py 결과(1분마다 ALARM · 병목 1위 HID_ZONE · 2·3위)를 월드모델파생 맵(OHT_MAP 레이아웃 · HID_Zone_Master) 위에 칠한 것입니다. 구역 번호는 HID_병목구간.py 와 같은 방법으로 붙였습니다(${D.info.use}).<br><br>
<b>누적 보기</b> — 기간 동안 병목 1위로 나온 구역일수록 진한 색 · 굵은 선. 2·3위로만 나온 구역은 파란 선.<br>
<b>사건 보기</b> — '알람 사건'에서 사건을 누르면 분마다 1위 구역을 ALARM 색(경계 · 위험 · 초위험)으로, 2·3위 구역을 파란색으로 보여 줍니다. ▶ 로 넘겨 보면 막힘이 어디서 어디로 번지는지 보입니다.<br><br>
<b>조작</b> — 휠 확대 · 드래그 이동 · 더블클릭 전체 · 구역 위에 마우스를 올리면 집계, 누르면 표에서 표시.<br><br>
<b>맵</b> ${D.info.layout} · ${D.info.msg}<br><b>결과 번호 일치</b> ${D.info.match}</div>`;
zoneTable();eventTable();
addEventListener('resize',()=>{fit();draw();});fit();home();
</script></body></html>
"""


# ==========================================================
def main():
    ap = argparse.ArgumentParser(description="HID_병목구간 결과 → 문제맵(HTML)")
    ap.add_argument("fab", help=f"FAB ({' '.join(HB.FABS)})")
    ap.add_argument("days", nargs="*", help="시작날짜 [끝날짜] YYYYMMDD (없으면 있는 날짜 다)")
    ap.add_argument("--src", choices=["과거", "실시간"], default="과거",
                    help="과거 = HID_병목/과거판정/{FAB}/ (기본), 실시간 = HID_병목/{FAB}/")
    ap.add_argument("--csv", nargs="+", help="결과 파일 직접 지정 (날짜별 · 합치기 결과 다 됨)")
    ap.add_argument("--out", help="저장할 폴더 (기본 HID_병목/문제맵)")
    a = ap.parse_args()

    fab = a.fab.upper()
    if fab not in HB.FABS:
        sys.exit(f"FAB 은 {' '.join(HB.FABS)} 중 하나")
    days = [d.replace("-", "") for d in a.days]
    if any(not re.fullmatch(r"\d{8}", d) for d in days) or len(days) > 2:
        sys.exit("날짜는 YYYYMMDD — 시작날짜 [끝날짜]")
    d0 = days[0] if days else None
    d1 = days[1] if len(days) > 1 else d0

    say(f"■ {fab} 문제맵")
    files = a.csv or _files(fab, a.src)
    if not files:
        where = (HB.PAST_DIR if a.src == "과거" else HB.OUT_DIR) / fab
        sys.exit(f"결과 파일 없음: {where}\\HID병목_{fab}_*.csv — 먼저 python HID_병목구간.py {fab} 날짜 로 판정하세요")
    rows = read_rows(fab, files, d0, d1)
    if not rows:
        sys.exit("그 기간 결과 줄이 없습니다")

    m, err = load_map(fab)
    if not m:
        sys.exit(f"맵 없음 — {err}")
    st = m["st"]
    use, hit, nv = pick_numbering(st, rows)
    geo = geometry(m, use)
    zmeta = {z["id"]: (z["name"], z["bay"]) for z in geo["zones"]}
    mapped = {z["id"] for z in geo["zones"] if z["n"]}
    events = events_of(rows)
    table = zone_table(rows, events, zmeta, mapped)

    s, e = rows[0]["t"][:10].replace("-", ""), rows[-1]["t"][:10].replace("-", "")
    rng = f"{rows[0]['t'][:10]} ~ {rows[-1]['t'][:10]}" if s != e else rows[0]["t"][:10]
    info = {"layout": m["layout_file"], "msg": m["msg"], "use": use,
            "match": f"결과 파일 구역 번호 {nv}개 중 {hit}개가 지도에 있음" if nv else "알람 없음"}
    out = Path(a.out) if a.out else MAP_OUT
    out.mkdir(parents=True, exist_ok=True)
    tag = f"{fab}_{s}_{e}" if s != e else f"{fab}_{s}"
    hp, cp = out / f"문제맵_{tag}.html", out / f"문제구역_{tag}.csv"
    hp.write_text(build_html(fab, rng, geo, rows, events, table, info), encoding="utf-8")
    write_zone_csv(cp, table)

    al = sum(1 for r in rows if r["alarm"] in LEVEL)
    say(f"  {rng} · {len(rows)}분 · 알람 {al}분 · 사건 {len(events)}건 · 문제 구역 {len(table)}개")
    say(f"  맵 {m['layout_file']} · 구역 {len(geo['zones'])} · 번호 {use} · {info['match']}")
    for i, d in enumerate(table[:5], 1):
        say(f"   {i}. HID {d['id']:>6} {d['bay']:6} 1위 경계 {d['c'][0]} · 위험 {d['c'][1]} · 초위험 {d['c'][2]}분"
            f" · 2·3위 {d['sub']}분 · 사건 {d['ev']}{'' if d['map'] else '  ⚠지도에 없음'}")
    say(f"  → {hp}")
    say(f"  → {cp}")


if __name__ == "__main__":
    main()
