#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HID_문제맵.py — 판정된 시간 하나로 "문제맵"(HTML 지도) 만들기

  HID_병목구간.py 가 판정한 1분 한 줄(ALARM · HID_ZONE · HID_ZONE_2/3 · ZONE_STOP …)을
  월드모델파생 맵(OHT_MAP 의 레이아웃 + HID_Zone_Master) 위에 그린다 — 그 시각 어디가 막혔나.
    · 1위 구역(HID_ZONE)   = ALARM 색 (경계 · 위험 · 초위험)
    · 2 · 3위 구역          = 파란색
    · 오른쪽에 그 줄의 숫자 (report · missing · JAM · HT_STOP · ZONE_STOP …) 와 판정 근거
  판정된 시간 하나 = HTML 파일 하나 (인터넷 · 서버 필요 없음, 브라우저로 열면 됨).

  필요한 것 (같은 폴더)
    HID_병목구간.py                 주소 → HID 구역 계산을 그대로 가져다 쓴다 (번호가 결과 파일과 같게)
    OHT_MAP/                        월드모델파생의 OHT_MAP 폴더 그대로 (HID_병목구간.py 와 같은 것)
    HID_병목/과거판정/{FAB}/…csv    HID_병목구간.py 결과 (--src 실시간 이면 HID_병목/{FAB}/, --csv 로 파일 지정도 됨)

  실행
    python HID_문제맵.py M16HUB 202609290813                     그 1분 (YYYYMMDDHHMM)
    python HID_문제맵.py M16HUB 202609290806 202609290813        여러 시각 — 시각마다 파일 하나
    python HID_문제맵.py M16HUB 20260929                         그 날 판정된(알람) 시간 전부 — 시각마다 파일 하나
    python HID_문제맵.py M16HUB 202610021405 --src 실시간         실시간 결과에서
    python HID_문제맵.py M16HUB 202609290813 --csv 합침_M16HUB_20260901_20260930.csv
      → HID_병목/문제맵/{FAB}_{YYYYMMDD}/문제맵_{FAB}_{YYYYMMDD}_{HHMM}_{ALARM}.html
"""
import argparse
import csv
import glob
import io
import json
import re
import sys
from collections import OrderedDict
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import HID_병목구간 as HB                           # noqa: E402  (맵 · 구역 번호 계산을 그대로 쓴다)


LEVEL = {"경계": 1, "위험": 2, "초위험": 3}
MAP_OUT = HB.OUT_DIR / "문제맵"


def say(msg):
    print(msg, flush=True)


# ==========================================================
# 결과 읽기
# ==========================================================
def _files(fab, src):
    base = (HB.PAST_DIR if src == "과거" else HB.OUT_DIR) / fab
    return sorted(glob.glob(str(base / f"HID병목_{fab}_*.csv")))


def _int(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def read_rows(fab, files, d0=None, d1=None):
    """결과 CSV → 분 행 목록. 날짜별 파일 · 합치기 파일(FAB · OHT_missing 칸) 다 받는다. 같은 분은 한 번만."""
    rows = OrderedDict()
    for p in files:
        try:
            text = Path(p).read_text(encoding="utf-8-sig")
        except UnicodeDecodeError:
            text = Path(p).read_text(encoding="cp949")
        rd = csv.DictReader(io.StringIO(text))
        cols = rd.fieldnames or []
        if "ALARM" not in cols or "날짜" not in cols:
            say(f"  건너뜀 (결과 파일 아님): {Path(p).name}")
            continue
        pre = f"{fab}_OHT_" if f"{fab}_OHT_missing" in cols else "OHT_"
        n = 0
        for r in rd:
            if "FAB" in cols and (r.get("FAB") or "").strip() != fab:
                continue
            day, hm = (r.get("날짜") or "").strip(), (r.get("시간") or "").strip()
            if not day or not hm:
                continue
            dk = day.replace("-", "")
            if (d0 and dk < d0) or (d1 and dk > d1):
                continue
            k = f"{day} {hm}"
            if k in rows:
                continue
            rows[k] = {
                "t": k, "alarm": (r.get("ALARM") or "정상").strip(),
                "z1": (r.get("HID_ZONE") or "0").strip(), "z2": (r.get("HID_ZONE_2") or "0").strip(),
                "z3": (r.get("HID_ZONE_3") or "0").strip(), "sect": (r.get("HID_section") or "0").strip(),
                "n": _int(r.get(pre + "report")), "miss": _int(r.get(pre + "missing")),
                "jam": _int(r.get(pre + "JAM")), "ht": _int(r.get(pre + "HT_STOP")),
                "zstop": _int(r.get("ZONE_STOP")), "zvhl": _int(r.get("ZONE_VHL")),
                "vmax": _int(r.get("VHL_MAX")), "occ": _int(r.get("ZONE_OCC")),
            }
            n += 1
        say(f"  {Path(p).name}: {n}분")
    return sorted(rows.values(), key=lambda r: r["t"])


# ==========================================================
# 월드모델파생 맵 → 지도 그림 재료
# ==========================================================
def load_map(fab):
    """HID_병목구간.py 와 똑같이 주소 → 구역을 만들고, 결과 파일과 같은 HID_ZONE 번호를 붙인다."""
    cfg = HB.FABS[fab]
    st = HB.FabState(fab, cfg)
    if not st.ok:
        return None, st.map_msg
    states = {fab: st}
    if fab != "M16HUB":                              # 번호 칸(ZONE_ID/ZONE_ID2)은 M16HUB 참조표로 정해진다
        hub = HB.FabState("M16HUB", HB.FABS["M16HUB"])
        if hub.ok:
            states["M16HUB"] = hub
    HB.resolve_hid_zone(states)
    _, layout = HB._find_map_files(*cfg["map"])
    L = json.loads(Path(layout).read_text(encoding="utf-8"))
    return {"st": st, "layout": L, "layout_file": Path(layout).name, "msg": st.map_msg}, ""


def zone_number(st, z, use):
    if use == "ZONE_ID2":
        return str(st.info.get(z, ("", "", "", 0))[2] or 0)
    return str(z or 0)


def pick_numbering(st, rows):
    """결과 파일의 HID_ZONE 값과 더 많이 맞는 칸 — 기본은 HID_병목구간.py 가 고른 칸."""
    vals = {r[k] for r in rows for k in ("z1", "z2", "z3") if r[k] not in ("", "0")}
    use = HB.HID_ZONE_USE
    if not vals:
        return use, 0, 0
    other = "ZONE_ID" if use == "ZONE_ID2" else "ZONE_ID2"
    has = lambda u: len(vals & {zone_number(st, z, u) for z in st.info})
    a, b = has(use), has(other)
    if b > a:
        say(f"  ★결과 파일 번호가 {other} 와 더 맞음 ({b} > {a}) — {other} 로 그림")
        return other, b, len(vals)
    return use, a, len(vals)


def geometry(m, use):
    st, L = m["st"], m["layout"]
    nodes = L.get("nodes", {})
    num = {z: zone_number(st, z, use) for z in st.info}
    ids, xs, ys, index = [], [], [], {}

    def idx(a):
        a = str(a)
        if a not in index and a in nodes:
            index[a] = len(ids)
            ids.append(a)
            xs.append(round(float(nodes[a][0]), 1))
            ys.append(round(float(nodes[a][1]), 1))
        return index.get(a)

    zlist = sorted({n for n in num.values() if n != "0"}, key=lambda s: (len(s), s))
    zi = {n: i for i, n in enumerate(zlist)}
    edges = []
    for k in L.get("edges", {}):
        a, _, b = str(k).partition(",")
        ia, ib = idx(a), idx(b)
        if ia is None or ib is None:
            continue
        za, zb = st.zone_of.get(a), st.zone_of.get(b)
        z = num.get(za) if za is not None and za == zb else None
        edges += [ia, ib, zi.get(z, -1) if z else -1]
    # 구역 정보 · 가운데 점 (라벨 · 클릭)
    acc = {n: [0.0, 0.0, 0, 1e18, 1e18, -1e18, -1e18] for n in zlist}
    for a, z in st.zone_of.items():
        n = num.get(z)
        if n in acc and str(a) in nodes:
            x, y = float(nodes[str(a)][0]), float(nodes[str(a)][1])
            c = acc[n]
            c[0] += x
            c[1] += y
            c[2] += 1
            c[3], c[4], c[5], c[6] = min(c[3], x), min(c[4], y), max(c[5], x), max(c[6], y)
    meta = {}
    for z, (name, bay, _, vmax) in st.info.items():
        n = num[z]
        if n != "0" and n not in meta:
            meta[n] = (name, bay, vmax)
    zones = []
    for n in zlist:
        sx, sy, c, x0, y0, x1, y1 = acc[n]
        name, bay, vmax = meta.get(n, ("", "", 0))
        zones.append({"id": n, "name": name, "bay": bay, "vmax": vmax, "n": c,
                      "cx": round(sx / c, 1) if c else None, "cy": round(sy / c, 1) if c else None,
                      "box": [round(x0, 1), round(y0, 1), round(x1, 1), round(y1, 1)] if c else None})
    return {"x": xs, "y": ys, "e": edges, "zones": zones}


# ==========================================================
# 판정 근거 — 지금 HID_CONFIG.json 기준 (파일은 읽기만 한다)
# ==========================================================
def levels_now(fab):
    raw = {}
    try:
        if HB.CONFIG_FILE.exists():
            raw = json.loads(HB.CONFIG_FILE.read_text(encoding="utf-8-sig")).get(fab) or {}
    except Exception:
        raw = {}
    out = {}
    for lv, dv in HB.DEFAULT_LEVELS.items():
        got = raw.get(lv) or {}
        out[lv] = {k: HB._num(got.get(k), 0 if got else d) for k, d in dv.items()}
    return out


def reasons(r, P):
    """그 줄 숫자가 어느 조건에 걸렸나 (높은 단계부터)"""
    out = []
    for lv in ("초위험", "위험", "경계"):
        p = P[lv]
        if p["missing"] and p["JAM"] and r["miss"] >= p["missing"] and r["jam"] >= p["JAM"]:
            out.append(f"{lv}: missing {r['miss']} + JAM {r['jam']} 같이 (기준 {p['missing']} + {p['JAM']})")
        if p["missing_ONLY"] and r["miss"] >= p["missing_ONLY"]:
            out.append(f"{lv}: missing {r['miss']} 단독 (기준 {p['missing_ONLY']})")
        if p["HT_STOP"] and r["ht"] >= p["HT_STOP"]:
            out.append(f"{lv}: HT_STOP {r['ht']} (기준 {p['HT_STOP']})")
        if p.get("ZONE_STOP") and r["zstop"] >= p["ZONE_STOP"]:
            out.append(f"{lv}: 구역 멈춘 차 {r['zstop']} (기준 {p['ZONE_STOP']})")
    return out


# ==========================================================
# HTML — 판정된 시간 한 줄 = 지도 하나
# ==========================================================
def build_html(fab, r, geo, info, why):
    data = {"fab": fab, "info": info, "geo": geo, "why": why,
            "r": {**r, "lv": LEVEL.get(r["alarm"], 0)}}
    js = json.dumps(data, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    title = f"HID 문제맵 · {fab} · {r['t']} · {r['alarm']}"
    return HTML.replace("__TITLE__", title).replace("__DATA__", js)


HTML = r"""<!doctype html>
<html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title>
<style>
:root{--bg:#f6f7f9;--panel:#fff;--fg:#1d2330;--fg2:#5b6474;--line:#e3e6eb;--rail:#c9ced6;--zone:#a3abb8;
--l0:#3f9b5f;--l1:#e0a12e;--l2:#e2533a;--l3:#8f1d4f;--sub:#3b82c4;--chip:#eef1f5}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#11151c;--panel:#171c25;--fg:#e6e9ef;--fg2:#9aa3b2;
--line:#2a3140;--rail:#353d4c;--zone:#596374;--l0:#5cc283;--l1:#f0b545;--l2:#ff6b52;--l3:#e0508f;--sub:#5aa7ef;--chip:#222a36}}
:root[data-theme="dark"]{--bg:#11151c;--panel:#171c25;--fg:#e6e9ef;--fg2:#9aa3b2;--line:#2a3140;--rail:#353d4c;--zone:#596374;
--l0:#5cc283;--l1:#f0b545;--l2:#ff6b52;--l3:#e0508f;--sub:#5aa7ef;--chip:#222a36}
*{box-sizing:border-box}html,body{margin:0;height:100%}
body{background:var(--bg);color:var(--fg);font:13px/1.5 "Malgun Gothic","Apple SD Gothic Neo",system-ui,sans-serif;display:flex;flex-direction:column}
header{padding:10px 16px;border-bottom:1px solid var(--line);background:var(--panel);display:flex;flex-wrap:wrap;gap:6px 14px;align-items:center}
header h1{font-size:17px;margin:0}header .m{color:var(--fg2);font-size:12px}
.b{display:inline-block;border-radius:5px;padding:1px 10px;color:#fff;font-weight:700;font-size:14px}
.b0{background:var(--l0)}.b1{background:var(--l1);color:#222}.b2{background:var(--l2)}.b3{background:var(--l3)}
main{flex:1;display:flex;min-height:0}
#mapbox{flex:1;position:relative;min-width:0;min-height:320px}
canvas{display:block;width:100%;height:100%;cursor:grab}canvas.drag{cursor:grabbing}
#side{width:360px;max-width:100%;border-left:1px solid var(--line);background:var(--panel);overflow:auto;padding:12px 14px}
h2{font-size:13px;margin:14px 0 6px;color:var(--fg2);font-weight:600}h2:first-child{margin-top:0}
.zone{border:1px solid var(--line);border-radius:8px;padding:8px 10px;margin-bottom:8px;cursor:pointer}
.zone .t{font-weight:700;font-size:15px}.zone .s{color:var(--fg2);font-size:12px}
.zone.r1{border-left:6px solid var(--lv)}.zone.r2,.zone.r3{border-left:6px solid var(--sub)}
table{border-collapse:collapse;width:100%;font-size:12.5px}td{padding:4px 6px;border-bottom:1px solid var(--line)}td:first-child{color:var(--fg2)}td:last-child{text-align:right;font-weight:600}
ul{margin:4px 0;padding-left:18px}li{margin:2px 0}
.legend{position:absolute;left:10px;bottom:10px;background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:6px 8px;font-size:11.5px;color:var(--fg2)}
.legend i{display:inline-block;width:18px;height:5px;border-radius:2px;margin:0 4px 2px 8px;vertical-align:middle}
.tools{position:absolute;right:10px;top:10px;display:flex;gap:6px}.tools button{border:1px solid var(--line);background:var(--panel);color:var(--fg);border-radius:6px;padding:4px 9px;font:inherit;font-size:12px;cursor:pointer}
#tip{position:absolute;pointer-events:none;background:var(--panel);border:1px solid var(--line);border-radius:6px;padding:5px 7px;font-size:12px;display:none;box-shadow:0 2px 8px #0003}
.warn{color:var(--l2);font-size:12px}.note{color:var(--fg2);font-size:11.5px}
@media (max-width:820px){main{flex-direction:column}#side{width:100%;border-left:0;border-top:1px solid var(--line);flex:none}#mapbox{height:60vh;flex:none}}
</style></head><body>
<header><h1 id="h1"></h1><span id="hb"></span><span class="m" id="hm"></span></header>
<main>
 <div id="mapbox"><canvas id="cv"></canvas>
  <div class="tools"><button id="bt-z">◎ 문제 구역</button><button id="bt-all">⤢ 전체</button></div>
  <div class="legend" id="lg"></div><div id="tip"></div></div>
 <aside id="side"></aside>
</main>
<script>
const D=__DATA__, R=D.r, G=D.geo, Z=G.zones, ZI={}; Z.forEach((z,i)=>ZI[z.id]=i);
const LV=['정상','경계','위험','초위험'];
const css=n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const $=id=>document.getElementById(id);
const TOP=[[R.z1,1],[R.z2,2],[R.z3,3]].filter(([z])=>z&&z!=='0');
$('h1').textContent=`HID 문제맵 · ${D.fab} · ${R.t}`;
$('hb').innerHTML=`<span class="b b${R.lv}">${R.alarm}</span>`;
$('hm').textContent=`맵 ${D.info.layout} · 결과 ${D.info.src}`;
document.documentElement.style.setProperty('--lv',css('--l'+R.lv));
// ---------- 좌표 ----------
let minx=Infinity,miny=Infinity,maxx=-Infinity,maxy=-Infinity;
for(let i=0;i<G.x.length;i++){const x=G.x[i],y=G.y[i];if(x<minx)minx=x;if(x>maxx)maxx=x;if(y<miny)miny=y;if(y>maxy)maxy=y;}
const cv=$('cv'),ctx=cv.getContext('2d');let W=0,H=0,zoom=1,px=0,py=0,base=1;
function fit(){const r=cv.getBoundingClientRect(),d=devicePixelRatio||1;W=r.width;H=r.height;cv.width=W*d;cv.height=H*d;ctx.setTransform(d,0,0,d,0,0);
 base=Math.min((W-40)/Math.max(1,maxx-minx),(H-40)/Math.max(1,maxy-miny));}
const S=(x,y)=>{const s=base*zoom;return[20+(x-minx)*s+px,20+(y-miny)*s+py];};
const I=(sx,sy)=>{const s=base*zoom;return[(sx-20-px)/s+minx,(sy-20-py)/s+miny];};
function view(x0,y0,x1,y1){const w=Math.max(1,x1-x0),h=Math.max(1,y1-y0);zoom=Math.max(.5,Math.min(80,Math.min((W-80)/w,(H-80)/h)/base));
 const s=base*zoom;px=W/2-20-((x0+x1)/2-minx)*s;py=H/2-20-((y0+y1)/2-miny)*s;draw();}
const home=()=>view(minx,miny,maxx,maxy);
function focusTop(){const bs=TOP.map(([z])=>Z[ZI[z]]).filter(z=>z&&z.box);if(!bs.length)return home();
 const x0=Math.min(...bs.map(z=>z.box[0])),y0=Math.min(...bs.map(z=>z.box[1])),x1=Math.max(...bs.map(z=>z.box[2])),y1=Math.max(...bs.map(z=>z.box[3]));
 const pad=Math.max(x1-x0,y1-y0)*.35+50;view(x0-pad,y0-pad,x1+pad,y1+pad);}
function focusZone(id){const z=Z[ZI[id]];if(!z||!z.box)return;const pad=Math.max(z.box[2]-z.box[0],z.box[3]-z.box[1])*.6+50;view(z.box[0]-pad,z.box[1]-pad,z.box[2]+pad,z.box[3]+pad);}
// ---------- 그리기 ----------
function lines(test,col,w){ctx.strokeStyle=col;ctx.lineWidth=w;ctx.beginPath();
 for(let i=0;i<G.e.length;i+=3){if(!test(G.e[i+2]))continue;const a=S(G.x[G.e[i]],G.y[G.e[i]]),b=S(G.x[G.e[i+1]],G.y[G.e[i+1]]);ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);}ctx.stroke();}
function draw(){ctx.clearRect(0,0,W,H);ctx.lineCap='round';
 const lw=Math.max(.6,Math.min(2,.5+zoom*.12)),hot={};TOP.forEach(([z,r])=>{if(ZI[z]!=null&&!(ZI[z] in hot))hot[ZI[z]]=r;});
 lines(z=>z<0,css('--rail'),lw);lines(z=>z>=0&&!(z in hot),css('--zone'),lw);
 [3,2].forEach(r=>lines(z=>hot[z]===r,css('--sub'),Math.max(3,lw*2.4)));
 lines(z=>hot[z]===1,css('--l'+(R.lv||0)),Math.max(5,lw*3.6));
 // 라벨: 1위 · 2위 · 3위 먼저, 겹치면 뒤를 뺀다. 나머지 구역 번호는 확대하면
 ctx.textAlign='center';ctx.textBaseline='middle';const placed=[];
 const L=[...TOP.map(([z,r])=>[z,r]),...(zoom>=2.5?Z.map(z=>[z.id,9]):[])];const done={};
 for(const [id,r] of L){if(done[id])continue;done[id]=1;const z=Z[ZI[id]];if(!z||z.cx==null)continue;let [x,y]=S(z.cx,z.cy);if(x<-30||y<-30||x>W+30||y>H+30)continue;
  const big=r<=3,t=big?`${r}위 HID ${id}${z.bay?' · '+z.bay:''}`:id;ctx.font=big?'700 12.5px system-ui,sans-serif':'600 10.5px system-ui,sans-serif';
  const w=ctx.measureText(t).width+10;x=Math.max(w/2+2,Math.min(W-w/2-2,x));if(big)y-=16;
  const hit=yy=>placed.some(p=>Math.abs(p[0]-x)<(p[2]+w)/2&&Math.abs(p[1]-yy)<20);
  if(hit(y)){if(!big)continue;const alt=[y+24,y-24,y+48,y-48].find(yy=>!hit(yy));if(alt==null)continue;y=alt;}  // 1·2·3위는 비켜서라도 보인다
  placed.push([x,y,w]);
  if(big){ctx.fillStyle=r===1?css('--l'+(R.lv||0)):css('--sub');ctx.fillRect(x-w/2,y-10,w,20);ctx.fillStyle=(r===1&&R.lv===1)?'#222':'#fff';}
  else ctx.fillStyle=css('--fg2');
  ctx.fillText(t,x,y);}
 $('lg').innerHTML=`<b>${R.t}</b><i style="background:${css('--l'+(R.lv||0))}"></i>1위 구역 (${R.alarm})<i style="background:${css('--sub')}"></i>2·3위 구역<i style="background:${css('--zone')}"></i>다른 HID 구역`;}
// ---------- 조작 ----------
let drag=null;
cv.addEventListener('pointerdown',e=>{drag={x:e.clientX,y:e.clientY,px,py};cv.setPointerCapture(e.pointerId);cv.classList.add('drag');});
cv.addEventListener('pointermove',e=>{if(drag){px=drag.px+e.clientX-drag.x;py=drag.py+e.clientY-drag.y;draw();}else hover(e);});
cv.addEventListener('pointerup',()=>{drag=null;cv.classList.remove('drag');});
cv.addEventListener('wheel',e=>{e.preventDefault();const r=cv.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top,[wx,wy]=I(mx,my);
 zoom=Math.max(.5,Math.min(80,zoom*(e.deltaY<0?1.2:1/1.2)));const [sx,sy]=S(wx,wy);px+=mx-sx;py+=my-sy;draw();},{passive:false});
cv.addEventListener('dblclick',home);
function seg(x,y,a,b){const dx=b[0]-a[0],dy=b[1]-a[1],l=dx*dx+dy*dy;let t=l?((x-a[0])*dx+(y-a[1])*dy)/l:0;t=Math.max(0,Math.min(1,t));const qx=a[0]+t*dx-x,qy=a[1]+t*dy-y;return qx*qx+qy*qy;}
function hover(e){const r=cv.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;let best=-1,bd=12*12;
 for(let i=0;i<G.e.length;i+=3){const z=G.e[i+2];if(z<0)continue;const d=seg(mx,my,S(G.x[G.e[i]],G.y[G.e[i]]),S(G.x[G.e[i+1]],G.y[G.e[i+1]]));if(d<bd){bd=d;best=z;}}
 const tp=$('tip');if(best<0){tp.style.display='none';return;}const z=Z[best],rk=TOP.find(([id])=>id===z.id);
 tp.innerHTML=`<b>HID ${z.id}</b> ${z.name||''}${z.bay?' · '+z.bay:''}${rk?` — <b>${rk[1]}위</b>`:''}${z.vmax?`<br>정원(Vehicle_Max) ${z.vmax}`:''}`;
 tp.style.display='block';tp.style.left=Math.min(mx+12,W-240)+'px';tp.style.top=(my+12)+'px';}
$('bt-all').onclick=home;$('bt-z').onclick=focusTop;
// ---------- 오른쪽 ----------
const zname=id=>{const z=Z[ZI[id]];return z?`${z.name||''}${z.bay?' · '+z.bay:''}`:'⚠ 지도에 없는 구역';};
let h=`<h2>문제 구역 (그 1분)</h2>`;
if(!TOP.length)h+=`<div class="note">${R.lv?'구역 정보 없음':'정상 — 문제 구역 없음'}</div>`;
TOP.forEach(([id,r])=>{h+=`<div class="zone r${r}" data-z="${id}"><div class="t">${r}위 · HID ${id}</div><div class="s">${zname(id)}</div>`+
 (r===1?`<div class="s">구역 안 멈춘 차 <b>${R.zstop}</b> · 구역 안 차량 <b>${R.zvhl}</b> / 정원 ${R.vmax} · 점유율 <b>${R.occ}%</b></div>`:'')+`</div>`;});
h+=`<h2>그 1분 숫자</h2><table>
<tr><td>날짜 · 시간</td><td>${R.t}</td></tr><tr><td>ALARM</td><td>${R.alarm}</td></tr>
<tr><td>HID_ZONE · section</td><td>${R.z1} · ${R.sect}</td></tr>
<tr><td>OHT_report (보고 차량)</td><td>${R.n}</td></tr><tr><td>OHT_missing (미보고)</td><td>${R.miss}</td></tr>
<tr><td>OHT_JAM</td><td>${R.jam}</td></tr><tr><td>OHT_HT_STOP</td><td>${R.ht}</td></tr>
<tr><td>ZONE_STOP (구역 멈춘 차)</td><td>${R.zstop}</td></tr><tr><td>ZONE_VHL / VHL_MAX</td><td>${R.zvhl} / ${R.vmax}</td></tr>
<tr><td>ZONE_OCC (점유율)</td><td>${R.occ}%</td></tr><tr><td>HID_ZONE_2 · 3</td><td>${R.z2} · ${R.z3}</td></tr></table>`;
h+=`<h2>판정 근거 (지금 HID_CONFIG.json 기준)</h2>`+(D.why.length?`<ul>${D.why.map(w=>`<li>${w}</li>`).join('')}</ul>`:`<div class="note">지금 기준으로는 걸리는 조건 없음 — 판정 때 config 가 달랐을 수 있습니다.</div>`);
if(D.info.diff)h+=`<div class="warn">⚠ ${D.info.diff} — 결과를 만든 OHT_MAP 마스터와 지금 OHT_MAP 이 다릅니다.</div>`;
if(D.info.miss.length)h+=`<div class="warn">⚠ 지도에 없는 구역: ${D.info.miss.join(', ')} — 결과를 만든 OHT_MAP 마스터와 지금 OHT_MAP 이 같은지 확인하세요.</div>`;
h+=`<h2>맵</h2><div class="note">${D.info.layout} · 구역 번호 ${D.info.use}<br>${D.info.msg}<br>휠 확대 · 드래그 이동 · 더블클릭 전체 · 구역에 마우스를 올리면 이름</div>`;
$('side').innerHTML=h;
document.querySelectorAll('.zone[data-z]').forEach(el=>el.onclick=()=>focusZone(el.dataset.z));
addEventListener('resize',()=>{fit();focusTop();});fit();focusTop();
</script></body></html>
"""


# ==========================================================
def main():
    ap = argparse.ArgumentParser(description="판정된 시간 하나 → 문제맵(HTML)")
    ap.add_argument("fab", help=f"FAB ({' '.join(HB.FABS)})")
    ap.add_argument("when", nargs="*",
                    help="YYYYMMDDHHMM (그 1분, 여러 개 가능) 또는 YYYYMMDD (그 날 알람 시간 전부). "
                         "없으면 --csv 파일의 알람 줄 전부")
    ap.add_argument("--src", choices=["과거", "실시간"], default="과거",
                    help="과거 = HID_병목/과거판정/{FAB}/ (기본), 실시간 = HID_병목/{FAB}/")
    ap.add_argument("--csv", nargs="+", help="결과 파일 직접 지정 (날짜별 · 합치기 결과 · 한 줄짜리 다 됨)")
    ap.add_argument("--out", help="저장할 폴더 (기본 HID_병목/문제맵)")
    a = ap.parse_args()

    fab = a.fab.upper()
    if fab not in HB.FABS:
        sys.exit(f"FAB 은 {' '.join(HB.FABS)} 중 하나")
    whens = [w.replace("-", "").replace(":", "").replace(" ", "") for w in a.when]
    if any(not re.fullmatch(r"\d{8}|\d{12}", w) for w in whens):
        sys.exit("시간은 YYYYMMDDHHMM (그 1분) 또는 YYYYMMDD (그 날 알람 시간 전부)")
    if not whens and not a.csv:
        sys.exit("판정된 시간을 주세요 — 예) python HID_문제맵.py M16HUB 202609291348")

    days = sorted({w[:8] for w in whens})
    files = a.csv or _files(fab, a.src)
    if not files:
        where = (HB.PAST_DIR if a.src == "과거" else HB.OUT_DIR) / fab
        sys.exit(f"결과 파일 없음: {where}/HID병목_{fab}_*.csv — 먼저 python HID_병목구간.py {fab} 날짜 로 판정하세요")
    say(f"■ {fab} 문제맵")
    rows = read_rows(fab, files, days[0] if days else None, days[-1] if days else None)
    by_t = {r["t"]: r for r in rows}

    pick = []
    for w in whens:
        if len(w) == 12:
            k = f"{w[:4]}-{w[4:6]}-{w[6:8]} {w[8:10]}:{w[10:12]}"
            if k in by_t:
                pick.append(by_t[k])
            else:
                say(f"  ★{k} 줄 없음 — 그 시각 결과가 파일에 없습니다")
        else:
            d = f"{w[:4]}-{w[4:6]}-{w[6:8]}"
            al = [r for r in rows if r["t"].startswith(d) and r["alarm"] in LEVEL]
            say(f"  {d}: 판정된 알람 시간 {len(al)}개")
            pick += al
    if not whens:
        pick = [r for r in rows if r["alarm"] in LEVEL]
        say(f"  파일의 알람 줄 {len(pick)}개")
    pick = list(OrderedDict((r["t"], r) for r in pick).values())
    if not pick:
        sys.exit("만들 줄이 없습니다")

    m, err = load_map(fab)
    if not m:
        sys.exit(f"맵 없음 — {err}")
    use, hit, nv = pick_numbering(m["st"], pick)
    geo = geometry(m, use)
    have = {z["id"] for z in geo["zones"] if z["n"]}
    zbay = {z["id"]: z["bay"] for z in geo["zones"]}
    P = levels_now(fab)
    src = ", ".join(Path(f).name for f in files[:2]) + (f" 외 {len(files) - 2}개" if len(files) > 2 else "")
    out_base = Path(a.out) if a.out else MAP_OUT
    made = []
    for r in pick:
        miss = [z for z in (r["z1"], r["z2"], r["z3"]) if z not in ("", "0") and z not in have]
        bay = zbay.get(r["z1"], "")
        diff = (f"결과의 HID_section {r['sect']} ≠ 지도의 {bay} (HID {r['z1']})"
                if r["z1"] in zbay and r["sect"] not in ("", "0") and bay and r["sect"] != bay else "")
        info = {"layout": m["layout_file"], "msg": m["msg"], "use": use, "src": src, "miss": miss, "diff": diff}
        day, hm = r["t"][:10].replace("-", ""), r["t"][11:].replace(":", "")
        d = out_base / f"{fab}_{day}"
        d.mkdir(parents=True, exist_ok=True)
        p = d / f"문제맵_{fab}_{day}_{hm}_{r['alarm']}.html"
        p.write_text(build_html(fab, r, geo, info, reasons(r, P)), encoding="utf-8")
        made.append(p)
        say(f"  {r['t']} {r['alarm']:3} 1위 HID {r['z1']} ({r['sect']}) · 2·3위 {r['z2']} · {r['z3']}"
            f" · 구역 멈춘 차 {r['zstop']}{'  ⚠지도에 없음 ' + ','.join(miss) if miss else ''}"
            f"{'  ⚠' + diff if diff else ''}")
    say(f"  맵 {m['layout_file']} · 구역 번호 {use}")
    say(f"  → {made[0].parent}  ({len(made)}개)")


if __name__ == "__main__":
    main()
