# -*- coding: utf-8 -*-
"""
참고 자료 (MD/TXT) — 서버측 보관 + 검색 주입.

파일을 통째로 프롬프트에 넣으면 컨텍스트가 터진다.
예산(docBudget)을 넘으면 헤딩/빈줄 기준으로 문단을 쪼개고,
질문과 겹치는 단어가 많은 문단부터 예산이 찰 때까지 채워 넣는다.
(기존 app.js 의 docsContext 를 그대로 파이썬으로 옮긴 것)
"""
import json
import re
import threading

from . import config

_LOCK = threading.Lock()


class DocStore:
    def __init__(self, path):
        self.path = path          # data/docs.json
        self.docs = []            # [{name, text, on}]
        self._load()

    def _load(self):
        try:
            if self.path.is_file():
                self.docs = json.loads(self.path.read_text(encoding="utf-8")) or []
        except Exception:
            self.docs = []

    def _save(self):
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text(json.dumps(self.docs, ensure_ascii=False),
                                 encoding="utf-8")
        except Exception:
            pass

    # ── CRUD ─────────────────────────────────────────────────────────────
    def list(self):
        with _LOCK:
            return [{"name": d["name"], "on": d.get("on", True),
                     "chars": len(d["text"])} for d in self.docs]

    def add(self, name, text):
        text = str(text or "").replace("\r\n", "\n").strip()
        if not text:
            return False
        # ★CSV/TSV 는 저장 시점에 요약(digest)한다 — 원본 통째 저장은
        #   (a) DOCS_BYTES 300KB 총량을 혼자 밀어내고
        #   (b) llm.py 첨부 주입 상한(docBudget)에서 앞부분만 잘려
        #       '헤더+몇 줄' 짜리 무의미한 근거가 된다.
        if str(name or "").lower().endswith((".csv", ".tsv")):
            text = csv_digest(str(name), text)
        with _LOCK:
            # 총량 한도: 새 문서를 넣되 오래된 것부터 밀어낸다
            for d in self.docs:
                if d["name"] == name:
                    d["text"] = text
                    break
            else:
                self.docs.append({"name": name, "text": text, "on": True})
            while sum(len(d["text"]) for d in self.docs) > config.DOCS_BYTES \
                    and len(self.docs) > 1:
                self.docs.pop(0)
            self._save()
        return True

    def get(self, name):
        """이름으로 본문 — 채팅 첨부가 '방금 그 파일' 을 통째로 쓸 때."""
        with _LOCK:
            for d in self.docs:
                if d["name"] == name:
                    return d["text"]
        return None

    def toggle(self, name, on):
        with _LOCK:
            for d in self.docs:
                if d["name"] == name:
                    d["on"] = bool(on)
                    self._save()
                    return True
        return False

    def delete(self, name):
        with _LOCK:
            n = len(self.docs)
            self.docs = [d for d in self.docs if d["name"] != name]
            if len(self.docs) != n:
                self._save()
                return True
        return False

    def clear(self):
        with _LOCK:
            self.docs = []
            self._save()

    # ── 검색 주입 ─────────────────────────────────────────────────────────
    def context(self, query, budget):
        with _LOCK:
            act = [d for d in self.docs if d.get("on", True) and d["text"]]
        if not act:
            return ""
        whole = "\n\n".join("### " + d["name"] + "\n" + d["text"] for d in act)
        if len(whole) <= budget:
            return whole

        # 예산 초과 -> 문단 분해 + 질의어 겹침 점수순
        chunks = []
        for d in act:
            for c in re.split(r"\n(?=#{1,6}\s)|\n\s*\n", d["text"]):
                t = c.strip()
                if len(t) > 15:
                    chunks.append({"name": d["name"], "t": t, "score": 0})

        terms = re.findall(r"[가-힣A-Za-z0-9]{2,}", (query or "").lower())
        for c in chunks:
            low = c["t"].lower()
            for w in terms:
                if w in low:
                    c["score"] += len(w)
        chunks.sort(key=lambda c: -c["score"])

        out = ""
        for c in chunks:
            if len(out) + len(c["t"]) + len(c["name"]) + 8 > budget:
                continue
            out += "### " + c["name"] + "\n" + c["t"] + "\n\n"
            if len(out) > budget * 0.96:
                break
        return out or whole[:budget]


# ── CSV 요약 (digest) ─────────────────────────────────────────────────────
def csv_digest(name, text, budget=5500):
    """큰 CSV 를 LLM 이 분석할 수 있는 요약 한 덩어리로 바꾼다.

    설계 이유
        발동이벤트 CSV 같은 수백 KB~수 MB 파일을 그대로 프롬프트에 넣을 수
        없다. 대신 저장 시점에 ① 행수·컬럼 구조 ② 컬럼별 실측 통계
        (숫자면 min/max/평균, 범주면 상위값 건수) ③ 앞뒤 원본 행을 만든다.
        ★여기 나오는 숫자는 전부 이 함수가 원본에서 계산한 값이다 —
          llm.py 숫자 가드의 화이트리스트에 그대로 올라간다.
        budget 기본 5500 은 llm.py 첨부 주입 상한(docBudget 6000) 안에
        통째로 들어가는 크기다 — 요약이 다시 잘리는 일이 없다.
    실패하면(파싱 불가 등) 원본 앞 budget 자로 폴백 — 죽지는 않는다.
    """
    import csv as _csv
    import io
    try:
        try:
            delim = _csv.Sniffer().sniff(text[:4096], delimiters=",;\t|").delimiter
        except Exception:
            delim = "\t" if str(name).lower().endswith(".tsv") else ","
        rows = [r for r in _csv.reader(io.StringIO(text), delimiter=delim)
                if any(c.strip() for c in r)]
    except Exception:
        return text[:budget]
    if len(rows) < 2:
        return text[:budget]
    head, body = rows[0], rows[1:]
    L = ["[CSV 자동요약: {}]".format(name),
         "원본 {:,}행 × {}열 · 구분자 '{}' · 아래 숫자는 전부 원본에서 계산한 실측값".format(
             len(body), len(head), "TAB" if delim == "\t" else delim),
         "컬럼별 요약:"]
    for i, col in enumerate(head):
        cn = (col or "").strip() or "열{}".format(i + 1)
        vals = [r[i].strip() for r in body if i < len(r) and r[i].strip()]
        if not vals:
            L.append("- {}: (값 없음)".format(cn))
            continue
        nums = []
        for v in vals:
            try:
                nums.append(float(v.replace(",", "")))
            except ValueError:
                nums = None
                break
        if nums:
            L.append("- {}: 숫자 {:,}개 · min {:g} · max {:g} · 평균 {:.2f}".format(
                cn, len(nums), min(nums), max(nums), sum(nums) / len(nums)))
            continue
        uniq = {}
        for v in vals:
            uniq[v] = uniq.get(v, 0) + 1
        if len(uniq) > 20 and len(uniq) >= len(vals) * 0.9:
            # 거의 전부 고유 (시각·ID 류) — 범위만 보여 준다
            L.append("- {}: 고유 {:,}개 · 처음 {} … 끝 {}".format(
                cn, len(uniq), vals[0][:40], vals[-1][:40]))
        else:
            top = sorted(uniq.items(), key=lambda kv: -kv[1])[:6]
            L.append("- {}: 고유 {:,}개 · 상위 {}".format(
                cn, len(uniq),
                ", ".join("{}({:,}건)".format(k[:30], c) for k, c in top)))
    out = "\n".join(L)
    # 남은 예산에 앞·뒤 원본 행을 그대로 싣는다 (검산·개별행 질문용)
    raw = text.split("\n")
    header_line = raw[0] if raw else ""
    tail_n = min(5, len(raw) - 1)
    tail = ["", "[뒤 {}행 원본]".format(tail_n)] + raw[-tail_n:] if tail_n > 0 else []
    tail_len = sum(len(s) + 1 for s in tail)
    front = ["", "[앞부분 원본]", header_line]
    used = len(out) + tail_len + sum(len(s) + 1 for s in front)
    for line in raw[1:]:
        if used + len(line) + 1 > budget:
            break
        front.append(line)
        used += len(line) + 1
    if len(front) > 3:
        front[1] = "[앞 {}행 원본]".format(len(front) - 3)
        out += "\n".join(front)
    out += "\n".join(tail)
    return out[:budget + 500]


# ── 토큰 추정 (한글 0.72/자, 영숫자 3.6자당 1, 기타 0.45) ─────────────────
def est_tokens(s):
    if not s:
        return 0
    ko = latin = other = 0
    for ch in s:
        c = ord(ch)
        if (0xAC00 <= c <= 0xD7A3) or (0x3040 <= c <= 0x30FF) \
                or (0x4E00 <= c <= 0x9FFF) or (0x1100 <= c <= 0x11FF):
            ko += 1
        elif (48 <= c <= 57) or (65 <= c <= 90) or (97 <= c <= 122):
            latin += 1
        else:
            other += 1
    return round(ko * 0.72 + latin / 3.6 + other * 0.45)
