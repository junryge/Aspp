# -*- coding: utf-8 -*-
"""
s3_core.py
S3 / S3 호환 스토리지(MinIO 등) 조작 코어 로직.
GUI 와 완전히 분리되어 있으므로 CLI/배치에서도 그대로 재사용 가능.

의존성: boto3 (pip install boto3)
"""

import os
import json
import base64
import posixpath
from datetime import datetime

import boto3
from botocore.client import Config
from botocore.exceptions import ClientError, EndpointConnectionError, NoCredentialsError

try:
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
except Exception:
    pass


# --------------------------------------------------------------------------
# 유틸
# --------------------------------------------------------------------------
def human_size(n):
    """바이트 -> 사람이 읽는 크기"""
    if n is None:
        return ""
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB", "PB"):
        if n < 1024.0:
            return ("%d %s" % (n, unit)) if unit == "B" else ("%.1f %s" % (n, unit))
        n /= 1024.0
    return "%.1f EB" % n


def norm_prefix(prefix):
    """'a/b' -> 'a/b/', '' -> '' (루트)"""
    if not prefix:
        return ""
    prefix = prefix.strip().lstrip("/")
    if prefix and not prefix.endswith("/"):
        prefix += "/"
    return prefix


def join_key(prefix, name):
    prefix = norm_prefix(prefix)
    return prefix + name.lstrip("/")


def parent_prefix(prefix):
    """'a/b/c/' -> 'a/b/'"""
    p = norm_prefix(prefix)
    if not p:
        return ""
    parent = posixpath.dirname(p.rstrip("/"))
    return norm_prefix(parent)


class CancelledError(Exception):
    """사용자 취소"""
    pass


# --------------------------------------------------------------------------
# 접속 프로파일 저장소
# --------------------------------------------------------------------------
class ProfileStore(object):
    """
    접속정보를 ~/.s3gui/profiles.json 에 저장.
    * secret key 는 base64 로 인코딩만 한다(암호화 아님, 어깨너머 노출 방지용).
      파일 권한을 0600 으로 제한하지만, 보안 요구가 높으면 저장하지 말 것.
    """

    def __init__(self, path=None):
        base = os.path.join(os.path.expanduser("~"), ".s3gui")
        self.path = path or os.path.join(base, "profiles.json")
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self.data = {}
        self.load()

    def load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            out = {}
            for name, p in raw.items():
                p = dict(p)
                if p.get("secret_key"):
                    try:
                        p["secret_key"] = base64.b64decode(
                            p["secret_key"].encode("ascii")).decode("utf-8")
                    except Exception:
                        pass
                out[name] = p
            self.data = out
        except FileNotFoundError:
            self.data = {}
        except Exception:
            self.data = {}
        return self.data

    def save(self):
        raw = {}
        for name, p in self.data.items():
            p = dict(p)
            if p.get("secret_key"):
                p["secret_key"] = base64.b64encode(
                    p["secret_key"].encode("utf-8")).decode("ascii")
            raw[name] = p
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(raw, f, indent=2, ensure_ascii=False)
        os.replace(tmp, self.path)
        try:
            os.chmod(self.path, 0o600)
        except Exception:
            pass

    def names(self):
        return sorted(self.data.keys())

    def get(self, name):
        return dict(self.data.get(name, {}))

    def put(self, name, profile):
        self.data[name] = dict(profile)
        self.save()

    def remove(self, name):
        self.data.pop(name, None)
        self.save()


# --------------------------------------------------------------------------
# S3 코어
# --------------------------------------------------------------------------
class S3Core(object):
    """
    endpoint_url 이 비어 있으면 AWS S3, 채워져 있으면 S3 호환 스토리지(MinIO 등).
    """

    def __init__(self):
        self.s3 = None
        self.info = {}

    # ---------------- 연결 ----------------
    def connect(self, access_key, secret_key, region="ap-northeast-2",
                endpoint_url="", path_style=None, verify_ssl=True,
                session_token="", timeout=15):
        endpoint_url = (endpoint_url or "").strip()
        is_compat = bool(endpoint_url)

        # 호환 스토리지는 path-style 이 기본, AWS 는 virtual-hosted 가 기본
        if path_style is None:
            path_style = is_compat

        cfg = Config(
            signature_version="s3v4",
            s3={"addressing_style": "path" if path_style else "auto"},
            connect_timeout=timeout,
            read_timeout=max(timeout, 60),
            retries={"max_attempts": 3, "mode": "standard"},
        )

        kwargs = dict(
            service_name="s3",
            aws_access_key_id=access_key or None,
            aws_secret_access_key=secret_key or None,
            region_name=region or None,
            config=cfg,
            verify=bool(verify_ssl),
        )
        if session_token:
            kwargs["aws_session_token"] = session_token
        if endpoint_url:
            kwargs["endpoint_url"] = endpoint_url

        self.s3 = boto3.client(**kwargs)
        self.info = {
            "endpoint": endpoint_url or "AWS S3 (%s)" % (region or "default"),
            "region": region,
            "path_style": path_style,
            "verify_ssl": verify_ssl,
            "compat": is_compat,
        }
        # 접속 확인
        self.s3.list_buckets()
        return self.info

    def _check(self):
        if self.s3 is None:
            raise RuntimeError("S3 에 연결되어 있지 않습니다. 먼저 [연결] 하십시오.")

    # ---------------- 조회 ----------------
    def list_buckets(self):
        self._check()
        res = self.s3.list_buckets()
        out = []
        for b in res.get("Buckets", []):
            out.append({"name": b["Name"], "created": b.get("CreationDate")})
        return sorted(out, key=lambda x: x["name"])

    def list_dir(self, bucket, prefix=""):
        """
        해당 prefix 바로 아래의 (폴더목록, 파일목록) 반환.
        folders: ['a/b/', ...]   files: [{'key','size','modified'}...]
        """
        self._check()
        prefix = norm_prefix(prefix)
        folders, files = [], []
        paginator = self.s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter="/"):
            for cp in page.get("CommonPrefixes", []) or []:
                folders.append(cp["Prefix"])
            for obj in page.get("Contents", []) or []:
                key = obj["Key"]
                if key == prefix:          # 폴더 마커 자기 자신
                    continue
                if key.endswith("/"):      # 빈 폴더 마커
                    continue
                files.append({
                    "key": key,
                    "name": key[len(prefix):],
                    "size": obj.get("Size", 0),
                    "modified": obj.get("LastModified"),
                    "etag": (obj.get("ETag") or "").strip('"'),
                })
        folders.sort()
        files.sort(key=lambda x: x["name"].lower())
        return folders, files

    def list_all_keys(self, bucket, prefix=""):
        """prefix 하위 전체 객체(재귀)."""
        self._check()
        prefix = norm_prefix(prefix)
        out = []
        paginator = self.s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
            for obj in page.get("Contents", []) or []:
                out.append({"key": obj["Key"], "size": obj.get("Size", 0)})
        return out

    def exists(self, bucket, key):
        self._check()
        try:
            self.s3.head_object(Bucket=bucket, Key=key)
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] in ("404", "NoSuchKey", "NotFound"):
                return False
            raise

    # ---------------- 디렉토리 생성 ----------------
    def create_dir(self, bucket, prefix, name):
        """
        S3 에는 실제 디렉토리 개념이 없다.
        'prefix/name/' 이라는 0바이트 객체(폴더 마커)를 만들어 디렉토리처럼 쓴다.
        """
        self._check()
        name = name.strip().strip("/")
        if not name:
            raise ValueError("폴더 이름이 비어 있습니다.")
        for ch in ("\\",):
            if ch in name:
                raise ValueError("폴더 이름에 사용할 수 없는 문자: %s" % ch)
        key = norm_prefix(join_key(prefix, name))
        self.s3.put_object(Bucket=bucket, Key=key, Body=b"")
        return key

    def create_bucket(self, bucket, region=None):
        self._check()
        region = region or self.info.get("region")
        kwargs = {"Bucket": bucket}
        if region and region != "us-east-1":
            kwargs["CreateBucketConfiguration"] = {"LocationConstraint": region}
        try:
            self.s3.create_bucket(**kwargs)
        except ClientError as e:
            # MinIO 등은 LocationConstraint 를 거부하는 경우가 있다
            if "InvalidLocationConstraint" in str(e) or "InvalidArgument" in str(e):
                self.s3.create_bucket(Bucket=bucket)
            else:
                raise
        return bucket

    # ---------------- 업로드 ----------------
    def upload_file(self, bucket, key, local_path, callback=None, extra_args=None):
        self._check()
        self.s3.upload_file(local_path, bucket, key,
                            Callback=callback, ExtraArgs=extra_args or {})
        return key

    def upload_dir(self, bucket, prefix, local_dir,
                   callback=None, on_file=None, should_cancel=None):
        """
        로컬 디렉토리를 통째로 업로드(재귀).
        prefix 아래에 '로컬폴더명/' 을 만들고 그 하위로 올린다.
        """
        self._check()
        local_dir = os.path.abspath(local_dir)
        base_name = os.path.basename(local_dir.rstrip(os.sep))
        root_prefix = norm_prefix(join_key(prefix, base_name))

        targets = []
        for dirpath, dirnames, filenames in os.walk(local_dir):
            for fn in filenames:
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, local_dir).replace(os.sep, "/")
                targets.append((full, root_prefix + rel))
            if not filenames and not dirnames:
                rel = os.path.relpath(dirpath, local_dir).replace(os.sep, "/")
                if rel != ".":
                    self.s3.put_object(Bucket=bucket,
                                       Key=norm_prefix(root_prefix + rel), Body=b"")

        done = 0
        for full, key in targets:
            if should_cancel and should_cancel():
                raise CancelledError()
            if on_file:
                on_file(key, done + 1, len(targets))
            self.s3.upload_file(full, bucket, key, Callback=callback)
            done += 1
        return root_prefix, done

    # ---------------- 다운로드 ----------------
    def download_file(self, bucket, key, local_path, callback=None):
        self._check()
        d = os.path.dirname(os.path.abspath(local_path))
        if d:
            os.makedirs(d, exist_ok=True)
        self.s3.download_file(bucket, key, local_path, Callback=callback)
        return local_path

    def download_dir(self, bucket, prefix, local_dir,
                     callback=None, on_file=None, should_cancel=None):
        """prefix 하위 전체를 local_dir/<폴더명>/ 아래로 재귀 다운로드."""
        self._check()
        prefix = norm_prefix(prefix)
        base_name = prefix.rstrip("/").split("/")[-1] if prefix else bucket
        root = os.path.join(local_dir, base_name)

        objs = [o for o in self.list_all_keys(bucket, prefix)
                if not o["key"].endswith("/")]
        os.makedirs(root, exist_ok=True)

        done = 0
        for o in objs:
            if should_cancel and should_cancel():
                raise CancelledError()
            rel = o["key"][len(prefix):]
            dest = os.path.join(root, *rel.split("/"))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            if on_file:
                on_file(o["key"], done + 1, len(objs))
            self.s3.download_file(bucket, o["key"], dest, Callback=callback)
            done += 1
        return root, done

    # ---------------- 삭제 ----------------
    def delete_file(self, bucket, key):
        self._check()
        self.s3.delete_object(Bucket=bucket, Key=key)
        return key

    def delete_keys(self, bucket, keys, on_progress=None, should_cancel=None):
        """delete_objects 는 1회 최대 1000개."""
        self._check()
        keys = list(keys)
        total, done = len(keys), 0
        errors = []
        for i in range(0, total, 1000):
            if should_cancel and should_cancel():
                raise CancelledError()
            chunk = keys[i:i + 1000]
            res = self.s3.delete_objects(
                Bucket=bucket,
                Delete={"Objects": [{"Key": k} for k in chunk], "Quiet": True},
            )
            for err in res.get("Errors", []) or []:
                errors.append("%s: %s" % (err.get("Key"), err.get("Message")))
            done += len(chunk)
            if on_progress:
                on_progress(done, total)
        return done, errors

    def delete_dir(self, bucket, prefix, on_progress=None, should_cancel=None):
        """prefix 하위 전체 재귀 삭제(폴더 마커 포함)."""
        self._check()
        prefix = norm_prefix(prefix)
        if not prefix:
            raise ValueError("루트 전체 삭제는 허용하지 않습니다.")
        keys = [o["key"] for o in self.list_all_keys(bucket, prefix)]
        if not keys:
            # 객체가 없는 폴더 — 마커만 정리
            self.s3.delete_object(Bucket=bucket, Key=prefix)
            return 0, []
        done, errors = self.delete_keys(
            bucket, keys, on_progress=on_progress, should_cancel=should_cancel)
        if prefix not in keys:
            # 목록에 안 잡힌 폴더 마커가 있으면 함께 정리(카운트에는 미포함)
            self.s3.delete_object(Bucket=bucket, Key=prefix)
        return done, errors

    def delete_bucket(self, bucket, force=False):
        self._check()
        if force:
            keys = [o["key"] for o in self.list_all_keys(bucket, "")]
            if keys:
                self.delete_keys(bucket, keys)
        self.s3.delete_bucket(Bucket=bucket)
        return bucket


def fmt_time(dt):
    if not dt:
        return ""
    if isinstance(dt, datetime):
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    return str(dt)
