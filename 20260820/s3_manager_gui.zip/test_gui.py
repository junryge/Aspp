# -*- coding: utf-8 -*-
"""offscreen 으로 GUI 를 실제 기동해서 위젯/워커 동작 검증 (moto mock S3)"""
import os, sys, tempfile
os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ.setdefault("AWS_DEFAULT_REGION", "ap-northeast-2")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from moto import mock_aws
from PyQt5 import QtWidgets, QtCore

import s3_manager as M

OK = []
def check(n, c, extra=""):
    OK.append(c); print(("  PASS  " if c else "  FAIL  ") + n + ("  " + str(extra) if extra else ""))


def pump(ms=1500):
    """워커가 끝날 때까지 이벤트 루프 돌리기"""
    loop = QtCore.QEventLoop()
    t = QtCore.QTimer(); t.setSingleShot(True)
    t.timeout.connect(loop.quit); t.start(ms)
    loop.exec_()


@mock_aws
def run():
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    w = M.MainWindow()
    w.show()
    check("윈도우 기동", w.isVisible())
    check("초기 비활성", not w.act_del.isEnabled())

    # 연결 다이얼로그를 거치지 않고 코어만 직접 연결
    w.core.connect("test", "test", region="ap-northeast-2")
    w.core.create_bucket("m16a-mcs")
    w._set_connected(True)
    w.load_buckets()
    check("트리 버킷 로드", w.tree.topLevelItemCount() == 1,
          w.tree.topLevelItemCount())
    check("버튼 활성화", w.act_del.isEnabled())

    w.navigate("m16a-mcs", "")
    check("경로표시", w.ed_path.text() == "s3://m16a-mcs/", w.ed_path.text())

    # 폴더 생성
    w.core.create_dir("m16a-mcs", "", "hubroom")
    w.refresh_table()
    check("테이블 폴더 표시", w.table.rowCount() == 1 and w.table.item(0, 1).text() == "폴더")

    # 폴더 진입 (더블클릭)
    w.on_table_dblclick(0, 0)
    check("폴더 진입", w.prefix == "hubroom/", w.prefix)

    # 업로드 (워커 스레드 경유)
    tmp = tempfile.mkdtemp()
    p = os.path.join(tmp, "port_maxcap.log")
    open(p, "wb").write(b"MAXCAPACITY\n" * 5000)

    def job(worker):
        cb = M.ByteProgress(worker, os.path.getsize(p))
        w.core.upload_file("m16a-mcs", "hubroom/port_maxcap.log", p, callback=cb)
        return 1
    w.run_worker("테스트 업로드", job)
    pump(2500)
    check("워커 업로드 성공", w.core.exists("m16a-mcs", "hubroom/port_maxcap.log"))
    check("진행률 100%", w.progress.value() == 100, w.progress.value())

    w.refresh_table()
    names = [w.table.item(r, 0).text() for r in range(w.table.rowCount())]
    check("업로드 파일 목록", names == ["port_maxcap.log"], names)

    # 선택 -> 삭제 경로 (핵심 로직만)
    w.table.selectRow(0)
    sel = w.selected_rows()
    check("선택 파싱", sel == [("file", "hubroom/port_maxcap.log", "port_maxcap.log")], sel)

    # 상위폴더
    w.on_go_up()
    check("상위 이동", w.prefix == "", repr(w.prefix))

    # 경로 직접 입력
    w.ed_path.setText("s3://m16a-mcs/hubroom/")
    w.on_path_entered()
    check("경로 입력 이동", (w.bucket, w.prefix) == ("m16a-mcs", "hubroom/"))

    # 트리 확장 lazy load
    top = w.tree.topLevelItem(0)
    w.on_tree_expand(top)
    check("트리 lazy 확장", top.childCount() == 1 and top.child(0).text(0) == "hubroom",
          top.childCount())

    # 재귀 삭제
    n, errs = w.core.delete_dir("m16a-mcs", "hubroom/")
    check("디렉토리 재귀삭제", n == 2 and errs == [], (n, errs))  # 파일1 + 폴더마커1

    w.close()


if __name__ == "__main__":
    run()
    print("\n결과: %d/%d 통과" % (sum(1 for x in OK if x), len(OK)))
    sys.exit(0 if all(OK) else 1)
