# -*- coding: utf-8 -*-
"""moto 목(mock) S3 로 s3_core 전 기능 검증"""
import os, shutil, tempfile, sys
import boto3
from moto import mock_aws

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from s3_core import S3Core, human_size, norm_prefix, parent_prefix, ProfileStore

os.environ.setdefault("AWS_DEFAULT_REGION", "ap-northeast-2")
OK = []


def check(name, cond, extra=""):
    OK.append(cond)
    print(("  PASS  " if cond else "  FAIL  ") + name + ("  " + str(extra) if extra else ""))


@mock_aws
def run():
    core = S3Core()
    core.connect("test", "test", region="ap-northeast-2")
    check("connect", core.s3 is not None)

    # 버킷 생성 / 목록
    core.create_bucket("fab-logs")
    names = [b["name"] for b in core.list_buckets()]
    check("create_bucket + list_buckets", names == ["fab-logs"], names)

    # 1) 디렉토리 생성
    k = core.create_dir("fab-logs", "", "m14a")
    check("create_dir root", k == "m14a/", k)
    k2 = core.create_dir("fab-logs", "m14a/", "oht")
    check("create_dir nested", k2 == "m14a/oht/", k2)

    folders, files = core.list_dir("fab-logs", "")
    check("list_dir folders", folders == ["m14a/"], folders)
    check("list_dir hides marker", files == [], files)

    # 2) 파일 업로드
    tmp = tempfile.mkdtemp()
    p1 = os.path.join(tmp, "a.txt")
    open(p1, "wb").write(b"hello-oht" * 1000)
    core.upload_file("fab-logs", "m14a/oht/a.txt", p1)
    check("upload_file", core.exists("fab-logs", "m14a/oht/a.txt"))

    folders, files = core.list_dir("fab-logs", "m14a/oht/")
    check("list_dir files", [f["name"] for f in files] == ["a.txt"], files)
    check("file size", files[0]["size"] == 9000, files[0]["size"])

    # 3) 폴더 통째 업로드
    src = os.path.join(tmp, "batch")
    os.makedirs(os.path.join(src, "sub"))
    open(os.path.join(src, "1.csv"), "w").write("a,b\n1,2\n")
    open(os.path.join(src, "sub", "2.csv"), "w").write("c,d\n3,4\n")
    root, cnt = core.upload_dir("fab-logs", "m14a/", src)
    check("upload_dir root", root == "m14a/batch/", root)
    check("upload_dir count", cnt == 2, cnt)
    keys = sorted(o["key"] for o in core.list_all_keys("fab-logs", "m14a/batch/"))
    check("upload_dir keys", keys == ["m14a/batch/1.csv", "m14a/batch/sub/2.csv"], keys)

    # 4) 파일 다운로드
    dl = os.path.join(tmp, "dl")
    out = core.download_file("fab-logs", "m14a/oht/a.txt", os.path.join(dl, "a.txt"))
    check("download_file", os.path.getsize(out) == 9000)

    # 5) 폴더 다운로드
    root2, c2 = core.download_dir("fab-logs", "m14a/batch/", dl)
    check("download_dir count", c2 == 2, c2)
    check("download_dir tree",
          os.path.exists(os.path.join(root2, "sub", "2.csv")), root2)

    # 진행률 콜백 동작
    seen = []
    core.download_file("fab-logs", "m14a/oht/a.txt",
                       os.path.join(dl, "a2.txt"), callback=lambda n: seen.append(n))
    check("progress callback", sum(seen) == 9000, sum(seen))

    # 6) 파일 삭제
    core.delete_file("fab-logs", "m14a/oht/a.txt")
    check("delete_file", not core.exists("fab-logs", "m14a/oht/a.txt"))

    # 7) 디렉토리 재귀 삭제
    n, errs = core.delete_dir("fab-logs", "m14a/batch/")
    check("delete_dir count", n == 2, n)   # 실제 객체 2건 (폴더마커는 카운트 제외)
    check("delete_dir errors", errs == [], errs)
    check("delete_dir gone", core.list_all_keys("fab-logs", "m14a/batch/") == [])

    # 8) 1000개 초과 대량 삭제 (delete_objects 청크)
    for i in range(1050):
        core.s3.put_object(Bucket="fab-logs", Key="bulk/%04d.txt" % i, Body=b"x")
    n2, e2 = core.delete_dir("fab-logs", "bulk/")
    check("bulk delete >1000", n2 == 1050 and e2 == [], (n2, e2))

    # 9) 버킷 강제 삭제
    core.delete_bucket("fab-logs", force=True)
    check("delete_bucket", core.list_buckets() == [])

    shutil.rmtree(tmp, ignore_errors=True)


def run_plain():
    check("human_size", human_size(1536) == "1.5 KB", human_size(1536))
    check("norm_prefix", norm_prefix("a/b") == "a/b/")
    check("norm_prefix empty", norm_prefix("") == "")
    check("parent_prefix", parent_prefix("a/b/c/") == "a/b/", parent_prefix("a/b/c/"))
    check("parent_prefix top", parent_prefix("a/") == "", repr(parent_prefix("a/")))

    tmp = tempfile.mkdtemp()
    st = ProfileStore(os.path.join(tmp, "p.json"))
    st.put("사내MinIO", {"endpoint_url": "http://10.1.1.1:9000",
                        "access_key": "AK", "secret_key": "S3CR3T!한글",
                        "path_style": True, "verify_ssl": False})
    st2 = ProfileStore(os.path.join(tmp, "p.json"))
    g = st2.get("사내MinIO")
    check("profile roundtrip", g.get("secret_key") == "S3CR3T!한글", g)
    check("profile perm", oct(os.stat(st.path).st_mode)[-3:] == "600",
          oct(os.stat(st.path).st_mode))
    st2.remove("사내MinIO")
    check("profile remove", ProfileStore(os.path.join(tmp, "p.json")).names() == [])
    shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    print("--- 순수 함수 / 프로파일 ---")
    run_plain()
    print("--- S3 코어 (moto mock) ---")
    run()
    print("\n결과: %d/%d 통과" % (sum(1 for x in OK if x), len(OK)))
    sys.exit(0 if all(OK) else 1)
