# S3 Manager (PyQt5 GUI)

S3 / S3 호환 스토리지(MinIO 등)용 파일 관리 GUI.

## 구성

| 파일 | 설명 |
|---|---|
| `s3_core.py` | boto3 래퍼. GUI 없이 CLI/배치에서도 그대로 재사용 가능 |
| `s3_manager.py` | PyQt5 GUI (PySide6 자동 폴백) |
| `test_core.py` | moto 목 S3 기반 코어 검증 (30건) |
| `test_gui.py` | offscreen GUI 기동 검증 (15건) |

## 설치 / 실행

```bash
pip install boto3 PyQt5
python s3_manager.py
```

폐쇄망이면 wheel 을 미리 받아 두고:

```bash
pip download boto3 PyQt5 -d ./wheels        # 외부망
pip install --no-index --find-links=./wheels boto3 PyQt5   # 내부망
```

PyQt5 반입이 불가능하면 `PySide6` 만 있어도 그대로 동작한다 (import 시 자동 분기).

## 접속

`[연결]` 버튼 → 접속 설정 다이얼로그.

- **Endpoint URL 비움** → AWS S3 (region 기반, virtual-hosted 주소)
- **Endpoint URL 입력** → S3 호환 스토리지. path-style 주소가 자동 기본값
  - 예: `http://10.20.30.40:9000`
- **SSL 인증서 검증** 체크 해제 → 사설 인증서 환경 대응 (`verify=False`)
- **프로파일로 저장** → `~/.s3gui/profiles.json` (권한 0600)

> Secret Key 는 base64 인코딩만 되어 저장된다. **암호화가 아니다.**
> 보안 등급이 높은 망에서는 저장하지 말고 매번 입력할 것.

## 기능

| 기능 | 동작 |
|---|---|
| 디렉토리 생성 | `prefix/name/` 0바이트 폴더 마커 객체 생성 |
| 버킷 생성 | `create_bucket` (MinIO 의 LocationConstraint 거부 시 자동 재시도) |
| 파일 업로드 | 다중 선택. 진행률은 전체 바이트 기준 |
| 폴더 업로드 | `os.walk` 재귀. 빈 하위폴더도 마커로 보존 |
| 다운로드 | 파일/폴더 혼합 선택 가능. 폴더는 트리 구조 그대로 복원 |
| 파일 삭제 | `delete_object` |
| 디렉토리 삭제 | prefix 하위 전체 재귀. `delete_objects` 1000개 단위 청크 |

부가:

- 좌측 **트리 브라우저** — 버킷/폴더 lazy 로딩, 클릭 시 우측 목록 이동
- 우측 **목록 테이블** — 폴더 더블클릭 진입, 다중 선택, 우클릭 메뉴
- **경로 입력창** — `s3://bucket/prefix/` 직접 입력 후 엔터로 이동
- **백그라운드 스레드 + 진행률바 + 취소** — 대용량 전송 중에도 GUI 안 멈춤
- 하단 **로그창** — 모든 작업 이력, 예외 발생 시 traceback 전체 기록

## S3 에는 디렉토리가 없다

S3 는 flat key-value 스토어다. `a/b/c.txt` 의 `/` 는 그냥 키 문자열의 일부다.
이 프로그램은 두 가지로 디렉토리를 흉내낸다.

1. 조회: `list_objects_v2(Delimiter='/')` 의 `CommonPrefixes` 를 폴더로 표시
2. 생성: `a/b/` 라는 0바이트 객체(폴더 마커)를 넣어 빈 폴더도 보이게 함

따라서 **빈 폴더 생성 → 파일 업로드 → 폴더 삭제** 가 파일시스템처럼 동작한다.
단, 다른 도구가 만든 폴더는 마커가 없을 수 있는데, 그 경우에도 하위에 객체가
있으면 트리에 정상 표시된다.

## 검증

```bash
pip install moto
python test_core.py     # 30/30 통과
python test_gui.py      # 15/15 통과 (offscreen)
```

`test_core.py` 는 1050개 객체 대량 삭제(1000개 청크 분할)까지 확인한다.

## 주의

- 삭제는 **복구 불가**다. 폴더 삭제 시 하위 객체 수를 확인 다이얼로그에 표시한다.
- 버킷 버저닝이 켜져 있으면 `delete_object` 는 delete marker 만 남기고
  이전 버전은 유지된다. 완전 삭제가 필요하면 `list_object_versions` 기반
  로직을 추가해야 한다.
- 멀티파트 임계값은 boto3 기본(8MB)을 사용한다. 회선이 느리면
  `s3_core.py` 의 `upload_file` 에 `TransferConfig(multipart_threshold=..., max_concurrency=...)`
  를 지정해 조정할 것.
