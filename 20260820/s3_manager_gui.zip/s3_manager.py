# -*- coding: utf-8 -*-
"""
s3_manager.py  --  S3 / S3호환 스토리지 GUI 관리자

기능
  * 디렉토리(폴더) 생성
  * 파일 업로드 / 다운로드  (폴더 통째로 가능)
  * 파일 삭제 / 디렉토리 재귀 삭제
  * 좌측 트리 브라우저 + 우측 목록 테이블
  * 백그라운드 스레드 + 진행률 표시 + 취소
  * 접속 프로파일 저장 (~/.s3gui/profiles.json)

실행
  pip install boto3 PyQt5          (PySide6 도 자동 지원)
  python s3_manager.py
"""

import os
import sys
import time
import traceback

# --------------------------------------------------------------------------
# Qt 바인딩 호환 레이어 (PyQt5 우선, 없으면 PySide6)
# --------------------------------------------------------------------------
QT_LIB = None
try:
    from PyQt5 import QtCore, QtGui, QtWidgets
    from PyQt5.QtCore import pyqtSignal as Signal
    QT_LIB = "PyQt5"
except ImportError:  # pragma: no cover
    try:
        from PySide6 import QtCore, QtGui, QtWidgets
        from PySide6.QtCore import Signal
        QT_LIB = "PySide6"
    except ImportError:
        sys.stderr.write("PyQt5 또는 PySide6 가 필요합니다.  pip install PyQt5\n")
        raise

Qt = QtCore.Qt
# QAction 위치가 PyQt5(QtWidgets) / PySide6(QtGui) 로 다르다
QAction = getattr(QtWidgets, "QAction", None) or QtGui.QAction

from s3_core import (S3Core, ProfileStore, CancelledError,
                     human_size, fmt_time, norm_prefix, join_key, parent_prefix)


APP_NAME = "S3 Manager"
APP_VER = "1.0"


# ==========================================================================
# 백그라운드 워커
# ==========================================================================
class Worker(QtCore.QThread):
    """
    fn(worker, *args) 를 별도 스레드에서 실행한다.
    fn 안에서 worker.log() / worker.progress() / worker.check_cancel() 사용.
    """
    sig_log = Signal(str)
    sig_progress = Signal(int, int, str)   # done, total, 설명
    sig_done = Signal(bool, str, object)   # ok, message, result

    def __init__(self, title, fn, *args, **kwargs):
        super(Worker, self).__init__()
        self.title = title
        self._fn = fn
        self._args = args
        self._kwargs = kwargs
        self._cancel = False
        self._last_emit = 0.0

    # --- fn 에서 호출 ---
    def log(self, msg):
        self.sig_log.emit(msg)

    def progress(self, done, total, text="", force=False):
        now = time.time()
        if force or (now - self._last_emit) > 0.08 or done >= total:
            self._last_emit = now
            self.sig_progress.emit(int(done), int(total), text)

    def cancelled(self):
        return self._cancel

    def check_cancel(self):
        if self._cancel:
            raise CancelledError()

    def cancel(self):
        self._cancel = True

    def run(self):
        try:
            result = self._fn(self, *self._args, **self._kwargs)
            self.sig_done.emit(True, "%s 완료" % self.title, result)
        except CancelledError:
            self.sig_done.emit(False, "%s 취소됨" % self.title, None)
        except Exception as e:
            self.sig_log.emit(traceback.format_exc())
            self.sig_done.emit(False, "%s 실패: %s" % (self.title, e), None)


class ByteProgress(object):
    """boto3 transfer Callback -> 워커 진행률"""

    def __init__(self, worker, total_bytes, text=""):
        self.worker = worker
        self.total = max(int(total_bytes), 1)
        self.done = 0
        self.text = text

    def __call__(self, n):
        self.done += n
        self.worker.progress(min(self.done, self.total), self.total, self.text)
        if self.worker.cancelled():
            raise CancelledError()

    def set_text(self, t):
        self.text = t


# ==========================================================================
# 접속 설정 다이얼로그
# ==========================================================================
class ConnectDialog(QtWidgets.QDialog):
    def __init__(self, store, parent=None):
        super(ConnectDialog, self).__init__(parent)
        self.store = store
        self.result_profile = None
        self.setWindowTitle("S3 접속 설정")
        self.setMinimumWidth(520)

        self.cmb_profile = QtWidgets.QComboBox()
        self.cmb_profile.setEditable(True)
        self.cmb_profile.addItem("")
        for n in self.store.names():
            self.cmb_profile.addItem(n)
        self.cmb_profile.currentIndexChanged.connect(self._load_profile)

        self.ed_endpoint = QtWidgets.QLineEdit()
        self.ed_endpoint.setPlaceholderText(
            "비우면 AWS S3.  사내 스토리지면 http://10.x.x.x:9000 형태로 입력")
        self.ed_region = QtWidgets.QLineEdit("ap-northeast-2")
        self.ed_access = QtWidgets.QLineEdit()
        self.ed_secret = QtWidgets.QLineEdit()
        self.ed_secret.setEchoMode(QtWidgets.QLineEdit.Password)
        self.ed_token = QtWidgets.QLineEdit()
        self.ed_token.setPlaceholderText("(선택) STS 세션 토큰")

        self.chk_pathstyle = QtWidgets.QCheckBox("Path-style 주소 강제 (MinIO/사내 스토리지 권장)")
        self.chk_verify = QtWidgets.QCheckBox("SSL 인증서 검증")
        self.chk_verify.setChecked(True)
        self.chk_save = QtWidgets.QCheckBox("이 접속정보를 프로파일로 저장")

        self.btn_show = QtWidgets.QPushButton("보기")
        self.btn_show.setCheckable(True)
        self.btn_show.setFixedWidth(50)
        self.btn_show.toggled.connect(
            lambda on: self.ed_secret.setEchoMode(
                QtWidgets.QLineEdit.Normal if on else QtWidgets.QLineEdit.Password))

        self.btn_del = QtWidgets.QPushButton("프로파일 삭제")
        self.btn_del.clicked.connect(self._delete_profile)

        sec_row = QtWidgets.QHBoxLayout()
        sec_row.addWidget(self.ed_secret)
        sec_row.addWidget(self.btn_show)
        sec_w = QtWidgets.QWidget()
        sec_w.setLayout(sec_row)
        sec_row.setContentsMargins(0, 0, 0, 0)

        prof_row = QtWidgets.QHBoxLayout()
        prof_row.addWidget(self.cmb_profile, 1)
        prof_row.addWidget(self.btn_del)
        prof_w = QtWidgets.QWidget()
        prof_w.setLayout(prof_row)
        prof_row.setContentsMargins(0, 0, 0, 0)

        form = QtWidgets.QFormLayout()
        form.addRow("프로파일", prof_w)
        form.addRow("Endpoint URL", self.ed_endpoint)
        form.addRow("Region", self.ed_region)
        form.addRow("Access Key", self.ed_access)
        form.addRow("Secret Key", sec_w)
        form.addRow("Session Token", self.ed_token)
        form.addRow("", self.chk_pathstyle)
        form.addRow("", self.chk_verify)
        form.addRow("", self.chk_save)

        note = QtWidgets.QLabel(
            "※ 프로파일 저장 시 Secret Key 가 ~/.s3gui/profiles.json 에 남습니다(암호화 아님).\n"
            "   보안 요구가 높은 환경에서는 저장하지 말고 매번 입력하십시오.")
        note.setStyleSheet("color:#b06000;")

        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel)
        buttons.button(QtWidgets.QDialogButtonBox.Ok).setText("연결")
        buttons.button(QtWidgets.QDialogButtonBox.Cancel).setText("취소")
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)

        lay = QtWidgets.QVBoxLayout(self)
        lay.addLayout(form)
        lay.addWidget(note)
        lay.addWidget(buttons)

    def _load_profile(self):
        name = self.cmb_profile.currentText().strip()
        p = self.store.get(name)
        if not p:
            return
        self.ed_endpoint.setText(p.get("endpoint_url", ""))
        self.ed_region.setText(p.get("region", ""))
        self.ed_access.setText(p.get("access_key", ""))
        self.ed_secret.setText(p.get("secret_key", ""))
        self.ed_token.setText(p.get("session_token", ""))
        self.chk_pathstyle.setChecked(bool(p.get("path_style", False)))
        self.chk_verify.setChecked(bool(p.get("verify_ssl", True)))
        self.chk_save.setChecked(True)

    def _delete_profile(self):
        name = self.cmb_profile.currentText().strip()
        if not name or name not in self.store.names():
            return
        if QtWidgets.QMessageBox.question(
                self, "확인", "프로파일 '%s' 을(를) 삭제할까요?" % name) \
                != QtWidgets.QMessageBox.Yes:
            return
        self.store.remove(name)
        idx = self.cmb_profile.currentIndex()
        self.cmb_profile.removeItem(idx)

    def _accept(self):
        prof = {
            "endpoint_url": self.ed_endpoint.text().strip(),
            "region": self.ed_region.text().strip(),
            "access_key": self.ed_access.text().strip(),
            "secret_key": self.ed_secret.text(),
            "session_token": self.ed_token.text().strip(),
            "path_style": self.chk_pathstyle.isChecked(),
            "verify_ssl": self.chk_verify.isChecked(),
        }
        if not prof["access_key"] or not prof["secret_key"]:
            QtWidgets.QMessageBox.warning(self, "확인", "Access Key / Secret Key 를 입력하십시오.")
            return
        name = self.cmb_profile.currentText().strip()
        if self.chk_save.isChecked():
            if not name:
                QtWidgets.QMessageBox.warning(self, "확인", "저장할 프로파일 이름을 입력하십시오.")
                return
            self.store.put(name, prof)
        self.result_profile = prof
        self.accept()


# ==========================================================================
# 메인 윈도우
# ==========================================================================
class MainWindow(QtWidgets.QMainWindow):

    ROLE_KIND = Qt.UserRole          # 'bucket' | 'folder'
    ROLE_BUCKET = Qt.UserRole + 1
    ROLE_PREFIX = Qt.UserRole + 2
    ROLE_LOADED = Qt.UserRole + 3

    def __init__(self):
        super(MainWindow, self).__init__()
        self.core = S3Core()
        self.store = ProfileStore()
        self.worker = None
        self.bucket = None
        self.prefix = ""

        self.setWindowTitle("%s %s" % (APP_NAME, APP_VER))
        self.resize(1180, 760)
        self._build_ui()
        self._set_connected(False)

    # ---------------------------------------------------------------- UI
    def _build_ui(self):
        # ----- 툴바 -----
        tb = self.addToolBar("main")
        tb.setMovable(False)
        tb.setIconSize(QtCore.QSize(16, 16))
        tb.setToolButtonStyle(Qt.ToolButtonTextOnly)

        def act(text, slot, tip=""):
            a = QAction(text, self)
            a.setToolTip(tip or text)
            a.triggered.connect(slot)
            tb.addAction(a)
            return a

        self.act_connect = act("연결", self.on_connect)
        self.act_disconnect = act("연결해제", self.on_disconnect)
        tb.addSeparator()
        self.act_refresh = act("새로고침 (F5)", self.on_refresh)
        self.act_up = act("상위폴더", self.on_go_up)
        tb.addSeparator()
        self.act_mkdir = act("폴더 생성", self.on_mkdir)
        self.act_mkbucket = act("버킷 생성", self.on_mkbucket)
        tb.addSeparator()
        self.act_up_file = act("파일 업로드", self.on_upload_files)
        self.act_up_dir = act("폴더 업로드", self.on_upload_dir)
        self.act_down = act("다운로드", self.on_download)
        tb.addSeparator()
        self.act_del = act("삭제", self.on_delete)

        self.act_refresh.setShortcut("F5")
        self.act_del.setShortcut(QtGui.QKeySequence.Delete)

        # ----- 경로 표시줄 -----
        self.lbl_conn = QtWidgets.QLabel("미연결")
        self.lbl_conn.setStyleSheet("color:#888;")
        self.ed_path = QtWidgets.QLineEdit()
        self.ed_path.setPlaceholderText("s3://bucket/prefix/  (엔터로 이동)")
        self.ed_path.returnPressed.connect(self.on_path_entered)

        path_bar = QtWidgets.QHBoxLayout()
        path_bar.addWidget(QtWidgets.QLabel("경로"))
        path_bar.addWidget(self.ed_path, 1)
        path_bar.addWidget(self.lbl_conn)

        # ----- 좌측 트리 -----
        self.tree = QtWidgets.QTreeWidget()
        self.tree.setHeaderLabels(["버킷 / 폴더"])
        self.tree.setMinimumWidth(280)
        self.tree.itemExpanded.connect(self.on_tree_expand)
        self.tree.itemClicked.connect(self.on_tree_click)

        # ----- 우측 목록 -----
        self.table = QtWidgets.QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["이름", "종류", "크기", "수정시각"])
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.setSortingEnabled(False)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(0, QtWidgets.QHeaderView.Stretch)
        hh.setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(3, QtWidgets.QHeaderView.ResizeToContents)
        self.table.cellDoubleClicked.connect(self.on_table_dblclick)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.on_table_menu)

        split_top = QtWidgets.QSplitter(Qt.Horizontal)
        split_top.addWidget(self.tree)
        split_top.addWidget(self.table)
        split_top.setStretchFactor(0, 0)
        split_top.setStretchFactor(1, 1)
        split_top.setSizes([300, 860])

        # ----- 로그 -----
        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumBlockCount(3000)
        self.log.setFont(QtGui.QFont("Consolas" if os.name == "nt" else "Monospace", 9))

        split_main = QtWidgets.QSplitter(Qt.Vertical)
        top_w = QtWidgets.QWidget()
        tl = QtWidgets.QVBoxLayout(top_w)
        tl.setContentsMargins(0, 0, 0, 0)
        tl.addLayout(path_bar)
        tl.addWidget(split_top, 1)
        split_main.addWidget(top_w)
        split_main.addWidget(self.log)
        split_main.setSizes([560, 160])

        self.setCentralWidget(split_main)

        # ----- 하단 상태/진행률 -----
        self.progress = QtWidgets.QProgressBar()
        self.progress.setMaximumWidth(320)
        self.progress.setValue(0)
        self.progress.setTextVisible(True)
        self.btn_cancel = QtWidgets.QPushButton("취소")
        self.btn_cancel.setEnabled(False)
        self.btn_cancel.clicked.connect(self.on_cancel)

        sb = self.statusBar()
        sb.addPermanentWidget(self.progress)
        sb.addPermanentWidget(self.btn_cancel)
        sb.showMessage("준비")

    def _set_connected(self, ok):
        for a in (self.act_disconnect, self.act_refresh, self.act_up,
                  self.act_mkdir, self.act_mkbucket, self.act_up_file,
                  self.act_up_dir, self.act_down, self.act_del):
            a.setEnabled(ok)
        self.act_connect.setEnabled(not ok)
        if not ok:
            self.tree.clear()
            self.table.setRowCount(0)
            self.ed_path.clear()
            self.lbl_conn.setText("미연결")
            self.lbl_conn.setStyleSheet("color:#888;")

    # ------------------------------------------------------------- 로그
    def logline(self, msg):
        ts = time.strftime("%H:%M:%S")
        self.log.appendPlainText("[%s] %s" % (ts, msg))

    def busy(self):
        return self.worker is not None and self.worker.isRunning()

    def run_worker(self, title, fn, *args, on_ok=None):
        if self.busy():
            QtWidgets.QMessageBox.information(self, "대기", "이전 작업이 진행 중입니다.")
            return None
        self.worker = Worker(title, fn, *args)
        self.worker.sig_log.connect(self.logline)
        self.worker.sig_progress.connect(self._on_progress)
        self.worker.sig_done.connect(
            lambda ok, msg, res: self._on_worker_done(ok, msg, res, on_ok))
        self.btn_cancel.setEnabled(True)
        self.progress.setValue(0)
        self.statusBar().showMessage("%s ..." % title)
        self.logline("▶ %s 시작" % title)
        self.worker.start()
        return self.worker

    def _on_progress(self, done, total, text):
        total = max(total, 1)
        self.progress.setMaximum(100)
        self.progress.setValue(int(done * 100 / total))
        if text:
            self.statusBar().showMessage(text)

    def _on_worker_done(self, ok, msg, result, on_ok):
        self.btn_cancel.setEnabled(False)
        self.progress.setValue(100 if ok else 0)
        self.statusBar().showMessage(msg)
        self.logline(("✔ " if ok else "✖ ") + msg)
        self.worker = None
        if ok and on_ok:
            try:
                on_ok(result)
            except Exception:
                self.logline(traceback.format_exc())

    def on_cancel(self):
        if self.busy():
            self.worker.cancel()
            self.logline("취소 요청...")

    # --------------------------------------------------------- 연결/해제
    def on_connect(self):
        dlg = ConnectDialog(self.store, self)
        if dlg.exec_() if hasattr(dlg, "exec_") else dlg.exec():
            p = dlg.result_profile
            try:
                info = self.core.connect(
                    access_key=p["access_key"],
                    secret_key=p["secret_key"],
                    region=p["region"],
                    endpoint_url=p["endpoint_url"],
                    path_style=p["path_style"] or None,
                    verify_ssl=p["verify_ssl"],
                    session_token=p.get("session_token", ""),
                )
            except Exception as e:
                QtWidgets.QMessageBox.critical(self, "연결 실패", str(e))
                self.logline("연결 실패: %s" % e)
                return
            self.lbl_conn.setText("연결됨: %s" % info["endpoint"])
            self.lbl_conn.setStyleSheet("color:#0a0; font-weight:bold;")
            self.logline("연결됨: %s (path_style=%s, ssl_verify=%s)"
                         % (info["endpoint"], info["path_style"], info["verify_ssl"]))
            self._set_connected(True)
            self.load_buckets()

    def on_disconnect(self):
        self.core = S3Core()
        self.bucket, self.prefix = None, ""
        self._set_connected(False)
        self.logline("연결 해제")

    # --------------------------------------------------------- 트리/목록
    def load_buckets(self):
        self.tree.clear()
        try:
            buckets = self.core.list_buckets()
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "오류", str(e))
            return
        for b in buckets:
            it = QtWidgets.QTreeWidgetItem([b["name"]])
            it.setData(0, self.ROLE_KIND, "bucket")
            it.setData(0, self.ROLE_BUCKET, b["name"])
            it.setData(0, self.ROLE_PREFIX, "")
            it.setData(0, self.ROLE_LOADED, False)
            it.setIcon(0, self.style().standardIcon(QtWidgets.QStyle.SP_DriveHDIcon))
            it.addChild(QtWidgets.QTreeWidgetItem(["로딩중..."]))
            self.tree.addTopLevelItem(it)
        self.logline("버킷 %d 개" % len(buckets))

    def on_tree_expand(self, item):
        if item.data(0, self.ROLE_LOADED):
            return
        bucket = item.data(0, self.ROLE_BUCKET)
        prefix = item.data(0, self.ROLE_PREFIX) or ""
        item.takeChildren()
        item.setData(0, self.ROLE_LOADED, True)
        try:
            folders, _ = self.core.list_dir(bucket, prefix)
        except Exception as e:
            self.logline("목록 실패: %s" % e)
            return
        icon = self.style().standardIcon(QtWidgets.QStyle.SP_DirIcon)
        for f in folders:
            name = f[len(norm_prefix(prefix)):].rstrip("/")
            child = QtWidgets.QTreeWidgetItem([name])
            child.setData(0, self.ROLE_KIND, "folder")
            child.setData(0, self.ROLE_BUCKET, bucket)
            child.setData(0, self.ROLE_PREFIX, f)
            child.setData(0, self.ROLE_LOADED, False)
            child.setIcon(0, icon)
            child.addChild(QtWidgets.QTreeWidgetItem(["로딩중..."]))
            item.addChild(child)

    def on_tree_click(self, item, col):
        bucket = item.data(0, self.ROLE_BUCKET)
        if not bucket:
            return
        self.navigate(bucket, item.data(0, self.ROLE_PREFIX) or "")

    def navigate(self, bucket, prefix):
        self.bucket = bucket
        self.prefix = norm_prefix(prefix)
        self.ed_path.setText("s3://%s/%s" % (bucket, self.prefix))
        self.refresh_table()

    def refresh_table(self):
        self.table.setRowCount(0)
        if not self.bucket:
            return
        try:
            folders, files = self.core.list_dir(self.bucket, self.prefix)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "오류", str(e))
            return

        dir_icon = self.style().standardIcon(QtWidgets.QStyle.SP_DirIcon)
        file_icon = self.style().standardIcon(QtWidgets.QStyle.SP_FileIcon)
        rows = []
        for f in folders:
            rows.append(("dir", f[len(self.prefix):].rstrip("/"), f, None, None))
        for f in files:
            rows.append(("file", f["name"], f["key"], f["size"], f["modified"]))

        self.table.setRowCount(len(rows))
        for r, (kind, name, key, size, mtime) in enumerate(rows):
            it0 = QtWidgets.QTableWidgetItem(name)
            it0.setIcon(dir_icon if kind == "dir" else file_icon)
            it0.setData(Qt.UserRole, (kind, key))
            self.table.setItem(r, 0, it0)
            self.table.setItem(r, 1, QtWidgets.QTableWidgetItem(
                "폴더" if kind == "dir" else "파일"))
            it2 = QtWidgets.QTableWidgetItem("" if size is None else human_size(size))
            it2.setTextAlignment(int(Qt.AlignRight | Qt.AlignVCenter))
            self.table.setItem(r, 2, it2)
            self.table.setItem(r, 3, QtWidgets.QTableWidgetItem(fmt_time(mtime)))

        total = sum(f["size"] for f in files)
        self.statusBar().showMessage(
            "폴더 %d / 파일 %d / 합계 %s" % (len(folders), len(files), human_size(total)))

    def selected_rows(self):
        out = []
        for idx in sorted({i.row() for i in self.table.selectedIndexes()}):
            it = self.table.item(idx, 0)
            if it:
                kind, key = it.data(Qt.UserRole)
                out.append((kind, key, it.text()))
        return out

    def on_table_dblclick(self, row, col):
        it = self.table.item(row, 0)
        if not it:
            return
        kind, key = it.data(Qt.UserRole)
        if kind == "dir":
            self.navigate(self.bucket, key)

    def on_table_menu(self, pos):
        menu = QtWidgets.QMenu(self)
        menu.addAction("다운로드", self.on_download)
        menu.addAction("삭제", self.on_delete)
        menu.addSeparator()
        menu.addAction("키(Key) 복사", self.on_copy_key)
        menu.addAction("새로고침", self.on_refresh)
        menu.exec_(self.table.viewport().mapToGlobal(pos)) \
            if hasattr(menu, "exec_") else menu.exec(self.table.viewport().mapToGlobal(pos))

    def on_copy_key(self):
        sel = self.selected_rows()
        if not sel:
            return
        text = "\n".join("s3://%s/%s" % (self.bucket, k) for _, k, _ in sel)
        QtWidgets.QApplication.clipboard().setText(text)
        self.logline("클립보드 복사: %d 건" % len(sel))

    def on_refresh(self):
        if self.bucket:
            self.refresh_table()
        else:
            self.load_buckets()

    def on_go_up(self):
        if not self.bucket:
            return
        if not self.prefix:
            self.bucket = None
            self.table.setRowCount(0)
            self.ed_path.clear()
            return
        self.navigate(self.bucket, parent_prefix(self.prefix))

    def on_path_entered(self):
        text = self.ed_path.text().strip()
        if text.startswith("s3://"):
            text = text[5:]
        if not text:
            return
        parts = text.split("/", 1)
        bucket = parts[0]
        prefix = parts[1] if len(parts) > 1 else ""
        self.navigate(bucket, prefix)

    # ------------------------------------------------------- 디렉토리 생성
    def on_mkdir(self):
        if not self.bucket:
            QtWidgets.QMessageBox.information(self, "안내", "먼저 버킷을 선택하십시오.")
            return
        name, ok = QtWidgets.QInputDialog.getText(
            self, "폴더 생성", "생성 위치: s3://%s/%s\n\n새 폴더 이름:"
            % (self.bucket, self.prefix))
        if not ok or not name.strip():
            return
        try:
            key = self.core.create_dir(self.bucket, self.prefix, name.strip())
            self.logline("폴더 생성: s3://%s/%s" % (self.bucket, key))
            self.refresh_table()
            self._reset_tree_node(self.bucket, self.prefix)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "오류", str(e))

    def on_mkbucket(self):
        name, ok = QtWidgets.QInputDialog.getText(self, "버킷 생성", "버킷 이름:")
        if not ok or not name.strip():
            return
        try:
            self.core.create_bucket(name.strip())
            self.logline("버킷 생성: %s" % name.strip())
            self.load_buckets()
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "오류", str(e))

    def _reset_tree_node(self, bucket, prefix):
        """해당 노드를 다시 로드하도록 표시"""
        prefix = norm_prefix(prefix)

        def walk(item):
            if item.data(0, self.ROLE_BUCKET) == bucket and \
               norm_prefix(item.data(0, self.ROLE_PREFIX) or "") == prefix:
                item.setData(0, self.ROLE_LOADED, False)
                item.takeChildren()
                item.addChild(QtWidgets.QTreeWidgetItem(["로딩중..."]))
                if item.isExpanded():
                    self.on_tree_expand(item)
                return True
            for i in range(item.childCount()):
                if walk(item.child(i)):
                    return True
            return False

        for i in range(self.tree.topLevelItemCount()):
            if walk(self.tree.topLevelItem(i)):
                break

    # ------------------------------------------------------------ 업로드
    def on_upload_files(self):
        if not self.bucket:
            QtWidgets.QMessageBox.information(self, "안내", "먼저 버킷/폴더를 선택하십시오.")
            return
        paths, _ = QtWidgets.QFileDialog.getOpenFileNames(self, "업로드할 파일 선택")
        if not paths:
            return
        bucket, prefix = self.bucket, self.prefix

        def job(w):
            total = sum(os.path.getsize(p) for p in paths)
            cb = ByteProgress(w, total)
            for i, p in enumerate(paths, 1):
                w.check_cancel()
                key = join_key(prefix, os.path.basename(p))
                cb.set_text("[%d/%d] 업로드 %s" % (i, len(paths), os.path.basename(p)))
                w.log("업로드 → s3://%s/%s (%s)" % (bucket, key, human_size(os.path.getsize(p))))
                self.core.upload_file(bucket, key, p, callback=cb)
            return len(paths)

        self.run_worker("파일 업로드", job, on_ok=lambda r: self.refresh_table())

    def on_upload_dir(self):
        if not self.bucket:
            QtWidgets.QMessageBox.information(self, "안내", "먼저 버킷/폴더를 선택하십시오.")
            return
        d = QtWidgets.QFileDialog.getExistingDirectory(self, "업로드할 폴더 선택")
        if not d:
            return
        bucket, prefix = self.bucket, self.prefix

        def job(w):
            total = 0
            for dp, _, fns in os.walk(d):
                for fn in fns:
                    total += os.path.getsize(os.path.join(dp, fn))
            cb = ByteProgress(w, total or 1)

            def on_file(key, i, n):
                cb.set_text("[%d/%d] %s" % (i, n, key))
                w.log("업로드 → s3://%s/%s" % (bucket, key))

            root, cnt = self.core.upload_dir(
                bucket, prefix, d, callback=cb, on_file=on_file,
                should_cancel=w.cancelled)
            w.log("폴더 업로드 완료: s3://%s/%s (%d 파일)" % (bucket, root, cnt))
            return cnt

        self.run_worker("폴더 업로드", job, on_ok=lambda r: (
            self.refresh_table(), self._reset_tree_node(bucket, prefix)))

    # ---------------------------------------------------------- 다운로드
    def on_download(self):
        sel = self.selected_rows()
        if not sel:
            QtWidgets.QMessageBox.information(self, "안내", "다운로드할 항목을 선택하십시오.")
            return
        dest = QtWidgets.QFileDialog.getExistingDirectory(self, "저장할 로컬 폴더 선택")
        if not dest:
            return
        bucket = self.bucket

        def job(w):
            # 총 바이트 산출
            total = 0
            plan = []
            for kind, key, name in sel:
                if kind == "file":
                    try:
                        size = self.core.s3.head_object(Bucket=bucket, Key=key)["ContentLength"]
                    except Exception:
                        size = 0
                    total += size
                    plan.append(("file", key, name, size))
                else:
                    objs = self.core.list_all_keys(bucket, key)
                    total += sum(o["size"] for o in objs)
                    plan.append(("dir", key, name, 0))
            cb = ByteProgress(w, total or 1)

            cnt = 0
            for kind, key, name, size in plan:
                w.check_cancel()
                if kind == "file":
                    local = os.path.join(dest, name)
                    cb.set_text("다운로드 %s" % name)
                    w.log("다운로드 ← s3://%s/%s  →  %s" % (bucket, key, local))
                    self.core.download_file(bucket, key, local, callback=cb)
                    cnt += 1
                else:
                    def on_file(k, i, n):
                        cb.set_text("[%d/%d] %s" % (i, n, k))
                        w.log("다운로드 ← s3://%s/%s" % (bucket, k))
                    root, c = self.core.download_dir(
                        bucket, key, dest, callback=cb, on_file=on_file,
                        should_cancel=w.cancelled)
                    w.log("폴더 다운로드 완료: %s (%d 파일)" % (root, c))
                    cnt += c
            return cnt

        self.run_worker("다운로드", job,
                        on_ok=lambda r: self.logline("총 %s 개 파일 저장: %s" % (r, dest)))

    # -------------------------------------------------------------- 삭제
    def on_delete(self):
        sel = self.selected_rows()
        if not sel:
            QtWidgets.QMessageBox.information(self, "안내", "삭제할 항목을 선택하십시오.")
            return
        dirs = [s for s in sel if s[0] == "dir"]
        files = [s for s in sel if s[0] == "file"]

        msg = "다음 항목을 삭제합니다.\n\n"
        msg += "\n".join("  [%s] %s" % ("폴더" if k == "dir" else "파일", n)
                         for k, _, n in sel[:15])
        if len(sel) > 15:
            msg += "\n  ... 외 %d 건" % (len(sel) - 15)
        if dirs:
            msg += "\n\n※ 폴더는 하위 객체까지 전부 재귀 삭제됩니다."
        msg += "\n\n삭제된 객체는 복구할 수 없습니다. 진행할까요?"

        box = QtWidgets.QMessageBox(self)
        box.setWindowTitle("삭제 확인")
        box.setIcon(QtWidgets.QMessageBox.Warning)
        box.setText(msg)
        box.setStandardButtons(QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No)
        box.setDefaultButton(QtWidgets.QMessageBox.No)
        if (box.exec_() if hasattr(box, "exec_") else box.exec()) != QtWidgets.QMessageBox.Yes:
            return

        bucket, prefix = self.bucket, self.prefix

        def job(w):
            deleted, errs = 0, []
            if files:
                keys = [k for _, k, _ in files]
                w.log("파일 삭제 %d 건" % len(keys))
                d, e = self.core.delete_keys(
                    bucket, keys,
                    on_progress=lambda a, b: w.progress(a, b, "파일 삭제 %d/%d" % (a, b)),
                    should_cancel=w.cancelled)
                deleted += d
                errs += e
            for _, key, name in dirs:
                w.check_cancel()
                w.log("디렉토리 삭제(재귀): s3://%s/%s" % (bucket, key))
                d, e = self.core.delete_dir(
                    bucket, key,
                    on_progress=lambda a, b, nm=name: w.progress(
                        a, b, "%s 삭제 %d/%d" % (nm, a, b)),
                    should_cancel=w.cancelled)
                deleted += d
                errs += e
            if errs:
                for x in errs[:20]:
                    w.log("삭제 오류: %s" % x)
            return deleted

        self.run_worker("삭제", job, on_ok=lambda r: (
            self.logline("%s 개 객체 삭제됨" % r),
            self.refresh_table(),
            self._reset_tree_node(bucket, prefix)))

    # ------------------------------------------------------------ 종료
    def closeEvent(self, ev):
        if self.busy():
            if QtWidgets.QMessageBox.question(
                    self, "확인", "작업이 진행 중입니다. 종료할까요?") \
                    != QtWidgets.QMessageBox.Yes:
                ev.ignore()
                return
            self.worker.cancel()
            self.worker.wait(3000)
        ev.accept()


def main():
    app = QtWidgets.QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    w = MainWindow()
    w.show()
    w.logline("%s %s  (Qt=%s)" % (APP_NAME, APP_VER, QT_LIB))
    w.logline("좌측 상단 [연결] 로 S3 접속정보를 입력하십시오.")
    sys.exit(app.exec_() if hasattr(app, "exec_") else app.exec())


if __name__ == "__main__":
    main()
