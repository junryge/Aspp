#!/usr/bin/env node
/* =============================================================
   2D 감정캐릭터 ↔ LLM 로컬 프록시   (Node 18+ / 의존성 없음)
   -------------------------------------------------------------
   브라우저에서 API를 직접 부르면 CORS에 막히거나, HTML 안에
   API 키가 노출된다. 이 프록시를 띄우면 둘 다 해결된다.

   [실행]
     Windows (PowerShell)
       $env:OPENAI_API_KEY="sk-..."
       node proxy.js
     macOS / Linux
       OPENAI_API_KEY="sk-..." node proxy.js

   [앱 설정 탭]
     Base URL : http://localhost:8787/v1
     API Key  : local        ← 아무 값이나. 진짜 키는 여기 서버에만 있다
     Model    : gpt-4o-mini

   [다른 백엔드로 바꾸기]
     UPSTREAM=https://api.openai.com/v1            (기본)
     UPSTREAM=http://localhost:11434/v1            Ollama
     UPSTREAM=https://generativelanguage.googleapis.com/v1beta/openai   Gemini
     UPSTREAM=https://api.groq.com/openai/v1       Groq
   ============================================================= */

const http = require('http');

const PORT     = Number(process.env.PORT || 8787);
const UPSTREAM = (process.env.UPSTREAM || 'https://api.openai.com/v1').replace(/\/+$/, '');
const KEY      = process.env.OPENAI_API_KEY || process.env.API_KEY || '';

if (!KEY && !UPSTREAM.includes('localhost')) {
  console.error('\n  [!] OPENAI_API_KEY 환경변수가 비어 있습니다.');
  console.error('      OPENAI_API_KEY="sk-..." node proxy.js\n');
  process.exit(1);
}

const CORS = {
  'Access-Control-Allow-Origin' : '*',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
  'Access-Control-Max-Age'      : '86400',
};

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') { res.writeHead(204, CORS); return res.end(); }

  // /v1/chat/completions -> UPSTREAM/chat/completions
  const path = req.url.replace(/^\/v1/, '');
  const url  = UPSTREAM + path;

  const chunks = [];
  for await (const c of req) chunks.push(c);
  const body = Buffer.concat(chunks);

  const t0 = Date.now();
  try {
    const up = await fetch(url, {
      method : req.method,
      headers: {
        'Content-Type' : 'application/json',
        'Authorization': 'Bearer ' + (KEY || 'local'),
      },
      body: req.method === 'GET' ? undefined : body,
    });

    const text = await up.text();
    console.log(`${up.status}  ${req.method} ${path}  ${Date.now() - t0}ms`);
    if (!up.ok) console.log('       ↳ ' + text.slice(0, 300).replace(/\s+/g, ' '));

    res.writeHead(up.status, { ...CORS, 'Content-Type': 'application/json; charset=utf-8' });
    res.end(text);
  } catch (e) {
    console.error('  [x] upstream 연결 실패:', e.message);
    res.writeHead(502, { ...CORS, 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: { message: 'upstream 연결 실패: ' + e.message } }));
  }
});

server.listen(PORT, () => {
  console.log('');
  console.log('  프록시 가동');
  console.log('  ├ 수신   http://localhost:' + PORT + '/v1');
  console.log('  ├ 전달   ' + UPSTREAM);
  console.log('  └ 키     ' + (KEY ? KEY.slice(0, 7) + '...' + KEY.slice(-4) : '(없음 · 로컬 백엔드용)'));
  console.log('');
  console.log('  앱 설정 탭 → Base URL 을 http://localhost:' + PORT + '/v1 로 바꾸고');
  console.log('  API Key 칸에는 아무 값(local)이나 넣으면 됩니다.');
  console.log('');
});
