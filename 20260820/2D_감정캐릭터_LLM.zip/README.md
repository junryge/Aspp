# 2D 감정캐릭터 × LLM

평면 이미지 1장을 WebGL 메쉬로 실시간 변형해서 표정·손동작을 만들고,
LLM 응답에 감정/모션을 붙여 움직이는 단일 HTML 앱.

```
2D_감정캐릭터_LLM.html   ← 이것만 더블클릭하면 실행 (캐릭터 이미지 내장)
proxy.js                 ← CORS 막혔을 때만 사용 (Node 18+, 의존성 없음)
README.md
```

---

## 1. 바로 실행

`2D_감정캐릭터_LLM.html` 더블클릭. 키 없이도 **데모 모드**(규칙 기반)로 동작한다.

---

## 2. LLM 연결

**설정** 탭 →

| 항목 | 값 |
|---|---|
| API Key | `sk-...` (platform.openai.com/api-keys) |
| Model | `gpt-4o-mini` |
| Base URL | `https://api.openai.com/v1` |

**[연결 테스트]** 클릭 → 초록 점 + `연결 성공` 뜨면 끝.
이때 **자동 저장**되므로 다음에 열면 바로 연결된다.

저장 항목: API 키 · 모델 · Base URL · Temp · 페르소나 · 캘리브레이션 좌표 · 렌더링 슬라이더
(체크박스 해제 또는 `저장값 지우기` 로 삭제)

### 실패 시

| 메시지 | 원인 |
|---|---|
| `Failed to fetch` | 브라우저가 직접 호출 차단 → 아래 프록시 사용 |
| `401` | API 키 오류 |
| `404` | 모델명 / Base URL 오류 |
| `429` | 사용량 한도 초과 |

---

## 3. 프록시 (CORS 우회 + 키 은닉)

```bash
# macOS / Linux
OPENAI_API_KEY="sk-..." node proxy.js

# Windows PowerShell
$env:OPENAI_API_KEY="sk-..."
node proxy.js
```

앱에서 **Base URL** → `http://localhost:8787/v1`, **API Key** → `local` (아무 값).
진짜 키는 프록시 프로세스에만 남는다. 공유·방송용이면 이 방식을 쓸 것.

### 다른 백엔드

```bash
UPSTREAM=http://localhost:11434/v1        node proxy.js   # Ollama
UPSTREAM=https://api.groq.com/openai/v1   node proxy.js   # Groq
UPSTREAM=https://generativelanguage.googleapis.com/v1beta/openai  node proxy.js   # Gemini
```

Ollama는 프록시 없이 Base URL만 `http://localhost:11434/v1` 로 바꿔도 되지만,
Ollama 쪽에 `OLLAMA_ORIGINS=*` 를 줘야 CORS가 뚫린다.

---

## 4. 캐릭터 교체

1. 스테이지에 이미지 **드래그 & 드롭**
2. 캘리브레이션 핸들이 자동으로 켜짐 → 눈 / 입 / 볼 / 목 / 팔꿈치 위치를 끌어다 맞춤
3. 그린스크린 이미지면 **크로마키** 슬라이더를 올림 (배경 제거 + 초록 물듦 제거)
4. 좌표는 자동 저장됨 (설정 탭 `현재값 내보내기` 로 JSON 백업 가능)

---

## 5. 동작 구조

**감정 12종** — 평온 / 미소 / 기쁨 / 슬픔 / 분노 / 놀람 / 부끄 / 고민 / 의기양양 / 당황 / 졸림 / 애정

**모션 12종** — 끄덕 / 도리 / 통통 / 점프 / 기울 / 부들 / 화들짝 / 손 흔들 / 손 올림 / 손가락 톡톡 / 팔 고쳐잡기

LLM에는 JSON 스키마를 강제해서 아래 형태로만 받는다.

```json
{ "text": "대사", "emotion": "joy", "intensity": 0.9, "motion": "wave" }
```

### 렌더링

- WebGL 100×150 격자 메쉬, 정점 변형은 전부 버텍스 셰이더에서 처리
- **눈 · 손** : 평탄형 커널 → 부위 전체가 통째로 움직임 (완전히 감기고, 손 가동범위 확보)
- **입 · 눈썹 · 턱** : 종형 커널 → 경계가 부드럽게 0으로 수렴 (고무처럼 늘어나지 않음)
- **구강 합성** : 평면 그림은 워핑만으론 입이 안 열리므로, 안쪽 어둠 + 혀 + 윗니를
  프래그먼트 셰이더에서 텍스처 좌표계에 그림 → 고개를 돌려도 그대로 따라감
- **발화** : 음절 단위 랜덤 개구(75~170ms) → 사인파 특유의 기계적인 움직임 제거
- **팔** : 팔꿈치 피벗 회전. 피벗 쪽 가중치가 0이라 어깨에서 찢어지지 않음
- 자동 호흡 · 눈깜빡임(비대칭 곡선) · 시선 이동 · 미세 흔들림 상시 동작

### 외부 제어

```js
AVATAR.setEmotion('joy', 0.9, 'wave');   // 감정, 강도, 모션
AVATAR.trigger('nod');                   // 모션만
AVATAR.speak('안녕하세요');               // 말풍선 + 립싱크
AVATAR.set('mouthOpen', 0.6);            // 파라미터 직접 제어
```

---

## 6. 배경

**배경** / **그린스크린** / **투명** 3종. OBS 송출 시 그린스크린 + 크로마키 필터로 합성.
