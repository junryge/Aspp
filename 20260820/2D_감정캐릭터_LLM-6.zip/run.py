#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
=============================================================================
 2D 감정캐릭터 × LLM  —  로컬 서버 + API 프록시   (Python 3.8+, 표준 라이브러리만)
=============================================================================

 실행하면
   1) token.txt 에서 토큰을 읽고
   2) 엔드포인트를 고르게 하고
   3) /v1/models 로 모델 목록을 받아 고르게 한 다음
   4) 앱을 띄운다. 브라우저 설정은 자동으로 채워진다.

 [실행]
   python run.py

 [비대화 실행 — 선택 과정 건너뛰기]
   python run.py --upstream http://hcp.llm.skhynix.com/v1 --model <모델명>

 [token.txt]
   이 스크립트와 같은 폴더에 두면 자동으로 읽는다.
   다른 곳에 있으면  python run.py --token-file D:/keys/token.txt
=============================================================================
"""

import argparse
import http.server
import json
import os
import socketserver
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
APP_FILE = "2D_감정캐릭터_LLM.html"

# 자주 쓰는 엔드포인트 — 번호로 고른다
ENDPOINTS = [
    ("http://hcp.llm.skhynix.com",     "HCP (운영)"),
    ("http://dev.hcp.llm.skhynix.com", "HCP (개발)"),
    ("http://common.llm.skhynix.com",  "Common"),
    ("https://api.openai.com",         "OpenAI"),
]

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Max-Age": "86400",
}


class Cfg:
    upstream = ""          # 예: http://hcp.llm.skhynix.com/v1
    token = ""
    model = ""
    models = []
    timeout = 180
    opener = None


# ═══════════════════════════════════════════════════════════════════════════
#  공통 유틸
# ═══════════════════════════════════════════════════════════════════════════
def build_opener(upstream):
    """사내 주소는 시스템 프록시를 타면 오히려 막히는 경우가 많아 우회한다."""
    host = urllib.parse.urlparse(upstream).hostname or ""
    internal = ("skhynix" in host) or host in ("localhost", "127.0.0.1")

    handlers = []
    if internal:
        handlers.append(urllib.request.ProxyHandler({}))     # 프록시 무시

    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE                          # 사내 자체서명 인증서 대응
    handlers.append(urllib.request.HTTPSHandler(context=ctx))

    return urllib.request.build_opener(*handlers)


def api_get(path):
    """upstream 에 GET. (예: /models)"""
    req = urllib.request.Request(
        Cfg.upstream.rstrip("/") + path,
        headers={"Authorization": "Bearer " + Cfg.token,
                 "Content-Type": "application/json"},
    )
    with Cfg.opener.open(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8"))


def read_token(token_file):
    """token.txt 읽기. 없으면 환경변수, 그것도 없으면 빈 문자열."""
    candidates = []
    if token_file:
        candidates.append(Path(token_file))
    candidates += [BASE_DIR / "token.txt", Path.cwd() / "token.txt"]

    for p in candidates:
        try:
            if p.is_file():
                tok = p.read_text(encoding="utf-8-sig").strip()
                if tok:
                    return tok, str(p)
        except Exception:
            pass

    tok = (os.environ.get("LLM_TOKEN") or os.environ.get("OPENAI_API_KEY") or "").strip()
    return tok, ("환경변수" if tok else "")


def mask(t):
    return (t[:6] + "..." + t[-4:]) if len(t) > 12 else (t or "(없음)")


def ask(prompt, default):
    """입력이 없거나(EOF) 그냥 엔터면 기본값."""
    try:
        v = input(prompt).strip()
    except EOFError:
        print(prompt + str(default) + "   (기본값)")
        return default
    except KeyboardInterrupt:
        print("")
        sys.exit(0)
    return v or default


# ═══════════════════════════════════════════════════════════════════════════
#  1) 엔드포인트 선택   2) 모델 선택
# ═══════════════════════════════════════════════════════════════════════════
def choose_endpoint(preset):
    if preset:
        return preset if preset.rstrip("/").endswith("/v1") else preset.rstrip("/") + "/v1"

    print("  ── API 엔드포인트 ────────────────────────────────────")
    for i, (url, label) in enumerate(ENDPOINTS, 1):
        print("   [{}] {:<34} {}".format(i, url, label))
    print("   [{}] 직접 입력".format(len(ENDPOINTS) + 1))
    print("")

    sel = ask("  번호 선택 [1] : ", "1")
    if sel.isdigit() and 1 <= int(sel) <= len(ENDPOINTS):
        base = ENDPOINTS[int(sel) - 1][0]
    elif sel.isdigit() and int(sel) == len(ENDPOINTS) + 1:
        base = ask("  주소 입력 (예: http://hcp.llm.skhynix.com) : ", ENDPOINTS[0][0])
    else:
        base = sel  # 주소를 그대로 붙여넣은 경우

    base = base.strip().rstrip("/")
    return base if base.endswith("/v1") else base + "/v1"


def fetch_models():
    """GET /v1/models — 토큰 검증까지 겸한다."""
    print("")
    print("  모델 목록 조회 중 ...  {}".format(Cfg.upstream + "/models"))
    try:
        raw = api_get("/models")
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")[:200]
        print("")
        print("  [!] 모델 목록 실패 : HTTP {}".format(e.code))
        if e.code in (401, 403):
            print("      토큰이 잘못됐거나 만료됐습니다. token.txt 를 확인하세요.")
        elif e.code == 404:
            print("      이 엔드포인트에 /v1/models 가 없습니다. 주소를 확인하세요.")
        if body.strip():
            print("      " + body.replace("\n", " "))
        return []
    except Exception as e:  # noqa: BLE001
        print("")
        print("  [!] 연결 실패 : {}".format(e))
        print("      사내망(VPN) 연결 상태와 주소를 확인하세요.")
        return []

    if isinstance(raw, dict):
        raw = raw.get("data", raw)
    if not isinstance(raw, list):
        return []

    out = []
    for m in raw:
        if isinstance(m, dict):
            mid = m.get("id") or m.get("model") or m.get("name")
        else:
            mid = str(m)
        if mid:
            out.append(str(mid))
    return sorted(set(out), key=str.lower)


def choose_model(models, preset):
    if preset:
        return preset
    if not models:
        return ask("  모델 이름을 직접 입력 : ", "gpt-4o-mini")

    print("")
    print("  ── 모델 ({}개) ──────────────────────────────────────".format(len(models)))
    for i, m in enumerate(models, 1):
        print("   [{:>2}] {}".format(i, m))
    print("")

    sel = ask("  번호 선택 [1] : ", "1")
    if sel.isdigit() and 1 <= int(sel) <= len(models):
        return models[int(sel) - 1]
    return sel


# ═══════════════════════════════════════════════════════════════════════════
#  HTTP 핸들러
# ═══════════════════════════════════════════════════════════════════════════
def find_app():
    p = BASE_DIR / APP_FILE
    if p.exists():
        return p.name
    htmls = sorted(BASE_DIR.glob("*.html"))
    return htmls[0].name if htmls else None


class Handler(http.server.SimpleHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(BASE_DIR), **kw)

    def log_message(self, fmt, *args):
        pass

    def _say(self, msg):
        sys.stdout.write("  " + msg + "\n")
        sys.stdout.flush()

    def _send(self, code, body: bytes, ctype="application/json; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for k, v in CORS_HEADERS.items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, code, obj):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"))

    def _err(self, code, msg):
        self._json(code, {"error": {"message": msg}})

    def do_OPTIONS(self):
        self.send_response(204)
        for k, v in CORS_HEADERS.items():
            self.send_header(k, v)
        self.send_header("Content-Length", "0")
        self.end_headers()

    # ── GET ──────────────────────────────────────────────────────────────
    def do_GET(self):
        if self.path == "/favicon.ico":
            self.send_response(204)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return

        # 앱이 시작할 때 읽어가는 설정 (여기서 고른 엔드포인트/모델이 자동 반영된다)
        if self.path.startswith("/__config"):
            self._json(200, {
                "baseUrl":  "/v1",
                "model":    Cfg.model,
                "models":   Cfg.models,
                "upstream": Cfg.upstream,
            })
            return

        if self.path.startswith("/v1"):
            return self._relay("GET", self.path[3:] or "/models", None)

        if self.path in ("/", "/index.html"):
            app = find_app()
            if not app:
                self._err(404, "앱 HTML 파일을 찾을 수 없습니다.")
                return
            self.path = "/" + app
        return super().do_GET()

    # ── POST ─────────────────────────────────────────────────────────────
    def do_POST(self):
        if not self.path.startswith("/v1"):
            self._err(404, "알 수 없는 경로: " + self.path)
            return
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        body = self.rfile.read(length) if length else b"{}"
        self._relay("POST", self.path[3:] or "/chat/completions", body)

    # ── 중계 ─────────────────────────────────────────────────────────────
    def _relay(self, method, path, body):
        url = Cfg.upstream.rstrip("/") + path

        model = ""
        if body:
            try:
                model = json.loads(body.decode("utf-8")).get("model", "")
            except Exception:
                pass

        req = urllib.request.Request(
            url, data=body, method=method,
            headers={"Content-Type": "application/json",
                     "Authorization": "Bearer " + Cfg.token},
        )

        t0 = time.time()
        try:
            with Cfg.opener.open(req, timeout=Cfg.timeout) as r:
                data = r.read()
                self._say("200  {}  {}  {}ms".format(
                    path, model or "-", int((time.time() - t0) * 1000)))
                self._send(200, data)

        except urllib.error.HTTPError as e:
            data = e.read()
            self._say("{}  {}  {}ms".format(e.code, path, int((time.time() - t0) * 1000)))
            try:
                msg = json.loads(data.decode("utf-8")).get("error", {}).get("message", "")
            except Exception:
                msg = data.decode("utf-8", "replace")[:300]
            if msg:
                self._say("     ↳ " + msg[:220])
            if e.code in (401, 403):
                self._say("     ↳ token.txt 의 토큰을 확인하세요.")
            elif e.code == 404:
                self._say("     ↳ 모델 이름 또는 엔드포인트를 확인하세요.")
            elif e.code == 429:
                self._say("     ↳ 사용량/한도 초과입니다.")
            self._send(e.code, data)

        except urllib.error.URLError as e:
            self._say("[x] 연결 실패: {}".format(e.reason))
            self._err(502, "연결 실패: {} (사내망/VPN 확인)".format(e.reason))

        except Exception as e:  # noqa: BLE001
            self._say("[x] {}".format(e))
            self._err(500, str(e))


class Server(socketserver.ThreadingTCPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        exc = sys.exc_info()[0]
        if exc in (ConnectionResetError, BrokenPipeError, ConnectionAbortedError):
            return
        super().handle_error(request, client_address)


# ═══════════════════════════════════════════════════════════════════════════
def main():
    ap = argparse.ArgumentParser(description="2D 감정캐릭터 로컬 서버 + LLM API 프록시")
    ap.add_argument("--port", type=int, default=8787, help="포트 (기본 8787)")
    ap.add_argument("--token-file", default="", help="토큰 파일 경로 (기본: 같은 폴더 token.txt)")
    ap.add_argument("--upstream", default="", help="엔드포인트 지정 시 선택 화면을 건너뛴다")
    ap.add_argument("--model", default="", help="모델 지정 시 선택 화면을 건너뛴다")
    ap.add_argument("--no-browser", action="store_true", help="브라우저 자동 실행 안 함")
    args = ap.parse_args()

    app = find_app()
    if app is None:
        print("\n  [!] 이 스크립트와 같은 폴더에 앱 HTML 이 있어야 합니다.")
        print("      현재 폴더: {}\n".format(BASE_DIR))
        sys.exit(1)

    print("")
    print("  ══ 2D 감정캐릭터 서버 ════════════════════════════════")
    print("")

    # ── 토큰 ──────────────────────────────────────────────────────────────
    Cfg.token, src = read_token(args.token_file)
    if not Cfg.token:
        print("  [!] 토큰을 찾을 수 없습니다.")
        print("      이 폴더에 token.txt 를 두거나  --token-file <경로> 로 지정하세요.")
        print("      폴더: {}\n".format(BASE_DIR))
        sys.exit(1)
    print("  토큰   {}   ({})".format(mask(Cfg.token), src))
    print("")

    # ── 엔드포인트 ────────────────────────────────────────────────────────
    Cfg.upstream = choose_endpoint(args.upstream)
    Cfg.opener = build_opener(Cfg.upstream)

    # ── 모델 ──────────────────────────────────────────────────────────────
    Cfg.models = fetch_models()
    Cfg.model = choose_model(Cfg.models, args.model)

    url = "http://localhost:{}/".format(args.port)
    print("")
    print("  ┌──────────────────────────────────────────────────────")
    print("  │  앱        {}".format(url))
    print("  │  엔드포인트 {}".format(Cfg.upstream))
    print("  │  모델      {}".format(Cfg.model))
    print("  │  토큰      {}".format(mask(Cfg.token)))
    print("  └──────────────────────────────────────────────────────")
    print("")
    print("  브라우저가 열리면 바로 대화하면 됩니다. (설정은 자동으로 채워집니다)")
    print("  종료: Ctrl+C")
    print("")

    try:
        httpd = Server(("127.0.0.1", args.port), Handler)
    except OSError as e:
        print("  [!] 포트 {} 를 열 수 없습니다: {}".format(args.port, e))
        print("      다른 포트로:  python run.py --port 8899\n")
        sys.exit(1)

    if not args.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  종료합니다.\n")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
