#!/usr/bin/env python3
"""엔드투엔드 검증: 목 LLM → 에이전트 루프 → 실제 IPython 커널 → 서브에이전트 → 하네스.

    python3 tests/test_e2e.py
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

WORK = Path(tempfile.mkdtemp(prefix="pa-e2e-"))
os.environ["PA_AGENT_DIR"] = str(WORK / "agent")

import mock_llm  # noqa: E402
from pa import config, skills as skills_mod  # noqa: E402
from pa.agent import AgentSession  # noqa: E402
from pa.session import SessionManager  # noqa: E402

PASS, FAIL = [], []


def check(name: str, cond: bool, detail: str = "") -> None:
    (PASS if cond else FAIL).append(name)
    mark = "\033[32m✓\033[0m" if cond else "\033[31m✗\033[0m"
    print(f"  {mark} {name}" + (f"  — {detail}" if detail and not cond else ""))


def make_session(script: list[dict], port: int, name="root", depth=0,
                 child_script: list[dict] | None = None,
                 settings: dict | None = None) -> AgentSession:
    mock_llm.SCRIPT[:] = script
    mock_llm.CHILD_SCRIPT[:] = child_script or []
    mock_llm.STATE["i"] = 0
    mock_llm.STATE["ci"] = 0
    mock_llm.STATE["calls"].clear()
    models = config.load_models()
    sm = SessionManager.create(WORK, persist=True)
    return AgentSession(model=models[0], sm=sm, cwd=WORK,
                        settings=settings or config.load_settings(WORK), skills=[],
                        depth=depth, name=name, emit=lambda k, d: None)


def main() -> int:
    srv, port = mock_llm.serve()
    config.ensure_dirs()
    (config.agent_dir() / "models.json").write_text(json.dumps({
        "providers": {"mock": {
            "baseUrl": f"http://127.0.0.1:{port}/v1",
            "api": "openai-completions", "apiKey": "dummy", "authHeader": True,
            "compat": {"supportsDeveloperRole": False, "maxTokensField": "max_tokens"},
            "models": [{"id": "mock-model", "contextWindow": 32000, "maxTokens": 2048}],
        }}
    }), encoding="utf-8")

    print("\n\033[1m1. 설정·모델 로딩\033[0m")
    models = config.load_models()
    check("models.json 파싱", len(models) == 1 and models[0].id == "mock-model")
    check("baseUrl 해석", models[0].base_url.endswith("/v1"))

    from pa import provider as prov
    good, msg = prov.probe(models[0])
    check("엔드포인트 probe", good, msg)

    print("\n\033[1m2. 커널 + 툴 루프\033[0m")
    s = make_session([
        {"tool": "x = 6 * 7\nprint('answer', x)"},
        {"tool": "print('여전히 살아있음:', x)"},
        {"text": "42 다."},
    ], port)
    out = s.run_turn("6 곱하기 7은?")
    check("최종 텍스트 수신", "42" in out, out)

    tool_results = [e for e in s.sm.entries
                    if e.get("type") == "message"
                    and (e.get("message") or {}).get("role") == "toolResult"]
    check("툴 결과 2건 기록", len(tool_results) == 2, str(len(tool_results)))
    check("커널 실행 결과 반영", "answer 42" in (tool_results[0]["message"]["content"]))
    check("커널 상태 유지(변수 x)", "여전히 살아있음: 42" in tool_results[1]["message"]["content"],
          tool_results[1]["message"]["content"])

    print("\n\033[1m3. 세션 JSONL 포맷 (원본 v3 호환)\033[0m")
    lines = [json.loads(l) for l in s.sm.path.read_text(encoding="utf-8").splitlines() if l.strip()]
    check("헤더 version 3", lines[0].get("version") == 3 and lines[0].get("type") == "session")
    check("헤더에 cwd", "cwd" in lines[0])
    check("첫 엔트리 parentId=null", lines[1].get("parentId") is None)
    check("엔트리 id 8자리 hex", all(len(e.get("id", "")) == 8 for e in lines[1:]
                                     if "id" in e))
    check("트리 연결 유효", all(lines[i]["parentId"] == lines[i - 1]["id"]
                                for i in range(2, len(lines))))
    reopened = SessionManager.open(s.sm.path)
    check("세션 재열기", len(reopened.entries) == len(s.sm.entries))

    print("\n\033[1m4. 하네스 CRUD + refine 롤백\033[0m")
    st = s.harness.store(False)
    e1 = st.upsert("memory", "배포 규칙", "릴리스는 금요일에 하지 않는다")
    check("메모리 생성", e1["id"] == "배포_규칙" or bool(e1["id"]))
    check("version 1", e1["version"] == 1)
    e2 = st.upsert("memory", "배포 규칙", "릴리스는 화요일에 한다", id=e1["id"])
    check("업데이트 시 version 증가", e2["version"] == 2)
    check("path 보존", e2["path"] == "general")

    try:
        st.upsert("prompt", "시스템", "덮어쓰기 시도", id="base_system_prompt")
        check("기본 시스템 프롬프트 보호", False)
    except ValueError:
        check("기본 시스템 프롬프트 보호", True)

    try:
        st.upsert("skill", "나쁜 스킬", "내용", reference={"type": "js"}, arguments={})
        check("skill reference 검증", False)
    except ValueError:
        check("skill reference 검증", True)

    from pa import harness as hmod
    prop = {"summary": "테스트 정제", "rationale": "e2e", "expectedOutcome": "-",
            "edits": [
                {"action": "create", "kind": "memory", "id": "tmp_mem",
                 "title": "임시", "content": "지워질 것"},
                {"action": "update", "kind": "memory", "id": e1["id"],
                 "title": "배포 규칙", "content": "수정됨"},
            ]}
    rec = hmod.apply_proposal(s.harness, prop, "local")
    check("제안 적용", all(e["applied"] for e in rec["edits"]))
    check("생성 확인", st.get("tmp_mem", "memory") is not None)
    check("수정 확인", st.get(e1["id"], "memory")["content"] == "수정됨")

    hmod.rollback(s.harness, rec)
    check("롤백: 생성분 삭제", st.get("tmp_mem", "memory") is None)
    check("롤백: 수정분 복원",
          st.get(e1["id"], "memory")["content"] == "릴리스는 화요일에 한다",
          st.get(e1["id"], "memory")["content"])

    print("\n\033[1m5. 서브에이전트 + 메시징\033[0m")
    s2 = make_session(
        [
            {"tool": "h = await rlm('부모에게 결과를 보내라', name='worker')\nprint('spawned', h.name)"},
            {"text": "자식을 띄웠다."},
        ],
        port,
        child_script=[
            {"tool": "await agent_message.send('작업 완료 보고', receiver_role='parent')\nprint('sent')"},
            {"text": "보고 끝."},
        ],
    )
    out2 = s2.run_turn("작업을 위임해라")
    check("spawn 성공", len(s2.children) == 1, str(len(s2.children)))
    if s2.children:
        ch = s2.children[0]
        check("자식 이름", ch.name == "worker")
        ch.thread.join(timeout=60)
        check("자식 완료", ch.status == "completed", f"{ch.status} {ch.error}")
        msgs = s2.drain_inbox()
        check("부모 인박스 수신", any("작업 완료 보고" in m for m in msgs),
              str(msgs))
        check("자식 usage 귀속", s2.child_usage.total > 0, str(s2.child_usage.total))
        check("자식 세션 디렉터리", ch.session_dir.exists())

    print("\n\033[1m6. 깊이 제한\033[0m")
    s3 = make_session([{"text": "x"}], port, depth=2)
    try:
        s3._h_rlm_run({"prompt": "더 깊이"})
        check("RLM_MAX_DEPTH 강제", False)
    except RuntimeError as e:
        check("RLM_MAX_DEPTH 강제", "깊이" in str(e), str(e))

    print("\n\033[1m7. 모르는 옵션 거부 / 모델 미존재 실패\033[0m")
    try:
        s2._h_rlm_run({"prompt": "x", "model": "없는/모델"})
        check("존재하지 않는 모델은 spawn 실패", False)
    except RuntimeError:
        check("존재하지 않는 모델은 spawn 실패", True)

    print("\n\033[1m8. 컴팩션\033[0m")
    comp_settings = dict(config.load_settings(WORK))
    comp_settings["compaction"] = {"enabled": True, "reserveTokens": 1000,
                                   "keepRecentTokens": 3000}
    s4 = make_session([{"text": "요약본"}] * 3, port, settings=comp_settings)
    for i in range(14):
        s4.sm.append_message({"role": "user", "content": f"메시지 {i} " + "가" * 900})
        s4.sm.append_message({"role": "assistant", "content": f"응답 {i} " + "나" * 900,
                              "provider": "mock", "model": "mock-model"})
    before = len(s4.sm.build_context())
    s4.compact("핵심만 남겨라")
    comp = [e for e in s4.sm.entries if e.get("type") == "compaction"]
    check("컴팩션 엔트리 기록", len(comp) == 1)
    if comp:
        check("firstKeptEntryId 존재", bool(comp[0].get("firstKeptEntryId")))
        check("customInstructions 보존", comp[0].get("customInstructions") == "핵심만 남겨라")
        after = len(s4.sm.build_context())
        check("컨텍스트 축소", after < before, f"{before} → {after}")
        check("요약이 컨텍스트 선두", s4.sm.build_context()[0]["role"] == "system")

    print("\n\033[1m9. 스킬 계약\033[0m")
    sk_root = WORK / "skills" / "word-count"
    (sk_root / "src" / "word_count").mkdir(parents=True)
    (sk_root / "SKILL.md").write_text(
        "---\nname: word-count\ndescription: 단어 빈도를 센다. 빈도 분석이 필요할 때 쓴다.\n---\n# 본문\n",
        encoding="utf-8")
    (sk_root / "pyproject.toml").write_text('[project]\nname="word-count"\nversion="0.1.0"\n',
                                            encoding="utf-8")
    (sk_root / "src" / "word_count" / "__init__.py").write_text(
        "async def run(text: str, top: int = 5) -> str:\n"
        "    from collections import Counter\n"
        "    return str(Counter(text.split()).most_common(top))\n", encoding="utf-8")
    found, notes = skills_mod.discover(WORK, {"skills": [str(WORK / "skills")]},
                                       enable_builtin=False)
    wc = next((x for x in found if x.name == "word-count"), None)
    check("Python 스킬 인식", wc is not None and wc.python, str(notes))
    check("import 이름 변환", wc and wc.import_name == "word_count")

    bad = WORK / "skills" / "no-desc"
    bad.mkdir(parents=True)
    (bad / "SKILL.md").write_text("---\nname: no-desc\n---\n본문\n", encoding="utf-8")
    found2, _ = skills_mod.discover(WORK, {"skills": [str(WORK / "skills")]},
                                    enable_builtin=False)
    check("description 없으면 미로드", not any(x.name == "no-desc" for x in found2))

    mism = WORK / "skills" / "dir-name"
    (mism / "src" / "other_name").mkdir(parents=True)
    (mism / "SKILL.md").write_text(
        "---\nname: other-name\ndescription: 이름이 디렉터리와 다르다. 경고가 나야 한다.\n---\n",
        encoding="utf-8")
    _, notes3 = skills_mod.discover(WORK, {"skills": [str(WORK / "skills")]},
                                    enable_builtin=False)
    check("이름·디렉터리 불일치 경고", any("디렉터리명" in n for n in notes3), str(notes3))

    print("\n\033[1m10. 원본 저장소 스킬 호환 (rlm import)\033[0m")
    repo_skills = Path("/home/claude/kit/prime-agent-offline-kit/skills")
    if repo_skills.is_dir():
        s5 = make_session([{"tool": "from rlm import host_request\nprint('rlm import ok')"},
                           {"text": "됨."}], port)
        s5.run_turn("확인")
        tr = [e for e in s5.sm.entries if (e.get("message") or {}).get("role") == "toolResult"]
        check("커널에서 `from rlm import host_request` 동작",
              tr and "rlm import ok" in tr[0]["message"]["content"],
              tr[0]["message"]["content"] if tr else "no result")
        s5.close()
    else:
        check("저장소 스킬 디렉터리 존재", False, "건너뜀")

    for sess in (s, s2, s3, s4):
        try:
            sess.close()
        except Exception:
            pass
    srv.shutdown()

    print(f"\n\033[1m결과: {len(PASS)} 통과 / {len(FAIL)} 실패\033[0m")
    if FAIL:
        for f in FAIL:
            print("  \033[31m✗\033[0m " + f)
        return 1
    print("  전부 통과")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
