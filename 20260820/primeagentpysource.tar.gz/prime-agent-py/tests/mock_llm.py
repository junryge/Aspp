#!/usr/bin/env python3
"""테스트용 OpenAI 호환 목 서버 (툴 콜 + SSE 스트리밍).

사내 vLLM 없이 에이전트 루프 전체를 검증하려고 쓴다.
시나리오는 `PA_MOCK_SCRIPT` 환경변수(JSON 배열 파일 경로)로 주입한다.
각 요소는 {"tool": "<python code>"} 또는 {"text": "..."} 다.
"""

from __future__ import annotations

import json
import os
import sys
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

SCRIPT: list[dict] = []          # 기본(부모) 스크립트
CHILD_SCRIPT: list[dict] = []    # "[task from parent]" 가 보이면 이쪽을 쓴다
STATE = {"i": 0, "ci": 0, "calls": []}
LOCK = threading.Lock()


def sse(obj: dict) -> bytes:
    return b"data: " + json.dumps(obj).encode() + b"\n\n"


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):  # 조용히
        pass

    def do_GET(self):
        if self.path.rstrip("/").endswith("/models"):
            body = json.dumps({"object": "list", "data": [{"id": "mock-model"}]}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_error(404)

    def do_POST(self):
        n = int(self.headers.get("Content-Length") or 0)
        req = json.loads(self.rfile.read(n) or b"{}")
        blob = json.dumps(req, ensure_ascii=False)
        is_child = "[task from parent]" in blob
        with LOCK:
            STATE["calls"].append(req)
            if is_child and CHILD_SCRIPT:
                i = STATE["ci"]; STATE["ci"] += 1
                script = CHILD_SCRIPT
            else:
                i = STATE["i"]; STATE["i"] += 1
                script = SCRIPT
        step = script[i] if i < len(script) else {"text": "끝."}

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()

        def chunk(delta: dict, finish=None):
            self.wfile.write(sse({"id": "c", "object": "chat.completion.chunk",
                                  "choices": [{"index": 0, "delta": delta,
                                               "finish_reason": finish}]}))
            self.wfile.flush()

        chunk({"role": "assistant", "content": ""})

        if "tool" in step:
            chunk({"tool_calls": [{"index": 0, "id": f"call_{i}", "type": "function",
                                   "function": {"name": "ipython", "arguments": ""}}]})
            args = json.dumps({"code": step["tool"]})
            for j in range(0, len(args), 40):
                chunk({"tool_calls": [{"index": 0,
                                       "function": {"arguments": args[j:j + 40]}}]})
            chunk({}, "tool_calls")
        else:
            for word in (step.get("text") or "").split(" "):
                chunk({"content": word + " "})
            chunk({}, "stop")

        self.wfile.write(sse({"id": "c", "object": "chat.completion.chunk", "choices": [],
                              "usage": {"prompt_tokens": 100, "completion_tokens": 20}}))
        self.wfile.write(b"data: [DONE]\n\n")
        self.wfile.flush()


def serve(port: int = 0) -> tuple[ThreadingHTTPServer, int]:
    srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    return srv, srv.server_address[1]


if __name__ == "__main__":
    path = os.environ.get("PA_MOCK_SCRIPT")
    if path:
        SCRIPT = json.loads(open(path, encoding="utf-8").read())
    srv, port = serve(int(sys.argv[1]) if len(sys.argv) > 1 else 8099)
    print(f"mock llm on http://127.0.0.1:{port}/v1", flush=True)
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        srv.shutdown()
