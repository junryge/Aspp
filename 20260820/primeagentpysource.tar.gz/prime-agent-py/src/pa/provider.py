"""OpenAI 호환 프로바이더 (스트리밍 + 툴 콜).

사내 vLLM / SGLang / Ollama / 게이트웨이를 그대로 붙일 수 있다.
`models.json` 의 `compat` 플래그로 서버별 차이를 흡수한다.

    supportsDeveloperRole   false → system 역할을 쓴다 (vLLM/SGLang 권장)
    supportsReasoningEffort false → reasoning_effort 를 보내지 않는다
    maxTokensField          "max_tokens" | "max_completion_tokens"
    thinkingFormat          "qwen-chat-template" → chat_template_kwargs.enable_thinking

**툴 콜 지원이 전제다.** 이 하네스의 유일한 툴이 `ipython` 이므로
tool calling 을 못 하는 모델은 쓸 수 없다.
vLLM 이면 `--enable-auto-tool-choice` 와 모델별 `--tool-call-parser` 를 켤 것.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Callable, Iterator

import httpx

from .config import Model
from .session import Usage

IPYTHON_TOOL = {
    "type": "function",
    "function": {
        "name": "ipython",
        "description": (
            "영속 IPython 커널에서 Python 코드를 실행한다. 이것이 유일한 툴이다.\n"
            "파일 읽기·쓰기·편집, 셸 명령, 데이터 처리, 스킬 호출, 서브에이전트 위임이 "
            "전부 이 안에서 코드로 일어난다.\n"
            "변수·import·함수는 호출과 턴을 넘어 유지된다."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "실행할 Python 코드 (셀 하나)"}
            },
            "required": ["code"],
        },
    },
}


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: str = ""

    def parsed(self) -> dict:
        try:
            return json.loads(self.arguments or "{}")
        except json.JSONDecodeError:
            # 일부 서버가 인자를 이중 인코딩하거나 잘라 보낸다 — 최대한 살려본다
            s = (self.arguments or "").strip()
            if s.startswith('"') and s.endswith('"'):
                try:
                    return json.loads(json.loads(s))
                except Exception:
                    pass
            return {"code": s} if s else {}


@dataclass
class Completion:
    text: str = ""
    thinking: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    usage: Usage = field(default_factory=Usage)
    stop_reason: str = "stop"     # stop | length | toolUse | error | aborted
    error: str | None = None


class ProviderError(RuntimeError):
    pass


def to_wire(messages: list[dict], model: Model, system: str | None) -> list[dict]:
    """내부 메시지 → OpenAI chat 포맷."""
    compat = model.compat or {}
    sys_role = "developer" if compat.get("supportsDeveloperRole") else "system"
    out: list[dict] = []
    if system:
        out.append({"role": sys_role, "content": system})

    for m in messages:
        role = m.get("role")
        if role == "system":
            out.append({"role": sys_role, "content": str(m.get("content") or "")})
        elif role == "user":
            c = m.get("content")
            out.append({"role": "user", "content": c if isinstance(c, str) else json.dumps(c)})
        elif role == "assistant":
            msg: dict[str, Any] = {"role": "assistant", "content": m.get("content") or ""}
            tcs = m.get("toolCalls") or []
            if tcs:
                msg["tool_calls"] = [
                    {"id": t["id"], "type": "function",
                     "function": {"name": t["name"],
                                  "arguments": t.get("arguments") or "{}"}}
                    for t in tcs
                ]
                if not msg["content"]:
                    msg["content"] = None
            out.append(msg)
        elif role == "toolResult":
            entry = {"role": "tool", "tool_call_id": m.get("toolCallId"),
                     "content": str(m.get("content") or "")}
            if compat.get("requiresToolResultName"):
                entry["name"] = m.get("toolName") or "ipython"
            out.append(entry)
        elif role == "bashExecution":
            out.append({"role": "user",
                        "content": f"$ {m.get('command')}\n{m.get('output') or ''}"})
    return out


def _payload(model: Model, wire: list[dict], thinking: str | None,
             tools: bool, temperature: float) -> dict:
    compat = model.compat or {}
    max_field = compat.get("maxTokensField") or "max_tokens"
    body: dict[str, Any] = {
        "model": model.id,
        "messages": wire,
        "stream": True,
        "temperature": temperature,
        max_field: model.max_tokens,
    }
    if compat.get("supportsUsageInStreaming", True):
        body["stream_options"] = {"include_usage": True}
    if tools:
        body["tools"] = [IPYTHON_TOOL]
        body["tool_choice"] = "auto"

    if thinking and thinking != "off" and model.reasoning:
        fmt = compat.get("thinkingFormat")
        if fmt == "qwen-chat-template":
            body["chat_template_kwargs"] = {"enable_thinking": True}
        elif fmt == "qwen":
            body["enable_thinking"] = True
        elif compat.get("supportsReasoningEffort", True):
            body["reasoning_effort"] = {"minimal": "low", "low": "low", "medium": "medium",
                                        "high": "high", "xhigh": "high",
                                        "max": "high"}.get(thinking, "medium")
    return body


def stream_completion(model: Model, messages: list[dict], *, system: str | None = None,
                      thinking: str | None = None, tools: bool = True,
                      temperature: float = 0.2, timeout: float = 600.0,
                      on_delta: Callable[[str, str], None] | None = None) -> Completion:
    """한 번의 모델 호출. `on_delta(kind, text)` 로 스트리밍 조각을 흘린다.

    kind 는 "text" | "thinking" | "tool".
    """
    if not model.base_url:
        raise ProviderError(
            f"모델 {model.selector} 에 baseUrl 이 없다. models.json 을 확인할 것"
        )

    headers = {"Content-Type": "application/json", **(model.headers or {})}
    if model.auth_header and model.api_key:
        headers["Authorization"] = f"Bearer {model.api_key}"

    url = model.base_url.rstrip("/") + "/chat/completions"
    body = _payload(model, to_wire(messages, model, system), thinking, tools, temperature)

    comp = Completion()
    tool_buf: dict[int, ToolCall] = {}

    try:
        with httpx.Client(timeout=httpx.Timeout(timeout, connect=30.0)) as client:
            with client.stream("POST", url, json=body, headers=headers) as r:
                if r.status_code >= 400:
                    detail = r.read().decode("utf-8", "replace")[:1500]
                    raise ProviderError(f"HTTP {r.status_code} — {detail}")
                for line in r.iter_lines():
                    if not line:
                        continue
                    if line.startswith("data:"):
                        line = line[5:].strip()
                    if line == "[DONE]":
                        break
                    if not line or line[0] != "{":
                        continue
                    try:
                        ev = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    if ev.get("usage"):
                        u = ev["usage"]
                        comp.usage.input = int(u.get("prompt_tokens") or 0)
                        comp.usage.output = int(u.get("completion_tokens") or 0)
                        details = u.get("prompt_tokens_details") or {}
                        comp.usage.cache_read = int(details.get("cached_tokens") or 0)

                    for choice in ev.get("choices") or []:
                        delta = choice.get("delta") or choice.get("message") or {}

                        rc = delta.get("reasoning_content") or delta.get("reasoning")
                        if rc:
                            comp.thinking += rc
                            if on_delta:
                                on_delta("thinking", rc)

                        c = delta.get("content")
                        if c:
                            comp.text += c
                            if on_delta:
                                on_delta("text", c)

                        for tc in delta.get("tool_calls") or []:
                            idx = int(tc.get("index") or 0)
                            slot = tool_buf.setdefault(
                                idx, ToolCall(id=tc.get("id") or f"call_{idx}", name=""))
                            if tc.get("id"):
                                slot.id = tc["id"]
                            fn = tc.get("function") or {}
                            if fn.get("name"):
                                slot.name = fn["name"]
                                if on_delta:
                                    on_delta("tool", fn["name"])
                            if fn.get("arguments"):
                                slot.arguments += fn["arguments"]

                        fr = choice.get("finish_reason")
                        if fr == "length":
                            comp.stop_reason = "length"
                        elif fr == "tool_calls":
                            comp.stop_reason = "toolUse"
    except ProviderError:
        raise
    except httpx.HTTPError as e:
        comp.error = f"{type(e).__name__}: {e}"
        comp.stop_reason = "error"
        return comp

    comp.tool_calls = [tool_buf[k] for k in sorted(tool_buf)]
    if comp.tool_calls and comp.stop_reason == "stop":
        comp.stop_reason = "toolUse"
    return comp


def probe(model: Model, timeout: float = 20.0) -> tuple[bool, str]:
    """엔드포인트 연결·인증·툴콜 지원을 빠르게 점검한다."""
    headers = {"Content-Type": "application/json", **(model.headers or {})}
    if model.auth_header and model.api_key:
        headers["Authorization"] = f"Bearer {model.api_key}"
    try:
        with httpx.Client(timeout=timeout) as c:
            r = c.get(model.base_url.rstrip("/") + "/models", headers=headers)
            if r.status_code >= 400:
                return False, f"GET /models → HTTP {r.status_code}"
            ids = [m.get("id") for m in (r.json().get("data") or [])]
            if ids and model.id not in ids:
                return True, f"연결 OK. 다만 서버 목록에 {model.id} 가 없다: {ids[:5]}"
            return True, f"연결 OK ({len(ids)}개 모델)"
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def estimate_tokens(messages: list[dict]) -> int:
    """토크나이저 없이 쓰는 근사치. 컴팩션 트리거 판단용으로만 쓴다.

    영문 ~4자/토큰, 한글은 그보다 훨씬 조밀하므로 보수적으로 2.5자/토큰으로 본다.
    """
    total = 0
    for m in messages:
        c = m.get("content")
        s = c if isinstance(c, str) else json.dumps(c, ensure_ascii=False, default=str)
        hangul = sum(1 for ch in s if "가" <= ch <= "힣")
        total += int((len(s) - hangul) / 4 + hangul / 1.5) + 8
        for t in m.get("toolCalls") or []:
            total += len(t.get("arguments") or "") // 4 + 8
    return total
