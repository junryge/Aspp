"""AgentSession — 에이전트 루프, 툴 디스패치, 호스트 요청 핸들러, 서브에이전트.

원본의 소유권 경계를 그대로 옮겼다.

    AgentSession  : 프로바이더 호출, 큐, 툴, 컴팩션, goal, 자식 라이프사이클, 트랜스크립트 기록
    IPython Kernel: 모델이 보는 실행면. 프로바이더 호출도, 에이전트 루프도 여기 없다

한 워커(= 이 프로세스)가 root 세션과 그 아래 RLM 자손 전부를 소유한다.
자식은 스레드로 돌고, 부모의 커널·프로바이더 설정·스킬을 상속한다.
"""

from __future__ import annotations

import json
import queue
import re
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from . import config, harness as harness_mod, provider as prov, skills as skills_mod
from .kernel import HostBridge, Kernel, format_tool_result
from .session import SessionManager, Usage, now_iso

BASE_SYSTEM_PROMPT = """\
너는 Prime Agent 다. 영속 Python 제어 환경 위에서 도는 코딩·리서치 에이전트다.

## 실행 모델

툴은 `ipython` **하나뿐이다.** 파일 읽기·쓰기·편집, 셸 명령, 데이터 처리, 스킬 호출,
서브에이전트 위임이 전부 그 안에서 Python 코드로 일어난다.
기능마다 툴이 따로 있는 구조가 아니다.

IPython 은 너의 오래 사는 노트북이다. 변수·import·헬퍼 함수·파싱 결과는
툴 호출과 턴과 컴팩션을 넘어 그대로 남는다. 툴 호출 자체가 Python `await` 식이므로
반환값을 변수에 묶어 프로그램 논리로 조립할 수 있다.

## 셸 규칙

- `%%bash` 는 셀의 **첫 줄**이어야 한다. 앞에 주석·공백·빈 줄·import·Python 문을 두지 않는다.
- `%%bash` 는 일회용 서브셸이다. `cd`, `export`, `source`, 셸 변수는 다음 셀로 넘어가지 않는다.
- 지속시키려면 `%cd <dir>` 와 `os.environ['VAR'] = '...'` 를 쓴다.

## 서브에이전트

    handle = await rlm("독립적인 하위 작업", name="reviewer")

`rlm(...)` 은 **작업 등록(admission) 시점에 즉시 반환한다. 자식의 답변을 반환하지 않는다.**
병렬 처리는 "여러 번 호출하고 턴을 끝내는 것"이다. 폴링하지 마라.
자식의 결과는 자식이 `await agent_message.send(msg, receiver_role="parent")` 를 부르거나
파일에 써야 온다.

## 하지 말 것

- `call_skill(...)`, `run_subagent(...)` 같은 없는 래퍼를 발명하지 마라.
- `time.sleep()` 이나 셸 `sleep` 으로 턴을 붙잡고 폴링하지 마라. 긴 블로킹 `await` 도 마찬가지다.
- 외부 프로젝트를 import·실행시키려고 커널에 의존성을 설치하지 마라.
  그 프로젝트의 환경을 써라 (`.venv/bin/python ...`).
- Python 예약어 때문에 `global=True` 는 문법 오류다. `global_=True` 를 써라.

## 작업 태도

정확성이 속도보다 우선이다. 확인하지 않은 것을 확인한 것처럼 말하지 마라.
파일을 고치기 전에 읽어라. 명령 결과를 지어내지 마라.
불확실하면 불확실하다고 말하고 무엇을 확인해야 하는지 적어라.
"""

CHILD_DOCTRINE = """\
## 자식 에이전트 지침

너는 {parent} 가 띄운 자식 에이전트다. 부모가 준 작업은 `[task from parent]` 로 표시된다.

작업이 답을 요구하면 반드시 명시적으로 회신해라:

    await agent_message.send("결과 요약", receiver_role="parent")

모든 메시지에 회신이 필요한 것은 아니다. 회신 후에는 정리 작업을 이어가고 평소처럼 유휴 상태로 간다.
"""


@dataclass
class Subagent:
    child_id: str
    name: str
    session_id: str | None
    session_dir: Path
    status: str = "running"          # running | completed | error
    thread: threading.Thread | None = None
    session: "AgentSession | None" = None
    error: str | None = None


@dataclass
class Goal:
    objective: str
    status: str = "active"           # active | paused | completed | budget | error
    token_budget: int | None = None
    tokens_used: int = 0
    started_at: float = field(default_factory=time.time)

    def to_json(self) -> dict:
        return {
            "objective": self.objective, "status": self.status,
            "token_budget": self.token_budget, "tokens_used": self.tokens_used,
            "time_used_seconds": int(time.time() - self.started_at),
        }


@dataclass
class Heartbeat:
    id: str
    instruction: str
    interval_s: int
    label: str | None = None
    delivery_mode: str = "steer"
    status: str = "active"
    next_at: float = 0.0
    owner: str = "agent"             # agent | user


def parse_interval(text: str | None, default: int = 300) -> int:
    if not text:
        return default
    m = re.match(r"^\s*(?:every\s+)?(\d+)\s*([smhd])?\s*$", str(text), re.I)
    if not m:
        return default
    n = int(m.group(1))
    return n * {"s": 1, "m": 60, "h": 3600, "d": 86400}.get((m.group(2) or "m").lower(), 60)


class AgentSession:
    """루트 또는 자식 하나에 대응하는 실행 단위."""

    def __init__(self, *, model, sm: SessionManager, cwd: Path, settings: dict,
                 skills: list, kernel: Kernel | None = None, bridge: HostBridge | None = None,
                 depth: int = 0, parent: "AgentSession | None" = None,
                 name: str | None = None, thinking: str | None = None,
                 emit: Callable[[str, dict], None] | None = None):
        self.model = model
        self.sm = sm
        self.cwd = Path(cwd)
        self.settings = settings
        self.skills = skills
        self.depth = depth
        self.parent = parent
        self.name = name or (f"root" if depth == 0 else f"child-{uuid.uuid4().hex[:6]}")
        self.thinking = thinking
        self.emit = emit or (lambda kind, data: None)

        self.harness = harness_mod.Harness(sm.artifact_dir() if sm.path else None)
        self.children: list[Subagent] = []
        self.inbox: "queue.Queue[dict]" = queue.Queue()
        self.goal: Goal | None = None
        self.heartbeats: list[Heartbeat] = []
        self._pending_compact: str | None = None
        self._pending_refine: dict | None = None
        self._compact_scheduled = False
        self._abort = threading.Event()
        self.usage = Usage()
        self.child_usage = Usage()
        self.last_assistant_entry: str | None = None
        self.status = "idle"

        self.bridge = bridge or HostBridge()
        self._own_bridge = bridge is None
        self._register_handlers()

        if kernel is not None:
            self.kernel = kernel
        else:
            env = {
                "RLM_DEPTH": str(depth),
                "RLM_MAX_DEPTH": str((settings.get("rlm") or {}).get("maxDepth", 2)),
                "RLM_SESSION_DIR": str(sm.artifact_dir()) if sm.path else "",
                "PA_SKILL_IMPORTS": ",".join(skills_mod.import_names(skills)),
                "PA_SKILL_PATHS": skills_mod.src_paths(skills),
            }
            self.kernel = Kernel(self.bridge, self.cwd, env)

    # ------------------------------------------------------------------ 시스템 프롬프트
    def system_prompt(self) -> str:
        parts = [BASE_SYSTEM_PROMPT]
        if self.depth > 0:
            parts.append(CHILD_DOCTRINE.format(
                parent=self.parent.name if self.parent else "부모"))

        sk = skills_mod.prompt_block(self.skills)
        if sk:
            parts.append(sk)

        hb = self.harness.prompt_block()
        if hb:
            parts.append(
                "## Continual Harness (보충 상태)\n"
                "아래는 이전 세션에서 축적된 보충 지시·메모리·재사용 스펙이다. "
                "기본 지침을 대체하지 않고 보충한다.\n\n" + hb
            )

        for fname in ("AGENTS.md", "CLAUDE.md"):
            for base in (self.cwd, config.agent_dir()):
                p = Path(base) / fname
                if p.exists():
                    try:
                        parts.append(f"## 컨텍스트 파일: {p}\n\n"
                                     + p.read_text(encoding="utf-8")[:20000])
                    except OSError:
                        pass

        if self.goal and self.goal.status == "active":
            parts.append(
                f"## 지속 목표\n\n{self.goal.objective}\n\n"
                f"이 목표는 완료·일시정지·해제될 때까지 매 턴 유지된다. "
                f"달성했다면 `await goal.complete()` 를 호출해라. "
                f"그것만이 성공 완료 신호다."
            )

        parts.append(f"작업 디렉터리: {self.cwd}\n현재 시각: {now_iso()}")
        return "\n\n".join(parts)

    # ------------------------------------------------------------------ 호스트 요청 핸들러
    def _register_handlers(self) -> None:
        b = self.bridge
        b.register("rlm.run", self._h_rlm_run)
        b.register("rlm.find_models", self._h_find_models)
        b.register("rlm.list_subagents", self._h_list_subagents)
        b.register("rlm.delete_subagent", self._h_delete_subagent)

        b.register("harness.overview", lambda p: self.harness.overview())
        b.register("harness.list", lambda p: self.harness.store(
            p.get("global", False)).list(p.get("kind")))
        b.register("harness.get", lambda p: self.harness.store(
            p.get("global", False)).get(p["id"], p.get("kind")))
        b.register("harness.delete", lambda p: self.harness.store(
            p.get("global", False)).delete(p["id"], p.get("kind")))
        b.register("harness.upsert", self._h_harness_upsert)
        b.register("harness.record_refinement", lambda p: self.harness.store(
            p.get("global", False)).record_refinement(
                p.get("trigger", ""), p.get("changes") or [],
                p.get("evidence", ""), p.get("outcome", "")))

        b.register("goal.get", lambda p: self._h_goal_get())
        b.register("goal.create", self._h_goal_create)
        b.register("goal.complete", lambda p: self._h_goal_complete())

        b.register("compact.status", lambda p: self._h_compact_status())
        b.register("compact.run", self._h_compact_run)
        b.register("refine.status", lambda p: {"pending": self._pending_refine is not None,
                                               "in_flight": False})
        b.register("refine.run", self._h_refine_run)

        b.register("agent_message.list_agents", lambda p: self._h_list_agents())
        b.register("agent_message.send", self._h_send)
        b.register("agent_message.broadcast", self._h_broadcast)

        b.register("agent_observe.list_agents", lambda p: self._h_list_agents())
        b.register("agent_observe.get_agent", self._h_observe_get)
        b.register("agent_observe.recent_messages", self._h_observe_recent)

        b.register("rlm_heartbeat.list", lambda p: [self._hb_json(h) for h in self.heartbeats
                                                    if h.owner == "agent"])
        b.register("rlm_heartbeat.create", self._h_hb_create)
        b.register("rlm_heartbeat.update", self._h_hb_update)
        b.register("rlm_heartbeat.delete", self._h_hb_delete)

    # -- rlm -----------------------------------------------------------------
    def _h_rlm_run(self, p: dict) -> dict:
        max_depth = int((self.settings.get("rlm") or {}).get("maxDepth", 2))
        if self.depth >= max_depth:
            raise RuntimeError(
                f"RLM 재귀 깊이 한도에 도달했다 (RLM_DEPTH={self.depth}, RLM_MAX_DEPTH={max_depth})"
            )
        prompt = p["prompt"]
        name = p.get("name") or f"child-{uuid.uuid4().hex[:6]}"
        if any(c.name == name for c in self.children):
            raise RuntimeError(f"형제 중에 같은 이름이 이미 있다: {name}")

        model = self.model
        if p.get("model"):
            from .config import find_model, load_models
            m = find_model(load_models(), p["model"])
            if m is None:
                # 원본과 동일: 조용히 다른 모델로 대체하지 않고 실패시킨다
                raise RuntimeError(f"요청한 모델을 쓸 수 없다: {p['model']}")
            model = m

        child_dir = self.sm.artifact_dir() / f"sub-{uuid.uuid4().hex[:8]}" if self.sm.path \
            else Path(self.cwd)
        child_dir.mkdir(parents=True, exist_ok=True)

        child_sm = SessionManager.create(self.cwd, session_dir=child_dir,
                                         persist=bool(self.sm.path),
                                         parent_session=str(self.sm.path) if self.sm.path else None)
        child = AgentSession(
            model=model, sm=child_sm, cwd=self.cwd, settings=self.settings,
            skills=self.skills, bridge=None, depth=self.depth + 1, parent=self,
            name=name, thinking=p.get("thinking") or self.thinking, emit=self.emit,
        )
        rec = Subagent(child_id=uuid.uuid4().hex[:12], name=name,
                       session_id=child_sm.session_id, session_dir=child_dir,
                       session=child)
        self.children.append(rec)

        def _work() -> None:
            try:
                child.run_turn(f"[task from parent]\n{prompt}")
                rec.status = "completed"
            except Exception as e:
                rec.status = "error"
                rec.error = f"{type(e).__name__}: {e}"
            finally:
                self.child_usage.add(child.usage)
                if self.last_assistant_entry:
                    try:
                        agg = Usage()
                        agg.add(self.usage)
                        agg.add(self.child_usage)
                        self.sm.append_child_usage(self.last_assistant_entry, child.usage, agg)
                    except Exception:
                        pass
                self.emit("child_end", {"name": name, "status": rec.status})

        rec.thread = threading.Thread(target=_work, name=f"rlm-{name}", daemon=True)
        rec.thread.start()
        self.emit("child_start", {"name": name, "model": model.selector, "prompt": prompt[:200]})

        return {"rlm_child_id": rec.child_id, "name": name,
                "session_dir": str(child_dir), "model": model.selector}

    def _h_find_models(self, p: dict) -> list[dict]:
        from .config import load_models
        q = (p.get("query") or "").lower()
        out = []
        for m in load_models():
            if q and q not in m.id.lower() and q not in m.name.lower() \
                    and q not in m.provider.lower():
                continue
            out.append({"provider": m.provider, "id": m.id, "name": m.name,
                        "selector": m.selector})
        return out[: int(p.get("limit") or 8)]

    def _h_list_subagents(self, p: dict) -> list[dict]:
        return [{"rlm_child_id": c.child_id, "session_id": c.session_id,
                 "session_name": c.name, "session_dir": str(c.session_dir),
                 "status": c.status} for c in self.children]

    def _h_delete_subagent(self, p: dict) -> dict:
        sel = str(p.get("target") or "")
        for c in list(self.children):
            if sel in (c.child_id, c.name, c.session_id):
                if c.session:
                    c.session.abort()
                self.children.remove(c)
                return {"deleted": c.name, "status": c.status,
                        "note": "툼스톤 기록. 디스크의 트랜스크립트와 아티팩트는 지우지 않는다"}
        raise RuntimeError(f"자식을 찾지 못했다: {sel}")

    # -- harness -------------------------------------------------------------
    def _h_harness_upsert(self, p: dict) -> dict:
        store = self.harness.store(p.get("global", False))
        return store.upsert(
            p["kind"], p["title"], p["content"], id=p.get("id"),
            path=p.get("path") or "general", reference=p.get("reference"),
            arguments=p.get("arguments"), metadata=p.get("metadata"),
            source="agent", mode=p.get("mode") or "upsert",
            scope="global" if p.get("global") else "local",
        )

    # -- goal ----------------------------------------------------------------
    def _h_goal_get(self) -> dict:
        remaining = None
        if self.goal and self.goal.token_budget:
            remaining = max(0, self.goal.token_budget - self.goal.tokens_used)
        return {"goal": self.goal.to_json() if self.goal else None,
                "remaining_tokens": remaining,
                "completion_budget_report": None}

    def _h_goal_create(self, p: dict) -> dict:
        if self.goal and self.goal.status in ("active", "paused", "budget"):
            raise RuntimeError("이미 진행 중인 goal 이 있다. 먼저 완료하거나 해제할 것")
        self.goal = Goal(objective=p["objective"], token_budget=p.get("token_budget"))
        self.emit("goal", {"action": "create", "objective": self.goal.objective})
        return self._h_goal_get()

    def _h_goal_complete(self) -> dict:
        if not self.goal:
            raise RuntimeError("설정된 goal 이 없다")
        self.goal.status = "completed"
        self.emit("goal", {"action": "complete", "objective": self.goal.objective})
        return self._h_goal_get()

    # -- compaction / refine --------------------------------------------------
    def _h_compact_status(self) -> dict:
        msgs = self.sm.build_context()
        tokens = prov.estimate_tokens(msgs)
        cw = self.model.context_window
        return {"tokens": tokens, "context_window": cw,
                "percent": round(tokens / cw * 100, 1) if cw else None,
                "scheduled": self._compact_scheduled}

    def _h_compact_run(self, p: dict) -> dict:
        if self._compact_scheduled:
            return {"scheduled": False, "reason": "이미 예약됨"}
        self._compact_scheduled = True
        self._pending_compact = p.get("instructions")
        return {"scheduled": True}

    def _h_refine_run(self, p: dict) -> dict:
        if self._pending_refine is not None:
            return {"scheduled": False, "reason": "이미 예약됨"}
        self._pending_refine = {"instructions": p.get("instructions"),
                                "scope": "global" if p.get("global") else "local"}
        return {"scheduled": True}

    # -- messaging -----------------------------------------------------------
    def _family(self) -> list[tuple[str, "AgentSession"]]:
        out: list[tuple[str, AgentSession]] = []
        if self.parent:
            out.append(("parent", self.parent))
            for c in self.parent.children:
                if c.session and c.session is not self:
                    out.append(("sibling", c.session))
        for c in self.children:
            if c.session:
                out.append(("child", c.session))
        return out

    def _h_list_agents(self) -> dict:
        entries = [{"relationship": rel, "name": s.name, "id": s.sm.session_id,
                    "depth": s.depth, "status": s.status} for rel, s in self._family()]
        entries.sort(key=lambda e: ({"parent": 0, "sibling": 1, "child": 2}[e["relationship"]],
                                    e["name"]))
        return {"current": {"name": self.name, "id": self.sm.session_id, "depth": self.depth},
                "entries": entries}

    def _resolve_target(self, role: str | None, name: str | None) -> "AgentSession":
        for rel, s in self._family():
            if role and rel != role:
                continue
            if role == "parent":
                return s
            if s.name == name:
                return s
        raise RuntimeError(f"대상을 찾지 못했다 (role={role}, name={name}). "
                           f"범위는 부모·형제·직계 자식뿐이다")

    def _h_send(self, p: dict) -> dict:
        target = self._resolve_target(p.get("receiver_role"), p.get("receiver_name"))
        busy = target.status == "running"
        target.inbox.put({"from": self.name, "text": p["message"], "at": time.time()})
        self.emit("message", {"from": self.name, "to": target.name,
                              "text": p["message"][:200]})
        return {"deliveryStatus": "queued" if busy else "delivered",
                ("queuedAt" if busy else "deliveredAt"): now_iso(),
                "receiver": target.name}

    def _h_broadcast(self, p: dict) -> dict:
        receipts = []
        for rel, s in self._family():
            try:
                s.inbox.put({"from": self.name, "text": p["message"], "at": time.time()})
                receipts.append({"receiver": s.name, "relationship": rel,
                                 "deliveryStatus": "queued"})
            except Exception as e:
                receipts.append({"receiver": s.name, "error": str(e)})
        return {"receipts": receipts}

    def _h_observe_get(self, p: dict) -> dict:
        t = p.get("target")
        for rel, s in self._family() + [("self", self)]:
            if s.name == t or s.sm.session_id == t:
                return {"agent": {"name": s.name, "session_id": s.sm.session_id,
                                  "relationship": rel, "cwd": str(s.cwd),
                                  "status": s.status, "depth": s.depth,
                                  "messages": len(s.sm.entries),
                                  "pending": s.inbox.qsize()}}
        raise RuntimeError(f"관측 대상을 찾지 못했다: {t}")

    def _h_observe_recent(self, p: dict) -> dict:
        t, limit, mx = p["target"], int(p["limit"]), int(p["max_chars"])
        for _, s in self._family() + [("self", self)]:
            if s.name == t or s.sm.session_id == t:
                msgs = [e for e in s.sm.entries if e.get("type") == "message"][-limit:]
                out = []
                for e in msgs:
                    m = e.get("message") or {}
                    c = m.get("content")
                    txt = c if isinstance(c, str) else json.dumps(c, ensure_ascii=False)
                    out.append({"role": m.get("role"), "preview": (txt or "")[:mx]})
                return {"agent": s.name, "messages": out}
        raise RuntimeError(f"관측 대상을 찾지 못했다: {t}")

    # -- heartbeats ----------------------------------------------------------
    @staticmethod
    def _hb_json(h: Heartbeat) -> dict:
        return {"id": h.id, "instruction": h.instruction, "interval": f"{h.interval_s}s",
                "label": h.label, "status": h.status, "delivery_mode": h.delivery_mode,
                "owner": h.owner}

    def _h_hb_create(self, p: dict) -> dict:
        h = Heartbeat(id=f"hb_{uuid.uuid4().hex[:8]}", instruction=p["instruction"],
                      interval_s=parse_interval(p.get("interval")), label=p.get("label"),
                      delivery_mode=p.get("delivery_mode") or "steer", owner="agent")
        h.next_at = time.time() + h.interval_s
        self.heartbeats.append(h)
        return {"heartbeat": self._hb_json(h)}

    def _h_hb_update(self, p: dict) -> dict:
        for h in self.heartbeats:
            if h.id == p["id"] and h.owner == "agent":
                if p.get("instruction"):
                    h.instruction = p["instruction"]
                if p.get("interval"):
                    h.interval_s = parse_interval(p["interval"])
                if p.get("label") is not None:
                    h.label = p["label"]
                if p.get("delivery_mode"):
                    h.delivery_mode = p["delivery_mode"]
                st = p.get("status")
                if st == "pause":
                    h.status = "paused"
                elif st == "resume":
                    h.status = "active"
                    h.next_at = time.time() + h.interval_s
                return {"heartbeat": self._hb_json(h)}
        raise RuntimeError(f"heartbeat 를 찾지 못했다: {p.get('id')}")

    def _h_hb_delete(self, p: dict) -> dict:
        for h in list(self.heartbeats):
            if h.id == p["id"] and h.owner == "agent":
                self.heartbeats.remove(h)
                return {"deleted": h.id}
        raise RuntimeError(f"heartbeat 를 찾지 못했다: {p.get('id')}")

    # ------------------------------------------------------------------ 실행
    def abort(self) -> None:
        self._abort.set()
        self.kernel.interrupt()

    def drain_inbox(self) -> list[str]:
        out = []
        while True:
            try:
                m = self.inbox.get_nowait()
            except queue.Empty:
                break
            out.append(f"[message from {m['from']}]\n{m['text']}")
        return out

    def run_turn(self, user_text: str | None, max_steps: int = 40) -> str:
        """사용자 입력 하나를 처리한다. 툴 호출이 끝날 때까지 루프를 돈다."""
        self._abort.clear()
        self.status = "running"
        try:
            if user_text:
                self.sm.append_message({"role": "user", "content": user_text,
                                        "timestamp": time.time()})
            self.maybe_compact()

            final_text = ""
            for step in range(max_steps):
                if self._abort.is_set():
                    final_text += "\n[중단됨]"
                    break

                messages = self.sm.build_context()
                self.emit("turn_start", {"step": step, "name": self.name})

                comp = prov.stream_completion(
                    self.model, messages, system=self.system_prompt(),
                    thinking=self.thinking,
                    on_delta=lambda k, t: self.emit("delta", {"kind": k, "text": t,
                                                              "name": self.name}),
                )
                if comp.error:
                    self.emit("error", {"text": comp.error})
                    self.sm.append_message({"role": "assistant", "content": "",
                                            "provider": self.model.provider,
                                            "model": self.model.id,
                                            "stopReason": "error",
                                            "errorMessage": comp.error,
                                            "timestamp": time.time()})
                    raise prov.ProviderError(comp.error)

                self.usage.add(comp.usage)
                if self.goal:
                    self.goal.tokens_used += comp.usage.total

                msg: dict[str, Any] = {
                    "role": "assistant",
                    "content": comp.text,
                    "provider": self.model.provider,
                    "model": self.model.id,
                    "api": self.model.api,
                    "usage": comp.usage.to_json(),
                    "stopReason": comp.stop_reason,
                    "timestamp": time.time(),
                }
                if comp.thinking:
                    msg["thinking"] = comp.thinking
                if comp.tool_calls:
                    msg["toolCalls"] = [{"id": t.id, "name": t.name, "arguments": t.arguments}
                                        for t in comp.tool_calls]
                self.last_assistant_entry = self.sm.append_message(msg)
                final_text = comp.text or final_text

                if not comp.tool_calls:
                    break

                for tc in comp.tool_calls:
                    if tc.name != "ipython":
                        result = f"알 수 없는 툴: {tc.name}. 이 하네스의 툴은 ipython 하나뿐이다."
                    else:
                        code = tc.parsed().get("code") or ""
                        self.emit("tool_call", {"code": code, "name": self.name})
                        res = self.kernel.execute(code)
                        result = format_tool_result(res)
                        self.emit("tool_result", {"text": result, "name": self.name,
                                                  "error": bool(res.get("error"))})
                    self.sm.append_message({
                        "role": "toolResult", "toolCallId": tc.id, "toolName": tc.name,
                        "content": result, "isError": False, "timestamp": time.time(),
                    })

                # 커널이 요청한 후처리는 셀 중간이 아니라 여기(턴 경계)에서 돈다
                if self._compact_scheduled:
                    self.compact(self._pending_compact)
                    self._compact_scheduled = False
                    self._pending_compact = None

                for m in self.drain_inbox():
                    self.sm.append_message({"role": "user", "content": m,
                                            "timestamp": time.time()})

            if self._pending_refine is not None:
                spec = self._pending_refine
                self._pending_refine = None
                try:
                    self.refine(spec.get("instructions"), spec.get("scope") or "local")
                except Exception as e:
                    self.emit("error", {"text": f"refine 실패: {e}"})

            return final_text
        finally:
            self.status = "idle"

    # ------------------------------------------------------------------ 컴팩션
    def maybe_compact(self) -> None:
        cfg = self.settings.get("compaction") or {}
        if not cfg.get("enabled", True):
            return
        reserve = int(cfg.get("reserveTokens", 16384))
        msgs = self.sm.build_context()
        if prov.estimate_tokens(msgs) > max(1, self.model.context_window - reserve):
            self.compact(None)

    def compact(self, instructions: str | None) -> None:
        cfg = self.settings.get("compaction") or {}
        keep = int(cfg.get("keepRecentTokens", 20000))

        chain = [e for e in self.sm.branch() if e.get("type") == "message"]
        if len(chain) < 4:
            return

        # 뒤에서부터 keep 토큰까지 누적하며 컷 포인트를 찾는다.
        # 툴 결과에서는 자르지 않는다 — 툴 호출과 붙어 있어야 한다.
        acc, cut = 0, len(chain)
        for i in range(len(chain) - 1, -1, -1):
            m = chain[i].get("message") or {}
            acc += prov.estimate_tokens([m])
            if acc >= keep:
                cut = i
                while cut < len(chain) and \
                        (chain[cut].get("message") or {}).get("role") == "toolResult":
                    cut += 1
                break
        if cut <= 0 or cut >= len(chain):
            return

        to_sum = [c.get("message") or {} for c in chain[:cut]]
        first_kept = chain[cut]["id"]
        tokens_before = prov.estimate_tokens(self.sm.build_context())

        transcript = _serialize(to_sum)
        ask = ("아래 대화를 요약해라. 형식은 정확히 다음 섹션을 쓴다:\n"
               "## Goal\n## Constraints & Preferences\n## Progress\n"
               "### Done\n### In Progress\n### Blocked\n"
               "## Key Decisions\n## Next Steps\n## Critical Context\n"
               "마지막에 <read-files></read-files> 와 <modified-files></modified-files> 블록을 넣는다.\n")
        if instructions:
            ask += f"\n사용자 지시(최우선): {instructions}\n"
        ask += "\n<conversation>\n" + transcript[-100000:] + "\n</conversation>"

        try:
            comp = prov.stream_completion(self.model, [{"role": "user", "content": ask}],
                                          system="너는 대화 요약기다. 요약만 출력한다.",
                                          tools=False, temperature=0.0)
            summary = comp.text.strip()
        except Exception as e:
            self.emit("error", {"text": f"컴팩션 요약 실패: {e}"})
            return
        if not summary:
            return

        details = _file_ops(to_sum)
        self.sm.append_compaction(summary, first_kept, tokens_before, details, instructions)
        self.emit("compaction", {"tokensBefore": tokens_before, "name": self.name})

    # ------------------------------------------------------------------ refine
    def refine(self, instructions: str | None, scope: str = "local",
               rollback_id: str | None = None) -> dict:
        if rollback_id:
            for rec in reversed(self.harness.history(200)):
                if rec.get("id") == rollback_id:
                    out = harness_mod.rollback(self.harness, rec)
                    self.emit("refine", {"rollback": rollback_id})
                    return out
            raise RuntimeError(f"롤백 대상을 찾지 못했다: {rollback_id}")

        transcript = _serialize([e.get("message") or {} for e in self.sm.branch()
                                 if e.get("type") == "message"])
        msgs = harness_mod.build_refine_prompt(self.harness, transcript, scope, instructions)
        comp = prov.stream_completion(self.model, msgs, system=harness_mod.REFINE_SYSTEM,
                                      tools=False, temperature=0.0)
        proposal = _extract_json(comp.text)
        if not proposal:
            raise RuntimeError("정제 제안을 JSON 으로 파싱하지 못했다")
        record = harness_mod.apply_proposal(self.harness, proposal, scope)
        if self.sm.path:
            self.sm.append_custom("prime-agent.refinement", record)
        self.emit("refine", {"summary": record.get("summary"),
                             "edits": len([e for e in record["edits"] if e.get("applied")])})
        return record

    # ------------------------------------------------------------------ 정리
    def close(self) -> None:
        for c in self.children:
            if c.session:
                c.session.close()
        try:
            self.kernel.shutdown()
        finally:
            if self._own_bridge:
                self.bridge.close()


# --------------------------------------------------------------------------- helpers
def _serialize(messages: list[dict]) -> str:
    """원본 `serializeConversation()` 에 대응. 툴 결과는 2000자로 자른다."""
    out = []
    for m in messages:
        role = m.get("role")
        if role == "user":
            out.append(f"[User]: {m.get('content')}")
        elif role == "assistant":
            if m.get("thinking"):
                out.append(f"[Assistant thinking]: {m['thinking'][:2000]}")
            if m.get("content"):
                out.append(f"[Assistant]: {m['content']}")
            for t in m.get("toolCalls") or []:
                out.append(f"[Assistant tool calls]: {t['name']}({t.get('arguments','')[:1500]})")
        elif role == "toolResult":
            c = str(m.get("content") or "")
            if len(c) > 2000:
                c = c[:2000] + f"\n... [{len(c) - 2000}자 잘림]"
            out.append(f"[Tool result]: {c}")
    return "\n".join(out)


_READ = re.compile(r"""(?:open|read_text|Path)\(\s*['"]([^'"]+)['"]""")
_WRITE = re.compile(r"""(?:write_text|to_csv|to_excel|savefig)\(\s*['"]?([^'",)]*)""")


def _file_ops(messages: list[dict]) -> dict:
    read: set[str] = set()
    mod: set[str] = set()
    for m in messages:
        for t in m.get("toolCalls") or []:
            args = t.get("arguments") or ""
            read.update(_READ.findall(args))
            mod.update(x for x in _WRITE.findall(args) if x)
    return {"readFiles": sorted(read)[:100], "modifiedFiles": sorted(mod)[:100]}


def _extract_json(text: str) -> dict | None:
    text = (text or "").strip()
    fence = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.S)
    if fence:
        text = fence.group(1)
    start = text.find("{")
    if start < 0:
        return None
    depth, in_str, esc = 0, False, False
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start:i + 1])
                except json.JSONDecodeError:
                    return None
    return None
