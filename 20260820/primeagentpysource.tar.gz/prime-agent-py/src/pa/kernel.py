"""영속 IPython 커널 + 호스트 브리지.

원본은 워커(TypeScript) ↔ 커널(Python) 사이를 Jupyter comm `host.request` 로 연결한다.
이 포팅본은 호스트도 Python 이므로 더 단순하게 간다:

    커널 안의 shim  ──loopback TCP(토큰 인증, 줄단위 JSON)──▶  호스트

Windows 에서 유닉스 소켓/named pipe 를 신경 쓸 필요가 없고, 커널이 별도 프로세스라
모델이 커널을 죽여도 호스트는 살아남는다는 원본의 성질도 그대로 유지된다.

주의(원본과 동일): 커널은 모델이 만든 Python 을 **호스트와 같은 OS 권한으로** 실행한다.
프로세스 분리는 라이프사이클 격리이지 보안 샌드박스가 아니다.
"""

from __future__ import annotations

import json
import os
import queue
import secrets
import socket
import threading
import time
from pathlib import Path
from typing import Any, Callable

from . import config

# 커널 안에서 실행되는 부트스트랩. 원본의 RLM_BOOTSTRAP_BASE_CODE 에 대응한다.
BOOTSTRAP = '''
import asyncio as _asyncio, os as _os, sys as _sys
try:
    import nest_asyncio as _na; _na.apply()
except Exception:
    pass
_sys.path.insert(0, {runtime_path!r})
import rlm as _rlm_module
_rlm_module.connect({host!r}, {port!r}, {token!r})

# 원본과 동일한 바인딩: `rlm` 이라는 이름은 호출 가능한 객체를 가리키고,
# sys.modules["rlm"] 는 패키지로 남아 스킬들이 `from rlm import host_request` 를 할 수 있다.
rlm = _rlm_module.rlm
harness = _rlm_module.harness
agent_message = _rlm_module.agent_message
agent_observe = _rlm_module.agent_observe
goal = _rlm_module.goal
compact = _rlm_module.compact
refine = _rlm_module.refine
rlm_heartbeat = _rlm_module.rlm_heartbeat
edit = _rlm_module.edit
del _rlm_module


def _rlm_wrap_skill(_mod):
    """`run()` 이 있는 스킬 모듈을 async callable 로 감싼다 (원본과 동일한 규약).

    `await word_count("텍스트")` 가 `await word_count.run("텍스트")` 와 같아지고,
    `help(word_count)` 가 run() 의 docstring/시그니처를 보여준다.
    """
    import functools as _ft, inspect as _isp, types as _t
    _run = getattr(_mod, "run", None)
    if _run is None or not callable(_run):
        return _mod

    class _CallableModule(_t.ModuleType):
        def __call__(self, *a, **k):
            return _run(*a, **k)

    _mod.__class__ = _CallableModule
    try:
        _mod.__doc__ = _run.__doc__ or _mod.__doc__
        _mod.__signature__ = _isp.signature(_run)
    except Exception:
        pass
    return _mod
'''


class HostBridge:
    """커널 shim 의 요청을 받아 등록된 핸들러로 넘긴다."""

    def __init__(self) -> None:
        self.token = secrets.token_hex(16)
        self._handlers: dict[str, Callable[[dict], Any]] = {}
        self._srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._srv.bind(("127.0.0.1", 0))
        self._srv.listen(16)
        self.port = self._srv.getsockname()[1]
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()

    def register(self, name: str, fn: Callable[[dict], Any]) -> None:
        self._handlers[name] = fn

    def _serve(self) -> None:
        while not self._stop.is_set():
            try:
                self._srv.settimeout(0.5)
                conn, _ = self._srv.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            threading.Thread(target=self._client, args=(conn,), daemon=True).start()

    def _client(self, conn: socket.socket) -> None:
        conn.settimeout(None)
        buf = b""
        try:
            while not self._stop.is_set():
                chunk = conn.recv(65536)
                if not chunk:
                    break
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    if not line.strip():
                        continue
                    self._handle_line(conn, line)
        except OSError:
            pass
        finally:
            try:
                conn.close()
            except OSError:
                pass

    def _handle_line(self, conn: socket.socket, line: bytes) -> None:
        try:
            req = json.loads(line.decode("utf-8"))
        except Exception:
            return
        rid = req.get("rid")
        if req.get("token") != self.token:
            self._reply(conn, rid, {"status": "error", "error": "unauthorized"})
            return
        rtype = req.get("type") or ""
        payload = req.get("payload") or {}
        fn = self._handlers.get(rtype)
        if fn is None:
            self._reply(conn, rid, {"status": "error",
                                    "error": f"등록되지 않은 host request: {rtype}"})
            return
        try:
            result = fn(payload)
            self._reply(conn, rid, {"status": "ok", "result": result})
        except Exception as e:  # 호스트 오류는 커널에서 RuntimeError 로 올라간다
            self._reply(conn, rid, {"status": "error", "error": f"{type(e).__name__}: {e}"})

    @staticmethod
    def _reply(conn: socket.socket, rid: Any, obj: dict) -> None:
        obj["rid"] = rid
        try:
            conn.sendall((json.dumps(obj, ensure_ascii=False) + "\n").encode("utf-8"))
        except OSError:
            pass

    def close(self) -> None:
        self._stop.set()
        try:
            self._srv.close()
        except OSError:
            pass


class Kernel:
    """jupyter_client 로 띄우는 영속 IPython 커널.

    - 첫 사용 시 lazy 하게 뜬다 (원본과 동일)
    - execute() 는 직렬화된다: 커널 1개 = 네임스페이스 1개
    - 상태는 턴·컴팩션을 넘어 유지된다
    """

    def __init__(self, bridge: HostBridge, cwd: Path, env: dict[str, str] | None = None):
        self.bridge = bridge
        self.cwd = Path(cwd)
        self.env = env or {}
        self._km = None
        self._kc = None
        # start() → _bootstrap() → execute() 로 재진입하므로 RLock 이어야 한다
        self._lock = threading.RLock()
        self.started = False

    # ------------------------------------------------------------------ lifecycle
    def start(self) -> None:
        if self.started:
            return
        with self._lock:
            if self.started:
                return
            try:
                from jupyter_client.manager import KernelManager
            except ImportError as e:
                raise RuntimeError(
                    "jupyter_client 가 없다. `pip install jupyter-client ipykernel` 후 다시 시도할 것"
                ) from e

            import os
            env = dict(os.environ)
            env.update(self.env)
            env["PYTHONUNBUFFERED"] = "1"

            km = KernelManager(kernel_name="python3")
            km.kernel_cmd = [config.kernel_python(), "-m", "ipykernel_launcher",
                             "-f", "{connection_file}"]
            km.start_kernel(cwd=str(self.cwd), env=env)
            kc = km.client()
            kc.start_channels()
            kc.wait_for_ready(timeout=90)
            self._km, self._kc = km, kc
            self.started = True
            self._bootstrap()

    def _bootstrap(self) -> None:
        runtime_path = str(Path(__file__).resolve().parent / "kernel_runtime")
        code = BOOTSTRAP.format(runtime_path=runtime_path, host="127.0.0.1",
                                port=self.bridge.port, token=self.bridge.token)
        # Python 스킬의 src 디렉터리를 그대로 sys.path 에 넣는다.
        # pip install 없이도 import 되므로 폐쇄망에서 설치 단계가 하나 줄어든다.
        for sp in filter(None, (self.env.get("PA_SKILL_PATHS") or "").split(os.pathsep)):
            code += f"\n_sys.path.insert(0, {sp!r})"

        extra = self.env.get("PA_SKILL_IMPORTS", "")
        if extra:
            lines = []
            for name in extra.split(","):
                name = name.strip()
                if not name:
                    continue
                # import 실패가 커널을 깨뜨리지 않게 한다 — 원본과 동일하게
                # 이름은 바인딩하되 호출 시 원래 에러를 담은 RuntimeError 를 던진다
                lines.append(
                    f"try:\n"
                    f"    import {name}\n"
                    f"except Exception as _e:\n"
                    f"    class _Missing_{name}:\n"
                    f"        _err = _e\n"
                    f"        def __call__(self, *a, **k):\n"
                    f"            raise RuntimeError('스킬 {name} import 실패: %s' % self._err)\n"
                    f"        def __repr__(self):\n"
                    f"            return '<스킬 {name} 사용 불가: %s>' % self._err\n"
                    f"    {name} = _Missing_{name}()\n"
                    f"else:\n"
                    f"    {name} = _rlm_wrap_skill({name})\n"
                )
            code += "\n" + "\n".join(lines)
        res = self.execute(code, timeout=120, silent=True)
        if res.get("error"):
            raise RuntimeError("커널 부트스트랩 실패:\n" + res.get("text", ""))

    def shutdown(self) -> None:
        if not self.started:
            return
        try:
            if self._kc:
                self._kc.stop_channels()
            if self._km:
                self._km.shutdown_kernel(now=True)
        except Exception:
            pass
        self.started = False

    def interrupt(self) -> None:
        if self._km:
            try:
                self._km.interrupt_kernel()
            except Exception:
                pass

    # ------------------------------------------------------------------ execute
    def execute(self, code: str, timeout: float = 600.0, silent: bool = False) -> dict:
        """셀 하나를 실행하고 stdout/stderr/result/error 를 모아 반환한다."""
        if not self.started:
            self.start()
        assert self._kc is not None

        with self._lock:
            msg_id = self._kc.execute(code, store_history=not silent, allow_stdin=False)
            out: list[str] = []
            error: str | None = None
            result: str | None = None
            images: list[str] = []
            deadline = time.time() + timeout
            idle = False

            while time.time() < deadline:
                try:
                    msg = self._kc.get_iopub_msg(timeout=0.4)
                except queue.Empty:
                    if idle:
                        break
                    continue
                parent = (msg.get("parent_header") or {}).get("msg_id")
                mtype = msg.get("msg_type")
                content = msg.get("content") or {}

                if parent != msg_id:
                    continue  # 다른 실행의 출력은 무시 (원본의 parent_header 필터와 동일)

                if mtype == "stream":
                    out.append(content.get("text", ""))
                elif mtype in ("execute_result", "display_data"):
                    data = content.get("data") or {}
                    if "text/plain" in data:
                        result = data["text/plain"]
                    for mime in ("image/png", "image/jpeg"):
                        if mime in data:
                            images.append(f"{mime}:{data[mime][:32]}...")
                elif mtype == "error":
                    error = "\n".join(content.get("traceback") or []) or content.get("evalue", "")
                elif mtype == "status" and content.get("execution_state") == "idle":
                    idle = True

            text = "".join(out)
            if result:
                text = (text + ("\n" if text and not text.endswith("\n") else "") + result)
            if images:
                text += f"\n[이미지 출력 {len(images)}개]"
            return {"text": text.rstrip(), "error": error, "timeout": time.time() >= deadline}


def format_tool_result(res: dict, limit: int = 30000) -> str:
    """커널 실행 결과를 모델에게 돌려줄 문자열로 만든다."""
    if res.get("error"):
        body = res["error"]
        head = ""
    else:
        body = res.get("text") or ""
        head = "" if body else "(출력 없음)"
    s = head + body
    if res.get("timeout"):
        s += "\n[실행 시간 초과 — 커널은 계속 살아 있다]"
    if len(s) > limit:
        s = s[:limit] + f"\n... [{len(s) - limit}자 잘림]"
    return s
