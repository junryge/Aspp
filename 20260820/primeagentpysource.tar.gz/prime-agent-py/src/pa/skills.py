"""스킬 탐색·검증·로딩.

원본 `docs/skills.md` 의 계약을 그대로 구현한다. 저장소의 스킬 디렉터리를
**수정 없이 그대로** 쓸 수 있다.

Python 스킬 계약 — 4개가 전부 성립해야 한다. 하나라도 어긋나면
경고와 함께 마크다운 전용으로 조용히 강등된다:

  1. SKILL.md 존재 (프론트매터에 name, description 필수)
  2. 스킬 루트에 pyproject.toml 존재  ← 이 파일의 존재가 Python 스킬임을 표시
  3. import 이름 = 스킬명의 하이픈을 언더스코어로 바꾼 것, 유효한 Python 식별자
  4. src/<import_name>/__init__.py 존재

탐색 우선순위(높음 → 낮음): 명시 경로 → 프로젝트 → 전역 → 번들
이름 충돌 시 **처음 찾은 것**을 유지하고 경고한다.
"""

from __future__ import annotations

import keyword
import re
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

from . import config


@dataclass
class Skill:
    name: str
    description: str
    path: Path                    # SKILL.md 경로
    root: Path                    # 스킬 디렉터리
    python: bool = False
    import_name: str | None = None
    source: str = "project"       # explicit | project | global | bundled
    disable_model_invocation: bool = False
    warnings: list[str] = field(default_factory=list)

    def body(self) -> str:
        text = self.path.read_text(encoding="utf-8")
        _, _, rest = _split_frontmatter(text)
        return rest.strip()


_FM = re.compile(r"^---\s*\n(.*?)\n---\s*\n?", re.S)


def _split_frontmatter(text: str) -> tuple[dict, str, str]:
    m = _FM.match(text)
    if not m:
        return {}, "", text
    raw = m.group(1)
    data: dict[str, str] = {}
    key = None
    for line in raw.splitlines():
        if not line.strip():
            continue
        if re.match(r"^\s+", line) and key:      # 아주 단순한 연속 줄 처리
            data[key] += " " + line.strip()
            continue
        if ":" in line:
            key, _, val = line.partition(":")
            key = key.strip()
            data[key] = val.strip().strip('"').strip("'")
    return data, raw, text[m.end():]


_NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")


def _validate_name(name: str, root: Path) -> list[str]:
    w = []
    if not name:
        w.append("name 이 없다")
        return w
    if len(name) > 64:
        w.append("name 이 64자를 넘는다")
    if not _NAME_RE.match(name):
        w.append(f"name 규칙 위반: 소문자·숫자·하이픈만, 선행/후행/연속 하이픈 금지 ({name!r})")
    if name != root.name:
        w.append(f"name({name!r}) 이 디렉터리명({root.name!r}) 과 다르다")
    return w


def load_skill(skill_md: Path, source: str = "project") -> Skill | None:
    try:
        text = skill_md.read_text(encoding="utf-8")
    except OSError:
        return None
    fm, _, _ = _split_frontmatter(text)
    root = skill_md.parent
    name = fm.get("name") or root.name
    desc = fm.get("description") or ""

    # description 없는 스킬은 로드하지 않는다 (원본과 동일)
    if not desc.strip():
        return None

    warnings = _validate_name(name, root)
    if len(desc) > 1024:
        warnings.append("description 이 1024자를 넘는다")

    py = False
    import_name = None
    if (root / "pyproject.toml").exists():
        cand = name.replace("-", "_")
        if cand.isidentifier() and not keyword.iskeyword(cand):
            if (root / "src" / cand / "__init__.py").exists():
                py, import_name = True, cand
            else:
                warnings.append(
                    f"pyproject.toml 은 있으나 src/{cand}/__init__.py 가 없다 "
                    f"→ 마크다운 전용으로 강등"
                )
        else:
            warnings.append(f"import 이름 {cand!r} 이 유효한 Python 식별자가 아니다 → 강등")

    return Skill(
        name=name, description=desc.strip(), path=skill_md, root=root,
        python=py, import_name=import_name, source=source,
        disable_model_invocation=str(fm.get("disable-model-invocation", "")).lower() == "true",
        warnings=warnings,
    )


def _scan_dir(d: Path, source: str, allow_root_md: bool = True) -> list[Skill]:
    out: list[Skill] = []
    if not d.is_dir():
        return out
    for sm in sorted(d.rglob("SKILL.md")):
        s = load_skill(sm, source)
        if s:
            out.append(s)
    if allow_root_md:
        for md in sorted(d.glob("*.md")):
            if md.name == "SKILL.md":
                continue
            s = load_skill(md, source)
            if s:
                out.append(s)
    return out


def discover(cwd: Path, settings: dict, explicit: list[Path] | None = None,
             enable_builtin: bool = True) -> tuple[list[Skill], list[str]]:
    """우선순위 순으로 스킬을 모으고 이름 충돌은 처음 것을 유지한다."""
    found: list[Skill] = []
    notes: list[str] = []

    for p in explicit or []:
        p = Path(p)
        sm = p if p.name.endswith(".md") else p / "SKILL.md"
        s = load_skill(sm, "explicit") if sm.exists() else None
        if s:
            found.append(s)
        else:
            notes.append(f"스킬을 로드하지 못했다: {p}")

    # settings.skills — 경로 목록, '-이름' 은 제외
    excludes: set[str] = set()
    for raw in settings.get("skills") or []:
        if isinstance(raw, str) and raw.startswith("-"):
            excludes.add(raw[1:].split("/")[0])
            continue
        p = Path(str(raw)).expanduser()
        if not p.is_absolute():
            p = (config.agent_dir() / p).resolve()
        found.extend(_scan_dir(p, "explicit"))

    found.extend(_scan_dir(Path(cwd) / ".prime" / "agent-py" / "skills", "project"))
    found.extend(_scan_dir(Path(cwd) / ".agents" / "skills", "project", allow_root_md=False))
    found.extend(_scan_dir(config.agent_dir() / "skills", "global"))
    found.extend(_scan_dir(Path.home() / ".agents" / "skills", "global", allow_root_md=False))

    if enable_builtin:
        found.extend(_scan_dir(Path(__file__).resolve().parent / "bundled_skills", "bundled"))

    seen: dict[str, Skill] = {}
    for s in found:
        if s.name in excludes:
            continue
        if s.name in seen:
            notes.append(f"스킬 이름 충돌: {s.name} — {seen[s.name].source} 것을 유지하고 "
                         f"{s.source}({s.root}) 는 무시")
            continue
        seen[s.name] = s
        for w in s.warnings:
            notes.append(f"[{s.name}] {w}")
    return list(seen.values()), notes


def install_python_skills(skills: list[Skill], python: str | None = None,
                          wheelhouse: Path | None = None) -> list[str]:
    """Python 스킬을 커널 인터프리터에 editable 로 설치한다.

    폐쇄망에서는 wheelhouse 를 주면 `--no-index --find-links` 로 오프라인 설치한다.
    """
    py = python or config.kernel_python()
    notes: list[str] = []
    for s in skills:
        if not s.python:
            continue
        try:
            __import__(s.import_name)  # 호스트에서 되면 커널에서도 될 가능성이 높다
        except Exception:
            pass
        cmd = [py, "-m", "pip", "install", "-q"]
        if wheelhouse:
            cmd += ["--no-index", "--find-links", str(wheelhouse)]
        cmd += ["-e", str(s.root)]
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
            if r.returncode != 0:
                notes.append(f"[{s.name}] 설치 실패: {(r.stderr or '').strip().splitlines()[-1:]}")
        except Exception as e:
            notes.append(f"[{s.name}] 설치 오류: {e}")
    return notes


def prompt_block(skills: list[Skill]) -> str:
    """시스템 프롬프트에 넣을 스킬 목록. 설명만 넣는 점진적 공개."""
    vis = [s for s in skills if not s.disable_model_invocation]
    if not vis:
        return ""
    lines = ["<available_skills>"]
    for s in vis:
        attrs = f'name="{s.name}"'
        if s.python:
            attrs += f' type="python" import="{s.import_name}"'
        else:
            attrs += ' type="markdown"'
        lines.append(f'  <skill {attrs} path="{s.path}">{s.description}</skill>')
    lines.append("</available_skills>")
    lines.append(
        "스킬 전문이 필요하면 ipython 에서 그 SKILL.md 를 읽어라. "
        "python 타입은 이미 커널에 import 되어 있으므로 `await <import>(...)` 로 바로 부른다."
    )
    return "\n".join(lines)


def import_names(skills: list[Skill]) -> list[str]:
    return [s.import_name for s in skills if s.python and s.import_name]


def src_paths(skills: list[Skill]) -> str:
    """Python 스킬의 src 디렉터리를 os.pathsep 로 이어 붙인다.

    커널이 이 경로들을 sys.path 에 넣으므로 `pip install -e` 없이도 import 된다.
    폐쇄망에서 설치 단계를 하나 줄여준다.
    """
    import os as _os
    return _os.pathsep.join(str(s.root / "src") for s in skills
                            if s.python and (s.root / "src").is_dir())
