"""Continual Harness — 세션보다 오래 사는 보충 상태.

원본과 동일한 파일 구조를 쓴다.

    <세션 아티팩트>/harness/harness_state.json     로컬(기본)
    <agent_dir>/harness/harness_state.json          전역
    <agent_dir>/harness/refinements.jsonl           전역 refine 이력 (롤백 소스)

    {"schema": 1,
     "entries": {"prompt": {}, "memory": {}, "skill": {}, "subagent": {}},
     "refinements": []}

불변식
------
* 기본 시스템 프롬프트는 **불변**이다. `base_system_prompt` id 는 하드 거부한다.
* 로컬 refine 중 전역 엔트리는 읽기 전용 컨텍스트다.
* 모든 적용 편집은 before/after 스냅샷을 남기고 역순 재생으로 롤백된다.
* 디스크 mtime 이 바뀌면 다시 읽는다 — 커널 쓰기와 호스트 쓰기가 서로를 덮지 않게.
"""

from __future__ import annotations

import json
import os
import re
import secrets
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from . import config

KINDS = ("prompt", "memory", "skill", "subagent")
BASE_PROMPT_ID = "base_system_prompt"
STATE_FILE = "harness_state.json"
HISTORY_FILE = "refinements.jsonl"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def _slug(title: str, kind: str) -> str:
    s = re.sub(r"[^0-9a-zA-Z가-힣]+", "_", title.lower()).strip("_")
    return (s or kind)[:80]


def _empty() -> dict:
    return {"schema": 1, "entries": {k: {} for k in KINDS}, "refinements": []}


def _atomic_write(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, path)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    finally:
        if os.path.exists(tmp):
            try:
                os.unlink(tmp)
            except OSError:
                pass


class HarnessStore:
    """하나의 harness_state.json 에 대한 CRUD."""

    def __init__(self, path: Path):
        self.path = Path(path)
        self._data = _empty()
        self._mtime = -1.0
        self._sync()

    def _sync(self) -> None:
        """디스크가 바뀌었으면 다시 읽는다. 손상 파일은 예외 대신 빈 상태로 degrade."""
        try:
            m = self.path.stat().st_mtime_ns
        except OSError:
            return
        if m == self._mtime:
            return
        try:
            d = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(d, dict) and isinstance(d.get("entries"), dict):
                for k in KINDS:
                    d["entries"].setdefault(k, {})
                d.setdefault("refinements", [])
                self._data = d
        except Exception:
            self._data = _empty()
        self._mtime = m

    def save(self) -> None:
        _atomic_write(self.path, self._data)
        try:
            self._mtime = self.path.stat().st_mtime_ns
        except OSError:
            pass

    # ------------------------------------------------------------------ CRUD
    def list(self, kind: str | None = None) -> list[dict]:
        self._sync()
        out = []
        for k in ([kind] if kind else KINDS):
            out.extend(self._data["entries"].get(k, {}).values())
        return sorted(out, key=lambda e: (e.get("kind", ""), e.get("id", "")))

    def get(self, eid: str, kind: str | None = None) -> dict | None:
        self._sync()
        for k in ([kind] if kind else KINDS):
            e = self._data["entries"].get(k, {}).get(eid)
            if e:
                return e
        return None

    def upsert(self, kind: str, title: str, content: str, *, id: str | None = None,
               path: str = "general", reference: dict | None = None,
               arguments: dict | None = None, metadata: dict | None = None,
               source: str = "agent", mode: Literal["upsert", "create", "update"] = "upsert",
               scope: str = "local") -> dict:
        if kind not in KINDS:
            raise ValueError(f"지원하지 않는 kind: {kind} (가능: {list(KINDS)})")
        eid = id or _slug(title, kind)
        if kind == "prompt" and eid == BASE_PROMPT_ID:
            raise ValueError("기본 시스템 프롬프트는 수정할 수 없다 (base system prompt is not editable)")
        if kind == "skill":
            _validate_skill_reference(reference, arguments)

        self._sync()
        bucket = self._data["entries"].setdefault(kind, {})
        exists = eid in bucket
        if mode == "create" and exists:
            raise ValueError(f"{kind} 엔트리 {eid!r} 가 이미 있다")
        if mode == "update" and not exists:
            raise ValueError(f"{kind} 엔트리 {eid!r} 를 찾지 못했다")

        prev = bucket.get(eid) or {}
        entry = {
            "id": eid, "kind": kind, "title": title, "content": content,
            # 생략된 값은 보존, 명시된 값({} 포함)은 덮어쓴다 — 원본과 동일
            "path": path if path is not None else prev.get("path", "general"),
            "scope": scope,
            "reference": reference if reference is not None else prev.get("reference", {}),
            "arguments": arguments if arguments is not None else prev.get("arguments", {}),
            "metadata": metadata if metadata is not None else prev.get("metadata", {}),
            "source": source,
            "created_at": prev.get("created_at") or _now(),
            "updated_at": _now(),
            "version": int(prev.get("version", 0)) + 1,
        }
        bucket[eid] = entry
        self.save()
        return entry

    def delete(self, eid: str, kind: str | None = None) -> dict:
        self._sync()
        for k in ([kind] if kind else KINDS):
            bucket = self._data["entries"].get(k, {})
            if eid in bucket:
                removed = bucket.pop(eid)
                self.save()
                return removed
        raise ValueError(f"엔트리 {eid!r} 를 찾지 못했다")

    def record_refinement(self, trigger: str, changes: list[str],
                          evidence: str = "", outcome: str = "") -> dict:
        self._sync()
        ev = {
            "id": f"refine_{len(self._data['refinements']) + 1:04d}",
            "trigger": trigger, "changes": changes,
            "evidence": evidence, "outcome": outcome, "created_at": _now(),
        }
        self._data["refinements"].append(ev)
        self.save()
        return ev

    def refinements(self) -> list[dict]:
        self._sync()
        return list(self._data.get("refinements") or [])

    # ------------------------------------------------------------------ 렌더링
    def overview(self, prefix: str) -> str:
        self._sync()
        lines = []
        for k in KINDS:
            items = self._data["entries"].get(k, {})
            if not items:
                continue
            lines.append(f"[{k}]")
            for e in items.values():
                head = (e.get("content") or "").strip().splitlines()
                head = head[0][:110] if head else ""
                lines.append(f"  [{prefix}:{e['id']}] {e.get('title','')} — {head}")
        return "\n".join(lines)


def _validate_skill_reference(reference: dict | None, arguments: dict | None) -> None:
    if arguments is None:
        raise ValueError("skill 엔트리는 arguments 객체가 필요하다 (인자가 없으면 {} 를 명시)")
    if not isinstance(reference, dict):
        raise ValueError("skill 엔트리는 reference 객체가 필요하다")
    if reference.get("type") != "python":
        raise ValueError('skill reference 의 type 은 "python" 이어야 한다')
    if not (reference.get("import") or reference.get("python_import")):
        raise ValueError("skill reference 에 import 가 필요하다")
    if not (reference.get("callable") or reference.get("call_pattern")):
        raise ValueError("skill reference 에 callable 또는 call_pattern 이 필요하다")


class Harness:
    """로컬 + 전역 두 스토어를 묶어서 다룬다."""

    def __init__(self, session_artifact_dir: Path | None):
        gdir = config.agent_dir() / "harness"
        self.global_store = HarnessStore(gdir / STATE_FILE)
        self.history_path = gdir / HISTORY_FILE
        self.local_store: HarnessStore | None = (
            HarnessStore(Path(session_artifact_dir) / "harness" / STATE_FILE)
            if session_artifact_dir else None
        )

    def store(self, global_: bool) -> HarnessStore:
        if global_:
            return self.global_store
        if self.local_store is None:
            raise RuntimeError(
                "로컬 하네스 상태를 쓰려면 영속 세션이 필요하다. "
                "전역으로 쓰려면 global_=True 를 넘겨라."
            )
        return self.local_store

    def overview(self, global_only: bool = False) -> str:
        parts = []
        if self.local_store and not global_only:
            t = self.local_store.overview("local")
            if t:
                parts.append(t)
        t = self.global_store.overview("global")
        if t:
            parts.append(t)
        return "\n".join(parts) or "(하네스 비어 있음)"

    def resolve(self, eid: str) -> tuple[HarnessStore, str]:
        """'global:foo' / 'local:foo' 접두어를 해석한다."""
        if eid.startswith("global:"):
            return self.global_store, eid[7:]
        if eid.startswith("local:"):
            return self.store(False), eid[6:]
        return (self.local_store or self.global_store), eid

    # ------------------------------------------------------------------ 시스템 프롬프트 주입
    def prompt_block(self) -> str:
        """하네스 상태를 시스템 프롬프트에 붙일 텍스트로 만든다.

        기본 프롬프트를 대체하지 않고 **보충**한다.
        """
        chunks: list[str] = []
        for store, label in ((self.global_store, "global"),
                             (self.local_store, "local")):
            if store is None:
                continue
            notes = store.list("prompt")
            mems = store.list("memory")
            subs = store.list("subagent")
            skills = store.list("skill")
            if not (notes or mems or subs or skills):
                continue
            block = [f"<continual_harness scope=\"{label}\">"]
            for e in notes:
                block.append(f"  <prompt_note id=\"{e['id']}\" title=\"{e['title']}\">"
                             f"{e['content']}</prompt_note>")
            for e in mems:
                block.append(f"  <memory id=\"{e['id']}\" title=\"{e['title']}\">"
                             f"{e['content']}</memory>")
            for e in subs:
                block.append(f"  <subagent_spec id=\"{e['id']}\" title=\"{e['title']}\">"
                             f"{e['content']}</subagent_spec>")
            for e in skills:
                ref = e.get("reference") or {}
                call = ref.get("call_pattern") or ref.get("callable") or ""
                block.append(f"  <skill id=\"{e['id']}\" title=\"{e['title']}\" "
                             f"import=\"{ref.get('import','')}\" call=\"{call}\">"
                             f"{e['content']}</skill>")
            block.append("</continual_harness>")
            chunks.append("\n".join(block))
        return "\n\n".join(chunks)

    # ------------------------------------------------------------------ refine 이력
    def append_history(self, record: dict) -> None:
        self.history_path.parent.mkdir(parents=True, exist_ok=True)
        with self.history_path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")

    def history(self, limit: int = 20) -> list[dict]:
        out: list[dict] = []
        if not self.history_path.exists():
            return out
        for line in self.history_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                out.append(json.loads(line))   # 깨진 줄 하나가 롤백 전체를 막지 않게
            except json.JSONDecodeError:
                continue
        return out[-limit:]


# --------------------------------------------------------------------------- refine

REFINE_SYSTEM = """\
너는 Prime Agent 의 continual harness 정제기다.

지금까지의 궤적(trajectory)을 읽고, **증거로 뒷받침되는 작은 편집**만 제안한다.

규칙:
- 기본 시스템 프롬프트는 불변이다. 절대 재작성하지 않는다. id 가 base_system_prompt 인 prompt 편집은 금지.
- 소스 파일을 직접 고치지 않는다. 하네스 엔트리만 만든다.
- 요청된 스코프의 스토어에만 쓴다. 로컬 정제 중 전역 엔트리는 읽기 전용이다.
- kind 는 prompt(보충 프롬프트 노트) / memory(지속 사실·결정·실패·선호) /
  skill(재사용 가능한 Python 호출의 기술) / subagent(재사용 위임 스펙) 중 하나.
- skill 편집에는 reference {"type":"python","import":...,"callable" 또는 "call_pattern":...} 와
  arguments 객체가 반드시 있어야 한다.
- 편집이 필요 없으면 edits 를 빈 배열로 둔다. 억지로 만들지 않는다.

정제할 만한 상황: 반복된 실패, 재사용 가능한 전술이 드러났을 때, 반복되는 위임 역할,
반복 절차, 지속적 사실·선호, 좁은 행동 정책, 사용자가 행동을 교정했을 때,
검증 결과 기존 엔트리가 틀렸을 때.

**JSON 객체 하나만** 출력한다. 다른 텍스트는 쓰지 않는다:
{"summary":"한 문장","rationale":"궤적 증거","expectedOutcome":"무엇이 개선되는가",
 "edits":[{"action":"create|update|delete","kind":"prompt|memory|skill|subagent",
           "id":"...","title":"...","content":"...","path":"general",
           "reference":{},"arguments":{},"reason":"..."}]}
"""


def build_refine_prompt(harness: "Harness", transcript: str, scope: str,
                        instructions: str | None) -> list[dict]:
    hist = harness.history(20)
    parts = [
        "<current_harness_state>", harness.overview(), "</current_harness_state>", "",
        "<refinement_history>",
        "\n".join(json.dumps(h, ensure_ascii=False) for h in hist) or "(없음)",
        "</refinement_history>", "",
        "<scope_policy>",
        f"이번 정제의 스코프는 {scope} 다.",
        "로컬이 기본이다: 세션 진행, 일시적 블로커, 현재 실행 조율.",
        "전역은 세션을 넘는 안정적 교훈, 지속적 사용자 선호, 재사용 스킬·서브에이전트,",
        "그리고 제목/경로/내용이 프로젝트를 명시적으로 지목한 사실에만 쓴다.",
        "</scope_policy>", "",
        "<conversation>", transcript[-80000:], "</conversation>",
    ]
    if instructions:
        parts += ["", "<user_refine_instructions>", instructions, "</user_refine_instructions>"]
    return [{"role": "user", "content": "\n".join(parts)}]


def apply_proposal(harness: "Harness", proposal: dict, scope: str) -> dict:
    """제안을 적용하고 before/after 스냅샷을 남긴다."""
    global_ = scope == "global"
    store = harness.store(global_)
    applied: list[dict] = []

    for edit in proposal.get("edits") or []:
        action = edit.get("action")
        kind = edit.get("kind")
        eid = edit.get("id")
        rec: dict[str, Any] = {"action": action, "kind": kind, "id": eid,
                               "reason": edit.get("reason"), "applied": False}
        try:
            if action not in ("create", "update", "delete"):
                raise ValueError(f"지원하지 않는 action: {action}")
            if kind not in KINDS:
                raise ValueError(f"지원하지 않는 kind: {kind}")
            if action in ("update", "delete") and not eid:
                raise ValueError("update/delete 에는 id 가 필요하다")
            if action != "delete" and not (edit.get("title") and edit.get("content")):
                raise ValueError("create/update 에는 title 과 content 가 모두 필요하다")

            before = store.get(eid, kind) if eid else None
            rec["before"] = before

            if action == "delete":
                store.delete(eid, kind)
                rec["after"] = None
            else:
                after = store.upsert(
                    kind, edit["title"], edit["content"], id=eid,
                    path=edit.get("path", "general"),
                    reference=edit.get("reference"), arguments=edit.get("arguments"),
                    metadata=edit.get("metadata"), source="refine",
                    mode=action, scope=scope,
                )
                rec["after"] = after
                rec["id"] = after["id"]
            rec["applied"] = True
        except Exception as e:
            rec["error"] = f"{type(e).__name__}: {e}"
        applied.append(rec)

    record = {
        "id": f"refine_{secrets.token_hex(6)}",
        "scope": scope,
        "summary": proposal.get("summary", ""),
        "rationale": proposal.get("rationale", ""),
        "expectedOutcome": proposal.get("expectedOutcome", ""),
        "edits": applied,
        "created_at": _now(),
        "harnessStatePath": str(store.path),
    }
    if global_:
        harness.append_history(record)
    store.record_refinement(
        trigger=proposal.get("summary", "refine"),
        changes=[f"{r['action']} {r['kind']}:{r.get('id')}" for r in applied if r["applied"]],
        evidence=proposal.get("rationale", ""),
        outcome=proposal.get("expectedOutcome", ""),
    )
    return record


def rollback(harness: "Harness", record: dict) -> dict:
    """적용된 편집을 **역순으로** 되돌린다."""
    store = harness.store(record.get("scope") == "global")
    undone: list[dict] = []
    for r in reversed(record.get("edits") or []):
        if not r.get("applied"):
            continue
        before, after = r.get("before"), r.get("after")
        try:
            if before is None and after is not None:
                store.delete(after["id"], after["kind"])
                undone.append({"undo": "delete", "id": after["id"]})
            elif before is not None:
                store.upsert(before["kind"], before["title"], before["content"],
                             id=before["id"], path=before.get("path", "general"),
                             reference=before.get("reference"),
                             arguments=before.get("arguments"),
                             metadata=before.get("metadata"),
                             source="refine", mode="upsert",
                             scope=before.get("scope", "local"))
                undone.append({"undo": "restore", "id": before["id"]})
        except Exception as e:
            undone.append({"undo": "error", "id": r.get("id"), "error": str(e)})
    out = {"rollbackOf": record.get("id"), "undone": undone, "created_at": _now(),
           "scope": record.get("scope")}
    if record.get("scope") == "global":
        harness.append_history(out)
    return out
