"""Prime Agent (Python 이식본).

PrimeIntellect-ai/prime-agent v0.8.0 의 RLM 하네스를 순수 Python 으로 옮긴 것.
Node.js·npm·bash 가 필요 없고, Windows 폐쇄망에서 pip 만으로 돈다.

원본에서 그대로 가져온 것:
  - 모델에게 노출되는 툴은 `ipython` 하나뿐 (프로그래매틱 실행)
  - `rlm(...)` 재귀 서브에이전트 — admission 시점 반환, 결과는 agent_message 로
  - Continual Harness — prompt/memory/skill/subagent 4종, /refine + 스냅샷 롤백
  - 세션 JSONL 트리 (version 3 포맷 호환)
  - 컴팩션 (contextWindow - reserveTokens 트리거, keepRecentTokens 보존)
  - goal / heartbeat / autonomous(게이트 우선 판정)
  - SKILL.md 스킬 계약 — 저장소 스킬을 수정 없이 그대로 로드

원본과 다른 것:
  - 데몬/슈퍼바이저/워커 3프로세스 대신 단일 프로세스 + 스레드
  - Jupyter comm 대신 loopback TCP 호스트 브리지 (Windows 친화)
  - 프로바이더는 OpenAI 호환 하나로 좁힘 (사내 vLLM/SGLang 대상)
"""

__version__ = "0.1.0"
