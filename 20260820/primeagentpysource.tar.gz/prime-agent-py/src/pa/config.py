"""경로 · 설정 · 모델 레지스트리.

원본(TypeScript)의 `~/.prime/agent` 레이아웃을 그대로 따르되, 이 포팅본은 충돌을 피해
`~/.prime/agent-py` 를 기본으로 쓴다. 환경변수로 원본 경로를 그대로 가리킬 수도 있다.

Windows 대응:
  - 홈은 `Path.home()` (보통 C:\\Users\\<id>)
  - 경로 구분자는 pathlib 이 처리
  - 소켓 대신 loopback TCP 를 쓰므로 named pipe 이슈가 없다
"""

from __future__ import annotations

import json
import os
import platform
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

APP = "prime-agent-py"
ENV_DIR = "PA_AGENT_DIR"
ENV_OFFLINE = "PA_OFFLINE"
ENV_KERNEL_PYTHON = "PA_KERNEL_PYTHON"


def is_windows() -> bool:
    return os.name == "nt" or platform.system() == "Windows"


def agent_dir() -> Path:
    raw = os.environ.get(ENV_DIR)
    if raw:
        return Path(raw).expanduser()
    return Path.home() / ".prime" / "agent-py"


def sessions_dir() -> Path:
    return agent_dir() / "sessions"


def artifacts_dir() -> Path:
    return agent_dir() / "session-artifacts"


def logs_dir() -> Path:
    return agent_dir() / "logs"


def ensure_dirs() -> None:
    for d in (agent_dir(), sessions_dir(), artifacts_dir(), logs_dir(),
              agent_dir() / "skills", agent_dir() / "harness"):
        d.mkdir(parents=True, exist_ok=True)


def offline() -> bool:
    return os.environ.get(ENV_OFFLINE, "").lower() in ("1", "true", "yes")


# --------------------------------------------------------------------------- settings

DEFAULT_SETTINGS: dict[str, Any] = {
    "defaultProvider": None,
    "defaultModel": None,
    "compaction": {"enabled": True, "reserveTokens": 16384, "keepRecentTokens": 20000},
    "autonomous": {
        "maxContinuations": 3,
        "maxTurns": 12,
        "maxTokens": 80000,
        "timeoutMs": 1800000,
        "gateRetries": 3,
        "gateTimeoutMs": 300000,
    },
    "rlm": {"maxDepth": 2},
    "skills": [],
    "enableSkillCommands": True,
    "theme": "dark",
    "quietStartup": False,
}


def _deep_merge(base: dict, over: dict) -> dict:
    out = dict(base)
    for k, v in over.items():
        if k.startswith("_"):
            continue
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _read_json(path: Path) -> dict:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {}


def load_settings(cwd: Path | None = None) -> dict[str, Any]:
    """전역 설정에 프로젝트 설정을 덮어쓴다(중첩 객체는 병합)."""
    s = _deep_merge(DEFAULT_SETTINGS, _read_json(agent_dir() / "settings.json"))
    if cwd:
        s = _deep_merge(s, _read_json(Path(cwd) / ".prime" / "agent-py" / "settings.json"))
    return s


# --------------------------------------------------------------------------- models

@dataclass
class Model:
    provider: str
    id: str
    name: str
    base_url: str
    api_key: str | None = None
    api: str = "openai-completions"
    context_window: int = 131072
    max_tokens: int = 16384
    reasoning: bool = False
    input: list[str] = field(default_factory=lambda: ["text"])
    headers: dict[str, str] = field(default_factory=dict)
    auth_header: bool = True
    compat: dict[str, Any] = field(default_factory=dict)

    @property
    def selector(self) -> str:
        return f"{self.provider}/{self.id}"


def _resolve_value(raw: str | None) -> str | None:
    """원본과 같은 3형태 해석: '!cmd' → 셸 stdout, 환경변수명 → 그 값, 그 외 → 리터럴."""
    if raw is None:
        return None
    if raw.startswith("!"):
        import subprocess
        try:
            out = subprocess.run(raw[1:], shell=True, capture_output=True, text=True, timeout=30)
            return out.stdout.strip()
        except Exception:
            return None
    env = os.environ.get(raw)
    return env if env is not None else raw


def load_models() -> list[Model]:
    """`models.json` 을 읽어 모델 목록을 만든다.

    스키마는 원본 `~/.prime/agent/models.json` 과 호환된다:
        {"providers": {"<name>": {"baseUrl","apiKey","api","headers","compat","models":[...]}}}
    """
    doc = _read_json(agent_dir() / "models.json")
    out: list[Model] = []
    for pname, pcfg in (doc.get("providers") or {}).items():
        if pname.startswith("_") or not isinstance(pcfg, dict):
            continue
        base = pcfg.get("baseUrl")
        pkey = _resolve_value(pcfg.get("apiKey"))
        papi = pcfg.get("api", "openai-completions")
        pheaders = {k: _resolve_value(v) or "" for k, v in (pcfg.get("headers") or {}).items()
                    if not k.startswith("_")}
        pcompat = {k: v for k, v in (pcfg.get("compat") or {}).items() if not k.startswith("_")}
        for m in pcfg.get("models") or []:
            if not isinstance(m, dict) or not m.get("id"):
                continue
            mcompat = dict(pcompat)
            mcompat.update({k: v for k, v in (m.get("compat") or {}).items()
                            if not k.startswith("_")})
            out.append(Model(
                provider=pname,
                id=m["id"],
                name=m.get("name") or m["id"],
                base_url=(m.get("baseUrl") or base or "").rstrip("/"),
                api_key=_resolve_value(m.get("apiKey")) or pkey,
                api=m.get("api") or papi,
                context_window=int(m.get("contextWindow", 131072)),
                max_tokens=int(m.get("maxTokens", 16384)),
                reasoning=bool(m.get("reasoning", False)),
                input=list(m.get("input") or ["text"]),
                headers={**pheaders, **{k: _resolve_value(v) or ""
                                        for k, v in (m.get("headers") or {}).items()
                                        if not k.startswith("_")}},
                auth_header=bool(pcfg.get("authHeader", True)),
                compat=mcompat,
            ))
    return out


def find_model(models: list[Model], pattern: str | None,
               provider: str | None = None) -> Model | None:
    """`provider/id`, 부분 문자열, glob 비슷한 매칭을 지원한다."""
    if not models:
        return None
    if not pattern:
        cands = [m for m in models if not provider or m.provider == provider]
        return cands[0] if cands else None
    pat = pattern.lower()
    if "/" in pattern:
        p, _, i = pattern.partition("/")
        for m in models:
            if m.provider.lower() == p.lower() and m.id.lower() == i.lower():
                return m
    for m in models:
        if provider and m.provider != provider:
            continue
        if m.id.lower() == pat or m.name.lower() == pat:
            return m
    for m in models:
        if provider and m.provider != provider:
            continue
        if pat in m.id.lower() or pat in m.name.lower():
            return m
    return None


def kernel_python() -> str:
    """커널로 쓸 Python 인터프리터. 폐쇄망에서는 사전 구축한 venv 를 가리키게 한다."""
    import sys
    return os.environ.get(ENV_KERNEL_PYTHON) or sys.executable
