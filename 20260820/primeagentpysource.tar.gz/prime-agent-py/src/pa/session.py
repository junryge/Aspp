"""세션 = JSONL 트리.

원본 `docs/session-format.md` 의 version 3 포맷을 그대로 따른다.
같은 파일을 원본 CLI 로도 열 수 있도록 엔트리 타입과 필드 이름을 맞췄다.

  {"type":"session","version":3,"id":"uuid","timestamp":"...","cwd":"..."}   ← 헤더
  {"type":"message","id":"a1b2c3d4","parentId":"prev1234","timestamp":"...","message":{...}}
  {"type":"model_change",...}  {"type":"compaction",...}  {"type":"custom",...}  ...

트리 규칙:
  - 첫 엔트리의 parentId 는 null
  - 현재 위치 = 활성 leaf
  - 브랜치는 이전 엔트리에서 새 자식을 만드는 것
"""

from __future__ import annotations

import json
import os
import secrets
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from . import config

SESSION_VERSION = 3


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def new_entry_id() -> str:
    return secrets.token_hex(4)  # 8자리 hex — 원본과 동일


@dataclass
class Usage:
    input: int = 0
    output: int = 0
    cache_read: int = 0
    cache_write: int = 0

    @property
    def total(self) -> int:
        return self.input + self.output + self.cache_read + self.cache_write

    def add(self, other: "Usage") -> None:
        self.input += other.input
        self.output += other.output
        self.cache_read += other.cache_read
        self.cache_write += other.cache_write

    def to_json(self) -> dict:
        return {
            "input": self.input, "output": self.output,
            "cacheRead": self.cache_read, "cacheWrite": self.cache_write,
            "totalTokens": self.total,
        }

    @staticmethod
    def from_json(d: dict | None) -> "Usage":
        d = d or {}
        return Usage(
            input=int(d.get("input", 0)), output=int(d.get("output", 0)),
            cache_read=int(d.get("cacheRead", 0)), cache_write=int(d.get("cacheWrite", 0)),
        )


class SessionManager:
    """단일 JSONL 파일에 대한 append-only 트리 저장소."""

    def __init__(self, path: Path | None, cwd: Path, header: dict | None = None):
        self.path = path
        self.cwd = Path(cwd)
        self.entries: list[dict] = []
        self.leaf_id: str | None = None
        self.header: dict = header or {}
        self._name: str | None = None

    # ------------------------------------------------------------------ 생성/열기
    @classmethod
    def create(cls, cwd: Path, session_dir: Path | None = None,
               persist: bool = True, parent_session: str | None = None) -> "SessionManager":
        sid = str(uuid.uuid4())
        path = None
        if persist:
            d = Path(session_dir) if session_dir else config.sessions_dir()
            d.mkdir(parents=True, exist_ok=True)
            path = d / f"{sid}.jsonl"
        header = {"type": "session", "version": SESSION_VERSION, "id": sid,
                  "timestamp": now_iso(), "cwd": str(cwd)}
        if parent_session:
            header["parentSession"] = str(parent_session)
        sm = cls(path, cwd, header)
        if path:
            sm._write_line(header)
        return sm

    @classmethod
    def open(cls, path: Path) -> "SessionManager":
        path = Path(path)
        lines = [l for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
        if not lines:
            raise ValueError(f"빈 세션 파일: {path}")
        header = json.loads(lines[0])
        sm = cls(path, Path(header.get("cwd", ".")), header)
        for raw in lines[1:]:
            try:
                e = json.loads(raw)
            except json.JSONDecodeError:
                continue  # 손상된 줄은 건너뛴다 — 하나가 세션 전체를 막지 않게
            sm.entries.append(e)
            if e.get("type") == "session_info":
                sm._name = e.get("name")
        sm.leaf_id = sm.entries[-1]["id"] if sm.entries else None
        return sm

    @classmethod
    def list_sessions(cls, session_dir: Path | None = None) -> list[dict]:
        d = Path(session_dir) if session_dir else config.sessions_dir()
        out = []
        if not d.exists():
            return out
        for f in sorted(d.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                with f.open(encoding="utf-8") as fh:
                    head = json.loads(fh.readline())
                name, count, first = None, 0, None
                for raw in fh:
                    if not raw.strip():
                        continue
                    count += 1
                    try:
                        e = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    if e.get("type") == "session_info":
                        name = e.get("name")
                    if first is None and e.get("type") == "message" \
                            and (e.get("message") or {}).get("role") == "user":
                        c = (e["message"].get("content") or "")
                        first = c if isinstance(c, str) else ""
                out.append({
                    "path": f, "id": head.get("id"), "cwd": head.get("cwd"),
                    "timestamp": head.get("timestamp"), "name": name,
                    "entries": count, "preview": (first or "").strip()[:70],
                    "mtime": f.stat().st_mtime,
                })
            except Exception:
                continue
        return out

    # ------------------------------------------------------------------ 기록
    def _write_line(self, obj: dict) -> None:
        if not self.path:
            return
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(obj, ensure_ascii=False) + "\n")
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass

    def _append(self, entry: dict) -> str:
        entry.setdefault("id", new_entry_id())
        entry.setdefault("parentId", self.leaf_id)
        entry.setdefault("timestamp", now_iso())
        self.entries.append(entry)
        self.leaf_id = entry["id"]
        self._write_line(entry)
        return entry["id"]

    def append_message(self, message: dict) -> str:
        return self._append({"type": "message", "message": message})

    def append_model_change(self, provider: str, model_id: str) -> str:
        return self._append({"type": "model_change", "provider": provider, "modelId": model_id})

    def append_compaction(self, summary: str, first_kept_entry_id: str,
                          tokens_before: int, details: dict | None = None,
                          custom_instructions: str | None = None) -> str:
        e = {"type": "compaction", "summary": summary,
             "firstKeptEntryId": first_kept_entry_id, "tokensBefore": tokens_before}
        if details:
            e["details"] = details
        if custom_instructions:
            e["customInstructions"] = custom_instructions
        return self._append(e)

    def append_branch_summary(self, summary: str, from_id: str) -> str:
        return self._append({"type": "branch_summary", "summary": summary, "fromId": from_id})

    def append_custom(self, custom_type: str, data: dict | None = None) -> str:
        return self._append({"type": "custom", "customType": custom_type, "data": data or {}})

    def append_custom_message(self, custom_type: str, content: str, display: bool = True) -> str:
        return self._append({"type": "custom_message", "customType": custom_type,
                             "content": content, "display": display})

    def append_session_info(self, name: str) -> str:
        self._name = name
        return self._append({"type": "session_info", "name": name})

    def append_label(self, target_id: str, label: str | None) -> str:
        return self._append({"type": "label", "targetId": target_id, "label": label})

    def append_child_usage(self, target_id: str, child: Usage, aggregate: Usage) -> str:
        return self._append({"type": "child_usage_attributed", "targetId": target_id,
                             "childUsage": child.to_json(),
                             "aggregateUsage": aggregate.to_json()})

    # ------------------------------------------------------------------ 조회
    @property
    def session_id(self) -> str:
        return self.header.get("id", "in-memory")

    @property
    def name(self) -> str | None:
        return self._name

    def get_entry(self, eid: str) -> dict | None:
        for e in self.entries:
            if e.get("id") == eid:
                return e
        return None

    def branch(self, from_id: str | None = None) -> list[dict]:
        """leaf(또는 지정 엔트리)에서 root 까지의 경로를 시간순으로 반환."""
        by_id = {e["id"]: e for e in self.entries if "id" in e}
        cur = from_id or self.leaf_id
        chain: list[dict] = []
        seen: set[str] = set()
        while cur and cur in by_id and cur not in seen:
            seen.add(cur)
            e = by_id[cur]
            chain.append(e)
            cur = e.get("parentId")
        chain.reverse()
        return chain

    def children_of(self, parent_id: str | None) -> list[dict]:
        return [e for e in self.entries if e.get("parentId") == parent_id]

    def set_leaf(self, eid: str | None) -> None:
        self.leaf_id = eid

    def labels(self) -> dict[str, str]:
        out: dict[str, str] = {}
        for e in self.entries:
            if e.get("type") == "label":
                if e.get("label"):
                    out[e["targetId"]] = e["label"]
                else:
                    out.pop(e.get("targetId"), None)
        return out

    # ------------------------------------------------------------------ 컨텍스트 구성
    def build_context(self) -> list[dict]:
        """현재 leaf 기준으로 모델에 보낼 메시지 리스트를 만든다.

        원본 `buildSessionContext()` 규칙:
          - 경로에 compaction 이 있으면 요약을 먼저 넣고,
            firstKeptEntryId 부터의 메시지를 잇는다
          - branch_summary / custom_message 는 메시지로 변환
          - 부기(child_usage_attributed, label, session_info 등)는 제외
        """
        chain = self.branch()
        # 마지막 compaction 을 찾는다
        cut_idx = -1
        for i, e in enumerate(chain):
            if e.get("type") == "compaction":
                cut_idx = i
        msgs: list[dict] = []

        if cut_idx >= 0:
            comp = chain[cut_idx]
            msgs.append({"role": "system",
                         "content": "[이전 대화 요약]\n" + (comp.get("summary") or "")})
            first_kept = comp.get("firstKeptEntryId")
            keep_from = 0
            for i, e in enumerate(chain[:cut_idx]):
                if e.get("id") == first_kept:
                    keep_from = i
                    break
            segment: Iterable[dict] = list(chain[keep_from:cut_idx]) + list(chain[cut_idx + 1:])
        else:
            segment = chain

        for e in segment:
            t = e.get("type")
            if t == "message":
                m = e.get("message") or {}
                if m.get("role") in ("user", "assistant", "toolResult", "bashExecution"):
                    msgs.append(m)
            elif t == "branch_summary":
                msgs.append({"role": "system",
                             "content": "[다른 분기 요약]\n" + (e.get("summary") or "")})
            elif t == "custom_message":
                msgs.append({"role": "user", "content": str(e.get("content") or "")})
        return msgs

    def total_usage(self) -> Usage:
        u = Usage()
        for e in self.entries:
            if e.get("type") == "message":
                m = e.get("message") or {}
                if m.get("role") == "assistant" and m.get("usage"):
                    u.add(Usage.from_json(m["usage"]))
            elif e.get("type") == "child_usage_attributed":
                u.add(Usage.from_json(e.get("childUsage")))
        return u

    # ------------------------------------------------------------------ 아티팩트
    def artifact_dir(self) -> Path:
        d = config.artifacts_dir() / self.session_id
        d.mkdir(parents=True, exist_ok=True)
        return d
