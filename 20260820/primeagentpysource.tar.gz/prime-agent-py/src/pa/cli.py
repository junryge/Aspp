"""CLI — 대화형 REPL, 슬래시 커맨드, print/json 모드, autonomous.

    pa                              대화형
    pa -p "..."                     한 번 실행하고 종료
    pa --mode json "..."            이벤트를 JSON 라인으로
    pa doctor                       환경 점검
    pa models                       등록된 모델 목록 + 연결 확인
    pa sessions                     저장된 세션 목록
    pa -r [id|path]                 세션 재개
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import time
from pathlib import Path

from . import config, provider as prov, skills as skills_mod
from .agent import AgentSession, Heartbeat, parse_interval
from .session import SessionManager

# --------------------------------------------------------------------------- 출력
_ANSI = sys.stdout.isatty() and not os.environ.get("NO_COLOR")


def c(code: str, s: str) -> str:
    return f"\033[{code}m{s}\033[0m" if _ANSI else s


DIM, BOLD, CYAN, GREEN, YELLOW, RED, MAG = "2", "1", "36", "32", "33", "31", "35"


class Printer:
    """스트리밍 이벤트를 사람이 읽는 형태로 찍는다."""

    def __init__(self, quiet: bool = False, json_mode: bool = False):
        self.quiet = quiet
        self.json_mode = json_mode
        self._open: str | None = None
        self._lock = threading.Lock()

    def __call__(self, kind: str, data: dict) -> None:
        if self.json_mode:
            print(json.dumps({"type": kind, **data}, ensure_ascii=False), flush=True)
            return
        with self._lock:
            self._render(kind, data)

    def _close(self) -> None:
        if self._open:
            print()
            self._open = None

    def _render(self, kind: str, data: dict) -> None:
        name = data.get("name")
        tag = f"{c(MAG, '['+name+']')} " if name and name != "root" else ""

        if kind == "delta":
            k = data.get("kind")
            if k == "thinking":
                if self.quiet:
                    return
                if self._open != "thinking":
                    self._close()
                    print(c(DIM, "생각 "), end="")
                    self._open = "thinking"
                print(c(DIM, data["text"]), end="", flush=True)
            elif k == "text":
                if self._open != "text":
                    self._close()
                    if tag:
                        print(tag, end="")
                    self._open = "text"
                print(data["text"], end="", flush=True)
        elif kind == "tool_call":
            self._close()
            code = data.get("code") or ""
            print(c(CYAN, f"{tag}⟩ ipython"))
            for line in code.rstrip().splitlines()[:40]:
                print(c(DIM, "  " + line))
            if len(code.splitlines()) > 40:
                print(c(DIM, f"  ... ({len(code.splitlines())-40}줄 더)"))
        elif kind == "tool_result":
            self._close()
            txt = (data.get("text") or "").rstrip()
            color = RED if data.get("error") else GREEN
            head = txt.splitlines()[:25]
            print(c(color, "  ⟨ "), end="")
            print(c(DIM, ("\n    ".join(head)) or "(출력 없음)"))
            if len(txt.splitlines()) > 25:
                print(c(DIM, f"    ... ({len(txt.splitlines())-25}줄 더)"))
        elif kind == "child_start":
            self._close()
            print(c(MAG, f"  ↳ 서브에이전트 시작: {data['name']} ({data['model']})"))
        elif kind == "child_end":
            self._close()
            print(c(MAG, f"  ↳ 서브에이전트 종료: {data['name']} — {data['status']}"))
        elif kind == "message":
            self._close()
            print(c(MAG, f"  ✉ {data['from']} → {data['to']}: {data['text']}"))
        elif kind == "compaction":
            self._close()
            print(c(YELLOW, f"  [컴팩션 — 이전 {data.get('tokensBefore')} 토큰 요약]"))
        elif kind == "refine":
            self._close()
            if data.get("rollback"):
                print(c(YELLOW, f"  [하네스 롤백: {data['rollback']}]"))
            else:
                print(c(YELLOW, f"  [하네스 정제: {data.get('summary')} "
                                f"— 편집 {data.get('edits')}건]"))
        elif kind == "goal":
            self._close()
            print(c(YELLOW, f"  [goal {data['action']}] {data.get('objective','')}"))
        elif kind == "error":
            self._close()
            print(c(RED, f"  ✗ {data.get('text')}"))

    def flush(self) -> None:
        with self._lock:
            self._close()


# --------------------------------------------------------------------------- 구성
def build_session(args, printer: Printer) -> AgentSession:
    config.ensure_dirs()
    cwd = Path(args.cwd or os.getcwd()).resolve()
    settings = config.load_settings(cwd)

    models = config.load_models()
    if not models:
        print(c(RED, "등록된 모델이 없다."))
        print(f"  {config.agent_dir() / 'models.json'} 을 만들어라. "
              f"`pa init --llm-base-url ... --llm-model ...` 로 생성할 수 있다.")
        raise SystemExit(2)

    model = config.find_model(models, args.model or settings.get("defaultModel"),
                              args.provider or settings.get("defaultProvider"))
    if model is None:
        print(c(RED, f"모델을 찾지 못했다: {args.model or settings.get('defaultModel')}"))
        print("  사용 가능:", ", ".join(m.selector for m in models))
        raise SystemExit(2)
    if args.api_key:
        model.api_key = args.api_key

    explicit = [Path(p) for p in (args.skill or [])]
    sk, notes = skills_mod.discover(cwd, settings, explicit,
                                    enable_builtin=not args.no_skills)
    if args.no_skills:
        sk = [s for s in sk if s.source == "explicit"]
    if notes and not args.quiet:
        for n in notes:
            print(c(YELLOW, f"  ! {n}"))

    if args.resume:
        p = Path(args.resume)
        if not p.exists():
            cands = [s for s in SessionManager.list_sessions()
                     if str(s["id"]).startswith(args.resume)]
            if not cands:
                print(c(RED, f"세션을 찾지 못했다: {args.resume}"))
                raise SystemExit(2)
            p = cands[0]["path"]
        sm = SessionManager.open(p)
    elif args.cont:
        lst = SessionManager.list_sessions()
        if not lst:
            print(c(RED, "이어갈 세션이 없다"))
            raise SystemExit(2)
        sm = SessionManager.open(lst[0]["path"])
    else:
        sm = SessionManager.create(cwd, persist=not args.no_session)

    sess = AgentSession(model=model, sm=sm, cwd=cwd, settings=settings, skills=sk,
                        thinking=args.thinking, emit=printer)

    if args.goal:
        from .agent import Goal
        sess.goal = Goal(objective=args.goal, token_budget=args.goal_token_budget)

    if not args.quiet and not args.json_mode:
        print(c(BOLD, "Prime Agent (Python)") + c(DIM, f"  {model.selector}"))
        print(c(DIM, f"  세션 {sm.session_id[:8]} · 스킬 {len(sk)}개 · "
                     f"커널 {config.kernel_python()}"))
        print(c(DIM, f"  작업 디렉터리 {cwd}"))
        if sm.path:
            print(c(DIM, f"  {sm.path}"))
        print(c(DIM, "  /help 로 명령 목록"))
        print()
    return sess


# --------------------------------------------------------------------------- 슬래시 커맨드
HELP = """\
세션      /new  /sessions  /resume <id>  /name <이름>  /session  /tree
컨텍스트  /compact [지시]  /usage  /context
하네스    /refine [지시]   /refine --global   /refine --rollback <id>   /harness
장기실행  /goal <목표>  /goal status|complete|clear
          /heartbeat every 10m <지시>  /heartbeat status|clear
          /autonomous on|off|status
에이전트  /agents  /send <이름> <메시지>
모델      /model [패턴]  /models  /effort <레벨>
스킬      /skills  /skill:<이름> [인자]  /reload
기타      /shell <명령>  (또는 !명령)  /help  /quit
"""


def handle_slash(sess: AgentSession, line: str, printer: Printer) -> str | None:
    """슬래시 커맨드를 처리한다. 모델에게 보낼 텍스트를 반환하거나 None."""
    parts = line.strip().split(maxsplit=1)
    cmd = parts[0].lower()
    rest = parts[1].strip() if len(parts) > 1 else ""

    if cmd in ("/help", "/?"):
        print(HELP)
    elif cmd == "/quit":
        raise EOFError
    elif cmd == "/usage" or cmd == "/context":
        st = sess._h_compact_status()
        u = sess.sm.total_usage()
        print(f"  컨텍스트 {st['tokens']:,} / {st['context_window']:,} 토큰 "
              f"({st['percent']}%)")
        print(f"  누적 usage  입력 {u.input:,} · 출력 {u.output:,} · 캐시읽기 {u.cache_read:,}")
        if sess.child_usage.total:
            print(f"  자식 귀속   {sess.child_usage.total:,} 토큰")
    elif cmd == "/compact":
        sess.compact(rest or None)
        print(c(GREEN, "  컴팩션 완료"))
    elif cmd == "/refine":
        if rest.startswith("--rollback"):
            rid = rest.split(maxsplit=1)[1].strip() if " " in rest else ""
            print(json.dumps(sess.refine(None, rollback_id=rid), ensure_ascii=False, indent=2))
        else:
            scope = "global" if rest.startswith("--global") else "local"
            instr = rest.replace("--global", "", 1).strip() or None
            rec = sess.refine(instr, scope)
            print(c(GREEN, f"  {rec.get('summary')}"))
            for e in rec["edits"]:
                mark = "✓" if e.get("applied") else "✗"
                print(f"    {mark} {e['action']} {e['kind']}:{e.get('id')}"
                      + (f"  ({e.get('error')})" if e.get("error") else ""))
            print(c(DIM, f"    id={rec['id']}  (롤백: /refine --rollback {rec['id']})"))
    elif cmd == "/harness":
        print(sess.harness.overview())
    elif cmd == "/goal":
        if not rest or rest == "status":
            print(json.dumps(sess._h_goal_get(), ensure_ascii=False, indent=2))
        elif rest == "complete":
            sess._h_goal_complete()
        elif rest == "clear":
            sess.goal = None
            print(c(GREEN, "  goal 해제"))
        else:
            from .agent import Goal
            sess.goal = Goal(objective=rest)
            print(c(GREEN, f"  goal 설정: {rest}"))
    elif cmd == "/heartbeat":
        if rest in ("status", ""):
            for h in sess.heartbeats:
                print(f"  {h.id} [{h.owner}] {h.status} {h.interval_s}s — {h.instruction}")
            if not sess.heartbeats:
                print(c(DIM, "  (없음)"))
        elif rest == "clear":
            sess.heartbeats = [h for h in sess.heartbeats if h.owner != "user"]
            print(c(GREEN, "  사용자 heartbeat 해제"))
        else:
            import uuid as _u
            iv = parse_interval(rest.split()[1] if rest.startswith("every ") else None)
            instr = rest.split(maxsplit=2)[-1] if rest.startswith("every ") else rest
            h = Heartbeat(id=f"hb_{_u.uuid4().hex[:6]}", instruction=instr, interval_s=iv,
                          owner="user")
            h.next_at = time.time() + iv
            sess.heartbeats = [x for x in sess.heartbeats if x.owner != "user"] + [h]
            print(c(GREEN, f"  heartbeat 설정: {iv}초마다 — {instr}"))
    elif cmd == "/agents":
        info = sess._h_list_agents()
        print(f"  현재: {info['current']['name']} (depth {info['current']['depth']})")
        for e in info["entries"]:
            print(f"    {e['relationship']:8} {e['name']:20} {e['status']}")
        if not info["entries"]:
            print(c(DIM, "    (가족 없음)"))
    elif cmd == "/send":
        n, _, msg = rest.partition(" ")
        try:
            r = sess._h_send({"receiver_role": "child", "receiver_name": n, "message": msg})
            print(c(GREEN, f"  {r['deliveryStatus']} → {r['receiver']}"))
        except Exception as e:
            print(c(RED, f"  {e}"))
    elif cmd == "/models":
        for m in config.load_models():
            mark = "*" if m.selector == sess.model.selector else " "
            print(f" {mark} {m.selector:40} ctx {m.context_window:,}  out {m.max_tokens:,}")
    elif cmd == "/model":
        if not rest:
            print(f"  현재: {sess.model.selector}")
        else:
            m = config.find_model(config.load_models(), rest)
            if m:
                sess.model = m
                sess.sm.append_model_change(m.provider, m.id)
                print(c(GREEN, f"  모델 변경: {m.selector}"))
            else:
                print(c(RED, "  못 찾음"))
    elif cmd == "/effort":
        sess.thinking = rest or None
        print(c(GREEN, f"  thinking = {sess.thinking}"))
    elif cmd == "/skills":
        for s in sess.skills:
            t = "py " if s.python else "md "
            print(f"  {t}{s.name:24} {s.description[:70]}")
        if not sess.skills:
            print(c(DIM, "  (없음)"))
    elif cmd.startswith("/skill:"):
        want = cmd.split(":", 1)[1]
        for s in sess.skills:
            if s.name == want:
                body = s.body()
                return (f"다음 스킬을 사용해라.\n\n<skill name=\"{s.name}\" path=\"{s.path}\">\n"
                        f"{body}\n</skill>" + (f"\n\nUser: {rest}" if rest else ""))
        print(c(RED, f"  스킬 없음: {want}"))
    elif cmd == "/sessions":
        for s in SessionManager.list_sessions()[:25]:
            print(f"  {str(s['id'])[:8]}  {s['timestamp'][:19]}  "
                  f"{(s['name'] or s['preview'])[:50]}")
    elif cmd == "/session":
        print(f"  id      {sess.sm.session_id}")
        print(f"  파일    {sess.sm.path}")
        print(f"  엔트리  {len(sess.sm.entries)}")
    elif cmd == "/name":
        sess.sm.append_session_info(rest)
        print(c(GREEN, f"  세션 이름: {rest}"))
    elif cmd == "/new":
        sess.sm = SessionManager.create(sess.cwd, persist=True)
        print(c(GREEN, f"  새 세션 {sess.sm.session_id[:8]}"))
    elif cmd == "/tree":
        labels = sess.sm.labels()
        for e in sess.sm.entries:
            if e.get("type") != "message":
                continue
            m = e.get("message") or {}
            role = m.get("role", "")
            txt = m.get("content") if isinstance(m.get("content"), str) else ""
            mark = "→" if e["id"] == sess.sm.leaf_id else " "
            lbl = f" [{labels[e['id']]}]" if e["id"] in labels else ""
            print(f" {mark} {e['id']} {role:11}{lbl} {str(txt)[:60]}")
    elif cmd == "/reload":
        sk, notes = skills_mod.discover(sess.cwd, sess.settings)
        sess.skills = sk
        print(c(GREEN, f"  스킬 {len(sk)}개 다시 로드"))
    elif cmd == "/autonomous":
        print(c(DIM, "  autonomous 는 CLI 플래그로 켠다: "
                     "pa -p --autonomous --autonomous-gate '...' \"작업\""))
    elif cmd == "/shell":
        import subprocess
        r = subprocess.run(rest, shell=True, capture_output=True, text=True)
        out = (r.stdout or "") + (r.stderr or "")
        print(out.rstrip())
        return f"$ {rest}\n{out}"
    else:
        print(c(RED, f"  알 수 없는 명령: {cmd}  (/help)"))
    return None


# --------------------------------------------------------------------------- heartbeat 루프
def start_heartbeats(sess: AgentSession, stop: threading.Event) -> threading.Thread:
    def loop() -> None:
        while not stop.wait(2.0):
            now = time.time()
            for h in list(sess.heartbeats):
                if h.status != "active" or h.next_at > now:
                    continue
                h.next_at = now + h.interval_s
                sess.inbox.put({"from": f"heartbeat:{h.label or h.id}",
                                "text": h.instruction, "at": now})
    t = threading.Thread(target=loop, daemon=True, name="heartbeats")
    t.start()
    return t


# --------------------------------------------------------------------------- autonomous
def run_autonomous(sess: AgentSession, first: str, args, printer: Printer) -> None:
    """게이트와 한도가 붙은 무인 실행.

    판정 순서는 원본과 같다: **게이트 먼저**, 그 다음 연속 → 턴 → 토큰 → 시간.
    게이트가 통과하면 한도에 도달했어도 완료를 허용한다.
    한도 도달은 작업 성공을 뜻하지 않는다.
    """
    import subprocess

    cfg = sess.settings.get("autonomous") or {}
    max_cont = args.autonomous_max_continuations or cfg.get("maxContinuations", 3)
    max_turns = args.autonomous_max_turns or cfg.get("maxTurns", 12)
    max_tokens = args.autonomous_max_tokens or cfg.get("maxTokens", 80000)
    timeout_ms = args.autonomous_timeout_ms or cfg.get("timeoutMs", 1800000)
    gate_retries = args.autonomous_gate_retries or cfg.get("gateRetries", 3)
    gate_timeout = (args.autonomous_gate_timeout_ms or cfg.get("gateTimeoutMs", 300000)) / 1000

    gates = list(args.autonomous_gate or [])
    started = time.time()
    conts = turns = 0
    attempts: dict[str, int] = {g: 0 for g in gates}
    last_fail: dict[str, str] = {}
    text = first

    while True:
        sess.run_turn(text)
        printer.flush()
        turns += 1
        text = None

        gate_ok = True
        for g in gates:
            print(c(CYAN, f"  ⟩ gate: {g}"))
            try:
                r = subprocess.run(g, shell=True, capture_output=True, text=True,
                                   timeout=gate_timeout, cwd=str(sess.cwd))
                out = ((r.stdout or "") + (r.stderr or ""))[-4000:]
                passed = r.returncode == 0
            except subprocess.TimeoutExpired:
                out, passed = f"[게이트 시간 초과 {gate_timeout}s — 프로세스 트리 종료]", False
            if passed:
                print(c(GREEN, "    ✓ 통과"))
                continue
            gate_ok = False
            attempts[g] += 1
            print(c(RED, f"    ✗ 실패 ({attempts[g]}/{gate_retries})"))
            if attempts[g] > gate_retries:
                print(c(RED, "  게이트 재시도 소진 — 종료"))
                return
            # 변경 없는 실패 게이트를 반복 실행하지 않는다 — 시도 횟수만 올린다
            if last_fail.get(g) == out:
                text = (f"게이트 `{g}` 가 같은 결과로 계속 실패한다. "
                        f"다른 접근을 시도해라.\n\n{out}")
            else:
                text = f"게이트 `{g}` 가 실패했다. 고쳐라.\n\n```\n{out}\n```"
            last_fail[g] = out
            break

        if gate_ok:
            # 통과한 게이트는 한도 도달과 무관하게 완료를 허용한다
            if gates:
                print(c(GREEN, "  모든 게이트 통과 — 완료"))
                return
            if sess.goal and sess.goal.status == "completed":
                print(c(GREEN, "  goal 완료"))
                return

        if conts >= max_cont:
            print(c(YELLOW, f"  한도 도달: 연속 {conts}/{max_cont} — 작업 성공을 뜻하지 않는다"))
            return
        if turns >= max_turns:
            print(c(YELLOW, f"  한도 도달: 턴 {turns}/{max_turns}"))
            return
        if sess.usage.total >= max_tokens:
            print(c(YELLOW, f"  한도 도달: 토큰 {sess.usage.total}/{max_tokens}"))
            return
        if (time.time() - started) * 1000 >= timeout_ms:
            print(c(YELLOW, "  한도 도달: 경과 시간"))
            return

        conts += 1
        if text is None:
            text = "계속해라. 남은 작업이 없으면 무엇을 검증했는지 요약하고 끝내라."


# --------------------------------------------------------------------------- 서브커맨드
def cmd_doctor(args) -> int:
    print(c(BOLD, "환경 점검"))
    print(f"  Python        {sys.version.split()[0]}")
    print(f"  커널 Python   {config.kernel_python()}")
    print(f"  설정 디렉터리 {config.agent_dir()}")
    print(f"  오프라인      {config.offline()}")
    ok = True
    for mod in ("httpx", "jupyter_client", "ipykernel", "prompt_toolkit"):
        try:
            __import__(mod)
            print(c(GREEN, f"  ✓ {mod}"))
        except ImportError:
            print(c(RED, f"  ✗ {mod} 없음"))
            ok = False

    models = config.load_models()
    if not models:
        print(c(YELLOW, f"  ! models.json 없음 ({config.agent_dir()/'models.json'})"))
        ok = False
    for m in models:
        good, msg = prov.probe(m)
        print((c(GREEN, "  ✓ ") if good else c(RED, "  ✗ ")) + f"{m.selector} — {msg}")

    settings = config.load_settings(Path.cwd())
    sk, notes = skills_mod.discover(Path.cwd(), settings)
    print(f"  스킬          {len(sk)}개")
    for n in notes:
        print(c(YELLOW, f"    ! {n}"))
    return 0 if ok else 1


def cmd_init(args) -> int:
    config.ensure_dirs()
    d = config.agent_dir()
    models = {
        "providers": {
            args.provider or "internal": {
                "name": "사내 추론",
                "baseUrl": args.llm_base_url,
                "api": "openai-completions",
                "apiKey": args.api_key_env or "INTERNAL_LLM_KEY",
                "authHeader": True,
                "compat": {"supportsDeveloperRole": False,
                           "supportsReasoningEffort": False,
                           "maxTokensField": "max_tokens"},
                "models": [{
                    "id": args.llm_model,
                    "name": args.llm_model,
                    "reasoning": False,
                    "input": ["text"],
                    "contextWindow": args.context_window,
                    "maxTokens": args.max_tokens,
                }],
            }
        }
    }
    mp = d / "models.json"
    if mp.exists() and not args.force:
        print(c(YELLOW, f"  이미 있다: {mp} (--force 로 덮어쓰기)"))
    else:
        mp.write_text(json.dumps(models, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(c(GREEN, f"  생성: {mp}"))

    sp = d / "settings.json"
    if not sp.exists():
        sp.write_text(json.dumps({
            "defaultProvider": args.provider or "internal",
            "defaultModel": args.llm_model,
            "compaction": {"enabled": True, "reserveTokens": 16384,
                           "keepRecentTokens": 20000},
            "rlm": {"maxDepth": 2},
        }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(c(GREEN, f"  생성: {sp}"))
    print(f"\n  확인:  pa doctor")
    return 0


def cmd_sessions(args) -> int:
    for s in SessionManager.list_sessions()[:50]:
        print(f"  {str(s['id'])[:8]}  {s['timestamp'][:19]}  {s['entries']:4}개  "
              f"{(s['name'] or s['preview'])[:55]}")
    return 0


# --------------------------------------------------------------------------- main
def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="pa", description="Prime Agent (Python 이식본)")
    sub = ap.add_subparsers(dest="sub")

    d = sub.add_parser("doctor", help="환경 점검")
    d.set_defaults(func=cmd_doctor)

    i = sub.add_parser("init", help="models.json / settings.json 생성")
    i.add_argument("--llm-base-url", required=True)
    i.add_argument("--llm-model", required=True)
    i.add_argument("--provider", default="internal")
    i.add_argument("--api-key-env", default="INTERNAL_LLM_KEY")
    i.add_argument("--context-window", type=int, default=131072)
    i.add_argument("--max-tokens", type=int, default=16384)
    i.add_argument("--force", action="store_true")
    i.set_defaults(func=cmd_init)

    s = sub.add_parser("sessions", help="저장된 세션 목록")
    s.set_defaults(func=cmd_sessions)

    m = sub.add_parser("models", help="모델 목록 + 연결 확인")
    m.set_defaults(func=lambda a: cmd_doctor(a))

    ap.add_argument("message", nargs="*", help="초기 프롬프트")
    ap.add_argument("-p", "--print", dest="print_mode", action="store_true",
                    help="한 번 실행하고 종료")
    ap.add_argument("--mode", choices=["text", "json"], default="text")
    ap.add_argument("--model")
    ap.add_argument("--provider")
    ap.add_argument("--api-key")
    ap.add_argument("--thinking", choices=["off", "minimal", "low", "medium",
                                           "high", "xhigh", "max"])
    ap.add_argument("--cwd")
    ap.add_argument("-c", "--continue", dest="cont", action="store_true")
    ap.add_argument("-r", "--resume", nargs="?", const="")
    ap.add_argument("--no-session", action="store_true")
    ap.add_argument("--skill", action="append")
    ap.add_argument("--no-skills", action="store_true")
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--goal")
    ap.add_argument("--goal-token-budget", type=int)
    ap.add_argument("--autonomous", action="store_true")
    ap.add_argument("--autonomous-gate", action="append")
    ap.add_argument("--autonomous-gate-retries", type=int)
    ap.add_argument("--autonomous-gate-timeout-ms", type=int)
    ap.add_argument("--autonomous-max-continuations", type=int)
    ap.add_argument("--autonomous-max-turns", type=int)
    ap.add_argument("--autonomous-max-tokens", type=int)
    ap.add_argument("--autonomous-timeout-ms", type=int)

    args = ap.parse_args(argv)
    if getattr(args, "func", None):
        return args.func(args)

    args.json_mode = args.mode == "json"
    printer = Printer(quiet=args.quiet, json_mode=args.json_mode)
    sess = build_session(args, printer)

    initial = " ".join(args.message).strip()
    if not sys.stdin.isatty() and not args.print_mode and not initial:
        piped = sys.stdin.read().strip()
        if piped:
            initial = piped

    stop = threading.Event()
    start_heartbeats(sess, stop)

    try:
        if args.autonomous:
            if not initial:
                print(c(RED, "autonomous 모드에는 초기 프롬프트가 필요하다"))
                return 2
            run_autonomous(sess, initial, args, printer)
            return 0

        if args.print_mode or args.json_mode:
            if not initial:
                initial = sys.stdin.read().strip()
            sess.run_turn(initial)
            printer.flush()
            return 0

        # 대화형
        if initial:
            sess.run_turn(initial)
            printer.flush()
            print()

        try:
            from prompt_toolkit import PromptSession
            from prompt_toolkit.history import FileHistory
            hist = FileHistory(str(config.agent_dir() / "history"))
            ps = PromptSession(history=hist)
            read = lambda: ps.prompt("› ")
        except Exception:
            read = lambda: input("› ")

        while True:
            try:
                line = read()
            except (EOFError, KeyboardInterrupt):
                break
            line = (line or "").strip()
            if not line:
                # 대기 중인 메시지·heartbeat 만 처리
                pending = sess.drain_inbox()
                if pending:
                    sess.run_turn("\n\n".join(pending))
                    printer.flush()
                    print()
                continue
            if line.startswith("!"):
                line = "/shell " + line[1:]
            if line.startswith("/"):
                try:
                    forwarded = handle_slash(sess, line, printer)
                except EOFError:
                    break
                except Exception as e:
                    print(c(RED, f"  {type(e).__name__}: {e}"))
                    continue
                if not forwarded:
                    continue
                line = forwarded

            pending = sess.drain_inbox()
            if pending:
                line = line + "\n\n" + "\n\n".join(pending)
            try:
                sess.run_turn(line)
            except KeyboardInterrupt:
                sess.abort()
                print(c(YELLOW, "\n  중단"))
            except Exception as e:
                print(c(RED, f"\n  {type(e).__name__}: {e}"))
            printer.flush()
            print()
        return 0
    finally:
        stop.set()
        printer.flush()
        sess.close()


if __name__ == "__main__":
    raise SystemExit(main())
