"""커널 안에서 도는 런타임 shim (원본 `prime-agent-runtime` 의 `rlm` 모듈에 대응).

이 모듈은 **커널 프로세스 안에서만** import 된다. 호스트 프로세스는 이걸 쓰지 않는다.
모든 권위 있는 동작(프로바이더 호출, 자식 생성, 스케줄, 트랜스크립트 기록)은
호스트에 있고, 여기서는 loopback TCP 로 요청만 보낸다.

원본과 맞춘 규약
----------------
* `await rlm("...")` 는 **admission 시점에 핸들을 반환**한다. 자식의 답변을 기다리지 않는다.
* 자식 결과는 오직 `agent_message` 나 파일로만 온다.
* Python 예약어 때문에 `global=True` 는 문법 오류다 → `global_=True` 를 쓴다.
* 모르는 옵션은 무시하지 않고 실패시킨다.
"""

from __future__ import annotations

import asyncio
import inspect
import itertools
import json
import socket
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

_HOST: str | None = None
_PORT: int | None = None
_TOKEN: str | None = None
_sock: socket.socket | None = None
_lock = threading.Lock()
_ids = itertools.count(1)
_buf = b""


# --------------------------------------------------------------------------- 전송
def connect(host: str, port: int, token: str) -> None:
    global _HOST, _PORT, _TOKEN, _sock, _buf
    _HOST, _PORT, _TOKEN = host, port, token
    _sock, _buf = None, b""


def _ensure() -> socket.socket:
    global _sock, _buf
    if _sock is None:
        if _HOST is None:
            raise RuntimeError("호스트 브리지가 설정되지 않았다 (connect 미호출)")
        s = socket.create_connection((_HOST, _PORT), timeout=None)
        s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        _sock, _buf = s, b""
    return _sock


def _request_sync(rtype: str, payload: dict | None = None) -> Any:
    global _sock, _buf
    with _lock:
        s = _ensure()
        rid = next(_ids)
        # payload 를 먼저 펼치고 type 을 나중에 넣는다 —
        # payload 안의 'type' 키가 요청을 가로채지 못하도록 (원본과 동일한 방어)
        msg = {"payload": payload or {}, "rid": rid, "token": _TOKEN, "type": rtype}
        try:
            s.sendall((json.dumps(msg, ensure_ascii=False, default=str) + "\n").encode("utf-8"))
        except OSError:
            _sock = None
            s = _ensure()
            s.sendall((json.dumps(msg, ensure_ascii=False, default=str) + "\n").encode("utf-8"))

        while True:
            if b"\n" in _buf:
                line, _buf = _buf.split(b"\n", 1)
                if not line.strip():
                    continue
                rep = json.loads(line.decode("utf-8"))
                if rep.get("rid") != rid:
                    continue
                status = rep.get("status")
                if status == "ok":
                    return rep.get("result")
                if status == "error":
                    raise RuntimeError(rep.get("error") or "host request failed")
                raise RuntimeError(f"host request {rtype} 가 예상치 못한 status 를 반환: {status}")
            chunk = s.recv(65536)
            if not chunk:
                _sock = None
                raise RuntimeError("호스트 브리지 연결이 끊겼다")
            _buf += chunk


async def host_request(request_type: str, payload: dict | None = None) -> Any:
    """범용 타입드 호스트 브리지 (원본 `rlm.host_request`)."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _request_sync, request_type, payload)


# --------------------------------------------------------------------------- 데이터 타입
@dataclass(frozen=True)
class RLMSpawnHandle:
    rlm_child_id: str
    name: str
    session_dir: Path
    model: str

    def __repr__(self) -> str:  # 모델이 읽기 좋게
        return f"RLMSpawnHandle(name={self.name!r}, model={self.model!r})"


@dataclass(frozen=True)
class RLMModel:
    provider: str
    id: str
    name: str
    selector: str


@dataclass(frozen=True)
class RLMSubagent:
    rlm_child_id: str
    session_id: str | None
    session_name: str
    session_dir: Path
    status: str  # running | completed | error


# --------------------------------------------------------------------------- rlm
_RUN_OPTIONS = {"name", "model", "thinking"}


class _RLM:
    """`rlm` 네임스페이스. 호출 가능하며 `rlm.run` 과 동일하다."""

    async def __call__(self, prompt: str, **kwargs) -> RLMSpawnHandle:
        return await self.run(prompt, **kwargs)

    async def run(self, prompt: str, **kwargs) -> RLMSpawnHandle:
        """재귀 자식 에이전트를 띄운다.

        **admission 시점에 즉시 반환한다. 자식의 답변은 절대 반환하지 않는다.**
        결과를 받으려면 자식이 `agent_message.send(..., receiver_role="parent")` 를
        호출하게 하거나, 자식이 파일에 쓰게 하고 그 파일을 읽어라.

        지원 옵션은 name / model / thinking 뿐이다. 그 외는 실패한다.
        """
        unknown = set(kwargs) - _RUN_OPTIONS
        if unknown:
            raise TypeError(
                f"지원하지 않는 옵션: {sorted(unknown)}. 쓸 수 있는 것은 {sorted(_RUN_OPTIONS)}"
            )
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("prompt 는 비어있지 않은 문자열이어야 한다")
        r = await host_request("rlm.run", {"prompt": prompt, **kwargs})
        return RLMSpawnHandle(
            rlm_child_id=r["rlm_child_id"], name=r["name"],
            session_dir=Path(r["session_dir"]), model=r["model"],
        )

    async def find_models(self, query: str = "", limit: int = 8) -> list[RLMModel]:
        """활성 자격증명으로 실제 쓸 수 있는 모델 목록을 검색한다."""
        r = await host_request("rlm.find_models", {"query": query, "limit": limit})
        return [RLMModel(**m) for m in r]

    async def list_subagents(self) -> list[RLMSubagent]:
        """현재 부모 세션이 보유한 직계 자식 목록."""
        r = await host_request("rlm.list_subagents", {})
        return [RLMSubagent(rlm_child_id=c["rlm_child_id"], session_id=c.get("session_id"),
                            session_name=c["session_name"],
                            session_dir=Path(c["session_dir"]), status=c["status"]) for c in r]

    async def delete_subagent(self, target: "str | RLMSubagent | RLMSpawnHandle") -> dict:
        """직계 자식 1개를 삭제한다. 디스크의 트랜스크립트는 지우지 않는다.

        주의: `agent_message.send` 직후에 삭제하지 말 것.
        배달된 follow-up 이 아직 돌고 있을 수 있다.
        """
        sel = target if isinstance(target, str) else getattr(
            target, "rlm_child_id", None) or getattr(target, "name", None)
        return await host_request("rlm.delete_subagent", {"target": sel})

    host_request = staticmethod(host_request)

    @property
    def harness(self) -> "_Harness":
        return harness

    def __repr__(self) -> str:
        return "<rlm: run / find_models / list_subagents / delete_subagent / harness>"


rlm = _RLM()


# --------------------------------------------------------------------------- harness
class _Harness:
    """Continual Harness — 프롬프트 노트·메모리·스킬 기술·서브에이전트 스펙의 영속 원장.

    실행 엔진이 아니다. 저장소일 뿐이다.
    """

    async def overview(self, global_: bool = False) -> str:
        return await host_request("harness.overview", {"global": global_})

    async def list(self, kind: str | None = None, global_: bool = False) -> list[dict]:
        return await host_request("harness.list", {"kind": kind, "global": global_})

    async def get(self, id: str, kind: str | None = None, global_: bool = False) -> dict | None:
        return await host_request("harness.get", {"id": id, "kind": kind, "global": global_})

    async def delete(self, id: str, kind: str | None = None, global_: bool = False) -> dict:
        return await host_request("harness.delete", {"id": id, "kind": kind, "global": global_})

    async def _upsert(self, kind: str, title: str, content: str, *, id: str | None = None,
                      path: str = "general", reference: dict | None = None,
                      arguments: dict | None = None, metadata: dict | None = None,
                      global_: bool = False, mode: str = "upsert") -> dict:
        return await host_request("harness.upsert", {
            "kind": kind, "title": title, "content": content, "id": id, "path": path,
            "reference": reference, "arguments": arguments, "metadata": metadata,
            "global": global_, "mode": mode,
        })

    # 타입드 헬퍼 — 원본과 같은 이름
    async def create_memory(self, title, content, **kw):
        return await self._upsert("memory", title, content, mode="create", **kw)

    async def update_memory(self, title, content, **kw):
        return await self._upsert("memory", title, content, mode="update", **kw)

    async def delete_memory(self, id, global_=False):
        return await self.delete(id, "memory", global_)

    async def create_prompt_note(self, title, content, **kw):
        kw.setdefault("path", "policy")
        return await self._upsert("prompt", title, content, mode="create", **kw)

    async def update_prompt_note(self, title, content, **kw):
        kw.setdefault("path", "policy")
        return await self._upsert("prompt", title, content, mode="update", **kw)

    async def delete_prompt_note(self, id, global_=False):
        return await self.delete(id, "prompt", global_)

    async def create_subagent(self, title, content, **kw):
        return await self._upsert("subagent", title, content, mode="create", **kw)

    async def update_subagent(self, title, content, **kw):
        return await self._upsert("subagent", title, content, mode="update", **kw)

    async def delete_subagent(self, id, global_=False):
        return await self.delete(id, "subagent", global_)

    async def create_skill(self, title, content, *, reference: dict, arguments: dict, **kw):
        return await self._upsert("skill", title, content, reference=reference,
                                  arguments=arguments, mode="create", **kw)

    async def update_skill(self, title, content, *, reference: dict, arguments: dict, **kw):
        return await self._upsert("skill", title, content, reference=reference,
                                  arguments=arguments, mode="update", **kw)

    async def delete_skill(self, id, global_=False):
        return await self.delete(id, "skill", global_)

    async def record_refinement(self, trigger: str, changes: list[str],
                                evidence: str = "", outcome: str = "",
                                global_: bool = False) -> dict:
        return await host_request("harness.record_refinement", {
            "trigger": trigger, "changes": changes, "evidence": evidence,
            "outcome": outcome, "global": global_,
        })

    def __repr__(self) -> str:
        return "<harness: overview / list / get / create_* / update_* / delete_* / record_refinement>"


harness = _Harness()


# --------------------------------------------------------------------------- 메시징
class _AgentMessage:
    """가족(부모·형제·직계 자식) 범위 메시징. 발신자 신원은 호스트가 정한다."""

    async def list_agents(self) -> dict:
        return await host_request("agent_message.list_agents", {})

    async def send(self, message: str, broadcast_message: str | None = None, *,
                   receiver_role: Literal["parent", "sibling", "child"] | None = None,
                   receiver_name: str | None = None) -> dict:
        """메시지를 보낸다.

        - `receiver_name` 은 sibling/child 에 **필수**, parent 에는 **금지**
        - `send("all", message)` 는 가족 로스터 브로드캐스트 (역할 지정과 병용 불가)
        - 블로킹하지 않는다. 영수증의 deliveryStatus 는 delivered 또는 queued
        """
        if broadcast_message is not None:
            if receiver_role or receiver_name:
                raise ValueError("브로드캐스트는 receiver_role/receiver_name 과 함께 쓸 수 없다")
            if message != "all":
                raise ValueError('브로드캐스트는 send("all", message) 형태여야 한다')
            return await host_request("agent_message.broadcast", {"message": broadcast_message})
        if receiver_role == "parent" and receiver_name:
            raise ValueError("parent 에는 receiver_name 을 주면 안 된다")
        if receiver_role in ("sibling", "child") and not receiver_name:
            raise ValueError(f"{receiver_role} 에는 receiver_name 이 필요하다")
        return await host_request("agent_message.send", {
            "message": message, "receiver_role": receiver_role, "receiver_name": receiver_name,
        })

    def __repr__(self) -> str:
        return "<agent_message: list_agents / send>"


agent_message = _AgentMessage()


class _AgentObserve:
    """읽기 전용 관측. 어떤 세션도 변경할 수 없다."""

    async def list_agents(self) -> dict:
        return await host_request("agent_observe.list_agents", {})

    async def get_agent(self, target: str) -> dict:
        return await host_request("agent_observe.get_agent", {"target": target})

    async def recent_messages(self, target: str, limit: int = 8, max_chars: int = 800) -> dict:
        if not 1 <= limit <= 50:
            raise ValueError("limit 은 1~50")
        if not 80 <= max_chars <= 2000:
            raise ValueError("max_chars 는 80~2000")
        return await host_request("agent_observe.recent_messages", {
            "target": target, "limit": limit, "max_chars": max_chars})

    def __repr__(self) -> str:
        return "<agent_observe: list_agents / get_agent / recent_messages (읽기 전용)>"


agent_observe = _AgentObserve()


# --------------------------------------------------------------------------- goal / compact / refine
class _Goal:
    async def get(self) -> dict:
        return await host_request("goal.get", {})

    async def create(self, objective: str, token_budget: int | None = None) -> dict:
        return await host_request("goal.create",
                                  {"objective": objective, "token_budget": token_budget})

    async def complete(self) -> dict:
        """goal 을 성공 완료로 표시한다. **이것만이 성공 완료 신호다.**"""
        return await host_request("goal.complete", {})

    def __repr__(self) -> str:
        return "<goal: get / create / complete>"


goal = _Goal()


class _Compact:
    async def status(self) -> dict:
        return await host_request("compact.status", {})

    async def run(self, instructions: str | None = None) -> dict:
        """컴팩션을 예약한다. 셀 중간에 돌지 않고 현재 턴이 끝날 때 실행된다."""
        return await host_request("compact.run", {"instructions": instructions})

    def __repr__(self) -> str:
        return "<compact: status / run>"


compact = _Compact()


class _Refine:
    async def status(self) -> dict:
        return await host_request("refine.status", {})

    async def run(self, instructions: str | None = None, global_: bool = False) -> dict:
        """하네스 정제를 예약한다. 즉시 반환하며 현재 턴이 끝날 때 실행된다."""
        return await host_request("refine.run",
                                  {"instructions": instructions, "global": global_})

    def __repr__(self) -> str:
        return "<refine: status / run>"


refine = _Refine()


class _RlmHeartbeat:
    """에이전트 소유 반복 프롬프트. 사용자 소유 `/heartbeat` 와는 별개이며 그것을 건드릴 수 없다."""

    async def list(self, include_inactive: bool = False) -> list[dict]:
        return await host_request("rlm_heartbeat.list", {"include_inactive": include_inactive})

    async def create(self, instruction: str, interval: str | None = None,
                     label: str | None = None,
                     delivery_mode: Literal["steer", "follow_up"] | None = None) -> dict:
        return await host_request("rlm_heartbeat.create", {
            "instruction": instruction, "interval": interval or "5m",
            "label": label, "delivery_mode": delivery_mode or "steer"})

    async def update(self, id: str, **kw) -> dict:
        return await host_request("rlm_heartbeat.update", {"id": id, **kw})

    async def delete(self, id: str) -> dict:
        return await host_request("rlm_heartbeat.delete", {"id": id})

    def __repr__(self) -> str:
        return "<rlm_heartbeat: list / create / update / delete>"


rlm_heartbeat = _RlmHeartbeat()


# --------------------------------------------------------------------------- edit
async def _edit_run(path: str, old_str: str, new_str: str) -> str:
    """정확히 1회 일치하는 문자열을 치환한다. 0회거나 2회 이상이면 예외."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"파일이 없다: {path}")
    text = p.read_text(encoding="utf-8")
    n = text.count(old_str)
    if n == 0:
        raise ValueError(f"old_str 를 찾지 못했다: {path}")
    if n > 1:
        raise ValueError(f"old_str 가 {n}번 일치한다. 유일해질 때까지 앞뒤 문맥을 넓혀라: {path}")
    p.write_text(text.replace(old_str, new_str, 1), encoding="utf-8")
    return f"{path} 1곳 수정"


class _Edit:
    run = staticmethod(_edit_run)

    async def __call__(self, path: str, old_str: str, new_str: str) -> str:
        return await _edit_run(path, old_str, new_str)

    def __repr__(self) -> str:
        return "<edit(path, old_str, new_str) — 유일 일치 1회 치환>"


edit = _Edit()

__all__ = [
    "connect", "host_request", "rlm", "harness", "agent_message", "agent_observe",
    "goal", "compact", "refine", "rlm_heartbeat", "edit",
    "RLMSpawnHandle", "RLMModel", "RLMSubagent",
]
