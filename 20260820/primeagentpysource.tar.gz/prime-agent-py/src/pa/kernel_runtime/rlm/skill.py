"""스킬용 CLI 어댑터.

저장소 원본 스킬들이 `pyproject.toml` 에 이렇게 선언한다:

    [project.scripts]
    word_count = "rlm.skill:cli"

`sys.argv[0]` 의 stem 으로 모듈 이름을 정하고, 그 모듈의 `run` 을 CLI 로 노출한다.
스크립트 이름은 **import 이름과 정확히 일치**해야 한다 (`word_count`, `word-count` 아님).

`tyro` 가 있으면 타입 힌트 기반 CLI 를 만들고, 없으면 argparse 로 최소한만 처리한다.
"""

from __future__ import annotations

import asyncio
import inspect
import sys
from pathlib import Path


def cli() -> None:
    prog = Path(sys.argv[0]).stem
    try:
        mod = __import__(prog)
    except ImportError as e:
        print(f"스킬 모듈을 import 하지 못했다: {prog} ({e})", file=sys.stderr)
        raise SystemExit(1)

    func = getattr(mod, "run", None)
    if func is None:
        print(f"{prog} 에 run() 이 없다", file=sys.stderr)
        raise SystemExit(1)

    try:
        import tyro
        result = tyro.cli(func, prog=prog)
    except ImportError:
        import argparse
        ap = argparse.ArgumentParser(prog=prog, description=(func.__doc__ or "").strip())
        sig = inspect.signature(func)
        for name, p in sig.parameters.items():
            if p.default is inspect.Parameter.empty:
                ap.add_argument(name)
            else:
                ap.add_argument(f"--{name.replace('_', '-')}", dest=name,
                                default=p.default,
                                type=type(p.default) if p.default is not None else str)
        ns = ap.parse_args()
        result = func(**vars(ns))

    if inspect.isawaitable(result):
        result = asyncio.run(result)
    if result is not None:
        print(result)
