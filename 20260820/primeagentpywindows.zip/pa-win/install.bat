@echo off
REM prime-agent-py 폐쇄망 설치 (Windows)
REM Python 3.10+ 가 PATH 에 있어야 한다.

where python >nul 2>nul
if errorlevel 1 (
  echo [!] python 을 PATH 에서 찾지 못했다. Python 3.10 이상을 먼저 설치할 것.
  pause
  exit /b 1
)

python install.py --check
if errorlevel 1 ( pause & exit /b 1 )

echo.
echo 사내 추론 엔드포인트를 입력해라 (예: http://10.0.0.42:8000/v1)
set /p BASEURL=baseUrl: 
set /p MODEL=모델 id: 

python install.py --venv C:\prime-agent\venv --llm-base-url %BASEURL% --llm-model %MODEL%
pause
