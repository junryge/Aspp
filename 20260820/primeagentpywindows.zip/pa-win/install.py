#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""prime-agent-py 윈도우 폐쇄망 설치기.

인터넷 없이 설치한다. 표준 라이브러리만 쓴다.

    python install.py                 가상환경 만들고 설치
    python install.py --system        현재 Python 에 바로 설치 (venv 없이)
    python install.py --check         설치 가능 여부만 점검
    python install.py --venv C:\\pa\\venv --llm-base-url http://10.0.0.42:8000/v1 \
                      --llm-model Qwen3-32B --context-window 262144
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
import venv
from pathlib import Path

HERE = Path(__file__).resolve().parent
WHEELS = HERE / "wheels"
WIN = os.name == "nt"

if WIN:
    os.system("")  # ANSI 활성화


def col(code: str, s: str) -> str:
    return f"\033[{code}m{s}\033[0m" if sys.stdout.isatty() else s


def ok(m):   print("  " + col("32", "✓") + " " + m)
def warn(m): print("  " + col("33", "!") + " " + m)
def bad(m):  print("  " + col("31", "✗") + " " + m)
def head(m): print("\n" + col("1", m))


def run(cmd, dry=False) -> int:
    print("  " + col("2", "$ " + " ".join(str(c) for c in cmd)))
    if dry:
        return 0
    return subprocess.run(cmd).returncode


def py_in(venv_dir: Path) -> Path:
    return venv_dir / ("Scripts" if WIN else "bin") / ("python.exe" if WIN else "python")


def check(args) -> int:
    head("환경 점검")
    v = sys.version_info
    if v >= (3, 10):
        ok(f"Python {platform.python_version()} ({platform.machine()})")
    else:
        bad(f"Python {platform.python_version()} — 3.10 이상 필요")
        return 1
    print(f"    실행 파일: {sys.executable}")
    print(f"    플랫폼:    {platform.platform()}")

    if not WHEELS.is_dir():
        bad(f"wheels 디렉터리가 없다: {WHEELS}")
        return 1
    whls = sorted(WHEELS.glob("*.whl"))
    ok(f"wheel {len(whls)}개 ({sum(f.stat().st_size for f in whls)/1e6:.0f} MB)")

    main = [w for w in whls if w.name.startswith("prime_agent_py")]
    if main:
        ok(f"본체: {main[0].name}")
    else:
        bad("prime_agent_py wheel 이 없다")
        return 1

    # 현재 인터프리터에 맞는 wheel 이 있는지 대략 확인
    tag = f"cp{v.major}{v.minor}"
    plat = "win_amd64" if WIN else "linux"
    binary = [w for w in whls if "-cp" in w.name]
    matched = [w for w in binary if tag in w.name]
    if binary and not matched:
        warn(f"바이너리 wheel 이 {tag} 용이 아닐 수 있다. "
             f"({[w.name for w in binary[:3]]}) — Python 버전을 맞추거나 wheel 을 다시 받을 것")
    else:
        ok(f"바이너리 wheel 태그 확인 ({tag}, {plat})")

    try:
        import ensurepip  # noqa: F401
        ok("ensurepip 사용 가능 (venv 생성 가능)")
    except ImportError:
        warn("ensurepip 없음 — --system 으로 현재 Python 에 설치할 것")
    return 0


def install(args) -> int:
    target_py = Path(sys.executable)
    if not args.system:
        head(f"가상환경 생성 → {args.venv}")
        if args.venv.exists() and args.force:
            shutil.rmtree(args.venv)
        if not args.venv.exists():
            if args.dry_run:
                print(f"  [dry-run] venv {args.venv}")
            else:
                venv.EnvBuilder(with_pip=True, symlinks=not WIN).create(args.venv)
                ok("생성 완료")
        else:
            warn("이미 존재 (--force 로 다시 만들기)")
        target_py = py_in(args.venv)

    head("오프라인 설치 (wheels 디렉터리만 사용)")
    cmd = [str(target_py), "-m", "pip", "install", "--no-index",
           "--find-links", str(WHEELS), "prime-agent-py"]
    if args.system:
        cmd.append("--user" if not args.no_user else "--break-system-packages")
    if run(cmd, args.dry_run) != 0:
        bad("설치 실패")
        return 1
    ok("prime-agent-py 설치")

    head("설정 파일")
    agent_dir = Path(os.environ.get("PA_AGENT_DIR") or (Path.home() / ".prime" / "agent-py"))
    agent_dir.mkdir(parents=True, exist_ok=True)

    if args.llm_base_url:
        models = {"providers": {args.provider: {
            "name": "사내 추론",
            "baseUrl": args.llm_base_url,
            "api": "openai-completions",
            "apiKey": args.api_key_env,
            "authHeader": True,
            "compat": {"supportsDeveloperRole": False,
                       "supportsReasoningEffort": False,
                       "maxTokensField": "max_tokens"},
            "models": [{"id": args.llm_model,
                        "name": args.llm_model,
                        "reasoning": False,
                        "input": ["text"],
                        "contextWindow": args.context_window,
                        "maxTokens": args.max_tokens}],
        }}}
        p = agent_dir / "models.json"
        if p.exists() and not args.force:
            warn(f"이미 존재, 건너뜀: {p}")
        elif args.dry_run:
            print(f"  [dry-run] write {p}")
        else:
            p.write_text(json.dumps(models, ensure_ascii=False, indent=2), encoding="utf-8")
            ok(f"models.json — {args.provider} → {args.llm_base_url}")
            print("    " + col("2", f"contextWindow({args.context_window})는 서버 "
                                    f"--max-model-len 과 반드시 맞출 것"))
    else:
        warn("--llm-base-url 미지정 — 나중에 `pa init` 으로 만들 것")

    sp = agent_dir / "settings.json"
    if not sp.exists() and not args.dry_run:
        sp.write_text(json.dumps({
            "defaultProvider": args.provider,
            "defaultModel": args.llm_model,
            "compaction": {"enabled": True, "reserveTokens": 16384,
                           "keepRecentTokens": 20000},
            "rlm": {"maxDepth": 2},
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        ok("settings.json")

    head("완료")
    exe = (args.venv / ("Scripts" if WIN else "bin") / ("pa.exe" if WIN else "pa")) \
        if not args.system else Path("pa")
    print(f"  실행:  {exe}")
    print(f"  점검:  {exe} doctor")
    if not args.system:
        act = args.venv / ("Scripts\\activate.bat" if WIN else "bin/activate")
        print(f"  활성화: {act}")
    if args.api_key_env:
        setcmd = f"set {args.api_key_env}=..." if WIN else f"export {args.api_key_env}=..."
        print(f"  키:    {setcmd}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="prime-agent-py 폐쇄망 설치기")
    ap.add_argument("--check", action="store_true", help="점검만")
    ap.add_argument("--system", action="store_true", help="venv 없이 현재 Python 에 설치")
    ap.add_argument("--no-user", action="store_true",
                    help="--system 일 때 --user 대신 --break-system-packages 사용")
    default_venv = Path("C:/prime-agent/venv") if WIN else Path.home() / ".prime" / "venv"
    ap.add_argument("--venv", type=Path, default=default_venv)
    ap.add_argument("--llm-base-url")
    ap.add_argument("--llm-model", default="internal-model")
    ap.add_argument("--provider", default="internal")
    ap.add_argument("--api-key-env", default="INTERNAL_LLM_KEY")
    ap.add_argument("--context-window", type=int, default=131072)
    ap.add_argument("--max-tokens", type=int, default=16384)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    print(col("1", "prime-agent-py 폐쇄망 설치기") + col("2", f"  kit={HERE}"))
    rc = check(a)
    if a.check or rc != 0:
        return rc
    return install(a)


if __name__ == "__main__":
    raise SystemExit(main())
