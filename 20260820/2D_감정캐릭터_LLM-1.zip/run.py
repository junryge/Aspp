#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
=============================================================================
 2D 감정캐릭터 × LLM  —  로컬 서버 + API 프록시   (Python 3.8+, 표준 라이브러리만)
=============================================================================

 이 스크립트 하나가 두 가지를 한다.
   1) 앱(HTML)을 http:// 로 서빙       -> file:// 특유의 제약이 사라진다
   2) LLM API를 같은 포트로 중계        -> 페이지와 출처가 같아져 CORS가 아예 없다
                                           API 키도 브라우저에 안 남는다

 [실행]
   Windows (PowerShell)
     $env:OPENAI_API_KEY="sk-..."
     python run.py
   macOS / Linux
     OPENAI_API_KEY="sk-..." python3 run.py

   키를 인자로 줘도 된다:  python3 run.py --key sk-...

 [앱 설정 탭]
   Base URL : /v1          <- 슬래시 브이원. 이게 전부다
   API Key  : local        <- 아무 값. 진짜 키는 이 서버에만 있다
   Model    : gpt-4o-mini

 [OpenAI 외 다른 엔드포인트를 쓸 일이 생기면]
   python3 run.py --upstream <OpenAI 호환 주소>

=============================================================================
"""

import argparse
import http.server
import json
import os
import socketserver
import sys
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
APP_FILE = "2D_감정캐릭터_LLM.html"

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Max-Age": "86400",
}


class Cfg:
    upstream = "https://api.openai.com/v1"
    key = ""
    timeout = 120


# ─────────────────────────────────────────────────────────────────────────────
def find_app():
    """앱 HTML 찾기. 이름이 바뀌었어도 .html 하나면 그걸 쓴다."""
    p = BASE_DIR / APP_FILE
    if p.exists():
        return p.name
    htmls = sorted(BASE_DIR.glob("*.html"))
    return htmls[0].name if htmls else None


class Handler(http.server.SimpleHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(BASE_DIR), **kw)

    # ── 로그: 프록시 호출만 보이게 정리 ────────────────────────────────────
    def log_message(self, fmt, *args):
        pass

    def _say(self, msg):
        sys.stdout.write("  " + msg + "\n")
        sys.stdout.flush()

    # ── 공통 응답 ─────────────────────────────────────────────────────────
    def _send(self, code, body: bytes, ctype="application/json; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in CORS_HEADERS.items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _err(self, code, msg):
        self._send(code, json.dumps({"error": {"message": msg}},
                                    ensure_ascii=False).encode("utf-8"))

    # ── OPTIONS (프리플라이트) ────────────────────────────────────────────
    def do_OPTIONS(self):
        self.send_response(204)
        for k, v in CORS_HEADERS.items():
            self.send_header(k, v)
        self.send_header("Content-Length", "0")
        self.end_headers()

    # ── GET : 앱 서빙 ─────────────────────────────────────────────────────
    def do_GET(self):
        if self.path == "/favicon.ico":
            self.send_response(204)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if self.path in ("/", "/index.html"):
            app = find_app()
            if not app:
                self._err(404, "앱 HTML 파일을 찾을 수 없습니다.")
                return
            self.path = "/" + app
        return super().do_GET()

    # ── POST : LLM API 중계 ───────────────────────────────────────────────
    def do_POST(self):
        if not self.path.startswith("/v1"):
            self._err(404, "알 수 없는 경로: " + self.path)
            return

        path = self.path[3:] or "/chat/completions"      # /v1/... -> /...
        url = Cfg.upstream.rstrip("/") + path

        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        body = self.rfile.read(length) if length else b"{}"

        model = ""
        try:
            model = json.loads(body.decode("utf-8")).get("model", "")
        except Exception:
            pass

        req = urllib.request.Request(
            url,
            data=body,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "Authorization": "Bearer " + (Cfg.key or "local"),
            },
        )

        t0 = time.time()
        try:
            with urllib.request.urlopen(req, timeout=Cfg.timeout) as r:
                data = r.read()
                ms = int((time.time() - t0) * 1000)
                self._say("200  {}  {}  {}ms".format(path, model or "-", ms))
                self._send(200, data)

        except urllib.error.HTTPError as e:
            data = e.read()
            ms = int((time.time() - t0) * 1000)
            self._say("{}  {}  {}ms".format(e.code, path, ms))
            try:
                detail = json.loads(data.decode("utf-8"))
                msg = detail.get("error", {}).get("message", "")
            except Exception:
                msg = data.decode("utf-8", "replace")[:300]
            if msg:
                self._say("     ↳ " + msg[:220])
            if e.code == 401:
                self._say("     ↳ API 키를 확인하세요.")
            elif e.code == 404:
                self._say("     ↳ 모델 이름 또는 --upstream 주소를 확인하세요.")
            elif e.code == 429:
                self._say("     ↳ 사용량/한도 초과입니다.")
            self._send(e.code, data)

        except urllib.error.URLError as e:
            self._say("[x] upstream 연결 실패: {}".format(e.reason))
            self._err(502, "upstream 연결 실패: {}".format(e.reason))

        except Exception as e:  # noqa: BLE001
            self._say("[x] {}".format(e))
            self._err(500, str(e))


class Server(socketserver.ThreadingTCPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address):
        """브라우저가 먼저 연결을 끊는 건 정상. 역추적 출력만 막는다."""
        exc = sys.exc_info()[0]
        if exc in (ConnectionResetError, BrokenPipeError, ConnectionAbortedError):
            return
        super().handle_error(request, client_address)


# ─────────────────────────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(
        description="2D 감정캐릭터 로컬 서버 + LLM API 프록시")
    ap.add_argument("--port", type=int, default=8787, help="포트 (기본 8787)")
    ap.add_argument("--key", default="", help="API 키 (없으면 OPENAI_API_KEY 환경변수)")
    ap.add_argument("--upstream", default=os.environ.get(
        "UPSTREAM", "https://api.openai.com/v1"),
        help="LLM 엔드포인트 (기본: OpenAI)")
    ap.add_argument("--no-browser", action="store_true", help="브라우저 자동 실행 안 함")
    args = ap.parse_args()

    Cfg.upstream = args.upstream
    Cfg.key = args.key or os.environ.get("OPENAI_API_KEY") or os.environ.get("API_KEY") or ""

    local_backend = "localhost" in Cfg.upstream or "127.0.0.1" in Cfg.upstream
    app = find_app()

    if app is None:
        print("\n  [!] 이 스크립트와 같은 폴더에 앱 HTML 파일이 있어야 합니다.")
        print("      현재 폴더: {}\n".format(BASE_DIR))
        sys.exit(1)

    if not Cfg.key and not local_backend:
        print("\n  [!] API 키가 없습니다. 앱은 켜지지만 데모 모드로만 동작합니다.")
        print('      OPENAI_API_KEY="sk-..." python3 run.py')
        print("      또는  python3 run.py --key sk-...\n")

    url = "http://localhost:{}/".format(args.port)
    masked = (Cfg.key[:7] + "..." + Cfg.key[-4:]) if len(Cfg.key) > 14 else (Cfg.key or "(없음)")

    print("")
    print("  ┌─ 2D 감정캐릭터 서버 ─────────────────────────────────")
    print("  │  앱      {}".format(url))
    print("  │  프록시  {}v1  →  {}".format(url, Cfg.upstream))
    print("  │  키      {}".format(masked))
    print("  │  파일    {}".format(app))
    print("  └──────────────────────────────────────────────────────")
    print("")
    print("  브라우저에서 위 주소를 열고 [설정] 탭에서")
    print("     Base URL : /v1")
    print("     API Key  : local")
    print("     Model    : gpt-4o-mini")
    print("  를 넣고 [연결 테스트]를 누르세요.")
    print("")
    print("  종료: Ctrl+C")
    print("")

    try:
        httpd = Server(("127.0.0.1", args.port), Handler)
    except OSError as e:
        print("  [!] 포트 {} 를 열 수 없습니다: {}".format(args.port, e))
        print("      다른 포트로:  python3 run.py --port 8899\n")
        sys.exit(1)

    if not args.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  종료합니다.\n")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
