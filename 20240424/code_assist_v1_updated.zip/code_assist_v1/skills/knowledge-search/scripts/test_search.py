"""
knowledge-search 검색 테스트 스크립트

사용법:
  python test_search.py "M14 CPU 컬럼"
  python test_search.py "급증"
  python test_search.py "디스크 사용률"
"""
import sys
import os

# app.py의 search_knowledge 함수를 직접 임포트하기 위해 경로 추가
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", ".."))

from app import search_knowledge

def test_search(query):
    print(f"\n{'='*60}")
    print(f"검색어: {query}")
    print(f"{'='*60}")

    results = search_knowledge(query, max_results=5)

    if not results:
        print("❌ 검색 결과 없음")
        return

    for i, r in enumerate(results, 1):
        print(f"\n[{i}] 📄 {r['filename']}  (점수: {r['score']})")
        print(f"    문서 길이: {r['content_length']}자")
        if r.get('preview'):
            for p in r['preview'][:2]:
                print(f"    미리보기: {p[:120]}")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        test_search(" ".join(sys.argv[1:]))
    else:
        # 기본 테스트 케이스
        tests = [
            "M14 컬럼",
            "CPU 사용률",
            "급증",
            "AMHS OHT",
            "허브룸 아키텍처",
            "디스크사용율",
            "M16A 스토리지",
            "접속정보",
        ]
        for q in tests:
            test_search(q)
