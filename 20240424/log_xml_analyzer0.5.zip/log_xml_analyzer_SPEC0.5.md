# 📊 로그 XML 태그 분석기 (log_xml_analyzer.html) 완전 스펙

> **목적**: 반도체 FAB MCS(Material Control System) 로그에서 XML 메시지를 자동 파싱·분류·검색·추출하는 단일 파일 웹 도구.
> 이 문서만 있으면 다른 LLM이나 개발자가 동일한 도구를 재구현할 수 있도록 상세 명세함.

---

## 1. 대상 로그 포맷

### 1.1 기본 라인 포맷 (Spring Boot 로거)

```
[2026-04-16 18:00:00,001] [ INFO] [quartzScheduler_Worker-2] [nexbe.mcs.custom.schedule.ProcessUsageJob.executeInternal] - [[ProcessUsageJob] will be invoked. ]
```

**구조**: `[timestamp] [ level] [threadId] [class] - [message]`

| 필드 | 포맷 | 주의사항 |
|---|---|---|
| timestamp | `YYYY-MM-DD HH:MM:SS,mmm` | 쉼표 구분자 (점 아님) |
| level | `INFO` / `WARN` / `ERROR` / `DEBUG` / `TRACE` | **좌측 공백 패딩** (`[ INFO]`, `[ WARN]`) |
| threadId | 예: `main`, `Tibrv Dispatcher`, `THREAD-ID=143`, `quartzScheduler_Worker-2` | **좌측 공백 패딩 있음** |
| class | Java FQCN + 메서드 (`.executeInternal`, `.onStart`, `.onEnd`) | 공백 없음 |
| message | `- [` 로 시작 `]` 로 끝남 | 멀티라인 가능 |

### 1.2 XML 임베드 포맷

```
[2026-04-16 18:00:06,681] [ INFO] [ Tibrv Dispatcher] [nexbe.mcs.core.communication.tibrv.TibrvDefaultListener.onMsg] - [
<?xml version="1.0" encoding="UTF-8"?>
<ApplicationControlMessage>
  <messageName>APS-CheckHeartBeat</messageName>
  <transactionId>20260416180006680981_MNS15</transactionId>
  ...
</ApplicationControlMessage>
]
```

로그 라인의 `message` 필드 안에 여러 줄에 걸친 XML 블록이 들어갈 수 있음. `[` 로 열고 `]` 로 닫음.

### 1.3 BPEL 워크플로우 포맷

```
[2026-04-16 18:00:06,682] [ INFO] [    THREAD-ID=143] [nexbe.mcs.core.workflow.WorkflowEventSubscriber.onStart] - [[7486] APS-CheckHeartBeat.bpel
<ApplicationControlMessage>...</ApplicationControlMessage>
]

[2026-04-16 18:00:06,682] [ INFO] [    THREAD-ID=143] [nexbe.mcs.core.workflow.WorkflowEventSubscriber.onEnd] - [[7486] APS-CheckHeartBeat.bpel elapsed=0ms]
```

- `[7486]` → BPEL 인스턴스 ID (추적 키)
- `APS-CheckHeartBeat.bpel` → BPEL 워크플로우 이름
- `elapsed=0ms` → 실행 소요 시간 (onEnd 라인에만)

### 1.4 관찰된 최상위 XML 태그 17종

```
ApplicationControlMessage   (하트비트/제어 메시지)
MESSAGE                      (범용 메시지 - HEADER/ORIGINATED/DATA 구조)
McsMessage                   (MCS 내부 메시지)
AlarmReportMessage           (알람 리포트)
AlarmDataMessage             (알람 데이터)
ClientMessage / ClientNotificationMessage  (클라이언트 UI 통신)
Envelop                      (외부 시스템 연동)
PortDataMessage, CarrierDataMessage, EquipmentDataMessageEx
TransferEvent, TransportJobStateMessage
EquipmentControlStateMessage, EquipmentStateMessage, EquipmentStatusDataMessageEx
EnhancedHostCommandSendMessageEx
```

### 1.5 messageName 두 형태 (매우 중요)

**케이스 A - 소문자** (`<ApplicationControlMessage>` 같은 태그):
```xml
<ApplicationControlMessage>
  <messageName>APS-CheckHeartBeat</messageName>   ← 최상위 직계 자식
  ...
  <originMessageName>APS-CheckHeartBeat</originMessageName>   ← 이건 제외!
</ApplicationControlMessage>
```

**케이스 B - 대문자** (`<MESSAGE>` 태그):
```xml
<MESSAGE>
  <HEADER>
    <MESSAGENAME>Rail-UnitAlarmCleared</MESSAGENAME>   ← HEADER 안 대문자
    <ORIGINMESSAGENAME>S6F11</ORIGINMESSAGENAME>        ← 이건 제외!
  </HEADER>
  <DATA>...</DATA>
</MESSAGE>
```

두 케이스 모두 "메시지 이름"을 의미. 둘 다 추출해야 하지만 `originMessageName` / `ORIGINMESSAGENAME` 는 제외해야 함.

### 1.6 실측 데이터 규모 (검증용 기준값)

| 파일 | 엔트리 | XML | messageName | BPEL |
|---|---|---|---|---|
| HIS01.2026-04-09-13.log | 12,100 | 5,149 | 4,031 | 3,810 |
| MNS05.2026-04-09-14.log | 28,671 | 5,053 | 4,786 | 3,080 |
| MNS05-26.04.09.132341-stdout.log | 59,463 | 10,179 | 9,586 | 6,380 |
| MNS15_2026-04-16-18.log | 5,900 | 1,624 | 1,614 | 1,130 |

---

## 2. 요구사항 (기능 명세)

### 2.1 필수 기능

| 기능 | 상세 |
|---|---|
| 파일 업로드 | 드래그앤드롭 + 클릭 선택, 다중 파일, `.log` / `.txt` |
| 로그 라인 파싱 | timestamp / level / threadId / class / message 추출 |
| 멀티라인 병합 | 헤더 없는 라인은 직전 엔트리의 message에 이어붙임 (스택트레이스 보존) |
| XML 태그 자동 감지 | message 안의 최상위 XML 블록 추출, 태그명 + 본문 저장 |
| XML → JSON 변환 | `<tag attr="v">text</tag>` → `{tag: {_attrs: {attr:"v"}, _text: "text"}}` |
| messageName 추출 | 소문자 `<messageName>` + 대문자 `<MESSAGENAME>` 둘 다, `originMessageName`류 제외 |
| BPEL 정보 추출 | `[인스턴스ID] 워크플로우이름.bpel` 패턴에서 `bpelId`, `bpelName`, `elapsedMs` 추출 |
| 태그 통계 | XML 태그별 빈도 + 시각화 바 |
| messageName 통계 | messageName별 빈도 + 시각화 바, 선택된 XML 태그 기준 교차필터 |
| 필터링 | 검색 / 레벨 / XML 유무 / 태그 선택 / messageName 선택 |
| 상세 뷰어 | JSON (syntax highlight) / XML 원본 / 전체 로그 / 메타정보 |
| 내보내기 | 전체 JSON, 전체 CSV |
| 문자 파싱기 (별도) | 복합 조건 조회 모달 + 3가지 뷰 + 복사/TXT/CSV 내보내기 |
| **JSON → 조건 변환 (양방향)** | **JSON 한 건 붙여넣기 → 비슷한 메시지 자동 검색 조건 생성. 정규식 모드 지원** |

### 2.2 성능 요구

- 10만 엔트리 (~40MB) 파싱 3초 이내
- 검색창 입력 시 UI 렉 없음 (debounce 필수)
- 결과 테이블은 페이지네이션 필수 (대량 결과에서 DOM 폭발 방지)

### 2.3 환경 제약

- **단일 HTML 파일** (외부 의존 없음, 폐쇄망 환경 지원)
- Chrome / Edge 최신 버전 기준
- 서버 없이 브라우저에서만 동작 (로그 데이터가 외부로 나가지 않음)

---

## 3. 파서 로직 명세 (JavaScript)

### 3.1 정규식 (핵심)

```javascript
// 로그 라인 헤더 - 좌측 공백 패딩 허용 ([ INFO], [    main])
const LOG_LINE_RE = /^\[([^\]]+)\]\s*\[\s*(\w+)\s*\]\s*\[\s*([^\]]*?)\s*\]\s*\[([^\]]+)\]\s*-\s*(.*)$/;

// messageName 추출 - 대소문자 둘 다, originMessageName 방어 (단어 경계)
const MESSAGE_NAME_LOWER = /<messageName(\s[^>]*)?>([^<]*)<\/messageName\s*>/;
const MESSAGE_NAME_UPPER = /<MESSAGENAME(\s[^>]*)?>([^<]*)<\/MESSAGENAME\s*>/;

// BPEL 패턴
const BPEL_RE = /^\[(\d+)\]\s+([\w-]+)\.bpel/;
const ELAPSED_RE = /\belapsed=(\d+)\s*ms\b/;

// XML 최상위 태그 시작 감지
const XML_OPEN_RE = /<([A-Za-z][A-Za-z0-9_\-]*)(\s|>|\/)/;
```

### 3.2 파싱 순서

1. 파일 텍스트를 `split(/\r?\n/)` 로 라인 분할 (CRLF/LF 혼재 대응)
2. 각 라인에 대해 `LOG_LINE_RE` 매칭 시도
3. 매칭되면 새 엔트리 시작, 이전 엔트리는 `finalizeEntry()` 호출 후 확정
4. 매칭 안 되면 현재 엔트리의 message에 줄바꿈으로 이어붙임 (멀티라인 지원)
5. 마지막 엔트리도 `finalizeEntry()` 호출

### 3.3 finalizeEntry 처리 (중요 - 순서 보존)

```javascript
function finalizeEntry(entry) {
  // (1) 바깥 [ ] 벗기기 - Spring Boot 로거 포맷
  if (entry.message) {
    const m = entry.message;
    if (/^\s*\[/.test(m) && /\]\s*$/.test(m)) {
      const s = m.indexOf('[');
      const e = m.lastIndexOf(']');
      if (s !== -1 && e > s) entry.message = m.slice(s + 1, e).trim();
    }
  }

  // (2) BPEL 정보 추출 (XML 추출 전에)
  if (entry.message) {
    const bpelMatch = entry.message.match(/^\[(\d+)\]\s+([\w-]+)\.bpel/);
    if (bpelMatch) {
      entry.bpelId = bpelMatch[1];
      entry.bpelName = bpelMatch[2];
    }
    const elapMatch = entry.message.match(/\belapsed=(\d+)\s*ms\b/);
    if (elapMatch) entry.elapsedMs = parseInt(elapMatch[1], 10);
  }

  // (3) XML 블록 추출
  const xml = extractXml(entry.message);
  if (xml) {
    entry.xmlTag = xml.tag;
    entry.xmlContent = xml.content;
    entry.messageName = extractMessageName(xml.content);
    try {
      entry.jsonContent = xmlToJson(xml.content);
    } catch (e) {
      entry.jsonContent = { _parseError: e.message };
    }
  }
}
```

### 3.4 XML 블록 추출 (extractXml)

**알고리즘**:
1. `<?xml version="1.0"?>` 선언이 있으면 제거
2. 첫 `<TagName>` 매칭 찾기 (`[A-Za-z][A-Za-z0-9_\-]*`)
3. 같은 이름의 여는/닫는 태그를 **depth 카운트**로 매칭 (중첩 동일 태그 방어)
4. self-closing `<Tag/>` 는 별도 처리
5. 반환: `{ tag: "TagName", content: "<TagName>...</TagName>" }`

```javascript
function extractXml(message) {
  let text = message.replace(/<\?xml[^?]*\?>/g, '');
  const m = text.match(/<([A-Za-z][A-Za-z0-9_\-]*)(\s|>|\/)/);
  if (!m) return null;
  const tagName = m[1];
  const tagStart = text.indexOf(m[0]);

  // self-closing 체크
  const selfClosingRe = new RegExp(`<${tagName}[^>]*\\/>`);
  const scMatch = text.slice(tagStart).match(selfClosingRe);
  if (scMatch && scMatch.index === 0) {
    return { tag: tagName, content: scMatch[0] };
  }

  // depth 카운트로 닫는 태그 매칭
  const openRe = new RegExp(`<${tagName}(\\s[^>]*)?>`, 'g');
  const closeRe = new RegExp(`</${tagName}\\s*>`, 'g');
  let depth = 0, scanPos = tagStart;
  while (scanPos < text.length) {
    openRe.lastIndex = scanPos;
    closeRe.lastIndex = scanPos;
    const oM = openRe.exec(text), cM = closeRe.exec(text);
    if (!cM) return null;
    if (oM && oM.index < cM.index) {
      depth++; scanPos = oM.index + oM[0].length;
    } else {
      depth--; scanPos = cM.index + cM[0].length;
      if (depth === 0) return { tag: tagName, content: text.slice(tagStart, cM.index + cM[0].length) };
    }
  }
  return null;
}
```

### 3.5 messageName 추출

```javascript
function extractMessageName(xmlContent) {
  // 소문자 시도 먼저
  const mLower = xmlContent.match(/<messageName(\s[^>]*)?>([^<]*)<\/messageName\s*>/);
  if (mLower) {
    const txt = decodeEntities(mLower[2]).trim();
    if (txt) return txt;
  }
  // 대문자 시도
  const mUpper = xmlContent.match(/<MESSAGENAME(\s[^>]*)?>([^<]*)<\/MESSAGENAME\s*>/);
  if (mUpper) {
    const txt = decodeEntities(mUpper[2]).trim();
    if (txt) return txt;
  }
  return null;
}
```

**왜 대소문자 구분하나?**: `<messageName>` (소문자) 와 `<MESSAGENAME>` (대문자) 는 각각 다른 XML 스키마의 태그. 대소문자 무시로 매칭하면 `<originMessageName>` / `<ORIGINMESSAGENAME>` 같은 유사 태그가 혼입될 수 있어 위험. 명시적으로 두 케이스만 허용.

### 3.6 XML → JSON 변환기

자체 구현 (외부 라이브러리 불가). 규칙:

| XML | JSON |
|---|---|
| `<tag>value</tag>` | `{tag: "value"}` |
| `<tag attr="v">text</tag>` | `{tag: {_attrs: {attr: "v"}, _text: "text"}}` |
| `<parent><child>v</child></parent>` | `{parent: {child: "v"}}` |
| 동일 이름 반복 요소 | 배열로 `{items: [...]}`
| `<tag/>` | `{tag: ""}` |
| `<tag>123</tag>` | `{tag: 123}` (15자리 이상은 문자열 유지) |
| `<tag>true</tag>` | `{tag: true}` |
| CDATA | `_text` 값에 포함 |
| 엔티티 (`&lt;`, `&amp;` 등) | 디코딩 후 값에 저장 |

**숫자 변환 (coerceScalar) 주의**:
```javascript
function coerceScalar(s) {
  if (s === 'true') return true;
  if (s === 'false') return false;
  if (/^-?\d+$/.test(s)) {
    if (s.length > 15) return s;  // JS Number 정밀도 한계 → 문자열 유지
    return parseInt(s, 10);
  }
  if (/^-?\d+\.\d+$/.test(s)) return parseFloat(s);
  return s;
}
```
실제 `transactionId`가 20자리 (`20260416180006680981`) 이므로 문자열 보존 필수. 그렇지 않으면 뒷자리 손실.

### 3.7 엔티티 디코딩

```javascript
function decodeEntities(s) {
  return s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')
          .replace(/&quot;/g, '"').replace(/&apos;/g, "'")
          .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(parseInt(n, 10)))
          .replace(/&#x([0-9a-fA-F]+);/g, (_, n) => String.fromCharCode(parseInt(n, 16)));
}
```

---

## 4. UI 레이아웃

### 4.1 전체 구조

```
┌─────────────────────────────────────────────────────────────────────┐
│ 📊 로그 XML 태그 분석기    [📁 파일선택] [🔎 문자파싱기] [⬇JSON] [⬇CSV] [🗑] │
├─────────────────────┬───────────────────────────────────────────────┤
│ 📑 XML 태그 (flex:1)│  전체 N · XML N · 태그 N · msgName N · BPEL N ·  │
│                     │  평균 X.Xms                                    │
│ 선택: 전체  [초기화] ├───────────────────────────────────────────────┤
│ ○ 전체         N    │ [🔍 검색] [레벨▼] [XML유무▼]                    │
│ ● Tag1    ■■■ N    ├───────────────────────────────────────────────┤
│ ● Tag2    ■■ N     │ 시간 │ 레벨 │ Thread │ XML태그 │ msgName │ BPEL │ 미리보기 │
│ ...                 │ ...                                           │
├─────────────────────┤ [이전] 1 / N [다음]   N 건 중 1-100            │
│ 📝 messageName      ├───────────────────────────────────────────────┤
│ (flex:1)            │ [JSON] [XML원본] [전체로그] [메타정보]          │
│ 선택: 전체  [초기화] │  {                                             │
│ ○ 전체         N    │    "tag": {...}                               │
│ ● Name1   ■■■ N    │  }                                             │
│ ● Name2   ■■ N     │                                                │
└─────────────────────┴───────────────────────────────────────────────┘

문자 파싱기 버튼 클릭 → 모달 팝업 (별도 UI)
```

### 4.2 사이드바 (320px 고정 폭)

- **상단**: XML 태그 통계 (flex:1)
  - 태그 이름, 건수, 막대 비율
  - 클릭 → 해당 태그로 필터
  - 태그별 자동 색상 (해시 기반)

- **하단**: messageName 통계 (flex:1)
  - 선택된 XML 태그 기준으로 교차 필터됨
  - 예: "ApplicationControlMessage" 선택 시 → 해당 태그에 속한 messageName 만 표시

### 4.3 상단 미니 통계 바

```
전체 5,900 | XML 포함 1,624 | 태그 종류 7 | 메시지명 1,614 | BPEL 1,130 | 평균 0.9ms
```

### 4.4 로그 테이블 컬럼

| 컬럼 | 너비 | 내용 |
|---|---|---|
| 시간 | 160px | 타임스탬프 (mono font) |
| 레벨 | 60px | 레벨 chip (색상 구분: INFO 파랑 / WARN 노랑 / ERROR 빨강) |
| Thread | 60px | threadId |
| XML 태그 | 150px | 태그별 색상 chip |
| messageName | 170px | messageName 색상 chip |
| BPEL | 130px | `#7486 0ms` (0ms 초록 / 10ms+ 주황 / 100ms+ 빨강) |
| 미리보기 | 남은 공간 | message 첫 200자 |

페이지네이션: 100행/페이지

### 4.5 상세 뷰어 (하단, 38% 높이)

4개 탭:
- **JSON** - syntax highlight (key/string/number/boolean/null 색상 분리)
- **XML 원본** - 들여쓰기 포맷 + 태그/속성/값 색상
- **전체 로그** - rawLog 그대로
- **메타정보** - timestamp/level/threadId/class/xmlTag/messageName/bpelId/bpelName/elapsedMs/srcFile/lineNo 을 JSON 형태로

---

## 5. 문자 파싱기 (핵심 도구, 모달)

### 5.0 모달 구현 핵심 패턴 (반드시 이대로)

```html
<!-- ✅ 올바른 모달 구조 -->
<div class="modal-overlay" id="parser-modal"
     onclick="if(event.target===this) closeParserModal()">
  <div class="modal">
    <!-- 모달 본체. stopPropagation() 쓰지 말 것 -->
  </div>
</div>
```

```javascript
// ✅ 올바른 keydown 핸들러
document.addEventListener('keydown', (e) => {
  if (!$('parser-modal').classList.contains('open')) return;

  if (e.key === 'Escape') {
    closeParserModal();
    return;
  }

  // Enter: input 포커스 + IME 조합 중 아닐 때만
  if (e.key === 'Enter' && !e.isComposing) {
    const t = document.activeElement;
    if (t && t.classList && t.classList.contains('query-input')) {
      e.preventDefault();
      runParser();
    }
  }

  // Backspace: input/textarea 밖에서 누르면 차단 (브라우저 뒤로가기 방지)
  if (e.key === 'Backspace') {
    const t = e.target;
    const tag = t && t.tagName;
    const isEditable = tag === 'INPUT' || tag === 'TEXTAREA' || (t && t.isContentEditable);
    if (!isEditable) e.preventDefault();
  }
});
```

**❌ 절대 하지 말 것**:
- 모달 본체에 `onclick="event.stopPropagation()"` (입력 이벤트와 충돌, backspace 시 모달 닫힘)
- 오버레이에 `onclick="closeModal()"` (target 체크 없이 무조건 닫음)
- Enter 핸들러에 `e.isComposing` 체크 누락 (한글 입력 중 Enter 시 오작동)
- input 에서 backspace 가 페이지 뒤로 가게 만들기 (옛 브라우저 호환성)

### 5.1 레이아웃 (좌 360px 조건 / 우 나머지 결과)

```
┌──────────────────────────────────────────────────────────┐
│ 🔎 문자 파싱기 - 조회 조건으로 추출                    [✕] │
├────────────────────┬─────────────────────────────────────┤
│ 조회 조건          │ 조회결과: N 건 / 전체 M [조건요약...] │
│                    │ [📊요약표][📄XML만][📋원본] [복사][TXT][CSV] │
│ 📝 messageName     ├─────────────────────────────────────┤
│ [          ]       │                                     │
│                    │                                     │
│ 📑 XML 태그        │          결과 테이블/뷰              │
│ [          ]       │                                     │
│                    │                                     │
│ ⚙️ BPEL 이름       │                                     │
│ [          ]       │                                     │
│                    │                                     │
│ ⏱ 최소 실행시간    │                                     │
│ [    ]             │                                     │
│                    │                                     │
│ ⏰ 시간 범위       │                                     │
│ [start]~[end]      │                                     │
│                    │                                     │
│ 🚦 레벨            │                                     │
│ [I][W][E][D][T]    │                                     │
│                    │                                     │
│ 🔍 자유 텍스트     │                                     │
│ [          ]       │                                     │
│                    │                                     │
│ 🧪 정규식          │                                     │
│ [          ]       │                                     │
│ (에러 메시지)      │                                     │
│                    │ (페이지네이션 200행/페이지)          │
│ [조회실행][초기화] │                                     │
└────────────────────┴─────────────────────────────────────┘
```

### 5.2 조회 조건 8가지

| 조건 | 매칭 방식 | 비고 |
|---|---|---|
| messageName | 공백 구분 **OR** 부분일치 (대소문자 무시) | `"APS MNS-Alarm"` → 둘 중 하나 포함 |
| XML 태그 | 공백 구분 OR 부분일치 | 동일 |
| BPEL 이름 | 공백 구분 OR 부분일치 | 동일 |
| 최소 실행시간 | `e.elapsedMs >= N` | 빈칸=전체, 숫자 아니면 에러 |
| 시간 범위 | `HH:MM` 또는 `HH:MM:SS[.mmm]` 허용 | 범위 검증 (시 0-23, 분초 0-59) |
| 레벨 | 다중 선택 칩 | 미선택=전체 |
| 자유 텍스트 | 공백 구분 **AND** (전체 로그에서) | 모두 포함 |
| 정규식 | RegExp 매칭 (case-insensitive) | 전체 로그 대상 |

**모든 조건은 AND 로 결합**됨. 조건을 1개 이상 입력해야 실행 가능 (아무것도 없이 실행하면 전체 반환 → 렌더 폭발 방지).

### 5.3 결과 표시 3가지 모드

- **📊 요약표**: 메인 테이블과 동일한 컬럼 (페이지네이션 200행)
- **📄 XML만**: 각 엔트리의 `xmlContent`를 구분자로 구분해서 표시
- **📋 원본**: `rawLog` 전체 (로그 파일 원본 그대로)

### 5.4 내보내기 3가지

- **📋 복사**: 현재 뷰 모드 기준 TXT 를 클립보드로 (전체, 페이지 상관없이)
- **⬇ TXT**: 파일 다운로드 (`log_parsed_{mode}_{timestamp}.txt`)
- **⬇ CSV**: 항상 표 형식 CSV, UTF-8 BOM 포함 (엑셀 한글 깨짐 방지)

### 5.5 UX 편의

- `Enter` 키: 조회 실행 (**단, 한글 IME 조합 중에는 발동 안 함** - `e.isComposing` 체크)
- `ESC` 키: 모달 닫기
- 모달 밖 (오버레이 회색 배경) 클릭: 닫기
- **모달 본체나 input 클릭 시 절대 닫히지 않음** (오버레이 onclick 에서 `event.target===this` 체크)
- **모달 열린 상태에서 input 밖 backspace → 브라우저 뒤로 가기 차단**
- 토스트 알림 (성공: 초록, 에러: 빨강, 경고: 주황)

### 5.6 JSON → 조건 자동 추출 (양방향 핵심 기능)

조회 결과의 JSON 한 건을 가지고 **"비슷한 메시지 다 찾기"** 를 자동화하는 양방향 도구. 좌측 조건 패널 맨 위 초록색 섹션에 통합됨 (접이식 토글).

#### 5.6.1 동작 흐름

```
1. JSON 붙여넣기 (예: 조회 결과 한 건의 jsonContent)
   ↓
2. 0.3초 후 자동 분석 (debounce)
   ↓
3. 추출된 필드 목록 표시 (체크박스 + 매핑 정보 + unique 뱃지)
   ↓
4. 사용자가 체크 조정 (필요 시)
   ↓
5. [✓ 선택 항목 → 조건 적용] 클릭
   ↓
6. 좌측 조건 칸들에 자동 입력 (적용 전 깨끗이 비우고 시작)
   ↓
7. [🔎 조회 실행] → 비슷한 메시지 모두 매칭
```

#### 5.6.2 입력 JSON 구조 가정

```json
{
  "ApplicationControlMessage": {        ← 최상위 1개 키 = XML 태그명
    "messageName": "APS-CheckHeartBeat",
    "transactionId": "20260416180006680981_MNS15",
    "applicationId": "MNS15",
    "correlationId": "7b4bf3ac-...",
    "eventUser": "APS02",
    "returnCode": "",                    ← 빈 값 자동 제외
    "secsLogData": ""                    ← 빈 값 자동 제외
  }
}
```

규칙:
- 최상위 키가 1개이고 값이 객체면 → XML 태그명으로 자동 추출
- 빈 문자열, null, 객체 값은 제외 (단순 값만)

#### 5.6.3 필드 매핑 규칙 (FIELD_TO_QUERY_MAP)

| JSON 필드 | → 조건 칸 | 기본 체크 | unique |
|---|---|---|---|
| `messageName` | 📝 messageName | ✅ | - |
| `bpelName` | ⚙️ BPEL 이름 | ✅ | - |
| `elapsed*` | ⏱ 실행시간 | ⬜ | - |
| `applicationId` | 🔍 자유텍스트 | ⬜ | - |
| `transactionId` | 🔍 자유텍스트 | ⬜ | ⚠️ unique |
| `equipmentId` | 🔍 자유텍스트 | ⬜ | - |
| `correlationId` | 🔍 자유텍스트 | ⬜ | ⚠️ unique |
| `carrierId` | 🔍 자유텍스트 | ⬜ | - |
| `alarmId` | 🔍 자유텍스트 | ⬜ | - |
| `eventUser` | 🔍 자유텍스트 | ⬜ | - |
| `originAddress` | 🔍 자유텍스트 | ⬜ | - |
| 그 외 | (미매핑) | ⬜ disabled | - |

**핵심 정책**: 기본 체크는 **메시지 종류 식별 필드만** (xmlTag, messageName, bpelName). 나머지 식별자는 사용자가 명시적으로 선택해야 함. 이유는 모든 필드를 자동 체크하면 매번 다른 식별자(`transactionId` 등)가 들어가서 "그 1건만" 매칭되는 함정에 빠짐.

#### 5.6.4 unique 뱃지

매번 다른 식별자는 빨간색 `unique` 뱃지로 표시. 체크하면 거의 1건만 매칭됨을 사용자에게 경고:
- `transactionId` (예: `20260416180006680981_MNS15`)
- `correlationId` (UUID)

#### 5.6.5 정규식 모드

`☑ 정규식으로 변환` 체크 후 적용 → 체크된 모든 필드를 정규식 패턴으로 합쳐 🧪 정규식 칸에 입력:

```
체크된 필드:
  messageName = APS-CheckHeartBeat
  applicationId = MNS15

생성된 정규식:
  <messageName>APS-CheckHeartBeat</messageName>.*<applicationId>MNS15</applicationId>
```

특수문자 자동 이스케이프 (`regexEscape`).

#### 5.6.6 자유 텍스트 합치기

여러 필드가 같은 `q-text` (자유 텍스트) 칸을 타겟으로 하면 공백으로 연결. 단, 자유 텍스트는 **AND 검색**이라 너무 많이 합치면 매칭 0건이 될 수 있음. 권장: 최대 1-2개.

#### 5.6.7 안내 메시지

추출 결과 상단에 노란 박스로 표시:
```
💡 같은 종류 메시지 잡기: XML 태그 + messageName 만 체크된 상태로 적용 → 비슷한 모든 메시지
⚠️ unique 표시 필드는 매번 다른 식별자라 체크하면 그 1건만 매칭됨
```

#### 5.6.8 적용 전 칸 초기화 (중요)

`[선택 항목 → 조건 적용]` 클릭 시 **모든 조건 칸을 먼저 비움** 후 새 값 채움. 이유:
- 이전에 적용했다가 일부 칸 수정하지 않은 값이 남아있으면 결과 0건 가능
- 깨끗한 상태에서 시작 → 사용자 의도대로 동작 보장

#### 5.6.9 구현 코드 (전체)

```javascript
const FIELD_TO_QUERY_MAP = [
  // [정규식, 타겟 input id, 라벨, defaultChecked, unique]
  [/^messagename$/i,   'q-msgname',  'messageName',                true,  false],
  [/^bpelname$/i,      'q-bpel',     'BPEL 이름',                   true,  false],
  [/^elapsed/i,        'q-elapsed',  '실행시간',                    false, false],
  [/^applicationid$/i, 'q-text',     '자유텍스트 (applicationId)',  false, false],
  [/^transactionid$/i, 'q-text',     '자유텍스트 (transactionId)',  false, true],
  [/^equipmentid$/i,   'q-text',     '자유텍스트 (equipmentId)',    false, false],
  [/^correlationid$/i, 'q-text',     '자유텍스트 (correlationId)',  false, true],
  [/^carrierid$/i,     'q-text',     '자유텍스트 (carrierId)',      false, false],
  [/^alarmid$/i,       'q-text',     '자유텍스트 (alarmId)',        false, false],
  [/^eventuser$/i,     'q-text',     '자유텍스트 (eventUser)',      false, false],
  [/^originaddress$/i, 'q-text',     '자유텍스트 (originAddress)',  false, false],
];

function findXmlTagKey(obj) {
  if (!obj || typeof obj !== 'object') return null;
  const keys = Object.keys(obj);
  if (keys.length === 1 && typeof obj[keys[0]] === 'object' && obj[keys[0]] !== null) {
    return keys[0];
  }
  return null;
}

function regexEscape(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function analyzeJson2Query() {
  const raw = $('q-jsoninput').value.trim();
  if (!raw) { /* 빈 입력 처리 */ return; }

  let obj;
  try { obj = JSON.parse(raw); }
  catch (e) { /* 에러 표시 */ return; }

  const xmlTag = findXmlTagKey(obj);
  const inner = xmlTag ? obj[xmlTag] : obj;

  const fields = [];
  if (xmlTag) {
    fields.push({
      key: '_xmlTag', label: 'XML 태그', value: xmlTag,
      target: 'q-xmltag', targetLabel: 'XML 태그',
      unique: false, checked: true,
    });
  }

  for (const [k, v] of Object.entries(inner || {})) {
    if (v === null || v === '' || v === undefined) continue;
    if (typeof v === 'object') continue;

    let target = null, targetLabel = '(미매핑)', defChecked = false, unique = false;
    for (const [pattern, tgt, lbl, dc, uq] of FIELD_TO_QUERY_MAP) {
      if (pattern.test(k)) {
        target = tgt; targetLabel = lbl; defChecked = dc; unique = uq;
        break;
      }
    }
    fields.push({
      key: k, label: k, value: String(v),
      target, targetLabel, unique, checked: defChecked,
    });
  }
  json2qState.extracted = fields;
  renderJson2QueryFields();
}

function applyJson2Query() {
  const checked = json2qState.extracted.filter(f => f.checked && f.target);
  if (checked.length === 0) return;

  // 적용 전 모든 칸 비우기 (중요)
  ['q-msgname', 'q-xmltag', 'q-bpel', 'q-elapsed', 'q-text', 'q-regex'].forEach(id => {
    if ($(id)) $(id).value = '';
  });

  const asRegex = $('q-as-regex').checked;
  if (asRegex) {
    const patterns = checked
      .filter(f => f.key !== '_xmlTag')
      .map(f => `<${regexEscape(f.key)}>${regexEscape(f.value)}</${regexEscape(f.key)}>`);
    if (patterns.length > 0) $('q-regex').value = patterns.join('.*');
    const xmlTagField = checked.find(f => f.key === '_xmlTag');
    if (xmlTagField) $('q-xmltag').value = xmlTagField.value;
  } else {
    const byTarget = {};
    for (const f of checked) {
      (byTarget[f.target] = byTarget[f.target] || []).push(f);
    }
    let textParts = [];
    for (const [target, fields] of Object.entries(byTarget)) {
      if (target === 'q-text') textParts.push(...fields.map(f => f.value));
      else $(target).value = fields[0].value;
    }
    if (textParts.length > 0) $('q-text').value = textParts.join(' ');
  }
}
```

#### 5.6.10 검증 시나리오

| 입력 JSON | 예상 결과 |
|---|---|
| `ApplicationControlMessage { messageName: "APS-CheckHeartBeat", ... }` 적용 | XML 태그 + messageName 만 입력됨, 조회 시 **1,302건** (MNS15 기준) |
| 여기에 `transactionId` 체크 후 적용 | transactionId 도 자유텍스트에 추가, 조회 시 **1건** (그 메시지 1건만) |
| 정규식 모드 체크 후 적용 | `<messageName>APS-CheckHeartBeat</messageName>` 정규식 생성, 조회 시 1,302건 |

---

## 6. 알려진 함정 및 방어 (중요)

이 도구 만들 때 **실제로 겪은 버그**들. 다시 만들 때 같은 함정 피하도록:

### 6.1 로그 파싱 관련

| 함정 | 올바른 처리 |
|---|---|
| 레벨 `[ INFO]` 좌측 공백 | 정규식 `\[\s*(\w+)\s*\]` 로 공백 허용 |
| CRLF / LF 혼재 | `split(/\r?\n/)` |
| 긴 `transactionId` (20자리) | 숫자 변환 시 15자리 이상은 문자열 유지 |
| 멀티라인 메시지 (스택 트레이스) | 헤더 없는 라인은 직전 엔트리에 병합 |
| `<messageName>` vs `<MESSAGENAME>` | 둘 다 추출, 단 `<originMessageName>` 제외 (단어 경계) |
| 바깥 `[` `]` 대괄호 | Spring Boot 로거 규칙, 벗기되 스택트레이스처럼 `]` 로 안 끝나면 건드리지 말 것 |

### 6.2 UI 관련

| 함정 | 방어 |
|---|---|
| 같은 파일 2번 드롭 → 중복 누적 | 파일명 Set 으로 중복 체크, 스킵 시 토스트 |
| 로딩 중 재진입 race | `state._loading` 플래그로 가드 |
| 검색창 매 키 입력 → 10만행 전체 스캔 렉 | 250ms debounce |
| 빈 조건 조회 → 전체 렌더 폭발 | 최소 1개 조건 필수 검증 |
| 결과 대량 → 테이블 DOM 폭발 | 페이지네이션 200행 |
| 악성 정규식 `(a+)+` → 브라우저 얼음 | 중첩 수량자 패턴 감지해서 차단 |
| 한글 IME 조합 중 Enter → 원치 않는 조회 | `e.isComposing` 체크 |
| 시간 `25:00:00` 정상 취급됨 | 범위 검증 (시 0-23, 분초 0-59) |
| 시간 `18:00` (초 생략) → null 로 무시 | `HH:MM` 도 허용하도록 정규식 수정 |
| elapsed 에 `abc` 입력 조용히 무시 | 숫자 아니면 에러 토스트 |
| `indexOf(e)` O(n) - 10만행 느림 | 파싱 직후 `_idx` 부여 |
| **모달 오버레이의 `onclick="closeModal()"` → 입력칸에서 backspace 등 누를 때 click 이벤트가 상위로 버블링되어 모달이 닫힘** | **오버레이 자신이 click target 일 때만 닫도록: `onclick="if(event.target===this) closeModal()"`. `stopPropagation()` 보다 안전.** |
| **모달 열린 상태에서 input/textarea 밖 backspace → 브라우저 뒤로 가기 발동 가능** | **`keydown` 핸들러에서 `e.target.tagName !== 'INPUT'/'TEXTAREA'` 면 `preventDefault()`** |
| **JSON→조건 변환에서 모든 필드 자동 체크 → `transactionId` 같은 고유 식별자가 들어가서 1건만 매칭됨 (사용자는 "비슷한 메시지 다 찾기" 의도였음)** | **기본 체크는 `xmlTag` + `messageName` + `bpelName` 만. 나머지는 미체크로 두고 사용자가 명시적으로 선택. `unique` 플래그 필드는 빨간 뱃지로 경고 표시** |
| **JSON→조건 적용 시 이전에 잘못 들어간 값이 남아있어 결과 0건** | **적용 직전에 모든 조건 칸 비우고 시작 (clean slate)** |

### 6.3 JSON 변환 관련

| 함정 | 처리 |
|---|---|
| `<tag />` self-closing | 빈 문자열 반환 |
| 동일 이름 형제 요소 | 배열로 변환 |
| `&amp;` 이중 이스케이프 | 디코딩 후 저장 (다시 esc 하지 않도록 주의) |
| `<?xml?>` 선언 | extractXml 에서 미리 제거 |

---

## 7. 파일 구조

**단일 HTML 파일 하나. 외부 의존 없음.**

```
log_xml_analyzer.html
├── <style>            순수 CSS (~350 lines)
├── <body>
│   ├── 헤더 (타이틀 + 버튼)
│   ├── 드롭존 (초기 화면)
│   ├── 메인 (사이드바 + 콘텐츠)
│   ├── 문자 파싱기 모달
│   └── 토스트 컨테이너
└── <script>           순수 Vanilla JS (~800 lines)
    ├── 파서 (LOG_LINE_RE, extractXml, xmlToJson, ...)
    ├── 상태 관리 (state, parserState)
    ├── 렌더링 (render, renderParserResult, renderViewer)
    ├── 이벤트 (파일 드롭, 모달, 검색)
    └── 내보내기 (JSON, CSV, TXT, 클립보드)
```

총 ~1500 lines, 단일 파일.

---

## 8. 검증 체크리스트

구현 완료 후 다음 항목들이 모두 통과하는지 확인:

### 8.1 파서 정확도 (실측 데이터 기준)

- [ ] MNS15_2026-04-16-18.log (2.55MB) → 엔트리 정확히 **5,900건**
- [ ] 같은 파일 XML 포함 **1,624건**
- [ ] 같은 파일 messageName 추출 **1,614건**
- [ ] 같은 파일 BPEL 추출 **1,130건**
- [ ] 같은 파일 elapsed 추출 **565건**
- [ ] JSON 변환 실패 0건
- [ ] `transactionId` 20자리가 문자열로 원본 그대로 보존

### 8.2 messageName 정확성

- [ ] `<ApplicationControlMessage>` 의 소문자 `<messageName>` 추출됨
- [ ] `<MESSAGE>` 의 대문자 `<MESSAGENAME>` 추출됨 (HEADER 안)
- [ ] `<originMessageName>APS-CheckHeartBeat</originMessageName>` 값은 messageName 에 **안 들어감**
- [ ] `<ORIGINMESSAGENAME>S6F11</ORIGINMESSAGENAME>` 값은 messageName 에 **안 들어감**

### 8.3 BPEL 교차 검증

grep 으로 원본 파일 카운트와 일치해야:
```bash
grep -cE "\[[0-9]+\] [A-Za-z-]+\.bpel" file.log   # BPEL 접두사 건수
grep -c "elapsed=" file.log                       # elapsed 건수
```

### 8.4 UI 동작

- [ ] 파일 드래그앤드롭 → 자동 파싱 → 사이드바 + 테이블 표시
- [ ] 사이드바 태그 클릭 → 해당 태그로 필터, messageName 섹션도 교차 필터
- [ ] 테이블 행 클릭 → 하단 뷰어에 JSON / XML / 전체 / 메타 표시
- [ ] 같은 파일 2번 드롭 → 중복 경고, 누적 안 됨
- [ ] 검색창 빠른 타이핑 → 렉 없음 (debounce 동작)
- [ ] 10만 엔트리 로드 → 테이블 페이지네이션 100행 정상
- [ ] JSON / CSV 다운로드 (UTF-8 BOM) → 엑셀에서 한글 깨짐 없음

### 8.5 문자 파싱기 동작

- [ ] 빈 조건 조회 → 빨간 토스트 "최소 1개 조건 필요"
- [ ] 시간 `25:00:00` 입력 → 빨간 토스트
- [ ] elapsed `abc` 입력 → 빨간 토스트
- [ ] 정규식 `(a+)+` 입력 → "성능 문제 가능 패턴" 경고, 실행 안 함
- [ ] 한글 입력 중 Enter (IME 조합) → 조회 실행 안 됨
- [ ] **input 칸에서 backspace 로 글자 지움 → 모달 닫히지 않음** (이전 버그)
- [ ] **모달 본체 안 어디든 클릭해도 닫히지 않음** (오버레이만 닫음)
- [ ] **모달 열린 상태에서 input 밖 backspace → 브라우저 뒤로 가기 안 됨**
- [ ] 결과 2만건 → 페이지네이션 200행/페이지
- [ ] 복사/다운로드는 **전체** (페이지 상관없이)
- [ ] 조건 요약이 결과 상단에 칩으로 표시
- [ ] ESC 키 → 모달 닫힘

### 8.6 JSON → 조건 변환 동작

- [ ] JSON 붙여넣기 → 0.3초 후 자동 분석 (debounce)
- [ ] 잘못된 JSON → "JSON 파싱 오류" 빨간 메시지
- [ ] 최상위 1개 키 + 객체 값 → 그 키가 XML 태그명으로 자동 추출
- [ ] 빈 문자열, null, 객체 값은 추출 목록에서 자동 제외
- [ ] **기본 체크는 `xmlTag` + `messageName` + `bpelName` 만** (나머지 미체크)
- [ ] `transactionId`, `correlationId` 옆에 빨간 `unique` 뱃지
- [ ] 안내 메시지 노란 박스 표시 ("같은 종류 메시지 잡기" / "unique 경고")
- [ ] 미매핑 필드는 체크박스 disabled (선택 불가)
- [ ] **[조건 적용] → 적용 전 모든 조건 칸 자동 초기화**
- [ ] 정규식 모드 체크 → `<필드>값</필드>.*<필드>값</필드>` 패턴 자동 생성
- [ ] 정규식 특수문자 자동 이스케이프 (`regexEscape`)
- [ ] 자유 텍스트는 여러 값 공백으로 연결 (AND 검색)
- [ ] 사용자 JSON (`ApplicationControlMessage`) 적용 → MNS15 파일 기준 **1,302건 매칭** (XML 태그 + messageName 만)
- [ ] 같은 JSON 에 `transactionId` 추가 체크 후 적용 → **1건만 매칭** (정확히 그 메시지)

---

## 9. 구현 언어 / 기술 선택

- **언어**: 순수 HTML + CSS + Vanilla JavaScript
- **번들러 없음**: 단일 파일로 배포
- **외부 라이브러리 금지**: 폐쇄망 환경 지원 (CDN 포함 전부 금지)
- **브라우저 API 사용 가능**: File API, Clipboard API, Blob, URL.createObjectURL
- **ES2020+** 문법 OK (optional chaining, nullish coalescing 등)

---

## 10. 스타일 가이드

- 전체 톤: **slate** 계열 (배경 `#f1f5f9`, 테두리 `#e2e8f0`, 본문 `#0f172a`)
- 강조: 파란색 (`#2563eb`)
- 에러: 빨간색 (`#dc2626`)
- 경고: 주황색 (`#d97706` / `#f59e0b`)
- 성공: 초록색 (`#10b981`)
- 폰트: 시스템 폰트 (`-apple-system, "Segoe UI", "Noto Sans KR", sans-serif`)
- 고정폭: `ui-monospace`
- 기본 폰트 크기 13px, 테이블 12px
- 태그별 자동 색상: 해시 기반 12색 팔레트

---

## 11. 배포 및 사용

1. `log_xml_analyzer.html` 파일을 더블클릭 → 기본 브라우저에서 열림
2. 로그 파일을 창에 드래그 → 자동 파싱 및 분석
3. 사이드바 / 테이블 / 뷰어 / 문자 파싱기로 탐색
4. JSON / CSV / TXT 로 결과 내보내기

**서버 불필요**. 네트워크 연결 불필요. 로그 데이터가 외부로 나가지 않음.

---

## 12. 재현 시 우선순위

처음 구현한다면 이 순서를 권장:

1. **HTML 뼈대 + 드롭존** - 파일 받기만
2. **로그 라인 파서** (`LOG_LINE_RE`) + 엔트리 리스트
3. **테이블 렌더링** - timestamp / level / class / message 보이기
4. **XML 블록 추출** (`extractXml`) + 태그 통계 사이드바
5. **XML → JSON 변환기** (`xmlToJson`) + JSON 뷰어
6. **messageName 추출** (소문자 + 대문자) + 사이드바 섹션
7. **BPEL 추출** + 테이블 컬럼
8. **검색/필터** + debounce + 페이지네이션
9. **문자 파싱기 모달** - 8개 조건 + 3가지 뷰 + 내보내기
10. **JSON → 조건 양방향 변환** - 파싱기 안에 통합 (5.6 섹션 참조)
11. **엣지 케이스 방어** - 6장 목록 전부 반영

---

**원본 HTML**: 약 1,500 lines, ~45KB 단일 파일.

**이 스펙 문서**: 이문서는 데모스를 통해서 제작되었습니다.
