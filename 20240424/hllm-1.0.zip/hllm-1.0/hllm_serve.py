#!/usr/bin/env python3
"""
hllm_serve — 로컬 GGUF OpenAI 호환 서버 (llama-cpp-python 기반)

이 프로세스는 한 번 띄워두고 계속 살아있게 둔다.
hllm CLI는 여기에 HTTP localhost로 붙는다. 외부 통신 없음.

사용:
    # 기본 (단일 GPU)
    python hllm_serve.py /path/to/model.gguf --n-ctx 16384

    # V100 2장 분배
    python hllm_serve.py /path/to/model.gguf \\
        --tensor-split 0.5,0.5 --n-ctx 16384

    # 백그라운드
    nohup python hllm_serve.py /path/model.gguf \\
        > ~/hllm_serve.log 2>&1 &
    tail -f ~/hllm_serve.log    # "Application startup complete" 뜨면 OK
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main():
    p = argparse.ArgumentParser(
        description="hllm_serve — 로컬 GGUF OpenAI 호환 서버",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p.add_argument("model", help="GGUF 파일 경로")
    p.add_argument("--host", default="127.0.0.1",
                   help="기본 127.0.0.1 (localhost only)")
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--n-ctx", type=int, default=8192,
                   help="컨텍스트 길이")
    p.add_argument("--n-gpu-layers", type=int, default=-1,
                   help="GPU에 올릴 레이어 (-1=전부)")
    p.add_argument("--tensor-split", default=None,
                   help="멀티 GPU 분배. 예: '0.5,0.5'")
    p.add_argument("--main-gpu", type=int, default=0)
    p.add_argument("--type-k", type=int, default=8,
                   help="KV K 양자화 (1=f16, 8=q8_0)")
    p.add_argument("--type-v", type=int, default=8)
    p.add_argument("--no-flash-attn", action="store_true",
                   help="Flash Attention 끄기")
    p.add_argument("--chat-format", default=None,
                   help="None=GGUF 메타 자동. 'chatml-function-calling' 등 강제")
    p.add_argument("--alias", default="local",
                   help="모델 alias (CLI에서 model 파라미터에 사용)")
    p.add_argument("--api-key", default=None,
                   help="API 키 강제 (None=인증 없음)")
    args = p.parse_args()

    model_path = Path(args.model)
    if not model_path.exists():
        print(f"[ERROR] 모델 파일 없음: {model_path}", file=sys.stderr)
        sys.exit(1)

    size_gb = model_path.stat().st_size / 1024**3
    tensor_split = None
    if args.tensor_split:
        tensor_split = [float(x) for x in args.tensor_split.split(",")]

    print("=" * 60)
    print(" hllm_serve — 로컬 GGUF OpenAI 호환 서버")
    print("=" * 60)
    print(f" 모델       : {model_path.name} ({size_gb:.1f} GB)")
    print(f" endpoint   : http://{args.host}:{args.port}/v1")
    print(f" alias      : {args.alias}")
    print(f" n_ctx      : {args.n_ctx}")
    print(f" n_gpu_layers: {args.n_gpu_layers}")
    if tensor_split:
        print(f" tensor_split: {tensor_split}")
    print(f" KV cache   : type_k={args.type_k}, type_v={args.type_v}")
    print(f" flash_attn : {not args.no_flash_attn}")
    print(f" chat_format: {args.chat_format or 'auto (from GGUF metadata)'}")
    print("-" * 60)
    if size_gb > 50:
        print(" 큰 모델 로딩 1~3분 걸림…")
        print("-" * 60)

    try:
        from llama_cpp.server.app import create_app
        from llama_cpp.server.settings import ServerSettings, ModelSettings
    except ImportError as e:
        print(f"[ERROR] 설치 필요: {e}", file=sys.stderr)
        print("  pip install fastapi uvicorn sse-starlette starlette-context "
              "'pydantic-settings>=2.0'", file=sys.stderr)
        sys.exit(1)

    model_settings = [ModelSettings(
        model=str(model_path),
        model_alias=args.alias,
        n_gpu_layers=args.n_gpu_layers,
        n_ctx=args.n_ctx,
        tensor_split=tensor_split,
        main_gpu=args.main_gpu,
        type_k=args.type_k,
        type_v=args.type_v,
        flash_attn=not args.no_flash_attn,
        chat_format=args.chat_format,
        verbose=True,
    )]
    server_settings = ServerSettings(
        host=args.host, port=args.port, api_key=args.api_key,
    )
    app = create_app(server_settings=server_settings,
                     model_settings=model_settings)

    import uvicorn
    uvicorn.run(app, host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
