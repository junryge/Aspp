# hllm — Linux CLI 데이터 분석/코딩 에이전트

Claude Code 스타일. 로컬 GGUF 모델 + tool calling 루프.

## 구성 (3가지 목표)

1. **코딩** — 파일 읽기/수정/생성/실행
2. **지식 도메인** — `~/.hllm/context.md` 자동 주입
3. **데이터 분석** — bash로 python 실행, CSV/로그 처리
4. **스킬 시스템** — `~/.hllm/skills/<이름>/SKILL.md` (예: 슈퍼파워)

## 파일 4개

```
hllm                            메인 CLI (1053줄)
hllm_serve.py                   로컬 OpenAI 호환 서버 (109줄)
context.md.template             ~/.hllm/context.md 시작 템플릿
superpower_skill.md.template    슈퍼파워 스킬 시작 템플릿
```

## 설치

### 1) 의존성

```bash
# 로컬 모델 서버
pip install llama_cpp_python-0.3.21-py3-none-linux_x86_64.whl
pip install fastapi uvicorn sse-starlette starlette-context 'pydantic-settings>=2.0'

# CLI
pip install httpx rich
# (데이터 분석 시 별도) pip install pandas matplotlib numpy
```

### 2) hllm 실행권한

```bash
chmod +x hllm
# PATH에 두기 (선택)
mkdir -p ~/.local/bin && cp hllm ~/.local/bin/
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

### 3) 컨텍스트/스킬 폴더 초기화

```bash
mkdir -p ~/.hllm/skills

# 글로벌 컨텍스트 (선택)
cp context.md.template ~/.hllm/context.md
$EDITOR ~/.hllm/context.md   # 본인 환경 정보 채우기

# 슈퍼파워 스킬 (선택)
mkdir -p ~/.hllm/skills/슈퍼파워
cp superpower_skill.md.template ~/.hllm/skills/슈퍼파워/SKILL.md
$EDITOR ~/.hllm/skills/슈퍼파워/SKILL.md
```

## 실행

### 1) 모델 서버 (한 번만 띄움)

테스트 (Qwen3.5-27B Q4_K_M, 약 16GB):
```bash
python hllm_serve.py /path/to/Qwen3.5-27B.Q4_K_M.gguf --n-ctx 16384
```

V100 2장 분배:
```bash
python hllm_serve.py /path/to/Qwen3.5-27B.Q4_K_M.gguf \
    --tensor-split 0.5,0.5 --n-ctx 32768
```

백그라운드:
```bash
nohup python hllm_serve.py /path/model.gguf --n-ctx 16384 \
    > ~/hllm_serve.log 2>&1 &
tail -f ~/hllm_serve.log    # "Application startup complete" 뜨면 준비 완료
```

서버 살아있는지:
```bash
curl http://127.0.0.1:8000/v1/models
```

### 2) hllm CLI

**단발 명령:**
```bash
hllm "현재 폴더 구조 파악해줘"
hllm "data.csv 첫 100행 보여주고 컬럼별 통계 내줘"
hllm "이 폴더의 모든 .py 파일 line 수 세줘"
hllm "error.log 최근 200줄에서 ERROR/WARN 패턴 분석"
```

**파이프:**
```bash
cat error.log | hllm "원인 추정"
ls -la | hllm "이 파일들 중 큰 거 위주로 정리"
```

**인터랙티브 (REPL):**
```bash
hllm
> data.csv 읽고 통계 내줘
> 위에서 발견한 이상치 시각화 PNG로 저장
> 코드 정리해서 analyze.py 파일로 만들어
> /exit
```

**자동 승인 (yolo, 위험):**
```bash
hllm -y "lint 에러 다 고쳐"
```

**스킬 활성화:**
```bash
hllm --skill 슈퍼파워 "큰 작업 처리"
# 또는 REPL 안에서: > /skill use 슈퍼파워
```

## REPL 명령

| 명령 | 동작 |
|---|---|
| `/help` | 도움말 |
| `/skill list` | 스킬 목록 |
| `/skill use <이름>` | 스킬 활성화 |
| `/skill drop <이름>` | 스킬 비활성화 |
| `/skill new <이름>` | 새 스킬 골격 생성 |
| `/context` | 컨텍스트/스킬 상태 |
| `/reload` | system 프롬프트 재구성 (context.md 수정 후) |
| `/clear` | 히스토리 초기화 |
| `/yolo` | 자동 승인 토글 |
| `/save [경로]` | 세션 저장 |
| `/load [경로]` | 세션 불러오기 |
| `/exit` | 종료 |

## 도구 (모델이 알아서 호출)

| 도구 | 동작 | 자동? |
|---|---|---|
| `read` | 파일 읽기 (라인 범위 가능) | ✅ 자동 |
| `grep` | 정규식 검색 | ✅ 자동 |
| `glob` | 글롭으로 파일 찾기 | ✅ 자동 |
| `ls` | 디렉토리 나열 | ✅ 자동 |
| `bash` | read-only 명령 (ls/cat/python 등) | ✅ 자동 |
| `bash` | 그 외 명령 | ❓ 확인 |
| `bash` | 위험 명령 (rm -rf, dd 등) | ⚠️ 한 번 더 확인 |
| `write` | 파일 작성/덮어쓰기 (diff 표시 + .bak) | ❓ 확인 |
| `edit` | 부분 수정 (diff 표시) | ❓ 확인 |
| `todo_write` | TODO 트래킹 | ✅ 자동 |

## 환경변수

```bash
export HLLM_ENDPOINT="http://127.0.0.1:8000/v1"   # 서버 주소
export HLLM_MODEL="local"                          # alias (서버와 일치)
export HLLM_API_KEY="dummy"                        # 로컬은 dummy
```

## 폴더 구조

```
~/.hllm/
├── context.md              # 자동 로딩 글로벌 컨텍스트
├── skills/
│   ├── 슈퍼파워/
│   │   └── SKILL.md       # /skill use 슈퍼파워
│   └── <other_skill>/
│       └── SKILL.md
├── last_session.json       # /save 기본 경로
└── actions.log             # 도구 호출 기록

./.hllm_context.md          # 프로젝트 로컬 컨텍스트 (있으면 자동 로딩)
```

## 모델 변경 (Qwen 3.5 → 3.6)

`hllm`은 모델에 의존하지 않음. 서버 쪽만 모델 파일 경로 바꾸고 재시작:

```bash
# 기존 서버 죽이고
pkill -f hllm_serve.py

# 새 모델로 재시작
python hllm_serve.py /path/to/Qwen3.6-XXX.gguf \
    --tensor-split 0.5,0.5 --n-ctx 16384
```

`hllm` CLI는 그대로 작동.

## 트러블슈팅

**서버 연결 실패**
- `curl http://127.0.0.1:8000/v1/models` 로 서버 살아있는지 확인
- `nvidia-smi`로 GPU 메모리 확인

**모델이 도구를 안 부름**
- Qwen 3.5/3.6은 tool calling 지원하지만, GGUF의 chat template이 무시되는 경우 있음
- `hllm_serve.py --chat-format chatml-function-calling` 명시 시도

**파일 인코딩**
- UTF-8 외 인코딩 (cp949/euc-kr) 자동 감지
- 안 되면 `iconv` 로 변환

**OOM**
- `--n-ctx 8192` 또는 `4096` 으로 낮춤
- 더 작은 양자화 모델 (Q3) 시도

## 주요 워크플로 예시

### 데이터 분석
```bash
$ hllm
> sales.csv 분석해줘
  → ls
  → read sales.csv (head)
  → bash: python -c "import pandas as pd; df = pd.read_csv('sales.csv'); print(df.describe())"
  → 결과 요약: 1245 rows, 매출 평균 $X, 결측치 N건...

> 월별 매출 그래프 그려줘
  → write _tmp_plot.py
  → bash: python _tmp_plot.py
  → 생성: monthly_sales.png

> /exit
```

### 코드 리팩토링
```bash
$ hllm
> parser.py 읽고 타입힌트 추가
  → read parser.py
  → edit (3개 함수 수정 - 각각 diff 확인 후 적용)
> 테스트도 짜줘
  → write test_parser.py
  → bash: python -m pytest test_parser.py

> /exit
```
