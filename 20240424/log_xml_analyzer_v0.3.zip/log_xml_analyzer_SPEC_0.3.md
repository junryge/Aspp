# 📊 로그 XML 태그 분석기 (log_xml_analyzer.html) 완전 스펙

> **목적**: 반도체 FAB MCS(Material Control System) 로그에서 XML 메시지를 자동 파싱·분류·검색·추출하는 단일 파일 웹 도구.
> 이 문서만 있으면 다른 LLM이나 개발자가 동일한 도구를 재구현할 수 있도록 상세 명세함.

---

## 1. 대상 로그 포맷

### 1.1 기본 라인 포맷 (Spring Boot 로거)

```
[2026-04-16 18:00:00,001] [ INFO] [quartzScheduler_Worker-2] [nexbe.mcs.custom.schedule.ProcessUsageJob.executeInternal] - [[ProcessUsageJob] will be invoked. ]
```

**구조**: `[timestamp] [ level] [threadId] [class] - [message]`

| 필드 | 포맷 | 주의사항 |
|---|---|---|
| timestamp | `YYYY-MM-DD HH:MM:SS,mmm` | 쉼표 구분자 (점 아님) |
| level | `INFO` / `WARN` / `ERROR` / `DEBUG` / `TRACE` | **좌측 공백 패딩** (`[ INFO]`, `[ WARN]`) |
| threadId | 예: `main`, `Tibrv Dispatcher`, `THREAD-ID=143`, `quartzScheduler_Worker-2` | **좌측 공백 패딩 있음** |
| class | Java FQCN + 메서드 (`.executeInternal`, `.onStart`, `.onEnd`) | 공백 없음 |
| message | `- [` 로 시작 `]` 로 끝남 | 멀티라인 가능 |

### 1.2 XML 임베드 포맷

```
[2026-04-16 18:00:06,681] [ INFO] [ Tibrv Dispatcher] [nexbe.mcs.core.communication.tibrv.TibrvDefaultListener.onMsg] - [
<?xml version="1.0" encoding="UTF-8"?>
<ApplicationControlMessage>
  <messageName>APS-CheckHeartBeat</messageName>
  <transactionId>20260416180006680981_MNS15</transactionId>
  ...
</ApplicationControlMessage>
]
```

로그 라인의 `message` 필드 안에 여러 줄에 걸친 XML 블록이 들어갈 수 있음. `[` 로 열고 `]` 로 닫음.

### 1.3 BPEL 워크플로우 포맷

```
[2026-04-16 18:00:06,682] [ INFO] [    THREAD-ID=143] [nexbe.mcs.core.workflow.WorkflowEventSubscriber.onStart] - [[7486] APS-CheckHeartBeat.bpel
<ApplicationControlMessage>...</ApplicationControlMessage>
]

[2026-04-16 18:00:06,682] [ INFO] [    THREAD-ID=143] [nexbe.mcs.core.workflow.WorkflowEventSubscriber.onEnd] - [[7486] APS-CheckHeartBeat.bpel elapsed=0ms]
```

- `[7486]` → BPEL 인스턴스 ID (추적 키)
- `APS-CheckHeartBeat.bpel` → BPEL 워크플로우 이름
- `elapsed=0ms` → 실행 소요 시간 (onEnd 라인에만)

### 1.4 관찰된 최상위 XML 태그 17종

```
ApplicationControlMessage   (하트비트/제어 메시지)
MESSAGE                      (범용 메시지 - HEADER/ORIGINATED/DATA 구조)
McsMessage                   (MCS 내부 메시지)
AlarmReportMessage           (알람 리포트)
AlarmDataMessage             (알람 데이터)
ClientMessage / ClientNotificationMessage  (클라이언트 UI 통신)
Envelop                      (외부 시스템 연동)
PortDataMessage, CarrierDataMessage, EquipmentDataMessageEx
TransferEvent, TransportJobStateMessage
EquipmentControlStateMessage, EquipmentStateMessage, EquipmentStatusDataMessageEx
EnhancedHostCommandSendMessageEx
```

### 1.5 messageName 두 형태 (매우 중요)

**케이스 A - 소문자** (`<ApplicationControlMessage>` 같은 태그):
```xml
<ApplicationControlMessage>
  <messageName>APS-CheckHeartBeat</messageName>   ← 최상위 직계 자식
  ...
  <originMessageName>APS-CheckHeartBeat</originMessageName>   ← 이건 제외!
</ApplicationControlMessage>
```

**케이스 B - 대문자** (`<MESSAGE>` 태그):
```xml
<MESSAGE>
  <HEADER>
    <MESSAGENAME>Rail-UnitAlarmCleared</MESSAGENAME>   ← HEADER 안 대문자
    <ORIGINMESSAGENAME>S6F11</ORIGINMESSAGENAME>        ← 이건 제외!
  </HEADER>
  <DATA>...</DATA>
</MESSAGE>
```

두 케이스 모두 "메시지 이름"을 의미. 둘 다 추출해야 하지만 `originMessageName` / `ORIGINMESSAGENAME` 는 제외해야 함.

### 1.6 실측 데이터 규모 (검증용 기준값)

| 파일 | 엔트리 | XML | messageName | BPEL |
|---|---|---|---|---|
| HIS01.2026-04-09-13.log | 12,100 | 5,149 | 4,031 | 3,810 |
| MNS05.2026-04-09-14.log | 28,671 | 5,053 | 4,786 | 3,080 |
| MNS05-26.04.09.132341-stdout.log | 59,463 | 10,179 | 9,586 | 6,380 |
| MNS15_2026-04-16-18.log | 5,900 | 1,624 | 1,614 | 1,130 |

---

## 2. 요구사항 (기능 명세)

### 2.1 필수 기능

| 기능 | 상세 |
|---|---|
| 파일 업로드 | 드래그앤드롭 + 클릭 선택, 다중 파일, `.log` / `.txt` |
| 로그 라인 파싱 | timestamp / level / threadId / class / message 추출 |
| 멀티라인 병합 | 헤더 없는 라인은 직전 엔트리의 message에 이어붙임 (스택트레이스 보존) |
| XML 태그 자동 감지 | message 안의 최상위 XML 블록 추출, 태그명 + 본문 저장 |
| XML → JSON 변환 | `<tag attr="v">text</tag>` → `{tag: {_attrs: {attr:"v"}, _text: "text"}}` |
| messageName 추출 | 소문자 `<messageName>` + 대문자 `<MESSAGENAME>` 둘 다, `originMessageName`류 제외 |
| BPEL 정보 추출 | `[인스턴스ID] 워크플로우이름.bpel` 패턴에서 `bpelId`, `bpelName`, `elapsedMs` 추출 |
| 태그 통계 | XML 태그별 빈도 + 시각화 바 |
| messageName 통계 | messageName별 빈도 + 시각화 바, 선택된 XML 태그 기준 교차필터 |
| 필터링 | 검색 / 레벨 / XML 유무 / 태그 선택 / messageName 선택 |
| 상세 뷰어 | JSON (syntax highlight) / XML 원본 / 전체 로그 / 메타정보 |
| 내보내기 | 전체 JSON, 전체 CSV |
| 문자 파싱기 (별도) | 복합 조건 조회 모달 + 3가지 뷰 + 복사/TXT/CSV 내보내기 |

### 2.2 성능 요구

- 10만 엔트리 (~40MB) 파싱 3초 이내
- 검색창 입력 시 UI 렉 없음 (debounce 필수)
- 결과 테이블은 페이지네이션 필수 (대량 결과에서 DOM 폭발 방지)

### 2.3 환경 제약

- **단일 HTML 파일** (외부 의존 없음, 폐쇄망 환경 지원)
- Chrome / Edge 최신 버전 기준
- 서버 없이 브라우저에서만 동작 (로그 데이터가 외부로 나가지 않음)

---

## 3. 파서 로직 명세 (JavaScript)

### 3.1 정규식 (핵심)

```javascript
// 로그 라인 헤더 - 좌측 공백 패딩 허용 ([ INFO], [    main])
const LOG_LINE_RE = /^\[([^\]]+)\]\s*\[\s*(\w+)\s*\]\s*\[\s*([^\]]*?)\s*\]\s*\[([^\]]+)\]\s*-\s*(.*)$/;

// messageName 추출 - 대소문자 둘 다, originMessageName 방어 (단어 경계)
const MESSAGE_NAME_LOWER = /<messageName(\s[^>]*)?>([^<]*)<\/messageName\s*>/;
const MESSAGE_NAME_UPPER = /<MESSAGENAME(\s[^>]*)?>([^<]*)<\/MESSAGENAME\s*>/;

// BPEL 패턴
const BPEL_RE = /^\[(\d+)\]\s+([\w-]+)\.bpel/;
const ELAPSED_RE = /\belapsed=(\d+)\s*ms\b/;

// XML 최상위 태그 시작 감지
const XML_OPEN_RE = /<([A-Za-z][A-Za-z0-9_\-]*)(\s|>|\/)/;
```

### 3.2 파싱 순서

1. 파일 텍스트를 `split(/\r?\n/)` 로 라인 분할 (CRLF/LF 혼재 대응)
2. 각 라인에 대해 `LOG_LINE_RE` 매칭 시도
3. 매칭되면 새 엔트리 시작, 이전 엔트리는 `finalizeEntry()` 호출 후 확정
4. 매칭 안 되면 현재 엔트리의 message에 줄바꿈으로 이어붙임 (멀티라인 지원)
5. 마지막 엔트리도 `finalizeEntry()` 호출

### 3.3 finalizeEntry 처리 (중요 - 순서 보존)

```javascript
function finalizeEntry(entry) {
  // (1) 바깥 [ ] 벗기기 - Spring Boot 로거 포맷
  if (entry.message) {
    const m = entry.message;
    if (/^\s*\[/.test(m) && /\]\s*$/.test(m)) {
      const s = m.indexOf('[');
      const e = m.lastIndexOf(']');
      if (s !== -1 && e > s) entry.message = m.slice(s + 1, e).trim();
    }
  }

  // (2) BPEL 정보 추출 (XML 추출 전에)
  if (entry.message) {
    const bpelMatch = entry.message.match(/^\[(\d+)\]\s+([\w-]+)\.bpel/);
    if (bpelMatch) {
      entry.bpelId = bpelMatch[1];
      entry.bpelName = bpelMatch[2];
    }
    const elapMatch = entry.message.match(/\belapsed=(\d+)\s*ms\b/);
    if (elapMatch) entry.elapsedMs = parseInt(elapMatch[1], 10);
  }

  // (3) XML 블록 추출
  const xml = extractXml(entry.message);
  if (xml) {
    entry.xmlTag = xml.tag;
    entry.xmlContent = xml.content;
    entry.messageName = extractMessageName(xml.content);
    try {
      entry.jsonContent = xmlToJson(xml.content);
    } catch (e) {
      entry.jsonContent = { _parseError: e.message };
    }
  }
}
```

### 3.4 XML 블록 추출 (extractXml)

**알고리즘**:
1. `<?xml version="1.0"?>` 선언이 있으면 제거
2. 첫 `<TagName>` 매칭 찾기 (`[A-Za-z][A-Za-z0-9_\-]*`)
3. 같은 이름의 여는/닫는 태그를 **depth 카운트**로 매칭 (중첩 동일 태그 방어)
4. self-closing `<Tag/>` 는 별도 처리
5. 반환: `{ tag: "TagName", content: "<TagName>...</TagName>" }`

```javascript
function extractXml(message) {
  let text = message.replace(/<\?xml[^?]*\?>/g, '');
  const m = text.match(/<([A-Za-z][A-Za-z0-9_\-]*)(\s|>|\/)/);
  if (!m) return null;
  const tagName = m[1];
  const tagStart = text.indexOf(m[0]);

  // self-closing 체크
  const selfClosingRe = new RegExp(`<${tagName}[^>]*\\/>`);
  const scMatch = text.slice(tagStart).match(selfClosingRe);
  if (scMatch && scMatch.index === 0) {
    return { tag: tagName, content: scMatch[0] };
  }

  // depth 카운트로 닫는 태그 매칭
  const openRe = new RegExp(`<${tagName}(\\s[^>]*)?>`, 'g');
  const closeRe = new RegExp(`</${tagName}\\s*>`, 'g');
  let depth = 0, scanPos = tagStart;
  while (scanPos < text.length) {
    openRe.lastIndex = scanPos;
    closeRe.lastIndex = scanPos;
    const oM = openRe.exec(text), cM = closeRe.exec(text);
    if (!cM) return null;
    if (oM && oM.index < cM.index) {
      depth++; scanPos = oM.index + oM[0].length;
    } else {
      depth--; scanPos = cM.index + cM[0].length;
      if (depth === 0) return { tag: tagName, content: text.slice(tagStart, cM.index + cM[0].length) };
    }
  }
  return null;
}
```

### 3.5 messageName 추출

```javascript
function extractMessageName(xmlContent) {
  // 소문자 시도 먼저
  const mLower = xmlContent.match(/<messageName(\s[^>]*)?>([^<]*)<\/messageName\s*>/);
  if (mLower) {
    const txt = decodeEntities(mLower[2]).trim();
    if (txt) return txt;
  }
  // 대문자 시도
  const mUpper = xmlContent.match(/<MESSAGENAME(\s[^>]*)?>([^<]*)<\/MESSAGENAME\s*>/);
  if (mUpper) {
    const txt = decodeEntities(mUpper[2]).trim();
    if (txt) return txt;
  }
  return null;
}
```

**왜 대소문자 구분하나?**: `<messageName>` (소문자) 와 `<MESSAGENAME>` (대문자) 는 각각 다른 XML 스키마의 태그. 대소문자 무시로 매칭하면 `<originMessageName>` / `<ORIGINMESSAGENAME>` 같은 유사 태그가 혼입될 수 있어 위험. 명시적으로 두 케이스만 허용.

### 3.6 XML → JSON 변환기

자체 구현 (외부 라이브러리 불가). 규칙:

| XML | JSON |
|---|---|
| `<tag>value</tag>` | `{tag: "value"}` |
| `<tag attr="v">text</tag>` | `{tag: {_attrs: {attr: "v"}, _text: "text"}}` |
| `<parent><child>v</child></parent>` | `{parent: {child: "v"}}` |
| 동일 이름 반복 요소 | 배열로 `{items: [...]}`
| `<tag/>` | `{tag: ""}` |
| `<tag>123</tag>` | `{tag: 123}` (15자리 이상은 문자열 유지) |
| `<tag>true</tag>` | `{tag: true}` |
| CDATA | `_text` 값에 포함 |
| 엔티티 (`&lt;`, `&amp;` 등) | 디코딩 후 값에 저장 |

**숫자 변환 (coerceScalar) 주의**:
```javascript
function coerceScalar(s) {
  if (s === 'true') return true;
  if (s === 'false') return false;
  if (/^-?\d+$/.test(s)) {
    if (s.length > 15) return s;  // JS Number 정밀도 한계 → 문자열 유지
    return parseInt(s, 10);
  }
  if (/^-?\d+\.\d+$/.test(s)) return parseFloat(s);
  return s;
}
```
실제 `transactionId`가 20자리 (`20260416180006680981`) 이므로 문자열 보존 필수. 그렇지 않으면 뒷자리 손실.

### 3.7 엔티티 디코딩

```javascript
function decodeEntities(s) {
  return s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')
          .replace(/&quot;/g, '"').replace(/&apos;/g, "'")
          .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(parseInt(n, 10)))
          .replace(/&#x([0-9a-fA-F]+);/g, (_, n) => String.fromCharCode(parseInt(n, 16)));
}
```

---

## 4. UI 레이아웃

### 4.1 전체 구조

```
┌─────────────────────────────────────────────────────────────────────┐
│ 📊 로그 XML 태그 분석기    [📁 파일선택] [🔎 문자파싱기] [⬇JSON] [⬇CSV] [🗑] │
├─────────────────────┬───────────────────────────────────────────────┤
│ 📑 XML 태그 (flex:1)│  전체 N · XML N · 태그 N · msgName N · BPEL N ·  │
│                     │  평균 X.Xms                                    │
│ 선택: 전체  [초기화] ├───────────────────────────────────────────────┤
│ ○ 전체         N    │ [🔍 검색] [레벨▼] [XML유무▼]                    │
│ ● Tag1    ■■■ N    ├───────────────────────────────────────────────┤
│ ● Tag2    ■■ N     │ 시간 │ 레벨 │ Thread │ XML태그 │ msgName │ BPEL │ 미리보기 │
│ ...                 │ ...                                           │
├─────────────────────┤ [이전] 1 / N [다음]   N 건 중 1-100            │
│ 📝 messageName      ├───────────────────────────────────────────────┤
│ (flex:1)            │ [JSON] [XML원본] [전체로그] [메타정보]          │
│ 선택: 전체  [초기화] │  {                                             │
│ ○ 전체         N    │    "tag": {...}                               │
│ ● Name1   ■■■ N    │  }                                             │
│ ● Name2   ■■ N     │                                                │
└─────────────────────┴───────────────────────────────────────────────┘

문자 파싱기 버튼 클릭 → 모달 팝업 (별도 UI)
```

### 4.2 사이드바 (320px 고정 폭)

- **상단**: XML 태그 통계 (flex:1)
  - 태그 이름, 건수, 막대 비율
  - 클릭 → 해당 태그로 필터
  - 태그별 자동 색상 (해시 기반)

- **하단**: messageName 통계 (flex:1)
  - 선택된 XML 태그 기준으로 교차 필터됨
  - 예: "ApplicationControlMessage" 선택 시 → 해당 태그에 속한 messageName 만 표시

### 4.3 상단 미니 통계 바

```
전체 5,900 | XML 포함 1,624 | 태그 종류 7 | 메시지명 1,614 | BPEL 1,130 | 평균 0.9ms
```

### 4.4 로그 테이블 컬럼

| 컬럼 | 너비 | 내용 |
|---|---|---|
| 시간 | 160px | 타임스탬프 (mono font) |
| 레벨 | 60px | 레벨 chip (색상 구분: INFO 파랑 / WARN 노랑 / ERROR 빨강) |
| Thread | 60px | threadId |
| XML 태그 | 150px | 태그별 색상 chip |
| messageName | 170px | messageName 색상 chip |
| BPEL | 130px | `#7486 0ms` (0ms 초록 / 10ms+ 주황 / 100ms+ 빨강) |
| 미리보기 | 남은 공간 | message 첫 200자 |

페이지네이션: 100행/페이지

### 4.5 상세 뷰어 (하단, 38% 높이)

4개 탭:
- **JSON** - syntax highlight (key/string/number/boolean/null 색상 분리)
- **XML 원본** - 들여쓰기 포맷 + 태그/속성/값 색상
- **전체 로그** - rawLog 그대로
- **메타정보** - timestamp/level/threadId/class/xmlTag/messageName/bpelId/bpelName/elapsedMs/srcFile/lineNo 을 JSON 형태로

---

## 5. 문자 파싱기 (핵심 도구, 모달)

### 5.1 레이아웃 (좌 360px 조건 / 우 나머지 결과)

```
┌──────────────────────────────────────────────────────────┐
│ 🔎 문자 파싱기 - 조회 조건으로 추출                    [✕] │
├────────────────────┬─────────────────────────────────────┤
│ 조회 조건          │ 조회결과: N 건 / 전체 M [조건요약...] │
│                    │ [📊요약표][📄XML만][📋원본] [복사][TXT][CSV] │
│ 📝 messageName     ├─────────────────────────────────────┤
│ [          ]       │                                     │
│                    │                                     │
│ 📑 XML 태그        │          결과 테이블/뷰              │
│ [          ]       │                                     │
│                    │                                     │
│ ⚙️ BPEL 이름       │                                     │
│ [          ]       │                                     │
│                    │                                     │
│ ⏱ 최소 실행시간    │                                     │
│ [    ]             │                                     │
│                    │                                     │
│ ⏰ 시간 범위       │                                     │
│ [start]~[end]      │                                     │
│                    │                                     │
│ 🚦 레벨            │                                     │
│ [I][W][E][D][T]    │                                     │
│                    │                                     │
│ 🔍 자유 텍스트     │                                     │
│ [          ]       │                                     │
│                    │                                     │
│ 🧪 정규식          │                                     │
│ [          ]       │                                     │
│ (에러 메시지)      │                                     │
│                    │ (페이지네이션 200행/페이지)          │
│ [조회실행][초기화] │                                     │
└────────────────────┴─────────────────────────────────────┘
```

### 5.2 조회 조건 8가지

| 조건 | 매칭 방식 | 비고 |
|---|---|---|
| messageName | 공백 구분 **OR** 부분일치 (대소문자 무시) | `"APS MNS-Alarm"` → 둘 중 하나 포함 |
| XML 태그 | 공백 구분 OR 부분일치 | 동일 |
| BPEL 이름 | 공백 구분 OR 부분일치 | 동일 |
| 최소 실행시간 | `e.elapsedMs >= N` | 빈칸=전체, 숫자 아니면 에러 |
| 시간 범위 | `HH:MM` 또는 `HH:MM:SS[.mmm]` 허용 | 범위 검증 (시 0-23, 분초 0-59) |
| 레벨 | 다중 선택 칩 | 미선택=전체 |
| 자유 텍스트 | 공백 구분 **AND** (전체 로그에서) | 모두 포함 |
| 정규식 | RegExp 매칭 (case-insensitive) | 전체 로그 대상 |

**모든 조건은 AND 로 결합**됨. 조건을 1개 이상 입력해야 실행 가능 (아무것도 없이 실행하면 전체 반환 → 렌더 폭발 방지).

### 5.3 결과 표시 3가지 모드

- **📊 요약표**: 메인 테이블과 동일한 컬럼 (페이지네이션 200행)
- **📄 XML만**: 각 엔트리의 `xmlContent`를 구분자로 구분해서 표시
- **📋 원본**: `rawLog` 전체 (로그 파일 원본 그대로)

### 5.4 내보내기 3가지

- **📋 복사**: 현재 뷰 모드 기준 TXT 를 클립보드로 (전체, 페이지 상관없이)
- **⬇ TXT**: 파일 다운로드 (`log_parsed_{mode}_{timestamp}.txt`)
- **⬇ CSV**: 항상 표 형식 CSV, UTF-8 BOM 포함 (엑셀 한글 깨짐 방지)

### 5.5 UX 편의

- `Enter` 키: 조회 실행 (**단, 한글 IME 조합 중에는 발동 안 함** - `e.isComposing` 체크)
- `ESC` 키: 모달 닫기
- 모달 밖 클릭: 닫기
- 토스트 알림 (성공: 초록, 에러: 빨강, 경고: 주황)

---

## 6. 알려진 함정 및 방어 (중요)

이 도구 만들 때 **실제로 겪은 버그**들. 다시 만들 때 같은 함정 피하도록:

### 6.1 로그 파싱 관련

| 함정 | 올바른 처리 |
|---|---|
| 레벨 `[ INFO]` 좌측 공백 | 정규식 `\[\s*(\w+)\s*\]` 로 공백 허용 |
| CRLF / LF 혼재 | `split(/\r?\n/)` |
| 긴 `transactionId` (20자리) | 숫자 변환 시 15자리 이상은 문자열 유지 |
| 멀티라인 메시지 (스택 트레이스) | 헤더 없는 라인은 직전 엔트리에 병합 |
| `<messageName>` vs `<MESSAGENAME>` | 둘 다 추출, 단 `<originMessageName>` 제외 (단어 경계) |
| 바깥 `[` `]` 대괄호 | Spring Boot 로거 규칙, 벗기되 스택트레이스처럼 `]` 로 안 끝나면 건드리지 말 것 |

### 6.2 UI 관련

| 함정 | 방어 |
|---|---|
| 같은 파일 2번 드롭 → 중복 누적 | 파일명 Set 으로 중복 체크, 스킵 시 토스트 |
| 로딩 중 재진입 race | `state._loading` 플래그로 가드 |
| 검색창 매 키 입력 → 10만행 전체 스캔 렉 | 250ms debounce |
| 빈 조건 조회 → 전체 렌더 폭발 | 최소 1개 조건 필수 검증 |
| 결과 대량 → 테이블 DOM 폭발 | 페이지네이션 200행 |
| 악성 정규식 `(a+)+` → 브라우저 얼음 | 중첩 수량자 패턴 감지해서 차단 |
| 한글 IME 조합 중 Enter → 원치 않는 조회 | `e.isComposing` 체크 |
| 시간 `25:00:00` 정상 취급됨 | 범위 검증 (시 0-23, 분초 0-59) |
| 시간 `18:00` (초 생략) → null 로 무시 | `HH:MM` 도 허용하도록 정규식 수정 |
| elapsed 에 `abc` 입력 조용히 무시 | 숫자 아니면 에러 토스트 |
| `indexOf(e)` O(n) - 10만행 느림 | 파싱 직후 `_idx` 부여 |

### 6.3 JSON 변환 관련

| 함정 | 처리 |
|---|---|
| `<tag />` self-closing | 빈 문자열 반환 |
| 동일 이름 형제 요소 | 배열로 변환 |
| `&amp;` 이중 이스케이프 | 디코딩 후 저장 (다시 esc 하지 않도록 주의) |
| `<?xml?>` 선언 | extractXml 에서 미리 제거 |

---

## 7. 파일 구조

**단일 HTML 파일 하나. 외부 의존 없음.**

```
log_xml_analyzer.html
├── <style>            순수 CSS (~350 lines)
├── <body>
│   ├── 헤더 (타이틀 + 버튼)
│   ├── 드롭존 (초기 화면)
│   ├── 메인 (사이드바 + 콘텐츠)
│   ├── 문자 파싱기 모달
│   └── 토스트 컨테이너
└── <script>           순수 Vanilla JS (~800 lines)
    ├── 파서 (LOG_LINE_RE, extractXml, xmlToJson, ...)
    ├── 상태 관리 (state, parserState)
    ├── 렌더링 (render, renderParserResult, renderViewer)
    ├── 이벤트 (파일 드롭, 모달, 검색)
    └── 내보내기 (JSON, CSV, TXT, 클립보드)
```

총 ~1500 lines, 단일 파일.

---

## 8. 검증 체크리스트

구현 완료 후 다음 항목들이 모두 통과하는지 확인:

### 8.1 파서 정확도 (실측 데이터 기준)

- [ ] MNS15_2026-04-16-18.log (2.55MB) → 엔트리 정확히 **5,900건**
- [ ] 같은 파일 XML 포함 **1,624건**
- [ ] 같은 파일 messageName 추출 **1,614건**
- [ ] 같은 파일 BPEL 추출 **1,130건**
- [ ] 같은 파일 elapsed 추출 **565건**
- [ ] JSON 변환 실패 0건
- [ ] `transactionId` 20자리가 문자열로 원본 그대로 보존

### 8.2 messageName 정확성

- [ ] `<ApplicationControlMessage>` 의 소문자 `<messageName>` 추출됨
- [ ] `<MESSAGE>` 의 대문자 `<MESSAGENAME>` 추출됨 (HEADER 안)
- [ ] `<originMessageName>APS-CheckHeartBeat</originMessageName>` 값은 messageName 에 **안 들어감**
- [ ] `<ORIGINMESSAGENAME>S6F11</ORIGINMESSAGENAME>` 값은 messageName 에 **안 들어감**

### 8.3 BPEL 교차 검증

grep 으로 원본 파일 카운트와 일치해야:
```bash
grep -cE "\[[0-9]+\] [A-Za-z-]+\.bpel" file.log   # BPEL 접두사 건수
grep -c "elapsed=" file.log                       # elapsed 건수
```

### 8.4 UI 동작

- [ ] 파일 드래그앤드롭 → 자동 파싱 → 사이드바 + 테이블 표시
- [ ] 사이드바 태그 클릭 → 해당 태그로 필터, messageName 섹션도 교차 필터
- [ ] 테이블 행 클릭 → 하단 뷰어에 JSON / XML / 전체 / 메타 표시
- [ ] 같은 파일 2번 드롭 → 중복 경고, 누적 안 됨
- [ ] 검색창 빠른 타이핑 → 렉 없음 (debounce 동작)
- [ ] 10만 엔트리 로드 → 테이블 페이지네이션 100행 정상
- [ ] JSON / CSV 다운로드 (UTF-8 BOM) → 엑셀에서 한글 깨짐 없음

### 8.5 문자 파싱기 동작

- [ ] 빈 조건 조회 → 빨간 토스트 "최소 1개 조건 필요"
- [ ] 시간 `25:00:00` 입력 → 빨간 토스트
- [ ] elapsed `abc` 입력 → 빨간 토스트
- [ ] 정규식 `(a+)+` 입력 → "성능 문제 가능 패턴" 경고, 실행 안 함
- [ ] 한글 입력 중 Enter (IME 조합) → 조회 실행 안 됨
- [ ] 결과 2만건 → 페이지네이션 200행/페이지
- [ ] 복사/다운로드는 **전체** (페이지 상관없이)
- [ ] 조건 요약이 결과 상단에 칩으로 표시
- [ ] ESC 키 → 모달 닫힘

---

## 9. 구현 언어 / 기술 선택

- **언어**: 순수 HTML + CSS + Vanilla JavaScript
- **번들러 없음**: 단일 파일로 배포
- **외부 라이브러리 금지**: 폐쇄망 환경 지원 (CDN 포함 전부 금지)
- **브라우저 API 사용 가능**: File API, Clipboard API, Blob, URL.createObjectURL
- **ES2020+** 문법 OK (optional chaining, nullish coalescing 등)

---

## 10. 스타일 가이드

- 전체 톤: **slate** 계열 (배경 `#f1f5f9`, 테두리 `#e2e8f0`, 본문 `#0f172a`)
- 강조: 파란색 (`#2563eb`)
- 에러: 빨간색 (`#dc2626`)
- 경고: 주황색 (`#d97706` / `#f59e0b`)
- 성공: 초록색 (`#10b981`)
- 폰트: 시스템 폰트 (`-apple-system, "Segoe UI", "Noto Sans KR", sans-serif`)
- 고정폭: `ui-monospace`
- 기본 폰트 크기 13px, 테이블 12px
- 태그별 자동 색상: 해시 기반 12색 팔레트

---

## 11. 배포 및 사용

1. `log_xml_analyzer.html` 파일을 더블클릭 → 기본 브라우저에서 열림
2. 로그 파일을 창에 드래그 → 자동 파싱 및 분석
3. 사이드바 / 테이블 / 뷰어 / 문자 파싱기로 탐색
4. JSON / CSV / TXT 로 결과 내보내기

**서버 불필요**. 네트워크 연결 불필요. 로그 데이터가 외부로 나가지 않음.

---

## 12. 재현 시 우선순위

처음 구현한다면 이 순서를 권장:

1. **HTML 뼈대 + 드롭존** - 파일 받기만
2. **로그 라인 파서** (`LOG_LINE_RE`) + 엔트리 리스트
3. **테이블 렌더링** - timestamp / level / class / message 보이기
4. **XML 블록 추출** (`extractXml`) + 태그 통계 사이드바
5. **XML → JSON 변환기** (`xmlToJson`) + JSON 뷰어
6. **messageName 추출** (소문자 + 대문자) + 사이드바 섹션
7. **BPEL 추출** + 테이블 컬럼
8. **검색/필터** + debounce + 페이지네이션
9. **문자 파싱기 모달** - 8개 조건 + 3가지 뷰 + 내보내기
10. **엣지 케이스 방어** - 6장 목록 전부 반영

---

**원본 HTML**: 약 1,500 lines, ~45KB 단일 파일.

**이 스펙 문서**: 이 정보만으로 처음부터 동일한 도구를 재구현 가능.
