#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
detect.py — Chronos-2 로 이동평균을 예측해 '심각한 정체'를 선제 감지
====================================================================
설계 근거 (RAW/FINDINGS_RAW분석.md + buildup 분석):
  · 순간값은 78%가 1분 블립(노이즈) → 예측 불가 ⇒ 이동평균을 타깃으로
  · 심각 사건(지속 10분+, 평균 52분) 18건 중 15건(83%)이 사전 buildup 있음
    ⇒ 예측 가능. 저부하→상승형(A)과 고부하 지속형(B) 두 패턴.

동작 (매 분, 인과적 — 직전까지의 데이터만):
    이동평균 이력 ──Chronos-2──▶ 미래 H분 이동평균 분포(q10/q50/q90)
                                        │
                     P(미래 이동평균 ≥ 임계) 계산
                                        │
    stage 3 = 지금 이미 임계 초과 (진행 중)
    stage 2 = h분 뒤 초과 예상  ← 선제 경보, lead = h
    stage 1 = 확률 중간 (관찰)
    stage 0 = 정상

Chronos-2 미설치/로드실패 시 baseline 예측기로 폴백 (로직 검증용).
"""
from __future__ import annotations

import argparse
import csv
import math

from data import load, moving_avg, learn_threshold, TARGET, LEADING, TIME_COL


# ──────────────────────────────────────────────────────────────
# 예측기
# ──────────────────────────────────────────────────────────────
def auto_device():
    try:
        import torch
        if torch.cuda.is_available():
            return "cuda"
        if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            return "mps"
    except Exception:
        pass
    return "cpu"


def resolve_model(path: str) -> str:
    """로컬 폴더가 있으면 그걸 쓰고(오프라인), 없으면 HF 식별자 그대로."""
    import os
    if os.path.isdir(path):
        return path
    base = os.path.basename(path)
    for c in (f"./models/{base}", f"./{base}", "./chronos_2", "./models/chronos_2"):
        if os.path.isdir(c):
            return c
    return path


QUANTILES = [0.1, 0.5, 0.9]


def _as_lists(obj):
    """텐서/배열/리스트 → 순수 파이썬 중첩 리스트."""
    if hasattr(obj, "tolist"):
        return obj.tolist()
    if isinstance(obj, (list, tuple)):
        return [_as_lists(o) for o in obj]
    return obj


def _dims(a) -> list[int]:
    """중첩 리스트의 각 축 길이."""
    d = []
    while isinstance(a, (list, tuple)) and a:
        d.append(len(a))
        a = a[0]
    return d


def _to_qrows(a, horizon):
    """중첩 리스트 → [[q10,q50,q90], ...] (horizon개). 축 순서/여분축 자동 처리."""
    d = _dims(a)
    while len(d) > 2 and d[0] == 1:          # 앞쪽 크기1 축 제거 (variate 등)
        a = a[0]
        d = d[1:]
    if len(d) > 2 and d[1] == 1:             # 중간 크기1 축 제거
        a = [row[0] for row in a]
        d = [d[0], d[2]]
    if d[:2] == [horizon, 3]:
        rows = a
    elif d[:2] == [3, horizon]:
        rows = [[a[0][h], a[1][h], a[2][h]] for h in range(horizon)]
    else:
        raise ValueError(f"예상 못한 분위수 형태: {d} (horizon={horizon})")
    return {"q10": [float(r[0]) for r in rows],
            "q50": [float(r[1]) for r in rows],
            "q90": [float(r[2]) for r in rows]}


def _normalize(result, horizon, n_series=1):
    """
    predict_quantiles 반환값을 [{'q10','q50','q90'}, ...] 로 정규화.
    버전에 따라 (quantiles, mean) 튜플 / 4-D (series,variate,horizon,q) /
    3-D (series,horizon,q) / 축 순서 반전 등이 모두 올 수 있어 형태로 판별한다.
    """
    q = result[0] if isinstance(result, tuple) and result else result
    arr = _as_lists(q)
    d = _dims(arr)
    if len(d) < 2:
        raise ValueError(f"예상 못한 반환 구조: dims={d}")
    # 시리즈 축이 있고 시리즈가 여러 개면 시리즈별로 처리
    if n_series > 1 and d[0] == n_series:
        return [_to_qrows(a, horizon) for a in arr]
    return [_to_qrows(arr, horizon)]


class Forecaster:
    """Chronos-2 (배치 예측). 실패 시 baseline 폴백."""

    def __init__(self, model="chronos_2", device=None):
        self.pipe = None
        self.err = None
        self.backend = "baseline"
        self._form = None          # 통하는 호출 형태를 기억해 재사용
        try:
            from chronos import Chronos2Pipeline
            mp = resolve_model(model)
            dev = device or auto_device()
            self.pipe = Chronos2Pipeline.from_pretrained(mp, device_map=dev)
            self.backend = mp.rstrip("/").split("/")[-1]
            self.device = dev
        except Exception as e:
            self.err = repr(e)

    def _forms(self, t3d, t2d, ctx_list, horizon):
        """
        버전별 호출 시그니처 후보.
        Chronos-2 는 inputs 를 3-D (n_series, n_variates, history_length) 로 받는다.
        Chronos-Bolt 는 context= 에 2-D 를 받는다.
        """
        kw = dict(prediction_length=horizon, quantile_levels=QUANTILES)
        return [
            ("inputs 3-D (n_series,n_variates,history)",
             lambda: self.pipe.predict_quantiles(t3d, **kw)),
            ("inputs= 3-D",
             lambda: self.pipe.predict_quantiles(inputs=t3d, **kw)),
            ("inputs= list of 2-D",
             lambda: self.pipe.predict_quantiles(inputs=ctx_list, **kw)),
            ("inputs 2-D",
             lambda: self.pipe.predict_quantiles(t2d, **kw)),
            ("context= 2-D (Bolt)",
             lambda: self.pipe.predict_quantiles(context=t2d, **kw)),
        ]

    def predict(self, contexts: list[list[float]], horizon: int) -> list[dict]:
        """contexts 여러 개를 한 번에 → [{'q10','q50','q90'}, ...]"""
        if self.pipe is None:
            return [_baseline(c, horizon) for c in contexts]
        try:
            import torch
            L = min(len(c) for c in contexts)
            trimmed = [c[-L:] for c in contexts]
            t2d = torch.tensor(trimmed, dtype=torch.float32)      # (S, L)
            t3d = t2d.unsqueeze(1)                                # (S, 1, L)
            ctx_list = [t3d[i] for i in range(t3d.shape[0])]      # [(1, L), ...]
            n = len(contexts)

            forms = self._forms(t3d, t2d, ctx_list, horizon)
            if self._form is not None:                    # 이미 통하는 형태 사용
                return _normalize(forms[self._form][1](), horizon, n)

            errors = []
            for i, (name, call) in enumerate(forms):
                try:
                    out = _normalize(call(), horizon, n)
                    self._form = i
                    print(f"   [모델 호출 형태] {name}")
                    return out
                except Exception as e:
                    errors.append(f"{name}: {e}")
            raise RuntimeError("모든 호출 형태 실패 →\n     " + "\n     ".join(errors))
        except Exception as e:
            # 실모델 예측 실패 → 즉시 알린다 (조용한 폴백은 결과를 오인시킴)
            self.err = repr(e)
            self.pipe = None
            self.backend = "baseline"
            print("=" * 72)
            print("⚠ 실모델 예측 실패 → baseline 으로 폴백합니다.")
            print(f"   원인: {e}")
            print("   이 결과는 Chronos-2 성적이 아닙니다. 원인 해결 후 재실행하세요.")
            print("=" * 72)
            return [_baseline(c, horizon) for c in contexts]


def _baseline(ctx: list[float], horizon: int) -> dict:
    """EWMA + 추세 외삽 (모델 없을 때 로직 검증용)."""
    x = [v for v in ctx if v is not None and math.isfinite(v)]
    if len(x) < 3:
        last = x[-1] if x else 0.0
        return {k: [last] * horizon for k in ("q10", "q50", "q90")}
    lvl = x[0]
    for v in x[1:]:
        lvl = 0.35 * v + 0.65 * lvl
    tail = x[-min(len(x), 10):]
    n = len(tail); xs = list(range(n))
    mx = sum(xs) / n; my = sum(tail) / n
    den = sum((i - mx) ** 2 for i in xs) or 1.0
    slope = sum((xs[i] - mx) * (tail[i] - my) for i in range(n)) / den
    d = [x[i] - x[i - 1] for i in range(1, len(x))]
    md = sum(d) / len(d)
    sd = math.sqrt(max(sum((v - md) ** 2 for v in d) / max(1, len(d) - 1), 1e-9))
    out = {"q10": [], "q50": [], "q90": []}
    for h in range(1, horizon + 1):
        c = lvl + slope * h
        s = sd * math.sqrt(h)
        out["q10"].append(c - 1.2816 * s)
        out["q50"].append(c)
        out["q90"].append(c + 1.2816 * s)
    return out


# ──────────────────────────────────────────────────────────────
# 분위수 → 초과확률
# ──────────────────────────────────────────────────────────────
def exceed_prob(q10, q50, q90, threshold) -> float:
    """(q10,.1)(q50,.5)(q90,.9) 로 CDF 근사 → P(X > threshold)."""
    a, b, c = sorted((q10, q50, q90))
    pts = [(a, 0.10), (b, 0.50), (c, 0.90)]
    x = threshold
    if x <= pts[0][0]:
        span = (pts[1][0] - pts[0][0]) or 1e-9
        p = pts[0][1] + (pts[1][1] - pts[0][1]) / span * (x - pts[0][0])
    elif x >= pts[2][0]:
        span = (pts[2][0] - pts[1][0]) or 1e-9
        p = pts[2][1] + (pts[2][1] - pts[1][1]) / span * (x - pts[2][0])
    else:
        p = 0.5
        for i in range(2):
            x0, p0 = pts[i]; x1, p1 = pts[i + 1]
            if x0 <= x <= x1:
                span = (x1 - x0) or 1e-9
                p = p0 + (p1 - p0) * (x - x0) / span
                break
    return max(0.0, min(1.0, 1.0 - max(0.0, min(1.0, p))))


# ──────────────────────────────────────────────────────────────
# 메인 감지 루프
# ──────────────────────────────────────────────────────────────
def predict_curves(series, threshold, window=10, horizon=15, context=90,
                   stride=1, model="chronos_2", device=None,
                   verbose=True, batch=256):
    """
    매 분 인과적으로 예측해 '지평별 초과확률 곡선'을 만든다.

    성능: 시점 하나씩 호출하면 호출 오버헤드가 GPU 계산을 압도한다
    (44,640분 = 44,640회 호출). Chronos-2 는 (n_series, n_variates, history)
    로 여러 시계열을 한 번에 받으므로, 예측이 필요한 시점들을 batch 개씩
    묶어 한 번에 호출한다 → 호출 수가 1/batch 로 줄어든다.
    각 시점의 입력은 그 시점까지의 이력뿐이라 배치해도 인과성은 유지된다.
    """
    times = series.times
    N = len(times)
    raw = series.get(TARGET)
    sm = moving_avg(series.filled(TARGET), window)

    f = Forecaster(model, device)
    if verbose:
        print("=" * 72)
        print(" detect — Chronos-2 이동평균 예측 → 심각 정체 선제 감지")
        print(f" backend={f.backend} | {window}분평균 | 지평 {horizon}분 | 임계 {threshold}")
        print(f" 데이터 {N}분  {times[0]} ~ {times[-1]}")
        if f.pipe is None:
            print(f" ⚠ Chronos-2 로드 실패 → baseline 폴백: {f.err}")
        print("=" * 72)

    # ── 1) 예측이 필요한 시점 수집 ─────────────────────────
    #    · 이미 임계 초과면 예측 불필요(stage 3)
    #    · 전체 이력창(context)이 확보된 시점만 → 길이가 같아 배치 가능
    stride = max(1, stride)
    need = [t for t in range(context - 1, N)
            if sm[t] < threshold and (t - (context - 1)) % stride == 0]

    # ── 2) 배치 예측 → 시점별 '지평별 초과확률 곡선' 저장 ───
    #    p_on/p_off 는 예측 이후의 문턱값일 뿐이므로, 확률 곡선을 남겨두면
    #    모델을 다시 돌리지 않고 여러 p_on 을 평가할 수 있다 (sweep).
    curves: dict[int, list[float]] = {}
    bs = max(1, batch)
    n_calls = (len(need) + bs - 1) // bs
    for i in range(0, len(need), bs):
        chunk = need[i:i + bs]
        ctxs = [sm[t - context + 1:t + 1] for t in chunk]
        fcs = f.predict(ctxs, horizon)
        for t, fc in zip(chunk, fcs):
            curves[t] = [exceed_prob(fc["q10"][h], fc["q50"][h], fc["q90"][h],
                                     threshold) for h in range(horizon)]
        if verbose and ((i // bs) % 10 == 0 or i + bs >= len(need)):
            print(f"  예측 {min(i+bs, len(need))}/{len(need)} 시점 "
                  f"(호출 {i//bs+1}/{n_calls}, backend={f.backend})")

    if verbose and f.backend == "baseline" and f.err:
        print(f"  ※ 실행 중 baseline 폴백됨 — 원인: {f.err}")
    return {"times": times, "raw": raw, "sm": sm, "curves": curves,
            "threshold": threshold, "horizon": horizon, "context": context,
            "backend": f.backend}


def decide(pre: dict, p_on=0.6, p_off=0.4):
    """
    예측 결과(확률 곡선)로 단계를 판정한다. 모델 호출 없음 → p_on 스윕이 공짜.
    히스테리시스는 시간순이어야 하므로 순차 루프.
    """
    times, raw, sm = pre["times"], pre["raw"], pre["sm"]
    curves, thr, H = pre["curves"], pre["threshold"], pre["horizon"]
    ctx = pre["context"]
    rows = []
    active = False
    last = (0.0, None)
    for t in range(len(times)):
        cur = sm[t]
        if cur >= thr:                                   # 진행 중
            rows.append([times[t], raw[t], 3, 1.0, "", "진행중",
                         f"이동평균 {cur:.1f} ≥ 임계 {thr}"])
            active = True
            continue
        if t in curves:
            c = curves[t]
            best_p = max(c)
            lead = next((h + 1 for h in range(H) if c[h] >= p_on), None)
            last = (best_p, lead)
        elif t < ctx - 1:                                # 이력 부족 구간
            rows.append([times[t], raw[t], 0, 0.0, "", "", "정상(이력부족)"])
            continue
        best_p, lead = last

        if best_p >= p_on:
            active = True
        elif best_p < p_off:
            active = False
        if active and lead is not None:
            rows.append([times[t], raw[t], 2, best_p, lead, "선제",
                         f"약 {lead}분 뒤 임계 초과 예상 (확률 {best_p:.2f})"])
        elif best_p >= p_off:
            rows.append([times[t], raw[t], 1, best_p, "", "관찰",
                         f"상승 조짐 (확률 {best_p:.2f})"])
        else:
            rows.append([times[t], raw[t], 0, best_p, "", "", "정상"])
    return rows


def run(series, threshold, window=10, horizon=15, context=90,
        p_on=0.6, p_off=0.4, stride=1, model="chronos_2", device=None,
        verbose=True, batch=256):
    """예측 + 판정 (기존 인터페이스 유지)."""
    pre = predict_curves(series, threshold, window, horizon, context,
                         stride, model, device, verbose, batch)
    return decide(pre, p_on, p_off), pre["backend"]


def save(rows, path):
    with open(path, "w", newline="", encoding="utf-8-sig") as fp:
        w = csv.writer(fp)
        w.writerow(["datetime", "raw_value", "stage", "prob", "lead_min",
                    "kind", "reason"])
        for t, rv, st, p, lead, kind, why in rows:
            w.writerow([t.strftime("%Y-%m-%d %H:%M:%S"),
                        "" if rv is None else rv, st, round(p, 3), lead, kind, why])


def main():
    ap = argparse.ArgumentParser(description="심각 정체 선제 감지 (Chronos-2)")
    ap.add_argument("--data", required=True, nargs="+", help="평가 대상 CSV(글롭)")
    ap.add_argument("--config", default=None,
                    help="학습 결과(model_config.json) — 임계·창을 그대로 재사용")
    ap.add_argument("--threshold", type=float, default=None,
                    help="임계(이동평균). 미지정 시 --config/--train/대상데이터")
    ap.add_argument("--train", nargs="+", default=None, help="임계 학습용 CSV")
    ap.add_argument("--pct", type=float, default=0.99)
    ap.add_argument("--window", type=int, default=10, help="이동평균 창(분)")
    ap.add_argument("--horizon", type=int, default=15, help="예측 지평(분)")
    ap.add_argument("--context", type=int, default=90,
                    help="모델이 보는 직전 이력(분). 기본 90분")
    ap.add_argument("--p-on", type=float, default=0.6)
    ap.add_argument("--p-off", type=float, default=0.4)
    ap.add_argument("--stride", type=int, default=1)
    ap.add_argument("--batch", type=int, default=256,
                    help="한 번의 모델 호출에 묶을 시점 수 (클수록 빠름, GPU 메모리↑)")
    ap.add_argument("--model", default="chronos_2")
    ap.add_argument("--device", default=None)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    # 학습 결과 재사용 (--config) — 명시 인자가 없으면 config 값 사용
    if a.config:
        from data import load_config
        cfg = load_config(a.config)
        if a.threshold is None:
            a.threshold = cfg["threshold"]
        if ap.get_default("window") == a.window:
            a.window = cfg.get("window", a.window)
        print(f"[config] {a.config} → 임계 {a.threshold} · {a.window}분평균 "
              f"(학습 {cfg.get('train_span')}, 사건 {cfg.get('train_events')}건)")

    sd = load(a.data, [TARGET] + LEADING + [TIME_COL])
    if a.threshold is not None:
        thr = a.threshold
    elif a.train:
        tr = load(a.train, [TARGET, TIME_COL])
        thr = learn_threshold(moving_avg(tr.filled(TARGET), a.window), a.pct)
        print(f"[학습] 임계 = {thr} (학습 {len(tr)}분, p{a.pct*100:.1f})")
    else:
        thr = learn_threshold(moving_avg(sd.filled(TARGET), a.window), a.pct)
        print(f"[주의] 대상데이터에서 임계 산출 = {thr} (leakage 가능)")

    rows, backend = run(sd, thr, a.window, a.horizon, a.context,
                        a.p_on, a.p_off, a.stride, a.model, a.device,
                        batch=a.batch)
    save(rows, a.out)
    n2 = sum(1 for r in rows if r[2] == 2)
    n3 = sum(1 for r in rows if r[2] == 3)
    print(f"\n저장: {a.out}")
    print(f"  선제경보(stage2) {n2}분 | 진행중(stage3) {n3}분")
    if backend == "baseline":
        print("  ※ baseline 폴백 결과 — 실 Chronos-2 로 다시 돌리세요.")


if __name__ == "__main__":
    main()
