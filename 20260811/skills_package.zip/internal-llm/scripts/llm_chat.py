#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
llm_chat.py — 폐쇄망 내부 LLM 호출 클라이언트 (stdlib-only)

엔드포인트:
  hcp   -> https://dev.hcp.llm.skhynix.com/v1
  spark -> http://14.35.248.221:10010/v1
인증: TOKEN.TXT CWD-first (CWD -> 스크립트 디렉터리 -> env LLM_TOKEN)

사용:
  python llm_chat.py "프롬프트"
  python llm_chat.py --endpoint hcp --model gpt-oss-20b "프롬프트"
  python llm_chat.py --model gemma4-26b --image ./defect.jpg "하자 찾아라"
  python llm_chat.py --file ./error.log "위 로그 요약"
  python llm_chat.py --list-models              # /models 실측 확인
"""
import argparse
import base64
import json
import mimetypes
import os
import ssl
import sys
import urllib.error
import urllib.request

ENDPOINTS = {
    "hcp": "https://dev.hcp.llm.skhynix.com/v1",
    "spark": "http://14.35.248.221:10010/v1",
}
DEFAULT_ENDPOINT = "spark"
DEFAULT_MODEL = "qwen3.6-35b"
TIMEOUT = 180  # 대형 모델 첫 토큰 지연 감안


def load_token():
    """TOKEN.TXT CWD-first 탐색."""
    candidates = [
        os.path.join(os.getcwd(), "TOKEN.TXT"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "TOKEN.TXT"),
    ]
    for p in candidates:
        if os.path.isfile(p):
            with open(p, "r", encoding="utf-8") as f:
                t = f.read().strip()
            if t:
                return t
    return os.environ.get("LLM_TOKEN", "")


def _request(url, payload=None, token=""):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, headers=headers,
                                 method="POST" if data else "GET")
    # 사내 인증서 이슈 대비 (폐쇄망 내부 통신 전제)
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT, context=ctx) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise SystemExit("[HTTP %d] %s\n%s" % (e.code, url, body[:2000]))
    except urllib.error.URLError as e:
        raise SystemExit("[연결 실패] %s -> %s" % (url, e.reason))


def encode_image(path):
    mime = mimetypes.guess_type(path)[0] or "image/jpeg"
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("ascii")
    return "data:%s;base64,%s" % (mime, b64)


def chat(prompt, endpoint=DEFAULT_ENDPOINT, model=DEFAULT_MODEL,
         system=None, image=None, temperature=0.3, max_tokens=4096):
    """OpenAI-compatible /chat/completions 호출. 응답 텍스트 반환."""
    base = ENDPOINTS.get(endpoint, endpoint).rstrip("/")
    token = load_token()

    if image:
        content = [
            {"type": "image_url", "image_url": {"url": encode_image(image)}},
            {"type": "text", "text": prompt},
        ]
    else:
        content = prompt

    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    elif model.lower().startswith("glm"):
        # GLM 계열: 한국어 시스템 프롬프트 없으면 중국어로 샘
        messages.append({"role": "system", "content": "한국어로만 답변한다."})
    messages.append({"role": "user", "content": content})

    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False,
    }
    res = _request(base + "/chat/completions", payload, token)
    try:
        return res["choices"][0]["message"]["content"]
    except (KeyError, IndexError):
        raise SystemExit("[응답 포맷 이상]\n" + json.dumps(res, ensure_ascii=False)[:2000])


def list_models(endpoint=DEFAULT_ENDPOINT):
    base = ENDPOINTS.get(endpoint, endpoint).rstrip("/")
    res = _request(base + "/models", None, load_token())
    return [m.get("id", "?") for m in res.get("data", [])]


def main():
    ap = argparse.ArgumentParser(description="폐쇄망 내부 LLM 호출 (stdlib-only)")
    ap.add_argument("prompt", nargs="?", help="사용자 프롬프트")
    ap.add_argument("--endpoint", default=DEFAULT_ENDPOINT,
                    help="hcp | spark | 직접 base URL (기본: spark)")
    ap.add_argument("--model", default=DEFAULT_MODEL, help="기본: qwen3.6-35b")
    ap.add_argument("--system", default=None, help="시스템 프롬프트")
    ap.add_argument("--image", default=None, help="비전 입력 이미지 경로 (gemma4-26b)")
    ap.add_argument("--file", default=None, help="프롬프트 앞에 붙일 텍스트 파일")
    ap.add_argument("--temperature", type=float, default=0.3)
    ap.add_argument("--max-tokens", type=int, default=4096)
    ap.add_argument("--list-models", action="store_true", help="/models 실측 목록")
    args = ap.parse_args()

    if args.list_models:
        for m in list_models(args.endpoint):
            print(m)
        return

    if not args.prompt:
        ap.error("프롬프트가 없다. --list-models 아니면 프롬프트 넣어라.")

    prompt = args.prompt
    if args.file:
        with open(args.file, "r", encoding="utf-8", errors="replace") as f:
            prompt = "```\n" + f.read() + "\n```\n\n" + prompt

    out = chat(prompt, endpoint=args.endpoint, model=args.model,
               system=args.system, image=args.image,
               temperature=args.temperature, max_tokens=args.max_tokens)
    # 폐쇄망 콘솔 인코딩 이슈 대비
    sys.stdout.buffer.write(out.encode("utf-8", errors="replace"))
    sys.stdout.buffer.write(b"\n")


if __name__ == "__main__":
    main()
