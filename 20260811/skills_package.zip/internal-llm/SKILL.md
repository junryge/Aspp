---
name: internal-llm
description: SK Hynix 폐쇄망에서 내부 LLM(HCP 게이트웨이 / DGX Spark)을 호출하는 표준 절차. "LLM한테 물어봐라", "내부 LLM 호출", "HCP 게이트웨이", "DGX Spark 모델", "qwen/glm/gemma 돌려라", 로그 요약·분류·비전 판독 등 외부 API 없이 LLM 추론이 필요한 모든 상황에서 반드시 이 스킬을 켠다. 어떤 엔드포인트·모델을 골라야 할지 애매할 때도 이 스킬의 모델 선택표를 따른다. 외부 인터넷 API(OpenAI/Anthropic 등) 호출 코드를 짜기 전에 무조건 이 스킬 먼저 확인.
---

# internal-llm

폐쇄망 내부 LLM 호출 표준. 외부 API 금지 환경이므로 모든 LLM 추론은 아래 두 엔드포인트로만 나간다. 클라이언트는 **stdlib-only** (`urllib`), pip 의존성 추가 금지.

## 1. 엔드포인트

| 별칭 | Base URL | 용도 |
|---|---|---|
| `hcp` | `https://dev.hcp.llm.skhynix.com/v1` | 사내 공식 게이트웨이. Qwen3 계열, GLM, gpt-oss-20b |
| `spark` | `http://14.35.248.221:10010/v1` | DGX Spark 로컬 추론 (llama.cpp 서버) |

둘 다 **OpenAI-compatible** (`/chat/completions`, `/models`). 요청/응답 포맷 동일.

## 2. 인증 — TOKEN.TXT CWD-first

토큰 탐색 순서 (첫 번째로 찾은 것 사용):

1. **현재 작업 디렉터리(CWD)의 `TOKEN.TXT`** ← 기본 패턴
2. 스크립트 위치 디렉터리의 `TOKEN.TXT`
3. 환경변수 `LLM_TOKEN`

파일은 공백/개행 strip 후 `Authorization: Bearer {token}` 헤더로. spark 로컬 서버는 토큰 없어도 동작할 수 있으나 헤더는 항상 붙인다(무해).

## 3. 모델 선택표

| 상황 | 엔드포인트 | 모델 | 비고 |
|---|---|---|---|
| 코딩·에이전트 작업 (기본값) | spark | `qwen3.6-35b` | 주력. SWE-bench 73.4% |
| 빠른 분류·요약 (저지연) | spark | `glm-4.7-flash` | 속도 우선 |
| 긴 문서·대용량 컨텍스트 | spark | `qwen3-next-80b` | 무거움, 필요할 때만 |
| 이미지 판독 (vision) | spark | `gemma4-26b` | mmproj 로드된 서버 필수 |
| 경량 테스트 | spark | `gemma4-12b` | |
| 사내 표준 경로 필요 시 | hcp | Qwen3 계열 / GLM / `gpt-oss-20b` | `/models`로 현재 목록 확인 후 지정 |

**규칙:**
- 모델명 추측 금지. 확신 없으면 `GET {base}/v1/models` 먼저 쳐서 실측 확인.
- GLM 계열은 **한국어 시스템 프롬프트 필수** — 없으면 중국어로 새는 사례 있음.
- 추측보다 실측: 응답 이상하면 서버 로그/모델 목록부터 확인하고 단정하지 않는다.

## 4. 호출 패턴 (stdlib-only)

동봉 스크립트 사용이 기본:

```bash
# 기본 (spark, qwen3.6-35b)
python scripts/llm_chat.py "이 로그 요약해라: ..."

# 엔드포인트/모델 지정
python scripts/llm_chat.py --endpoint hcp --model gpt-oss-20b "질문"

# 시스템 프롬프트
python scripts/llm_chat.py --system "너는 AMHS 물류 분석가다. 한국어로만 답한다." "OHT 에러 분류해라"

# 비전 (gemma4-26b + 이미지)
python scripts/llm_chat.py --model gemma4-26b --image ./defect.jpg "이 사진에서 하자 찾아라"

# 파일을 프롬프트에 첨부
python scripts/llm_chat.py --file ./error.log "위 로그에서 근본 원인 후보 3개"
```

코드에 직접 박아야 하면 `scripts/llm_chat.py`의 `chat()` 함수를 import 해서 쓴다. `requests`/`openai` 패키지 새로 깔지 말 것.

## 5. 폐쇄망 함정 (겪은 것만 기록)

- **tiktoken**: 런타임에 BPE 파일 다운로드 시도함 → `TIKTOKEN_CACHE_DIR` 지정해서 사전 배치한 캐시 쓰게 할 것.
- **LiteLLM**: 모델 메타데이터 원격 조회함 → `LITELLM_LOCAL_MODEL_COST_MAP=True` 설정.
- **wheel 반입**: `pip download --only-binary=:all:` 로 받아서 base64 codec으로 넘긴다. sdist 빌드는 폐쇄망에서 터진다.
- **타임아웃**: 대형 모델(qwen3-next-80b)은 첫 토큰까지 오래 걸림. 클라이언트 타임아웃 120s 이상.

## 6. 하지 말 것

- 외부 API 엔드포인트(api.openai.com 등) 호출 코드 생성 — 폐쇄망에서 무조건 실패.
- 스트리밍 파싱 커스텀 구현 — 필요 없으면 non-stream(`"stream": false`)으로 단순하게.
- 2.5D/3D 시각화 관련 판단을 LLM에 섞어서 처리 — 시각화 규칙은 별도(절대 안 섞는다).
- 검증 없이 "이 모델이 제일 좋다" 단정 — 태스크 샘플 몇 개 실측 비교 후 결정.
