#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
llm.py — 폐쇄망 범용 LLM CLI/모듈 (stdlib-only, 단일 파일)

Claude Code 필요 없음. 파이썬만 있으면 어디서든 돈다.
CLI로 쓰든, import 해서 쓰든, 파이프로 물리든 자유.

엔드포인트:
  spark -> http://14.35.248.221:10010/v1   (DGX Spark llama.cpp, 기본값)
  hcp   -> https://dev.hcp.llm.skhynix.com/v1
인증: TOKEN.TXT CWD-first (CWD -> 스크립트 디렉터리 -> env LLM_TOKEN)
설정 덮어쓰기: env LLM_BASE_URL / LLM_MODEL

── CLI ─────────────────────────────────────────────
  python llm.py "프롬프트"
  python llm.py --model glm-4.7-flash "빨리 분류해라"
  python llm.py --endpoint hcp --model gpt-oss-20b "질문"
  type error.log | python llm.py "위 로그 요약"        # 파이프 (윈도우)
  cat error.log  | python llm.py "위 로그 요약"        # 파이프 (리눅스)
  python llm.py --file report.txt "핵심 3줄"
  python llm.py --image defect.jpg --model gemma4-26b "하자 찾아라"
  python llm.py --list-models
  python llm.py --chat                                 # 대화 모드 (히스토리 유지)
  python llm.py --stream "긴 답변 실시간으로"

── 모듈 ────────────────────────────────────────────
  from llm import chat
  out = chat("요약해라: ...", model="qwen3.6-35b")
"""
import argparse
import base64
import json
import mimetypes
import os
import ssl
import sys
import urllib.error
import urllib.request

ENDPOINTS = {
    "spark": "http://14.35.248.221:10010/v1",
    "hcp": "https://dev.hcp.llm.skhynix.com/v1",
}
DEFAULT_ENDPOINT = os.environ.get("LLM_BASE_URL", "spark")
DEFAULT_MODEL = os.environ.get("LLM_MODEL", "qwen3.6-35b")
TIMEOUT = 300  # 대형 모델(qwen3-next-80b) 첫 토큰 지연 감안


# ── 인증 ──────────────────────────────────────────
def load_token():
    """TOKEN.TXT CWD-first 탐색."""
    for p in (os.path.join(os.getcwd(), "TOKEN.TXT"),
              os.path.join(os.path.dirname(os.path.abspath(__file__)), "TOKEN.TXT")):
        if os.path.isfile(p):
            with open(p, "r", encoding="utf-8") as f:
                t = f.read().strip()
            if t:
                return t
    return os.environ.get("LLM_TOKEN", "")


def _base(endpoint):
    return ENDPOINTS.get(endpoint, endpoint).rstrip("/")


def _open(url, payload=None, token="", stream=False):
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = "Bearer " + token
    data = json.dumps(payload).encode("utf-8") if payload is not None else None
    req = urllib.request.Request(url, data=data, headers=headers,
                                 method="POST" if data else "GET")
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE  # 사내 인증서 대비 (폐쇄망 내부 전제)
    try:
        return urllib.request.urlopen(req, timeout=TIMEOUT, context=ctx)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        raise SystemExit("[HTTP %d] %s\n%s" % (e.code, url, body[:2000]))
    except urllib.error.URLError as e:
        raise SystemExit("[연결 실패] %s -> %s" % (url, e.reason))


def _out(text, end="\n"):
    """윈도우 cp949 콘솔에서도 안 깨지게 출력."""
    sys.stdout.buffer.write(text.encode("utf-8", errors="replace"))
    if end:
        sys.stdout.buffer.write(end.encode())
    sys.stdout.flush()


# ── 핵심 API ──────────────────────────────────────
def encode_image(path):
    mime = mimetypes.guess_type(path)[0] or "image/jpeg"
    with open(path, "rb") as f:
        return "data:%s;base64,%s" % (mime, base64.b64encode(f.read()).decode("ascii"))


def _build_messages(prompt, system=None, image=None, model="", history=None):
    msgs = []
    if system:
        msgs.append({"role": "system", "content": system})
    elif model.lower().startswith("glm"):
        # GLM 계열: 한국어 시스템 프롬프트 없으면 중국어로 샘
        msgs.append({"role": "system", "content": "한국어로만 답변한다."})
    if history:
        msgs.extend(history)
    if image:
        content = [{"type": "image_url", "image_url": {"url": encode_image(image)}},
                   {"type": "text", "text": prompt}]
    else:
        content = prompt
    msgs.append({"role": "user", "content": content})
    return msgs


def chat(prompt, endpoint=DEFAULT_ENDPOINT, model=DEFAULT_MODEL, system=None,
         image=None, history=None, temperature=0.3, max_tokens=4096):
    """단발 호출. 응답 텍스트 반환. (import 용 진입점)"""
    payload = {
        "model": model,
        "messages": _build_messages(prompt, system, image, model, history),
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False,
    }
    with _open(_base(endpoint) + "/chat/completions", payload, load_token()) as r:
        res = json.loads(r.read().decode("utf-8"))
    try:
        return res["choices"][0]["message"]["content"]
    except (KeyError, IndexError):
        raise SystemExit("[응답 포맷 이상]\n" + json.dumps(res, ensure_ascii=False)[:2000])


def chat_stream(prompt, endpoint=DEFAULT_ENDPOINT, model=DEFAULT_MODEL, system=None,
                image=None, history=None, temperature=0.3, max_tokens=4096):
    """스트리밍 호출. 델타 문자열을 yield. OpenAI-compatible SSE(data: {...}) 파싱."""
    payload = {
        "model": model,
        "messages": _build_messages(prompt, system, image, model, history),
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": True,
    }
    with _open(_base(endpoint) + "/chat/completions", payload, load_token()) as r:
        for raw in r:
            line = raw.decode("utf-8", errors="replace").strip()
            if not line.startswith("data:"):
                continue
            body = line[5:].strip()
            if body == "[DONE]":
                break
            try:
                delta = json.loads(body)["choices"][0].get("delta", {})
            except (ValueError, KeyError, IndexError):
                continue
            piece = delta.get("content")
            if piece:
                yield piece


def list_models(endpoint=DEFAULT_ENDPOINT):
    with _open(_base(endpoint) + "/models", None, load_token()) as r:
        res = json.loads(r.read().decode("utf-8"))
    return [m.get("id", "?") for m in res.get("data", [])]


# ── 대화 모드 ─────────────────────────────────────
def repl(endpoint, model, system):
    _out("── 대화 모드 (%s / %s) ──" % (endpoint, model))
    _out("명령: /model <이름>  /models  /clear  /exit")
    history = []
    while True:
        try:
            q = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not q:
            continue
        if q in ("/exit", "/q"):
            break
        if q == "/clear":
            history = []
            _out("[히스토리 초기화]")
            continue
        if q == "/models":
            for m in list_models(endpoint):
                _out("  " + m)
            continue
        if q.startswith("/model "):
            model = q.split(None, 1)[1].strip()
            _out("[모델 변경: %s]" % model)
            continue
        full = []
        try:
            for piece in chat_stream(q, endpoint, model, system, history=history):
                _out(piece, end="")
                full.append(piece)
            _out("")
        except SystemExit as e:
            # 스트리밍 미지원 서버 폴백
            _out("[stream 실패, non-stream 재시도] %s" % e)
            ans = chat(q, endpoint, model, system, history=history)
            _out(ans)
            full = [ans]
        history.append({"role": "user", "content": q})
        history.append({"role": "assistant", "content": "".join(full)})


# ── CLI ───────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(
        description="폐쇄망 범용 LLM CLI (stdlib-only, Claude Code 불필요)")
    ap.add_argument("prompt", nargs="?", help="프롬프트. 생략+파이프 입력이면 stdin이 프롬프트")
    ap.add_argument("--endpoint", default=DEFAULT_ENDPOINT,
                    help="spark | hcp | 직접 base URL (기본: %s)" % DEFAULT_ENDPOINT)
    ap.add_argument("--model", default=DEFAULT_MODEL, help="기본: %s" % DEFAULT_MODEL)
    ap.add_argument("--system", default=None, help="시스템 프롬프트")
    ap.add_argument("--image", default=None, help="비전 입력 이미지 (gemma4-26b)")
    ap.add_argument("--file", default=None, help="프롬프트 앞에 붙일 텍스트 파일")
    ap.add_argument("--temperature", type=float, default=0.3)
    ap.add_argument("--max-tokens", type=int, default=4096)
    ap.add_argument("--stream", action="store_true", help="실시간 출력")
    ap.add_argument("--chat", action="store_true", help="대화 모드 (히스토리 유지)")
    ap.add_argument("--list-models", action="store_true", help="/models 실측 목록")
    args = ap.parse_args()

    if args.list_models:
        for m in list_models(args.endpoint):
            _out(m)
        return
    if args.chat:
        repl(args.endpoint, args.model, args.system)
        return

    # stdin 파이프 처리: cat log | python llm.py "요약"
    piped = None
    if not sys.stdin.isatty():
        piped = sys.stdin.buffer.read().decode("utf-8", errors="replace").strip()

    prompt = args.prompt or ""
    if args.file:
        with open(args.file, "r", encoding="utf-8", errors="replace") as f:
            prompt = "```\n" + f.read() + "\n```\n\n" + prompt
    if piped:
        prompt = ("```\n" + piped + "\n```\n\n" + prompt) if prompt else piped
    if not prompt:
        ap.error("프롬프트가 없다. 인자로 주든가 파이프로 넣어라.")

    if args.stream:
        for piece in chat_stream(prompt, args.endpoint, args.model, args.system,
                                 args.image, temperature=args.temperature,
                                 max_tokens=args.max_tokens):
            _out(piece, end="")
        _out("")
    else:
        _out(chat(prompt, args.endpoint, args.model, args.system, args.image,
                  temperature=args.temperature, max_tokens=args.max_tokens))


if __name__ == "__main__":
    main()
