# -*- coding: utf-8 -*-
"""비었다 — 가로 전체 폭 줄 시험은 작은 칸으로 되돌리면서 tests/test_graph_select.py 로 옮겼다 (2026-10-07). 지워도 된다."""
