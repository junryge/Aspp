"""가짜 주피터 파일서버 — 진짜와 같은 로그인 흐름으로 CSV 를 내준다.

  GET  /login   → _xsrf 쿠키 + 로그인 폼
  POST /login   → 비밀번호 맞으면 세션 쿠키, 틀리면 폼 재출력(200, 'Invalid password')
  GET  /files/… → 세션 쿠키 없으면 403, 있으면 CSV
"""
import json, os, sys, threading, time, urllib.parse
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn

# 테스트 전용 더미. 진짜 비밀번호를 여기에 두면 저장소에 커밋된다.
PW = os.environ.get("MOCK_PW", "테스트용-더미-비번")
with open(os.environ.get("MOCK_CSV") or os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "fixtures", "발동이벤트_샘플.csv"), "rb") as _f:
    CSV = _f.read()
SESS = set()
# ── 진짜 파일서버처럼 Range 를 받는다 ──────────────────────────────────
# 하루치 CSV 는 예측 잡이 1분에 한 줄씩 **덧붙이는** 파일이다. 수집이 그걸
# 매번 통째로 받으면 오후엔 1.5MB 를 받아 새 줄 하나를 얻는다. 꼬리만 받는
# 길(Range)을 시험하려면 가짜 서버도 진짜처럼 굴어야 한다.
LOCK = threading.Lock()
STATE = {"csv": CSV, "range": True, "hits": [], "om": [], "om_rev": 0}
# hits: 요청마다 받은 Range · om: OHT_MAP 요청 · om_rev: 허브룸 잡이 파일을 다시 쓴 횟수


def _rng(hdr: str, n: int):
    """'bytes=123-' → (시작, 끝). 못 읽으면 None."""
    if not hdr or not hdr.startswith("bytes="):
        return None
    a, _, b = hdr[6:].partition("-")
    try:
        start = int(a)
    except ValueError:
        return None
    end = int(b) if b.strip() else n - 1
    if start >= n:
        return "416"
    return start, min(end, n - 1)

# FAB 별 파일(fab분리 폴더) — 실물과 같은 특징만 축약:
#   · unified_risk_score(전체 점수)와 hot_area(전체 기준 M16HUB)가 그대로 있고
#   · 그 FAB 자신의 점수는 area_score / area_level 이다
#   · {FAB}_pts_* 룰 점수 컬럼이 있다 (기여도 분해가 이걸 쓴다)
# 정규화(area_score→unified, hot_area→FAB)가 안 되면 화면이 전체 점수를
# 보게 되므로, 두 점수를 일부러 다르게 둔다.
FABS = ("M14", "M14B", "M16A", "M16B", "M16HUB")


def fab_csv(day: str, fab: str) -> bytes:
    d = f"{day[:4]}-{day[4:6]}-{day[6:8]}"
    head = ("file,datetime,date,time,unified_risk_score,unified_risk_level,"
            f"hot_area,reason,{fab}_score,{fab}_pts_RA_sus,{fab}_pts_SLA,"
            f"{fab}_ra,sla_{fab},area_score,area_level,area_saturated")
    scores = [(5, ""), (65, "경계"), (72, "위험"), (88, "초위험")]
    rows = [
        f"HUB_PR.csv,{d} 00:0{i},{d},00:0{i},44,경계,M16HUB,"
        f"\"hot_area=M16HUB; 발동: M16HUB[R-A_sus]; {fab}[R-A_sus,SLA(9.9%4분초과)]\","
        f"{sc},5,5,3.1{i},9.9,{sc},{lv},"
        for i, (sc, lv) in enumerate(scores)
    ]
    return ("\n".join([head] + rows) + "\n").encode("utf-8")


def oht_map_csv(day: str) -> bytes:
    """허브룸 잡의 OHT_MAP_{day}.csv — 실물 머리줄 그대로. 20:14 에 FAB 둘, 20:15 는 레포트 없음."""
    d = f"{day[:4]}-{day[4:6]}-{day[6:8]}"
    root = "/project/pjt_shared_pool/job/vhl_ohl/HID_BOTTLENECK/PROBLEM_MAP"
    rows = [
        "날짜,시간,FAB,ALARM_KR,ALARM_EN,HID_ZONE,HID_section,OHT_report,OHT_missing,OHT_JAM,"
        "ZONE_STOP,FILE_NAME,FILE_PATH",
        f"{d},20:14,M16HUB,경계,WARNING,1,B01,259,11,8,10,PROBLEM_MAP_M16HUB_{day}_2014_WARNING.html,"
        f"{root}/M16HUB_{day}/PROBLEM_MAP_M16HUB_{day}_2014_WARNING.html",
        f"{d},20:14,M16A,위험,DANGER,3,A07,301,20,15,12,PROBLEM_MAP_M16A_{day}_2014_DANGER.html,"
        f"{root}/M16A_{day}/PROBLEM_MAP_M16A_{day}_2014_DANGER.html",
        f"{d},20:15,M16HUB,경계,WARNING,2,B02,255,9,6,4,,",
    ]
    if STATE["om_rev"]:                    # 잡이 그 날 파일을 다시 썼다 — 줄이 하나 늘었다
        rows.append(f"{d},20:16,M16HUB,위험,DANGER,4,B03,250,30,12,9,,")
    return ("\n".join(rows) + "\n").encode("utf-8")


class Srv(ThreadingMixIn, HTTPServer):
    daemon_threads = True


class H(BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="text/html; charset=utf-8", cookies=()):
        if isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for c in cookies:
            self.send_header("Set-Cookie", c)
        self.end_headers()
        self.wfile.write(body)

    def _cookies(self):
        raw = self.headers.get("Cookie", "")
        return dict(p.strip().split("=", 1) for p in raw.split(";") if "=" in p)

    def do_GET(self):
        path = urllib.parse.urlsplit(self.path).path
        if path == "/login":
            return self._send(200, "<html><body><form><input name='password'>"
                                   "</form></body></html>",
                              cookies=["_xsrf=abc123; Path=/"])
        if path.startswith("/api/contents"):
            if self._cookies().get("session_id") not in SESS:
                return self._send(403, "<html>Forbidden</html>")
            days = ["20260809", "20260810", "20260811"]
            return self._send(200, json.dumps({"content": [
                {"name": f"{d}_발동이벤트.csv", "size": 5243, "type": "file",
                 "last_modified": f"2026-08-{d[6:]}T23:59:00Z"} for d in days
            ] + [{"name": "메모.md", "size": 10, "type": "file"}]},
                ensure_ascii=False), "application/json")
        if path.startswith("/files/"):
            if self._cookies().get("session_id") not in SESS:
                return self._send(403, "<html>Forbidden</html>")
            name = urllib.parse.unquote(path.rsplit("/", 1)[-1])
            # 허브룸 잡 — …/oht_map/OHT_MAP_20261003.csv · …/PROBLEM_MAP/…/PROBLEM_MAP_….html
            if name.startswith("OHT_MAP_") and name.endswith(".csv") and "/oht_map/" in path:
                STATE["om"].append(name)
                return self._send(200, oht_map_csv(name[8:16]), "text/csv")
            if name.startswith("PROBLEM_MAP_") and name.endswith(".html") and "/PROBLEM_MAP/" in path:
                STATE["om"].append(name)
                return self._send(200, f"<html><body><h1>{name}</h1></body></html>")
            if not name[:8].isdigit() or name[:4] != "2026":
                return self._send(404, "<html>Not Found</html>")
            # FAB 별 파일 — …/fab분리/20260814_발동이벤트_M14.csv
            for fab in FABS:
                if name.endswith(f"발동이벤트_{fab}.csv"):
                    if "fab분리" not in urllib.parse.unquote(path):
                        return self._send(404, "<html>Not Found</html>")
                    return self._send(200, fab_csv(name[:8], fab), "text/csv")
            if not name.endswith("발동이벤트.csv"):
                return self._send(404, "<html>Not Found</html>")
            with LOCK:
                body, ok_range = STATE["csv"], STATE["range"]
            rq = self.headers.get("Range")
            STATE["hits"].append(rq or "")
            if rq and ok_range:
                r = _rng(rq, len(body))
                if r == "416":
                    return self._send(416, "<html>Range Not Satisfiable</html>")
                if r:
                    a, b = r
                    part = body[a:b + 1]
                    self.send_response(206)
                    self.send_header("Content-Type", "text/csv")
                    self.send_header("Content-Length", str(len(part)))
                    self.send_header("Content-Range",
                                     f"bytes {a}-{b}/{len(body)}")
                    self.end_headers()
                    self.wfile.write(part)
                    return
            return self._send(200, body, "text/csv")
        if path.startswith("/mock/"):
            # 시험용 손잡이 — 예측 잡이 줄을 덧붙이거나, 파일을 통째로 다시
            # 쓰거나, 서버가 Range 를 아예 안 받는 상황을 만든다.
            q = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            with LOCK:
                if path == "/mock/append":
                    STATE["csv"] += (q.get("line", ["x"])[0] + "\n").encode()
                elif path == "/mock/rewrite":
                    # 길이는 그대로 두고 **앞부분만** 바꾼다 — 꼬리 검사만으로는
                    # 절대 못 잡는 경우다 (수집이 여기서 조용히 틀릴 뻔했다)
                    STATE["csv"] = b"X" + STATE["csv"][1:]
                elif path == "/mock/reset":
                    STATE.update(csv=CSV, range=True, hits=[], om_rev=0)
                elif path == "/mock/norange":
                    STATE["range"] = False
                elif path == "/mock/om_bump":
                    STATE["om_rev"] += 1
                elif path == "/mock/truncate":
                    STATE["csv"] = STATE["csv"][:len(STATE["csv"]) // 2]
                out = json.dumps({"size": len(STATE["csv"]),
                                  "hits": STATE["hits"][-6:], "om": STATE["om"][-20:]},
                                 ensure_ascii=False)
            return self._send(200, out, "application/json")
        return self._send(404, "<html>Not Found</html>")

    def do_POST(self):
        if urllib.parse.urlsplit(self.path).path != "/login":
            return self._send(404, "nope")
        n = int(self.headers.get("Content-Length", 0))
        form = urllib.parse.parse_qs(self.rfile.read(n).decode())
        if self._cookies().get("_xsrf") != form.get("_xsrf", [""])[0]:
            return self._send(403, "<html>XSRF cookie does not match</html>")
        if form.get("password", [""])[0] != PW:
            return self._send(200, "<html><body>Invalid password or token"
                                   "<form><input name='password'></form></body></html>")
        sid = "s%d" % time.time_ns()
        SESS.add(sid)
        return self._send(200, "<html>ok</html>",
                          cookies=[f"session_id={sid}; Path=/"])

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 9911
    Srv(("127.0.0.1", port), H).serve_forever()
