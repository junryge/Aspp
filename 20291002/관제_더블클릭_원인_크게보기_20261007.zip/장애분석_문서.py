#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""사건 하나를 놓고 '왜 그 점수였나' 를 따지는 문서를 만든다.

    python 장애분석_문서.py 발동이벤트.csv --fab M14 \
        --event 11:38-14:30 --title "M14A OHT 8대 무언정지"

왜 스크립트로 만드나 — 손으로 쓰면 다음 사건 때 또 처음부터다
    2026-09-13 M14A 무언정지를 분석하면서 만들었다. 그때 손으로 표를 짜
    두었으면 다음 사건에는 아무것도 안 남는다. 숫자는 전부 발동이벤트
    CSV 에서 읽고, 임계는 hubroom_predictor.py 에서 읽는다 — 룰이 바뀌면
    문서도 따라 바뀐다.

무엇을 따지나 — 고객이 물은 그대로
    ① 조용한데 왜 높은 점수가 났나   → 켜진 룰 수와 **임계 대비 배율**
    ② 사건인데 왜 점수가 낮았나      → 사건 전후로 지표가 어느 쪽으로 갔나
    ③ 그래서 점수식을 어떻게 고치나  → ①②에서 나온 것만 적는다
"""
from __future__ import annotations

import csv
import html
import io
import os
import re
import sys
from datetime import datetime

BASE = os.path.dirname(os.path.abspath(__file__))
DOC_DIR = os.path.join(BASE, "docs")

# 룰 배점 칸 이름 — CSV 의 {FAB}_pts_{키} 와 같아야 한다
RULES = [("RA", "반송지연"), ("RA_sus", "반송지연 지속"), ("RB", "반입급증(30분)"),
         ("RB_fast", "반입급증(10분)"), ("RC", "리프터 정체"), ("RD", "저장 포화"),
         ("SLA", "4분초과"), ("SORT", "소터 대기"), ("MAXCAPA", "용량 축소")]

# 배율을 잴 수 있는 지표 — (표시이름, CSV 칸, 임계를 읽을 곳, 방향)
#   dir=+1 이면 '크면 이상', -1 이면 '작으면 이상'
METRICS = [
    ("반송시간(분)", "{f}_ra", ("TH_RA", "{f}"), +1),
    ("반입증감(30분)", "{f}_rb_diff30", ("TH_RB_30", "{f}"), +1),
    ("4분초과율(%)", "sla_{f}", ("TH_SLA_RATIO", "{f}"), +1),
    ("소터 대기", "sorter_{f}", ("TH_SORTER_WAIT", "{f}"), +1),
    ("OHT 가동률(%)", "{f}_rd_oht", ("TH_RD_OHT_UTIL", None), +1),
]


LV = ["정상", "경계", "위험", "초위험"]


def e(s):
    return html.escape(str(s))


def f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def read_th():
    """임계를 룰 원본에서 읽는다 — 문서에 손으로 적으면 어긋난다."""
    import importlib.util
    p = os.path.join(BASE, "컬럼흐름_문서.py")
    spec = importlib.util.spec_from_file_location("_cf", p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    d = m.build()
    return (d["C"] if d.get("ok") else {}), d


def th_of(C, spec, fab):
    """('TH_RA','M14') → 3.3. 없으면 None (문서에 '—' 로 적는다)."""
    key, sub = spec
    v = C.get(key)
    if v is None:
        return None
    if sub is None:
        return f(v)
    return f((v or {}).get(sub.format(f=fab)))


def josa(word, pair="은는"):
    """받침에 맞는 조사 — "초위험 가 아니라" 같은 글이 나오면 안 읽힌다.

    fab_score._josa 와 같은 규칙이다. 이 파일은 룰 원본이 없어도 돌아야
    해서(위쪽 import 를 try 로 감쌌다) 여기에 따로 둔다.
    """
    w = str(word or "").rstrip()
    if not w:
        return pair[1]
    ch = w[-1]
    if "가" <= ch <= "힣":
        return pair[0] if (ord(ch) - 0xAC00) % 28 else pair[1]
    return pair[1]


def hhmm(s):
    return str(s or "")[11:16]


def _mins(t):
    try:
        return int(t[:2]) * 60 + int(t[3:5])
    except (ValueError, IndexError):
        return None


def _shift(t, dm):
    m = (_mins(t) or 0) + dm
    m = max(0, min(24 * 60 - 1, m))
    return "%02d:%02d" % (m // 60, m % 60)


def d_lead(t, ref):
    """ref 보다 몇 분 빠른가 — 양수면 앞섰다. 못 읽으면 None."""
    a, b = _mins(t), _mins(ref)
    return None if (a is None or b is None) else (b - a)


_DT = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}")


def load_screen(path):
    """FAB 화면 표 CSV(시간,등급,종합점수,…) → {HH:MM: (등급, 종합점수)}.

    ★등급은 발동이벤트 CSV 에 없다(unified_risk_level 이 비어 있다). 그런데
      고객이 물은 건 '초위험 알람이 울렸다' 이고, 그 등급은 화면이 매긴 것이다.
      두 파일을 맞춰야 '무엇을 보고 물었는지' 와 '왜 그랬는지' 가 한 줄에 선다.
    """
    out = {}
    if not path or not os.path.exists(path):
        return out
    for r in csv.DictReader(io.open(path, encoding="utf-8-sig")):
        t = str(r.get("시간") or "")
        if _DT.match(t):
            out[t[11:16]] = (r.get("등급") or "", r.get("종합점수") or "")
    return out


def load(path):
    """CSV → 분 단위 행. **datetime 이 날짜가 아닌 행은 버린다.**

    ★실제 받은 파일에 그런 행이 2개 있었다 — reason 칸 안의 따옴표가 어긋나
      한 줄이 두 줄로 쪼개진 것이다. 그대로 두면 정렬했을 때 맨 앞에 와서
      문서의 날짜·파일명이 'M16HUB.QUE…' 가 된다. 몇 줄을 버렸는지는
      문서에 적는다 — 조용히 버리면 자료가 모자란 걸 아무도 모른다.
    """
    raw = list(csv.DictReader(io.open(path, encoding="utf-8-sig")))
    rows = [r for r in raw if _DT.match(str(r.get("datetime") or ""))]
    rows.sort(key=lambda r: r["datetime"])
    return rows, len(raw) - len(rows)


# ────────────────────────────── 분석 ──────────────────────────────
def fired(r, fab):
    """그 분에 켜진 룰 — [(이름, 배점)]."""
    out = []
    for k, nm in RULES:
        v = f(r.get("{}_pts_{}".format(fab, k)))
        if v:
            out.append((nm, v))
    return out


def ratios(r, fab, C):
    """임계를 넘은 지표의 **배율** — [(이름, 값, 임계, 배율)].

    ★이 문서의 핵심 숫자다. 배점은 0 아니면 만점이라 '얼마나 넘었나' 를
      안 보는데, 고객이 물은 게 정확히 그것이다.
    """
    out = []
    for nm, col, spec, _d in METRICS:
        v = f(r.get(col.format(f=fab)))
        th = th_of(C, spec, fab)
        if v is None or not th:
            continue
        out.append((nm, v, th, v / th))
    return out


def peak_rows(rows, fab, C, n=8):
    """지표가 제일 심했던 분 — '심한데 점수가 낮았다' 를 보이는 자리."""
    col = "{}_ra".format(fab)
    th = th_of(C, ("TH_RA", "{f}"), fab) or 1.0
    got = [(f(r.get(col)), r) for r in rows]
    got = [(v, r) for v, r in got if v is not None]
    got.sort(key=lambda x: -x[0])
    return [(v, v / th, r) for v, r in got[:n]]


def window(rows, lo, hi):
    return [r for r in rows if lo <= hhmm(r.get("datetime")) <= hi]


def avg(rows, col):
    vs = [f(r.get(col)) for r in rows]
    vs = [v for v in vs if v is not None]
    return (sum(vs) / len(vs)) if vs else None


def top_scored(rows, fab, n=1):
    col = "{}_score".format(fab)
    got = [(f(r.get(col)) or 0, r) for r in rows]
    got.sort(key=lambda x: -x[0])
    return got[:n]


def direction(rows, fab, C, before, during):
    """사건 전/중 평균과 방향 — ②의 근거."""
    out = []
    for nm, col, spec, _d in METRICS:
        c = col.format(f=fab)
        a, b = avg(before, c), avg(during, c)
        if a is None or b is None:
            continue
        out.append((nm, a, b, th_of(C, spec, fab)))
    return out


CSS = """
:root{--ink:#111827;--dim:#6b7280;--line:#e5e7eb;--acc:#4f46e5;--bad:#b91c1c;
 --ok:#047857;--warn:#b45309;--bg:#f8fafc}
*{box-sizing:border-box}
body{margin:0;background:#fff;color:var(--ink);line-height:1.7;
 font-family:"Malgun Gothic","맑은 고딕",-apple-system,system-ui,sans-serif}
.wrap{max-width:960px;margin:0 auto;padding:36px 24px 80px}
h1{font-size:26px;margin:0 0 6px}
.sub{color:var(--dim);font-size:13px;margin:0 0 28px}
h2{font-size:18px;margin:34px 0 10px;padding-top:16px;border-top:2px solid var(--ink)}
h3{font-size:14.5px;margin:20px 0 8px;color:#374151}
p,li{font-size:13.5px}
table{border-collapse:collapse;width:100%;margin:10px 0 6px;font-size:13px}
th,td{border:1px solid var(--line);padding:7px 9px;text-align:left;vertical-align:top}
th{background:var(--bg);font-weight:700;white-space:nowrap}
td.n,th.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
code,.mono{font-family:Consolas,"D2Coding",monospace;font-size:12.5px;
 background:var(--bg);padding:1px 5px;border-radius:4px}
.note{background:var(--bg);border-left:4px solid var(--acc);padding:10px 14px;
 margin:12px 0;font-size:13px}
.miss{background:#fef2f2;border-left-color:var(--bad)}
.miss b{color:var(--bad)}
.good{background:#ecfdf5;border-left-color:var(--ok)}
.flow{font-family:Consolas,"D2Coding",monospace;font-size:12.5px;
 background:var(--bg);border:1px solid var(--line);border-radius:8px;
 padding:14px 16px;white-space:pre;overflow-x:auto;line-height:1.6}
.big{font-size:20px;font-weight:800;font-variant-numeric:tabular-nums}
.dim{color:var(--dim)}
.tag{display:inline-block;font-size:11px;padding:1px 7px;border-radius:9px;
 background:var(--bg);border:1px solid var(--line);color:var(--dim)}
.bad{color:var(--bad);font-weight:700}
.warn{color:var(--warn);font-weight:700}
.okc{color:var(--ok);font-weight:700}
tr.hi td{background:#fff7ed}
tr.lo td{background:#f5f3ff}
@media print{.wrap{max-width:none;padding:0} h2{page-break-after:avoid}}
"""


def bar_svg(items, th, unit="", w=620, label=""):
    """임계 대비 배율 막대 — 숫자만으로는 '3.45배' 가 안 와닿는다."""
    if not items:
        return ""
    h = 22 * len(items) + 34
    mx = max(max(v for _t, v in items), th * 1.2) or 1.0
    X = lambda v: 118 + (w - 150) * (v / mx)
    o = ['<svg viewBox="0 0 %d %d" width="100%%" role="img" aria-label="%s">' % (w, h, e(label)),
         '<style>.b{fill:#a5b4fc}.b2{fill:#f87171}.t{font:11px "Malgun Gothic",sans-serif;fill:#374151}'
         '.n{font:700 11px Consolas,monospace;fill:#111827}.th{stroke:#b91c1c;stroke-dasharray:4 3}'
         '.thx{font:10px Consolas,monospace;fill:#b91c1c}</style>']
    o.append('<line class="th" x1="%.1f" y1="16" x2="%.1f" y2="%d"/>' % (X(th), X(th), h - 16))
    o.append('<text class="thx" x="%.1f" y="12" text-anchor="middle">임계 %s</text>'
             % (X(th), _num(th)))
    y = 24
    for t, v in items:
        o.append('<text class="t" x="0" y="%d">%s</text>' % (y + 10, e(t)))
        o.append('<rect class="%s" x="118" y="%d" width="%.1f" height="13" rx="2"/>'
                 % ("b2" if v >= th else "b", y, max(1.0, X(v) - 118)))
        o.append('<text class="n" x="%.1f" y="%d">%s%s</text>'
                 % (X(v) + 5, y + 11, _num(v), e(unit)))
        y += 22
    o.append("</svg>")
    return '<div style="margin:10px 0">' + "".join(o) + "</div>"


def ratio_svg(items, w=660, label=""):
    """룰별 '임계 대비 배율' 가로 막대 — 1.0배 선을 긋는다.

    ★이 그림 하나가 1번의 답이다. 막대가 전부 1.0배 선에 딱 붙어 있으면
      '심해서 높은 게 아니라 여럿이 걸쳐서 높은 것' 이 눈에 보인다.
    """
    if not items:
        return ""
    h = 24 * len(items) + 46
    mx = max(2.2, max(m for _n, _v, _t, m in items) * 1.15)
    X = lambda r: 150 + (w - 190) * (r / mx)
    o = ['<svg viewBox="0 0 %d %d" width="100%%" role="img" aria-label="%s">' % (w, h, e(label)),
         '<style>.t{font:11.5px "Malgun Gothic",sans-serif;fill:#374151}'
         '.n{font:700 11px Consolas,monospace}.g{stroke:#e5e7eb}'
         '.one{stroke:#b91c1c;stroke-width:1.2;stroke-dasharray:4 3}'
         '.lb{font:10px Consolas,monospace;fill:#b91c1c}'
         '.s{font:10px Consolas,monospace;fill:#9ca3af}</style>']
    for g in (1.0, 2.0):
        if g <= mx:
            o.append('<line class="%s" x1="%.1f" y1="26" x2="%.1f" y2="%d"/>'
                     % ("one" if g == 1.0 else "g", X(g), X(g), h - 18))
            o.append('<text class="%s" x="%.1f" y="20" text-anchor="middle">%.0f배</text>'
                     % ("lb" if g == 1.0 else "s", X(g), g))
    y = 32
    for nm, v, th, m in items:
        col = "#dc2626" if m >= 2 else "#f59e0b" if m >= 1.3 else "#93c5fd"
        o.append('<text class="t" x="0" y="%d">%s</text>' % (y + 11, e(nm)))
        o.append('<rect x="150" y="%d" width="%.1f" height="14" rx="2" fill="%s"/>'
                 % (y, max(1.5, X(m) - 150), col))
        o.append('<text class="n" x="%.1f" y="%d" fill="#111827">%.2f배</text>'
                 % (X(m) + 6, y + 12, m))
        o.append('<text class="s" x="%.1f" y="%d">%s / %s</text>'
                 % (X(m) + 52, y + 12, _num(v), _num(th)))
        y += 24
    o.append("</svg>")
    return '<div style="margin:12px 0">%s</div>' % "".join(o)


def series_svg(pts, mark=None, w=880, h=None, label=""):
    """사건 구간 시계열 — 점수는 막대, 지표는 선(각자 0~1 로 정규화).

    ★2번의 답이다. 점수가 낮은 채로 눌려 있는 동안 지표들이 **같이 내려가는**
      모습이 한 화면에 있어야 '왜 못 잡았나' 가 설명된다. 눈금이 서로 달라
      정규화하고, 실제 값은 양 끝에 적는다.
    """
    if not pts:
        return ""
    ts = [t for t, _sc, _ms in pts]
    n = len(pts)
    # 높이는 범례 줄 수를 따라간다 — 박아 두면 지표가 늘 때 범례가 넘친다
    h = h or max(210, 56 + 27 * len(pts[0][2] or {}))
    L, R, T, B = 46, 150, 26, 30      # 오른쪽은 범례 자리(두 줄 × 지표 수)
    iw, ih = w - L - R, h - T - B
    X = lambda i: L + iw * (i / max(1, n - 1))
    smax = max([sc for _t, sc, _m in pts] + [1.0])
    o = ['<svg viewBox="0 0 %d %d" width="100%%" role="img" aria-label="%s">' % (w, h, e(label)),
         '<style>.ax{font:10px Consolas,monospace;fill:#9ca3af}'
         '.lg{font:10.5px "Malgun Gothic",sans-serif}'
         '.bar{fill:#c7d2fe}.mk{stroke:#b91c1c;stroke-dasharray:3 3}</style>',
         '<rect x="%d" y="%d" width="%d" height="%d" fill="#fbfcfe" stroke="#e5e7eb"/>'
         % (L, T, iw, ih)]
    bw = max(2.0, iw / n * 0.62)
    for i, (_t, sc, _m) in enumerate(pts):
        hh = ih * (sc / smax)
        o.append('<rect class="bar" x="%.1f" y="%.1f" width="%.1f" height="%.1f" rx="1"/>'
                 % (X(i) - bw / 2, T + ih - hh, bw, max(0.8, hh)))
    cols = ["#dc2626", "#0891b2", "#7c3aed", "#059669", "#d97706"]
    names = [k for k in (pts[0][2] or {})]
    for j, k in enumerate(names):
        vs = [(m or {}).get(k) for _t, _s, m in pts]
        ok = [v for v in vs if v is not None]
        if len(ok) < 2:
            continue
        lo, hi = min(ok), max(ok)
        rng = (hi - lo) or 1.0
        d, first = [], True
        for i, v in enumerate(vs):
            if v is None:
                continue
            d.append("%s%.1f,%.1f" % ("M" if first else "L", X(i),
                                      T + ih * (1 - (v - lo) / rng) * 0.92 + ih * 0.04))
            first = False
        c = cols[j % len(cols)]
        o.append('<path d="%s" fill="none" stroke="%s" stroke-width="1.5" opacity=".9"/>' % (" ".join(d), c))
        yy = T + 14 + j * 27          # 이름+값범위 두 줄이라 15px 면 겹친다
        o.append('<text class="lg" x="%d" y="%d" fill="%s">%s</text>' % (L + iw + 8, yy, c, e(k)))
        o.append('<text class="ax" x="%d" y="%d">%s→%s</text>'
                 % (L + iw + 8, yy + 11, _num(ok[0]), _num(ok[-1])))
    o.append('<text class="ax" x="%d" y="%d" text-anchor="end">%s</text>' % (L - 5, T + 9, _num(smax)))
    o.append('<text class="ax" x="%d" y="%d" text-anchor="end">0</text>' % (L - 5, T + ih))
    o.append('<text class="ax" x="%d" y="%d">%s</text>' % (L, h - 10, e(ts[0])))
    o.append('<text class="ax" x="%d" y="%d" text-anchor="end">%s</text>' % (L + iw, h - 10, e(ts[-1])))
    o.append('<text class="ax" x="%d" y="%d">점수(막대)</text>' % (L + 4, T + 11))
    o.append("</svg>")
    return '<div style="margin:12px 0;overflow-x:auto">%s</div>' % "".join(o)


def compare_svg(rows, w=660, label=""):
    """지금 점수 vs 제안 점수 — 3번이 실제로 뒤집는지 눈으로 본다."""
    if not rows:
        return ""
    h = 44 * len(rows) + 40
    mx = max(max(a, b) for _n, a, b in rows) * 1.18 or 1
    X = lambda v: 152 + (w - 190) * (v / mx)
    o = ['<svg viewBox="0 0 %d %d" width="100%%" role="img" aria-label="%s">' % (w, h, e(label)),
         '<style>.t{font:11.5px "Malgun Gothic",sans-serif;fill:#374151}'
         '.n{font:700 11px Consolas,monospace;fill:#111827}'
         '.k{font:10px "Malgun Gothic",sans-serif;fill:#6b7280}</style>']
    o.append('<rect x="152" y="8" width="9" height="9" rx="2" fill="#c7d2fe"/>'
             '<text class="k" x="165" y="16">지금</text>'
             '<rect x="205" y="8" width="9" height="9" rx="2" fill="#4f46e5"/>'
             '<text class="k" x="218" y="16">제안</text>')
    y = 26
    for nm, now, new in rows:
        o.append('<text class="t" x="0" y="%d">%s</text>' % (y + 22, e(nm)))
        for k, (v, c) in enumerate(((now, "#c7d2fe"), (new, "#4f46e5"))):
            o.append('<rect x="152" y="%d" width="%.1f" height="15" rx="2" fill="%s"/>'
                     % (y + k * 18, max(1.5, X(v) - 152), c))
            o.append('<text class="n" x="%.1f" y="%d">%s</text>' % (X(v) + 6, y + 12 + k * 18, _num(v)))
        y += 44
    o.append("</svg>")
    return '<div style="margin:12px 0">%s</div>' % "".join(o)


LVC = {"정상": "#d1d5db", "경계": "#fbbf24", "위험": "#f97316", "초위험": "#dc2626"}


def day_svg(cmp2, marks=(), w=920, label=""):
    """하루 24시간을 **두 줄**로 — 위는 예측기, 아래는 운전원 화면.

    ★이 문서의 핵심 그림이다. 두 줄이 어긋나는 자리가 곧 문제다:
      위는 '3단계 확정' 인데 아래는 회색(정상) 인 구간이 하루의 절반이다.
      표로 적으면 1440줄이라 아무도 안 읽는다 — 한 장에 겹쳐 놓아야 보인다.
    """
    if not cmp2:
        return ""
    L, R, T = 92, 16, 22
    iw = w - L - R
    h = T + 104
    X = lambda t: L + iw * ((_mins(t) or 0) / 1440.0)
    bw = max(0.6, iw / 1440.0)
    o = ['<svg viewBox="0 0 %d %d" width="100%%" role="img" aria-label="%s">' % (w, h, e(label)),
         '<style>.r{font:11px "Malgun Gothic",sans-serif;fill:#374151}'
         '.x{font:9.5px Consolas,monospace;fill:#9ca3af}'
         '.m{stroke:#111827;stroke-width:1}.mt{font:9.5px "Malgun Gothic",sans-serif;fill:#111827}'
         '.k{font:10px "Malgun Gothic",sans-serif;fill:#6b7280}</style>']
    rowy = {"stage": T + 6, "fault": T + 34, "screen": T + 62}
    o.append('<text class="r" x="0" y="%d">예측기 단계</text>' % (rowy["stage"] + 12))
    o.append('<text class="r" x="0" y="%d">고장 유형 예측</text>' % (rowy["fault"] + 12))
    o.append('<text class="r" x="0" y="%d">운전원 화면</text>' % (rowy["screen"] + 12))
    for k in rowy:
        o.append('<rect x="%d" y="%d" width="%d" height="16" fill="#f3f4f6"/>'
                 % (L, rowy[k], iw))
    for t, st, ft, g, _sc in cmp2:
        x = X(t)
        if st:
            c = "#dc2626" if "3단계" in st else "#fbbf24"
            o.append('<rect x="%.2f" y="%d" width="%.2f" height="16" fill="%s"/>'
                     % (x, rowy["stage"], bw, c))
        if ft:
            c = "#7c3aed" if "OHT" in ft else "#a78bfa"
            o.append('<rect x="%.2f" y="%d" width="%.2f" height="16" fill="%s"/>'
                     % (x, rowy["fault"], bw, c))
        if g and g != "정상":
            o.append('<rect x="%.2f" y="%d" width="%.2f" height="16" fill="%s"/>'
                     % (x, rowy["screen"], bw, LVC.get(g, "#9ca3af")))
    for hh in range(0, 25, 2):
        x = L + iw * (hh * 60 / 1440.0)
        o.append('<line x1="%.1f" y1="%d" x2="%.1f" y2="%d" stroke="#e5e7eb"/>'
                 % (x, T, x, rowy["screen"] + 16))
        o.append('<text class="x" x="%.1f" y="%d" text-anchor="middle">%02d</text>'
                 % (x, h - 16, hh))
    for mt, mlab in marks:
        x = X(mt)
        o.append('<line class="m" x1="%.1f" y1="%d" x2="%.1f" y2="%d"/>'
                 % (x, T - 8, x, rowy["screen"] + 18))
        o.append('<text class="mt" x="%.1f" y="%d" text-anchor="middle">%s</text>'
                 % (min(w - 40, max(40, x)), T - 11, e(mlab)))
    o.append('<text class="k" x="%d" y="%d">'
             '단계: 빨강=3단계확정 · 노랑=1단계조기경보   |   '
             '유형: 진보라=OHT정체   |   화면: 노랑=경계 주황=위험 빨강=초위험</text>'
             % (L, h - 3))
    o.append("</svg>")
    return '<div style="margin:12px 0;overflow-x:auto">%s</div>' % "".join(o)


def runs_svg(runs, w=920, color="#dc2626", label="", total=1440):
    """구간 막대 — '몇 분 계속됐나' 를 눈으로 보이게."""
    if not runs:
        return ""
    L, R, T = 92, 16, 18
    iw = w - L - R
    h = T + 52
    X = lambda t: L + iw * ((_mins(t) or 0) / float(total))
    o = ['<svg viewBox="0 0 %d %d" width="100%%" role="img" aria-label="%s">' % (w, h, e(label)),
         '<style>.x{font:9.5px Consolas,monospace;fill:#9ca3af}'
         '.n{font:700 10px Consolas,monospace;fill:#111827}</style>',
         '<rect x="%d" y="%d" width="%d" height="18" fill="#f3f4f6"/>' % (L, T, iw)]
    for a, b, m in runs:
        x0, x1 = X(a), X(b)
        o.append('<rect x="%.1f" y="%d" width="%.1f" height="18" rx="2" fill="%s"/>'
                 % (x0, T, max(1.5, x1 - x0), color))
        if m >= 40:
            o.append('<text class="n" x="%.1f" y="%d" text-anchor="middle" fill="#fff">'
                     "%d분</text>" % ((x0 + x1) / 2, T + 13, m))
    for hh in range(0, 25, 2):
        x = L + iw * (hh * 60 / float(total))
        o.append('<line x1="%.1f" y1="%d" x2="%.1f" y2="%d" stroke="#e5e7eb"/>' % (x, T, x, T + 18))
        o.append('<text class="x" x="%.1f" y="%d" text-anchor="middle">%02d</text>' % (x, T + 32, hh))
    o.append("</svg>")
    return '<div style="margin:10px 0;overflow-x:auto">%s</div>' % "".join(o)


def _num(v):
    if v is None:
        return "—"
    return ("%.2f" % v).rstrip("0").rstrip(".") if abs(v) < 100 else "%.0f" % v


# ────────────────────────────── 문서 ──────────────────────────────
def render(d):
    fab, C, rows = d["fab"], d["C"], d["rows"]
    o = ['<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8">',
         '<meta name="viewport" content="width=device-width,initial-scale=1">',
         "<title>%s 장애 분석 — %s</title><style>%s</style></head><body><div class=wrap>"
         % (e(fab), e(d["day"]), CSS)]
    a = o.append
    a("<h1>%s</h1>" % e(d["title"]))
    a('<p class="sub">%s · 대상 <b>%s</b> · 사건 구간 <b>%s~%s</b> · '
      '자료 %s (%d분) · 임계 출처 <code>%s</code></p>'
      % (e(d["day"]), e(fab), e(d["ev_lo"]), e(d["ev_hi"]),
         e(os.path.basename(d["src"])), len(rows), e(d["rule_src"])))

    # ── 0. 한 줄 요약 ──
    hi, lo = d["hi"], d["lo"]
    a("<h2>0. 한 줄로</h2>")
    a('<div class="note"><b>하루에 사건이 둘이었습니다. 둘 다 예측기는 봤고, '
      "둘 다 화면에서는 약하게 보였습니다.</b></div>")
    a("<table><tr><th>언제</th><th>무슨 일</th><th>예측기는</th><th>화면은</th></tr>")
    _am = [b for b in d["blocks"] if b[1] <= "09:00"]
    if d["maxcapa"]:
        _long = max(d["maxcapa"], key=lambda x: x[2])
        a("<tr><td><b>오전</b><br><span class=dim>%s~%s</span></td>"
          "<td>컨베이어 <b>용량 축소</b>가 <b>%d분</b> 이어짐</td>"
          "<td class=okc>계속 감지 (%d조각으로 쪼개짐)</td>"
          '<td class="bad">마지막 %d분 덩어리에서야 초위험</td></tr>'
          % (e(_long[0]), e(_long[1]), _long[2], len(_am),
             _am[-1][3] if _am else 0))
    _h = [x for x in d["hits"] if 0 < (d_lead(x[0], d["ev_lo"]) or -1) <= 60]
    if _h:
        a("<tr><td><b>점심</b><br><span class=dim>%s~%s</span></td>"
          "<td>OHT <b>무언정지</b></td>"
          "<td class=okc><b>%s 에 유형 적중</b><br>"
          "<code>%s</code> (%d분 전)</td>"
          '<td class="bad">같은 시각 <b>%s %s점</b></td></tr>'
          % (e(d["ev_lo"]), e(d["ev_hi"]), e(_h[-1][0]), e(_h[-1][1]),
             d_lead(_h[-1][0], d["ev_lo"]), e(_h[-1][3]), e(_h[-1][4])))
    a("</table>")
    a("<h3>그리고 점수 만드는 방식에 한계가 있다</h3>")
    a('<table><tr><th>시각</th><th class=n>반송시간</th><th class=n>임계 대비</th>'
      "<th class=n>켜진 룰</th><th class=n>영역 원점수</th>"
      "<th>화면 등급</th><th class=n>화면 점수</th></tr>")
    for r, cls, note in ((lo, "lo", "심한데 낮았다"), (hi, "hi", "여럿이 걸쳐 높았다")):
        if not r:
            continue
        a('<tr class="%s"><td><b>%s</b> <span class=dim>%s</span></td>'
          '<td class=n><b>%s분</b></td><td class=n><b>%.2f배</b></td>'
          '<td class=n>%d개</td><td class=n>%s</td><td class="%s">%s</td>'
          "<td class=n><b>%s</b></td></tr>"
          % (cls, e(hhmm(r["r"].get("datetime"))), e(note), _num(r["ra"]), r["mul"],
             len(fired(r["r"], fab)), e(r["r"].get("%s_score_raw" % fab) or
                                        r["r"].get("%s_score" % fab)),
             "bad" if r.get("level") in ("초위험", "위험") else "dim",
             e(r.get("level") or "—"), e(r.get("screen") or "—")))
    a("</table>")
    a('<div class="note miss"><b>배점이 0 아니면 만점이라 두 가지를 못 본다.</b><br>'
      "① <b>얼마나 넘었나</b> — 1% 넘으나 300% 넘으나 같은 점수<br>"
      "② <b>얼마나 계속됐나</b> — 6시간 이어진 것과 1분짜리가 같은 점수</div>")

    # ── 두 자료를 나란히 ──────────────────────────────────────────
    a("<h2>두 자료를 나란히 놓으면</h2>")
    a("<p><b>발동이벤트 데이터</b>(예측기가 계산한 것)와 <b>분석 이벤트 "
      "데이터</b>(운전원 화면에 뜬 것)를 같은 시간축에 겹쳤다.</p>")
    a(day_svg(d["cmp2"], marks=[(d["ev_lo"], "사건 %s" % d["ev_lo"])] +
              ([(hhmm(hi["r"].get("datetime")), "초위험")] if hi else []),
              label="하루 24시간 — 예측기 vs 화면"))
    a('<div class="note miss"><b>위 두 줄은 거의 종일 켜져 있는데, 아래 줄은 '
      "대부분 비어 있다.</b> 예측기는 계속 무언가를 보고 있었는데 화면은 "
      "정상이었다는 뜻이다 — <b>예측 결과가 점수·등급으로 이어지지 않는다.</b> "
      "이 문서의 1)2)가 모두 이 한 장에서 나온다.</div>")

    # ── 두 자료를 잇는 자 ───────────────────────────────────────────
    # ★두 번 틀리고 세 번째에 맞춘 자리다.
    #     1판 — 등급 컷을 코드 기본값(60/71/85)으로 가정
    #     2판 — 자료의 관측 최소·최대를 컷인 양 적음
    #     3판 — 컷은 돌고 있는 설정값(밖에서 받는다), 자료로 확인만
    #   환산도 "×1.43, 상한에 닿으면 ×1.58" 이라고 썼는데 틀렸다. 배수가
    #   둘인 게 아니라 **재는 대상이 둘** 이다. 아래에 그대로 적는다.
    a("<h3>먼저 — 두 자료의 점수는 같은 자가 아니다</h3>")
    if d["denom"]:
        a("<p>같은 순간을 두 자료가 다른 수로 적는다. 배수가 다른 게 아니라 "
          "<b>재는 대상이 다르다</b>.</p>")
        a("<div class=flow>발동이벤트  %s_score   = min(%g, Σ켜진 룰 배점)"
          "      ← ALL 융합에 넣으려고 <b>자른</b> 값"
          "\n화면        종합점수      = round(Σ켜진 룰 배점 ÷ %g × 100)"
          "  ← <b>안 자른</b> 값</div>"
          % (e(fab), d["cap"] or 50, d["denom"]))
        if d["scale_n"]:
            a("<p>이 식으로 그날 <b>%d분</b>을 다시 계산해 봤다 — "
              "화면 값과 <b>어긋난 분 %d</b>.</p>"
              % (d["scale_n"], d["scale_bad"]))
    if d["split_rows"]:
        a("<p>둘이 갈라지는 건 <b>룰 합이 상한을 넘은 분</b>뿐이다. "
          "그날은 <b>%d분</b>이 그랬다.</p>" % len(d["split_rows"]))
        a("<table><tr><th>시각</th><th class=n>Σ룰(안 자른 값)</th>"
          "<th class=n>%s_score(자른 값)</th><th class=n>화면에 뜬 값</th>"
          "<th class=n>잘랐다면</th></tr>" % e(fab))
        for t, rw, a_, sc_, sc_cap in d["split_rows"]:
            a("<tr class=hi><td>%s</td><td class=n><b>%g</b></td>"
              "<td class=n>%g</td><td class=n><b>%g</b></td>"
              "<td class=n>%s</td></tr>"
              % (e(t), rw, a_, sc_, ("%g" % sc_cap) if sc_cap is not None else "—"))
        a("</table>")
        a('<div class="note"><b>화면은 상한을 적용하지 않는다 — 이건 버그가 '
          "아니다.</b> 상한 %g 은 <b>ALL 융합에 들어갈 때</b> 자르는 값이지 "
          "점수 분모가 아니다(룰 원본 <code>fab_score.risk_of()</code> 주석에 "
          "같은 경고가 적혀 있다). 두 자료를 겹쳐 볼 때 <b>이 분들만 두 수가 "
          "다르다</b>는 것만 알고 있으면 된다.</div>" % (d["cap"] or 50))
    if d["map_rows"]:
        a("<h3>그날 실제로 짝지어진 값 전부</h3>")
        a("<table><tr><th class=n>Σ룰</th><th class=n>화면 종합점수</th>"
          "<th>등급</th></tr>")
        _lv = {g: (lo_c, hi_c) for g, lo_c, hi_c, _a, _b, _c in d["grade_rows"]}
        for rw, b_ in d["map_rows"]:
            g = LV[0]
            for c, nm in zip(d["cuts"], LV[1:]):
                if b_ >= c:
                    g = nm
            a('<tr%s><td class=n>%g</td><td class=n>%g</td>'
              '<td><b class="%s">%s</b></td></tr>'
              % (" class=hi" if g == LV[-1] else "", rw, b_,
                 "bad" if g in ("위험", "초위험") else "dim", e(g)))
        a("</table>")

    # ── 등급 컷 ────────────────────────────────────────────────────
    if d["grade_rows"]:
        a("<h3>등급 컷 — 돌고 있는 값을 받아서, 자료로 확인만 한다</h3>")
        a("<p>컷을 코드 기본값으로 짐작하거나 자료의 최소·최대로 지어내지 "
          "않는다. <b>%s</b> 를 받아 그날 <b>%d분</b>을 다시 매겨 봤다 — "
          "<b>어긋난 분 %d</b>.</p>"
          % (e(" / ".join(str(c) for c in d["cuts"])), d["cut_n"], d["cut_bad"]))
        a("<table><tr><th>등급</th><th class=n>컷</th>"
          "<th class=n>그날 관측</th><th class=n>분</th></tr>")
        for g, lo_c, hi_c, mn, mx, n in d["grade_rows"]:
            a('<tr><td><b class="%s">%s</b></td><td class=n>%g ~ %g</td>'
              "<td class=n>%s</td><td class=n>%d</td></tr>"
              % ("bad" if g in ("위험", "초위험") else "", e(g), lo_c, hi_c,
                 ("%g ~ %g" % (mn, mx)) if mn is not None else "—", n))
        a("</table>")

    # ── 그래서 몇 개가 켜져야 하나 — 3)의 답이 여기서 나온다 ────────
    if d["need_rows"] and d["rule_pts"]:
        _tot = sum(p for _, _, p in d["rule_pts"])
        a("<h3>그래서 이 FAB 은 룰이 <b>몇 개</b> 켜져야 등급이 오르나"
          "<span class=tag>3)의 뿌리</span></h3>")
        a("<p>%s 에 걸린 룰은 <b>%d개</b>, 배점을 다 더하면 <b>%g</b> 다. "
          "화면 점수로는 최대 <b>%s점</b> — <b>%s 는 아무리 나빠도 100점이 "
          "안 나온다</b>.</p>"
          % (e(fab), len(d["rule_pts"]), _tot,
             ("%g" % d["screen_max"]) if d["screen_max"] is not None else "—",
             e(fab)))
        a("<table><tr><th>등급</th><th class=n>화면 컷</th>"
          "<th class=n>필요한 Σ룰</th><th class=n>최소 몇 개가 동시에</th></tr>")
        for nm, c, need, k in d["need_rows"]:
            a('<tr%s><td><b class="%s">%s</b></td><td class=n>%g~</td>'
              "<td class=n>%s / %g</td><td class=n><b>%s개</b> / %d개</td></tr>"
              % (" class=hi" if nm == LV[-1] else "",
                 "bad" if nm in ("위험", "초위험") else "", e(nm), c,
                 ("%g" % need) if need is not None else "—", _tot,
                 ("%d" % k) if k else "—", len(d["rule_pts"])))
        a("</table>")
        _crit = d["need_rows"][-1]
        a('<div class="note miss"><b>%s 이 뜨려면 룰 %d개 중 %s개가 '
          "<u>동시에</u> 켜져야 한다.</b> 그리고 배점이 0 아니면 만점이라 "
          "<b>한 지표가 아무리 심해도 혼자서는 화면 %s점</b>이 끝이다 — "
          "임계의 3배를 넘든 10배를 넘든 같다.<br><br>"
          "고객이 말한 <b>\u0027특정 한 개 지표가 심각해도 고점이 안 나온다\u0027</b> "
          "가 바로 이 표다. 3)의 제안들은 전부 이 표를 바꾸려는 것이다.</div>"
          % (e(_crit[0]), len(d["rule_pts"]),
             ("%d" % _crit[3]) if _crit[3] else "—",
             ("%g" % d["solo_max"]) if d["solo_max"] is not None else "—"))

    # ── 1) ──
    a("<h2>1) 08:00 즈음 별일 없었는데 초위험이 울린 원인</h2>")
    if hi:
        r = hi["r"]
        fr = fired(r, fab)
        a("<p><b>%s</b> — 화면 <b class=bad>%s %s점</b>. 룰 <b>%d개</b>가 "
          "한꺼번에 켜졌다.</p>"
          % (e(hhmm(r.get("datetime"))), e(hi.get("level") or "—"),
             e(hi.get("screen") or "—"), len(fr)))
        a("<div class=flow>%s\n= %s   ÷ %s × 100 = <b>화면 %s</b>%s</div>"
          % (e(" + ".join("%s(%g)" % (n, v) for n, v in fr)),
             e(r.get("%s_score_raw" % fab) or "?"), e(d["denom"] or 70),
             e(hi.get("screen") or "?"),
             ("\n  (ALL 융합에 넣을 때만 상한 %s 로 잘린다 — 화면 점수는 안 자른다)"
              % e(r.get("%s_score" % fab)))
             if (f(r.get("%s_score_raw" % fab)) or 0) > (f(r.get("%s_score" % fab)) or 0) else ""))
        rt = [x for x in ratios(r, fab, C) if x[3] >= 1.0]
        if rt:
            a("<h3>그림 1 — 켜진 값은 하나하나 보면 전부 임계 턱걸이다</h3>")
            a(ratio_svg(sorted(rt, key=lambda x: -x[3]), label="룰별 임계 대비 배율"))

        # ★여기가 처음 판에서 틀렸던 자리
        a("<h3>그런데 이것이 <b>헛알람이 아니다</b> — 6시간 쌓인 것이다</h3>")
        if d["maxcapa"]:
            a("<p>같은 시각 <code>reason</code> 원문에 이렇게 적혀 있다:</p>")
            a("<div class=flow>%s</div>"
              % e((r.get("maxcapa_signals") or "").strip() or "—"))
            a("<p><b>컨베이어 반입 상한이 정상값보다 내려가 있었다.</b> "
              "그 상태가 하루 중 이만큼 이어졌다:</p>")
            a(runs_svg(d["maxcapa"], color="#b45309", label="용량 축소 지속 구간"))
            a("<table><tr><th>구간</th><th class=n>지속</th></tr>")
            for aa, bb, mm in d["maxcapa"]:
                a("<tr><td>%s ~ %s</td><td class=n><b>%d분</b></td></tr>" % (e(aa), e(bb), mm))
            a("<tr><td><b>합계</b></td><td class=n><b>%d분</b> / 1440분</td></tr>"
              % sum(x[2] for x in d["maxcapa"]))
            a("</table>")

            # ★"컨베이어 용량 축소?" — 얼마나 내려갔는지를 값으로 적는다.
            if d["capa_rows"]:
                a("<h3>얼마나 내려갔나 — 정상치와 나란히</h3>")
                a("<p>정상값 <b>%s</b>, 룰 임계 <b>%s 이하</b>. "
                  "임계 밑으로 내려간 분에만 값이 기록된다.</p>"
                  % (e(d["capa_norm"] or "—"), e(d["capa_thr"] or "—")))
                a("<table><tr><th>기록된 값</th><th class=n>정상 대비</th>"
                  "<th class=n>분</th></tr>")
                for sig, v, n, pct in d["capa_rows"]:
                    hit = (hhmm(r.get("datetime")) and
                           sig == (r.get("maxcapa_signals") or "").strip())
                    a("<tr%s><td><code>%s</code>%s</td>"
                      "<td class=n>%s</td><td class=n>%d</td></tr>"
                      % (" class=hi" if hit else "", e(sig),
                         (" <b>← %s</b>" % e(hhmm(r.get("datetime")))) if hit else "",
                         ("%.0f%%" % (pct * 100)) if pct else "—", n))
                a("</table>")
                lowv = min((x for x in d["capa_rows"] if x[1]), key=lambda x: x[1], default=None)
                if lowv:
                    a("<p>가장 낮았을 때는 <b>%g</b> — 정상의 <b>%s</b> 였다.</p>"
                      % (lowv[1], ("%.0f%%" % (lowv[3] * 100)) if lowv[3] else "—"))

            # ★초위험을 만든 마지막 한 걸음이 이것이었다.
            if d["hi_nomc"]:
                tot, mc, wo, sc_wo, g_wo, nmin = d["hi_nomc"]
                a("<h3>그리고 이 10점이 <b>초위험을 만든 마지막 한 걸음</b>이다"
                  "<span class=tag>핵심</span></h3>")
                _lv = hi.get("level") or LV[-1]
                a("<div class=flow>켜진 룰 합계  %g   ÷ %g × 100 = 화면 %s   "
                  "→ <b>%s</b>"
                  "\n  − 용량 축소  %g"
                  "\n  =            %g   ÷ %g × 100 = 화면 %s   → <b>%s</b></div>"
                  % (tot, d["denom"] or 70, e(hi.get("screen") or "?"), e(_lv),
                     mc, wo, d["denom"] or 70,
                     ("%g" % sc_wo) if sc_wo is not None else "?",
                     e(g_wo or "—")))
                if sc_wo is not None:
                    a("<p>용량 축소 <b>%g점</b>이 없었다면 이 시각은 "
                      "<b class=bad>%s</b>%s 아니라 <b>%s</b> 에서 멈췄다 "
                      "(%s 컷 <b>%g</b>, 이 계산은 <b>%g</b>). 같은 값이 "
                      "그날 화면에 <b>%d분</b> 떠 있었다.</p>"
                      % (mc, e(_lv), josa(_lv, "이가"), e(g_wo or "—"),
                         e(LV[-1]), d["cuts"][-1], sc_wo, nmin))
                a('<div class="note miss"><b>그래서 08:00 초위험은 '
                  "\u0027설비가 멀쩡한데 울린 것\u0027 이 아니다.</b> "
                  "<b>설비 상한이 내려가 있었고</b>, 그 부담으로 다른 룰들이 "
                  "같이 임계를 넘었고, 용량 축소 배점이 마지막으로 얹혀 "
                  "초위험 컷을 넘겼다.<br><br>"
                  "<b>다만 이 룰은 \u0027사람이 손댔다\u0027 는 신호지 "
                  "\u0027멀쩡하다\u0027 는 신호가 아니다.</b> 자료에 적힌 것은 "
                  "<b>값이 얼마였는지</b>뿐이고, 누가 왜 내렸는지는 적혀 있지 "
                  "않다. 계획 정비일 수도, 방금 난 고장에 대응하는 중일 수도 "
                  "있다. 이 시각에는 반송지연·반입급증·리프터 감소·저장FULL·"
                  "SLA 가 <b>같이</b> 켜져 있었으니 <b>고장 대응 쪽</b>으로 "
                  "읽는 것이 맞다.</div>")
        if d["blocks"]:
            am = [b for b in d["blocks"] if b[1] <= "09:00"]
            if am:
                a("<h3>그림 2 — 아침 내내 켰다 껐다를 반복했다</h3>")
                a(runs_svg([(x[0], x[1], x[3]) for x in am], color="#f97316",
                           label="오전 경계 이상 덩어리"))
                a("<p>09시 전까지 <b>%d조각</b>으로 쪼개져 떴고, 마지막 "
                  "<b>%s~%s (%d분)</b> 덩어리에서 초위험이 나왔다.</p>"
                  % (len(am), e(am[-1][0]), e(am[-1][1]), am[-1][3]))
        a('<div class="note miss"><b>답:</b> "별일 없었는데" 가 아니다. '
          "<b>설비 용량이 줄어든 채로 몇 시간 돌고 있었고</b>, 그 부담이 여러 "
          "지표를 동시에 임계선 위로 밀어 올린 순간이 %s 다.<br><br>"
          "다만 <b>점수 만드는 방식은 문제가 맞다</b> — 배점이 0 아니면 "
          "만점이라 <b>1%% 넘으나 300%% 넘으나 같은 점수</b>고, "
          "<b>6시간 계속된 것과 1분짜리가 같은 점수</b>다. "
          "그래서 여러 개가 겹친 순간에만 갑자기 튄다.</div>"
          % e(hhmm(r.get("datetime"))))

    # ── 2) ──
    a("<h2>2) 사건 발생 때 점수가 낮았던 원인</h2>")
    a('<div class="note good"><b>이쪽도 못 잡은 것이 아닙니다.</b> '
      "예측기는 <b>고장 유형까지 맞혔습니다</b>. 화면에 안 떴을 뿐입니다.</div>")
    a("<h3>㉠ 최초가 아니라 <b>최종</b> 공유 시각이다 — 그 전 1시간을 보면</h3>")
    a("<p><b>%s</b> 는 <b>최종 공유</b> 시각이다. 그 앞 한 시간 동안 예측기가 "
      "무엇을 가리키고 있었는지가 이 사건의 핵심이다.</p>" % e(d["ev_lo"]))
    if d["lead_rows"]:
        a("<table><tr><th>시각</th><th>예측 고장 유형</th><th>단계</th>"
          "<th>hot_area</th><th>화면 등급</th><th class=n>화면 점수</th></tr>")
        prev = None
        for t, ft, st, hot, g, sc in d["lead_rows"]:
            key = (ft, g)
            if key == prev and t[3:] not in ("00", "15", "30", "45"):
                continue
            prev = key
            a('<tr><td>%s</td><td class="%s">%s</td><td>%s</td><td>%s</td>'
              '<td class="%s">%s</td><td class=n>%s</td></tr>'
              % (e(t), "bad" if "OHT" in ft else "dim", e(ft or "—"), e(st or "—"),
                 e(hot or "—"), "warn" if g and g != "정상" else "dim",
                 e(g or "—"), e(sc or "—")))
        a("</table>")
    if d["fab_first"]:
        _lead = d_lead(d["fab_first"], d["ev_lo"])
        a('<div class="note miss"><b>%s 부터 — 공유 %d분 전부터</b> 예측기는 '
          "줄곧 <code>%s</code> 를 가리켰습니다. 그 %d분 동안 화면은 "
          "<b>대부분 정상</b>이었고, 경계는 %s 에 처음 떴습니다.</div>"
          % (e(d["fab_first"]), _lead, e(fab), _lead,
             e(d["alerts"][0][0]) if d["alerts"] else "—"))
    hit = [h for h in d["hits"] if 0 < (d_lead(h[0], d["ev_lo"]) or -1) <= 60]
    if hit:
        t0, ft0, st0, g0, sc0 = hit[-1]
        a("<h3>㉡ 고장 유형까지 맞혔다 <span class=tag>핵심</span></h3>")
        a('<div class="flow">발동이벤트 데이터  %s  predicted_fault_type = <b>%s</b>\n'
          "                   %s  stage = %s\n\n"
          "분석 이벤트 데이터  %s  <b>%s %s점</b></div>"
          % (e(t0), e(ft0), " " * len(t0), e(st0), e(t0), e(g0), e(sc0)))
        a('<div class="note miss"><b>공유(%s)보다 %d분 빨랐습니다.</b> '
          "예측기는 <code>%s</code> — 실제로 일어난 그 고장을 집어냈는데, "
          "운전원 화면에는 <b>%s %s점</b>으로 떴습니다.</div>"
          % (e(d["ev_lo"]), d_lead(t0, d["ev_lo"]), e(ft0), e(g0), e(sc0)))

    a("<h3>㉢ 사건 추적 장치가 값을 채우지 않는다</h3>")
    a("<table><tr><th>칸</th><th>하루 %d분 동안</th><th>뜻</th></tr>" % len(rows))
    for c, nm, why in (("incident_state", "사건 상태", "사건으로 묶인 적이 한 번도 없다"),
                       ("continuity_min", "연속 분", "얼마나 계속됐는지 안 센다"),
                       ("refire_count", "재발 횟수", "몇 번 되살아났는지 안 센다")):
        v = d["dead"].get(c)
        a('<tr><td><code>%s</code></td><td class="%s">%s</td><td>%s</td></tr>'
          % (e(c), "bad" if v else "dim",
             ("계속 <b>%s</b>" % e(v)) if v else "값이 바뀜", e(why)))
    a("</table>")
    a("<h3>㉣ 단계가 늘 켜져 있어 뜻이 없다</h3>")
    a("<table><tr><th>단계</th><th class=n>분</th><th class=n>비율</th></tr>")
    tot = sum(d["stages"].values()) or 1
    for k, v in sorted(d["stages"].items(), key=lambda x: -x[1]):
        a("<tr><td>%s</td><td class=n>%d</td><td class=n>%.0f%%</td></tr>"
          % (e(k), v, 100.0 * v / tot))
    a("</table>")
    a('<div class="note miss">「3단계 확정」이 하루의 절반입니다. '
      "정상(0단계)인 분이 <b>한 분도 없습니다</b>. 늘 켜진 경보는 경보가 "
      "아닙니다.<br><br>"
      "<b>다만 범위를 분명히 합니다</b> — <code>stage_name</code> 에는 FAB "
      "접두어가 없어 <b>전체 시스템</b> 값입니다(%s 전용이 아닙니다). "
      "그래도 사건 앞 한 시간은 <code>hot_area</code> 가 %d분 중 <b>%d분</b>이 "
      "%s 라, 이 구간에 한해서는 %s 얘기로 읽어도 됩니다.</div>"
      % (e(fab), min(60, len(d["lead_rows"])), len(d["hot_near"]), e(fab), e(fab)))
    a("<h3>㉤ 13시 이후엔 지표까지 거꾸로 갔다</h3>")
    a("<table><tr><th>지표</th><th class=n>사건 전</th><th class=n>사건 중</th>"
      "<th>방향</th><th class=n>임계</th><th>룰이 켜지나</th></tr>")
    for nm, bef, dur, th in d["dirs"]:
        down = dur < bef
        on = (th is not None and dur >= th)
        a("<tr><td>%s</td><td class=n>%s</td><td class=n>%s</td>"
          '<td class="%s">%s</td><td class=n>%s</td><td class="%s">%s</td></tr>'
          % (e(nm), _num(bef), _num(dur), "okc" if down else "warn",
             "▼ 내려감" if down else "▲ 올라감", _num(th),
             "bad" if on else "dim", "켜짐" if on else "안 켜짐"))
    a("</table>")
    if d.get("series"):
        a("<h3>그림 3 — 점수가 눌려 있는 동안 지표도 같이 내려갔다</h3>")
        a(series_svg(d["series"], label="사건 구간 점수와 지표"))
    a('<div class="note miss"><b>답:</b> 무언정지로 OHT 가 줄줄이 대기했는데 '
      "점수가 안 오른 이유는 <b>지표가 오히려 좋아 보였기 때문</b>입니다.<br>"
      "㉠ <b>평균의 함정</b> — 반송시간 평균은 <b>끝난 반송</b>만 셉니다. 차가 "
      "멈추면 그 화물은 평균에 안 들어가 <b>정체가 심할수록 평균이 "
      "내려갑니다</b>.<br>"
      "㉡ 여덟 룰이 전부 <b>올라가는 것</b>만 잡습니다. 무언정지는 "
      "<b>내려가는 것</b>(가동률 93%%→76%%)으로 나타납니다.</div>")

    # ── 3) 점수 재산정 ──
    a("<h2>3) 점수 산정 방식 재설계</h2>")
    a('<div class="note"><b>고객 지적:</b> 이상 지표가 <i>많으면</i> 고점을 '
      "주는데, 특정 지표가 <i>심각</i>하면 고점을 못 준다. 한 지표가 많이 높으면 "
      "전체 점수도 많이 높아져야 한다.<br>"
      "<b>→ 1)2) 가 정확히 그 증상이다.</b> 아래가 그 답이다.</div>")
    a("<h3>㉮ 초과 배율 가중 — 1)을 고친다</h3>")
    a("<div class=flow>배율 r = 값 / 임계\n"
      "  r &lt; 1.3       →  배점 × 1.0   (턱걸이 — 지금과 같다)\n"
      "  1.3 ≤ r &lt; 2.0 →  배점 × 1.5\n"
      "  r ≥ 2.0       →  배점 × 2.5   (심각)</div>")
    if d.get("cmp"):
        a("<h3>그림 3 — 이 규칙을 그날 두 분에 적용하면</h3>")
        a(compare_svg(d["cmp"], label="지금 점수 vs 제안 점수"))
        # ★숫자를 실제로 읽어 적는다. "순서가 바로잡힌다" 고 단정했다가
        #   52 vs 55 로 여전히 뒤집히지 않은 걸 뒤늦게 봤다 — 과장하면
        #   고객이 돌려 봤을 때 바로 들통난다.
        _c = {n.split()[0]: (a_, b_) for n, a_, b_ in d["cmp"]}
        _lo = _c.get(hhmm(lo["r"].get("datetime"))) if lo else None
        _hi = _c.get(hhmm(hi["r"].get("datetime"))) if hi else None
        if _lo and _hi:
            gap0, gap1 = _hi[0] - _lo[0], _hi[1] - _lo[1]
            flipped = _lo[1] > _hi[1]
            a('<div class="note %s">심한 쪽이 <b>%s → %s</b> 로 오른다. '
              "턱걸이 쪽은 <b>%s → %s</b> 로 그대로다 — 배율이 1배라 곱해도 "
              "안 오른다.<br>두 분의 차이가 <b>%s점 → %s점</b> 으로 좁혀진다. "
              "%s</div>"
              % ("good" if flipped else "",
                 _num(_lo[0]), _num(_lo[1]), _num(_hi[0]), _num(_hi[1]),
                 _num(gap0), _num(gap1),
                 "순서가 뒤집힌다." if flipped else
                 "<b>다만 ㉮만으로는 아직 뒤집히지 않는다</b> — 뒤집으려면 "
                 "아래 ㉯(단독 심각 하한)가 같이 있어야 한다."))
    a("<h3>㉯ 단독 심각 하한 — \"한 지표가 높으면 전체도 높게\"</h3>")
    a("<p>한 룰이라도 <code>r ≥ 2.0</code> 이면 그것만으로 <b>위험 등급 하한</b>을 "
      "보장한다. 지금은 아무리 심해도 다른 룰이 안 켜지면 경계에 머문다 — "
      "%s 가 그 예다(%s배인데 <b>%s</b>).</p>"
      % (e(hhmm(lo["r"].get("datetime"))) if lo else "—",
         ("%.2f" % lo["mul"]) if lo else "—",
         e(lo.get("level") or "—") if lo else "—"))

    # ── 예측 시스템다운 개선 ─────────────────────────────────────
    a("<h3>㉰ 예측 결과를 점수에 넣는다 <span class=tag>예측 시스템의 핵심</span></h3>")
    a('<div class="note"><b>우리는 예측 시스템입니다.</b> 그런데 지금은 '
      "예측 결과(<code>predicted_fault_type</code>·단계)와 점수가 "
      "<b>따로 돕니다</b>. 2)㉡ 에서 본 대로, 고장 유형을 맞힌 그 분의 화면은 "
      "<b>정상</b>이었습니다.</div>")
    a("<table><tr><th>지금</th><th>제안</th></tr>"
      "<tr><td>예측 유형은 <code>reason</code> 에만 적힌다</td>"
      "<td><b>그 FAB 의 고장 유형을 맞히면 가산점</b> — 예측이 점수를 올린다</td></tr>"
      "<tr><td>3단계 확정이 하루의 55%%, 0단계가 0분</td>"
      "<td><b>단계를 올리는 조건을 조인다</b> — 늘 켜진 경보는 경보가 아니다</td></tr>"
      "</table>")

    a("<h3>㉱ 전조를 이어 붙인다 — 사건 추적을 되살린다</h3>")
    a('<div class="note miss"><b>%s 분 내내 '
      "<code>incident_state=IDLE · continuity_min=0 · refire_count=0</code> "
      "입니다.</b> 칸은 있는데 아무도 채우지 않습니다 — 그래서 "
      "<b>전조가 아무리 계속돼도 점수가 안 쌓입니다.</b></div>" % len(rows))
    a("<table><tr><th>칸</th><th>되살리면</th></tr>"
      "<tr><td><code>continuity_min</code></td>"
      "<td>같은 룰이 <b>N분 이어지면</b> 가산 — 3시간 계속된 것과 1분짜리가 "
      "같은 점수일 수 없다</td></tr>"
      "<tr><td><code>refire_count</code></td>"
      "<td>10분 안에 <b>다시 뜨면</b> 같은 사건으로 묶고 점수 유지 — 지금은 "
      "한 분만 정상이면 리셋된다</td></tr>"
      "<tr><td><code>incident_state</code></td>"
      "<td>IDLE → <b>감시 → 진행 → 종료</b> 로 상태를 갖는다. 사건이 "
      "이어지는 동안 등급이 안 떨어진다</td></tr></table>")
    if d["alerts"]:
        a("<p>이 규칙이면 %s 흩어진 경계 <b>%d분</b>이 <b>한 사건</b>으로 "
          "묶입니다 — 운전원 눈에 들어옵니다.</p>"
          % (e("%s~%s" % (d["alerts"][0][0], d["alerts"][-1][0])), len(d["alerts"])))

    a("<h3>㉲ 상한 재조정</h3>")
    a("<p>지금 영역점수 상한은 <b>%s</b> 다. 위 %s 의 원점수 %s 가 이미 잘렸다 — "
      "가중·가산을 넣으면 더 자주 잘려 <b>변별력이 사라진다</b>. 상한을 올리거나 "
      "정규화 방식을 바꿔야 한다.</p>"
      % (e(d["cap"]), e(hhmm(hi["r"].get("datetime"))) if hi else "—",
         e(hi["r"].get("%s_score_raw" % fab)) if hi else "—"))

    a("<h3>그리고 — 내려가는 것도 봐야 한다</h3>")
    a("<table><tr><th>신호</th><th>지금</th><th>제안</th><th>자료</th></tr>"
      "<tr><td>OHT 가동률 <b>급락</b></td><td>≥95%% 일 때만 켜짐</td>"
      "<td>평소 대비 −10%%p 급락도 이상으로</td><td class=okc>이미 있음 "
      "(<code>%s_rd_oht</code>)</td></tr>"
      "<tr><td>처리량 대비</td><td>반송시간만 봄</td>"
      "<td>시간이 내려가는데 <b>처리 건수도</b> 내려가면 좋아진 게 아니라 "
      "일이 안 되는 것</td><td class=warn>일부 (4분초과 건수로 대체 가능)</td></tr>"
      "<tr><td>무언정지 대수</td><td>없음</td><td>제일 직접적인 신호</td>"
      "<td class=bad>수집에 없음 — 요청 필요</td></tr></table>" % e(fab))

    # ── 4) 후순위 ──
    a("<h2>4) Play Back HMI 개선 <span class=tag>후순위</span></h2>")
    a("<p class=dim>요청하신 대로 이번 분석에서는 제외했습니다. "
      "1)2)3)이 정리된 뒤에 착수하는 것이 맞다고 봅니다.</p>")

    if d.get("dropped"):
        a('<div class="note miss"><b>자료에서 %d줄을 버렸습니다.</b> '
          "datetime 이 날짜가 아닌 줄입니다 — reason 칸 안의 따옴표가 어긋나 "
          "한 줄이 두 줄로 쪼개진 것으로 보입니다. 이 문서의 모든 수치는 "
          "나머지 %d분으로 계산했습니다.</div>" % (d["dropped"], len(rows)))

    a("<h2>4. 이 문서가 말하지 않는 것</h2>")
    a("<ul><li>장애의 <b>원인</b>은 다루지 않는다. 왜 OHT 가 멈췄는지가 아니라, "
      "<b>우리 점수가 왜 그 값이었는지</b>만 따진다.</li>"
      "<li>제안한 배율(1.3 / 2.0 / ×1.5 / ×2.5)은 <b>출발점</b>이다. "
      "과거 사건들에 돌려 보고 정해야 한다.</li>"
      "<li>Play Back HMI 개선은 <b>후순위</b>로 빼 두었다.</li></ul>")
    a('<p class="sub" style="margin-top:30px">이 문서는 '
      "<code>장애분석_문서.py</code> 가 발동이벤트 CSV 와 "
      "<code>hubroom_predictor.py</code> 에서 읽어 만듭니다 — 손으로 고치지 "
      "마세요. 룰·임계가 바뀌면 다시 돌리면 됩니다.</p>")
    a("</div></body></html>")
    return "".join(o)


# ────────────────────────────── 실행 ──────────────────────────────
CUTS = (36, 52, 72)        # 경계·위험·초위험 시작점 — 돌고 있는 값


def build(src, fab, ev_lo, ev_hi, title, before_min=38, screen=None,
          cuts=CUTS):
    C, meta = read_th()
    rows, dropped = load(src)
    scr = load_screen(screen)
    if not rows:
        raise SystemExit("빈 CSV: " + src)
    # ★date 칸을 믿으면 안 된다 — 이 CSV 에는 컬럼명이 밀려 들어와
    #   " M16HUB.QU…" 같은 값이 들어 있었다. datetime 앞 10자가 정답이다.
    day = (rows[0].get("datetime") or "")[:10] or "unknown"
    ev = window(rows, ev_lo, ev_hi)
    # 사건 직전 같은 길이 — 비교 기준을 임의로 고르지 않는다
    lo_h, lo_m = int(ev_lo[:2]), int(ev_lo[3:5])
    st = max(0, lo_h * 60 + lo_m - before_min)
    bf_lo, bf_hi = "%02d:%02d" % (st // 60, st % 60), ev_lo
    bf = window(rows, bf_lo, bf_hi)

    cap = None
    m = re.search(r"min\((\d+)", "")            # 상한은 룰 원본 pts 에서
    pts = (meta or {}).get("pts") or {}
    cap = pts.get("_cap")

    # ① 하루 중 제일 높았던 분 (턱걸이 다발)
    top = top_scored(rows, fab, 1)
    hi = None
    if top and top[0][0]:
        r = top[0][1]
        ra = f(r.get("%s_ra" % fab))
        th = th_of(C, ("TH_RA", "{f}"), fab) or 1.0
        hi = {"r": r, "ra": ra, "mul": (ra / th) if ra else 0, "level": None}

    # ② 지표가 제일 심했던 분 (점수는 낮았던)
    pk = peak_rows(rows, fab, C, 1)
    lo = None
    if pk:
        v, mul, r = pk[0]
        raw = f(r.get("%s_score_raw" % fab)) or 0
        ra_pts = f(r.get("%s_pts_RA" % fab)) or 0
        lo = {"r": r, "ra": v, "mul": mul, "level": None, "boost": None}

    def weighted(r):
        """제안 ㉮ 를 그 분에 실제로 적용해 본 점수.

        ★말로만 '올라갑니다' 라고 쓰면 아무도 못 믿는다. 그날 데이터에 돌려
          숫자를 보여야 한다. 배율은 룰이 보는 지표에 맞춰 잡는다 —
          RA/RA_sus 는 반송시간, RB/RB_fast 는 반입증감, SLA 는 4분초과율.
        """
        mp = {"RA": ("{f}_ra", ("TH_RA", "{f}")),
              "RA_sus": ("{f}_ra", ("TH_RA", "{f}")),
              "RB": ("{f}_rb_diff30", ("TH_RB_30", "{f}")),
              "RB_fast": ("{f}_rb_diff10", ("TH_RB_10", "{f}")),
              "SLA": ("sla_{f}", ("TH_SLA_RATIO", "{f}")),
              "SORT": ("sorter_{f}", ("TH_SORTER_WAIT", "{f}"))}
        tot = 0.0
        for k, _nm in RULES:
            pv = f(r.get("{}_pts_{}".format(fab, k))) or 0
            if not pv:
                continue
            g = 1.0
            if k in mp:
                col, spec = mp[k]
                v, th = f(r.get(col.format(f=fab))), th_of(C, spec, fab)
                if v is not None and th:
                    m = v / th
                    g = 2.5 if m >= 2.0 else 1.5 if m >= 1.3 else 1.0
            tot += pv * g
        return tot

    # 화면 등급은 CSV 에 없으면 컷으로 매긴다
    try:
        from sentinel import grade_cuts
        warn_cut = grade_cuts({"_sys": fab})[0]
    except Exception:
        warn_cut = None
    for x in (hi, lo):
        if x:
            g, sc = scr.get(hhmm(x["r"].get("datetime")), ("", ""))
            x["level"] = g or x["r"].get("unified_risk_level") or "—"
            x["screen"] = sc

    # 시계열 그림용 — 점수(막대) + 지표(선). 눈금이 달라 그림에서 정규화한다.
    SER = [("반송시간", "{f}_ra"), ("OHT가동률", "{f}_rd_oht"),
           ("4분초과율", "sla_{f}"), ("4분초과건수", "{f}_sla_cnt")]
    step = max(1, len(ev) // 90)
    series = []
    for r in ev[::step]:
        g, sc = scr.get(hhmm(r.get("datetime")), ("", ""))
        series.append((hhmm(r.get("datetime")),
                       (f(sc) if scr else f(r.get("%s_score" % fab))) or 0,
                       {nm: f(r.get(c.format(f=fab))) for nm, c in SER}))

    # 추이는 **화면 점수**로 그린다 — 운전원이 본 눈금이 그거다(없으면 영역점수)
    evs = [(hhmm(r.get("datetime")),
            f(scr.get(hhmm(r.get("datetime")), ("", ""))[1]) if scr
            else (f(r.get("%s_score" % fab)) or 0))
           for r in ev]
    evs = [(t, v if v is not None else 0) for t, v in evs][::max(1, len(ev) // 12)][:12]

    # ── 룰이 켜진 '구간' — 점점이 아니라 덩어리로 봐야 보인다 ─────────
    # ★07:58 을 '전부 턱걸이라 헛알람' 이라고 썼다가 지적을 받았다.
    #   배율만 보면 1.01배지만, **같은 것이 몇 시간 계속되는 것**이 신호다.
    #   구간으로 묶어 보면 아침 내내 용량이 줄어 있었다는 게 드러난다.
    def rule_runs(key):
        out, cur = [], None
        for r in rows:
            t = hhmm(r.get("datetime"))
            on = (f(r.get("{}_pts_{}".format(fab, key))) or 0) > 0
            if on and cur is None:
                cur = [t, t]
            elif on:
                cur[1] = t
            elif cur:
                out.append(tuple(cur)); cur = None
        if cur:
            out.append(tuple(cur))
        return [(a, b, (_mins(b) - _mins(a) + 1)) for a, b in out]

    maxcapa = rule_runs("MAXCAPA")
    # 어떤 설비가 얼마나 줄었나
    caps = {}
    for r in rows:
        sig = (r.get("maxcapa_signals") or "").strip()
        if sig:
            caps[sig] = caps.get(sig, 0) + 1

    # 화면 등급이 '정상이 아닌' 덩어리 — 몇 조각으로 쪼개졌나
    blocks, cur = [], None
    for t in sorted(scr):
        g = scr[t][0]
        on = g and g != "정상"
        if on and cur is None:
            cur = [t, t, g]
        elif on:
            cur[1] = t
            cur[2] = max(cur[2], g, key=lambda x: LV.index(x) if x in LV else 0)
        elif cur:
            blocks.append(tuple(cur)); cur = None
    if cur:
        blocks.append(tuple(cur))
    blocks = [(a, b, g, _mins(b) - _mins(a) + 1) for a, b, g in blocks]

    # ── 두 자료를 나란히 — 이 문서의 핵심 ───────────────────────────
    # 발동이벤트(예측기가 본 것) vs 화면 표(운전원이 본 것)
    cmp2 = []
    for r in rows:
        t = hhmm(r.get("datetime"))
        g, sc = scr.get(t, ("", ""))
        cmp2.append((t, r.get("stage_name") or "", r.get("predicted_fault_type") or "",
                     g, sc))

    # ── 검토에서 나온 것들 ─────────────────────────────────────────
    # ★내 분석을 내가 깨 보다가 나왔고, 한 번은 고객이 잡아 줬다.
    #   전부 '자료에 적힌 것' 이 아니라 '내가 가정한 것' 이었다.

    # (1) 등급 컷. 처음엔 코드 기본값(60/71/85)으로 가정했고, 다음엔 자료에서
    #     관측된 최소·최대를 컷인 양 적었다 — 둘 다 아니다. 컷은 돌고 있는
    #     시스템 설정값이라 **밖에서 받아** 쓰고, 자료로 맞는지 확인만 한다.
    obs = {}
    for t, (g, sc) in scr.items():
        v = f(sc)
        if g and v is not None:
            obs.setdefault(g, []).append(v)

    def _lv_of(v):
        out = LV[0]
        for c, nm in zip(cuts, LV[1:]):
            if v >= c:
                out = nm
        return out

    cut_bad, cut_n = 0, 0
    for t, (g, sc) in scr.items():
        v = f(sc)
        if g and v is not None:
            cut_n += 1
            cut_bad += (_lv_of(v) != g)
    _hi_cut = list(cuts) + [101]
    grade_rows = []
    for i, g in enumerate(LV):
        lo_c = 0 if i == 0 else cuts[i - 1]
        hi_c = _hi_cut[i] - 1
        vs = obs.get(g) or []
        grade_rows.append((g, lo_c, hi_c,
                           min(vs) if vs else None, max(vs) if vs else None, len(vs)))

    # (2) 두 자료의 점수. "화면 = 영역 × 1.43 인데 상한에 닿으면 ×1.58" 이라고
    #     썼는데 **틀렸다**. 배수가 둘인 게 아니라 **재는 대상이 다르다**.
    #       발동이벤트 {fab}_score = min(상한, Σ룰)   ← ALL 융합에 넣으려고 자른 값
    #       화면 종합점수          = round(Σ룰 ÷ 분모 × 100)  ← 자르지 않은 값
    #     fab_score.py 의 risk_of() 주석이 이미 같은 경고를 해 두고 있었다
    #     ("상한은 점수 분모가 아니다"). 읽고도 가정으로 덮었다.
    denom = None
    try:
        import fab_score as _FS
        import sentinel as _SN
        denom = _FS.area_denoms(_SN.load_config()).get(fab, float(_FS.AREA_DENOM))
    except Exception:                      # 룰 원본이 없어도 문서는 나온다
        pass

    def _screen_of(raw):
        if not denom or denom <= 0 or raw is None:
            return None
        return int(min(100, round(float(raw) * 100.0 / denom)))

    mapping, scale_n, scale_bad, split_rows = {}, 0, 0, []
    for r in rows:
        t = hhmm(r.get("datetime"))
        a_ = f(r.get("%s_score" % fab))
        rw_ = f(r.get("%s_score_raw" % fab))
        b_ = f(scr.get(t, ("", ""))[1])
        if rw_ is None:
            rw_ = a_
        if b_ is None or rw_ is None:
            continue
        mapping.setdefault(rw_, set()).add(b_)
        got = _screen_of(rw_)
        if got is not None:
            scale_n += 1
            scale_bad += (got != b_)
        if a_ is not None and rw_ != a_:
            split_rows.append((t, rw_, a_, b_, _screen_of(a_)))
    map_rows = [(rw_, sorted(v)[0]) for rw_, v in sorted(mapping.items())]

    # (3) 그래서 이 FAB 은 룰이 몇 개나 켜져야 초위험에 닿나 — 고객이 물은
    #     "한 지표가 심해도 점수가 안 오른다" 를 **수로** 적는다.
    rule_pts, need_rows, solo_max, screen_max = [], [], None, None
    try:
        import itertools as _it
        import fab_score as _FS
        _W = _FS.WATCH.get(fab) or {}
        for _r in _FS.RULES:
            _sp = _W.get(_r["code"])
            if not _sp:
                continue
            rule_pts.append((_r["code"], _r["label"],
                             _r["pts"] * (len(_sp) if _r.get("per") else 1)))
        _tot = sum(p for _, _, p in rule_pts)
        screen_max = _screen_of(_tot)
        solo_max = _screen_of(max((p for _, _, p in rule_pts), default=0))
        for _c, _nm in zip(cuts, LV[1:]):
            _need = next((v for v in range(_tot + 1)
                          if (_screen_of(v) or 0) >= _c), None)
            _k = None
            if _need is not None:
                for _n in range(1, len(rule_pts) + 1):
                    if max((sum(x[2] for x in _cb)
                            for _cb in _it.combinations(rule_pts, _n)),
                           default=0) >= _need:
                        _k = _n
                        break
            need_rows.append((_nm, _c, _need, _k))
    except Exception:
        pass

    # (3) 컨베이어 상한이 얼마나 내려가 있었나 — 값과 정상치를 나란히.
    #     ★"컨베이어 용량 축소?" 라는 물음을 받고 넣었다. 그때까지 문서는
    #       "줄어 있었다" 고만 썼지 **얼마나** 를 안 적었다. 정상치는 룰
    #       원본(fab_score.WATCH)에 적혀 있으니 손으로 옮기지 않는다.
    capa_rows, capa_norm, capa_thr = [], None, None
    try:
        import fab_score as _FS
        for _sp in (_FS.WATCH.get(fab) or {}).get("MAXCAPA") or []:
            capa_norm, capa_thr = _sp.get("normal"), _sp.get("thr")
            break
    except Exception:                      # 룰 원본이 없어도 문서는 나온다
        pass
    _V = re.compile(r"=(\d+)")
    for _sig, _n in caps.items():
        _m = _V.search(_sig)
        _v = f(_m.group(1)) if _m else None
        capa_rows.append((_sig, _v, _n,
                          (_v / capa_norm) if (_v and capa_norm) else None))
    capa_rows.sort(key=lambda x: (-(x[1] or 0)))

    # (4) 초위험에서 '용량 축소' 배점을 빼면 어떻게 되나 — 자료에 있는
    #     같은 점수의 화면값을 그대로 가져다 쓴다(지어내지 않는다).
    hi_nomc = None
    if hi:
        _fr = fired(hi["r"], fab)
        _mc = sum(v for n, v in _fr if "용량" in n)
        if _mc:
            _tot = sum(v for _, v in _fr)
            _wo = _tot - _mc
            _sc = _screen_of(_wo)
            hi_nomc = (_tot, _mc, _wo, _sc,
                       _lv_of(_sc) if _sc is not None else None,
                       sum(1 for _g2, _s2 in scr.values() if f(_s2) == _sc))

    # (5) stage_name 에는 FAB 접두어가 없다 — **전체 시스템** 값이다.
    #     다만 사건 앞 한 시간은 hot_area 가 거의 이 FAB 이라 그 구간은 유효하다.
    hot_near = [hhmm(r.get("datetime")) for r in rows
                if r.get("hot_area") == fab and
                _shift(ev_lo, -60) <= hhmm(r.get("datetime")) <= ev_lo]

    # (6) 이 FAB 을 가리킨 예측이 언제부터였나 — 선행 시간의 진짜 값
    lead_rows = []
    for r in rows:
        t = hhmm(r.get("datetime"))
        if not (_shift(ev_lo, -60) <= t <= _shift(ev_lo, 5)):
            continue
        ft = r.get("predicted_fault_type") or ""
        g, sc = scr.get(t, ("", ""))
        lead_rows.append((t, ft, r.get("stage_name") or "", r.get("hot_area") or "", g, sc))
    fab_first = next((x[0] for x in lead_rows if x[1].startswith(fab + "-")), None)

    # ── 예측 장치가 무엇을 하고 있었나 ─────────────────────────────
    # ★"전조는 계속 있었다" 는 지적을 받고 넣었다. 처음엔 점수만 보고
    #   '못 잡았다' 고 썼는데, 단계·예측유형 칸을 보니 시스템은 보고 있었다.
    #   점수에 반영이 안 됐을 뿐이다 — 진단이 통째로 달라진다.
    from collections import Counter
    stages = Counter(r.get("stage_name") or "(빈값)" for r in rows)
    dead = {c: (len(set(str(r.get(c, "")) for r in rows)) == 1 and
                str(rows[0].get(c, "")))
            for c in ("incident_state", "continuity_min", "refire_count")}
    # 사건 구간 언저리에서 '그 고장'을 맞힌 분
    kinds = ("OHT정체", "큐누적", "반송지연")
    hits = []
    for r in rows:
        t = hhmm(r.get("datetime"))
        ft = r.get("predicted_fault_type") or ""
        if ft.startswith(fab + "-") and any(k in ft for k in kinds):
            g, sc = scr.get(t, ("", ""))
            hits.append((t, ft, r.get("stage_name") or "-", g or "-", sc or "-"))
    ev_hits = [h for h in hits if d_lead(h[0], ev_lo) is not None]

    # 지금 vs 제안 — 그날의 두 분에 실제로 돌려 본다
    # 사건 언저리에서 경계 이상이 뜬 분 — '전조가 떴다' 의 증거
    alerts = []
    for t, (g, sc) in sorted(scr.items()):
        if g and g != "정상" and d_lead(t, ev_hi) is not None and t <= ev_hi:
            if d_lead(t, ev_lo) is None or t >= _shift(ev_lo, -30):
                alerts.append((t, g, sc))

    cmp_rows = []
    for x, tag in ((lo, "심했는데 낮았다"), (hi, "턱걸이인데 높았다")):
        if not x:
            continue
        r = x["r"]
        now = f(r.get("%s_score_raw" % fab)) or 0
        cmp_rows.append(("%s  %s" % (hhmm(r.get("datetime")), tag), now, weighted(r)))
    return {"fab": fab, "C": C, "rows": rows, "day": day, "src": src,
            "rule_src": os.path.basename(meta.get("path") or "hubroom_predictor.py"),
            "ev_lo": ev_lo, "ev_hi": ev_hi, "bf_lo": bf_lo, "bf_hi": bf_hi,
            "dropped": dropped,
            "dirs": direction(rows, fab, C, bf, ev), "hi": hi, "lo": lo,
            "cap": cap, "warn_cut": warn_cut, "ev_scores": evs, "title": title,
            "screen": bool(scr), "series": series, "cmp": cmp_rows,
            "stages": stages, "dead": dead, "hits": hits, "ev_hits": ev_hits,
            "alerts": alerts, "maxcapa": maxcapa, "caps": caps,
            "blocks": blocks, "cmp2": cmp2,
            "grade_rows": grade_rows, "cuts": tuple(cuts),
            "cut_bad": cut_bad, "cut_n": cut_n,
            "map_rows": map_rows, "denom": denom,
            "scale_n": scale_n, "scale_bad": scale_bad, "split_rows": split_rows,
            "rule_pts": rule_pts, "need_rows": need_rows,
            "solo_max": solo_max, "screen_max": screen_max,
            "capa_rows": capa_rows, "capa_norm": capa_norm,
            "capa_thr": capa_thr, "hi_nomc": hi_nomc, "cap": cap,
            "hot_near": hot_near, "lead_rows": lead_rows, "fab_first": fab_first}


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv:
        print(__doc__)
        return 1
    src = argv.pop(0)
    fab, ev, title, out, screen = "M14", "11:38-14:30", "", None, None
    cuts = CUTS
    while argv:
        k = argv.pop(0)
        if k == "--fab":
            fab = argv.pop(0)
        elif k == "--event":
            ev = argv.pop(0)
        elif k == "--screen":
            screen = argv.pop(0)
        elif k == "--cut":
            # 등급 컷은 돌고 있는 시스템 값이다 — 코드에 박지 않는다
            cuts = tuple(int(x) for x in argv.pop(0).replace("/", ",").split(","))
        elif k == "--title":
            title = argv.pop(0)
        elif k == "--out":
            out = argv.pop(0)
        else:
            out = k
    lo, hi = (ev.split("-") + [""])[:2]
    d = build(src, fab, lo, hi, title or ("%s 장애 분석" % fab),
              screen=screen, cuts=cuts)
    os.makedirs(DOC_DIR, exist_ok=True)
    out = out or os.path.join(DOC_DIR, "%s_%s_장애분석.html" % (fab, d["day"].replace("-", "")))
    io.open(out, "w", encoding="utf-8").write(render(d))
    print("만들었습니다:", out)
    print("  대상 %s · %d분 · 사건 %s~%s" % (fab, len(d["rows"]), lo, hi))
    if d["hi"]:
        print("  턱걸이 다발: %s (%.2f배, 원점수 %s)"
              % (hhmm(d["hi"]["r"].get("datetime")), d["hi"]["mul"],
                 d["hi"]["r"].get("%s_score_raw" % fab)))
    if d["lo"]:
        print("  심했는데 낮음: %s (%.2f배, 원점수 %s)"
              % (hhmm(d["lo"]["r"].get("datetime")), d["lo"]["mul"],
                 d["lo"]["r"].get("%s_score_raw" % fab)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
