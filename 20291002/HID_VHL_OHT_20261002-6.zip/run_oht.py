# -*- coding: utf-8 -*-
"""
run_oht.py — HID_VHL_OHT.py + Rule_hid.py 같이 돌리기

    python run_oht.py                     실시간 (계속 돈다, Ctrl+C 로 멈춤)
    python run_oht.py --no-problem-map    실시간인데 문제맵은 안 만듦
    (HID_VHL_OHT.py 의 옵션을 그대로 넘긴다)

  50초마다  HID_VHL_OHT 가 로그프레소에서 차량 보고를 받아 판정
  1분 끝나면 그 분 한 줄 → CSV  (HID_BOTTLENECK/{FAB}/HID_BOTTLENECK_{FAB}_YYYYMMDD.csv)
                          → 같은 줄 + FAB → 로그프레소 AMHS_VHL_OHT  (Rule_hid)
                          → 경계 이상이면 문제맵 (HID_BOTTLENECK/PROBLEM_MAP/…)
  돌릴 FAB 은 HID_CONFIG.json 의 RUN_FABS. 적재 설정은 config.json (Rule_LO 와 같은 파일).
  다시 켜도 이미 CSV 에 쓴 분은 다시 안 넣는다 (CSV · AMHS_VHL_OHT 중복 없음).
"""
import sys

import HID_VHL_OHT as HID
import Rule_hid


def main():
    Rule_hid.start()
    HID.SAVE_HOOKS.append(Rule_hid.upload_rows)       # CSV 에 1분 줄을 쓸 때마다 → AMHS_VHL_OHT
    try:
        HID.main()                                    # 50초마다 판정 (옵션은 HID_VHL_OHT.py 와 같다)
    except KeyboardInterrupt:
        HID.log.info("멈춤 (Ctrl+C)")
    finally:
        Rule_hid.stop()                               # 남은 줄 다 보내고 끝


if __name__ == "__main__":
    main()
