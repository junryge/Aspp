# 아틀라스 ML/BATCH → HCP ML 파이썬 이관 체크리스트

> **배포 일자: 2026-06-11 (수)**

---

## 1. 서버 점검

| No | 항목 | 내용 | 상태 |
|----|------|------|------|
| 1 | 로그프레소 API (운영) | 접속 확인, 읽기/쓰기 가능 여부 확인 | ☐ |
| 2 | 스타 (운영) | 접속 확인, 읽기 가능 여부 확인 (추후 사용 가능) | ☐ |
| 3 | 아틀라스 API 접속 확인 | ~~취소~~ **필요 없음 (제외)** — 배치로 적용 | 제외 |
| 4 | HCP 서버 라이브러리 설치 | XGBoost, oracledb, Requests **설치 완료** | ✅ |

### 환경 정보

- **Python 버전:** 3.8
- **라이브러리 버전:**
  - XGBoost `2.1.4` (ML)
  - oracledb `3.0.0` (접속)
  - Requests `2.32.3` (접속)

---

## 2. 설계 구조

```
로그프레소 데이터 조회(CSV) 생성 → 각 ML 예측 → 결과 각 테이블에 저장
```

| 단계 | 내용 |
|------|------|
| 로그프레소 데이터 조회(CSV) 생성 | 기존 JAVA CSV 생성 구조 변경 → make로 로그프레소 접속 CSV 생성으로 변경 |
| 각 ML 예측 | 각 FAB에 맞는 기존 ML 모델 사용 |
| 결과 저장 | 로그프레소 각 해당 테이블에 데이터 적재 |

---

## 3. HCP 사전 준비 작업

### 3-1. M14A_FAB 폴더 스크립트 준비 (ML, 마이그레이션)

- ✅ ML 예측: `V8.3.1_Q_TRANSFER_PREDICTOR_10m~25m` 3가지 파일 사전 준비 완료
- ✅ `QTransferDashBoardItemBatch.PY` 배치 파일 사전 준비 완료 (마이그레이션 버전)
- ✅ `QTransferPredictBatch.py` 배치 파일 사전 준비 완료 (마이그레이션 버전)

### 3-2. M16A_BR 폴더 스크립트 준비 (ML, 마이그레이션)

- ✅ ML 예측: `V8.3.1_Q_TRANSFER_PREDICTOR_10m~25m` 3가지 파일 사전 준비 완료
- ✅ `QTransferDashBoardItemBatch.PY` 배치 파일 사전 준비 완료 (마이그레이션 버전)
- ✅ `QTransferPredictBatch.py` 배치 파일 사전 준비 완료 (마이그레이션 버전)

---

## 4. 배포 당일 (6/11) 설정 변경

### 4-1. M14_FAB 폴더 CONFIG 변경

| 파일 | 항목 | 변경 전 | 변경 후 |
|------|------|---------|---------|
| `m14a_config` | 로그프레소 테이블 | `test_table2` | `ATLAS_TS_PREDICT` |
| `qtransfer_alarm_config` | `insert_table` | `test_table5` | `test_currentjob_predict` |
| `qtransfer_alarm_config` | `predict_table` | `test_table2` | `ATLAS_TS_PREDICT` |
| `qtransfer_alarm_config` | `dashboard_table` | `test_table6` | `qtransfer_dashboard` |

### 4-2. M16A_BR 폴더 CONFIG 변경

| 파일 | 항목 | 변경 전 | 변경 후 |
|------|------|---------|---------|
| `hubroom_alarm_config` | 로그프레소 테이블 | `test_table` | `test_hubroom_predict` |
| `m16br_config` | `insert_table` | `test_table` | `test_hubroom_predict` |

---

## 5. 배포 당일 (6/11) 아틀라스 BATCH 3개 중지

- ☐ `QTransferDashBoardItemBatch.JAVA` 중지
- ☐ `QTransferPredictBatch.JAVA` 중지
- ☐ `HubroomTransPredictBatch.JAVA` 중지

---

## 6. 배포 당일 (6/11) 마지막 — 파일 실행

```bash
cd /project/day/workSpace/aiu-amhas-prediction/aiu-amhas-prediction-que/pjt_shared_pool/job
python Prediction_ml.PY
```

---

## 배포 당일 작업 순서 요약

1. CONFIG 변경 (M14_FAB, M16A_BR)
2. 아틀라스 BATCH 3개 중지
3. `Prediction_ml.PY` 실행
