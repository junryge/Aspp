# CEO 멀티에이전트 연구 시스템 구현 계획

## 날짜: 2026-03-29

## 수정 파일
- `uio/index.html` 만 (app.py 변경 없음)
- 백업: `uio/index_backup_20260329.html`

## CEO 클릭 → 3가지 모드
1. 🔬 연구하기 → 에이전트 병렬 연구
2. 💻 프로그램 만들기 → 코드 에이전트 협업
3. 📊 데이터 분석하기 → 분석 에이전트 협업

## 핵심 흐름
```
CEO 모드 선택 → 과제 입력
  ↓
/api/chat으로 과제 분해 (LLM이 서브태스크 분리)
  ↓
에이전트 자동 배정 + 스킬 선택
  ↓
Promise.all로 /api/chat N개 병렬 호출
  ↓
실시간 상태 표시 (🟡작업중 → 🔵완료)
  ↓
CEO 합성 (/api/chat) → 통합 보고서
  ↓
CEO 검토: ✅승인 / 🔄수정 / ❌재작업
  ↓
수정 → 해당 에이전트 재실행 → 다시 보고
```

## 모드별 에이전트 배정
### 연구하기
- SEO: 데이터 분석 (statistical-analysis, exploratory-data-analysis)
- YOON: PPT 작성 (pptx)
- LEE: 구조도 (drawio-diagram)
- PARK: 보고서 (scientific-writing)
- KIM: 차트 (matplotlib)
- CHOI: 로그 조회 (logpresso-search)
- JUNG: 도메인 지식 (knowledge-search)

### 프로그램 만들기
- SEO: 설계 (agent-api-designer)
- KIM: 코드 작성 (agent-python-pro)
- LEE: 아키텍처 (drawio-diagram)
- PARK: 문서 (markdown-mermaid-writing)
- CHOI: 보안 (agent-security-engineer)

### 데이터 분석하기
- SEO: 통계 분석 (statistical-analysis)
- KIM: 시각화 (matplotlib)
- PARK: 보고서 (scientific-writing)
- JUNG: 도메인 지식 (knowledge-search)

## 랠프 위검 (피드백 루프)
- ✅ 승인 → 최종 확정
- 🔄 수정 요청 → 텍스트 입력 → 해당 에이전트만 재실행
- ❌ 전체 재작업 → 전체 재실행

## localStorage 저장
- 연구 상태: 과제, 모드, 에이전트 결과, 진행상황
- 복원 다이얼로그: "이전 연구가 있습니다" → 이어서/폐기

## API 모델만 허용
- GGUF 선택 시 → "연구 모드는 API 모델만 사용 가능합니다" 경고

## 실패 시 복원
- 백업파일: uio/index_backup_20260329.html
- 이 문서 참조하여 재구현 가능
