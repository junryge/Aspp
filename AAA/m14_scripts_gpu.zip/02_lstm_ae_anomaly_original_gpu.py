import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns

import missingno as msno

from itertools import groupby
from operator import itemgetter
from collections import defaultdict

from sklearn.preprocessing import StandardScaler, MinMaxScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import KNNImputer

import tensorflow as tf

# ============================================================
# GPU 설정
# ============================================================
gpus = tf.config.list_physical_devices('GPU')
if gpus:
    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        print(f"[GPU] {len(gpus)}개 감지: {[g.name for g in gpus]}")
        print(f"[GPU] Memory growth 활성화")
    except RuntimeError as e:
        print(f"[GPU] 설정 오류: {e}")
else:
    print("[GPU] GPU 없음 → CPU 모드")

# Mixed Precision (FP16 연산 → 3060에서 약 2배 속도 향상)
tf.keras.mixed_precision.set_global_policy('mixed_float16')
print(f"[GPU] Mixed precision: {tf.keras.mixed_precision.global_policy().name}")
print(f"[GPU] TF version: {tf.__version__}")
print(f"[GPU] CUDA available: {tf.test.is_built_with_cuda()}")

from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, LSTM, RepeatVector, TimeDistributed, Dense
from tensorflow.keras.callbacks import EarlyStopping

import joblib
import os
os.makedirs("model", exist_ok=True)
os.makedirs("results", exist_ok=True)  # 결과 이미지/HTML 저장 폴더

data = pd.read_csv('data/M14_20250909_202602042358.csv')
data['CURRTIME'] = data['CURRTIME'].astype(str)
data['CURRTIME'] = pd.to_datetime(data['CURRTIME'])
data.head()

# 학습 및 검증 분리
train = data[:-10080]
test = data[-10080:]

print(train.shape)
print(test.shape)

# 1분 단위 완전한 시계열 생성
train["CURRTIME"] = pd.to_datetime(train["CURRTIME"])
full_range = pd.date_range(start=train["CURRTIME"].min(), end=train["CURRTIME"].max(), freq='1min')

# 누락된 시점 확인
missing_times = full_range.difference(train["CURRTIME"])

print("[데이터] 누락된 시점 개수:", len(missing_times))
print("[데이터] 누락된 시점 예시: \n", missing_times)

missing_summary = pd.DataFrame({
    'missing_count': train.isna().sum(),
    'missing_ratio(%)': np.ceil((train.isna().sum() / len(train) * 100) * 100) / 100
})


print(missing_summary[missing_summary['missing_ratio(%)'] != 0.00])

print("=========================================================================")
print(f'결측률이 가장많은 변수: {missing_summary[missing_summary["missing_count"] == missing_summary["missing_count"].max()]}')
non_zero_missing = missing_summary[(missing_summary['missing_ratio(%)'] != 0.00) & 
                                   (missing_summary['missing_count'] == missing_summary['missing_count'].min())]
print(f'결측률이 가장 적은 변수: {non_zero_missing}')

msno.matrix(train, sparkline=True)

fig = plt.gcf()
fig.set_size_inches(14, 8)

ax = plt.gca()
ax.tick_params(axis='x', labelsize=9, rotation=45)
ax.tick_params(axis='y', labelsize=7)

plt.title('Missing Value Pattern by Sample and Variable', 
          fontsize=14, fontweight='bold', pad=20)

plt.savefig('results/01_missing_matrix.png', dpi=150, bbox_inches='tight')
print("[저장] results/01_missing_matrix.png")
plt.show()

variables = [col for col in train.columns if col != "CURRTIME"]

missing_data = train[train[variables].isna().all(axis=1)]["CURRTIME"]
missing_data

# 연속된 그룹
def group_consecutive(datetimes):
    groups = []
    for k, g in groupby(enumerate(datetimes), lambda ix: ix[0] - int(ix[1].timestamp() / 60)):
        block = list(map(itemgetter(1), g))
        groups.append(block)
    return groups

# 그룹별 정보 수집
consecutive_groups = group_consecutive(missing_data)

# 결과
g_count = defaultdict(int)
for i, group in enumerate(consecutive_groups):
    duration_minutes = (group[-1] - group[0]).total_seconds() / 60 + 1
    count = len(group)
    g_count[duration_minutes] += 1

# 출력
print("\n=== 누락 시간별 그룹 수 ===")
for duration, freq in sorted(g_count.items()):
    duration = int(duration)
    print(f"{duration}분 누락 구간 수: {freq}건")

# 중복된 행이 있는지 확인
duplicated_rows = train.duplicated()

print("중복된 행 수:", duplicated_rows.sum())
print(train[duplicated_rows])

date_col = 'CURRTIME'

dates = train[date_col]
numeric_df = train.drop(columns=[date_col])

# valid_mask
valid_mask = numeric_df.notna().any(axis=1)

filtered_numeric = numeric_df[valid_mask]
filtered_dates = dates[valid_mask]

print(f"원본 행 수: {len(train)}")
print(f"완전 결측 제거 후: {len(filtered_numeric)} 행")
print(f"제거된 행 수: {len(train) - len(filtered_numeric)} 행")

# Scaling
scaler = StandardScaler()
scaled_data = scaler.fit_transform(filtered_numeric)

# KNNImputer
imputer = KNNImputer(n_neighbors=5)
imputed_scaled = imputer.fit_transform(scaled_data)
imputed_values = scaler.inverse_transform(imputed_scaled)

train.shape
imputed_values.shape

dates_test = test[date_col]
numeric_df_test = test.drop(columns=[date_col])

# valid_mask
valid_mask_test = numeric_df_test.notna().any(axis=1)

filtered_numeric_test = numeric_df_test[valid_mask_test]
filtered_dates_test = dates_test[valid_mask_test]

print(f"원본 행 수: {len(test)}")
print(f"완전 결측 제거 후: {len(filtered_numeric_test)} 행")
print(f"제거된 행 수: {len(test) - len(filtered_numeric_test)} 행")

# Scaling
scaled_data_test = scaler.transform(filtered_numeric_test)

# KNNImputer
imputed_scaled_test = imputer.transform(scaled_data_test)
imputed_values_test = scaler.inverse_transform(imputed_scaled_test)
print(f"학습 데이터 shape: {imputed_values.shape}")
print(f"테스트 데이터 shape: {imputed_values_test.shape}")

train = imputed_values.copy()
test = imputed_values_test.copy()

def create_sequences_without_missing(X, window_size: int):
    if isinstance(X, pd.DataFrame):
        X = X.to_numpy(dtype=np.float32)
    elif not isinstance(X, np.ndarray):
        X = np.array(X, dtype=np.float32)
    
    T = X.shape[0]
    sequences = []
    indices = []
    
    for i in range(T - window_size + 1):
        window = X[i:i + window_size]
        
        if not np.isnan(window).any():
            sequences.append(window)
            indices.append(i + window_size - 1)
    
    return np.array(sequences), np.array(indices)

window_size = 10

seq_train, train_indices = create_sequences_without_missing(train, window_size)

print(f"생성된 시퀀스 수: {seq_train.shape[0]}")
print(f"인덱스 수: {len(train_indices)}")
input_dim = seq_train.shape[-1]
timesteps = seq_train.shape[1]

# ============================================================
# 모델 빌드 (GPU에서 실행)
# ============================================================
with tf.device('/GPU:0' if gpus else '/CPU:0'):
    inputs = Input(shape=(timesteps, input_dim))
    encoded = LSTM(128, activation="tanh", return_sequences=False)(inputs)

    decoded = RepeatVector(timesteps)(encoded)
    decoded = LSTM(128, activation="tanh", return_sequences=True)(decoded)
    outputs = TimeDistributed(Dense(input_dim, dtype='float32'))(decoded)  # mixed precision: 출력은 float32

    autoencoder = Model(inputs, outputs)
    autoencoder.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3), loss="mse")

autoencoder.summary()

es = EarlyStopping(monitor="val_loss", patience=5, restore_best_weights=True)

# ============================================================
# 학습 (GPU 가속)
# ============================================================
import time
train_start = time.time()

history = autoencoder.fit(
    seq_train, seq_train,
    epochs=50,
    batch_size=64,  # GPU니까 배치 사이즈 키움 (원본 16 → 64)
    validation_split=0.2,
    callbacks=[es],
    verbose=1  # 진행률 표시
)

train_elapsed = time.time() - train_start
print(f"\n[학습 완료] 소요 시간: {train_elapsed:.1f}초 ({train_elapsed/60:.1f}분)")

plt.figure(figsize=(10,4))
plt.plot(history.history["loss"], label="train")
plt.plot(history.history["val_loss"], label="val")
plt.title("Loss")
plt.xlabel("Epoch")
plt.ylabel("MSE")
plt.legend()
plt.tight_layout()
plt.savefig('results/02_training_loss.png', dpi=150, bbox_inches='tight')
print("[저장] results/02_training_loss.png")
plt.show()

# 학습 모델 저장
autoencoder.save("model/lstm_ae_m14_20260227.h5")
print("[저장] model/lstm_ae_m14_20260227.h5")

def reconstruction_error(model: tf.keras.Model, seq: np.ndarray) -> np.ndarray:
    recon = model.predict(seq, verbose=0)
    err = np.mean((seq - recon)**2, axis=(1,2))
    return err

# 재구성 오차 계산
train_err = reconstruction_error(autoencoder, seq_train)
threshold = 25000

print("train_err mean/std:", float(train_err.mean()), float(train_err.std()))
print("threshold (99%):", float(threshold))

# data index → datetime
if not isinstance(data.index, pd.DatetimeIndex):
    data['CURRTIME'] = pd.to_datetime(data['CURRTIME'])
    data = data.set_index('CURRTIME')

# 학습 데이터 세그먼트 추출
train_segment = data.iloc[:-10080]

if train_indices.max() >= len(train_segment):
    raise IndexError(f"train_indices({train_indices.max()})가 train_segment 길이({len(train_segment)})를 벗어납니다.")

plot_dates = train_segment.index[train_indices]

if not isinstance(plot_dates, pd.DatetimeIndex):
    plot_dates = pd.to_datetime(plot_dates)

# --- Train 재구성 오차 (matplotlib) ---
plt.figure(figsize=(18, 5))
plt.plot(plot_dates, train_err, label="train recon err", alpha=0.7)
plt.gca().xaxis_date()
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M'))
plt.gca().xaxis.set_major_locator(mdates.AutoDateLocator(minticks=5, maxticks=15))
plt.xticks(rotation=45, ha='right')
plt.axhline(threshold, color='red', linestyle="--", label="threshold")
plt.legend()
plt.title("Train Reconstruction Error")
plt.tight_layout()
plt.savefig('results/03_train_recon_error.png', dpi=150, bbox_inches='tight')
print("[저장] results/03_train_recon_error.png")
plt.show()

# --- Train 재구성 오차 (Plotly) ---
import plotly.graph_objects as go

anomaly_mask = train_err > threshold
anomaly_indices = train_indices[anomaly_mask]
train_segment = data.iloc[:-10080]
anomaly_times = train_segment.index[anomaly_indices]

plot_dates = train_segment.index[train_indices]

print(f"이상 감지된 포인트 수: {len(anomaly_times)}")

fig = go.Figure()

fig.add_trace(
    go.Scatter(
        x=plot_dates,
        y=train_err,
        mode='lines',
        name='Reconstruction Error',
        line=dict(color='#4A90E2', width=1.5),
        hovertemplate='<b>Time</b>: %{x|%Y-%m-%d %H:%M}<br><b>Error</b>: %{y:.6f}<extra></extra>'
    )
)

fig.add_hline(
    y=threshold,
    line_dash="dash",
    line_color="red",
    annotation_text=f"Threshold: {threshold:.6f}",
    annotation_position="top right",
    name='Threshold'
)

if len(anomaly_indices) > 0:
    anomaly_err_values = train_err[anomaly_mask]
    
    fig.add_trace(
        go.Scatter(
            x=anomaly_times,
            y=anomaly_err_values,
            mode='markers',
            name='Anomaly',
            marker=dict(
                color='red',
                size=10,
                symbol='circle',
                line=dict(width=1.5, color='black')
            ),
            hovertemplate='<b>ANOMALY</b><br>Time: %{x|%Y-%m-%d %H:%M}<br>Error: %{y:.6f}<extra></extra>'
        )
    )

fig.update_layout(
    title=dict(
        text=f'Train Reconstruction Error with Anomaly Detection<br><sup>Threshold: {threshold:.6f}</sup>',
        x=0.5,
        xanchor='center',
        font=dict(size=16)
    ),
    xaxis_title="Time",
    yaxis_title="Reconstruction Error (MSE)",
    height=500,
    width=1400,
    hovermode='x unified',
    template='plotly_white',
    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1
    )
)

fig.update_xaxes(
    tickformat='%Y-%m-%d %H:%M',
    tickangle=45,
    showgrid=True,
    gridwidth=1,
    gridcolor='lightgray'
)

fig.update_yaxes(
    showgrid=True,
    gridwidth=1,
    gridcolor='lightgray',
    zeroline=False
)

fig.write_html('results/04_train_recon_error_plotly.html')
print("[저장] results/04_train_recon_error_plotly.html")
fig.show()

# --- Train anomaly on TOTALCNT ---
anomaly_mask = train_err > threshold
anomaly_indices = train_indices[anomaly_mask]
train_segment = data.iloc[:-10080]
anomaly_times = train_segment.index[anomaly_indices]

print(f"이상 감지된 포인트 수: {len(anomaly_times)}")
print("이상 발생 시간 예시:")
print(anomaly_times[:10])

target_var = 'TOTALCNT'

plt.figure(figsize=(14, 5))

plt.plot(train_segment.index, train_segment[target_var],
         color='#4A90E2', linewidth=1, label='Normal', alpha=0.7)

if len(anomaly_times) > 0:
    anomaly_values = train_segment.loc[anomaly_times, target_var]
    
    plt.scatter(anomaly_times, anomaly_values,
                color='red', s=50, label='Anomaly', 
                zorder=5, alpha=0.8, edgecolors='black', linewidth=0.5)

plt.title(f'{target_var} - Time Series with Autoencoder Anomalies (Train)', fontsize=14)
plt.ylabel(target_var, fontsize=12)
plt.xlabel('Time', fontsize=12)

plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M'))
plt.xticks(rotation=45, ha='right')

plt.legend(loc='upper right')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('results/05_train_totalcnt_anomaly.png', dpi=150, bbox_inches='tight')
print("[저장] results/05_train_totalcnt_anomaly.png")
plt.show()

# --- Train TOTALCNT anomaly (Plotly) ---
fig = go.Figure()

fig.add_trace(
    go.Scatter(
        x=train_segment.index,
        y=train_segment[target_var],
        mode='lines',
        name=f'{target_var} (Normal)',
        line=dict(color='#4A90E2', width=1.5),
        hovertemplate=f'<b>{target_var}</b><br>Time: %{{x|%Y-%m-%d %H:%M}}<br>Value: %{{y:.4f}}<extra></extra>'
    )
)

if len(anomaly_times) > 0:
    anomaly_values = train_segment.loc[anomaly_times, target_var]
    
    fig.add_trace(
        go.Scatter(
            x=anomaly_times,
            y=anomaly_values,
            mode='markers',
            name='Anomaly',
            marker=dict(
                color='red',
                size=10,
                symbol='circle',
                line=dict(width=1.5, color='black')
            ),
            hovertemplate=f'<b>ANOMALY</b><br>Time: %{{x|%Y-%m-%d %H:%M}}<br>Value: %{{y:.4f}}<extra></extra>'
        )
    )

fig.update_layout(
    title=dict(
        text=f'{target_var} Time Series with Autoencoder Anomalies (Train)<br><sup>Threshold: {threshold:.6f}</sup>',
        x=0.5,
        xanchor='center',
        font=dict(size=16)
    ),
    xaxis_title="Time",
    yaxis_title=target_var,
    height=600,
    width=1400,
    hovermode='x unified',
    template='plotly_white',
    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1
    )
)

fig.update_xaxes(
    tickformat='%Y-%m-%d %H:%M',
    tickangle=45,
    showgrid=True,
    gridwidth=1,
    gridcolor='lightgray',
    nticks=20
)

fig.update_yaxes(
    showgrid=True,
    gridwidth=1,
    gridcolor='lightgray',
    zeroline=False
)

fig.write_html('results/06_train_totalcnt_anomaly_plotly.html')
print("[저장] results/06_train_totalcnt_anomaly_plotly.html")
fig.show()

# ============================================================
# TEST 평가
# ============================================================
seq_test, test_indices = create_sequences_without_missing(test, window_size)
test_err = reconstruction_error(autoencoder, seq_test)

threshold = 50000
is_anom = test_err > threshold

print("Detected anomalies:", int(is_anom.sum()), " / ", len(is_anom))

if not isinstance(data.index, pd.DatetimeIndex):
    data['CURRTIME'] = pd.to_datetime(data['CURRTIME'])
    data = data.set_index('CURRTIME')

test_segment = data.iloc[-10080:]

if test_indices.max() >= len(test_segment):
    raise IndexError(f"test_indices({test_indices.max()})가 test_segment 길이({len(test_segment)})를 벗어납니다.")

plot_dates_test = test_segment.index[test_indices]

if not isinstance(plot_dates_test, pd.DatetimeIndex):
    plot_dates_test = pd.to_datetime(plot_dates_test)

# --- Test 재구성 오차 (matplotlib) ---
plt.figure(figsize=(18, 5))
plt.plot(plot_dates_test, test_err, label="test recon err", alpha=0.7)
plt.gca().xaxis_date()
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M'))
plt.gca().xaxis.set_major_locator(mdates.AutoDateLocator(minticks=5, maxticks=15))
plt.xticks(rotation=45, ha='right')
plt.axhline(threshold, color='red', linestyle="--", label="threshold")
plt.legend()
plt.title("Test Reconstruction Error")
plt.tight_layout()
plt.savefig('results/07_test_recon_error.png', dpi=150, bbox_inches='tight')
print("[저장] results/07_test_recon_error.png")
plt.show()

# --- Test anomaly on TOTALCNT ---
anomaly_mask_test = test_err > threshold
anomaly_indices_test = test_indices[anomaly_mask_test]
test_segment = data.iloc[-10080:]
anomaly_times_test = test_segment.index[anomaly_indices_test]

print(f"이상 감지된 포인트 수: {len(anomaly_times_test)}")
print("이상 발생 시간 예시:")
print(anomaly_times_test[:10])

target_var = 'TOTALCNT'

plt.figure(figsize=(14, 5))

plt.plot(test_segment.index, test_segment[target_var],
         color='#4A90E2', linewidth=1, label='Normal', alpha=0.7)

if len(anomaly_times_test) > 0:
    anomaly_values_test = test_segment.loc[anomaly_times_test, target_var]
    
    plt.scatter(anomaly_times_test, anomaly_values_test,
                color='red', s=50, label='Anomaly', 
                zorder=5, alpha=0.8, edgecolors='black', linewidth=0.5)

plt.title(f'{target_var} - Time Series with Autoencoder Anomalies (Test)', fontsize=14)
plt.ylabel(target_var, fontsize=12)
plt.xlabel('Time', fontsize=12)

plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M'))
plt.xticks(rotation=45, ha='right')

plt.legend(loc='upper right')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('results/08_test_totalcnt_anomaly.png', dpi=150, bbox_inches='tight')
print("[저장] results/08_test_totalcnt_anomaly.png")
plt.show()

# --- 이상 시간 출력 ---
for i in anomaly_times:
    print(i)

# --- Feature 기여도 ---
recon = autoencoder.predict(seq_test, verbose=0)
feat_mse = np.mean((seq_test - recon)**2, axis=1)

anom_feat = feat_mse[is_anom].mean(axis=0)
top_idx = np.argsort(-anom_feat)[:10]

top_features = [(variables[i], float(anom_feat[i])) for i in top_idx]
print("\n=== Top 10 Feature Contribution ===")
for name, val in top_features:
    print(f"  {name}: {val:.2f}")

# --- Feature 기여도 바차트 ---
if top_features:
    names, values = zip(*top_features)
    
    plt.figure(figsize=(10, 6))
    plt.barh(range(len(names)), values, color='#FF6B6B', edgecolor='black', linewidth=0.5)
    plt.yticks(range(len(names)), names, fontsize=10)
    plt.xlabel('Mean MSE', fontsize=12)
    plt.title('Top 10 Feature Contribution to Anomalies', fontsize=14)
    plt.gca().invert_yaxis()
    plt.tight_layout()
    plt.savefig('results/09_feature_contribution.png', dpi=150, bbox_inches='tight')
    print("[저장] results/09_feature_contribution.png")
    plt.show()

# ============================================================
# 결과 요약
# ============================================================
print("\n" + "=" * 70)
print("[완료] 모든 결과가 results/ 폴더에 저장되었습니다.")
print("=" * 70)
print(f"  01_missing_matrix.png")
print(f"  02_training_loss.png")
print(f"  03_train_recon_error.png")
print(f"  04_train_recon_error_plotly.html")
print(f"  05_train_totalcnt_anomaly.png")
print(f"  06_train_totalcnt_anomaly_plotly.html")
print(f"  07_test_recon_error.png")
print(f"  08_test_totalcnt_anomaly.png")
print(f"  09_feature_contribution.png")
print(f"\n  학습 소요 시간: {train_elapsed:.1f}초 ({train_elapsed/60:.1f}분)")
print(f"  GPU 사용: {'Yes' if gpus else 'No (CPU)'}")
print("=" * 70)
