import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns

import missingno as msno

from itertools import groupby
from operator import itemgetter
from collections import defaultdict

from sklearn.preprocessing import StandardScaler, MinMaxScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import KNNImputer

import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, LSTM, RepeatVector, TimeDistributed, Dense
from tensorflow.keras.callbacks import EarlyStopping

import joblib
import os
os.makedirs("model", exist_ok=True)

data = pd.read_csv('data/M14_20250909_202602042358.csv')
data['CURRTIME'] = data['CURRTIME'].astype(str)
data['CURRTIME'] = pd.to_datetime(data['CURRTIME'])
data.head()

# 학습 및 검증 분리
train = data[:-10080]
test = data[-10080:]

print(train.shape)
print(test.shape)

# 1분 단위 완전한 시계열 생성
train["CURRTIME"] = pd.to_datetime(train["CURRTIME"])
full_range = pd.date_range(start=train["CURRTIME"].min(), end=train["CURRTIME"].max(), freq='1min')

# 누락된 시점 확인
missing_times = full_range.difference(train["CURRTIME"])

print("[데이터] 누락된 시점 개수:", len(missing_times))
print("[데이터] 누락된 시점 예시: \n", missing_times)

missing_summary = pd.DataFrame({
    'missing_count': train.isna().sum(),
    'missing_ratio(%)': np.ceil((train.isna().sum() / len(train) * 100) * 100) / 100
})


print(missing_summary[missing_summary['missing_ratio(%)'] != 0.00])

print("=========================================================================")
print(f'결측률이 가장많은 변수: {missing_summary[missing_summary["missing_count"] == missing_summary["missing_count"].max()]}')
non_zero_missing = missing_summary[(missing_summary['missing_ratio(%)'] != 0.00) & 
                                   (missing_summary['missing_count'] == missing_summary['missing_count'].min())]
print(f'결측률이 가장 적은 변수: {non_zero_missing}')

msno.matrix(train, sparkline=True)

# 2. Figure 크기 조정 (matrix는 가로로 길게 설정하는 것이 좋음)
fig = plt.gcf()
fig.set_size_inches(14, 8)  # 가로 14, 세로 8 (데이터 양에 따라 조정)

# 3. Axis 가져와서 라벨 조정
ax = plt.gca()

# x축: 변수명 기울이고 크기 줄이기
ax.tick_params(axis='x', labelsize=9, rotation=45)

# y축: 인덱스(행 번호/시간) 라벨 - 데이터가 많으면 생략하거나 크기만 작게
ax.tick_params(axis='y', labelsize=7)  # 또는 labelleft=False로 숨기기

# 4. 제목 추가 (영어)
plt.title('Missing Value Pattern by Sample and Variable', 
          fontsize=14, fontweight='bold', pad=20)

plt.show()

variables = [col for col in train.columns if col != "CURRTIME"]

missing_data = train[train[variables].isna().all(axis=1)]["CURRTIME"]
missing_data

# 연속된 그룹
def group_consecutive(datetimes):
    groups = []
    for k, g in groupby(enumerate(datetimes), lambda ix: ix[0] - int(ix[1].timestamp() / 60)):
        block = list(map(itemgetter(1), g))
        groups.append(block)
    return groups

# 그룹별 정보 수집
consecutive_groups = group_consecutive(missing_data)

# 결과
g_count = defaultdict(int)
for i, group in enumerate(consecutive_groups):
    duration_minutes = (group[-1] - group[0]).total_seconds() / 60 + 1  # 시작 포함
    count = len(group)
    g_count[duration_minutes] += 1  # 해당 길이의 누락 구간 수를 증가

# 출력
print("\n=== 누락 시간별 그룹 수 ===")
for duration, freq in sorted(g_count.items()):
    duration = int(duration)
    print(f"{duration}분 누락 구간 수: {freq}건")

# 중복된 행이 있는지 확인
duplicated_rows = train.duplicated()

# 중복된 행 수 출력
print("중복된 행 수:", duplicated_rows.sum())

# 중복된 행만 보기
print(train[duplicated_rows])
date_col = 'CURRTIME'  # 실제 날짜 컬럼명으로 변경하세요

dates = train[date_col]
numeric_df = train.drop(columns=[date_col])

# valid_mask
valid_mask = numeric_df.notna().any(axis=1)

filtered_numeric = numeric_df[valid_mask]
filtered_dates = dates[valid_mask]

print(f"원본 행 수: {len(train)}")
print(f"완전 결측 제거 후: {len(filtered_numeric)} 행")
print(f"제거된 행 수: {len(train) - len(filtered_numeric)} 행")

# Scaling
scaler = StandardScaler()
scaled_data = scaler.fit_transform(filtered_numeric)

# KNNImputer
imputer = KNNImputer(n_neighbors=5)
imputed_scaled = imputer.fit_transform(scaled_data)
imputed_values = scaler.inverse_transform(imputed_scaled)

train.shape
imputed_values.shape

dates_test = test[date_col]
numeric_df_test = test.drop(columns=[date_col])

# valid_mask
valid_mask_test = numeric_df_test.notna().any(axis=1)

filtered_numeric_test = numeric_df_test[valid_mask_test]
filtered_dates_test = dates_test[valid_mask_test]

print(f"원본 행 수: {len(test)}")
print(f"완전 결측 제거 후: {len(filtered_numeric_test)} 행")
print(f"제거된 행 수: {len(test) - len(filtered_numeric_test)} 행")

# Scaling
scaled_data_test = scaler.transform(filtered_numeric_test)

# KNNImputer
imputed_scaled_test = imputer.transform(scaled_data_test)
imputed_values_test = scaler.inverse_transform(imputed_scaled_test)
print(f"학습 데이터 shape: {imputed_values.shape}")
print(f"테스트 데이터 shape: {imputed_values_test.shape}")

train = imputed_values.copy()
test = imputed_values_test.copy()
def create_sequences_without_missing(X, window_size: int):
    # DataFrame이면 numpy로 변환
    if isinstance(X, pd.DataFrame):
        X = X.to_numpy(dtype=np.float32)
    elif not isinstance(X, np.ndarray):
        X = np.array(X, dtype=np.float32)
    
    T = X.shape[0]
    sequences = []
    indices = []  # 각 시퀀스의 마지막 인덱스(또는 시작 인덱스) 저장
    
    for i in range(T - window_size + 1):
        window = X[i:i + window_size]
        
        # 결측치 체크 (결측이 있는 window는 학습에서 제외(데이터 삭제 아님))
        if not np.isnan(window).any():
            sequences.append(window)
            indices.append(i + window_size - 1)  # 윈도우의 마지막 인덱스 저장
    
    return np.array(sequences), np.array(indices)
window_size = 10

# seq_train: 시퀀스 데이터, train_indices: 해당 시퀀스의 마지막 인덱스
seq_train, train_indices = create_sequences_without_missing(train, window_size)

print(f"생성된 시퀀스 수: {seq_train.shape[0]}")
print(f"인덱스 수: {len(train_indices)}")
input_dim = seq_train.shape[-1]
timesteps = seq_train.shape[1]

from tensorflow.keras.layers import Input, LSTM, RepeatVector, TimeDistributed, Dense
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import EarlyStopping
import tensorflow as tf

inputs = Input(shape=(timesteps, input_dim))
encoded = LSTM(128, activation="tanh", return_sequences=False)(inputs)

decoded = RepeatVector(timesteps)(encoded)
decoded = LSTM(128, activation="tanh", return_sequences=True)(decoded)
outputs = TimeDistributed(Dense(input_dim))(decoded)

autoencoder = Model(inputs, outputs)
autoencoder.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3), loss="mse")

es = EarlyStopping(monitor="val_loss", patience=5, restore_best_weights=True)

history = autoencoder.fit(
    seq_train, seq_train,
    epochs=50,
    batch_size=16,
    validation_split=0.2,
    callbacks=[es],
    verbose=0
)
plt.figure(figsize=(10,4))
plt.plot(history.history["loss"], label="train")
plt.plot(history.history["val_loss"], label="val")
plt.title("Loss")
plt.legend(); plt.show()
# 학습 모델 저장
autoencoder.save("model/lstm_ae_m14_20260227.h5")
def reconstruction_error(model: tf.keras.Model, seq: np.ndarray) -> np.ndarray:
    recon = model.predict(seq, verbose=0)
    # window 단위 평균 MSE
    err = np.mean((seq - recon)**2, axis=(1,2))
    return err

# 재구성 오차 계산
train_err = reconstruction_error(autoencoder, seq_train)
# threshold = np.quantile(train_err, 0.99)
threshold = 25000

print("train_err mean/std:", float(train_err.mean()), float(train_err.std()))
print("threshold (99%):", float(threshold))

# data가 원본 DataFrame이고, index가 datetime이라고 가정
# train_indices에 해당하는 날짜만 추출
if not isinstance(data.index, pd.DatetimeIndex):
    data['CURRTIME'] = pd.to_datetime(data['CURRTIME'])
    data = data.set_index('CURRTIME')  # 또는 data.index = pd.to_datetime(data.index)

# 3. 학습 데이터 세그먼트 추출
train_segment = data.iloc[:-10080]

# 4. 날짜 추출 (train_indices가 train_segment 내 위치라고 가정)
# 주의: train_indices가 너무 크면 에러 발생하므로 범위 체크
if train_indices.max() >= len(train_segment):
    raise IndexError(f"train_indices({train_indices.max()})가 train_segment 길이({len(train_segment)})를 벗어납니다.")

plot_dates = train_segment.index[train_indices]

# 명시적으로 DatetimeIndex 확인/변환
if not isinstance(plot_dates, pd.DatetimeIndex):
    plot_dates = pd.to_datetime(plot_dates)


plt.figure(figsize=(18, 5))
plt.plot(plot_dates, train_err, label="train recon err", alpha=0.7)

# 핵심: x축을 날짜 축으로 명시적 설정
plt.gca().xaxis_date()

# 원하는 형식으로 포맷터 설정
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M'))

# 눈금 간격은 자동 또는 수동 (데이터 양에 따라 조절)
plt.gca().xaxis.set_major_locator(mdates.AutoDateLocator(minticks=5, maxticks=15))

plt.xticks(rotation=45, ha='right')
plt.axhline(threshold, color='red', linestyle="--", label="threshold")
plt.legend()
plt.title("Train Reconstruction Error")
plt.tight_layout()
plt.show()
import plotly.graph_objects as go
import pandas as pd

# 1. 데이터 준비 (기존 코드와 동일)
anomaly_mask = train_err > threshold
anomaly_indices = train_indices[anomaly_mask]
train_segment = data.iloc[:-10080]
anomaly_times = train_segment.index[anomaly_indices]

# X축 날짜 (train_err와 매핑되는 시간)
plot_dates = train_segment.index[train_indices]

print(f"이상 감지된 포인트 수: {len(anomaly_times)}")

# 2. Figure 생성
fig = go.Figure()

# 3. 재구성 오차 라인 (파란색)
fig.add_trace(
    go.Scatter(
        x=plot_dates,
        y=train_err,
        mode='lines',
        name='Reconstruction Error',
        line=dict(color='#4A90E2', width=1.5),
        hovertemplate='<b>Time</b>: %{x|%Y-%m-%d %H:%M}<br><b>Error</b>: %{y:.6f}<extra></extra>'
    )
)

# 4. Threshold 수평선 (빨간 점선)
fig.add_hline(
    y=threshold,
    line_dash="dash",
    line_color="red",
    annotation_text=f"Threshold: {threshold:.6f}",
    annotation_position="top right",
    name='Threshold'
)

# 5. 이상치 포인트 (빨간 점)
if len(anomaly_indices) > 0:
    # anomaly_indices에 해당하는 오차 값 추출
    anomaly_err_values = train_err[anomaly_mask]
    
    fig.add_trace(
        go.Scatter(
            x=anomaly_times,
            y=anomaly_err_values,
            mode='markers',
            name='Anomaly',
            marker=dict(
                color='red',
                size=10,
                symbol='circle',
                line=dict(width=1.5, color='black')
            ),
            hovertemplate='<b>ANOMALY</b><br>Time: %{x|%Y-%m-%d %H:%M}<br>Error: %{y:.6f}<extra></extra>'
        )
    )

# 6. 레이아웃 설정
fig.update_layout(
    title=dict(
        text=f'Train Reconstruction Error with Anomaly Detection<br><sup>Threshold: {threshold:.6f}</sup>',
        x=0.5,
        xanchor='center',
        font=dict(size=16)
    ),
    xaxis_title="Time",
    yaxis_title="Reconstruction Error (MSE)",
    height=500,
    width=1400,
    hovermode='x unified',
    template='plotly_white',
    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1
    )
)

# 7. X축 날짜 포맷 설정
fig.update_xaxes(
    tickformat='%Y-%m-%d %H:%M',
    tickangle=45,
    showgrid=True,
    gridwidth=1,
    gridcolor='lightgray'
)

fig.update_yaxes(
    showgrid=True,
    gridwidth=1,
    gridcolor='lightgray',
    zeroline=False
)

# 8. 표시
fig.show()

# (선택) HTML 저장
# fig.write_html("train_error_plotly.html")
# 1. 이상치 마스크 생성 (threshold 초과)
anomaly_mask = train_err > threshold

# 2. 이상 윈도우의 인덱스 추출 (train_indices는 create_sequences_without_missing에서 반환한 배열)
anomaly_indices = train_indices[anomaly_mask]

# 3. 원본 데이터에서 해당 시간 추출
train_segment = data.iloc[:-10080]  # 학습에 사용된 데이터 세그먼트
anomaly_times = train_segment.index[anomaly_indices]

print(f"이상 감지된 포인트 수: {len(anomaly_times)}")
print("이상 발생 시간 예시:")
print(anomaly_times[:10])  # 상위 10개만 출력

target_var = 'TOTALCNT'

plt.figure(figsize=(14, 5))

# 1. 정상 구간 시계열 (학습 데이터 구간 기준)
plt.plot(train_segment.index, train_segment[target_var],
         color='#4A90E2', linewidth=1, label='Normal', alpha=0.7)

# 2. 이상치 포인트 표시 (빨간 점)
if len(anomaly_times) > 0:
    # anomaly_times에 해당하는 값 추출
    anomaly_values = train_segment.loc[anomaly_times, target_var]
    
    plt.scatter(anomaly_times, anomaly_values,
                color='red', s=50, label='Anomaly', 
                zorder=5, alpha=0.8, edgecolors='black', linewidth=0.5)

# 3. 포맷팅
plt.title(f'{target_var} - Time Series with Autoencoder Anomalies', fontsize=14)
plt.ylabel(target_var, fontsize=12)
plt.xlabel('Time', fontsize=12)

# 날짜 포맷 (이전에 해결한 형식 적용)
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M'))
plt.xticks(rotation=45, ha='right')

plt.legend(loc='upper right')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()
# 재구성 오차 계산
seq_test, test_indices = create_sequences_without_missing(test, window_size)
test_err = reconstruction_error(autoencoder, seq_test)

threshold = 50000
# 이상 판단
is_anom = test_err > threshold

print("Detected anomalies:", int(is_anom.sum()), " / ", len(is_anom))

# data가 원본 DataFrame이고, index가 datetime이라고 가정
# train_indices에 해당하는 날짜만 추출
if not isinstance(data.index, pd.DatetimeIndex):
    data['CURRTIME'] = pd.to_datetime(data['CURRTIME'])
    data = data.set_index('CURRTIME')  # 또는 data.index = pd.to_datetime(data.index)

# 3. 학습 데이터 세그먼트 추출
test_segment = data.iloc[-10080:]

# 4. 날짜 추출 (test_indices가 test_segment 내 위치라고 가정)
# 주의: test_indices가 너무 크면 에러 발생하므로 범위 체크
if test_indices.max() >= len(test_segment):
    raise IndexError(f"test_indices({test_indices.max()})가 test_segment 길이({len(test_segment)})를 벗어납니다.")

plot_dates_test = test_segment.index[test_indices]

# 명시적으로 DatetimeIndex 확인/변환
if not isinstance(plot_dates_test, pd.DatetimeIndex):
    plot_dates_test = pd.to_datetime(plot_dates_test)


plt.figure(figsize=(18, 5))
plt.plot(plot_dates_test, test_err, label="test recon err", alpha=0.7)

# 핵심: x축을 날짜 축으로 명시적 설정
plt.gca().xaxis_date()

# 원하는 형식으로 포맷터 설정
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M'))

# 눈금 간격은 자동 또는 수동 (데이터 양에 따라 조절)
plt.gca().xaxis.set_major_locator(mdates.AutoDateLocator(minticks=5, maxticks=15))

plt.xticks(rotation=45, ha='right')
plt.axhline(threshold, color='red', linestyle="--", label="threshold")
plt.legend()
plt.title("Test Reconstruction Error")
plt.tight_layout()
plt.show()

# 1. 이상치 마스크 생성 (threshold 초과)
anomaly_mask_test = test_err > threshold

# 2. 이상 윈도우의 인덱스 추출 (test_indices는 create_sequences_without_missing에서 반환한 배열)
anomaly_indices_test = test_indices[anomaly_mask_test]

# 3. 원본 데이터에서 해당 시간 추출
test_segment = data.iloc[-10080:]  # 학습에 사용된 데이터 세그먼트
anomaly_times_test = test_segment.index[anomaly_indices_test]

print(f"이상 감지된 포인트 수: {len(anomaly_times_test)}")
print("이상 발생 시간 예시:")
print(anomaly_times_test[:10])  # 상위 10개만 출력

target_var = 'TOTALCNT'

plt.figure(figsize=(14, 5))

# 1. 정상 구간 시계열 (학습 데이터 구간 기준)
plt.plot(test_segment.index, test_segment[target_var],
         color='#4A90E2', linewidth=1, label='Normal', alpha=0.7)

# 2. 이상치 포인트 표시 (빨간 점)
if len(anomaly_times_test) > 0:
    # anomaly_times에 해당하는 값 추출
    anomaly_values_test = test_segment.loc[anomaly_times_test, target_var]
    
    plt.scatter(anomaly_times_test, anomaly_values_test,
                color='red', s=50, label='Anomaly', 
                zorder=5, alpha=0.8, edgecolors='black', linewidth=0.5)

# 3. 포맷팅
plt.title(f'{target_var} - Time Series with Autoencoder Anomalies', fontsize=14)
plt.ylabel(target_var, fontsize=12)
plt.xlabel('Time', fontsize=12)

# 날짜 포맷 (이전에 해결한 형식 적용)
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M'))
plt.xticks(rotation=45, ha='right')

plt.legend(loc='upper right')
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()
for i in anomaly_times:
    print(i)
recon = autoencoder.predict(seq_test, verbose=0)
# (N, T, F) -> feature별 평균 MSE: (N, F)
feat_mse = np.mean((seq_test - recon)**2, axis=1)

# anomaly window들 평균 feature mse
anom_feat = feat_mse[is_anom].mean(axis=0)
top_idx = np.argsort(-anom_feat)[:10]

top_features = [(variables[i], float(anom_feat[i])) for i in top_idx]
top_features
import plotly.graph_objects as go
import pandas as pd
import numpy as np

target_var = 'TOTALCNT'

# 1. 이상치 탐지 (Train 세트 기준)
anomaly_mask = train_err > threshold
anomaly_indices = train_indices[anomaly_mask]
train_segment = data.iloc[:-10080]
anomaly_times = train_segment.index[anomaly_indices]

print(f"이상 감지된 포인트 수: {len(anomaly_times)}")

# 2. Figure 생성 (단일 플롯)
fig = go.Figure()

# 3. 정상 구간 라인 (파란색)
fig.add_trace(
    go.Scatter(
        x=train_segment.index,
        y=train_segment[target_var],
        mode='lines',
        name=f'{target_var} (Normal)',
        line=dict(color='#4A90E2', width=1.5),
        hovertemplate=f'<b>{target_var}</b><br>Time: %{{x|%Y-%m-%d %H:%M}}<br>Value: %{{y:.4f}}<extra></extra>'
    )
)

# 4. 이상치 포인트 (빨간 점)
if len(anomaly_times) > 0:
    # anomaly_times에 해당하는 값 추출
    anomaly_values = train_segment.loc[anomaly_times, target_var]
    
    fig.add_trace(
        go.Scatter(
            x=anomaly_times,
            y=anomaly_values,
            mode='markers',
            name='Anomaly',
            marker=dict(
                color='red',
                size=10,
                symbol='circle',
                line=dict(width=1.5, color='black')
            ),
            hovertemplate=f'<b>ANOMALY</b><br>Time: %{{x|%Y-%m-%d %H:%M}}<br>Value: %{{y:.4f}}<extra></extra>'
        )
    )

# 5. 레이아웃 설정
fig.update_layout(
    title=dict(
        text=f'{target_var} Time Series with Autoencoder Anomalies<br><sup>Threshold: {threshold:.6f}</sup>',
        x=0.5,
        xanchor='center',
        font=dict(size=16)
    ),
    xaxis_title="Time",
    yaxis_title=target_var,
    height=600,  # 단일 플롯이므로 고정 높이 (여러 변수일 때보다 작게)
    width=1400,
    hovermode='x unified',  # x축 기준으로 모든 y값 툴팁 표시
    template='plotly_white',
    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1
    )
)

# 6. X축 날짜 포맷 설정 (요청하신 형식: 연-월-일 시:분)
fig.update_xaxes(
    tickformat='%Y-%m-%d %H:%M',
    tickangle=45,
    showgrid=True,
    gridwidth=1,
    gridcolor='lightgray',
    nticks=20  # 눈금 개수 제한
)

fig.update_yaxes(
    showgrid=True,
    gridwidth=1,
    gridcolor='lightgray',
    zeroline=False
)

# 7. 표시 및 저장
fig.show()

# HTML 파일로 저장 (선택)
# fig.write_html("totalcnt_anomaly_plotly.html")
