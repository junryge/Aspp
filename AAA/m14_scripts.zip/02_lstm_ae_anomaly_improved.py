"""
M14 FAB AMHS LSTM Autoencoder 이상탐지 (개선 버전)
===================================================
개선 사항:
  1. train/test 변수 덮어쓰기 문제 해결
     (원본: train DataFrame → imputed ndarray로 덮어써서 이후 .shape 등 혼란)
  2. threshold를 train 99th percentile 기반 자동 산출
     (원본: train=25000, test=50000 하드코딩 → 일관성 없음)
  3. 모델 구조 개선: Dropout 추가, 2-layer encoder/decoder
  4. 재현성: random seed 고정
  5. scaler/imputer 저장하여 추후 재사용 가능
  6. 함수화로 구조 정리 (EDA, 전처리, 학습, 평가 분리)
  7. feature 기여도 분석 시각화 추가
  8. CSV 인코딩 자동 감지
  9. 모델 저장 형식: .h5 → SavedModel (.keras) 권장
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import missingno as msno
import plotly.graph_objects as go

from itertools import groupby
from operator import itemgetter
from collections import defaultdict

from sklearn.preprocessing import StandardScaler
from sklearn.impute import KNNImputer

import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import (
    Input, LSTM, RepeatVector, TimeDistributed, Dense, Dropout
)
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau

import joblib
import os

# ============================================================
# 재현성
# ============================================================
SEED = 42
np.random.seed(SEED)
tf.random.set_seed(SEED)

# ============================================================
# 설정
# ============================================================
DATA_PATH = 'data/M14_20250909_202602042358.csv'
MODEL_DIR = 'model'
OUTPUT_DIR = 'output_anomaly'
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

TEST_SIZE = 10080          # 마지막 7일 (1분 단위)
WINDOW_SIZE = 10           # 시퀀스 길이
KNN_NEIGHBORS = 5          # KNNImputer k
THRESHOLD_PERCENTILE = 99  # 재구성 오차 threshold (train 기준)

# 모델 하이퍼파라미터
LSTM_UNITS_1 = 128
LSTM_UNITS_2 = 64
DROPOUT_RATE = 0.2
LEARNING_RATE = 1e-3
EPOCHS = 50
BATCH_SIZE = 16
PATIENCE = 5


# ============================================================
# 유틸 함수
# ============================================================
def load_csv_auto_encoding(path: str) -> pd.DataFrame:
    """UTF-8 → CP949 → EUC-KR 순서로 인코딩 자동 감지."""
    for enc in ['utf-8', 'cp949', 'euc-kr']:
        try:
            df = pd.read_csv(path, encoding=enc, on_bad_lines='skip', low_memory=False)
            print(f"[로드] 인코딩={enc}, shape={df.shape}")
            return df
        except (UnicodeDecodeError, UnicodeError):
            continue
    raise ValueError(f"CSV 로드 실패: {path}")


def group_consecutive_missing(datetimes):
    """연속 결측 그룹핑."""
    groups = []
    for k, g in groupby(enumerate(datetimes), lambda ix: ix[0] - int(ix[1].timestamp() / 60)):
        block = list(map(itemgetter(1), g))
        groups.append(block)
    return groups


def create_sequences(X: np.ndarray, window_size: int):
    """
    슬라이딩 윈도우 시퀀스 생성. NaN 포함 윈도우 제외.
    Returns: (sequences, indices) - indices는 각 윈도우의 마지막 행 인덱스
    """
    if isinstance(X, pd.DataFrame):
        X = X.to_numpy(dtype=np.float32)
    elif not isinstance(X, np.ndarray):
        X = np.array(X, dtype=np.float32)

    T = X.shape[0]
    sequences, indices = [], []

    for i in range(T - window_size + 1):
        window = X[i:i + window_size]
        if not np.isnan(window).any():
            sequences.append(window)
            indices.append(i + window_size - 1)

    return np.array(sequences), np.array(indices)


def reconstruction_error(model: tf.keras.Model, sequences: np.ndarray) -> np.ndarray:
    """윈도우 단위 평균 MSE 재구성 오차."""
    recon = model.predict(sequences, verbose=0)
    return np.mean((sequences - recon) ** 2, axis=(1, 2))


def feature_contribution(model: tf.keras.Model, sequences: np.ndarray,
                          is_anomaly: np.ndarray, feature_names: list):
    """이상 윈도우의 feature별 MSE 기여도 계산."""
    recon = model.predict(sequences, verbose=0)
    feat_mse = np.mean((sequences - recon) ** 2, axis=1)  # (N, F)

    if is_anomaly.sum() == 0:
        print("[경고] 이상 윈도우 없음 → feature 기여도 분석 불가")
        return []

    anom_feat = feat_mse[is_anomaly].mean(axis=0)
    top_idx = np.argsort(-anom_feat)[:10]
    result = [(feature_names[i], float(anom_feat[i])) for i in top_idx]
    return result


# ============================================================
# EDA 단계
# ============================================================
def run_eda(df_train: pd.DataFrame):
    """학습 데이터에 대한 간단 EDA."""
    print(f"\n{'='*70}")
    print(f"[EDA] Train shape: {df_train.shape}")

    # 시계열 누락
    full_range = pd.date_range(
        start=df_train["CURRTIME"].min(),
        end=df_train["CURRTIME"].max(),
        freq='1min'
    )
    missing = full_range.difference(df_train["CURRTIME"])
    print(f"[EDA] 시계열 누락: {len(missing)}개")

    # 결측 요약
    summary = pd.DataFrame({
        'missing_count': df_train.isna().sum(),
        'missing_ratio(%)': np.round(df_train.isna().sum() / len(df_train) * 100, 2)
    })
    has_missing = summary[summary['missing_ratio(%)'] > 0]
    if len(has_missing) > 0:
        print(f"[EDA] 결측 있는 변수: {len(has_missing)}개")
        print(has_missing.head(10).to_string())

    # 연속 결측 구간
    variables = [c for c in df_train.columns if c != 'CURRTIME']
    all_missing = df_train[df_train[variables].isna().all(axis=1)]['CURRTIME']
    if len(all_missing) > 0:
        groups = group_consecutive_missing(all_missing)
        g_count = defaultdict(int)
        for grp in groups:
            dur = int((grp[-1] - grp[0]).total_seconds() / 60 + 1)
            g_count[dur] += 1
        print("\n[EDA] 연속 결측 구간:")
        for dur, freq in sorted(g_count.items()):
            print(f"  {dur}분: {freq}건")

    # 중복
    dup_count = df_train.duplicated().sum()
    print(f"[EDA] 중복 행: {dup_count}")

    # missingno
    msno.matrix(df_train, sparkline=True)
    plt.gcf().set_size_inches(14, 8)
    plt.title('Missing Value Pattern (Train)', fontsize=14, fontweight='bold')
    plt.savefig(os.path.join(OUTPUT_DIR, 'missing_matrix_train.png'), dpi=150, bbox_inches='tight')
    plt.show()


# ============================================================
# 전처리 단계
# ============================================================
def preprocess(df: pd.DataFrame, scaler=None, imputer=None, fit: bool = True):
    """
    완전 결측 제거 → StandardScaler → KNNImputer.
    fit=True: scaler/imputer를 fit_transform (학습용)
    fit=False: transform만 (테스트용)
    Returns: (imputed_values, valid_dates, scaler, imputer)
    """
    dates = df['CURRTIME'].copy()
    numeric = df.drop(columns=['CURRTIME'])

    valid_mask = numeric.notna().any(axis=1)
    filtered = numeric[valid_mask]
    filtered_dates = dates[valid_mask]

    print(f"  원본: {len(df)} → 유효: {len(filtered)} (제거: {len(df) - len(filtered)})")

    if fit:
        scaler = StandardScaler()
        scaled = scaler.fit_transform(filtered)
        imputer = KNNImputer(n_neighbors=KNN_NEIGHBORS)
        imputed_scaled = imputer.fit_transform(scaled)
    else:
        scaled = scaler.transform(filtered)
        imputed_scaled = imputer.transform(scaled)

    imputed = scaler.inverse_transform(imputed_scaled)
    return imputed, filtered_dates.reset_index(drop=True), filtered.columns.tolist(), scaler, imputer


# ============================================================
# 모델 빌드
# ============================================================
def build_autoencoder(timesteps: int, input_dim: int) -> Model:
    """2-layer LSTM Autoencoder with Dropout."""
    inputs = Input(shape=(timesteps, input_dim))

    # Encoder
    x = LSTM(LSTM_UNITS_1, activation='tanh', return_sequences=True)(inputs)
    x = Dropout(DROPOUT_RATE)(x)
    encoded = LSTM(LSTM_UNITS_2, activation='tanh', return_sequences=False)(x)

    # Decoder
    x = RepeatVector(timesteps)(encoded)
    x = LSTM(LSTM_UNITS_2, activation='tanh', return_sequences=True)(x)
    x = Dropout(DROPOUT_RATE)(x)
    x = LSTM(LSTM_UNITS_1, activation='tanh', return_sequences=True)(x)
    outputs = TimeDistributed(Dense(input_dim))(x)

    model = Model(inputs, outputs, name='lstm_autoencoder')
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=LEARNING_RATE),
        loss='mse'
    )
    return model


# ============================================================
# 평가/시각화
# ============================================================
def plot_recon_error(dates, errors, threshold, title: str, save_path: str = None):
    """재구성 오차 시계열 + threshold + anomaly 표시 (Plotly)."""
    anomaly_mask = errors > threshold
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=dates, y=errors, mode='lines',
        name='Reconstruction Error',
        line=dict(color='#4A90E2', width=1.2),
    ))

    fig.add_hline(y=threshold, line_dash='dash', line_color='red',
                  annotation_text=f'Threshold: {threshold:.2f}')

    if anomaly_mask.any():
        fig.add_trace(go.Scatter(
            x=dates[anomaly_mask], y=errors[anomaly_mask],
            mode='markers', name='Anomaly',
            marker=dict(color='red', size=8, line=dict(width=1, color='black')),
        ))

    fig.update_layout(
        title=title, height=450, width=1400,
        template='plotly_white', hovermode='x unified',
    )
    fig.update_xaxes(tickformat='%Y-%m-%d %H:%M', tickangle=45)

    if save_path:
        fig.write_html(save_path)
        print(f"[저장] {save_path}")
    fig.show()

    print(f"  이상 감지: {anomaly_mask.sum()} / {len(errors)}")
    return anomaly_mask


def plot_anomaly_on_timeseries(segment_dates, segment_values,
                                anomaly_dates, anomaly_values,
                                var_name: str, title_suffix: str = '',
                                save_path: str = None):
    """원본 시계열 위에 anomaly 오버레이 (Plotly)."""
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=segment_dates, y=segment_values,
        mode='lines', name=f'{var_name} (Normal)',
        line=dict(color='#4A90E2', width=1.2),
    ))
    if len(anomaly_dates) > 0:
        fig.add_trace(go.Scatter(
            x=anomaly_dates, y=anomaly_values,
            mode='markers', name='Anomaly',
            marker=dict(color='red', size=8, line=dict(width=1, color='black')),
        ))
    fig.update_layout(
        title=f'{var_name} with Anomalies {title_suffix}',
        height=500, width=1400,
        template='plotly_white', hovermode='x unified',
    )
    fig.update_xaxes(tickformat='%Y-%m-%d %H:%M', tickangle=45)
    if save_path:
        fig.write_html(save_path)
    fig.show()


def plot_feature_contribution(contrib: list, save_path: str = None):
    """Feature 기여도 바차트."""
    if not contrib:
        return
    names, values = zip(*contrib)
    fig = go.Figure(go.Bar(
        x=list(values), y=list(names), orientation='h',
        marker_color='#FF6B6B'
    ))
    fig.update_layout(
        title='Top 10 Feature Contribution to Anomalies (MSE)',
        height=400, width=800, template='plotly_white',
        yaxis=dict(autorange='reversed'),
    )
    if save_path:
        fig.write_html(save_path)
    fig.show()


# ============================================================
# 메인
# ============================================================
def main():
    # 1. 데이터 로드
    data = load_csv_auto_encoding(DATA_PATH)
    data['CURRTIME'] = pd.to_datetime(data['CURRTIME'].astype(str))

    # 2. Train/Test 분리 (DataFrame 상태 유지)
    df_train = data.iloc[:-TEST_SIZE].copy()
    df_test = data.iloc[-TEST_SIZE:].copy()
    print(f"\n[분리] Train: {df_train.shape}, Test: {df_test.shape}")

    # 3. EDA
    run_eda(df_train)

    # 4. 전처리
    print("\n[전처리] Train...")
    train_imputed, train_dates, feature_names, scaler, imputer = preprocess(df_train, fit=True)

    print("[전처리] Test...")
    test_imputed, test_dates, _, _, _ = preprocess(df_test, scaler=scaler, imputer=imputer, fit=False)

    print(f"\n  Train imputed: {train_imputed.shape}")
    print(f"  Test imputed:  {test_imputed.shape}")
    print(f"  Features: {len(feature_names)}")

    # scaler/imputer 저장
    joblib.dump(scaler, os.path.join(MODEL_DIR, 'scaler.pkl'))
    joblib.dump(imputer, os.path.join(MODEL_DIR, 'imputer.pkl'))

    # 5. 시퀀스 생성
    seq_train, idx_train = create_sequences(train_imputed, WINDOW_SIZE)
    seq_test, idx_test = create_sequences(test_imputed, WINDOW_SIZE)

    print(f"\n[시퀀스] Train: {seq_train.shape}, Test: {seq_test.shape}")

    timesteps = seq_train.shape[1]
    input_dim = seq_train.shape[2]

    # 6. 모델 빌드 & 학습
    model = build_autoencoder(timesteps, input_dim)
    model.summary()

    callbacks = [
        EarlyStopping(monitor='val_loss', patience=PATIENCE, restore_best_weights=True),
        ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=3, min_lr=1e-6),
    ]

    history = model.fit(
        seq_train, seq_train,
        epochs=EPOCHS, batch_size=BATCH_SIZE,
        validation_split=0.2,
        callbacks=callbacks,
        verbose=1,
    )

    # Loss 플롯
    plt.figure(figsize=(10, 4))
    plt.plot(history.history['loss'], label='train')
    plt.plot(history.history['val_loss'], label='val')
    plt.title('Training Loss')
    plt.xlabel('Epoch')
    plt.ylabel('MSE')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, 'training_loss.png'), dpi=150)
    plt.show()

    # 모델 저장
    model_path = os.path.join(MODEL_DIR, 'lstm_ae_m14.keras')
    model.save(model_path)
    print(f"[저장] 모델 → {model_path}")

    # 7. Threshold 산출 (train 기반)
    train_err = reconstruction_error(model, seq_train)
    threshold = np.percentile(train_err, THRESHOLD_PERCENTILE)
    print(f"\n[Threshold] train_err mean={train_err.mean():.2f}, "
          f"std={train_err.std():.2f}")
    print(f"[Threshold] {THRESHOLD_PERCENTILE}th percentile = {threshold:.2f}")

    # 8. Train 평가
    # ★ 수정: valid_mask로 필터된 train_dates 사용 (원본 index와 정확히 매핑)
    train_plot_dates = train_dates.iloc[idx_train].values

    print("\n[평가] Train 재구성 오차:")
    train_anom_mask = plot_recon_error(
        train_plot_dates, train_err, threshold,
        title='Train Reconstruction Error',
        save_path=os.path.join(OUTPUT_DIR, 'train_recon_error.html')
    )

    # Train anomaly on TOTALCNT
    target_var = 'TOTALCNT'
    if target_var in feature_names:
        # train_segment를 CURRTIME 인덱스로 세팅
        train_segment = df_train.set_index('CURRTIME')
        anom_times_train = pd.DatetimeIndex(train_plot_dates[train_anom_mask])

        plot_anomaly_on_timeseries(
            train_segment.index, train_segment[target_var],
            anom_times_train, train_segment.loc[anom_times_train, target_var] if len(anom_times_train) > 0 else [],
            var_name=target_var, title_suffix='(Train)',
            save_path=os.path.join(OUTPUT_DIR, 'train_totalcnt_anomaly.html')
        )

    # 9. Test 평가
    test_err = reconstruction_error(model, seq_test)
    test_plot_dates = test_dates.iloc[idx_test].values

    print("\n[평가] Test 재구성 오차 (same threshold):")
    test_anom_mask = plot_recon_error(
        test_plot_dates, test_err, threshold,
        title=f'Test Reconstruction Error (Threshold from Train: {threshold:.2f})',
        save_path=os.path.join(OUTPUT_DIR, 'test_recon_error.html')
    )

    # Test anomaly on TOTALCNT
    if target_var in feature_names:
        test_segment = df_test.set_index('CURRTIME')
        anom_times_test = pd.DatetimeIndex(test_plot_dates[test_anom_mask])

        plot_anomaly_on_timeseries(
            test_segment.index, test_segment[target_var],
            anom_times_test, test_segment.loc[anom_times_test, target_var] if len(anom_times_test) > 0 else [],
            var_name=target_var, title_suffix='(Test)',
            save_path=os.path.join(OUTPUT_DIR, 'test_totalcnt_anomaly.html')
        )

    # 10. Feature 기여도 분석
    print("\n[Feature 기여도] Test anomaly 기준 Top 10:")
    contrib = feature_contribution(model, seq_test, test_anom_mask, feature_names)
    for name, val in contrib:
        print(f"  {name}: {val:.2f}")

    plot_feature_contribution(
        contrib,
        save_path=os.path.join(OUTPUT_DIR, 'feature_contribution.html')
    )

    # 11. 결과 요약 저장
    summary = {
        'threshold': float(threshold),
        'threshold_percentile': THRESHOLD_PERCENTILE,
        'train_anomalies': int(train_anom_mask.sum()),
        'train_total': int(len(train_err)),
        'test_anomalies': int(test_anom_mask.sum()),
        'test_total': int(len(test_err)),
        'train_err_mean': float(train_err.mean()),
        'train_err_std': float(train_err.std()),
        'test_err_mean': float(test_err.mean()),
        'test_err_std': float(test_err.std()),
        'top_features': contrib,
    }

    import json
    with open(os.path.join(OUTPUT_DIR, 'summary.json'), 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(f"\n[저장] summary.json → {OUTPUT_DIR}/")

    print("\n" + "=" * 70)
    print("완료!")
    print(f"  Train anomalies: {summary['train_anomalies']}/{summary['train_total']}")
    print(f"  Test anomalies:  {summary['test_anomalies']}/{summary['test_total']}")
    print(f"  Threshold: {threshold:.2f} ({THRESHOLD_PERCENTILE}th percentile)")
    print("=" * 70)

    return model, threshold, summary


if __name__ == '__main__':
    model, threshold, summary = main()
