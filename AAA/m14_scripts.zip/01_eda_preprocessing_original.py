import numpy as np
import pandas as pd

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns

import missingno as msno

from itertools import groupby
from operator import itemgetter
from collections import defaultdict

from sklearn.preprocessing import StandardScaler, MinMaxScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import KNNImputer

import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, LSTM, RepeatVector, TimeDistributed, Dense
from tensorflow.keras.callbacks import EarlyStopping

import joblib
import os
os.makedirs("model", exist_ok=True)

data = pd.read_csv('data/M14_20250909_202603092359.CSV')
data['CURRTIME'] = data['CURRTIME'].astype(str)
data['CURRTIME'] = pd.to_datetime(data['CURRTIME'])
data.head()

for col in data.columns:
    print(col)

# 1분 단위 완전한 시계열 생성
full_range = pd.date_range(start=data["CURRTIME"].min(), end=data["CURRTIME"].max(), freq='1min')

# 누락된 시점 확인
missing_times = full_range.difference(data["CURRTIME"])

print("[데이터] 누락된 시점 개수:", len(missing_times))
print("[데이터] 누락된 시점 예시: \n", missing_times)

missing_summary = pd.DataFrame({
    'missing_count': data.isna().sum(),
    'missing_ratio(%)': np.ceil((data.isna().sum() / len(data) * 100) * 100) / 100
})


print(missing_summary[missing_summary['missing_ratio(%)'] != 0.00])

print("=========================================================================")
print(f'결측률이 가장많은 변수: {missing_summary[missing_summary["missing_count"] == missing_summary["missing_count"].max()]}')
non_zero_missing = missing_summary[(missing_summary['missing_ratio(%)'] != 0.00) & 
                                   (missing_summary['missing_count'] == missing_summary['missing_count'].min())]
print(f'결측률이 가장 적은 변수: {missing_summary[missing_summary["missing_ratio(%)"] != 0].nsmallest(1, "missing_ratio(%)")}')

msno.matrix(data, sparkline=True)

# 2. Figure 크기 조정 (matrix는 가로로 길게 설정하는 것이 좋음)
fig = plt.gcf()
fig.set_size_inches(14, 8)  # 가로 14, 세로 8 (데이터 양에 따라 조정)

# 3. Axis 가져와서 라벨 조정
ax = plt.gca()

# x축: 변수명 기울이고 크기 줄이기
ax.tick_params(axis='x', labelsize=9, rotation=45)

# y축: 인덱스(행 번호/시간) 라벨 - 데이터가 많으면 생략하거나 크기만 작게
ax.tick_params(axis='y', labelsize=7)  # 또는 labelleft=False로 숨기기

# 4. 제목 추가 (영어)
plt.title('Missing Value Pattern by Sample and Variable', 
          fontsize=14, fontweight='bold', pad=20)

plt.show()

variables = [col for col in data.columns if col != "CURRTIME"]

# 모든 컬럼(CURRTIME 제외)의 값이 빠져있는 데이터
missing_data = data[data[variables].isna().all(axis=1)]["CURRTIME"]
missing_data

# 연속된 그룹
def group_consecutive(datetimes):
    groups = []
    for k, g in groupby(enumerate(datetimes), lambda ix: ix[0] - int(ix[1].timestamp() / 60)):
        block = list(map(itemgetter(1), g))
        groups.append(block)
    return groups

# 그룹별 정보 수집
consecutive_groups = group_consecutive(missing_data)

# 결과
g_count = defaultdict(int)
for i, group in enumerate(consecutive_groups):
    duration_minutes = (group[-1] - group[0]).total_seconds() / 60 + 1  # 시작 포함
    count = len(group)
    g_count[duration_minutes] += 1  # 해당 길이의 누락 구간 수를 증가

# 출력
print("\n=== 누락 시간별 그룹 수 ===")
for duration, freq in sorted(g_count.items()):
    duration = int(duration)
    print(f"{duration}분 누락 구간 수: {freq}건")

main_col = [
    'TOTALCNT',
    'M14.QUE.ALL.TRANSPORT4MINOVERCNT',
    'M14.QUE.ALL.TRANSPORT4MINOVERTIMEAVG',
    'M14.QUE.ALL.TRANSPORT4MINOVERRATIO',
    'M14.QUE.CNV.M14ATOM16ACURRNETQCNT',
    'M14.QUE.OHT.CURRENTOHTQCNT',
    'M14B.QUE.OHT.RTCOHTUTIL',
    'M14.QUE.OHT.OHTUTIL',
    'M14.QUE.LOAD.AVGLOADTIME']

# 시각화
fig, ax = plt.subplots(len(main_col),2, figsize=(14,12))
fig.suptitle('Distribution & Boxplot of Variables', fontsize=18, y=1.02)

line_colors = ['#4A90E2', '#50E3C2', '#F5A623', '#FF0000', 
               '#800080', '#F8E71C', '#FF6B9D', '#2C3E50',
               '#1ABC9C']  

for i, (variable, color) in enumerate(zip(main_col, line_colors)):
    # 왼쪽 열: 히스토그램과 KDE Plot
    sns.histplot(data=data, x=variable, ax=ax[i,0], color=color, kde=True)
    ax[i, 0].set_title(f'{variable} - Histogram & KDE Plot', fontsize=12)
    ax[i, 0].set_xlabel('Value')
    ax[i, 0].set_ylabel('Frequency')
    
    # 오른쪽 열: box plot
    sns.boxplot(data=data, x=variable, ax=ax[i, 1], color=color)
    ax[i, 1].set_title(f'{variable} - Box Plot', fontsize=12)
    ax[i, 1].set_xlabel('Value')
    
plt.tight_layout()
plt.show()

import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np

# 서브플롯 생성
fig = make_subplots(
    rows=len(main_col),
    cols=1,
    shared_xaxes=True,
    vertical_spacing=0.02,
    subplot_titles=main_col
)

for idx, (col, line_color) in enumerate(zip(main_col, line_colors)):
    row = idx + 1
    
    # 결측치 제거한 데이터와 해당 시간 추출
    valid_mask = data[col].notna()
    data_series = data.loc[valid_mask, col]
    time_series = data.loc[valid_mask, 'CURRTIME']  # 시간 컬럼 매핑
    
    # IQR 기준 수염 범위 계산
    q1 = data_series.quantile(0.25)
    q3 = data_series.quantile(0.75)
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    
    # 1. 정상 시계열 (라인) - CURRTIME을 x축으로 사용
    fig.add_trace(
        go.Scatter(
            x=time_series,
            y=data_series,
            mode='lines',
            name=col,
            line=dict(color=line_color, width=1.5),
            showlegend=False,
            hovertemplate=f'<b>{col}</b><br>Time: %{{x}}<br>Value: %{{y:.4f}}<extra></extra>'
        ),
        row=row, col=1
    )
    
    # 2. Lower Outliers (하한 수염 미만) - 파란색
    lower_mask = data_series < lower_bound
    if lower_mask.any():
        lower_times = time_series[lower_mask]
        lower_values = data_series[lower_mask]
        
        fig.add_trace(
            go.Scatter(
                x=lower_times,
                y=lower_values,
                mode='markers',
                name=f'Lower (<{lower_bound:.2f})' if idx == 0 else None,
                marker=dict(
                    color='#0066CC',
                    size=8,
                    symbol='triangle-down',
                    line=dict(width=1, color='darkblue')
                ),
                showlegend=(idx == 0),
                hovertemplate=f'<b>LOWER OUTLIER</b><br>Time: %{{x}}<br>Value: %{{y:.4f}}<br>Bound: {lower_bound:.4f}<extra></extra>'
            ),
            row=row, col=1
        )
    
    # 3. Upper Outliers (상한 수염 초과) - 빨간색
    upper_mask = data_series > upper_bound
    if upper_mask.any():
        upper_times = time_series[upper_mask]
        upper_values = data_series[upper_mask]
        
        fig.add_trace(
            go.Scatter(
                x=upper_times,
                y=upper_values,
                mode='markers',
                name=f'Upper (>{upper_bound:.2f})' if idx == 0 else None,
                marker=dict(
                    color='#FF0000',
                    size=8,
                    symbol='triangle-up',
                    line=dict(width=1, color='darkred')
                ),
                showlegend=(idx == 0),
                hovertemplate=f'<b>UPPER OUTLIER</b><br>Time: %{{x}}<br>Value: %{{y:.4f}}<br>Bound: {upper_bound:.4f}<extra></extra>'
            ),
            row=row, col=1
        )

# 레이아웃 설정
fig.update_layout(
    height=250 * len(main_col),
    width=1400,
    title_text="Time Series with IQR Whisker Outliers (Lower: Blue ▼, Upper: Red ▲)",
    title_x=0.5,
    hovermode='x unified',
    template='plotly_white',
    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="right",
        x=1
    )
)

# x축 시간 포맷 설정
fig.update_xaxes(
    tickformat='%Y-%m-%d %H:%M',
    tickangle=45,
    nticks=20,
    showgrid=True,
    gridcolor='lightgray'
)
fig.update_yaxes(showgrid=True, gridcolor='lightgray', zeroline=False)

fig.show()

# 중복된 행이 있는지 확인
duplicated_rows = data[variables].duplicated()

# 중복된 행 수 출력
print("중복된 행 수:", duplicated_rows.sum())

# 중복된 행만 보기
print(data[duplicated_rows])

date_col = 'CURRTIME'  # 실제 날짜 컬럼명으로 변경하세요

dates = data[date_col]
numeric_df = data.drop(columns=[date_col])

# valid_mask
valid_mask = numeric_df.notna().any(axis=1)

filtered_numeric = numeric_df[valid_mask]
filtered_dates = dates[valid_mask]

print(f"원본 행 수: {len(data)}")
print(f"완전 결측 제거 후: {len(filtered_numeric)} 행")
print(f"제거된 행 수: {len(data) - len(filtered_numeric)} 행")

# Scaling
scaler = StandardScaler()
scaled_data = scaler.fit_transform(filtered_numeric)

# KNNImputer
imputer = KNNImputer(n_neighbors=5)
imputed_scaled = imputer.fit_transform(scaled_data)
imputed_values = scaler.inverse_transform(imputed_scaled)

# 결측치 처리 확인
data_scaled = pd.DataFrame(imputed_values, columns=main_col, index=data['CURRTIME'])
data_scaled.head()
