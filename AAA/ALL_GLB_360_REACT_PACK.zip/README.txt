﻿# ALL GLB 360 React Pack

핵심:
- `ALL.glb` 기준으로 360 프레임 생성 가능
- React에서 GLB 대신 이미지 시퀀스로 회전 뷰어 구현

먼저 읽기:
- `사용법_ALL_GLB_기준.md`

구성:
- ALL.glb
- blender_turntable_from_all_glb.py
- run_turntable_render.bat
- REACT_360_FROM_ALL_GLB_KR.md
- react/Spin360Viewer.tsx
- react/App.example.tsx
