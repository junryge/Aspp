@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "ROOT=%~dp0"
set "SCRIPT=%ROOT%blender_turntable_from_all_glb.py"
set "INPUT=%ROOT%ALL.glb"
set "OUTDIR=%ROOT%spin"

if not exist "!SCRIPT!" if exist "%ROOT%..\blender_turntable_from_all_glb.py" set "SCRIPT=%ROOT%..\blender_turntable_from_all_glb.py"
if not exist "!INPUT!" if exist "%ROOT%..\ALL.glb" set "INPUT=%ROOT%..\ALL.glb"

if not exist "!INPUT!" (
  echo [WARN] ALL.glb not found next to this bat file.
  set /p "INPUT=Enter ALL.glb full path (drag-drop supported): "
  set "INPUT=!INPUT:"=!"
)

if not exist "!INPUT!" (
  echo [ERROR] Invalid ALL.glb path: !INPUT!
  pause
  exit /b 1
)

if not exist "!SCRIPT!" (
  echo [ERROR] blender_turntable_from_all_glb.py not found: !SCRIPT!
  pause
  exit /b 1
)

if not exist "!OUTDIR!" mkdir "!OUTDIR!"

set "BLENDER_EXE="
for /f "delims=" %%I in ('where blender 2^>nul') do if not defined BLENDER_EXE set "BLENDER_EXE=%%I"
if not defined BLENDER_EXE for /f "delims=" %%I in ('dir /b /s "%ProgramFiles%\Blender Foundation\Blender *\blender.exe" 2^>nul') do set "BLENDER_EXE=%%I"
if not defined BLENDER_EXE for /f "delims=" %%I in ('dir /b /s "%ProgramFiles(x86)%\Blender Foundation\Blender *\blender.exe" 2^>nul') do set "BLENDER_EXE=%%I"
if not defined BLENDER_EXE for /f "delims=" %%I in ('dir /b /s "%LocalAppData%\Programs\Blender Foundation\Blender *\blender.exe" 2^>nul') do set "BLENDER_EXE=%%I"

if not defined BLENDER_EXE (
  echo [WARN] Blender executable not auto-detected.
  set /p "BLENDER_EXE=Enter blender.exe full path ^(or Blender folder path^): "
  set "BLENDER_EXE=!BLENDER_EXE:"=!"
)

if exist "!BLENDER_EXE!\blender.exe" set "BLENDER_EXE=!BLENDER_EXE!\blender.exe"

if not exist "!BLENDER_EXE!" (
  echo [ERROR] Invalid Blender path: !BLENDER_EXE!
  pause
  exit /b 1
)

echo Blender: !BLENDER_EXE!
echo Input  : !INPUT!
echo Output : !OUTDIR!

"!BLENDER_EXE!" -b -P "!SCRIPT!" -- --input "!INPUT!" --output "!OUTDIR!" --frames 72 --size 1024 --format webp --quality 85 --elevation 20

if errorlevel 1 (
  echo.
  echo [ERROR] Render failed.
  pause
  exit /b 1
)

echo.
echo [OK] Done. Frames are in: !OUTDIR!
pause
endlocal
