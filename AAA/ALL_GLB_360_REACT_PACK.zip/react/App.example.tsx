﻿import React, { useState } from 'react';
import Spin360Viewer from './Spin360Viewer';

export default function App() {
  const [autoPlay, setAutoPlay] = useState(false);

  return (
    <div style={{ width: '100vw', height: '100vh', background: '#111', color: '#fff' }}>
      <div style={{ position: 'fixed', top: 12, left: 12, zIndex: 10 }}>
        <button onClick={() => setAutoPlay((v) => !v)}>
          {autoPlay ? '자동회전 끄기' : '자동회전 켜기'}
        </button>
      </div>

      <Spin360Viewer
        frameCount={72}
        basePath="/spin"
        ext="webp"
        autoPlay={autoPlay}
        autoPlayFps={24}
        dragSensitivity={5}
      />
    </div>
  );
}
