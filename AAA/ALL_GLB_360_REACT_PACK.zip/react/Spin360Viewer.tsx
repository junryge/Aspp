﻿import React, { useEffect, useMemo, useRef, useState } from 'react';

type Spin360ViewerProps = {
  frameCount?: number;
  basePath?: string;
  ext?: 'webp' | 'png' | 'jpg' | 'jpeg';
  autoPlay?: boolean;
  autoPlayFps?: number;
  dragSensitivity?: number;
  width?: string | number;
  height?: string | number;
  className?: string;
};

const mod = (n: number, m: number) => ((n % m) + m) % m;

function pad3(n: number): string {
  return String(n).padStart(3, '0');
}

export default function Spin360Viewer({
  frameCount = 72,
  basePath = '/spin',
  ext = 'webp',
  autoPlay = false,
  autoPlayFps = 24,
  dragSensitivity = 4,
  width = '100%',
  height = '100%',
  className,
}: Spin360ViewerProps) {
  const [frame, setFrame] = useState(0);
  const [isDragging, setIsDragging] = useState(false);

  const startXRef = useRef(0);
  const startFrameRef = useRef(0);

  const frameUrls = useMemo(() => {
    return Array.from({ length: frameCount }, (_, i) => `${basePath}/${pad3(i)}.${ext}`);
  }, [basePath, ext, frameCount]);

  // Preload images once.
  useEffect(() => {
    frameUrls.forEach((url) => {
      const img = new Image();
      img.src = url;
    });
  }, [frameUrls]);

  // Optional autoplay.
  useEffect(() => {
    if (!autoPlay || isDragging) return;

    const interval = Math.max(1, Math.round(1000 / autoPlayFps));
    const timer = window.setInterval(() => {
      setFrame((prev) => mod(prev + 1, frameCount));
    }, interval);

    return () => window.clearInterval(timer);
  }, [autoPlay, autoPlayFps, frameCount, isDragging]);

  const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    setIsDragging(true);
    startXRef.current = e.clientX;
    startFrameRef.current = frame;
    e.currentTarget.setPointerCapture?.(e.pointerId);
  };

  const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const deltaX = e.clientX - startXRef.current;
    const steps = Math.round(deltaX / dragSensitivity);
    setFrame(mod(startFrameRef.current - steps, frameCount));
  };

  const endDrag = () => setIsDragging(false);

  return (
    <div
      className={className}
      style={{ width, height, touchAction: 'none', userSelect: 'none', position: 'relative' }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      onPointerLeave={endDrag}
    >
      <img
        src={frameUrls[frame]}
        alt={`360 frame ${frame + 1}`}
        draggable={false}
        style={{ width: '100%', height: '100%', objectFit: 'contain', display: 'block' }}
      />

      <div
        style={{
          position: 'absolute',
          left: 10,
          bottom: 10,
          background: 'rgba(0,0,0,0.55)',
          color: '#fff',
          padding: '4px 8px',
          borderRadius: 6,
          fontSize: 12,
        }}
      >
        {frame + 1} / {frameCount}
      </div>
    </div>
  );
}
