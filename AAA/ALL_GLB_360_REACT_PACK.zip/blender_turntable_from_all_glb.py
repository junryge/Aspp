import argparse
import math
import os
import sys
from mathutils import Vector
import bpy


def parse_args() -> argparse.Namespace:
    argv = sys.argv
    if '--' in argv:
        argv = argv[argv.index('--') + 1:]
    else:
        argv = []

    parser = argparse.ArgumentParser(description='Render turntable frames from GLB for React 360 image sequence.')
    parser.add_argument('--input', required=True, help='Input GLB path')
    parser.add_argument('--output', required=True, help='Output frame folder')
    parser.add_argument('--frames', type=int, default=72, help='Number of frames (default: 72)')
    parser.add_argument('--size', type=int, default=1024, help='Square render size (default: 1024)')
    parser.add_argument('--elevation', type=float, default=20.0, help='Camera elevation angle in degrees')
    parser.add_argument('--distance', type=float, default=0.0, help='Camera distance (0 = auto)')
    parser.add_argument('--format', choices=['webp', 'png'], default='webp', help='Output image format')
    parser.add_argument('--quality', type=int, default=85, help='WEBP quality (default: 85)')
    return parser.parse_args(argv)


def clear_scene() -> None:
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)

    for data_block in (bpy.data.meshes, bpy.data.materials, bpy.data.images, bpy.data.lights, bpy.data.cameras):
        for item in list(data_block):
            if item.users == 0:
                data_block.remove(item)


def import_glb(filepath: str):
    before = set(bpy.data.objects)
    bpy.ops.import_scene.gltf(filepath=filepath)
    imported = [obj for obj in bpy.data.objects if obj not in before]
    if not imported:
        raise RuntimeError('No objects were imported from GLB.')
    return imported


def compute_bounds(objs):
    mesh_objs = [o for o in objs if o.type == 'MESH']
    if not mesh_objs:
        raise RuntimeError('No mesh objects found in imported GLB.')

    min_v = Vector((float('inf'), float('inf'), float('inf')))
    max_v = Vector((float('-inf'), float('-inf'), float('-inf')))

    for obj in mesh_objs:
        for corner in obj.bound_box:
            p = obj.matrix_world @ Vector(corner)
            min_v.x = min(min_v.x, p.x)
            min_v.y = min(min_v.y, p.y)
            min_v.z = min(min_v.z, p.z)
            max_v.x = max(max_v.x, p.x)
            max_v.y = max(max_v.y, p.y)
            max_v.z = max(max_v.z, p.z)

    center = (min_v + max_v) * 0.5
    size = max_v - min_v
    max_dim = max(size.x, size.y, size.z)
    return center, max_dim


def setup_camera(center: Vector, max_dim: float, elevation_deg: float, distance: float):
    scene = bpy.context.scene

    cam_data = bpy.data.cameras.new('TurntableCamera')
    cam_obj = bpy.data.objects.new('TurntableCamera', cam_data)
    bpy.context.collection.objects.link(cam_obj)
    scene.camera = cam_obj

    target = bpy.data.objects.new('TurntableTarget', None)
    target.empty_display_type = 'PLAIN_AXES'
    target.location = center
    bpy.context.collection.objects.link(target)

    track = cam_obj.constraints.new(type='TRACK_TO')
    track.target = target
    track.track_axis = 'TRACK_NEGATIVE_Z'
    track.up_axis = 'UP_Y'

    dist = distance if distance > 0 else max_dim * 2.4
    elev = math.radians(elevation_deg)
    radius = dist * math.cos(elev)
    z = dist * math.sin(elev)

    return cam_obj, radius, z, target


def setup_lighting() -> None:
    scene = bpy.context.scene

    scene.world.use_nodes = True
    bg = scene.world.node_tree.nodes.get('Background')
    if bg:
        bg.inputs[1].default_value = 1.0

    sun_data = bpy.data.lights.new(name='Sun', type='SUN')
    sun_data.energy = 2.0
    sun = bpy.data.objects.new(name='Sun', object_data=sun_data)
    sun.location = (6.0, -6.0, 8.0)
    bpy.context.collection.objects.link(sun)


def setup_render(size: int, fmt: str, quality: int):
    scene = bpy.context.scene
    scene.render.engine = 'BLENDER_EEVEE'
    scene.eevee.taa_render_samples = 16
    scene.eevee.taa_samples = 8

    scene.render.resolution_x = size
    scene.render.resolution_y = size
    scene.render.resolution_percentage = 100

    if fmt == 'webp':
        scene.render.image_settings.file_format = 'WEBP'
        scene.render.image_settings.quality = quality
    else:
        scene.render.image_settings.file_format = 'PNG'


def render_frames(cam_obj, center: Vector, radius: float, z: float, out_dir: str, frames: int, ext: str):
    scene = bpy.context.scene
    for i in range(frames):
        angle = (2.0 * math.pi * i) / frames
        cam_obj.location = (
            center.x + radius * math.cos(angle),
            center.y + radius * math.sin(angle),
            center.z + z,
        )
        scene.render.filepath = os.path.join(out_dir, f'{i:03d}.{ext}')
        bpy.ops.render.render(write_still=True)
        print(f'Rendered {i + 1}/{frames}: {scene.render.filepath}')


def main() -> None:
    args = parse_args()

    in_path = os.path.abspath(args.input)
    out_dir = os.path.abspath(args.output)
    os.makedirs(out_dir, exist_ok=True)

    clear_scene()
    imported = import_glb(in_path)
    center, max_dim = compute_bounds(imported)

    cam_obj, radius, z, _target = setup_camera(center, max_dim, args.elevation, args.distance)
    setup_lighting()
    setup_render(args.size, args.format, args.quality)
    render_frames(cam_obj, center, radius, z, out_dir, args.frames, args.format)

    print('\nDone.')
    print(f'Input : {in_path}')
    print(f'Output: {out_dir}')
    print(f'Frames: {args.frames}')


if __name__ == '__main__':
    main()
