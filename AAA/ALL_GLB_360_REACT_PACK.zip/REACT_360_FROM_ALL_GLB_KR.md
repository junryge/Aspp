﻿# ALL.glb -> 360 이미지 시퀀스 -> React 사용 가이드

## 1) Blender 프레임 렌더

아래 파일 실행:

- `F:\M14_Q\glb_all\run_turntable_render.bat`

출력 경로:

- `F:\M14_Q\glb_all\spin\000.webp` ~ `071.webp`

## 2) React 프로젝트에 복사

React 프로젝트 `public` 폴더 기준:

- `public/spin/000.webp` ~ `071.webp`

## 3) 컴포넌트 적용

복사 파일:

- `react_360/Spin360Viewer.tsx` -> `src/components/Spin360Viewer.tsx`
- `react_360/App.example.tsx` 참고해서 `App.tsx`에 적용

## 4) 장점

- GLB/WebGL보다 저사양 PC에서 호환성 높음
- 드래그로 360도 회전 UX 구현 쉬움
- CPU 중심 환경에서도 비교적 안정적

## 5) 한계

- 진짜 3D가 아니라 이미지 교체 방식
- 동적 조명/재질/정밀 카메라 자유도 제한
