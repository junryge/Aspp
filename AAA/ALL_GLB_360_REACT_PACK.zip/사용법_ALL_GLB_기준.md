﻿# ALL.glb 기준 사용법 (필독)


예제 1. exe 경로 입력
C:\Program Files\Blender Foundation\Blender 4.1\blender.exe

예제 2. 폴더 경로 입력
C:\Program Files\Blender Foundation\Blender 4.1

그다음 Enter.

가장 쉬운 방법:

탐색기에서 blender.exe 찾기
그 파일을 배치창으로 드래그앤드롭
자동으로 경로 들어가면 Enter
참고로 ALL.glb는 bat 파일과 같은 폴더에 있으면 자동 인식됩니다

이 폴더만 있으면 360 이미지 시퀀스를 만들고 React에서 바로 사용할 수 있습니다.

## 1) 준비물

1. Blender 설치 (권장 3.6 이상)
2. 이 폴더 안에 `ALL.glb` 존재 확인

확인 파일:
- `ALL.glb`
- `run_turntable_render.bat`
- `blender_turntable_from_all_glb.py`

## 2) 360 프레임 생성 (ALL.glb 기준)

1. `run_turntable_render.bat` 더블클릭
2. 완료되면 `spin` 폴더 생성
3. 아래 파일이 생성됨:
- `spin/000.webp`
- `spin/001.webp`
- ...
- `spin/071.webp`

기본 설정:
- 프레임 수: 72장
- 해상도: 1024x1024
- 포맷: webp

## 3) React 프로젝트에 적용

1. 생성된 `spin` 폴더를 React 프로젝트 `public` 아래로 복사
- 예: `your-app/public/spin/000.webp ... 071.webp`

2. 컴포넌트 복사
- `react/Spin360Viewer.tsx` -> `your-app/src/components/Spin360Viewer.tsx`

3. 예제 참고
- `react/App.example.tsx` 내용대로 `App.tsx`에 연결

## 4) React에서 실제 사용 예

```tsx
<Spin360Viewer
  frameCount={72}
  basePath="/spin"
  ext="webp"
  autoPlay={false}
  autoPlayFps={24}
  dragSensitivity={5}
/>
```

## 5) 자주 발생하는 문제

### Q1. bat 실행했는데 안 됨
- Blender가 설치되어 있는지 확인
- `ALL.glb`가 bat 파일과 같은 폴더에 있는지 확인

### Q2. React에서 이미지가 안 보임
- `public/spin` 경로가 맞는지 확인
- 파일명이 `000.webp` ~ `071.webp`인지 확인
- 브라우저 캐시 문제면 일반 새로고침(F5) 후 확인

### Q3. 더 부드럽게 돌리고 싶음
- 72 -> 120 프레임으로 렌더 (스크립트 옵션 수정)
- 대신 용량 증가
