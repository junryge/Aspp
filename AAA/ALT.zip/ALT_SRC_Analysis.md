# ATLAS AMHS (ALT/src) 소스코드 분석 보고서

> **프로젝트**: SK Hynix Smart ATLAS AMHS  
> **분석 대상**: `ALT/src/` (158 Java files, 47,178 lines)  
> **분석일**: 2026-03-06 ~ 2026-03-21

---

## 1. 프로젝트 개요

ATLAS(Advanced Transport Logistics & Automation System)는 SK Hynix 반도체 FAB의 AMHS(Automated Material Handling System)를 관리하는 핵심 시스템이다. OHT(Overhead Hoist Transport), Stocker, Conveyor, STB(Side Track Buffer) 등의 물류 장비를 실시간으로 모니터링하고 제어하며, Dijkstra 기반 경로 탐색, 예측 배치, 이상 감지 등을 수행한다.

### 1.1 기술 스택

| 구분 | 기술 |
|------|------|
| 언어 | Java |
| 프레임워크 | SmartFX (SK Hynix 내부 프레임워크) |
| DB | MongoDB, Oracle RAC (MyBatis) |
| 로그 시스템 | Logpresso |
| 메시징 | TIBCO Rendezvous (TibRV) |
| 통신 | UDP (OHT), Socket.IO (Conveyor) |
| 스케줄링 | Quartz Scheduler (Job interface) |
| 외부 연동 | ITSM, Python (ML 예측), SMS |

### 1.2 전체 통계

| 패키지 | 파일 수 | 라인 수 | 비고 |
|--------|---------|---------|------|
| `batch/` | 27 | 9,958 | 스케줄 배치 작업 |
| `data/` | 23 | 7,025 | 핵심 도메인 모델 |
| `data/eq/` | 6 | 1,036 | 장비 모델 |
| `data/raw/` | 17 | 3,122 | MCP75 원시 데이터 |
| `db_BB/` ⚠️ | 7 | 973 | DB 접근 계층 (**→ `db/`로 변경 필요**) |
| `environment/` | 4 | 845 | 환경 설정 |
| `listener/` | 2 | 754 | UDP/Socket.IO 리스너 |
| `map/` | 6 | 1,309 | 맵 추상 모델 |
| `map/edge/` | 7 | 2,807 | Edge 구현체 |
| `map/node/` | 8 | 1,850 | Node 구현체 |
| `map/mcslog/` | 4 | 528 | MCS 로그 VO |
| `navi/` | 5 | 461 | 경로 탐색 (Dijkstra) |
| `process/` | 1 | 897 | OHT 메시지 처리 |
| `queryformat/` | 16 | 4,468 | 쿼리 포맷터 |
| `service/` | 4 | 4,318 | 서비스 계층 |
| `util/` | 19 | 6,784 | 유틸리티 |
| root | 2 | 43 | 이벤트 핸들러/런처 |
| **합계** | **158** | **47,178** | |

---

## 2. 패키지별 소스코드 상세 분석

### 2.1 `batch/` — 스케줄 배치 작업 (27파일, 9,958줄)

모든 배치 클래스가 Quartz `Job` 인터페이스를 구현하며, `execute()` → `_run()` 패턴을 따른다.

#### 핵심 배치 목록

| 클래스 | 줄 수 | 기능 |
|--------|-------|------|
| **QTransferPredictBatch** | 1,753 | Q-Transfer 예측 (Python ML 연동, CSV 입출력, Logpresso 적재) |
| **BridgeLayoutDetailBatch** | 1,640 | Bridge 상세 레이아웃 — Port 검증, Storage Util, Hubroom OHT Deadlock 감지, Machine Down 검증 |
| **SystemMessageDetectBatch** | 867 | MES↔MCS 메시지 이상 감지 (MES_REQ_TS_JOB, MCS_REP_TS_JOB 카운트 비교) |
| **OhtPerformanceTimeMinBatch** | 532 | OHT 분 단위 성능 집계 + 알람 메시지 XML |
| **RailCutRefreshBatch** | 478 | Rail Cut 상태 갱신 (FTP 다운로드 → 파싱 → TibRV 전송 → Logpresso 적재) |
| **SwitchSystemBatch** | 466 | 기능 스위치 동적 변경 (Properties 파일 감시 → 런타임 제어) |
| **MonitoringControlBatch** | 378 | VHL OFF / Stage Command / UDP 메시지 모니터링 통합 |
| **ServerResourceApmBatch** | 375 | APM 서버 리소스 모니터링 (Oracle → 알람 생성) |
| **BridgeLayoutBatch** | 334 | Bridge 레이아웃 기본 + 이상치 감지 |
| **DataSetRefreshBatch** | 316 | 맵 데이터 갱신 (FTP 다운로드 → HID OFF/VHL OFF/Rail Cut 업데이트) |
| **TrafficBatch** | 308 | HID Edge별 교통량 집계 (velocity, passCnt, vhlCnt → Logpresso) |
| **AbnormalDetectBatch** | 281 | 로그 패턴 기반 이상 감지 (중복 제거 → 비교 필터링) |
| **RailVibrationBatch** | 281 | Rail 진동 모니터링 (센서 데이터 → 정상/이상 판정) |
| **HubroomTransPredictBatch** | 266 | Hubroom 반송 예측 (Python 연동, CSV 생성, 알람 판정) |
| **HidEdgeInOutUpdateMasterBatch** | 248 | HID Edge IN/OUT 마스터 정보 갱신 |
| **BridgeJudgeRangeBatch** | 221 | Bridge 이상 판정 범위 배치 (시그마 기반 Anomaly) |
| **QTransferDashBoardItemBatch** | 195 | Q-Transfer 대시보드 아이템 생성 |
| **ItsmChangeRequestBatch** | 168 | ITSM 변경 요청 자동 처리 (REST POST) |
| **OhtPerformanceTimeHourBatch** | 140 | OHT 시간 단위 성능 집계 |
| **VhlCntBatch** | 124 | VHL 카운트 기본 배치 |
| **VhlCnt10Batch** | 109 | VHL 카운트 10분 주기 |
| **VhlCnt30Batch** | 110 | VHL 카운트 30분 주기 |
| **VhlCnt60Batch** | 110 | VHL 카운트 60분 주기 |
| **HidEdgeInOutQueueFlushBatch** | 81 | HID Edge IN/OUT 큐 플러시 |
| **AlertingSystemStatus** | 75 | 시스템 리소스 알림 (CPU/Memory/Disk → SMS) |
| **UpdatingDbMachineListBatch** | 52 | DB 머신 리스트 갱신 |
| **UpdatingDbMasterDataBatch** | 50 | DB 마스터 데이터 갱신 |

#### 주요 패턴

- **Python ML 연동**: `QTransferPredictBatch`, `HubroomTransPredictBatch`가 CSV 파일 생성 후 `PythonUtil`로 Python 스크립트 실행
- **Logpresso 적재**: 대부분의 배치가 결과를 `Tuple` 형태로 Logpresso 테이블에 INSERT
- **TibRV 메시징**: 알림 및 상태 변경 시 TibRV로 메시지 전송
- **이상 감지**: 시그마 기반 Anomaly Detection (BridgeJudgeRangeBatch), IQR 기반 (BridgeLayoutDetailBatch)

---

### 2.2 `data/` — 도메인 모델 (46파일, 11,183줄)

#### 2.2.1 핵심 도메인 (`data/`, 23파일)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **DataSet** | 1,398 | **핵심 데이터 저장소** — 모든 Edge/Node/Vhl/Station/Carrier/Command 등의 ConcurrentHashMap 관리. 시스템의 중앙 상태 저장소. |
| **Job** | 1,353 | 반송 작업 (Job) 도메인 — 소스/목적지 장비, 캐리어, 명령 큐, 타임스탬프 관리 |
| **Command** | 759 | 반송 명령 — JobId, CarrierId, Source/Dest Node, VHL 할당, 우선순위, 상태 |
| **Carrier** | 330 | FOUP/Carrier — Lot, Router, BatchId, 위치 추적, ReentrantLock 동기화 |
| **RouteItem** | 324 | 경로 아이템 — 예측/실제/이력 경로, 비용, VHL 상태 맵 |
| **OhtStats** | 273 | OHT 통계 — VHL 수, 반송중/대기/수동 등 상태별 카운트 |
| **PredictionPara** | 256 | 경로 예측 파라미터 (Singleton) — 가중치, 페널티, bias 등 ML 파라미터 |
| **RailVibrationRecordItem** | 274 | Rail 진동 기록 — X/Y/Z 센서값, 상태 판정 |
| **CnvTask** | 224 | Conveyor 작업 — 각 단계별 타임스탬프, ConcurrentMap 락 관리 |
| **VhlOffRecordItem** | 221 | VHL OFF 이벤트 기록 — 영향받는 포트/주소 |
| **FabProperties** | 218 | FAB 속성 — fabId, facId, mcpName, Bridge 설정, MCP 매핑 |
| **OhtRegData** | 200 | OHT 회귀 데이터 (Long Edge 기반) |
| **OhtRegBjData** | 200 | OHT 회귀 데이터 (BranchJoin Edge 기반) |
| **HidOffRecordItem** | 183 | HID OFF 이벤트 기록 |
| **McpProperties** | 164 | MCP 속성 — IP, Port, FTP 접속정보, UDP 포트 |
| **RailCutRecordItem** | 159 | Rail Cut 이벤트 기록 |
| **StageCommandRecordItem** | 108 | Stage Command 모니터링 기록 |
| **Area** | 72 | 구역(Area) 도메인 — RailEdge ID 목록 |
| **Bay** | 59 | Bay 도메인 |
| **Msg** | 80 | 메시지 도메인 — MHS/EI/OHT/UI/CNV 타입 enum |
| **DbProperties** | 35 | DB 접속 정보 |
| **TibrvSendMsg** | 28 | TibRV 전송 메시지 래퍼 |
| **FirstEdgeInfo** | 107 | 첫 번째 Edge 정보 (Long Edge/BranchJoin 연결) |

#### 2.2.2 장비 모델 (`data/eq/`, 6파일)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **Eqp** (base) | 401 | 장비 기본 클래스 — EQP_TYPE(OHT/STOCKER/STB_GROUP/EQP/FIO/CNV), PROCESS_TYPE, 포트 목록 |
| **Conveyor** | 192 | CNV — Socket.IO 통신, CNV_EVENT_CD, 레이아웃, 그룹 노드 맵 |
| **Stocker** | 175 | Stocker — STK_TYPE(NA/INTER/UNIFIED), 쉘프/RM, N2 가스 지원 |
| **Oht** | 130 | OHT — VHL 목록, Station 목록, Control/TSC/Alarm 상태 |
| **StbGroup** | 107 | STB 그룹 — 가용 StbNode 탐색, Full 상태, MaxCapa/Occupancy |
| **Fio** | 31 | FIO(Floor I/O) — FIOTYPE(NORMAL/VM) |

#### 2.2.3 원시 데이터 모델 (`data/raw/`, 17파일)

MCP75 Config 파일에서 파싱되는 원시 맵 데이터:

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **Mcp75Config** | 1,129 | **MCP75 설정 파서** — ZIP 파일에서 Point/Station/VHL/Area/Bay/Junction/HID/BZ 등 전체 맵 데이터 파싱 |
| **RawStation** | 374 | Station 원시 데이터 — STATION_TYPE, INV_MGT_CATEGORY, STATION_LOCATION |
| **RawBz** | 247 | Buffer Zone 원시 데이터 — ObzQueue, StopPoint, HidInfo, Fd 내부 클래스 |
| **RawArea** | 198 | Area — VHL 최대/최소/평균, Entry/Exit 세트 |
| **RawPoint** | 197 | Rail 포인트 — Address, 좌우 주소/거리/속도, Draw/CAD 좌표 |
| **RawVhlType** | 138 | VHL 타입 — 운송 캐리어 타입, 운행 범위, 최소 거리, 오프라인 타이머 |
| **RawCnvZone** | 125 | Conveyor Zone — LD/QS/LFT 속성, Draw 정보 |
| **RawHid** | 118 | HID Zone — Entry(LoopEntry), Exit, AutoClose 설정 |
| **RawRouteInfo** | 108 | 경로 정보 — From/To Bay, VHL 타입, 우선순위 범위 |
| **RawBay** | 97 | Bay — Entry/Exit(RawBayPort), ZoneCarrierType |
| **RawLabel** | 87 | 맵 라벨 — Address, X/Y 좌표, 표시 문자열 |
| **RawLoop** | 71 | Loop — Entry/Exit, RunningAreaType |
| **RawJunction** | 67 | Junction — Entry/Exit, VhlPreCaution |
| **RawVhl** | 66 | VHL 원시 — Type, LoopId, ID Read/Mask Detection |
| **LoopEntry** | 52 | Loop 진입 정보 — 레인 시작/끝, ZCU, 설정번호 |
| **RawVhlSpeed** | 31 | VHL 속도 레벨 |
| **RawEdge** | 17 | Edge 원시 — fromNode, toNode, railEdgeId |

---

### 2.3 `db_BB/` → ⚠️ `db/`로 변경 필요 (7파일, 973줄)

> **수정 사항**: 현재 폴더명이 `db_BB`로 되어 있으나, 올바른 이름은 `db`이다.  
> 코드 내부에서 `db_BB` 패키지를 직접 import하는 부분은 없음 (패키지 선언문 누락 확인).  
> → **폴더명만 `db_BB` → `db`로 rename하면 됨**.

#### 변경 작업 체크리스트

```
[ ] ALT/src/db_BB/ → ALT/src/db/ 폴더명 변경
[ ] ALT/src/db_BB/logpresso/ → ALT/src/db/logpresso/
[ ] ALT/src/db_BB/mongodb/ → ALT/src/db/mongodb/
[ ] ALT/src/db_BB/mybatis/ → ALT/src/db/mybatis/
[ ] 빌드 설정 파일(pom.xml, build.gradle 등)에서 경로 참조 확인
[ ] CI/CD 파이프라인 경로 확인
```

#### 2.3.1 Logpresso (`db/logpresso/`, 1파일)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **LogpressoAPI** | 430 | Logpresso 클라이언트 — Connection Pool, 쿼리 실행 (SELECT/INSERT), Canceller 스레드, Active Node 이중화 |

#### 2.3.2 MongoDB (`db/mongodb/`, 5파일)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **MongodbAPI** | 90 | MongoDB 클라이언트 — Database Pool, find/aggregate/insertMany |
| **MongodbLinq\<T\>** | 76 | LINQ 스타일 쿼리 기본 클래스 — iterator, toList, FutureTask |
| **MongodbFindLinq** | 154 | Find 쿼리 빌더 — filter/limit/skip/sort/projection 체이닝 |
| **MongodbAggregateLinq** | 85 | Aggregate 파이프라인 빌더 — allowDiskUse, let, explain |
| **MongodbQueryPool** | 83 | XML 기반 쿼리 풀 — Element 파싱, 태그 치환, 아규먼트 바인딩 |

#### 2.3.3 MyBatis (`db/mybatis/`, 1파일)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **MybatisQueryHandler** | 55 | MyBatis 쿼리 관리 — XML 파일 읽기/수정, 쿼리 목록 조회 |

---

### 2.4 `map/` — 맵 모델 (25파일, 6,494줄)

ATLAS FAB 레이아웃의 그래프 구조를 정의하는 핵심 패키지.

#### 2.4.1 추상 모델 (`map/`, 6파일)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **AbstractEdge** | 242 | Edge 추상 클래스 — EDGE_TYPE enum(7종), id/fabId/fromNode/toNode/area/bay/length |
| **AbstractNode** | 443 | Node 추상 클래스 — fromEdges/toEdges, fromLongEdges/toLongEdges, 캐리어/커맨드 관리 |
| **Vhl** | 523 | Vehicle — UDP 상태(VhlUdpState), 위치/속도/가속도, ReentrantLock, 메시지 시퀀스 |
| **Label** | 87 | 맵 라벨 표시 |
| **CarrierContainable** | 8 | 캐리어 보관 가능 인터페이스 |
| **CarrierTransportable** | 6 | 캐리어 운송 가능 인터페이스 |

#### 2.4.2 Edge 구현체 (`map/edge/`, 7파일)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **LongEdge** | 896 | **핵심** — 여러 RailEdge의 논리적 묶음, 비용 계산, 예측 큐, RouteItem 관리 |
| **Station** | 526 | Station 노드 — Transfer Edge 연결, 포트 매핑, 캐리어 적재/하역 |
| **RailEdge** | 464 | 물리적 레일 구간 — HID ID, VHL 맵, 속도/교통량, HID IN/OUT 카운트 |
| **TransferEdge** | 344 | 적재/하역 Edge — 평균 반송 비용, VHL 호출 비용, Acquire/Deposit 구분 |
| **StkRmEdge** | 302 | Stocker RM Edge — Bridge RM, 이동 중 캐리어 추적 |
| **BranchJoinEdge** | 169 | 분기/합류 Edge — RailEdge 목록, 비용/속도 |
| **CnvEdge** | 106 | Conveyor Edge — 평균 반송 간격 |

#### 2.4.3 Node 구현체 (`map/node/`, 8파일)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **CnvPortNode** | 375 | CNV 포트 — Zone, Group, CNV_NODE_TYPE, CNV_REF_DIR |
| **StkPortNode** | 271 | Stocker 포트 — SubPort, MaxCapa, 층별 관리, OHT FAB 매핑 |
| **RailNode** | 225 | Rail 노드 — Draw/CAD 좌표, Branch/Junction 판별, 주소 |
| **StbNode** | 203 | STB 노드 — N2, 가용성, Reader Port |
| **StkRmNode** | 203 | Stocker RM 노드 — CarrierContainable + CarrierTransportable |
| **StkShelfNode** | 202 | Stocker 쉘프 — MaxCapa, N2, 가용성 |
| **FioPortNode** | 196 | FIO 포트 — SubPort, IN/OUT 타입 |
| **EqpPortNode** | 175 | 장비 포트 — Inline Port, 가용성, Transfer 상태 |

#### 2.4.4 MCS 로그 VO (`map/mcslog/`, 4파일)

`EiVo`, `SecsVo`, `TotalVo`, `MachineVo` — MCS 로그 검색 파라미터 Value Object

---

### 2.5 `navi/` — 경로 탐색 (5파일, 461줄)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **DijkstraVhlRouteFind** | 110 | **Dijkstra 알고리즘 OHT 경로 탐색** — Source→Destination RailNode 최단 경로 |
| **Navigator** | 233 | Rail 영향 범위 탐색 — Rail Cut/HID Off 시 영향받는 포트 탐색 |
| **ComparableRailNode** | 49 | 우선순위 큐용 비교 가능 노드 래퍼 |
| **RouteResult** | 52 | 경로 결과 — PathItem(LongEdgeId + Cost) 목록 |
| **RailEdgePredecessor** | 17 | Dijkstra 선행자 추적 |

---

### 2.6 `process/` — 메시지 처리 (1파일, 897줄)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **OhtMsgWorkerRunnable** | 897 | **OHT UDP 메시지 처리 핵심** — VHL 상태 보고 파싱, 위치/속도/가속도 업데이트, HID OFF 처리, VHL OFF 처리, Edge InOut 큐 업데이트 |

내부 상수 클래스: `MSG_ID` (메시지 ID 상수), `VHL_STATE_REPORT` (상태 보고 필드 인덱스), `OHT_TIB_STATE` (TibRV 상태)

---

### 2.7 `listener/` — 외부 통신 리스너 (2파일, 754줄)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **OhtUdpListener** | 178 | OHT UDP 수신 — 단일/멀티 리스너, DatagramSocket, 메시지 큐 적재 |
| **CnvSocketIOListener** | 576 | Conveyor Socket.IO — 연결/레이아웃 빌드, Zone 이벤트 수신, RawCnvZone 맵 구성 |

---

### 2.8 `environment/` — 환경 설정 (4파일, 845줄)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **Env** | 401 | **중앙 환경 관리** — Properties 로딩, Logpresso/MongoDB 접속정보, FAB 설정, 기능 스위치, 스레드 풀 |
| **FunctionItem** | 368 | 기능 스위치 아이템 — useHidOff, useVhlOff, useRailCut, useVhlCnt 등 20+ 스위치 |
| **DbProperties** | 35 | DB 접속 속성 (environment 버전 — Port가 int) |
| **SmsProperties** | 41 | SMS 알림 설정 — CPU/Memory/Disk 임계값 |

---

### 2.9 `queryformat/` — 쿼리 포맷터 (16파일, 4,468줄)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **LogpressoMcslogQuery** | 2,188 | **최대 파일** — Logpresso MCS 로그 쿼리 빌더 (Total/SECS/EI/Machine 통합) |
| **LogpressoCommonFilterQuery** | 1,073 | 공통 필터 쿼리 — Job History, Command History 추출 |
| **MongodbCommonFilterQuery** | 260 | MongoDB 공통 필터 쿼리 |
| **MongodbMcslogQuery** | 17 | MongoDB FAB 접미사 변환 |
| **LogpressoConditionUtil** | 194 | 쿼리 조건 유틸 — AND/OR/IN 조건 생성 |
| 타입 클래스 (11개) | 736 | VO/Enum — McslogTotalVo, McslogSecsVo, ENUM_DBCONNECTION_ID 등 |

---

### 2.10 `service/` — 서비스 계층 (4파일, 4,318줄)

| 클래스 | 줄 수 | 역할 |
|--------|-------|------|
| **BizDataInitializer** | 178 | 시스템 초기화 — FAB 데이터 로드, UDP 리스너 생성, 워커 스레드 시작 |
| **HttpService** | 253 | HTTP API 서비스 — REST 엔드포인트 |
| **TibrvService** | — | TIBCO Rendezvous 메시징 서비스 |
| **UiLogpresso** | — | UI용 Logpresso 쿼리 서비스 |

---

### 2.11 `util/` — 유틸리티 (19파일, 6,784줄)

| 클래스 | 역할 |
|--------|------|
| **DataService** | 중앙 데이터 접근 서비스 — DataSet 싱글턴 관리 |
| **Util** | 범용 유틸리티 |
| **XmlUtil** | XML 파싱 유틸 |
| **JsonUtil** | JSON 변환 유틸 |
| **ParseUtil** | 데이터 파싱 유틸 |
| **QueryUtil** | 쿼리 관련 유틸 |
| **LayoutUtil** | 맵 레이아웃 유틸 |
| **FilePathUtil** | 파일 경로 관리 — PYTHON_FILE_PATH 등 |
| **PythonUtil** | Python 스크립트 실행 유틸 |
| **CryptoUtil** | 암호화/복호화 유틸 |
| **SecurityUtil** | 보안 유틸 |
| **SmsUtil** | SMS 전송 유틸 |
| **RemoteCommandUtil** | 원격 명령 실행 유틸 |
| **AsyncUtil** | 비동기 처리 유틸 |
| **ThreadPool** | 스레드 풀 관리 |
| **MemoryTailerUtil** | 메모리 테일링 유틸 |
| **ReflectionUtil** | 리플렉션 유틸 |
| **JsonToStringBuilder** | JSON toString 빌더 |
| **AleadyClosedException** | 이미 닫힌 예외 (오타: Already) |

---

## 3. 핵심 데이터 흐름

### 3.1 OHT 실시간 처리 파이프라인

```
MCP75 Server
    │ UDP
    ▼
OhtUdpListener (listener/)
    │ DatagramSocket → String message
    ▼
OhtMsgWorkerRunnable (process/)
    │ 토큰 파싱 → VHL 상태 업데이트
    │ HID OFF / VHL OFF 처리
    │ Edge InOut 큐 업데이트
    ▼
DataSet (data/)
    │ ConcurrentHashMap 상태 저장
    ▼
TrafficBatch (batch/)
    │ HID Edge별 교통량 집계
    ▼
Logpresso + TibRV
```

### 3.2 배치 예측 파이프라인

```
Oracle RAC / Logpresso
    │ 데이터 조회
    ▼
QTransferPredictBatch / HubroomTransPredictBatch
    │ CSV 파일 생성
    ▼
PythonUtil → Python ML 스크립트
    │ 예측 결과 CSV
    ▼
배치 후처리
    │ 알람 판정 + Tuple 생성
    ▼
Logpresso 테이블 INSERT
```

### 3.3 경로 탐색 흐름

```
경로 요청 (Command)
    │
    ▼
DijkstraVhlRouteFind (navi/)
    │ Source RailNode → Dest RailNode
    │ ComparableRailNode 우선순위 큐
    ▼
RouteResult
    │ PathItem 리스트 (LongEdge + Cost)
    ▼
LongEdge.pathPredictQueue
    │ RouteItem 예측 큐
    ▼
VHL 배차 실행
```

---

## 4. 동시성 모델

- **ConcurrentHashMap**: DataSet의 모든 맵 (Edge/Node/VHL/Station/Carrier)
- **ConcurrentLinkedQueue**: Edge의 RailEdge 목록, Node의 Edge 목록
- **ReentrantLock**: Vhl, Carrier 개별 락
- **AtomicLong/AtomicInteger**: 메시지 시퀀스, OHT 시퀀스
- **PriorityBlockingQueue**: LongEdge 예측 큐

---

## 5. 수정 사항: `db_BB` → `db`

```
ALT/src/db/
├── logpresso/
│   └── LogpressoAPI.java
├── mongodb/
│   ├── MongodbAPI.java
│   ├── MongodbAggregateLinq.java
│   ├── MongodbFindLinq.java
│   ├── MongodbLinq.java
│   └── MongodbQueryPool.java
└── mybatis/
    └── MybatisQueryHandler.java
```

### 5.1 영향도 분석

- **코드 내 import 참조**: 소스 파일에 `package` 선언문이 없음 → 폴더명만 변경하면 됨
- **빌드 시스템**: pom.xml 또는 build.gradle에서 소스 디렉토리 설정 확인 필요
- **Git 작업**: `git mv ALT/src/db_BB ALT/src/db`


