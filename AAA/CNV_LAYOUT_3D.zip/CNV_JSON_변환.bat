@echo off
chcp 65001 >nul
title CNV.JSON → CNV_DATA.js 변환기

echo ============================================
echo   CNV.JSON → CNV_DATA.js 자동 변환기
echo ============================================
echo.

:: Check if CNV.JSON exists in the same folder
if not exist "%~dp0CNV.JSON" (
    echo [ERROR] CNV.JSON 파일을 찾을 수 없습니다!
    echo         이 파일과 같은 폴더에 CNV.JSON을 넣어주세요.
    echo.
    pause
    exit /b 1
)

echo [1/3] CNV.JSON 읽는 중...

:: Use PowerShell to convert JSON to JS variable
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$json = Get-Content -Raw '%~dp0CNV.JSON';" ^
  "$out = '// Auto-generated from CNV.JSON - ' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + [char]10;" ^
  "$out += '// Do not edit manually. Re-run CNV_JSON_변환.bat to regenerate.' + [char]10;" ^
  "$out += 'const CNV_RAW_DATA = ' + $json.Trim() + ';' + [char]10;" ^
  "[System.IO.File]::WriteAllText('%~dp0CNV_DATA.js', $out, [System.Text.Encoding]::UTF8);"

if %errorlevel% neq 0 (
    echo [ERROR] 변환 실패!
    pause
    exit /b 1
)

echo [2/3] CNV_DATA.js 생성 완료!

:: Show file sizes
for %%A in ("%~dp0CNV.JSON") do echo        CNV.JSON:    %%~zA bytes
for %%A in ("%~dp0CNV_DATA.js") do echo        CNV_DATA.js: %%~zA bytes

echo [3/3] 완료!
echo.
echo ============================================
echo   이제 CNV_3D_Conveyor.html을 열면 됩니다!
echo ============================================
echo.
pause
