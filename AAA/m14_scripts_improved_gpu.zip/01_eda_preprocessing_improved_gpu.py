"""
M14 FAB AMHS 데이터 EDA & 전처리 (개선 + GPU 버전)
===================================================
개선 사항:
  1. 안 쓰는 import 제거
  2. CSV 인코딩 자동 감지 (utf-8 → cp949 → euc-kr)
  3. KNNImputer 후 DataFrame 컬럼 매핑 버그 수정
  4. 시각화 함수화 + 결과 자동 저장 (png/html/pkl/csv)
  5. GPU 설정 + Mixed Precision
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import missingno as msno
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from itertools import groupby
from operator import itemgetter
from collections import defaultdict

from sklearn.preprocessing import StandardScaler
from sklearn.impute import KNNImputer

import tensorflow as tf

# ============================================================
# GPU 설정
# ============================================================
gpus = tf.config.list_physical_devices('GPU')
if gpus:
    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        print(f"[GPU] {len(gpus)}개 감지: {[g.name for g in gpus]}")
        print(f"[GPU] Memory growth 활성화")
    except RuntimeError as e:
        print(f"[GPU] 설정 오류: {e}")
else:
    print("[GPU] GPU 없음 → CPU 모드")

tf.keras.mixed_precision.set_global_policy('mixed_float16')
print(f"[GPU] Mixed precision: {tf.keras.mixed_precision.global_policy().name}")
print(f"[GPU] TF version: {tf.__version__}")
print(f"[GPU] CUDA available: {tf.test.is_built_with_cuda()}")

import joblib
import os
import time

# ============================================================
# 설정
# ============================================================
DATA_PATH = 'data/M14_20250909_202603092359.CSV'
OUTPUT_DIR = 'results_eda'
os.makedirs(OUTPUT_DIR, exist_ok=True)

MAIN_COL = [
    'TOTALCNT',
    'M14.QUE.ALL.TRANSPORT4MINOVERCNT',
    'M14.QUE.ALL.TRANSPORT4MINOVERTIMEAVG',
    'M14.QUE.ALL.TRANSPORT4MINOVERRATIO',
    'M14.QUE.CNV.M14ATOM16ACURRNETQCNT',
    'M14.QUE.OHT.CURRENTOHTQCNT',
    'M14B.QUE.OHT.RTCOHTUTIL',
    'M14.QUE.OHT.OHTUTIL',
    'M14.QUE.LOAD.AVGLOADTIME',
]

LINE_COLORS = [
    '#4A90E2', '#50E3C2', '#F5A623', '#FF0000',
    '#800080', '#F8E71C', '#FF6B9D', '#2C3E50',
    '#1ABC9C',
]


# ============================================================
# 유틸 함수
# ============================================================
def load_csv_auto_encoding(path: str, **kwargs) -> pd.DataFrame:
    """UTF-8 → CP949 → EUC-KR 순서로 인코딩 자동 감지하여 CSV 로드."""
    for enc in ['utf-8', 'cp949', 'euc-kr']:
        try:
            df = pd.read_csv(path, encoding=enc, on_bad_lines='skip', low_memory=False, **kwargs)
            print(f"[로드 성공] 인코딩: {enc}, shape: {df.shape}")
            return df
        except (UnicodeDecodeError, UnicodeError):
            continue
    raise ValueError(f"CSV 로드 실패: {path}")


def group_consecutive_missing(datetimes):
    """연속된 결측 시점을 그룹으로 묶기."""
    groups = []
    for k, g in groupby(enumerate(datetimes), lambda ix: ix[0] - int(ix[1].timestamp() / 60)):
        block = list(map(itemgetter(1), g))
        groups.append(block)
    return groups


def print_missing_summary(df: pd.DataFrame, label: str = "데이터"):
    """결측률 요약 출력."""
    summary = pd.DataFrame({
        'missing_count': df.isna().sum(),
        'missing_ratio(%)': np.round(df.isna().sum() / len(df) * 100, 2)
    })
    has_missing = summary[summary['missing_ratio(%)'] > 0]

    print(f"\n{'='*70}")
    print(f"[{label}] 결측 요약 (결측 있는 변수만)")
    print(f"{'='*70}")
    if len(has_missing) == 0:
        print("결측 없음!")
    else:
        print(has_missing.to_string())
        print(f"\n  - 최다 결측: {has_missing['missing_count'].idxmax()} "
              f"({has_missing['missing_count'].max()}건, "
              f"{has_missing.loc[has_missing['missing_count'].idxmax(), 'missing_ratio(%)']:.2f}%)")
        print(f"  - 최소 결측: {has_missing['missing_count'].idxmin()} "
              f"({has_missing['missing_count'].min()}건, "
              f"{has_missing.loc[has_missing['missing_count'].idxmin(), 'missing_ratio(%)']:.2f}%)")
    return summary


def plot_distributions(df: pd.DataFrame, columns: list, colors: list, save_path: str = None):
    """히스토그램 + 박스플롯 쌍 시각화."""
    n = len(columns)
    fig, axes = plt.subplots(n, 2, figsize=(14, 3 * n))
    fig.suptitle('Distribution & Boxplot of Variables', fontsize=18, y=1.01)

    for i, (col, color) in enumerate(zip(columns, colors)):
        sns.histplot(data=df, x=col, ax=axes[i, 0], color=color, kde=True)
        axes[i, 0].set_title(f'{col}', fontsize=10)
        axes[i, 0].set_xlabel('')
        axes[i, 0].set_ylabel('Freq')

        sns.boxplot(data=df, x=col, ax=axes[i, 1], color=color)
        axes[i, 1].set_title(f'{col}', fontsize=10)
        axes[i, 1].set_xlabel('')

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"[저장] {save_path}")
    plt.show()


def plot_timeseries_iqr_outliers(df: pd.DataFrame, time_col: str,
                                  columns: list, colors: list,
                                  save_path: str = None):
    """Plotly 시계열 + IQR 이상치 서브플롯."""
    fig = make_subplots(
        rows=len(columns), cols=1,
        shared_xaxes=True, vertical_spacing=0.02,
        subplot_titles=columns
    )

    for idx, (col, color) in enumerate(zip(columns, colors)):
        row = idx + 1
        valid = df[col].notna()
        series = df.loc[valid, col]
        times = df.loc[valid, time_col]

        q1, q3 = series.quantile(0.25), series.quantile(0.75)
        iqr = q3 - q1
        lb, ub = q1 - 1.5 * iqr, q3 + 1.5 * iqr

        fig.add_trace(go.Scatter(
            x=times, y=series, mode='lines', name=col,
            line=dict(color=color, width=1.2), showlegend=False,
            hovertemplate=f'<b>{col}</b><br>%{{x}}<br>%{{y:.2f}}<extra></extra>'
        ), row=row, col=1)

        lo = series < lb
        if lo.any():
            fig.add_trace(go.Scatter(
                x=times[lo], y=series[lo], mode='markers',
                name='Lower' if idx == 0 else None,
                marker=dict(color='#0066CC', size=6, symbol='triangle-down'),
                showlegend=(idx == 0),
            ), row=row, col=1)

        hi = series > ub
        if hi.any():
            fig.add_trace(go.Scatter(
                x=times[hi], y=series[hi], mode='markers',
                name='Upper' if idx == 0 else None,
                marker=dict(color='#FF0000', size=6, symbol='triangle-up'),
                showlegend=(idx == 0),
            ), row=row, col=1)

    fig.update_layout(
        height=220 * len(columns), width=1400,
        title_text="Time Series + IQR Outliers", title_x=0.5,
        hovermode='x unified', template='plotly_white',
    )
    fig.update_xaxes(tickformat='%Y-%m-%d %H:%M', tickangle=45, showgrid=True)
    fig.update_yaxes(showgrid=True, zeroline=False)

    if save_path:
        fig.write_html(save_path)
        print(f"[저장] {save_path}")
    fig.show()


# ============================================================
# 메인 로직
# ============================================================
def main():
    total_start = time.time()

    # 1. 데이터 로드
    data = load_csv_auto_encoding(DATA_PATH)
    data['CURRTIME'] = pd.to_datetime(data['CURRTIME'].astype(str))

    print(f"\n컬럼 목록 ({len(data.columns)}개):")
    for col in data.columns:
        print(f"  - {col}")

    # 2. 시계열 누락 확인
    full_range = pd.date_range(
        start=data["CURRTIME"].min(),
        end=data["CURRTIME"].max(),
        freq='1min'
    )
    missing_times = full_range.difference(data["CURRTIME"])
    print(f"\n[시계열] 전체 기대 시점: {len(full_range)}")
    print(f"[시계열] 실제 데이터 시점: {len(data)}")
    print(f"[시계열] 누락 시점: {len(missing_times)}")

    # 3. 결측 요약
    print_missing_summary(data, "전체 데이터")

    # 4. missingno 매트릭스
    msno.matrix(data, sparkline=True)
    fig = plt.gcf()
    fig.set_size_inches(14, 8)
    ax = plt.gca()
    ax.tick_params(axis='x', labelsize=9, rotation=45)
    ax.tick_params(axis='y', labelsize=7)
    plt.title('Missing Value Pattern', fontsize=14, fontweight='bold', pad=20)
    plt.savefig(os.path.join(OUTPUT_DIR, '01_missing_matrix.png'), dpi=150, bbox_inches='tight')
    print(f"[저장] {OUTPUT_DIR}/01_missing_matrix.png")
    plt.show()

    # 5. 연속 결측 구간 분석
    variables = [c for c in data.columns if c != "CURRTIME"]
    all_missing = data[data[variables].isna().all(axis=1)]["CURRTIME"]

    if len(all_missing) > 0:
        groups = group_consecutive_missing(all_missing)
        g_count = defaultdict(int)
        for grp in groups:
            dur = int((grp[-1] - grp[0]).total_seconds() / 60 + 1)
            g_count[dur] += 1

        print("\n=== 연속 결측 구간 요약 ===")
        for dur, freq in sorted(g_count.items()):
            print(f"  {dur}분 구간: {freq}건")
    else:
        print("\n완전 결측(모든 변수 NaN) 행 없음")

    # 6. 분포 시각화
    valid_cols = [c for c in MAIN_COL if c in data.columns]
    valid_colors = LINE_COLORS[:len(valid_cols)]

    if valid_cols:
        plot_distributions(
            data, valid_cols, valid_colors,
            save_path=os.path.join(OUTPUT_DIR, '02_distribution_boxplot.png')
        )

        plot_timeseries_iqr_outliers(
            data, 'CURRTIME', valid_cols, valid_colors,
            save_path=os.path.join(OUTPUT_DIR, '03_timeseries_iqr_outliers.html')
        )

    # 7. 중복 체크
    dup = data[variables].duplicated()
    print(f"\n중복 행 수: {dup.sum()}")

    # 8. 전처리: 완전 결측 제거 → StandardScaler → KNNImputer
    print("\n[전처리] KNNImputer 시작 (26만행이면 오래 걸릴 수 있음)...")
    preprocess_start = time.time()

    numeric_df = data.drop(columns=['CURRTIME'])
    valid_mask = numeric_df.notna().any(axis=1)
    filtered = numeric_df[valid_mask].copy()
    filtered_dates = data.loc[valid_mask, 'CURRTIME'].copy()

    print(f"  원본: {len(data)} → 완전결측 제거: {len(filtered)} "
          f"(제거: {len(data) - len(filtered)}행)")

    scaler = StandardScaler()
    scaled = scaler.fit_transform(filtered)

    imputer = KNNImputer(n_neighbors=5)
    imputed_scaled = imputer.fit_transform(scaled)
    imputed = scaler.inverse_transform(imputed_scaled)

    preprocess_elapsed = time.time() - preprocess_start
    print(f"[전처리] KNNImputer 완료: {preprocess_elapsed:.1f}초 ({preprocess_elapsed/60:.1f}분)")

    # ★ 버그 수정: 원본은 main_col(9개)로 매핑 → 실제 컬럼 수와 불일치 가능
    imputed_df = pd.DataFrame(
        imputed,
        columns=filtered.columns,  # ← 원본 numeric 컬럼 그대로 사용
        index=filtered_dates.values
    )
    imputed_df.index.name = 'CURRTIME'

    print(f"[전처리] 보간 완료: {imputed_df.shape}")
    print(f"[전처리] 남은 NaN: {imputed_df.isna().sum().sum()}")

    # 9. 전처리 아티팩트 저장
    joblib.dump(scaler, os.path.join(OUTPUT_DIR, 'scaler.pkl'))
    joblib.dump(imputer, os.path.join(OUTPUT_DIR, 'imputer.pkl'))
    imputed_df.to_csv(os.path.join(OUTPUT_DIR, 'imputed_data.csv'))

    total_elapsed = time.time() - total_start

    # 결과 요약
    print(f"\n{'='*70}")
    print(f"[완료] 모든 결과 → {OUTPUT_DIR}/")
    print(f"{'='*70}")
    print(f"  01_missing_matrix.png")
    print(f"  02_distribution_boxplot.png")
    print(f"  03_timeseries_iqr_outliers.html")
    print(f"  scaler.pkl / imputer.pkl / imputed_data.csv")
    print(f"\n  KNNImputer 소요: {preprocess_elapsed:.1f}초 ({preprocess_elapsed/60:.1f}분)")
    print(f"  전체 소요: {total_elapsed:.1f}초 ({total_elapsed/60:.1f}분)")
    print(f"  GPU: {'Yes' if gpus else 'No (CPU)'}")
    print(f"{'='*70}")

    return imputed_df


if __name__ == '__main__':
    result = main()
