"""
M14 FAB AMHS LSTM Autoencoder 이상탐지 (개선 + GPU 버전)
=========================================================
개선 사항:
  1. train/test 변수 덮어쓰기 문제 해결
  2. threshold: train 99th percentile 자동 산출 (train/test 동일 적용)
  3. 모델: 2-layer encoder/decoder + Dropout + ReduceLROnPlateau
  4. GPU: memory growth + mixed_float16 + batch_size 64
  5. 재현성: seed 고정
  6. scaler/imputer pkl 저장
  7. 모든 결과 이미지/HTML 자동 저장 (results_anomaly/)
  8. feature 기여도 바차트 시각화
  9. summary.json 내보내기
"""

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import missingno as msno
import plotly.graph_objects as go

from itertools import groupby
from operator import itemgetter
from collections import defaultdict

from sklearn.preprocessing import StandardScaler
from sklearn.impute import KNNImputer

import tensorflow as tf
import logging
logging.getLogger('tensorflow').setLevel(logging.ERROR)

# ============================================================
# GPU 설정
# ============================================================
gpus = tf.config.list_physical_devices('GPU')
if gpus:
    try:
        for gpu in gpus:
            tf.config.experimental.set_memory_growth(gpu, True)
        print(f"[GPU] {len(gpus)}개 감지")
        print(f"[GPU] Memory growth 활성화")
    except RuntimeError as e:
        print(f"[GPU] 설정 오류: {e}")
else:
    print("[GPU] GPU 없음 → CPU 모드")

tf.keras.mixed_precision.set_global_policy('mixed_float16')
print(f"[GPU] Mixed precision: {tf.keras.mixed_precision.global_policy().name}")
print(f"[GPU] TF version: {tf.__version__}")
print(f"[GPU] CUDA available: {tf.test.is_built_with_cuda()}")

from tensorflow.keras.models import Model
from tensorflow.keras.layers import (
    Input, LSTM, RepeatVector, TimeDistributed, Dense, Dropout
)
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau

import joblib
import json
import os
import time

# ============================================================
# 재현성
# ============================================================
SEED = 42
np.random.seed(SEED)
tf.random.set_seed(SEED)

# ============================================================
# 설정
# ============================================================
DATA_PATH = 'data/M14_20250909_202602042358.csv'
MODEL_DIR = 'model'
OUTPUT_DIR = 'results_anomaly'
os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)

TEST_SIZE = 10080          # 마지막 7일 (1분 단위)
WINDOW_SIZE = 10           # 시퀀스 길이
KNN_NEIGHBORS = 5          # KNNImputer k
THRESHOLD_PERCENTILE = 99  # 재구성 오차 threshold (train 기준)

# 모델 하이퍼파라미터
LSTM_UNITS_1 = 128
LSTM_UNITS_2 = 64
DROPOUT_RATE = 0.2
LEARNING_RATE = 1e-3
EPOCHS = 50
BATCH_SIZE = 64            # GPU니까 64 (원본 16)
PATIENCE = 5


# ============================================================
# 유틸 함수
# ============================================================
def load_csv_auto_encoding(path: str) -> pd.DataFrame:
    """UTF-8 → CP949 → EUC-KR 순서로 인코딩 자동 감지."""
    for enc in ['utf-8', 'cp949', 'euc-kr']:
        try:
            df = pd.read_csv(path, encoding=enc, on_bad_lines='skip', low_memory=False)
            print(f"[로드] 인코딩={enc}, shape={df.shape}")
            return df
        except (UnicodeDecodeError, UnicodeError):
            continue
    raise ValueError(f"CSV 로드 실패: {path}")


def group_consecutive_missing(datetimes):
    """연속 결측 그룹핑."""
    groups = []
    for k, g in groupby(enumerate(datetimes), lambda ix: ix[0] - int(ix[1].timestamp() / 60)):
        block = list(map(itemgetter(1), g))
        groups.append(block)
    return groups


def create_sequences(X: np.ndarray, window_size: int):
    """슬라이딩 윈도우 시퀀스 생성. NaN 포함 윈도우 제외."""
    if isinstance(X, pd.DataFrame):
        X = X.to_numpy(dtype=np.float32)
    elif not isinstance(X, np.ndarray):
        X = np.array(X, dtype=np.float32)

    T = X.shape[0]
    sequences, indices = [], []

    for i in range(T - window_size + 1):
        window = X[i:i + window_size]
        if not np.isnan(window).any():
            sequences.append(window)
            indices.append(i + window_size - 1)

    return np.array(sequences), np.array(indices)


def reconstruction_error(model: tf.keras.Model, sequences: np.ndarray) -> np.ndarray:
    """윈도우 단위 평균 MSE 재구성 오차."""
    recon = model.predict(sequences, verbose=0)
    return np.mean((sequences - recon) ** 2, axis=(1, 2))


def feature_contribution(model: tf.keras.Model, sequences: np.ndarray,
                          is_anomaly: np.ndarray, feature_names: list):
    """이상 윈도우의 feature별 MSE 기여도 계산."""
    recon = model.predict(sequences, verbose=0)
    feat_mse = np.mean((sequences - recon) ** 2, axis=1)  # (N, F)

    if is_anomaly.sum() == 0:
        print("[경고] 이상 윈도우 없음 → feature 기여도 분석 불가")
        return []

    anom_feat = feat_mse[is_anomaly].mean(axis=0)
    top_idx = np.argsort(-anom_feat)[:10]
    result = [(feature_names[i], float(anom_feat[i])) for i in top_idx]
    return result


# ============================================================
# EDA 단계
# ============================================================
def run_eda(df_train: pd.DataFrame):
    """학습 데이터에 대한 간단 EDA."""
    print(f"\n{'='*70}")
    print(f"[EDA] Train shape: {df_train.shape}")

    full_range = pd.date_range(
        start=df_train["CURRTIME"].min(),
        end=df_train["CURRTIME"].max(),
        freq='1min'
    )
    missing = full_range.difference(df_train["CURRTIME"])
    print(f"[EDA] 시계열 누락: {len(missing)}개")

    summary = pd.DataFrame({
        'missing_count': df_train.isna().sum(),
        'missing_ratio(%)': np.round(df_train.isna().sum() / len(df_train) * 100, 2)
    })
    has_missing = summary[summary['missing_ratio(%)'] > 0]
    if len(has_missing) > 0:
        print(f"[EDA] 결측 있는 변수: {len(has_missing)}개")
        print(has_missing.head(10).to_string())

    variables = [c for c in df_train.columns if c != 'CURRTIME']
    all_missing = df_train[df_train[variables].isna().all(axis=1)]['CURRTIME']
    if len(all_missing) > 0:
        groups = group_consecutive_missing(all_missing)
        g_count = defaultdict(int)
        for grp in groups:
            dur = int((grp[-1] - grp[0]).total_seconds() / 60 + 1)
            g_count[dur] += 1
        print("\n[EDA] 연속 결측 구간:")
        for dur, freq in sorted(g_count.items()):
            print(f"  {dur}분: {freq}건")

    dup_count = df_train.duplicated().sum()
    print(f"[EDA] 중복 행: {dup_count}")

    msno.matrix(df_train, sparkline=True)
    plt.gcf().set_size_inches(14, 8)
    plt.title('Missing Value Pattern (Train)', fontsize=14, fontweight='bold')
    plt.savefig(os.path.join(OUTPUT_DIR, '01_missing_matrix.png'), dpi=150, bbox_inches='tight')
    print(f"[저장] {OUTPUT_DIR}/01_missing_matrix.png")
    plt.show()


# ============================================================
# 전처리 단계
# ============================================================
def preprocess(df: pd.DataFrame, scaler=None, imputer=None, fit: bool = True):
    """완전 결측 제거 → StandardScaler → KNNImputer."""
    dates = df['CURRTIME'].copy()
    numeric = df.drop(columns=['CURRTIME'])

    valid_mask = numeric.notna().any(axis=1)
    filtered = numeric[valid_mask]
    filtered_dates = dates[valid_mask]

    print(f"  원본: {len(df)} → 유효: {len(filtered)} (제거: {len(df) - len(filtered)})")

    if fit:
        scaler = StandardScaler()
        scaled = scaler.fit_transform(filtered)
        imputer = KNNImputer(n_neighbors=KNN_NEIGHBORS)
        imputed_scaled = imputer.fit_transform(scaled)
    else:
        scaled = scaler.transform(filtered)
        imputed_scaled = imputer.transform(scaled)

    imputed = scaler.inverse_transform(imputed_scaled)
    return imputed, filtered_dates.reset_index(drop=True), filtered.columns.tolist(), scaler, imputer


# ============================================================
# 모델 빌드 (GPU)
# ============================================================
def build_autoencoder(timesteps: int, input_dim: int) -> Model:
    """2-layer LSTM Autoencoder with Dropout (GPU 가속)."""
    with tf.device('/GPU:0' if gpus else '/CPU:0'):
        inputs = Input(shape=(timesteps, input_dim))

        # Encoder
        x = LSTM(LSTM_UNITS_1, activation='tanh', return_sequences=True)(inputs)
        x = Dropout(DROPOUT_RATE)(x)
        encoded = LSTM(LSTM_UNITS_2, activation='tanh', return_sequences=False)(x)

        # Decoder
        x = RepeatVector(timesteps)(encoded)
        x = LSTM(LSTM_UNITS_2, activation='tanh', return_sequences=True)(x)
        x = Dropout(DROPOUT_RATE)(x)
        x = LSTM(LSTM_UNITS_1, activation='tanh', return_sequences=True)(x)
        outputs = TimeDistributed(Dense(input_dim, dtype='float32'))(x)  # mixed precision: 출력 float32

        model = Model(inputs, outputs, name='lstm_autoencoder')
        model.compile(
            optimizer=tf.keras.optimizers.Adam(learning_rate=LEARNING_RATE),
            loss='mse'
        )
    return model


# ============================================================
# 평가/시각화
# ============================================================
def plot_recon_error(dates, errors, threshold, title: str,
                     save_png: str = None, save_html: str = None):
    """재구성 오차 시계열 + threshold + anomaly (matplotlib + Plotly 둘 다 저장)."""
    anomaly_mask = errors > threshold

    # matplotlib
    plt.figure(figsize=(18, 5))
    plt.plot(dates, errors, label="recon err", alpha=0.7, color='#4A90E2')
    plt.gca().xaxis_date()
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M'))
    plt.gca().xaxis.set_major_locator(mdates.AutoDateLocator(minticks=5, maxticks=15))
    plt.xticks(rotation=45, ha='right')
    plt.axhline(threshold, color='red', linestyle="--", label=f"threshold ({threshold:.2f})")
    if anomaly_mask.any():
        plt.scatter(dates[anomaly_mask], errors[anomaly_mask],
                    color='red', s=30, zorder=5, label='Anomaly')
    plt.legend()
    plt.title(title)
    plt.tight_layout()
    if save_png:
        plt.savefig(save_png, dpi=150, bbox_inches='tight')
        print(f"[저장] {save_png}")
    plt.show()

    # Plotly
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=dates, y=errors, mode='lines',
        name='Reconstruction Error',
        line=dict(color='#4A90E2', width=1.2),
    ))
    fig.add_hline(y=threshold, line_dash='dash', line_color='red',
                  annotation_text=f'Threshold: {threshold:.2f}')
    if anomaly_mask.any():
        fig.add_trace(go.Scatter(
            x=dates[anomaly_mask], y=errors[anomaly_mask],
            mode='markers', name='Anomaly',
            marker=dict(color='red', size=8, line=dict(width=1, color='black')),
        ))
    fig.update_layout(
        title=title, height=450, width=1400,
        template='plotly_white', hovermode='x unified',
    )
    fig.update_xaxes(tickformat='%Y-%m-%d %H:%M', tickangle=45)
    if save_html:
        fig.write_html(save_html)
        print(f"[저장] {save_html}")
    fig.show()

    print(f"  이상 감지: {anomaly_mask.sum()} / {len(errors)}")
    return anomaly_mask


def plot_anomaly_on_timeseries(segment_dates, segment_values,
                                anomaly_dates, anomaly_values,
                                var_name: str, title_suffix: str = '',
                                save_png: str = None, save_html: str = None):
    """원본 시계열 위에 anomaly 오버레이 (matplotlib + Plotly)."""
    # matplotlib
    plt.figure(figsize=(14, 5))
    plt.plot(segment_dates, segment_values,
             color='#4A90E2', linewidth=1, label='Normal', alpha=0.7)
    if len(anomaly_dates) > 0:
        plt.scatter(anomaly_dates, anomaly_values,
                    color='red', s=50, label='Anomaly',
                    zorder=5, alpha=0.8, edgecolors='black', linewidth=0.5)
    plt.title(f'{var_name} - Anomalies {title_suffix}', fontsize=14)
    plt.ylabel(var_name)
    plt.xlabel('Time')
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d %H:%M'))
    plt.xticks(rotation=45, ha='right')
    plt.legend(loc='upper right')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    if save_png:
        plt.savefig(save_png, dpi=150, bbox_inches='tight')
        print(f"[저장] {save_png}")
    plt.show()

    # Plotly
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=segment_dates, y=segment_values,
        mode='lines', name=f'{var_name} (Normal)',
        line=dict(color='#4A90E2', width=1.2),
    ))
    if len(anomaly_dates) > 0:
        fig.add_trace(go.Scatter(
            x=anomaly_dates, y=anomaly_values,
            mode='markers', name='Anomaly',
            marker=dict(color='red', size=8, line=dict(width=1, color='black')),
        ))
    fig.update_layout(
        title=f'{var_name} with Anomalies {title_suffix}',
        height=500, width=1400,
        template='plotly_white', hovermode='x unified',
    )
    fig.update_xaxes(tickformat='%Y-%m-%d %H:%M', tickangle=45)
    if save_html:
        fig.write_html(save_html)
        print(f"[저장] {save_html}")
    fig.show()


def plot_feature_contribution(contrib: list, save_png: str = None, save_html: str = None):
    """Feature 기여도 바차트."""
    if not contrib:
        return
    names, values = zip(*contrib)

    # matplotlib
    plt.figure(figsize=(10, 6))
    plt.barh(range(len(names)), values, color='#FF6B6B', edgecolor='black', linewidth=0.5)
    plt.yticks(range(len(names)), names, fontsize=10)
    plt.xlabel('Mean MSE', fontsize=12)
    plt.title('Top 10 Feature Contribution to Anomalies', fontsize=14)
    plt.gca().invert_yaxis()
    plt.tight_layout()
    if save_png:
        plt.savefig(save_png, dpi=150, bbox_inches='tight')
        print(f"[저장] {save_png}")
    plt.show()

    # Plotly
    fig = go.Figure(go.Bar(
        x=list(values), y=list(names), orientation='h',
        marker_color='#FF6B6B'
    ))
    fig.update_layout(
        title='Top 10 Feature Contribution to Anomalies (MSE)',
        height=400, width=800, template='plotly_white',
        yaxis=dict(autorange='reversed'),
    )
    if save_html:
        fig.write_html(save_html)
        print(f"[저장] {save_html}")
    fig.show()


# ============================================================
# 메인
# ============================================================
def main():
    total_start = time.time()

    # 1. 데이터 로드
    data = load_csv_auto_encoding(DATA_PATH)
    data['CURRTIME'] = pd.to_datetime(data['CURRTIME'].astype(str))

    # 2. Train/Test 분리 (DataFrame 상태 유지)
    df_train = data.iloc[:-TEST_SIZE].copy()
    df_test = data.iloc[-TEST_SIZE:].copy()
    print(f"\n[분리] Train: {df_train.shape}, Test: {df_test.shape}")

    # 3. EDA
    run_eda(df_train)

    # 4. 전처리
    print("\n[전처리] Train (KNNImputer)...")
    t0 = time.time()
    train_imputed, train_dates, feature_names, scaler, imputer = preprocess(df_train, fit=True)
    print(f"  Train 전처리 소요: {time.time()-t0:.1f}초")

    print("[전처리] Test...")
    t0 = time.time()
    test_imputed, test_dates, _, _, _ = preprocess(df_test, scaler=scaler, imputer=imputer, fit=False)
    print(f"  Test 전처리 소요: {time.time()-t0:.1f}초")

    print(f"\n  Train imputed: {train_imputed.shape}")
    print(f"  Test imputed:  {test_imputed.shape}")
    print(f"  Features: {len(feature_names)}")

    # scaler/imputer 저장
    joblib.dump(scaler, os.path.join(MODEL_DIR, 'scaler.pkl'))
    joblib.dump(imputer, os.path.join(MODEL_DIR, 'imputer.pkl'))
    print(f"[저장] {MODEL_DIR}/scaler.pkl, imputer.pkl")

    # 5. 시퀀스 생성
    seq_train, idx_train = create_sequences(train_imputed, WINDOW_SIZE)
    seq_test, idx_test = create_sequences(test_imputed, WINDOW_SIZE)

    print(f"\n[시퀀스] Train: {seq_train.shape}, Test: {seq_test.shape}")

    timesteps = seq_train.shape[1]
    input_dim = seq_train.shape[2]

    # 6. 모델 빌드 & 학습 (GPU)
    model = build_autoencoder(timesteps, input_dim)
    model.summary()

    callbacks = [
        EarlyStopping(monitor='val_loss', patience=PATIENCE, restore_best_weights=True),
        ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=3, min_lr=1e-6),
    ]

    print(f"\n[학습] GPU: {'Yes' if gpus else 'No'}, batch_size={BATCH_SIZE}")
    train_start = time.time()

    history = model.fit(
        seq_train, seq_train,
        epochs=EPOCHS, batch_size=BATCH_SIZE,
        validation_split=0.2,
        callbacks=callbacks,
        verbose=1,
    )

    train_elapsed = time.time() - train_start
    print(f"\n[학습 완료] 소요: {train_elapsed:.1f}초 ({train_elapsed/60:.1f}분)")

    # Loss 플롯
    plt.figure(figsize=(10, 4))
    plt.plot(history.history['loss'], label='train')
    plt.plot(history.history['val_loss'], label='val')
    plt.title('Training Loss')
    plt.xlabel('Epoch')
    plt.ylabel('MSE')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_DIR, '02_training_loss.png'), dpi=150)
    print(f"[저장] {OUTPUT_DIR}/02_training_loss.png")
    plt.show()

    # 모델 저장
    model_path = os.path.join(MODEL_DIR, 'lstm_ae_m14.keras')
    model.save(model_path)
    print(f"[저장] {model_path}")

    # 7. Threshold 산출 (train 기준 자동)
    train_err = reconstruction_error(model, seq_train)
    threshold = np.percentile(train_err, THRESHOLD_PERCENTILE)
    print(f"\n[Threshold] train_err mean={train_err.mean():.2f}, std={train_err.std():.2f}")
    print(f"[Threshold] {THRESHOLD_PERCENTILE}th percentile = {threshold:.2f}")

    # 8. Train 평가
    train_plot_dates = train_dates.iloc[idx_train].values

    print("\n[평가] Train 재구성 오차:")
    train_anom_mask = plot_recon_error(
        train_plot_dates, train_err, threshold,
        title='Train Reconstruction Error',
        save_png=os.path.join(OUTPUT_DIR, '03_train_recon_error.png'),
        save_html=os.path.join(OUTPUT_DIR, '04_train_recon_error.html'),
    )

    # Train anomaly on TOTALCNT
    target_var = 'TOTALCNT'
    if target_var in feature_names:
        train_segment = df_train.set_index('CURRTIME')
        anom_times_train = pd.DatetimeIndex(train_plot_dates[train_anom_mask])

        anom_vals = train_segment.loc[anom_times_train, target_var] if len(anom_times_train) > 0 else []
        plot_anomaly_on_timeseries(
            train_segment.index, train_segment[target_var],
            anom_times_train, anom_vals,
            var_name=target_var, title_suffix='(Train)',
            save_png=os.path.join(OUTPUT_DIR, '05_train_totalcnt_anomaly.png'),
            save_html=os.path.join(OUTPUT_DIR, '06_train_totalcnt_anomaly.html'),
        )

    # 9. Test 평가 (동일 threshold 적용)
    test_err = reconstruction_error(model, seq_test)
    test_plot_dates = test_dates.iloc[idx_test].values

    print("\n[평가] Test 재구성 오차 (same threshold):")
    test_anom_mask = plot_recon_error(
        test_plot_dates, test_err, threshold,
        title=f'Test Reconstruction Error (Threshold: {threshold:.2f})',
        save_png=os.path.join(OUTPUT_DIR, '07_test_recon_error.png'),
        save_html=os.path.join(OUTPUT_DIR, '08_test_recon_error.html'),
    )

    if target_var in feature_names:
        test_segment = df_test.set_index('CURRTIME')
        anom_times_test = pd.DatetimeIndex(test_plot_dates[test_anom_mask])

        anom_vals_test = test_segment.loc[anom_times_test, target_var] if len(anom_times_test) > 0 else []
        plot_anomaly_on_timeseries(
            test_segment.index, test_segment[target_var],
            anom_times_test, anom_vals_test,
            var_name=target_var, title_suffix='(Test)',
            save_png=os.path.join(OUTPUT_DIR, '09_test_totalcnt_anomaly.png'),
            save_html=os.path.join(OUTPUT_DIR, '10_test_totalcnt_anomaly.html'),
        )

    # 10. Feature 기여도 분석
    print("\n[Feature 기여도] Test anomaly 기준 Top 10:")
    contrib = feature_contribution(model, seq_test, test_anom_mask, feature_names)
    for name, val in contrib:
        print(f"  {name}: {val:.2f}")

    plot_feature_contribution(
        contrib,
        save_png=os.path.join(OUTPUT_DIR, '11_feature_contribution.png'),
        save_html=os.path.join(OUTPUT_DIR, '12_feature_contribution.html'),
    )

    # 11. 결과 요약 저장
    total_elapsed = time.time() - total_start

    summary = {
        'threshold': float(threshold),
        'threshold_percentile': THRESHOLD_PERCENTILE,
        'train_anomalies': int(train_anom_mask.sum()),
        'train_total': int(len(train_err)),
        'test_anomalies': int(test_anom_mask.sum()),
        'test_total': int(len(test_err)),
        'train_err_mean': float(train_err.mean()),
        'train_err_std': float(train_err.std()),
        'test_err_mean': float(test_err.mean()),
        'test_err_std': float(test_err.std()),
        'top_features': contrib,
        'train_time_sec': round(train_elapsed, 1),
        'total_time_sec': round(total_elapsed, 1),
        'gpu_used': bool(gpus),
    }

    with open(os.path.join(OUTPUT_DIR, 'summary.json'), 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    # 최종 출력
    print(f"\n{'='*70}")
    print(f"[완료] 모든 결과 → {OUTPUT_DIR}/")
    print(f"{'='*70}")
    print(f"  01_missing_matrix.png")
    print(f"  02_training_loss.png")
    print(f"  03_train_recon_error.png      04_train_recon_error.html")
    print(f"  05_train_totalcnt_anomaly.png  06_train_totalcnt_anomaly.html")
    print(f"  07_test_recon_error.png        08_test_recon_error.html")
    print(f"  09_test_totalcnt_anomaly.png   10_test_totalcnt_anomaly.html")
    print(f"  11_feature_contribution.png    12_feature_contribution.html")
    print(f"  summary.json")
    print(f"\n  학습 소요: {train_elapsed:.1f}초 ({train_elapsed/60:.1f}분)")
    print(f"  전체 소요: {total_elapsed:.1f}초 ({total_elapsed/60:.1f}분)")
    print(f"  GPU: {'Yes' if gpus else 'No (CPU)'}")
    print(f"  Train anomalies: {summary['train_anomalies']}/{summary['train_total']}")
    print(f"  Test anomalies:  {summary['test_anomalies']}/{summary['test_total']}")
    print(f"  Threshold: {threshold:.2f} ({THRESHOLD_PERCENTILE}th percentile)")
    print(f"{'='*70}")

    return model, threshold, summary


if __name__ == '__main__':
    model, threshold, summary = main()
