# -*- mode: python ; coding: utf-8 -*-
# GLB 빌더 PyInstaller spec 파일
# 빌드: pyinstaller --noconfirm GLB빌더.spec

from PyInstaller.utils.hooks import collect_data_files, collect_submodules

# rembg 모델 데이터 및 서브모듈
rembg_datas = collect_data_files('rembg')
rembg_imports = collect_submodules('rembg')

# trimesh 서브모듈
trimesh_imports = collect_submodules('trimesh')

a = Analysis(
    ['glb_builder_ui.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('build_glb.py', '.'),
    ] + rembg_datas,
    hiddenimports=[
        'PIL', 'PIL.Image', 'PIL.ImageTk', 'PIL.ImageDraw', 'PIL.ImageFilter',
        'numpy',
        'trimesh', 'trimesh.visual', 'trimesh.visual.material',
        'trimesh.exchange', 'trimesh.exchange.gltf',
        'rembg', 'rembg.sessions',
    ] + rembg_imports + trimesh_imports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'PyQt5', 'PyQt6', 'PySide2', 'PySide6',
        'matplotlib', 'IPython', 'jupyter',
        'pandas', 'sympy', 'numba', 'scipy',
    ],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='GLBBuilder',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
