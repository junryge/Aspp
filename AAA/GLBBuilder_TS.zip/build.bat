@echo off
echo ========================================
echo   GLB Builder
echo ========================================
echo.

echo [1/2] Installing dependencies...
pip install -r requirements.txt pyinstaller
if errorlevel 1 (
    echo ERROR: pip install failed!
    pause
    exit /b 1
)
echo.

echo [2/2] Building EXE...
pyinstaller --noconfirm GLBBuilder.spec
if errorlevel 1 (
    echo ERROR: Build failed!
    pause
    exit /b 1
)

echo.
echo ========================================
echo   Build complete!
echo   Output: dist\GLBBuilder.exe
echo ========================================
pause
