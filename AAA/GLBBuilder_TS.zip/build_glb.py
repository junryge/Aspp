"""
건물 사진들로부터 GLB 3D 모델을 생성하는 스크립트.
각 폴더에 정면.png, 후문.png, 왼쪽.png, 오른쪽.png, 윗면.png 이 있어야 함.
사용법: python build_glb.py <폴더1> [폴더2] [폴더3] ...
"""
import sys
import os
import numpy as np
from PIL import Image
import trimesh
from rembg import remove as rembg_remove


def remove_and_crop(img: Image.Image) -> Image.Image:
    """AI 배경 제거 → 크롭. 배경은 투명(alpha=0) 유지."""
    removed = rembg_remove(img).convert("RGBA")

    data = np.array(removed)
    alpha = data[:, :, 3]
    rows = np.any(alpha > 0, axis=1)
    cols = np.any(alpha > 0, axis=0)
    if not rows.any() or not cols.any():
        return removed
    t, b = np.where(rows)[0][[0, -1]]
    l, r = np.where(cols)[0][[0, -1]]

    # 원본 RGB + rembg 알파 결합
    orig = np.array(img.convert("RGBA"))
    result = orig[t:b+1, l:r+1].copy()
    result[:, :, 3] = alpha[t:b+1, l:r+1]  # rembg 알파 적용

    return Image.fromarray(result)


def simple_crop(img: Image.Image, threshold=245) -> Image.Image:
    """흰색 테두리만 잘라내기 (배경 제거 없이)."""
    data = np.array(img)
    # 흰색이 아닌 픽셀 찾기
    not_white = ~((data[:, :, 0] > threshold) &
                  (data[:, :, 1] > threshold) &
                  (data[:, :, 2] > threshold))
    rows = np.any(not_white, axis=1)
    cols = np.any(not_white, axis=0)
    if not rows.any() or not cols.any():
        return img
    top, bottom = np.where(rows)[0][[0, -1]]
    left, right = np.where(cols)[0][[0, -1]]
    return img.crop((int(left), int(top), int(right + 1), int(bottom + 1)))


def get_content_bbox(img: Image.Image):
    """투명하지 않은 영역의 bounding box 반환 (left, top, right, bottom)"""
    data = np.array(img)
    alpha = data[:, :, 3]
    rows = np.any(alpha > 0, axis=1)
    cols = np.any(alpha > 0, axis=0)
    if not rows.any() or not cols.any():
        return 0, 0, img.width, img.height
    top, bottom = np.where(rows)[0][[0, -1]]
    left, right = np.where(cols)[0][[0, -1]]
    return int(left), int(top), int(right + 1), int(bottom + 1)


def crop_to_content(img: Image.Image) -> Image.Image:
    """건물 부분만 크롭"""
    bbox = get_content_bbox(img)
    return img.crop(bbox)


def create_atlas_and_mesh(images, hw, hh, hd, top_y, insets=None):
    """모든 면의 텍스처를 하나의 아틀라스로 합치고 단일 메쉬 생성."""
    # 아틀라스 크기: 3x2 그리드로 배치
    # [front] [back ] [top   ]
    # [left ] [right] [bottom]
    atlas_cell = 512  # 각 셀 크기
    atlas_w = atlas_cell * 3
    atlas_h = atlas_cell * 2
    atlas = Image.new("RGBA", (atlas_w, atlas_h), (0, 0, 0, 0))  # 투명 배경

    # 각 면을 아틀라스에 배치
    face_positions = {
        "front":  (0, 0),
        "back":   (1, 0),
        "top":    (2, 0),
        "left":   (0, 1),
        "right":  (1, 1),
        "bottom": (2, 1),
    }

    for face_name, (col, row) in face_positions.items():
        if face_name == "bottom":
            cell = Image.new("RGBA", (atlas_cell, atlas_cell), (128, 128, 128, 255))
        elif face_name in images:
            cell = images[face_name].resize((atlas_cell, atlas_cell), Image.LANCZOS)
        else:
            cell = Image.new("RGBA", (atlas_cell, atlas_cell), (200, 200, 200, 255))
        # alpha 채널 포함하여 붙이기
        atlas.paste(cell, (col * atlas_cell, row * atlas_cell), cell)

    # UV 좌표 계산 (아틀라스 내 각 셀의 위치)
    def cell_uvs(col, row):
        """셀의 UV 좌표 반환 [좌하, 우하, 우상, 좌상]"""
        margin = 0.002  # 텍스처 블리딩 방지
        u0 = col / 3.0 + margin
        u1 = (col + 1) / 3.0 - margin
        v0 = 1.0 - (row + 1) / 2.0 + margin  # Y 반전
        v1 = 1.0 - row / 2.0 - margin
        return [[u0, v0], [u1, v0], [u1, v1], [u0, v1]]

    # 단일 메쉬의 모든 vertices, faces, uvs
    all_verts = []
    all_faces = []
    all_uvs = []
    vert_offset = 0

    # 각 면 정의: (vertices, face_name, col, row)
    face_defs = []

    # 면별 inset (안쪽으로 밀어넣기)
    if insets is None:
        insets = {}
    fi = insets.get("front", 0.0)   # 정면 inset (Z축 안쪽)
    bi = insets.get("back", 0.0)    # 후면 inset (Z축 안쪽)
    li = insets.get("left", 0.0)    # 왼쪽 inset (X축 안쪽)
    ri = insets.get("right", 0.0)   # 오른쪽 inset (X축 안쪽)

    # 모서리 틈 방지용 확장값
    e = 0.005

    # 정면 (+Z) - fi만큼 안쪽(-Z방향)으로
    if "front" in images:
        z = hd - fi
        face_defs.append(([[-hw - e, -hh - e, z], [hw + e, -hh - e, z], [hw + e, hh + e, z], [-hw - e, hh + e, z]], "front", 0, 0))
    # 후면 (-Z) - bi만큼 안쪽(+Z방향)으로
    if "back" in images:
        z = -hd + bi
        face_defs.append(([[hw + e, -hh - e, z], [-hw - e, -hh - e, z], [-hw - e, hh + e, z], [hw + e, hh + e, z]], "back", 1, 0))
    # 왼쪽 (-X) - li만큼 안쪽(+X방향)으로
    if "left" in images:
        x = -hw + li
        face_defs.append(([[x, -hh - e, -hd - e], [x, -hh - e, hd + e], [x, hh + e, hd + e], [x, hh + e, -hd - e]], "left", 0, 1))
    # 오른쪽 (+X) - ri만큼 안쪽(-X방향)으로
    if "right" in images:
        x = hw - ri
        face_defs.append(([[x, -hh - e, hd + e], [x, -hh - e, -hd - e], [x, hh + e, -hd - e], [x, hh + e, hd + e]], "right", 1, 1))
    # 윗면 (+Y) - 살짝 확장
    if "top" in images:
        face_defs.append(([[-hw - e, top_y, hd + e], [hw + e, top_y, hd + e], [hw + e, top_y, -hd - e], [-hw - e, top_y, -hd - e]], "top", 2, 0))
    # 바닥 (-Y)
    face_defs.append(([[-hw - e, -hh, -hd - e], [hw + e, -hh, -hd - e], [hw + e, -hh, hd + e], [-hw - e, -hh, hd + e]], "bottom", 2, 1))

    for verts, face_name, col, row in face_defs:
        all_verts.extend(verts)
        all_faces.append([vert_offset, vert_offset + 1, vert_offset + 2])
        all_faces.append([vert_offset, vert_offset + 2, vert_offset + 3])

        uvs = cell_uvs(col, row)
        # 윗면 UV 회전 보정
        if face_name == "top":
            uvs = [uvs[0], uvs[1], uvs[2], uvs[3]]
        all_uvs.extend(uvs)

        vert_offset += 4

    # 단일 메쉬 생성
    material = trimesh.visual.material.PBRMaterial(
        baseColorTexture=atlas,
        alphaMode="MASK",
        alphaCutoff=0.5,
        name="building"
    )
    visual = trimesh.visual.TextureVisuals(
        uv=np.array(all_uvs, dtype=np.float64),
        material=material
    )
    mesh = trimesh.Trimesh(
        vertices=np.array(all_verts, dtype=np.float64),
        faces=np.array(all_faces, dtype=np.int64),
        visual=visual,
        process=False
    )
    return mesh


def build_glb(folder_path: str):
    """폴더 내 사진들로 GLB 생성"""
    # 파일 매핑
    face_files = {
        "front": "정면.png",
        "back": "후문.png",
        "left": "왼쪽.png",
        "right": "오른쪽.png",
        "top": "윗면.png",
    }

    # 이미지 로드 및 배경 제거 (윗면은 배경 제거 안함)
    images = {}
    for face, filename in face_files.items():
        filepath = os.path.join(folder_path, filename)
        if not os.path.exists(filepath):
            print(f"  경고: {filepath} 없음, 건너뜀")
            continue
        img = Image.open(filepath).convert("RGBA")
        if face == "top":
            img = simple_crop(img)
        else:
            img = remove_and_crop(img)
        images[face] = img
        print(f"  {face}: {img.width}x{img.height}")

    if "front" not in images:
        print(f"  오류: 정면.png가 없어서 건너뜁니다.")
        return

    # 비율 계산 (정면 기준)
    front = images["front"]
    W = front.width   # 건물 너비
    H = front.height  # 건물 높이

    # 깊이는 왼쪽면 가로에서 추출
    if "left" in images:
        D = images["left"].width
    elif "right" in images:
        D = images["right"].width
    else:
        D = H  # 기본값

    # 정규화 (가장 큰 값을 기준으로)
    max_dim = max(W, H, D)
    w = W / max_dim
    h = H / max_dim
    d = D / max_dim

    print(f"  비율: W={w:.2f}, H={h:.2f}, D={d:.2f}")

    hw = w / 2
    hh = h / 2
    hd = d / 2

    # 윗면 오프셋: 벽 상단에서 안쪽으로 내려감
    top_inset = h * 0.08  # 높이의 8% 만큼 아래로
    top_y = hh - top_inset

    # 하나의 텍스처 아틀라스 + 단일 메쉬로 생성
    mesh = create_atlas_and_mesh(images, hw, hh, hd, top_y)

    scene = trimesh.Scene()
    scene.add_geometry(mesh, node_name="building")

    output_path = os.path.join(folder_path, "building.glb")
    scene.export(output_path, file_type="glb")
    file_size = os.path.getsize(output_path)
    print(f"  저장: {output_path} ({file_size / 1024:.1f} KB)")


def main():
    if len(sys.argv) < 2:
        # 인자 없으면 현재 디렉토리의 모든 하위 폴더 처리
        base = os.path.dirname(os.path.abspath(__file__))
        folders = sorted([
            os.path.join(base, d) for d in os.listdir(base)
            if os.path.isdir(os.path.join(base, d))
        ])
        if not folders:
            print("사용법: python build_glb.py <폴더1> [폴더2] ...")
            sys.exit(1)
    else:
        folders = sys.argv[1:]

    for folder in folders:
        folder = os.path.abspath(folder)
        if not os.path.isdir(folder):
            print(f"폴더 없음: {folder}")
            continue
        print(f"처리 중: {folder}")
        build_glb(folder)
    print("완료!")


if __name__ == "__main__":
    main()
