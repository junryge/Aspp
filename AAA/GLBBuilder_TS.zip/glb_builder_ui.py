"""
GLB 빌더 UI - 마우스로 이미지 조정, 배경 투명, 크기 조절 가능
"""
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from PIL import Image, ImageTk, ImageDraw
import os
import threading
import numpy as np

from build_glb import remove_and_crop, simple_crop, create_atlas_and_mesh
import trimesh
from rembg import remove as rembg_remove


class FaceEditor(tk.Canvas):
    """각 면의 이미지를 보여주고 마우스로 위치/크기 조정하는 캔버스."""
    def __init__(self, parent, face_name, label_kr, width=200, height=160):
        super().__init__(parent, width=width, height=height, bg="#333333", highlightthickness=1, highlightbackground="#888")
        self.face_name = face_name
        self.label_kr = label_kr
        self.canvas_w = width
        self.canvas_h = height

        self.original_img = None      # 원본 PIL Image
        self.processed_img = None     # 처리된 PIL Image (배경 제거 등)
        self.display_img = None       # 표시용 PhotoImage
        self.img_path = None

        # 이미지 위치/크기
        self.img_x = 0
        self.img_y = 0
        self.img_scale = 1.0

        # 설정
        self.remove_bg = tk.BooleanVar(value=True)
        self.is_processing = False

        # 라벨 표시
        self.create_text(width // 2, height // 2, text=f"{label_kr}\n클릭하여 이미지 로드",
                         fill="#aaa", font=("", 10), tag="placeholder", justify="center")

        # 이벤트 바인딩
        self.bind("<Button-1>", self._on_click)
        self.bind("<B1-Motion>", self._on_drag)
        self.bind("<ButtonPress-1>", self._start_drag)
        self.bind("<MouseWheel>", self._on_scroll)
        self.bind("<Button-3>", self._on_right_click)

        self._last_x = 0
        self._last_y = 0

    def _on_click(self, event):
        if self.original_img is None:
            self.load_image()

    def _start_drag(self, event):
        self._last_x = event.x
        self._last_y = event.y

    def _on_drag(self, event):
        if self.processed_img is None:
            return
        dx = event.x - self._last_x
        dy = event.y - self._last_y
        self.img_x += dx
        self.img_y += dy
        self._last_x = event.x
        self._last_y = event.y
        self._render()

    def _on_scroll(self, event):
        if self.processed_img is None:
            return
        if event.delta > 0:
            self.img_scale *= 1.1
        else:
            self.img_scale *= 0.9
        self.img_scale = max(0.1, min(5.0, self.img_scale))
        self._render()

    def _on_right_click(self, event):
        """우클릭 메뉴"""
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(label="이미지 로드", command=self.load_image)
        menu.add_command(label="이미지 제거", command=self.clear_image)
        menu.add_separator()
        menu.add_checkbutton(label="배경 제거", variable=self.remove_bg, command=self._reprocess)
        menu.add_separator()
        menu.add_command(label="크기 맞추기", command=self._fit_to_canvas)
        menu.post(event.x_root, event.y_root)

    def load_image(self, path=None):
        if path is None:
            path = filedialog.askopenfilename(
                title=f"{self.label_kr} 이미지 선택",
                filetypes=[("이미지", "*.png *.jpg *.jpeg *.bmp *.tiff")]
            )
        if not path:
            return
        self.img_path = path
        self.original_img = Image.open(path).convert("RGBA")
        self._reprocess()

    def _reprocess(self):
        if self.original_img is None:
            return
        self.is_processing = True
        self.delete("all")
        self.create_text(self.canvas_w // 2, self.canvas_h // 2,
                         text="처리 중...", fill="#fff", font=("", 10))

        def worker():
            try:
                if self.remove_bg.get() and self.face_name != "top":
                    img = remove_and_crop(self.original_img.copy())
                elif self.face_name == "top":
                    img = simple_crop(self.original_img.copy())
                else:
                    img = self.original_img.copy()
                self.processed_img = img
                self.after(0, self._fit_to_canvas)
            except Exception as e:
                self.after(0, lambda: self._show_error(str(e)))
            finally:
                self.is_processing = False

        threading.Thread(target=worker, daemon=True).start()

    def _show_error(self, msg):
        self.delete("all")
        self.create_text(self.canvas_w // 2, self.canvas_h // 2,
                         text=f"오류: {msg}", fill="red", font=("", 9))

    def _fit_to_canvas(self):
        if self.processed_img is None:
            return
        w, h = self.processed_img.size
        scale_x = (self.canvas_w - 10) / w
        scale_y = (self.canvas_h - 10) / h
        self.img_scale = min(scale_x, scale_y)
        self.img_x = (self.canvas_w - w * self.img_scale) / 2
        self.img_y = (self.canvas_h - h * self.img_scale) / 2
        self._render()

    def _render(self):
        if self.processed_img is None:
            return
        self.delete("all")

        # 체커보드 배경 (투명 영역 표시)
        self._draw_checker()

        w = int(self.processed_img.width * self.img_scale)
        h = int(self.processed_img.height * self.img_scale)
        if w < 1 or h < 1:
            return

        resized = self.processed_img.resize((w, h), Image.LANCZOS)
        self.display_img = ImageTk.PhotoImage(resized)
        self.create_image(int(self.img_x), int(self.img_y), image=self.display_img, anchor="nw")

        # 라벨
        self.create_text(5, 5, text=self.label_kr, fill="#fff", font=("", 9, "bold"), anchor="nw")
        self.create_text(5, 20, text=f"{self.processed_img.width}x{self.processed_img.height}",
                         fill="#aaa", font=("", 8), anchor="nw")

    def _draw_checker(self):
        """투명 영역을 보여주는 체커보드 패턴."""
        size = 10
        for y in range(0, self.canvas_h, size):
            for x in range(0, self.canvas_w, size):
                color = "#444" if (x // size + y // size) % 2 == 0 else "#555"
                self.create_rectangle(x, y, x + size, y + size, fill=color, outline="")

    def clear_image(self):
        self.original_img = None
        self.processed_img = None
        self.display_img = None
        self.img_path = None
        self.delete("all")
        self.create_text(self.canvas_w // 2, self.canvas_h // 2,
                         text=f"{self.label_kr}\n클릭하여 이미지 로드",
                         fill="#aaa", font=("", 10), tag="placeholder", justify="center")

    def get_image(self):
        return self.processed_img


class GLBBuilderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("GLB 빌더 - 건물 3D 모델 생성")
        self.root.geometry("1100x750")
        self.root.configure(bg="#2b2b2b")

        style = ttk.Style()
        style.theme_use("clam")
        style.configure(".", background="#2b2b2b", foreground="#ddd")
        style.configure("TLabelframe", background="#2b2b2b", foreground="#ddd")
        style.configure("TLabelframe.Label", background="#2b2b2b", foreground="#ddd")
        style.configure("TButton", background="#444", foreground="#ddd")
        style.configure("TCheckbutton", background="#2b2b2b", foreground="#ddd")
        style.configure("TLabel", background="#2b2b2b", foreground="#ddd")
        style.configure("TScale", background="#2b2b2b")
        style.configure("Accent.TButton", background="#0078d4", foreground="#fff")

        self.editors = {}
        self._build_ui()

    def _build_ui(self):
        # 상단 툴바
        toolbar = ttk.Frame(self.root)
        toolbar.pack(fill="x", padx=10, pady=5)

        ttk.Button(toolbar, text="폴더 열기", command=self._load_folder).pack(side="left", padx=2)
        ttk.Button(toolbar, text="전체 초기화", command=self._clear_all).pack(side="left", padx=2)

        ttk.Separator(toolbar, orient="vertical").pack(side="left", fill="y", padx=10)

        self.btn_build = ttk.Button(toolbar, text="GLB 생성", command=self._build)
        self.btn_build.pack(side="left", padx=5)

        ttk.Button(toolbar, text="자동 크기", command=self._auto_size).pack(side="left", padx=2)

        self.status_var = tk.StringVar(value="준비됨 | 각 면을 클릭하여 이미지를 로드하세요. 우클릭으로 옵션 메뉴.")
        ttk.Label(toolbar, textvariable=self.status_var, foreground="#999").pack(side="right")

        # 메인 영역: 5면 에디터 + 조정 패널
        main = ttk.Frame(self.root)
        main.pack(fill="both", expand=True, padx=10, pady=5)

        # 레이아웃:
        #        [  윗면  ]
        # [왼쪽] [정면] [오른쪽] [후문]
        face_layout = {
            "top":   (0, 1),
            "left":  (1, 0),
            "front": (1, 1),
            "right": (1, 2),
            "back":  (1, 3),
        }

        labels_kr = {
            "front": "정면", "back": "후문", "left": "왼쪽",
            "right": "오른쪽", "top": "윗면"
        }

        for face, (row, col) in face_layout.items():
            editor = FaceEditor(main, face, labels_kr[face], width=230, height=180)
            editor.grid(row=row, column=col, padx=3, pady=3, sticky="nsew")
            self.editors[face] = editor

        for i in range(4):
            main.columnconfigure(i, weight=1)
        main.rowconfigure(0, weight=1)
        main.rowconfigure(1, weight=1)

        # 하단: 크기/인셋 조정 패널
        ctrl_frame = ttk.LabelFrame(self.root, text="3D 모델 크기 조정")
        ctrl_frame.pack(fill="x", padx=10, pady=3)

        # 건물 크기 (너비/높이/깊이)
        size_row = ttk.Frame(ctrl_frame)
        size_row.pack(fill="x", padx=5, pady=2)

        ttk.Label(size_row, text="너비(W):").pack(side="left")
        self.size_w = tk.DoubleVar(value=1.0)
        ttk.Spinbox(size_row, from_=0.1, to=10.0, increment=0.05, textvariable=self.size_w, width=6).pack(side="left", padx=2)

        ttk.Label(size_row, text="높이(H):").pack(side="left", padx=(10, 0))
        self.size_h = tk.DoubleVar(value=1.0)
        ttk.Spinbox(size_row, from_=0.1, to=10.0, increment=0.05, textvariable=self.size_h, width=6).pack(side="left", padx=2)

        ttk.Label(size_row, text="깊이(D):").pack(side="left", padx=(10, 0))
        self.size_d = tk.DoubleVar(value=1.0)
        ttk.Spinbox(size_row, from_=0.1, to=10.0, increment=0.05, textvariable=self.size_d, width=6).pack(side="left", padx=2)

        self.auto_size_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(size_row, text="자동", variable=self.auto_size_var).pack(side="left", padx=10)

        # 면별 인셋 + 윗면 내림
        inset_row = ttk.Frame(ctrl_frame)
        inset_row.pack(fill="x", padx=5, pady=2)

        ttk.Label(inset_row, text="면 인셋(%):").pack(side="left")

        self.inset_front = tk.DoubleVar(value=0.0)
        ttk.Label(inset_row, text="정면").pack(side="left", padx=(5, 0))
        ttk.Spinbox(inset_row, from_=0, to=30, increment=0.5, textvariable=self.inset_front, width=5).pack(side="left", padx=2)

        self.inset_back = tk.DoubleVar(value=0.0)
        ttk.Label(inset_row, text="후면").pack(side="left", padx=(5, 0))
        ttk.Spinbox(inset_row, from_=0, to=30, increment=0.5, textvariable=self.inset_back, width=5).pack(side="left", padx=2)

        self.inset_left = tk.DoubleVar(value=0.0)
        ttk.Label(inset_row, text="왼쪽").pack(side="left", padx=(5, 0))
        ttk.Spinbox(inset_row, from_=0, to=30, increment=0.5, textvariable=self.inset_left, width=5).pack(side="left", padx=2)

        self.inset_right = tk.DoubleVar(value=0.0)
        ttk.Label(inset_row, text="오른쪽").pack(side="left", padx=(5, 0))
        ttk.Spinbox(inset_row, from_=0, to=30, increment=0.5, textvariable=self.inset_right, width=5).pack(side="left", padx=2)

        self.top_inset = tk.DoubleVar(value=8.0)
        ttk.Label(inset_row, text="윗면내림").pack(side="left", padx=(5, 0))
        ttk.Spinbox(inset_row, from_=0, to=30, increment=0.5, textvariable=self.top_inset, width=5).pack(side="left", padx=2)

        # 하단: 조작 안내
        help_frame = ttk.Frame(self.root)
        help_frame.pack(fill="x", padx=10, pady=3)
        ttk.Label(help_frame, text="조작: 클릭=이미지 로드 | 드래그=이동 | 스크롤=확대/축소 | 우클릭=메뉴(배경제거 ON/OFF) | 자동크기=이미지 비율로 크기 계산",
                  foreground="#777", font=("", 9)).pack()

    def _load_folder(self):
        folder = filedialog.askdirectory(title="건물 사진 폴더 선택")
        if not folder:
            return

        file_map = {
            "front": "정면.png", "back": "후문.png", "left": "왼쪽.png",
            "right": "오른쪽.png", "top": "윗면.png",
        }

        found = 0
        for face, filename in file_map.items():
            filepath = os.path.join(folder, filename)
            if os.path.exists(filepath):
                self.editors[face].load_image(filepath)
                found += 1

        self.output_folder = folder
        self.status_var.set(f"{found}/5 이미지 로드됨 | 폴더: {folder}")

    def _clear_all(self):
        for editor in self.editors.values():
            editor.clear_image()
        self.status_var.set("전체 초기화됨")

    def _auto_size(self):
        """이미지 비율로 W/H/D 자동 계산"""
        front = self.editors["front"].get_image()
        if front is None:
            messagebox.showwarning("알림", "정면 이미지를 먼저 로드하세요.")
            return

        W, H = front.width, front.height
        left_img = self.editors["left"].get_image()
        right_img = self.editors["right"].get_image()
        if left_img:
            D = left_img.width
        elif right_img:
            D = right_img.width
        else:
            D = H

        max_dim = max(W, H, D)
        w = W / max_dim
        h = H / max_dim
        d = D / max_dim

        self.size_w.set(round(w, 3))
        self.size_h.set(round(h, 3))
        self.size_d.set(round(d, 3))
        self.status_var.set(f"자동 크기: W={w:.3f}, H={h:.3f}, D={d:.3f}")

    def _build(self):
        front = self.editors["front"].get_image()
        if front is None:
            messagebox.showerror("오류", "최소 정면 이미지가 필요합니다.")
            return

        output_dir = getattr(self, "output_folder", None)
        if not output_dir:
            output_dir = filedialog.askdirectory(title="저장 폴더 선택")
            if not output_dir:
                return
            self.output_folder = output_dir

        # 자동이면 먼저 크기 계산
        if self.auto_size_var.get():
            self._auto_size()

        self.btn_build.configure(state="disabled")
        self.status_var.set("GLB 생성 중...")

        def worker():
            try:
                images = {}
                for face, editor in self.editors.items():
                    img = editor.get_image()
                    if img is not None:
                        images[face] = img

                w = self.size_w.get()
                h = self.size_h.get()
                d = self.size_d.get()
                hw, hh, hd = w / 2, h / 2, d / 2

                top_inset_pct = self.top_inset.get() / 100.0
                top_y = hh - h * top_inset_pct

                # 면별 인셋
                insets = {
                    "front": d * (self.inset_front.get() / 100.0),
                    "back":  d * (self.inset_back.get() / 100.0),
                    "left":  w * (self.inset_left.get() / 100.0),
                    "right": w * (self.inset_right.get() / 100.0),
                }

                mesh = create_atlas_and_mesh(images, hw, hh, hd, top_y, insets=insets)

                scene = trimesh.Scene()
                scene.add_geometry(mesh, node_name="building")

                output_path = os.path.join(output_dir, "building.glb")
                scene.export(output_path, file_type="glb")
                size_kb = os.path.getsize(output_path) / 1024

                self.root.after(0, lambda: self.status_var.set(f"완료! {output_path} ({size_kb:.1f} KB)"))
                self.root.after(0, lambda: messagebox.showinfo("완료", f"GLB 생성 완료!\n{output_path}\n({size_kb:.1f} KB)"))
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("오류", str(e)))
                self.root.after(0, lambda: self.status_var.set(f"오류: {e}"))
            finally:
                self.root.after(0, lambda: self.btn_build.configure(state="normal"))

        threading.Thread(target=worker, daemon=True).start()


def main():
    root = tk.Tk()
    app = GLBBuilderApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
