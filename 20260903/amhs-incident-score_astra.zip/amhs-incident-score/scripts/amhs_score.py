#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AMHS 발동이벤트 / 화면(분석 이벤트) 데이터 분석 CLI  (표준 라이브러리만 사용)

  load     노트북(.txt JSON) 또는 CSV → 정리된 events.csv / screen.csv
  verify   점수 식·PIO 구간표·등급 컷을 자료로 재계산해 어긋난 분 수를 센다
  window   사건 구간 요약 (등급 분포·최고점·PIO·예측 유형·사건추적·PIO 가산 what-if)
  ceiling  날짜별로 켜진 룰·배점 합·화면 천장·등급별 최소 룰 개수
  tracker  날짜별 incident_state / continuity_min / refire_count / stage 동작
  claims   사람이 적은 "시각·점수"를 자료와 분 단위 대조
  runs     한 칸에 특정 값이 이어진 구간 (예: MAXCAPA 축소 구간)
  compare  사건 전/중 지표 평균 비교 (하락형 장애 확인용)
  weight   초과 배율 가중 what-if (값/임계 배율로 룰 배점에 곱) — 제안 규칙 시험용
  chart    window --csv 결과 → 보고서에 넣을 SVG (화면 점수 막대 + PIO 선 + 컷 선)

예)
  python amhs_score.py load 원본1.txt 원본2.txt --out data
  python amhs_score.py verify --event data/events.csv --screen data/screen.csv --cuts M16HUB=43,57,72 --cuts M14=36,52,72
  python amhs_score.py window --event data/events.csv --screen data/screen.csv --fab M16HUB
         --from "2026-09-12 14:00" --to "2026-09-12 16:00" --incident "2026-09-12 14:53" --cuts 43,57,72
  (Python 3.7 이상, 외부 패키지 없음)
"""
import argparse
import csv
import io
import json
import os
import re
import sys
from collections import Counter, OrderedDict
from datetime import datetime, timedelta

csv.field_size_limit(10 ** 9)
try:  # 윈도우 콘솔(cp949)에서 기호 때문에 멈추지 않게
    sys.stdout.reconfigure(errors="replace")
except (AttributeError, ValueError):
    pass
try:  # | head 등으로 출력이 끊겨도 조용히 끝내기
    import signal
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
except (AttributeError, ValueError, ImportError):
    pass

TIME_RE = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$")
FABS = ["M16HUB", "M14", "M14B", "M16A", "M16B"]
LAYER1_FABS = ["M16HUB", "M14", "M14B", "M16A", "M16B", "M16", "M16_WT"]
RULES = ["RA", "RA_sus", "RB", "RB_fast", "RC", "RD", "SLA", "SORT", "MAXCAPA"]
RULE_KO = OrderedDict([
    ("RA", "반송지연"), ("RA_sus", "반송지연 지속"), ("RB", "Queue 누적"),
    ("RB_fast", "Queue 급증"), ("RC", "리프터 정체"), ("RD", "Storage FULL/저장·가동률"),
    ("SLA", "4분초과"), ("SORT", "분류기 대기"), ("MAXCAPA", "용량변경(운영자)"),
])
# 룰 정의 배점. 기존 보고서(hubroom_predictor.py 기준)에서 확인된 값.
# M16HUB MAXCAPA=30, 나머지 FAB MAXCAPA=10. M14B/M16A/M16B 의 전체 표는 보고서에 없어 같은 값으로 둔다.
DEFAULT_PTS = {"RA": 10, "RA_sus": 5, "RB": 10, "RB_fast": 5, "RC": 8, "RD": 7, "SLA": 5, "SORT": 3, "MAXCAPA": 10}
FAB_PTS_OVERRIDE = {"M16HUB": {"MAXCAPA": 30}}
SCREEN_DENOM = 70.0      # 화면 점수 = min(100, round(Σ룰배점 / 70 × 100))
EVENT_CAP = 50           # 발동이벤트 {FAB}_score = min(50, Σ룰배점)
PIO_THRESHOLD = 16       # PIO 10분 합 임계
PIO_BINS = [(81, 11), (63, 9), (41, 7), (26, 4), (16, 2)]  # pio_10min_cnt 이상 → pio_score
GRADES = ["정상", "경계", "위험", "초위험"]
# predicted_fault_type 접두어 → 영역
FAULT_PREFIX = {"M16HUB": ("HUB-",), "M14": ("M14-",), "M14B": ("M14B-",), "M16A": ("M16A-",), "M16B": ("M16B-",)}


# ───────────────────────── 공통 유틸 ─────────────────────────
def die(msg):
    print("오류: " + msg, file=sys.stderr)
    sys.exit(2)


def num(v, default=None):
    if v is None:
        return default
    s = str(v).strip()
    if s == "" or s.lower() in ("nan", "none", "<na>"):
        return default
    try:
        return float(s)
    except ValueError:
        return default


def inum(v, default=0):
    x = num(v, None)
    return default if x is None else int(round(x))


def screen_score(raw):
    return min(100, int(round(raw / SCREEN_DENOM * 100)))


def screen_score_halfup(raw):
    return min(100, int(raw / SCREEN_DENOM * 100 + 0.5))


def pio_points(cnt):
    for lo, pts in PIO_BINS:
        if cnt >= lo:
            return pts
    return 0


def grade_of(score, cuts):
    c1, c2, c3 = cuts
    if score >= c3:
        return "초위험"
    if score >= c2:
        return "위험"
    if score >= c1:
        return "경계"
    return "정상"


def parse_cuts(s):
    try:
        v = [int(x) for x in s.split(",")]
        assert len(v) == 3 and v[0] < v[1] < v[2]
        return v
    except Exception:
        die("--cuts 는 '경계,위험,초위험' 형식 (예: 43,57,72)")


def pt(s):
    try:
        return datetime.strptime(s.strip(), "%Y-%m-%d %H:%M")
    except ValueError:
        die("시각 형식은 'YYYY-MM-DD HH:MM' : " + s)


def hm(t):
    return t.strftime("%H:%M")


def read_table(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def pts_table(fab):
    d = dict(DEFAULT_PTS)
    d.update(FAB_PTS_OVERRIDE.get(fab, {}))
    return d


def rules_on(row, fab):
    return [r for r in RULES if inum(row.get("%s_pts_%s" % (fab, r))) > 0]


def raw_sum(row, fab):
    return sum(inum(row.get("%s_pts_%s" % (fab, r))) for r in RULES)


def fault_hits(ftype, fab):
    ftype = (ftype or "").strip()
    return ftype.startswith(FAULT_PREFIX.get(fab, (fab + "-",)))


def load_event_index(path):
    rows = read_table(path)
    idx = OrderedDict()
    for r in rows:
        t = (r.get("datetime") or "").strip()
        if TIME_RE.match(t):
            idx[t] = r
    return idx


def load_screen_index(path):
    rows = read_table(path)
    idx = {}
    for r in rows:
        t = (r.get("시간") or "").strip()
        if TIME_RE.match(t):
            idx.setdefault(t, r)
    return idx


def screen_fab_value(srow, fab):
    v = num(srow.get(fab))
    if v is None and (srow.get("HI_FAB") or "").strip() == fab:
        v = num(srow.get("종합점수"))
    return v


def minutes(t0, t1):
    t = t0
    while t <= t1:
        yield t
        t += timedelta(minutes=1)


def runs_of(times, gap=1):
    """정렬된 datetime 목록 → [(start, end, n)] (gap 분 이하 끊김은 이어 붙임)"""
    out = []
    for t in times:
        if out and (t - out[-1][1]).total_seconds() / 60 <= gap:
            out[-1][1] = t
            out[-1][2] += 1
        else:
            out.append([t, t, 1])
    return out


# ───────────────────────── load ─────────────────────────
def extract_csv_texts(path):
    with open(path, encoding="utf-8-sig") as f:
        text = f.read()
    s = text.lstrip()
    if s.startswith("{"):
        try:
            nb = json.loads(s)
        except json.JSONDecodeError:
            return [text]
        out = []
        for c in nb.get("cells", []):
            src = c.get("source", "")
            src = "".join(src) if isinstance(src, list) else src
            if src.strip():
                out.append(src)
        return out
    return [text]


def cmd_load(a):
    os.makedirs(a.out, exist_ok=True)
    buckets = {"event": {"header": None, "rows": {}}, "screen": {"header": None, "rows": {}}}
    for path in a.inputs:
        base = os.path.basename(path)
        for k, text in enumerate(extract_csv_texts(path)):
            rd = csv.reader(io.StringIO(text))
            try:
                header = next(rd)
            except StopIteration:
                continue
            if "datetime" in header and "stage" in header:
                kind, tcol = "event", "datetime"
            elif "시간" in header and "등급" in header:
                kind, tcol = "screen", "시간"
            else:
                print("[건너뜀] %s 셀%d : 발동이벤트/화면 헤더가 아님 (%s...)" % (base, k, ",".join(header[:5])))
                continue
            ti = header.index(tcol)
            b = buckets[kind]
            if b["header"] is None:
                b["header"] = list(header)
            elif b["header"] != header:
                if set(b["header"]) == set(header):
                    print("  · %s : 칸 순서가 앞 파일과 달라 칸 이름으로 맞춘다" % base)
                else:
                    extra = [h for h in header if h not in b["header"]]
                    miss = [h for h in b["header"] if h not in header]
                    print("  · %s : 칸 구성이 다르다 (추가 %s / 없음 %s) — 칸 이름으로 맞추고 없는 칸은 비운다" % (
                        base, extra[:5], miss[:5]))
                    b["header"].extend(extra)
            bad, dup, kept, dates = [], 0, 0, Counter()
            for ln, row in enumerate(rd, start=2):
                t = row[ti].strip() if len(row) > ti else ""
                if len(row) != len(header) or not TIME_RE.match(t):
                    bad.append(ln)
                    continue
                if t in b["rows"]:
                    dup += 1
                    continue
                b["rows"][t] = dict(zip(header, row))
                kept += 1
                dates[t[:10]] += 1
            print("[%s] %s : %d분 사용 · 깨진 줄 %d개 버림%s · 중복 %d · 날짜 %s" % (
                "발동이벤트" if kind == "event" else "화면", base, kept, len(bad),
                (" (줄 " + ",".join(map(str, bad[:10])) + ")") if bad else "", dup,
                ", ".join("%s=%d분" % (d, n) for d, n in sorted(dates.items()))))
            m = re.findall(r"(\d{1,2})일", base)
            if m and dates:
                days = {int(d[8:10]) for d in dates}
                if not any(int(x) in days for x in m):
                    print("  ⚠ 파일 이름의 날짜(%s일)와 자료 날짜(%s)가 다르다 — 자료 날짜를 기준으로 쓴다" % (
                        ",".join(m), ",".join(sorted(dates))))
    for kind, fname in (("event", "events.csv"), ("screen", "screen.csv")):
        b = buckets[kind]
        if b["header"] is None:
            continue
        p = os.path.join(a.out, fname)
        with open(p, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(b["header"])
            for t in sorted(b["rows"]):
                r = b["rows"][t]
                w.writerow([r.get(h, "") for h in b["header"]])
        days = Counter(t[:10] for t in b["rows"])
        print("→ %s : %d분 (%s)" % (p, len(b["rows"]), ", ".join("%s %d분" % kv for kv in sorted(days.items()))))
        for d, n in sorted(days.items()):
            if n < 1440:
                print("  · %s 은 %d분이 빈다" % (d, 1440 - n))


# ───────────────────────── verify ─────────────────────────
def cmd_verify(a):
    ev = load_event_index(a.event) if a.event else {}
    sc = load_screen_index(a.screen) if a.screen else {}
    cuts = {}
    for c in a.cuts or []:
        if "=" not in c:
            die("verify 의 --cuts 는 FAB=경계,위험,초위험 형식")
        f, v = c.split("=", 1)
        cuts[f.strip()] = parse_cuts(v)
    ok_all = True
    if ev:
        print("■ 발동이벤트 %d분" % len(ev))
        for fab in FABS:
            if ("%s_score_raw" % fab) not in next(iter(ev.values())):
                continue
            m1 = m2 = 0
            for r in ev.values():
                s = raw_sum(r, fab)
                if inum(r.get("%s_score_raw" % fab)) != s:
                    m1 += 1
                if inum(r.get("%s_score" % fab)) != min(EVENT_CAP, inum(r.get("%s_score_raw" % fab))):
                    m2 += 1
            ok_all &= (m1 == 0 and m2 == 0)
            print("  %-7s score_raw = Σ룰배점 : 어긋난 분 %d · score = min(50, raw) : 어긋난 분 %d" % (fab, m1, m2))
        first = next(iter(ev.values()))
        if "layer1_total" in first:
            m = 0
            for r in ev.values():
                s = sum(inum(r.get("%s_score" % f)) for f in LAYER1_FABS)
                if inum(r.get("layer1_total")) != s:
                    m += 1
            print("  layer1_total = Σ(M16HUB,M14,M14B,M16A,M16B,M16,M16_WT _score) : 어긋난 분 %d" % m)
        if "pio_score" in first:
            m, seen = 0, {}
            for r in ev.values():
                c, p = inum(r.get("pio_10min_cnt")), inum(r.get("pio_score"))
                lo, hi = seen.get(p, (c, c))
                seen[p] = (min(lo, c), max(hi, c))
                if pio_points(c) != p:
                    m += 1
            ok_all &= (m == 0)
            print("  pio_score 구간표(16↑+2·26↑+4·41↑+7·63↑+9·81↑+11) : 어긋난 분 %d" % m)
            print("    관측: " + " · ".join("+%d ← %d~%d개" % (p, lo, hi) for p, (lo, hi) in sorted(seen.items())))
            with_pio = [r for r in ev.values() if inum(r.get("pio_score")) > 0]
            added = sum(1 for r in with_pio if inum(r.get("M16HUB_score_raw")) == raw_sum(r, "M16HUB") + inum(r.get("pio_score")))
            print("  PIO 가산(>0)이 있는 %d분 중 M16HUB_score_raw 에 PIO 가 더해진 분 %d%s" % (
                len(with_pio), added, "  → PIO 는 FAB 점수에 안 들어간다" if with_pio and added == 0 else ""))
    if sc:
        print("■ 화면 %d분" % len(sc))
        bad_hi = sum(1 for r in sc.values()
                     if num(r.get("종합점수")) is not None
                     and screen_fab_value(r, (r.get("HI_FAB") or "").strip()) != num(r.get("종합점수")))
        print("  종합점수 = HI_FAB 칸 값 : 어긋난 분 %d" % bad_hi)
        obs = {}
        for r in sc.values():
            fab = (r.get("HI_FAB") or "").strip()
            s = num(r.get("종합점수"))
            g = (r.get("등급") or "").strip()
            if s is None:
                continue
            d = obs.setdefault(fab, {})
            lo, hi, n = d.get(g, (s, s, 0))
            d[g] = (min(lo, s), max(hi, s), n + 1)
        for fab, d in obs.items():
            print("  %s 등급별 관측 점수: " % fab + " · ".join(
                "%s %d~%d (%d분)" % (g, d[g][0], d[g][1], d[g][2]) for g in GRADES if g in d))
            rng = [d[g] for g in GRADES if g in d]
            for i in range(1, len(rng)):
                print("    → %s 컷은 %d~%d 사이 (자료만으로 좁힐 수 있는 범위)" % (
                    [g for g in GRADES if g in d][i], rng[i - 1][1] + 1, rng[i][0]))
            if fab in cuts:
                m = sum(1 for r in sc.values() if (r.get("HI_FAB") or "").strip() == fab
                        and num(r.get("종합점수")) is not None
                        and grade_of(num(r.get("종합점수")), cuts[fab]) != (r.get("등급") or "").strip())
                ok_all &= (m == 0)
                print("    컷 %s 로 다시 매기면 어긋난 분 %d" % ("/".join(map(str, cuts[fab])), m))
            else:
                print("    컷을 받지 않았다 — 등급 비교는 --cuts %s=경계,위험,초위험 으로" % fab)
    if ev and sc:
        print("■ 두 자료 연결 (분 단위)")
        common = [t for t in sc if t in ev]
        print("  화면 %d분 중 발동이벤트와 맞물린 분 %d" % (len(sc), len(common)))
        for fab in FABS:
            m_r = m_h = n = 0
            for t in common:
                v = screen_fab_value(sc[t], fab)
                if v is None:
                    continue
                n += 1
                raw = inum(ev[t].get("%s_score_raw" % fab))
                if screen_score(raw) != v:
                    m_r += 1
                if screen_score_halfup(raw) != v:
                    m_h += 1
            if n:
                ok_all &= (m_r == 0)
                print("  %-7s 화면 = min(100, round(raw/70×100)) : %d분 중 어긋난 분 %d (반올림 half-up 이면 %d)" % (fab, n, m_r, m_h))
    print("\n결과: " + ("전부 맞음" if ok_all else "어긋난 곳 있음 — 위 줄을 확인"))


# ───────────────────────── window ─────────────────────────
def cmd_window(a):
    ev = load_event_index(a.event)
    sc = load_screen_index(a.screen) if a.screen else {}
    fab = a.fab
    t0, t1 = pt(a.frm), pt(a.to)
    cuts = parse_cuts(a.cuts) if a.cuts else None
    inc = pt(a.incident) if a.incident else None
    ref = pt(a.ref) if a.ref else (inc or t0)
    rows = []
    for t in minutes(t0, t1):
        k = t.strftime("%Y-%m-%d %H:%M")
        e = ev.get(k)
        s = sc.get(k)
        if e is None and s is None:
            continue
        raw = inum(e.get("%s_score_raw" % fab)) if e else None
        scr = screen_fab_value(s, fab) if s else None
        if scr is None and raw is not None and not sc:
            scr = screen_score(raw)
        grade = (s.get("등급") or "").strip() if s else ""
        if not grade and scr is not None and cuts:
            grade = grade_of(scr, cuts)
        pc = inum(e.get("pio_10min_cnt")) if e else 0
        pp = inum(e.get("pio_score")) if e else 0
        after = screen_score(raw + pp) if raw is not None else None
        rows.append(OrderedDict([
            ("time", k), ("screen_score", "" if scr is None else int(scr)), ("grade", grade),
            ("raw", "" if raw is None else raw), ("rules", "+".join(rules_on(e, fab)) if e else ""),
            ("pio_cnt", pc), ("pio_score", pp),
            ("screen_if_pio", "" if after is None else after),
            ("grade_if_pio", grade_of(after, cuts) if (cuts and after is not None) else ""),
            ("predicted_fault_type", (e.get("predicted_fault_type") or "") if e else ""),
            ("stage", (e.get("stage") or "") if e else ""),
            ("hot_area", (e.get("hot_area") or "") if e else ""),
            ("incident_state", (e.get("incident_state") or "") if e else ""),
            ("continuity_min", inum(e.get("continuity_min")) if e else ""),
            ("refire_count", inum(e.get("refire_count")) if e else ""),
            ("case", (s.get("CASE") or "") if s else ""),
        ]))
    if not rows:
        die("구간에 자료가 없다")
    n = len(rows)
    print("■ %s  %s ~ %s  (%d분%s)" % (fab, a.frm, hm(t1), n,
                                       "" if n == int((t1 - t0).total_seconds() // 60) + 1 else " · 빈 분 있음"))
    gc = Counter(r["grade"] for r in rows if r["grade"])
    label = "화면 등급" if sc else "등급(화면 자료 없음 — 발동이벤트 raw 와 --cuts 로 계산)"
    print("  %s: " % label + (" · ".join("%s %d분" % (g, gc[g]) for g in GRADES if gc.get(g)) or "없음"))
    scored = [r for r in rows if r["screen_score"] != ""]
    if scored:
        mx = max(r["screen_score"] for r in scored)
        at = [r["time"][11:] for r in scored if r["screen_score"] == mx]
        top = next(r for r in scored if r["screen_score"] == mx)
        print("  최고 화면점수 %d점 (%s) · 그때 룰 %s · raw %s" % (
            mx, ", ".join(at[:5]) + (" 외 %d분" % (len(at) - 5) if len(at) > 5 else ""), top["rules"] or "-", top["raw"]))
    pmx = max(r["pio_cnt"] for r in rows)
    pat = [r["time"][11:] for r in rows if r["pio_cnt"] == pmx]
    print("  PIO 10분 합 최대 %d개 (%s) · 임계 %d 의 %.1f배 · 임계 이상 %d분 · PIO 가산 0 인 분 %d" % (
        pmx, ", ".join(pat[:5]), PIO_THRESHOLD, pmx / PIO_THRESHOLD,
        sum(1 for r in rows if r["pio_cnt"] >= PIO_THRESHOLD), sum(1 for r in rows if r["pio_score"] == 0)))
    rc = Counter()
    for r in rows:
        for x in r["rules"].split("+"):
            if x:
                rc[x] += 1
    print("  켜진 룰(분): " + (" · ".join("%s %d" % (k, rc[k]) for k in RULES if rc.get(k)) or "없음"))
    # 예측 유형
    look0 = ref - timedelta(minutes=a.lookback)
    hits = []
    for t in minutes(look0, ref):
        e = ev.get(t.strftime("%Y-%m-%d %H:%M"))
        if e and fault_hits(e.get("predicted_fault_type"), fab):
            hits.append(t)
    print("  예측 유형 (기준 시각 %s%s, 끊김 허용 %d분, %d분 전부터 탐색)" % (
        hm(ref), " = 장애 시작" if (inc and ref == inc) else (" = 구간 시작" if ref == t0 else ""), a.gap, a.lookback))
    if hits:
        start = hits[-1]
        for prev, cur in zip(reversed(hits[:-1]), reversed(hits[1:])):
            if (cur - prev).total_seconds() / 60 - 1 > a.gap:
                break
            start = prev
        nh = sum(1 for h in hits if h >= start)
        span = int((ref - start).total_seconds() // 60)
        last_gap = int((ref - hits[-1]).total_seconds() // 60)
        print("    %s 부터 %s 을(를) 가리킴 → 기준까지 %d분 (그 사이 %d분이 %s)%s" % (
            hm(start), fab, span, nh, fab,
            "" if last_gap <= a.gap else " · 단, 마지막으로 가리킨 뒤 %d분이 지났다" % last_gap))
    else:
        print("    기준 전 %d분 동안 %s 을(를) 가리킨 적 없음" % (a.lookback, fab))
    fc = Counter(r["predicted_fault_type"] or "(없음)" for r in rows)
    print("    구간 안 유형: " + " · ".join("%s %d" % kv for kv in fc.most_common(6)))
    ha = Counter(r["hot_area"] or "(없음)" for r in rows)
    print("    구간 안 hot_area: " + " · ".join("%s %d" % kv for kv in ha.most_common(5)))
    stc = Counter(r["stage"] for r in rows)
    print("  stage: " + " · ".join("%s단계 %d분" % (k, v) for k, v in sorted(stc.items()) if k != ""))
    ins = Counter(r["incident_state"] for r in rows)
    cm = max((r["continuity_min"] for r in rows if r["continuity_min"] != ""), default=0)
    rf = max((r["refire_count"] for r in rows if r["refire_count"] != ""), default=0)
    inc_times = [datetime.strptime(r["time"], "%Y-%m-%d %H:%M") for r in rows if r["incident_state"] == "IN_INCIDENT"]
    print("  사건추적: " + " · ".join("%s %d분" % kv for kv in ins.items() if kv[0]) +
          " · continuity_min 최대 %d · refire_count 최대 %d" % (cm, rf) +
          ("" if not inc_times else " · IN_INCIDENT " + ", ".join(
              "%s~%s" % (hm(s), hm(e)) for s, e, _ in runs_of(inc_times))))
    cases = OrderedDict()
    for r in rows:
        if r["case"]:
            cases.setdefault(r["case"], []).append(r["time"][11:])
    if cases:
        print("  화면 CASE: " + " · ".join("%s (%s~%s, %d분)" % (c, v[0], v[-1], len(v)) for c, v in cases.items()))
    if cuts:
        up = [r for r in rows if r["grade"] and r["grade_if_pio"]
              and GRADES.index(r["grade_if_pio"]) > GRADES.index(r["grade"])]
        best = max((r for r in rows if r["screen_if_pio"] != ""), key=lambda r: r["screen_if_pio"], default=None)
        print("  PIO 가산 what-if (raw + pio_score, 컷 %s): 등급이 오르는 분 %d / %d" % (
            "/".join(map(str, cuts)), len(up), n))
        if best:
            print("    가산 후 최고 %d점 (%s, 지금 %s점, PIO %d개 +%d) · 지금 최고 %s점" % (
                best["screen_if_pio"], best["time"][11:], best["screen_score"], best["pio_cnt"], best["pio_score"],
                max(r["screen_score"] for r in scored) if scored else "-"))
        ag = Counter(r["grade_if_pio"] for r in rows if r["grade_if_pio"])
        print("    가산 후 등급: " + " · ".join("%s %d분" % (g, ag[g]) for g in GRADES if ag.get(g)))
    else:
        print("  (PIO 가산 what-if 등급 비교는 --cuts 경계,위험,초위험 을 주면 나온다)")
    if a.csv:
        with open(a.csv, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        print("→ 분 단위 표: " + a.csv)


# ───────────────────────── ceiling ─────────────────────────
def min_rules_for(need, pts):
    acc, k = 0, 0
    for p in sorted(pts, reverse=True):
        if acc >= need:
            break
        acc += p
        k += 1
    return k if acc >= need else None


def cmd_ceiling(a):
    ev = load_event_index(a.event)
    fab = a.fab
    table = pts_table(fab)
    total = sum(table.values())
    cuts = parse_cuts(a.cuts) if a.cuts else None
    print("■ %s 룰 정의 배점 (합 %d → 화면 최대 %d점)%s" % (
        fab, total, screen_score(total),
        "" if fab in ("M16HUB", "M14") else "  ※ 이 FAB 의 전체 배점표는 받은 적 없음 — 기본값으로 가정"))
    print("  " + " · ".join("%s(%s) %d" % (r, RULE_KO[r], table[r]) for r in RULES))
    if cuts:
        print("  등급 컷 %s 에 닿으려면:" % "/".join(map(str, cuts)))
        for g, c in zip(GRADES[1:], cuts):
            need = next((s for s in range(0, total + 1) if screen_score(s) >= c), None)
            if need is None:
                print("    %s(%d~): 룰을 다 켜도 못 닿는다" % (g, c))
            else:
                print("    %s(%d~): Σ룰 %d 이상 · 최소 %s개 동시 / %d개" % (
                    g, c, need, min_rules_for(need, list(table.values())), len(RULES)))
    days = OrderedDict()
    for k, r in ev.items():
        if a.date and not k.startswith(a.date):
            continue
        days.setdefault(k[:10], []).append(r)
    for d, rs in days.items():
        fired = OrderedDict()
        for r in RULES:
            mx = max(inum(x.get("%s_pts_%s" % (fab, r))) for x in rs)
            if mx > 0:
                fired[r] = mx
        s = sum(fired.values())
        mxraw = max(inum(x.get("%s_score_raw" % fab)) for x in rs)
        at = [k[11:] for k, x in ev.items() if k.startswith(d) and inum(x.get("%s_score_raw" % fab)) == mxraw]
        never = [r for r in RULES if r not in fired]
        print("■ %s (%d분)" % (d, len(rs)))
        print("  켜진 룰 %d개: %s → 합 %d (화면 천장 %d점)" % (
            len(fired), " · ".join("%s %d" % kv for kv in fired.items()), s, screen_score(s)))
        print("  한 번도 안 켜진 룰: %s (배점 %d)" % (" · ".join(never) or "없음", sum(table[r] for r in never)))
        print("  실제 최고 raw %d → 화면 %d점 (%s)" % (mxraw, screen_score(mxraw), ", ".join(at[:5])))
        if cuts:
            reach = [g for g, c in zip(GRADES[1:], cuts) if screen_score(s) >= c]
            print("  그날 켜진 룰만으로 닿을 수 있는 최고 등급: %s" % (reach[-1] if reach else "정상"))


# ───────────────────────── tracker ─────────────────────────
def cmd_tracker(a):
    ev = load_event_index(a.event)
    days = OrderedDict()
    for k, r in ev.items():
        days.setdefault(k[:10], []).append((k, r))
    for d, rs in days.items():
        st = Counter((r.get("stage") or "").strip() for _, r in rs)
        tr = Counter((r.get("transition") or "").strip() for _, r in rs if (r.get("transition") or "").strip())
        ins = [datetime.strptime(k, "%Y-%m-%d %H:%M") for k, r in rs if (r.get("incident_state") or "") == "IN_INCIDENT"]
        cm = max(inum(r.get("continuity_min")) for _, r in rs)
        rf = Counter(inum(r.get("refire_count")) for _, r in rs)
        n = len(rs)
        print("■ %s (%d분)" % (d, n))
        print("  stage: " + " · ".join("%s단계 %d분(%d%%)" % (k, v, round(v * 100 / n)) for k, v in sorted(st.items())) +
              ("" if st.get("0") else " · 0단계(정상) 0분"))
        print("  단계 전환: " + (" · ".join("%s %d회" % kv for kv in tr.most_common()) or "없음"))
        if ins:
            print("  IN_INCIDENT: " + " · ".join("%s~%s (%d분)" % (hm(s), hm(e), c) for s, e, c in runs_of(ins)))
        else:
            print("  IN_INCIDENT: 없음 — 하루 종일 IDLE")
        print("  continuity_min 최대 %d · refire_count 값 분포 %s" % (cm, dict(rf)))


# ───────────────────────── claims ─────────────────────────
def cmd_claims(a):
    ev = load_event_index(a.event) if a.event else {}
    sc = load_screen_index(a.screen)
    rows = read_table(a.claims)
    same = 0
    print("시각 | 적힌 점수 | 자료 점수 | 등급 | PIO | 판정")
    for r in rows:
        t = (r.get("time") or r.get("시각") or "").strip()
        claim = num(r.get("score") or r.get("점수"))
        fab = (r.get("fab") or r.get("FAB") or a.fab or "").strip()
        s = sc.get(t)
        if s is None:
            print("%s | %s | 자료 없음 | - | - | 확인 불가" % (t, claim))
            continue
        v = screen_fab_value(s, fab) if fab else num(s.get("종합점수"))
        e = ev.get(t)
        pio = inum(e.get("pio_10min_cnt")) if e else None
        ok = (claim is not None and v is not None and int(claim) == int(v))
        same += ok
        print("%s | %s | %s | %s | %s | %s" % (t, "-" if claim is None else int(claim), "-" if v is None else int(v),
                                               s.get("등급", ""), "-" if not pio else "%d개" % pio,
                                               "맞음" if ok else "다름"))
    print("\n%d개 중 %d개가 자료와 같다" % (len(rows), same))


# ───────────────────────── runs ─────────────────────────
def cmd_runs(a):
    ev = load_event_index(a.event)
    pat = re.compile(a.match) if a.match else None
    times, vals = [], Counter()
    for k, r in ev.items():
        if a.date and not k.startswith(a.date):
            continue
        v = (r.get(a.col) or "").strip()
        if not v or v.lower() == "nan":
            continue
        if pat and not pat.search(v):
            continue
        times.append(datetime.strptime(k, "%Y-%m-%d %H:%M"))
        vals[v] += 1
    if not times:
        print("해당 값이 있는 분이 없다")
        return
    rs = runs_of(times, gap=a.gap)
    print("■ %s %s: %d분, %d구간 (끊김 %d분 이하는 이어 붙임)" % (a.col, a.match or "", len(times), len(rs), a.gap))
    for s, e, c in rs:
        span = int((e - s).total_seconds() // 60) + 1
        if span >= a.min_len:
            print("  %s ~ %s  %d분 (값 있는 분 %d)" % (s.strftime("%m-%d %H:%M"), hm(e), span, c))
    print("  값별 분:")
    for v, c in vals.most_common(15):
        extra = ""
        if a.normal:
            m = re.search(r"=(\d+(?:\.\d+)?)", v)
            if m:
                extra = "  (정상 대비 %d%%)" % round(float(m.group(1)) * 100 / a.normal)
        print("    %s : %d%s" % (v, c, extra))


# ───────────────────────── compare ─────────────────────────
def cmd_compare(a):
    ev = load_event_index(a.event)

    def span(txt):
        f, t = [x.strip() for x in txt.split(",")]
        return pt(f), pt(t)

    b0, b1 = span(a.before)
    d0, d1 = span(a.during)
    cols = [c.strip() for c in a.cols.split(",") if c.strip()]
    thr = {}
    for kv in (a.thr or "").split(","):
        if "=" in kv:
            k, v = kv.split("=")
            thr[k.strip()] = float(v)

    def vals(t0, t1, c):
        out = []
        for t in minutes(t0, t1):
            r = ev.get(t.strftime("%Y-%m-%d %H:%M"))
            x = num(r.get(c)) if r else None
            if x is not None:
                out.append(x)
        return out

    print("■ 사건 전 %s~%s  vs  사건 중 %s~%s" % (b0.strftime("%m-%d %H:%M"), hm(b1), d0.strftime("%m-%d %H:%M"), hm(d1)))
    print("  칸 | 사건 전 평균 | 사건 중 평균 | 방향 | 사건 중 처음→끝 | 임계 | 사건 중 평균이 임계 넘나")
    for c in cols:
        bv, dv = vals(b0, b1, c), vals(d0, d1, c)
        if not bv or not dv:
            print("  %s | 자료 없음" % c)
            continue
        mb, md = sum(bv) / len(bv), sum(dv) / len(dv)
        arrow = "▲ 올라감" if md > mb else ("▼ 내려감" if md < mb else "= 같음")
        t = thr.get(c)
        over = "-" if t is None else ("넘음" if md >= t else "안 넘음")
        print("  %s | %.2f | %.2f | %s | %g→%g | %s | %s" % (c, mb, md, arrow, dv[0], dv[-1],
                                                           "-" if t is None else "%g" % t, over))


# ───────────────────────── weight ─────────────────────────
# 룰 → 초과 배율을 읽을 칸. RA_sus 는 RA 와 같은 배율을 쓴다(기존 M14 보고서 16:55 계산과 일치).
RATIO_COL = {"RA": "{fab}_ra", "RA_sus": "{fab}_ra", "RB": "{fab}_rb_diff30", "RD": "{fab}_rd_oht", "SLA": "sla_{fab}"}
# 기존 M14 보고서에 적힌 임계(출처 hubroom_predictor.py). 다른 FAB 은 --thr 로 받는다.
DEFAULT_THR = {"M14_ra": 3.3, "M14_rb_diff30": 80.0, "M14_rd_oht": 95.0, "sla_M14": 25.0}


def parse_bands(s):
    out = []
    for part in s.split(","):
        lo, w = part.split(":")
        out.append((float(lo), float(w)))
    return sorted(out, reverse=True)


def weighted(row, fab, thr, bands):
    total, detail, max_r = 0.0, [], 0.0
    for r in RULES:
        p = inum(row.get("%s_pts_%s" % (fab, r)))
        if p <= 0:
            continue
        col = RATIO_COL.get(r, "").format(fab=fab)
        w, ratio = 1.0, None
        if col and col in thr:
            v = num(row.get(col))
            if v is not None and thr[col]:
                ratio = v / thr[col]
                max_r = max(max_r, ratio)
                w = next((bw for lo, bw in bands if ratio >= lo), 1.0)
        total += p * w
        detail.append("%s %d%s" % (r, p, "" if ratio is None else "×%.1f(%.2f배)" % (w, ratio)))
    return total, detail, max_r


def cmd_weight(a):
    ev = load_event_index(a.event)
    fab = a.fab
    thr = {k: v for k, v in DEFAULT_THR.items()}
    for kv in (a.thr or "").split(","):
        if "=" in kv:
            k, v = kv.split("=")
            thr[k.strip()] = float(v)
    thr = {k: v for k, v in thr.items() if k.endswith("_" + fab) or k.startswith(fab + "_")}
    bands = parse_bands(a.bands)
    cuts = parse_cuts(a.cuts) if a.cuts else None
    print("■ %s 초과 배율 가중 what-if  배율표 %s · 임계 %s" % (
        fab, " / ".join("%.1f배↑ ×%.1f" % b for b in sorted(bands)),
        ", ".join("%s=%g" % kv for kv in sorted(thr.items())) or "없음(전부 ×1)"))
    no_thr = [r for r in RULES if RATIO_COL.get(r) and RATIO_COL[r].format(fab=fab) not in thr]
    if no_thr:
        print("  임계를 모르는 룰은 ×1: " + ", ".join(no_thr))
    t0 = pt(a.frm) if a.frm else None
    t1 = pt(a.to) if a.to else None
    picks = set(x.strip() for x in (a.at or "").split(",") if x.strip())
    out, up = [], 0
    for k, row in ev.items():
        t = datetime.strptime(k, "%Y-%m-%d %H:%M")
        if t0 and t < t0 or t1 and t > t1:
            continue
        raw = inum(row.get("%s_score_raw" % fab))
        wsum, detail, max_r = weighted(row, fab, thr, bands)
        new = int(round(wsum))
        s0, s1 = screen_score(raw), screen_score(new)
        g0 = grade_of(s0, cuts) if cuts else ""
        g1 = grade_of(s1, cuts) if cuts else ""
        if cuts and a.floor_severe and max_r >= a.floor_severe and GRADES.index(g1) < 2:
            g1 = "위험"
        if cuts and GRADES.index(g1) > GRADES.index(g0):
            up += 1
        out.append((k, raw, new, s0, s1, g0, g1, detail))
    if not out:
        die("구간에 자료가 없다")
    print("  %d분 · 가중 후 등급이 오르는 분 %s" % (len(out), up if cuts else "(컷 없음)"))
    show = [o for o in out if o[0][11:] in picks or o[0] in picks] if picks else \
        sorted(out, key=lambda o: o[2] - o[1], reverse=True)[:a.top]
    print("  시각 | raw→가중 | 화면 지금→가중 | 등급 지금→가중 | 룰(배점×가중)")
    for k, raw, new, s0, s1, g0, g1, detail in show:
        print("  %s | %d→%d | %d→%d | %s→%s | %s" % (k[5:], raw, new, s0, s1, g0 or "-", g1 or "-", " · ".join(detail)))

# ───────────────────────── chart ─────────────────────────
GRADE_COLOR = {"정상": "#cbd5e1", "경계": "#f59e0b", "위험": "#ea580c", "초위험": "#dc2626"}


def esc(x):
    return str(x).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def cmd_chart(a):
    rows = read_table(a.csv)
    if not rows:
        die("표가 비었다")
    cuts = parse_cuts(a.cuts) if a.cuts else None
    W, H, L, R, T, B = 920, 230, 40, 44, 14, 30
    pw, ph = W - L - R, H - T - B
    n = len(rows)
    bw = pw / n
    pio = [inum(r.get("pio_cnt")) for r in rows]
    pmax = max(max(pio), PIO_THRESHOLD, 1)
    pmax = int((pmax + 9) // 10 * 10)
    y = lambda v: T + ph - v / 100.0 * ph
    yp = lambda v: T + ph - v / float(pmax) * ph
    out = ['<svg viewBox="0 0 %d %d" width="100%%" role="img" aria-label="%s" '
           'xmlns="http://www.w3.org/2000/svg" style="font-family:Consolas,monospace;font-size:10px">' % (W, H, esc(a.title))]
    out.append('<rect x="%d" y="%d" width="%d" height="%d" fill="#ffffff" stroke="#e5e7eb"/>' % (L, T, pw, ph))
    for v in (0, 50, 100):
        out.append('<text x="%d" y="%.1f" text-anchor="end" fill="#6b7280">%d</text>' % (L - 4, y(v) + 3, v))
    for v in (0, pmax // 2, pmax):
        out.append('<text x="%d" y="%.1f" fill="#4f46e5">%d</text>' % (W - R + 4, yp(v) + 3, v))
    for i, r in enumerate(rows):
        sv = num(r.get("screen_score"))
        if sv is None:
            continue
        g = (r.get("grade") or "정상").strip() or "정상"
        out.append('<rect x="%.2f" y="%.2f" width="%.2f" height="%.2f" fill="%s"><title>%s · %s %d점 · PIO %s</title></rect>' % (
            L + i * bw, y(sv), max(bw - 0.3, 0.3), T + ph - y(sv), GRADE_COLOR.get(g, "#cbd5e1"),
            esc(r["time"][11:]), esc(g), sv, esc(r.get("pio_cnt", ""))))
    if cuts:
        for name, c in zip(GRADES[1:], cuts):
            out.append('<line x1="%d" x2="%d" y1="%.1f" y2="%.1f" stroke="%s" stroke-dasharray="4 3"/>' % (
                L, L + pw, y(c), y(c), GRADE_COLOR[name]))
            out.append('<text x="%d" y="%.1f" fill="%s" stroke="#ffffff" stroke-width="3" paint-order="stroke" '
                       'font-weight="700">%s %d</text>' % (L + 4, y(c) - 3, GRADE_COLOR[name], esc(name), c))
    out.append('<line x1="%d" x2="%d" y1="%.1f" y2="%.1f" stroke="#4f46e5" stroke-dasharray="2 3"/>' % (
        L, L + pw, yp(PIO_THRESHOLD), yp(PIO_THRESHOLD)))
    pts = " ".join("%.1f,%.1f" % (L + (i + 0.5) * bw, yp(v)) for i, v in enumerate(pio))
    out.append('<polyline points="%s" fill="none" stroke="#4f46e5" stroke-width="1.5"/>' % pts)
    if a.incident:
        for i, r in enumerate(rows):
            if r["time"] == a.incident:
                x = L + i * bw
                out.append('<line x1="%.1f" x2="%.1f" y1="%d" y2="%d" stroke="#111827"/>' % (x, x, T, T + ph))
                out.append('<text x="%.1f" y="%d" fill="#111827">장애 %s</text>' % (x + 3, T + 10, esc(a.incident[11:])))
    step = max(1, n // 8)
    for i in range(0, n, step):
        out.append('<text x="%.1f" y="%d" text-anchor="middle" fill="#6b7280">%s</text>' % (
            L + (i + 0.5) * bw, H - 14, esc(rows[i]["time"][11:])))
    out.append('<text x="%d" y="%d" fill="#6b7280">막대 = 화면 점수(등급 색) · 선 = PIO 10분 합(오른쪽 축) · 점선 = 임계 %d</text>' % (
        L, H - 2, PIO_THRESHOLD))
    out.append("</svg>")
    with open(a.out, "w", encoding="utf-8") as f:
        f.write("\n".join(out))
    print("→ " + a.out)


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = p.add_subparsers(dest="cmd", required=True)

    s = sp.add_parser("load", help="원본(.txt 노트북 JSON / .csv) → events.csv, screen.csv")
    s.add_argument("inputs", nargs="+")
    s.add_argument("--out", default="data")
    s.set_defaults(fn=cmd_load)

    s = sp.add_parser("verify", help="점수 식·PIO 구간표·등급 컷 재계산")
    s.add_argument("--event")
    s.add_argument("--screen")
    s.add_argument("--cuts", action="append", help="FAB=경계,위험,초위험 (여러 번 가능)")
    s.set_defaults(fn=cmd_verify)

    s = sp.add_parser("window", help="사건 구간 요약")
    s.add_argument("--event", required=True)
    s.add_argument("--screen")
    s.add_argument("--fab", required=True, choices=FABS)
    s.add_argument("--from", dest="frm", required=True)
    s.add_argument("--to", required=True)
    s.add_argument("--incident", help="장애 시작 시각")
    s.add_argument("--ref", help="예측 리드타임 기준 시각 (기본: --incident, 없으면 --from)")
    s.add_argument("--cuts", help="경계,위험,초위험")
    s.add_argument("--gap", type=int, default=10, help="예측 유형 끊김 허용 분 (기본 10)")
    s.add_argument("--lookback", type=int, default=180, help="예측 유형 탐색 범위 분 (기본 180)")
    s.add_argument("--csv", help="분 단위 표 저장 경로")
    s.set_defaults(fn=cmd_window)

    s = sp.add_parser("ceiling", help="켜진 룰과 점수 천장")
    s.add_argument("--event", required=True)
    s.add_argument("--fab", required=True, choices=FABS)
    s.add_argument("--date")
    s.add_argument("--cuts")
    s.set_defaults(fn=cmd_ceiling)

    s = sp.add_parser("tracker", help="사건추적 칸·stage 동작")
    s.add_argument("--event", required=True)
    s.set_defaults(fn=cmd_tracker)

    s = sp.add_parser("claims", help="적힌 시각·점수 대조 (CSV: time,score[,fab])")
    s.add_argument("--claims", required=True)
    s.add_argument("--screen", required=True)
    s.add_argument("--event")
    s.add_argument("--fab")
    s.set_defaults(fn=cmd_claims)

    s = sp.add_parser("runs", help="한 칸에 값이 이어진 구간")
    s.add_argument("--event", required=True)
    s.add_argument("--col", required=True)
    s.add_argument("--match", help="정규식 (예: '^M14:')")
    s.add_argument("--date")
    s.add_argument("--gap", type=int, default=1)
    s.add_argument("--min-len", dest="min_len", type=int, default=1)
    s.add_argument("--normal", type=float, help="정상값 (값=숫자 에서 비율 계산)")
    s.set_defaults(fn=cmd_runs)

    s = sp.add_parser("compare", help="사건 전/중 지표 평균 비교")
    s.add_argument("--event", required=True)
    s.add_argument("--before", required=True, help="'YYYY-MM-DD HH:MM,YYYY-MM-DD HH:MM'")
    s.add_argument("--during", required=True, help="'YYYY-MM-DD HH:MM,YYYY-MM-DD HH:MM'")
    s.add_argument("--cols", required=True, help="칸 이름들 (쉼표)")
    s.add_argument("--thr", help="칸=임계 (쉼표)")
    s.set_defaults(fn=cmd_compare)

    s = sp.add_parser("weight", help="초과 배율 가중 what-if")
    s.add_argument("--event", required=True)
    s.add_argument("--fab", required=True, choices=FABS)
    s.add_argument("--from", dest="frm")
    s.add_argument("--to")
    s.add_argument("--at", help="보고 싶은 시각들 (HH:MM 또는 YYYY-MM-DD HH:MM, 쉼표)")
    s.add_argument("--thr", help="칸=임계 (예: M14_ra=3.3,sla_M14=25)")
    s.add_argument("--bands", default="1.3:1.5,2.0:2.5", help="배율하한:가중 (기본 1.3:1.5,2.0:2.5)")
    s.add_argument("--cuts")
    s.add_argument("--floor-severe", dest="floor_severe", type=float,
                   help="이 배율 이상인 룰이 하나라도 있으면 등급 하한을 위험으로 (예: 2.0)")
    s.add_argument("--top", type=int, default=10)
    s.set_defaults(fn=cmd_weight)

    s = sp.add_parser("chart", help="window --csv 결과 → SVG")
    s.add_argument("--csv", required=True)
    s.add_argument("--out", required=True)
    s.add_argument("--cuts")
    s.add_argument("--incident", help="세로선 시각 YYYY-MM-DD HH:MM")
    s.add_argument("--title", default="화면 점수와 PIO")
    s.set_defaults(fn=cmd_chart)

    a = p.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
