# 자료 구조와 검증된 계산식

이 문서의 식은 2026-09-12~14 자료에서 모두 다시 계산해 확인했다.

- 발동이벤트 4320분, 화면 4310분
- 따로 적지 않은 식은 어긋난 분이 0이다.
- 새 자료를 받으면 `verify`로 다시 확인한다.

## 1. 원본 파일 형태

- **`.txt` 파일:** 사실은 Kaggle/Jupyter 노트북 JSON이다. 첫 코드 셀의 `source`에 CSV 전체가 문자열로 들어 있다. `load`가 꺼낸다.
- **깨진 줄:** 파일마다 2줄 정도 있다. reason 칸 안의 따옴표가 어긋나 한 줄이 둘로 쪼개진 것이다.
  - 시간 칸이 `YYYY-MM-DD HH:MM`가 아니거나 칸 수가 헤더와 다르면 버린다.
  - 버려도 하루 1440분은 그대로 남았다.
- **파일 이름과 자료 날짜가 다를 수 있다.** 예: `M16HUB_발동이벤트12일.txt` 안의 자료는 2026-09-13이다. 날짜는 항상 자료의 시간 칸을 기준으로 한다.
- **칸 순서가 파일마다 다르다.** 칸 구성은 같다. 합칠 때는 칸 이름으로 맞춘다.

## 2. 발동이벤트 (예측기 출력, 156칸, 1분 1줄)

| 묶음 | 칸 | 뜻 |
|---|---|---|
| 시각 | `file`(=M16A_HUBROOM_PR.csv), `datetime`, `date`, `time` | 분 단위 키는 `datetime` |
| 단계 | `stage`(1·3), `stage_name`(1단계 조기경보 / 3단계 ⭐확정), `prev_stage`, `transition`(1→3, 3→1) | FAB 접두어가 없다. 전체 시스템 값이다 |
| 사건추적 | `incident_state`(IDLE / IN_INCIDENT), `continuity_min`, `refire_count` | |
| 예측 | `predicted_fault_type`, `hot_area`, `hot_score`, `affected_areas`(`;` 구분), `propagation_chain` | 유형 접두어로 영역을 가린다. `HUB-`=M16HUB, `M14-`, `M14B-`, `M16A-`, `M16B-`, `M16-`, `M16_WT-`, `광역정체` |
| 통합 | `unified_risk_score`, `unified_risk_level`, `layer1_total`, `flow_score`, `sla_score_total`, `sorter_score_total`, `mc_score_total` | `unified_risk_score` 계산식은 확인하지 못했다. 식을 추정해 쓰지 않는다 |
| 영역 점수 | `{FAB}_score`, `{FAB}_score_raw`, `{FAB}_signals`(예: `RA+RA_sus+RD`, `MAXCAPA*1`) | FAB = M16HUB, M14, M14B, M16A, M16B. `M16_score`와 `M16_WT_score`는 score만 있다 |
| 룰 배점 | `{FAB}_pts_{RULE}` | RULE = RA, RA_sus, RB, RB_fast, RC, RD, SLA, SORT, MAXCAPA. 값은 0 또는 배점 |
| 지표 | `{FAB}_ra`(반송시간, 분), `{FAB}_rb_diff30` / `_rb_diff10`(큐 증감), `{FAB}_rd_oht`(OHT 가동률 %), `M16HUB_rd_fab`(FAB 저장 여유 %), `M16HUB_stb_util`, `M16HUB_rc_trend`, `M16HUB_rev_count` / `_rev_lids`(리프터 역전 수와 ID), `M14_cnv_skew`, `sla_{FAB}`(4분초과율 %), `{FAB}_sla_cnt`, `sorter_{FAB}`, `{FAB}_sorter_fail`, `{FAB}_ra_count` | |
| 흐름·용량 | `flow_signals`(예: `M16A_2F_TO_HUB=1.8x(주의)`), `maxcapa_signals`(예: `M14:3F_CNV_MAXCAPA=112(<=150)`) | MAXCAPA 값은 임계 밑으로 내려간 분에만 적힌다 |
| PIO | `pio_10min_cnt`, `pio_score`, 경로별 `{구간}_PIOERROR_DEPOSITED` 12칸 | 아래 PIO 절 참고 |
| 이상탐지 | `BOTTLENECK_downward_anomaly_cols`, `BOTTLENECK_upward_anomaly_cols`, `QUEUE_downward_anomaly_cols`, `QUEUE_upward_anomaly_cols` | 화면의 AMOS 칸과 대응한다 |
| 운영자 조치 | `MACHINE`, `PORT:후(after)`, `PROCESS`, `TRANSACTIONID` | 09-12~14에는 전부 비어 있다 |
| 원문 | `reason` | 아래 문법 참고 |

### reason 원문 문법

```
hot_area=M14; S3확정; 발동: M16HUB[R-D(FAB저장=0.0%)]; M14[R-A'(AVGLOADTIME1MIN=3.32분/기준3.3),R-A_sus,R-B(3F_TO_HUB_JOB+82/30분/기준+80),R-C'(CNV쏠림),R-D(OHT=97.5%),SLA(26.7%4분초과),MAXCAPA1개변경]; ...; 흐름:M16A_2F_TO_HUB=1.7x(주의); 운영자조치:M14:3F_CNV_MAXCAPA=112(<=150); PIO(M16HUB<-M16A=18건/10분,합19,+2)
```

- `S1조기경보` / `S3확정`은 stage에 대응한다.
- 룰 괄호 안에 `값/기준값`이 있으면 초과 배율을 바로 읽을 수 있다.
- `PIO(...합N,+P)`에서 N은 `pio_10min_cnt`와 같다(2473분, 어긋남 0). P는 `pio_score`이다.

## 3. 화면 (운전원 화면 = 분석 이벤트, 15칸)

| 칸 | 뜻 |
|---|---|
| `시간` | 분 단위 키. 발동이벤트 `datetime`과 1:1로 맞물린다 (4310/4310) |
| `CASE` | `C{시작 YYYYMMDDHHMMSS}-{FAB}`. 화면이 한 사건으로 묶은 분들 |
| `등급` | 정상 / 경계 / 위험 / 초위험 |
| `종합점수` | `HI_FAB` 칸의 값과 같다 |
| `HI_FAB`, `M14`, `M14B`, `M16A`, `M16B`, `M16HUB` | 내보낸 파일은 HI_FAB 하나로 걸러져, 그 FAB 칸만 차 있다 |
| `reason` | 켜진 룰의 한글 이름. PIO 문구와 주 경로 건수가 붙는다 |
| `reason 원문` | 발동이벤트 `reason`과 같은 문법 |
| `실제지표` | 근거 지표 이름(공백 구분). 예: `M16HUB.STRATE.ALL.FABSTORAGERATIO`, `M14.QUE.LOAD.AVGLOADTIME1MIN`, `PIO.DEPOSIT.10MIN.CNT` |
| `AMOS HID구역`, `AMOS QUEUE지표` | ▲▼로 표시한 이상 구역·큐 지표 |

화면 reason 라벨과 룰의 대응은 M16HUB·M14에서 100% 일치했다.

| 라벨 | 룰 |
|---|---|
| 반송지연 | RA |
| 반송지연 지속 | RA_sus |
| Queue 누적 | RB |
| Queue 상승 | RB_fast |
| 리프터 정체 | RC |
| Storage FULL | RD |
| 4분초과 | SLA |

- M14에서도 RD의 라벨은 "Storage FULL"이다. 근거 값은 OHT 가동률(`R-D(OHT=…%)`)이다.
- **용량변경(MAXCAPA) 라벨은 화면 reason에 나오지 않는다.** 09-13 M14에서 306분 켜졌지만 라벨은 0분이었다.

화면 PIO 문구 구간(관측값)은 아래와 같다. `pio_score` 구간과 같은 경계다.

| 개수 | 문구 |
|---|---|
| 15 | 표시만 (라벨 없음) |
| 16~25 | 조금 많음 |
| 26~40 | 확실히 많음 |
| 41~59 | 이상 |
| 63~77 | 심각 |
| 81↑ | 최고 |

## 4. 검증된 식

```
{FAB}_score_raw = Σ {FAB}_pts_*                              (5개 FAB, 4320분, 어긋남 0)
{FAB}_score     = min(50, {FAB}_score_raw)                   ← ALL 융합에 넣으려고 자른 값
layer1_total    = Σ _score (M16HUB, M14, M14B, M16A, M16B, M16, M16_WT)
화면 FAB 점수    = min(100, round({FAB}_score_raw / 70 × 100))  ← 자르지 않은 raw 사용 (M16HUB 2875분, M14 1435분, 어긋남 0)
화면 종합점수     = 화면 HI_FAB 칸 값
pio_score       = 16↑ +2 · 26↑ +4 · 41↑ +7 · 63↑ +9 · 81↑ +11  (pio_10min_cnt 기준, 어긋남 0)
```

- **두 자료의 점수는 같은 자가 아니다.** 발동이벤트 `{FAB}_score`는 50에서 자른 값이고, 화면은 자르지 않은 raw를 70으로 나눈다. 둘이 갈라지는 건 raw > 50인 분뿐이다(09-13 M14 07:58~08:00, 3분).
- **PIO는 FAB 점수에 안 들어간다.** `pio_score > 0`인 541분 모두 `M16HUB_score_raw`가 룰 배점 합과 같다. `pio_score`는 ALL 룰 쪽에만 있다.
- **반올림:** 파이썬 `round`와 half-up 모두 어긋남 0이다. 어느 방식인지 자료만으로는 가릴 수 없다.

## 5. 등급 컷

| FAB | 컷 (경계/위험/초위험) | 출처 | 자료 확인 |
|---|---|---|---|
| M14 | 36 / 52 / 72 | 운영 중인 값으로 받은 값 | 1435분 어긋남 0 |
| M16HUB | 43 / 57 / 72 | 기존 보고서가 놓은 값. **운영값 확인 전** | 2875분 어긋남 0. 자료로는 경계 40~43, 위험 54~57까지만 좁혀진다. 초위험은 안 나와서 못 정한다 |

컷을 자료의 최소·최대로 지어내지 않는다. 운영값을 받으면 `--cuts`로 다시 매긴다.

## 6. 룰 배점 (룰 정의)

| 룰 | 이름 | 배점 |
|---|---|---|
| RA | 반송지연 | 10 |
| RA_sus | 반송지연 지속 | 5 |
| RB | Queue 누적 (M14는 반입급증 30분) | 10 |
| RB_fast | Queue 급증 | 5 |
| RC | 리프터 정체 (M14는 CNV 쏠림 `R-C'`) | 8 |
| RD | Storage FULL (M14는 OHT 가동률) | 7 |
| SLA | 4분초과 | 5 |
| SORT | 분류기 대기 | 3 |
| MAXCAPA | 운영자 용량변경 | M16HUB 30, M14 10 |

- 합계는 M16HUB 83(화면 100), M14 63(화면 90)이다.
- 출처는 기존 보고서(`hubroom_predictor.py` 기준)이다. SORT 3과 M16HUB MAXCAPA 30은 09-12~14에 한 번도 켜지지 않아 자료로는 확인하지 못했다.
- M14B·M16A·M16B의 전체 배점표는 받은 적이 없다. 켜진 값은 위 표와 같았다(M16A MAXCAPA 10 포함).

## 7. 임계 (기존 M14 보고서에 적힌 값, 출처 `hubroom_predictor.py`)

| 지표 | 칸 | 임계 |
|---|---|---|
| 반송시간 | `M14_ra` | 3.3분 |
| 반입증감(30분) | `M14_rb_diff30` | +80 |
| 4분초과율 | `sla_M14` | 25% |
| OHT 가동률 | `M14_rd_oht` | 95% 이상이면 켜짐 |
| 소터 대기 | `sorter_M14` | 100 |
| 3F CNV MAXCAPA | `maxcapa_signals` | 150 이하 (정상값 244) |
| PIO 10분 합 | `pio_10min_cnt` | 16 |

다른 FAB의 임계는 reason 원문의 `기준…` 값이나 사용자가 준 원본 코드에서 읽는다. 없으면 "임계 모름"으로 둔다.

## 8. PIO 경로 칸

`{구간}_PIOERROR_DEPOSITED` 12칸은 다음과 같다.

- M16HUB->MLUD
- M16HUB↔M14B
- M16HUB↔M14A
- M16HUB↔M16A
- M16A↔M16B
- M14A↔M14B
- M14A->M10A

`pio_10min_cnt`는 이 칸들을 단순히 10분 합한 값과 맞지 않았다. 건수는 `pio_10min_cnt`나 reason의 `합N`을 쓰고, 경로별 칸은 "어느 경로가 많았나"를 볼 때만 쓴다.
