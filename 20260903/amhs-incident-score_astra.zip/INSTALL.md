# amhs-incident-score 스킬 — 설치와 사용법 (GPT-6 Astra / Codex)

## 1. 넣는 위치

`amhs-incident-score` 폴더를 통째로 아래 중 한 곳에 복사한다.

| 범위 | 경로 |
|---|---|
| 이 저장소에서만 | `<저장소>/.agents/skills/amhs-incident-score/` |
| 내 PC 전체 | `~/.agents/skills/amhs-incident-score/` |

```
amhs-incident-score/
├── SKILL.md                      # 목차 + 할 일·판단 범위·우선순위·검증·완료 조건
├── references/
│   ├── data-schema.md            # 칸 뜻, 검증된 계산식, 룰 배점, 임계, 컷
│   ├── analysis-playbook.md      # 질문별 분석 순서와 명령
│   ├── known-findings.md         # 09-12~14 자료에서 확인된 사실 (비교 기준)
│   └── report-style.md           # 보고서 구성과 문장
├── scripts/amhs_score.py         # 분석 CLI (Python 3.7+, 외부 패키지 없음)
└── assets/report_template.html   # 기존 보고서와 같은 스타일의 틀
```

- **필요한 것:** Python 3.7 이상. pip 설치는 필요 없다.
- **호출:** 대화에서 `$amhs-incident-score`로 부르거나, 질문 내용이 description과 맞으면 자동으로 켜진다.

## 2. 요청 예시 (5항목 틀)

```
$amhs-incident-score
[무엇을] data_raw/ 의 발동이벤트·화면 파일로 09-12 오후 M16HUB 데드락(장애 14:53~16:00) 때
        점수가 왜 경계에 머물렀는지 분석하고 HTML 보고서를 써라.
[판단 범위] 분석 구간은 네가 정해도 된다. 원본 파일은 고치지 마라.
[우선순위] 등급 컷은 43/57/72 (운영값). 스킬 기본값보다 이 값을 따른다.
[검증] 보고서의 숫자는 전부 amhs_score.py 출력과 대조하고, verify 결과를 1절에 넣어라.
[완료] out/M16HUB_0912_분석.html 이 생기고, "이 문서가 말하지 않는 것" 절이 있고,
      숫자 대조가 끝났으면 멈춰라.
```

짧게 물어도 된다: "$amhs-incident-score 09-14 16:52 데드락 점수 왜 낮았어? 컷 43/57/72"

## 3. 명령만 따로 쓸 때

```
python scripts/amhs_score.py load 원본/*.txt --out data
python scripts/amhs_score.py verify  --event data/events.csv --screen data/screen.csv --cuts M16HUB=43,57,72 --cuts M14=36,52,72
python scripts/amhs_score.py window  --event data/events.csv --screen data/screen.csv --fab M16HUB --from "2026-09-12 14:00" --to "2026-09-12 16:00" --incident "2026-09-12 14:53" --cuts 43,57,72 --csv out/w.csv
python scripts/amhs_score.py chart   --csv out/w.csv --out out/w.svg --cuts 43,57,72 --incident "2026-09-12 14:53"
python scripts/amhs_score.py ceiling --event data/events.csv --fab M16HUB --cuts 43,57,72
python scripts/amhs_score.py tracker --event data/events.csv
python scripts/amhs_score.py claims  --claims claims.csv --screen data/screen.csv --event data/events.csv --fab M16HUB
python scripts/amhs_score.py runs    --event data/events.csv --col maxcapa_signals --match '^M14:' --date 2026-09-13 --min-len 10 --normal 244
python scripts/amhs_score.py compare --event data/events.csv --before "2026-09-13 11:00,2026-09-13 11:38" --during "2026-09-13 11:38,2026-09-13 14:30" --cols M14_ra,sla_M14,M14_rd_oht --thr M14_ra=3.3,sla_M14=25,M14_rd_oht=95
python scripts/amhs_score.py weight  --event data/events.csv --fab M14 --at "16:55,07:58" --from "2026-09-13 00:00" --to "2026-09-13 23:59" --cuts 36,52,72
```

## 4. 받은 자료로 확인한 것

- 기존 보고서 두 편의 숫자를 스크립트로 다시 뽑아 모두 같게 나왔다. 확인한 항목은 다음과 같다.
  - 등급 분 수, 최고점, PIO 최대
  - PIO 가산 시 등급이 오르는 분, 예측 유형 시점, 사건추적 구간
  - MAXCAPA 구간, 사건 전/중 평균, 16:55 가중 27→52
- 점수 식은 발동이벤트 4320분, 화면 4310분에서 어긋난 분이 0이다.
- M16HUB 등급 컷 43/57/72는 아직 운영값 확인 전이다. 운영값을 받으면 `references/data-schema.md` 5절을 고친다.
