# 파일 읽기/쓰기 샘플 프로젝트

Python 파일 IO 기본 예제 (텍스트, JSON, CSV, 로그)

## 실행
```bash
python main.py
```

## 구조
- `main.py` - 파일 읽기/쓰기 함수 + 실행 테스트
- `data/` - 생성되는 데이터 파일들
