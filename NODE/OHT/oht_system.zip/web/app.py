"""
web/app.py
Flask 웹 서버 - 실시간 OHT 차량 위치 모니터링 (반도체 FAB)

실행: python run_web.py
"""
import sys
import os
import json
import threading
import time
from datetime import datetime
from flask import Flask, render_template, jsonify
from flask_socketio import SocketIO, emit

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from client.oht_client import OhtClient
from web.fab_layout import generate_fab_layout

app = Flask(__name__)
app.config['SECRET_KEY'] = 'oht-secret-key'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# OHT 클라이언트
oht_client = None
connected_to_server = False

# FAB 레이아웃 (캐시)
fab_layout = None


def get_fab_layout():
    """FAB 레이아웃 가져오기 (캐시)"""
    global fab_layout
    if fab_layout is None:
        fab_layout = generate_fab_layout()
    return fab_layout


def connect_to_oht_server(host="127.0.0.1", port=9000):
    """OHT 서버에 연결"""
    global oht_client, connected_to_server

    oht_client = OhtClient(host, port)
    if oht_client.connect():
        connected_to_server = True
        print(f"[Web] OHT 서버 연결 성공: {host}:{port}")

        # 실시간 구독 시작
        def on_location(data):
            # 레이아웃 기반 좌표 계산
            layout = get_fab_layout()
            data['position'] = calculate_vehicle_position(data, layout)
            socketio.emit('vehicle_update', data)

        def on_alert(data):
            socketio.emit('vehicle_alert', data)

        oht_client.subscribe(None, on_location, on_alert)
        return True
    else:
        print(f"[Web] OHT 서버 연결 실패: {host}:{port}")
        return False


def calculate_vehicle_position(vehicle_data, layout):
    """차량 위치를 레이아웃 좌표로 변환"""
    current_address = vehicle_data.get('current_address', 0)
    distance = vehicle_data.get('distance', 0)  # mm
    next_address = vehicle_data.get('next_address', 0)

    # 현재 주소에 해당하는 노드 찾기
    current_node = None
    next_node = None

    for node in layout.get('nodes', []):
        if node['address'] == current_address:
            current_node = node
        if node['address'] == next_address:
            next_node = node

    if current_node:
        x = current_node['x']
        y = current_node['y']

        # 다음 노드가 있으면 보간
        if next_node and distance > 0:
            # 해당 엣지 찾기
            for edge in layout.get('edges', []):
                if edge['from_address'] == current_address and edge['to_address'] == next_address:
                    # 거리 비율로 보간
                    ratio = min(distance / edge['length'], 1.0) if edge['length'] > 0 else 0
                    x = current_node['x'] + (next_node['x'] - current_node['x']) * ratio
                    y = current_node['y'] + (next_node['y'] - current_node['y']) * ratio
                    break

        return {"x": x, "y": y, "address": current_address}

    # 노드를 찾지 못한 경우 기본 위치 (주소 기반 추정)
    # 주소 범위에 따라 대략적인 위치 계산
    addr_offset = current_address - 1000
    row = (addr_offset // 100) % 4
    col = (addr_offset // 10) % 8
    pos_in_bay = addr_offset % 10

    x = 100 + col * 450 + (pos_in_bay % 5) * 50
    y = 150 + row * 400 + (pos_in_bay // 5) * 100

    return {"x": x, "y": y, "address": current_address}


@app.route('/')
def index():
    """메인 페이지"""
    return render_template('index.html')


@app.route('/api/layout')
def get_layout():
    """FAB 레이아웃 API"""
    layout = get_fab_layout()
    return jsonify(layout)


@app.route('/api/vehicles')
def get_vehicles():
    """전체 차량 조회 API"""
    if not connected_to_server or not oht_client:
        return jsonify({"error": "Not connected to server", "vehicles": []})

    vehicles = oht_client.get_all_vehicles()

    # 각 차량에 위치 정보 추가
    layout = get_fab_layout()
    for v in vehicles:
        v['position'] = calculate_vehicle_position(v, layout)

    return jsonify({"vehicles": vehicles, "count": len(vehicles)})


@app.route('/api/vehicle/<vehicle_id>')
def get_vehicle(vehicle_id):
    """특정 차량 조회 API"""
    if not connected_to_server or not oht_client:
        return jsonify({"error": "Not connected to server"})

    vehicle = oht_client.get_vehicle(vehicle_id)
    if vehicle:
        layout = get_fab_layout()
        vehicle['position'] = calculate_vehicle_position(vehicle, layout)
        return jsonify(vehicle)
    return jsonify({"error": "Vehicle not found"}), 404


@app.route('/api/stats')
def get_stats():
    """서버 통계 API"""
    if not connected_to_server or not oht_client:
        return jsonify({"error": "Not connected to server"})

    stats = oht_client.get_stats()
    stats['web_connected'] = connected_to_server
    return jsonify(stats)


@app.route('/api/history/<vehicle_id>')
def get_history(vehicle_id):
    """차량 이력 API"""
    if not connected_to_server or not oht_client:
        return jsonify({"error": "Not connected to server", "history": []})

    history = oht_client.get_vehicle_history(vehicle_id, 50)
    return jsonify({"vehicle_id": vehicle_id, "history": history})


@socketio.on('connect')
def handle_connect():
    """클라이언트 연결"""
    print(f"[Web] 브라우저 연결됨")
    emit('server_status', {'connected': connected_to_server})


@socketio.on('disconnect')
def handle_disconnect():
    """클라이언트 연결 해제"""
    print(f"[Web] 브라우저 연결 해제됨")


@socketio.on('request_vehicles')
def handle_request_vehicles():
    """차량 목록 요청"""
    if connected_to_server and oht_client:
        vehicles = oht_client.get_all_vehicles()
        layout = get_fab_layout()
        for v in vehicles:
            v['position'] = calculate_vehicle_position(v, layout)
        emit('vehicles_list', {'vehicles': vehicles})


@socketio.on('request_layout')
def handle_request_layout():
    """레이아웃 요청"""
    layout = get_fab_layout()
    emit('layout_data', layout)


def run_web_server(host="0.0.0.0", port=8080, oht_host="127.0.0.1", oht_port=9000):
    """웹 서버 실행"""
    # FAB 레이아웃 미리 생성
    get_fab_layout()
    print(f"[Web] FAB 레이아웃 생성 완료")

    # OHT 서버 연결
    connect_to_oht_server(oht_host, oht_port)

    print(f"\n[Web] 웹 서버 시작: http://{host}:{port}")
    print(f"[Web] 브라우저에서 http://localhost:{port} 접속\n")

    socketio.run(app, host=host, port=port, debug=False, allow_unsafe_werkzeug=True)


def run_all_in_one(web_port=8080, udp_port=5006, tcp_port=9000, vehicle_count=10):
    """서버 + 시뮬레이터 + 웹 통합 실행"""
    from server.oht_server import OhtServer
    from simulator.mcp_simulator import McpSimulator

    print("=" * 60)
    print("  OHT 모니터링 시스템 (통합 실행)")
    print("=" * 60)

    # 1. OHT 서버 시작 (백그라운드)
    print(f"\n[1] OHT 서버 시작 (UDP:{udp_port}, TCP:{tcp_port})...")
    server = OhtServer(udp_port=udp_port, tcp_port=tcp_port)
    server_thread = threading.Thread(target=server.start, daemon=True)
    server_thread.start()
    time.sleep(1)

    # 2. 시뮬레이터 시작 (백그라운드)
    print(f"[2] 시뮬레이터 시작 ({vehicle_count}대 차량)...")
    simulator = McpSimulator(
        server_host="127.0.0.1",
        server_port=udp_port,
        vehicle_count=vehicle_count,
        interval=0.5,
        fab_id="M14A"
    )

    def run_simulator():
        while True:
            for vhl in simulator.vehicles:
                vhl.update()
                simulator.send_message(vhl)
            time.sleep(0.5)

    sim_thread = threading.Thread(target=run_simulator, daemon=True)
    sim_thread.start()
    time.sleep(1)

    # 3. 웹 서버 시작
    print(f"[3] 웹 서버 시작...")
    run_web_server(port=web_port, oht_port=tcp_port)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="OHT 웹 모니터링")
    parser.add_argument("--mode", choices=["web", "all"], default="all",
                        help="실행 모드: web(웹만), all(서버+시뮬+웹)")
    parser.add_argument("--port", type=int, default=8080, help="웹 포트")
    parser.add_argument("--vehicles", type=int, default=10, help="시뮬레이터 차량 수")
    args = parser.parse_args()

    if args.mode == "all":
        run_all_in_one(web_port=args.port, vehicle_count=args.vehicles)
    else:
        run_web_server(port=args.port)
