"""
web 패키지
Flask 웹 UI - 실시간 차량 위치 모니터링
"""
