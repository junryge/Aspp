"""
web/fab_layout.py
반도체 FAB OHT 레이아웃 데이터 생성

실제 FAB 구조:
- Inter-bay: Bay 간 연결하는 메인 레일 (직선)
- Intra-bay: Bay 내부 레일 (U자형 또는 루프)
- Stocker: FOUP 보관 장소
- Equipment: 공정 장비 (Port 보유)
- Station: Load/Unload 포인트
"""
import json
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Tuple, Optional
import math


@dataclass
class Point:
    """좌표"""
    x: float
    y: float

    def to_dict(self):
        return {"x": self.x, "y": self.y}


@dataclass
class RailNode:
    """레일 노드 (번지)"""
    address: int
    x: float
    y: float
    node_type: str = "normal"  # normal, junction, stocker, port
    bay_id: str = ""
    name: str = ""

    def to_dict(self):
        return asdict(self)


@dataclass
class RailEdge:
    """레일 엣지 (구간)"""
    edge_id: str
    from_address: int
    to_address: int
    from_x: float
    from_y: float
    to_x: float
    to_y: float
    length: float  # mm
    max_speed: int = 300  # m/min
    rail_type: str = "inter"  # inter, intra
    bay_id: str = ""
    direction: str = "forward"  # forward, backward, bidirectional

    def to_dict(self):
        return asdict(self)


@dataclass
class Equipment:
    """장비"""
    equip_id: str
    name: str
    x: float
    y: float
    width: float
    height: float
    bay_id: str
    equip_type: str  # litho, etch, cvd, diffusion, implant, clean, inspect, stocker
    ports: List[Dict] = field(default_factory=list)

    def to_dict(self):
        return asdict(self)


@dataclass
class Bay:
    """Bay 영역"""
    bay_id: str
    name: str
    x: float
    y: float
    width: float
    height: float
    bay_type: str = "process"  # process, stocker, utility

    def to_dict(self):
        return asdict(self)


class FabLayoutGenerator:
    """FAB 레이아웃 생성기"""

    def __init__(self):
        self.nodes: List[RailNode] = []
        self.edges: List[RailEdge] = []
        self.equipments: List[Equipment] = []
        self.bays: List[Bay] = []
        self.address_counter = 1000

        # 레이아웃 설정
        self.bay_width = 400
        self.bay_height = 300
        self.bay_gap = 50
        self.inter_bay_y = 50  # Inter-bay 레일 Y 위치
        self.rail_spacing = 60  # 레일 간격

    def generate_full_fab(self) -> Dict:
        """전체 FAB 레이아웃 생성"""

        # 1. Bay 생성 (4행 x 8열 = 32개 Bay)
        self._generate_bays(rows=4, cols=8)

        # 2. Inter-bay 레일 생성 (상단/하단 2개 메인 레일)
        self._generate_inter_bay_rails()

        # 3. Intra-bay 레일 생성 (각 Bay 내부)
        self._generate_intra_bay_rails()

        # 4. 장비 배치
        self._generate_equipments()

        # 5. Stocker 배치
        self._generate_stockers()

        return self.to_dict()

    def _generate_bays(self, rows: int, cols: int):
        """Bay 영역 생성"""
        bay_types = ["process", "process", "process", "stocker"]
        equip_types_by_row = [
            ["litho", "litho", "etch", "etch", "cvd", "cvd", "clean", "inspect"],
            ["diffusion", "diffusion", "implant", "implant", "etch", "etch", "clean", "inspect"],
            ["cvd", "cvd", "metal", "metal", "etch", "etch", "clean", "inspect"],
            ["stocker", "stocker", "stocker", "stocker", "stocker", "stocker", "stocker", "stocker"],
        ]

        for row in range(rows):
            for col in range(cols):
                bay_id = f"B{row+1}{col+1:02d}"
                bay_type = bay_types[row] if row < len(bay_types) else "process"

                x = 100 + col * (self.bay_width + self.bay_gap)
                y = 150 + row * (self.bay_height + self.bay_gap + 50)

                bay = Bay(
                    bay_id=bay_id,
                    name=f"Bay {row+1}-{col+1}",
                    x=x,
                    y=y,
                    width=self.bay_width,
                    height=self.bay_height,
                    bay_type=bay_type
                )
                self.bays.append(bay)

    def _generate_inter_bay_rails(self):
        """Inter-bay 메인 레일 생성"""
        # 상단 Inter-bay 레일 (좌→우)
        start_x = 50
        end_x = 100 + 8 * (self.bay_width + self.bay_gap)
        y_top = 100

        # 상단 레일 노드들
        prev_addr = None
        for col in range(9):  # 8개 Bay + 시작점
            x = start_x + col * (self.bay_width + self.bay_gap)
            addr = self._next_address()

            node = RailNode(
                address=addr,
                x=x,
                y=y_top,
                node_type="junction" if col > 0 and col < 8 else "normal",
                bay_id="INTER_TOP",
                name=f"IT-{col}"
            )
            self.nodes.append(node)

            if prev_addr is not None:
                edge = RailEdge(
                    edge_id=f"IT-{prev_addr}-{addr}",
                    from_address=prev_addr,
                    to_address=addr,
                    from_x=self.nodes[-2].x,
                    from_y=self.nodes[-2].y,
                    to_x=x,
                    to_y=y_top,
                    length=(self.bay_width + self.bay_gap) * 1000,
                    rail_type="inter",
                    direction="bidirectional"
                )
                self.edges.append(edge)

            prev_addr = addr

        # 각 행 사이의 Inter-bay 레일
        for row in range(4):
            y = 150 + row * (self.bay_height + self.bay_gap + 50) - 30
            prev_addr = None

            for col in range(9):
                x = start_x + col * (self.bay_width + self.bay_gap)
                addr = self._next_address()

                node = RailNode(
                    address=addr,
                    x=x,
                    y=y,
                    node_type="junction",
                    bay_id=f"INTER_R{row}",
                    name=f"IR{row}-{col}"
                )
                self.nodes.append(node)

                if prev_addr is not None:
                    edge = RailEdge(
                        edge_id=f"IR{row}-{prev_addr}-{addr}",
                        from_address=prev_addr,
                        to_address=addr,
                        from_x=self.nodes[-2].x,
                        from_y=self.nodes[-2].y,
                        to_x=x,
                        to_y=y,
                        length=(self.bay_width + self.bay_gap) * 1000,
                        rail_type="inter",
                        direction="bidirectional"
                    )
                    self.edges.append(edge)

                prev_addr = addr

    def _generate_intra_bay_rails(self):
        """Intra-bay 레일 생성 (각 Bay 내부 U자형 루프)"""
        for bay in self.bays:
            self._generate_bay_internal_rail(bay)

    def _generate_bay_internal_rail(self, bay: Bay):
        """개별 Bay 내부 레일 생성"""
        # U자형 레일: 상단 진입 → 좌측 하강 → 하단 이동 → 우측 상승 → 상단 복귀

        # 레일 포인트들
        margin = 30
        port_y_offset = 80

        # 상단 진입점 (Junction에서 연결)
        entry_x = bay.x + bay.width / 2
        entry_y = bay.y

        # 좌측 상단
        left_top_x = bay.x + margin
        left_top_y = bay.y + margin

        # 좌측 하단
        left_bottom_x = bay.x + margin
        left_bottom_y = bay.y + bay.height - margin

        # 우측 하단
        right_bottom_x = bay.x + bay.width - margin
        right_bottom_y = bay.y + bay.height - margin

        # 우측 상단
        right_top_x = bay.x + bay.width - margin
        right_top_y = bay.y + margin

        # 노드 생성
        points = [
            (entry_x, entry_y, "junction", f"{bay.bay_id}-ENTRY"),
            (left_top_x, left_top_y, "normal", f"{bay.bay_id}-LT"),
            (left_top_x, left_top_y + port_y_offset, "port", f"{bay.bay_id}-P1"),
            (left_top_x, left_top_y + port_y_offset * 2, "port", f"{bay.bay_id}-P2"),
            (left_bottom_x, left_bottom_y, "normal", f"{bay.bay_id}-LB"),
            (bay.x + bay.width/2, left_bottom_y, "normal", f"{bay.bay_id}-CB"),
            (right_bottom_x, right_bottom_y, "normal", f"{bay.bay_id}-RB"),
            (right_bottom_x, right_top_y + port_y_offset * 2, "port", f"{bay.bay_id}-P3"),
            (right_bottom_x, right_top_y + port_y_offset, "port", f"{bay.bay_id}-P4"),
            (right_top_x, right_top_y, "normal", f"{bay.bay_id}-RT"),
            (entry_x, entry_y, "junction", f"{bay.bay_id}-EXIT"),  # 복귀점
        ]

        prev_addr = None
        bay_nodes = []

        for i, (x, y, node_type, name) in enumerate(points[:-1]):  # 마지막 EXIT 제외
            addr = self._next_address()
            node = RailNode(
                address=addr,
                x=x,
                y=y,
                node_type=node_type,
                bay_id=bay.bay_id,
                name=name
            )
            self.nodes.append(node)
            bay_nodes.append(node)

            if prev_addr is not None:
                prev_node = bay_nodes[-2]
                length = math.sqrt((x - prev_node.x)**2 + (y - prev_node.y)**2) * 10  # mm
                edge = RailEdge(
                    edge_id=f"{bay.bay_id}-{prev_addr}-{addr}",
                    from_address=prev_addr,
                    to_address=addr,
                    from_x=prev_node.x,
                    from_y=prev_node.y,
                    to_x=x,
                    to_y=y,
                    length=length,
                    rail_type="intra",
                    bay_id=bay.bay_id,
                    direction="forward"
                )
                self.edges.append(edge)

            prev_addr = addr

        # 마지막 노드에서 첫 노드로 연결 (루프 완성)
        if bay_nodes:
            first = bay_nodes[0]
            last = bay_nodes[-1]
            length = math.sqrt((first.x - last.x)**2 + (first.y - last.y)**2) * 10
            edge = RailEdge(
                edge_id=f"{bay.bay_id}-{last.address}-{first.address}",
                from_address=last.address,
                to_address=first.address,
                from_x=last.x,
                from_y=last.y,
                to_x=first.x,
                to_y=first.y,
                length=length,
                rail_type="intra",
                bay_id=bay.bay_id,
                direction="forward"
            )
            self.edges.append(edge)

    def _generate_equipments(self):
        """장비 배치"""
        equip_types = {
            0: ["ASML", "ASML", "LAM", "LAM", "AMAT", "AMAT", "DNS", "KLA"],
            1: ["DIFF", "DIFF", "AMAT", "AMAT", "LAM", "LAM", "DNS", "KLA"],
            2: ["AMAT", "AMAT", "AMAT", "AMAT", "LAM", "LAM", "DNS", "KLA"],
        }

        equip_full_types = {
            0: ["litho", "litho", "etch", "etch", "cvd", "cvd", "clean", "inspect"],
            1: ["diffusion", "diffusion", "implant", "implant", "etch", "etch", "clean", "inspect"],
            2: ["cvd", "cvd", "metal", "metal", "etch", "etch", "clean", "inspect"],
        }

        equip_counter = {}

        for bay in self.bays:
            if bay.bay_type == "stocker":
                continue

            # Bay 정보에서 row, col 추출
            row = int(bay.bay_id[1]) - 1
            col = int(bay.bay_id[2:]) - 1

            if row >= 3:
                continue

            # 장비 2개 배치 (좌/우)
            for side in range(2):
                equip_type = equip_full_types.get(row, ["process"])[col] if col < 8 else "process"
                vendor = equip_types.get(row, ["EQP"])[col] if col < 8 else "EQP"

                # 장비 ID 생성
                if equip_type not in equip_counter:
                    equip_counter[equip_type] = 0
                equip_counter[equip_type] += 1
                equip_id = f"{equip_type.upper()}{equip_counter[equip_type]:03d}"

                # 위치 계산
                equip_width = 80
                equip_height = 100
                margin = 50

                if side == 0:
                    x = bay.x + margin
                else:
                    x = bay.x + bay.width - margin - equip_width

                y = bay.y + bay.height / 2 - equip_height / 2

                # 포트 정보
                ports = [
                    {"port_id": f"{equip_id}-LP1", "x": x + equip_width/2, "y": y, "type": "load"},
                    {"port_id": f"{equip_id}-LP2", "x": x + equip_width/2, "y": y + equip_height, "type": "load"},
                ]

                equip = Equipment(
                    equip_id=equip_id,
                    name=f"{vendor} {equip_type.upper()}",
                    x=x,
                    y=y,
                    width=equip_width,
                    height=equip_height,
                    bay_id=bay.bay_id,
                    equip_type=equip_type,
                    ports=ports
                )
                self.equipments.append(equip)

    def _generate_stockers(self):
        """Stocker 배치"""
        stocker_counter = 0

        for bay in self.bays:
            if bay.bay_type != "stocker":
                continue

            stocker_counter += 1
            stocker_id = f"STK{stocker_counter:03d}"

            # Stocker는 Bay 전체 크기
            stocker = Equipment(
                equip_id=stocker_id,
                name=f"Stocker {stocker_counter}",
                x=bay.x + 20,
                y=bay.y + 20,
                width=bay.width - 40,
                height=bay.height - 40,
                bay_id=bay.bay_id,
                equip_type="stocker",
                ports=[
                    {"port_id": f"{stocker_id}-IN", "x": bay.x + bay.width/2, "y": bay.y, "type": "input"},
                    {"port_id": f"{stocker_id}-OUT", "x": bay.x + bay.width/2, "y": bay.y + bay.height, "type": "output"},
                ]
            )
            self.equipments.append(stocker)

    def _next_address(self) -> int:
        """다음 주소 반환"""
        addr = self.address_counter
        self.address_counter += 1
        return addr

    def to_dict(self) -> Dict:
        """전체 레이아웃을 딕셔너리로 변환"""
        return {
            "fab_id": "M14A",
            "fab_name": "M14 FAB A",
            "canvas": {
                "width": 3800,
                "height": 1600
            },
            "bays": [b.to_dict() for b in self.bays],
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
            "equipments": [e.to_dict() for e in self.equipments],
            "stats": {
                "total_bays": len(self.bays),
                "total_nodes": len(self.nodes),
                "total_edges": len(self.edges),
                "total_equipments": len(self.equipments),
                "address_range": f"1000-{self.address_counter-1}"
            }
        }

    def to_json(self) -> str:
        """JSON 문자열로 변환"""
        return json.dumps(self.to_dict(), indent=2, ensure_ascii=False)


def generate_fab_layout() -> Dict:
    """FAB 레이아웃 생성"""
    generator = FabLayoutGenerator()
    return generator.generate_full_fab()


if __name__ == "__main__":
    layout = generate_fab_layout()
    print(json.dumps(layout, indent=2))
    print(f"\n총 Bay: {layout['stats']['total_bays']}")
    print(f"총 Node: {layout['stats']['total_nodes']}")
    print(f"총 Edge: {layout['stats']['total_edges']}")
    print(f"총 Equipment: {layout['stats']['total_equipments']}")
