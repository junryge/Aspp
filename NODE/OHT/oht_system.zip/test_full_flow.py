#!/usr/bin/env python
"""
test_full_flow.py
전체 흐름 테스트 - 시뮬레이터 → 서버 → 클라이언트
"""
import sys
import os
import time
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from simulator.mcp_simulator import McpSimulator
from server.oht_server import OhtServer
from client.oht_client import OhtClient


def test_full_flow():
    """전체 흐름 테스트"""
    print("=" * 70)
    print("  OHT 시스템 전체 흐름 테스트")
    print("=" * 70)

    # 1. 서버 시작
    print("\n[1] 서버 시작...")
    server = OhtServer(udp_port=5000, tcp_port=9000)
    server_thread = threading.Thread(target=server.start, daemon=True)
    server_thread.start()
    time.sleep(1)
    print("    서버 시작됨 (UDP:5000, TCP:9000)")

    # 2. 시뮬레이터 시작
    print("\n[2] 시뮬레이터 시작...")
    simulator = McpSimulator(
        server_host="127.0.0.1",
        server_port=5000,
        vehicle_count=5,
        interval=0.5
    )

    def run_simulator():
        for _ in range(10):  # 10회 전송
            for vhl in simulator.vehicles:
                vhl.update()
                simulator.send_message(vhl)
            time.sleep(0.5)

    sim_thread = threading.Thread(target=run_simulator, daemon=True)
    sim_thread.start()
    print("    시뮬레이터 시작됨 (5대 차량, 0.5초 간격)")

    # 3. 데이터 수신 대기
    print("\n[3] 데이터 수신 대기 (3초)...")
    time.sleep(3)

    # 4. 클라이언트 연결 및 조회
    print("\n[4] 클라이언트 연결...")
    client = OhtClient(host="127.0.0.1", port=9000)

    if client.connect():
        print("    클라이언트 연결 성공!")

        # Ping 테스트
        print("\n[5] Ping 테스트...")
        if client.ping():
            print("    Ping 성공!")
        else:
            print("    Ping 실패!")

        # 통계 조회
        print("\n[6] 서버 통계 조회...")
        stats = client.get_stats()
        print(f"    총 차량 수: {stats.get('total_vehicles', 0)}")
        print(f"    총 메시지: {stats.get('total_messages', 0)}")
        print(f"    속도 계산: {stats.get('velocity_calculations', 0)}")

        # 전체 차량 조회
        print("\n[7] 전체 차량 조회...")
        vehicles = client.get_all_vehicles()
        print(f"    조회된 차량 수: {len(vehicles)}")

        for v in vehicles[:3]:
            vid = v.get('vehicle_id', '')
            addr = v.get('current_address', 0)
            dist = v.get('distance', 0)
            state = v.get('state_desc', '')
            print(f"      {vid}: addr={addr}, dist={dist}mm, state={state}")

        # 특정 차량 조회
        if vehicles:
            first_vid = vehicles[0].get('vehicle_id')
            print(f"\n[8] 특정 차량 조회 ({first_vid})...")
            vehicle = client.get_vehicle(first_vid)
            if vehicle:
                print(f"    ID: {vehicle.get('vehicle_id')}")
                print(f"    위치: {vehicle.get('current_address')} + {vehicle.get('distance')}mm")
                print(f"    상태: {vehicle.get('state_desc')}")
                print(f"    Cycle: {vehicle.get('run_cycle_desc')} / {vehicle.get('vhl_cycle_desc')}")
                print(f"    적재: {'있음' if vehicle.get('is_loaded') else '없음'}")

        # 구독 테스트
        print("\n[9] 실시간 구독 테스트 (2초)...")
        received_count = 0

        def on_location(data):
            nonlocal received_count
            received_count += 1

        client.subscribe(None, on_location)
        time.sleep(2)
        client.unsubscribe()
        print(f"    수신된 위치 업데이트: {received_count}건")

        # 연결 해제
        client.disconnect()
        print("\n[10] 클라이언트 연결 해제")

    else:
        print("    클라이언트 연결 실패!")

    # 종료
    print("\n" + "=" * 70)
    print("  테스트 완료!")
    print("=" * 70)

    # 정리
    server.stop()


if __name__ == "__main__":
    test_full_flow()
