"""
common/protocol.py
서버-클라이언트 TCP 통신 프로토콜 정의
"""
import json
import uuid
from enum import Enum
from typing import Dict, Any, Optional
from dataclasses import dataclass, asdict
from datetime import datetime


class MessageType(Enum):
    """메시지 타입"""
    # 요청 (Client → Server)
    REQ_ALL_VEHICLES = "REQ_ALL_VEHICLES"       # 전체 차량 조회
    REQ_VEHICLE = "REQ_VEHICLE"                 # 특정 차량 조회
    REQ_VEHICLE_HISTORY = "REQ_VEHICLE_HISTORY" # 차량 이력 조회
    REQ_STATS = "REQ_STATS"                     # 서버 통계 조회
    REQ_SUBSCRIBE = "REQ_SUBSCRIBE"             # 실시간 구독
    REQ_UNSUBSCRIBE = "REQ_UNSUBSCRIBE"         # 구독 해제
    REQ_PING = "REQ_PING"                       # 연결 확인

    # 응답 (Server → Client)
    RES_SUCCESS = "RES_SUCCESS"
    RES_ERROR = "RES_ERROR"
    RES_VEHICLES = "RES_VEHICLES"
    RES_VEHICLE = "RES_VEHICLE"
    RES_HISTORY = "RES_HISTORY"
    RES_STATS = "RES_STATS"
    RES_PONG = "RES_PONG"

    # 푸시 (Server → Client, 구독 시)
    PUSH_LOCATION = "PUSH_LOCATION"             # 위치 업데이트
    PUSH_VELOCITY = "PUSH_VELOCITY"             # 속도 계산 결과
    PUSH_ALERT = "PUSH_ALERT"                   # 알림 (JAM, ABNORMAL 등)


@dataclass
class Message:
    """통신 메시지 구조"""
    msg_type: str
    payload: Dict[str, Any] = None
    request_id: str = ""
    timestamp: str = ""

    def __post_init__(self):
        if self.payload is None:
            self.payload = {}
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()
        if not self.request_id:
            self.request_id = str(uuid.uuid4())[:8]

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_json(cls, json_str: str) -> 'Message':
        data = json.loads(json_str)
        return cls(**data)

    def encode(self) -> bytes:
        """네트워크 전송용 인코딩 (4바이트 길이 헤더 + JSON 데이터)"""
        json_data = self.to_json().encode('utf-8')
        length = len(json_data)
        return length.to_bytes(4, 'big') + json_data

    @classmethod
    def decode(cls, data: bytes) -> 'Message':
        """네트워크 수신 데이터 디코딩"""
        json_str = data.decode('utf-8')
        return cls.from_json(json_str)


class Protocol:
    """프로토콜 헬퍼 클래스"""

    HEADER_SIZE = 4  # 길이 헤더 크기 (bytes)

    @staticmethod
    def create_request(msg_type: MessageType, payload: Dict = None,
                       request_id: str = "") -> Message:
        """요청 메시지 생성"""
        return Message(
            msg_type=msg_type.value,
            payload=payload or {},
            request_id=request_id or str(uuid.uuid4())[:8]
        )

    @staticmethod
    def create_response(msg_type: MessageType, payload: Dict = None,
                        request_id: str = "") -> Message:
        """응답 메시지 생성"""
        return Message(
            msg_type=msg_type.value,
            payload=payload or {},
            request_id=request_id
        )

    @staticmethod
    def create_error(error_msg: str, request_id: str = "") -> Message:
        """에러 응답 생성"""
        return Message(
            msg_type=MessageType.RES_ERROR.value,
            payload={"error": error_msg},
            request_id=request_id
        )

    @staticmethod
    def create_push(msg_type: MessageType, payload: Dict = None) -> Message:
        """푸시 메시지 생성"""
        return Message(
            msg_type=msg_type.value,
            payload=payload or {}
        )
