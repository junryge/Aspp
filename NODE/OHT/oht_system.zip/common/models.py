"""
common/models.py
OHT 시스템 공통 데이터 모델
"""
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional, Dict, Any, List
from enum import Enum
import json


class VhlState(Enum):
    """Vehicle 상태 코드"""
    RUNNING = "1"       # 운전 중
    STOPPED = "2"       # 정지 중
    ABNORMAL = "3"      # 이상
    MANUAL = "4"        # 수동
    EXPORTING = "5"     # 수출 중
    OBS_STOP = "6"      # OBS-STOP/BZ-STOP
    JAM = "7"           # 정체
    E84_TIMEOUT = "9"   # E84 Timeout
    E84_NO_CYCLE = "10" # 주회 없음 E84 Timeout
    HT_STOP = "11"      # HT-STOP


class RunCycle(Enum):
    """실행 Cycle 코드"""
    NONE = "0"          # Cycle 없음
    POSITION = "1"      # 위치 확인 Cycle 중
    MOVING = "2"        # 이동 Cycle 중
    DEPOSIT = "3"       # Unload Cycle 중 (DEPOSIT)
    ACQUIRE = "4"       # Load Cycle 중 (ACQUIRE)
    EXPORT = "5"        # 수출 Cycle 중
    INTER_FLOOR = "9"   # 승간 이동 Cycle 중
    PATROL = "21"       # 주회 주행 Cycle 중


class VhlCycle(Enum):
    """Vehicle 실행 Cycle 진척"""
    NONE = "0"          # 실행 Cycle 없음
    MOVING = "1"        # 이동 중
    DEPOSIT_MOVING = "2" # Unload 이동 중
    DEPOSIT_TRANS = "3"  # Unload 이재 중
    ACQUIRE_MOVING = "4" # Load 이동 중
    ACQUIRE_TRANS = "5"  # Load 이재 중
    ALT_WAIT = "7"      # 대체 지시 대기


# 상태 코드 → 설명 매핑
STATE_DESC_MAP = {
    "1": "운전중(RUN)", "2": "정지중", "3": "이상(ABNORMAL)",
    "4": "수동", "5": "수출중", "6": "OBS_STOP",
    "7": "정체(JAM)", "9": "E84_TIMEOUT",
    "10": "주회없음 E84", "11": "HT_STOP"
}

RUN_CYCLE_DESC_MAP = {
    "0": "없음", "1": "위치확인", "2": "이동",
    "3": "DEPOSIT", "4": "ACQUIRE",
    "5": "수출", "9": "승간이동", "21": "주회주행"
}

VHL_CYCLE_DESC_MAP = {
    "0": "없음", "1": "이동중",
    "2": "DEPOSIT_MOVING", "3": "DEPOSIT_TRANS",
    "4": "ACQUIRE_MOVING", "5": "ACQUIRE_TRANS",
    "7": "대체지시대기"
}


@dataclass
class VhlLocationData:
    """Vehicle 위치 데이터"""
    # 기본 식별 정보
    message_id: str = ""
    mcp_name: str = ""
    vehicle_id: str = ""

    # 상태 정보
    state: str = ""
    state_desc: str = ""
    is_loaded: bool = False
    error_code: str = "0000"
    comm_status: str = "1"

    # 위치 정보 (핵심)
    current_address: int = 0
    distance: int = 0           # mm 단위
    next_address: int = 0

    # Cycle 정보
    run_cycle: str = ""
    run_cycle_desc: str = ""
    vhl_cycle: str = ""
    vhl_cycle_desc: str = ""

    # 반송 정보
    carrier_id: str = ""
    destination: int = 0
    em_status: str = ""
    group_id: str = ""

    # 추가 정보
    source_port: str = ""
    dest_port: str = ""
    priority: int = 0
    detail_state: str = ""
    run_distance: int = 0
    command_id: str = ""
    bay_name: str = ""

    # 메타 정보
    received_time: str = ""
    raw_message: str = ""

    # 속도 정보 (계산된 값)
    velocity: float = 0.0
    velocity_valid: bool = False

    def __post_init__(self):
        if not self.received_time:
            self.received_time = datetime.now().isoformat()
        if not self.state_desc and self.state:
            self.state_desc = STATE_DESC_MAP.get(self.state, "알수없음")
        if not self.run_cycle_desc and self.run_cycle:
            self.run_cycle_desc = RUN_CYCLE_DESC_MAP.get(self.run_cycle, "알수없음")
        if not self.vhl_cycle_desc and self.vhl_cycle:
            self.vhl_cycle_desc = VHL_CYCLE_DESC_MAP.get(self.vhl_cycle, "알수없음")

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'VhlLocationData':
        valid_fields = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        return cls(**valid_fields)

    @classmethod
    def from_json(cls, json_str: str) -> 'VhlLocationData':
        return cls.from_dict(json.loads(json_str))


@dataclass
class VhlVelocityData:
    """Vehicle 속도 데이터"""
    vehicle_id: str
    velocity: float             # m/min
    distance: float             # mm
    time_diff: float            # seconds
    from_address: int
    to_address: int
    rail_edge_id: str = ""
    calculated_time: str = ""

    def __post_init__(self):
        if not self.calculated_time:
            self.calculated_time = datetime.now().isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)


@dataclass
class ServerStats:
    """서버 통계 정보"""
    total_vehicles: int = 0
    active_vehicles: int = 0
    total_messages: int = 0
    messages_per_second: float = 0.0
    connected_clients: int = 0
    uptime_seconds: float = 0.0
    velocity_calculations: int = 0
    last_update: str = ""

    def __post_init__(self):
        if not self.last_update:
            self.last_update = datetime.now().isoformat()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)
