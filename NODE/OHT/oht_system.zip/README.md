# OHT System - 위치 데이터 시뮬레이션 및 모니터링

OHT(Overhead Hoist Transport) 시스템의 위치 데이터를 시뮬레이션하고 모니터링하는 시스템입니다.

## 구조

```
oht_system/
├── common/                 # 공통 모듈
│   ├── __init__.py
│   ├── models.py          # 데이터 모델 (VhlLocationData, VhlVelocityData 등)
│   └── protocol.py        # TCP 통신 프로토콜
├── server/                 # 서버 모듈
│   ├── __init__.py
│   ├── oht_server.py      # 메인 서버
│   ├── udp_receiver.py    # UDP 수신기
│   └── client_handler.py  # TCP 클라이언트 핸들러
├── client/                 # 클라이언트 모듈
│   ├── __init__.py
│   ├── oht_client.py      # TCP 클라이언트
│   └── cli.py             # CLI 인터페이스
├── simulator/              # 시뮬레이터 모듈
│   ├── __init__.py
│   └── mcp_simulator.py   # MCP 시뮬레이터 (가짜 데이터 생성)
├── run_server.py          # 서버 실행
├── run_client.py          # 클라이언트 실행
└── run_simulator.py       # 시뮬레이터 실행
```

## 아키텍처

```
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│   ┌─────────────────┐                                                  │
│   │  MCP Simulator  │  ← 가짜 OHT 데이터 생성 & UDP 송신               │
│   │  (run_simulator)│                                                  │
│   └────────┬────────┘                                                  │
│            │ UDP (Port 5000)                                           │
│            ▼                                                            │
│   ┌─────────────────┐                                                  │
│   │   OHT Server    │  ← UDP 수신 + 처리 + 속도 계산                   │
│   │   (run_server)  │                                                  │
│   └────────┬────────┘                                                  │
│            │ TCP (Port 9000)                                           │
│            ▼                                                            │
│   ┌─────────────────┐                                                  │
│   │   OHT Client    │  ← 서버 접속 + 조회/모니터링                     │
│   │   (run_client)  │                                                  │
│   └─────────────────┘                                                  │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 실행 방법

### 1. 서버 실행 (터미널 1)

```bash
cd oht_system
python run_server.py
```

옵션:
- `--udp-port`: UDP 수신 포트 (기본: 5000)
- `--tcp-port`: TCP 서비스 포트 (기본: 9000)

### 2. 시뮬레이터 실행 (터미널 2)

```bash
python run_simulator.py
```

옵션:
- `--host`: 서버 IP (기본: 127.0.0.1)
- `--port`: 서버 UDP 포트 (기본: 5000)
- `--vehicles`: 시뮬레이션할 차량 수 (기본: 10)
- `--interval`: 송신 주기 초 (기본: 0.5)
- `--fab`: FAB ID - M11A, M14A, M16A (기본: M11A)

예시:
```bash
python run_simulator.py --vehicles 20 --interval 0.3
```

### 3. 클라이언트 실행 (터미널 3)

```bash
python run_client.py
```

또는 자동 연결:
```bash
python run_client.py --auto-connect
```

모니터링 모드:
```bash
python run_client.py --monitor
```

## CLI 명령어

```
connect [host] [port]  - 서버 연결 (기본: 127.0.0.1:9000)
disconnect             - 서버 연결 해제
status                 - 연결 상태 확인
ping                   - 서버 핑

vehicles               - 전체 차량 목록
vehicle <id>           - 특정 차량 상세 정보
history <id> [limit]   - 차량 이력 조회
stats                  - 서버 통계

subscribe [id1,id2..]  - 실시간 구독 (비어있으면 전체)
unsubscribe            - 구독 해제
monitor                - 실시간 모니터링 모드

quit                   - 종료
```

## UDP 메시지 형식

프로토콜 ID: 2 (Vehicle 상태 보고)

```
2,OHT,V00001,1,1,0000,1,4176,20,4177,4,4,CARRIER1234,4011,00000000,0000,...
```

| 인덱스 | 필드 | 설명 |
|--------|------|------|
| 0 | message_id | 메시지 ID (2) |
| 1 | mcp_name | MCP 명칭 |
| 2 | vehicle_id | Vehicle 명칭 |
| 3 | state | 상태 (1=운전중, 6=OBS_STOP, 7=JAM 등) |
| 4 | is_loaded | 재하 정보 (0=없음, 1=있음) |
| 5 | error_code | 에러 코드 |
| 6 | comm_status | 통신 상태 (1=정상) |
| 7 | current_address | 현재 번지 |
| 8 | distance | 거리 (100mm 단위) |
| 9 | next_address | 다음 번지 |
| 10 | run_cycle | 실행 Cycle (3=DEPOSIT, 4=ACQUIRE) |
| 11 | vhl_cycle | Vehicle Cycle (2=DEPOSIT_MOVING, 4=ACQUIRE_MOVING) |
| 12 | carrier_id | Carrier ID |
| 13 | destination | 목적지 |
| ... | ... | ... |

## 속도 계산 조건

속도를 계산하려면 다음 5가지 조건을 모두 만족해야 합니다:

1. **시간 조건**: 메시지 수신 시간 차이 1분 미만
2. **상태 조건**: RUN(1), OBS_STOP(6), JAM(7), E84_TIMEOUT(9) 중 하나
3. **Cycle 일치**: 이전과 현재의 run_cycle, vhl_cycle 동일
4. **실행 Cycle**: ACQUIRE(4) 또는 DEPOSIT(3)
5. **Vehicle Cycle**: ACQUIRE_MOVING(4) 또는 DEPOSIT_MOVING(2)

속도 공식: `v = Δx / Δt × 60` (m/min)

## 요구사항

- Python 3.7+
- 추가 패키지 없음 (표준 라이브러리만 사용)
