"""
simulator/mcp_simulator.py
MCP 시뮬레이터 - 가짜 OHT Vehicle 데이터 생성 및 UDP 송신

실행: python mcp_simulator.py --vehicles 10 --interval 0.5
"""
import socket
import time
import random
import math
from datetime import datetime
from dataclasses import dataclass, field
from typing import List, Dict, Optional
import sys
import os


# ============================================================
# 가짜 레이아웃 데이터
# ============================================================

# FAB 정보
FAB_INFO = {
    "M11A": {"prefix": 1000, "vehicle_length": 1084},
    "M14A": {"prefix": 2000, "vehicle_length": 1084},
    "M16A": {"prefix": 3000, "vehicle_length": 1243},
}

# Bay 이름 목록
BAY_NAMES = [f"B{i:02d}" for i in range(1, 33)]  # B01 ~ B32


def generate_rail_edges(fab_id: str, count: int = 200) -> Dict:
    """가짜 RailEdge 데이터 생성"""
    prefix = FAB_INFO.get(fab_id, {}).get("prefix", 1000)
    edges = {}

    for i in range(count):
        addr = prefix + i
        next_addr = prefix + i + 1
        length = random.randint(1500, 4000)  # mm
        max_speed = random.choice([200, 250, 300, 320])  # m/min

        edge_id = f"{fab_id}:RE:A:{fab_id}:RN:A:{addr:05d}-{fab_id}:RN:A:{next_addr:05d}"
        edges[addr] = {
            "edge_id": edge_id,
            "from_address": addr,
            "to_address": next_addr,
            "length": length,
            "max_speed": max_speed,
        }

    return edges


# ============================================================
# Vehicle 시뮬레이션
# ============================================================

@dataclass
class SimVehicle:
    """시뮬레이션용 Vehicle"""
    vehicle_id: str
    fab_id: str = "M11A"
    mcp_name: str = "OHT"

    # 위치 정보
    current_address: int = 1000
    next_address: int = 1001
    distance: int = 0               # 100mm 단위 (UDP 전송용)
    distance_mm: int = 0            # 실제 mm 단위 (내부 계산용)

    # 상태 정보
    state: str = "1"                # 1=운전중, 6=OBS_STOP, 7=JAM 등
    is_loaded: bool = False
    error_code: str = "0000"
    comm_status: str = "1"          # 1=정상, 2=끊김

    # Cycle 정보
    run_cycle: str = "4"            # 3=DEPOSIT, 4=ACQUIRE
    vhl_cycle: str = "4"            # 2=DEPOSIT_MOVING, 4=ACQUIRE_MOVING
    detail_state: str = "101"       # 101=이동중

    # 반송 정보
    carrier_id: str = ""
    destination: int = 1050
    source_port: str = ""
    dest_port: str = ""
    priority: int = 50

    # 기타
    em_status: str = "00000000"
    group_id: str = "0000"
    bay_name: str = "B01"
    command_id: str = ""
    run_distance: int = 0           # 대차 주행거리 (mm)
    eta: int = 0                    # 도착 예상 시간 (msec)

    # 시뮬레이션 파라미터
    speed_mpm: float = 280.0        # m/min
    rail_length: int = 2000         # 현재 RailEdge 길이 (mm)
    update_interval: float = 0.5    # 업데이트 주기 (초)

    # 내부 상태
    _stop_counter: int = 0

    def __post_init__(self):
        """초기화"""
        self.bay_name = random.choice(BAY_NAMES)
        self.command_id = f"CMD{random.randint(10000, 99999)}"
        self._calculate_eta()

    def _calculate_eta(self):
        """도착 예상 시간 계산"""
        if self.destination > self.current_address:
            remain_distance = (self.destination - self.current_address) * 2500
            if self.speed_mpm > 0:
                self.eta = int((remain_distance / 1000) / self.speed_mpm * 60 * 1000)

    def update(self):
        """위치 업데이트 (매 주기 호출)"""
        # JAM이나 STOP 상태면 일정 시간 후 해제
        if self.state in ["6", "7"]:
            self._stop_counter += 1
            if self._stop_counter > random.randint(5, 15):
                self.state = "1"
                self._stop_counter = 0
            return

        # 이동 거리 계산 (speed_mpm * interval / 60 * 1000 = mm)
        move_distance = int(self.speed_mpm * self.update_interval / 60 * 1000)
        self.distance_mm += move_distance
        self.run_distance += move_distance

        # 100mm 단위로 변환 (UDP 전송용)
        self.distance = self.distance_mm // 100

        # RailEdge 끝 도달
        if self.distance_mm >= self.rail_length:
            self._move_to_next_address()

        # 랜덤 이벤트 (3% 확률로 JAM/OBS_STOP)
        if random.random() < 0.03:
            self.state = random.choice(["6", "7"])  # OBS_STOP or JAM
            self._stop_counter = 0

        # 목적지 도착 체크
        if self.current_address >= self.destination:
            self._arrive_destination()

        # ETA 업데이트
        self._calculate_eta()

    def _move_to_next_address(self):
        """다음 번지로 이동"""
        self.current_address = self.next_address
        self.next_address += 1
        self.distance_mm = 0
        self.distance = 0

        # 새 RailEdge 길이 설정
        self.rail_length = random.randint(1500, 4000)

        # Bay 변경 (10% 확률)
        if random.random() < 0.1:
            self.bay_name = random.choice(BAY_NAMES)

    def _arrive_destination(self):
        """목적지 도착"""
        # 새 목적지 설정
        self.destination = self.current_address + random.randint(20, 100)

        # 적재 상태 토글
        self.is_loaded = not self.is_loaded

        # Cycle 변경
        if self.is_loaded:
            self.carrier_id = self._generate_carrier_id()
            self.run_cycle = "3"    # DEPOSIT (Unload)
            self.vhl_cycle = "2"    # DEPOSIT_MOVING
            self.source_port = f"LP{random.randint(1, 20):02d}"
            self.dest_port = f"LP{random.randint(1, 20):02d}"
        else:
            self.carrier_id = ""
            self.run_cycle = "4"    # ACQUIRE (Load)
            self.vhl_cycle = "4"    # ACQUIRE_MOVING
            self.source_port = ""
            self.dest_port = ""

        # 새 Command ID
        self.command_id = f"CMD{random.randint(10000, 99999)}"
        self.run_distance = 0

        # 우선순위 랜덤
        self.priority = random.choice([30, 50, 70, 90])

    def _generate_carrier_id(self) -> str:
        """Carrier ID 생성"""
        prefix = random.choice(["FOUP", "POD", "4PDM", "4CSC"])
        suffix = f"{random.randint(1000, 9999)}"
        return f"{prefix}{suffix}"

    def to_udp_message(self) -> str:
        """
        UDP 메시지 형식 변환

        형식 (UDP 프로토콜 ID:2):
        2,MCP명,VHL명,상태,재하,에러,통신,현재번지,거리,다음번지,
        실행cycle,vhl_cycle,carrier,목적지,EM상태,그룹ID,
        반송원Port,반송처Port,우선도,상세상태,주행거리,CommandID,Bay명
        """
        tokens = [
            "2",                                    # 0: message_id
            self.mcp_name,                          # 1: mcp 명칭
            self.vehicle_id,                        # 2: vehicle 명칭
            self.state,                             # 3: 상태
            "1" if self.is_loaded else "0",         # 4: 재하 정보
            self.error_code,                        # 5: error code
            self.comm_status,                       # 6: 통신 상태
            str(self.current_address),              # 7: 현재 번지
            str(self.distance),                     # 8: 거리 (100mm 단위)
            str(self.next_address),                 # 9: 다음 번지
            self.run_cycle,                         # 10: 실행 cycle
            self.vhl_cycle,                         # 11: vehicle 실행 cycle
            self.carrier_id,                        # 12: carrier id
            str(self.destination),                  # 13: 목적지
            self.em_status,                         # 14: E/M 상태
            self.group_id,                          # 15: group id
            self.source_port,                       # 16: 반송원 Port
            self.dest_port,                         # 17: 반송처 Port
            str(self.priority),                     # 18: 반송 우선도
            self.detail_state,                      # 19: 작업 상태 상세
            str(self.run_distance),                 # 20: 대차 주행거리
            self.command_id,                        # 21: Command ID
            self.bay_name,                          # 22: Bay 명칭
        ]
        return ",".join(tokens)

    def get_status_display(self) -> str:
        """상태 표시용 문자열"""
        state_map = {
            "1": "RUN", "2": "STOP", "3": "ABNORMAL",
            "6": "OBS_STOP", "7": "JAM", "9": "E84_TIMEOUT"
        }
        cycle_map = {"3": "DEPOSIT", "4": "ACQUIRE"}

        return (f"{self.vehicle_id} | Addr:{self.current_address}+{self.distance*100}mm | "
                f"{state_map.get(self.state, '?'):>8} | "
                f"{cycle_map.get(self.run_cycle, '?'):>8} | "
                f"{'LOADED' if self.is_loaded else 'EMPTY':>6} | "
                f"Dest:{self.destination}")


# ============================================================
# MCP 시뮬레이터
# ============================================================

class McpSimulator:
    """MCP 시뮬레이터 - 가짜 데이터 생성 및 UDP 송신"""

    def __init__(self,
                 server_host: str = "127.0.0.1",
                 server_port: int = 5000,
                 vehicle_count: int = 10,
                 interval: float = 0.5,
                 fab_id: str = "M11A"):

        self.server_host = server_host
        self.server_port = server_port
        self.interval = interval
        self.fab_id = fab_id

        # UDP 소켓
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # 가짜 레이아웃 데이터 생성
        self.rail_edges = generate_rail_edges(fab_id, 200)

        # Vehicle 생성
        self.vehicles: List[SimVehicle] = []
        self._create_vehicles(vehicle_count)

        # 통계
        self.running = False
        self.send_count = 0
        self.start_time: Optional[datetime] = None

    def _create_vehicles(self, count: int):
        """Vehicle 생성"""
        prefix = FAB_INFO.get(self.fab_id, {}).get("prefix", 1000)

        for i in range(count):
            vid = f"V{i+1:05d}"
            start_addr = prefix + (i * 10)  # 10칸 간격으로 배치

            vhl = SimVehicle(
                vehicle_id=vid,
                fab_id=self.fab_id,
                current_address=start_addr,
                next_address=start_addr + 1,
                destination=start_addr + random.randint(20, 80),
                is_loaded=random.choice([True, False]),
                speed_mpm=random.uniform(250, 320),
                rail_length=random.randint(1500, 3500),
                update_interval=self.interval,
            )

            # 적재 상태에 따른 Cycle 설정
            if vhl.is_loaded:
                vhl.carrier_id = vhl._generate_carrier_id()
                vhl.run_cycle = "3"
                vhl.vhl_cycle = "2"

            self.vehicles.append(vhl)

    def send_message(self, vhl: SimVehicle):
        """UDP 메시지 송신"""
        message = vhl.to_udp_message()
        self.socket.sendto(
            message.encode('utf-8'),
            (self.server_host, self.server_port)
        )
        self.send_count += 1

    def start(self):
        """시뮬레이터 시작"""
        self.running = True
        self.start_time = datetime.now()

        print("=" * 70)
        print("  MCP SIMULATOR - OHT 가짜 데이터 생성 및 UDP 송신")
        print("=" * 70)
        print(f"  FAB ID       : {self.fab_id}")
        print(f"  송신 대상    : {self.server_host}:{self.server_port}")
        print(f"  Vehicle 수   : {len(self.vehicles)}")
        print(f"  송신 주기    : {self.interval}초")
        print(f"  RailEdge 수  : {len(self.rail_edges)}")
        print("=" * 70)
        print("\n[Ctrl+C로 종료]\n")

        last_print_time = time.time()

        try:
            while self.running:
                # 모든 Vehicle 업데이트 및 송신
                for vhl in self.vehicles:
                    vhl.update()
                    self.send_message(vhl)

                # 2초마다 상태 출력
                if time.time() - last_print_time >= 2.0:
                    self._print_status()
                    last_print_time = time.time()

                time.sleep(self.interval)

        except KeyboardInterrupt:
            print("\n\n종료 요청...")
        finally:
            self.stop()

    def _print_status(self):
        """상태 출력"""
        elapsed = (datetime.now() - self.start_time).total_seconds()
        msg_per_sec = self.send_count / elapsed if elapsed > 0 else 0

        print(f"\n[{datetime.now().strftime('%H:%M:%S')}] "
              f"송신: {self.send_count:,}건 | {msg_per_sec:.1f} msg/s")
        print("-" * 70)

        # 처음 5개 Vehicle 상태만 출력
        for vhl in self.vehicles[:5]:
            print(f"  {vhl.get_status_display()}")

        if len(self.vehicles) > 5:
            print(f"  ... 외 {len(self.vehicles) - 5}대")

    def stop(self):
        """시뮬레이터 중지"""
        self.running = False
        self.socket.close()

        elapsed = (datetime.now() - self.start_time).total_seconds() if self.start_time else 0
        print("\n" + "=" * 70)
        print("  MCP SIMULATOR 종료")
        print(f"  총 송신: {self.send_count:,}건")
        print(f"  실행 시간: {elapsed:.1f}초")
        print("=" * 70)


# ============================================================
# 메인 실행
# ============================================================

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="MCP Simulator")
    parser.add_argument("--host", default="127.0.0.1", help="서버 IP (기본: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=5000, help="서버 UDP Port (기본: 5000)")
    parser.add_argument("--vehicles", type=int, default=10, help="Vehicle 수 (기본: 10)")
    parser.add_argument("--interval", type=float, default=0.5, help="송신 주기 초 (기본: 0.5)")
    parser.add_argument("--fab", default="M11A", help="FAB ID (기본: M11A)")

    args = parser.parse_args()

    simulator = McpSimulator(
        server_host=args.host,
        server_port=args.port,
        vehicle_count=args.vehicles,
        interval=args.interval,
        fab_id=args.fab
    )

    simulator.start()
