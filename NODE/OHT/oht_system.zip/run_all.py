#!/usr/bin/env python
"""
run_all.py - 서버 + 시뮬레이터 + 웹 한번에 실행
"""
import sys
import os
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from server.oht_server import OhtServer
from simulator.mcp_simulator import McpSimulator
from web.app import run_web_server

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--vehicles", type=int, default=30)
    args = parser.parse_args()

    print("=" * 60)
    print("  OHT 통합 실행 (서버 + 시뮬레이터 + 웹)")
    print("=" * 60)

    # 1. 서버
    print("[1] 서버 시작 (UDP:5000, TCP:9000)")
    server = OhtServer(udp_port=5000, tcp_port=9000)
    threading.Thread(target=server.start, daemon=True).start()
    time.sleep(2)

    # 2. 시뮬레이터
    print(f"[2] 시뮬레이터 시작 ({args.vehicles}대)")
    sim = McpSimulator(server_port=5000, vehicle_count=args.vehicles, fab_id="M14A")
    def run_sim():
        while True:
            for v in sim.vehicles:
                v.update()
                sim.send_message(v)
            time.sleep(0.5)
    threading.Thread(target=run_sim, daemon=True).start()
    time.sleep(2)

    # 3. 웹
    print("[3] 웹 시작")
    print("=" * 60)
    print("  http://localhost:8080 접속하세요!")
    print("=" * 60)
    run_web_server(port=8080, oht_port=9000)
