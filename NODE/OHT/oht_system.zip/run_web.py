#!/usr/bin/env python
"""
run_web.py
OHT 웹 모니터링 UI 실행

사용법:
    python run_web.py
    python run_web.py --port 8080 --oht-port 9000
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from web.app import run_web_server

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="OHT Web Monitor - 실시간 차량 위치 모니터링",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
예시:
  python run_web.py                              # 기본 (http://localhost:8080)
  python run_web.py --port 3000                  # 포트 변경
  python run_web.py --oht-host 192.168.1.100     # 다른 OHT 서버에 연결

브라우저에서 http://localhost:8080 접속
        """
    )
    parser.add_argument("--host", default="0.0.0.0",
                        help="웹 서버 IP (기본: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=8080,
                        help="웹 서버 포트 (기본: 8080)")
    parser.add_argument("--oht-host", default="127.0.0.1",
                        help="OHT 서버 IP (기본: 127.0.0.1)")
    parser.add_argument("--oht-port", type=int, default=9000,
                        help="OHT 서버 TCP 포트 (기본: 9000)")

    args = parser.parse_args()

    print("\n" + "=" * 60)
    print("  OHT Web Monitor 시작")
    print("=" * 60)
    print(f"  웹 서버: http://localhost:{args.port}")
    print(f"  OHT 서버: {args.oht_host}:{args.oht_port}")
    print("=" * 60)

    try:
        run_web_server(
            host=args.host,
            port=args.port,
            oht_host=args.oht_host,
            oht_port=args.oht_port
        )
    except KeyboardInterrupt:
        print("\n웹 서버 종료")
