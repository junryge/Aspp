"""
server/oht_server.py
OHT 위치 데이터 서버 메인

기능:
- UDP로 MCP에서 Vehicle 상태 수신
- 데이터 파싱 및 저장
- 속도 계산 (5가지 조건 기반)
- TCP로 클라이언트에 데이터 제공
"""
import threading
import time
from datetime import datetime
from typing import Dict, List, Any, Optional
from collections import deque
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from common.models import VhlLocationData, VhlVelocityData, ServerStats
from server.udp_receiver import UdpReceiver
from server.client_handler import ClientHandler


class VehicleDataStore:
    """Vehicle 데이터 저장소"""

    def __init__(self, history_size: int = 100):
        self.history_size = history_size

        # 최신 위치 (vehicle_id → VhlLocationData)
        self.current_locations: Dict[str, VhlLocationData] = {}

        # 이력 (vehicle_id → deque of VhlLocationData)
        self.location_history: Dict[str, deque] = {}

        # 속도 데이터 (vehicle_id → VhlVelocityData)
        self.velocities: Dict[str, VhlVelocityData] = {}

        self.lock = threading.Lock()

        # 통계
        self.velocity_calc_count = 0

    def update_location(self, location: VhlLocationData) -> Optional[VhlVelocityData]:
        """위치 업데이트 및 속도 계산"""
        with self.lock:
            vehicle_id = location.vehicle_id
            prev_location = self.current_locations.get(vehicle_id)

            # 현재 위치 업데이트
            self.current_locations[vehicle_id] = location

            # 이력 추가
            if vehicle_id not in self.location_history:
                self.location_history[vehicle_id] = deque(maxlen=self.history_size)
            self.location_history[vehicle_id].append(location)

            # 속도 계산
            velocity = self._calculate_velocity(prev_location, location)
            if velocity:
                self.velocities[vehicle_id] = velocity
                location.velocity = velocity.velocity
                location.velocity_valid = True
                self.velocity_calc_count += 1

            return velocity

    def _calculate_velocity(self, prev: Optional[VhlLocationData],
                            curr: VhlLocationData) -> Optional[VhlVelocityData]:
        """
        속도 계산 - 5가지 필수 조건 체크

        조건:
        1. 메시지 수신 시간 차이 1분 미만
        2. Vehicle 상태: RUN(1), OBS_STOP(6), JAM(7), E84_TIMEOUT(9) 중 하나
        3. Cycle 일치: 이전과 현재의 run_cycle, vhl_cycle 동일
        4. 실행 Cycle: ACQUIRE(4) 또는 DEPOSIT(3)
        5. Vehicle Cycle: ACQUIRE_MOVING(4) 또는 DEPOSIT_MOVING(2)

        공식: 속도(v) = 거리(Δx) / 시간(Δt) × 60.0 (m/min)
        """
        if prev is None:
            return None

        try:
            # 시간 차이 계산
            prev_time = datetime.fromisoformat(prev.received_time)
            curr_time = datetime.fromisoformat(curr.received_time)
            time_diff = (curr_time - prev_time).total_seconds()
        except:
            return None

        # 조건 1: 시간 차이 1분 미만
        if time_diff >= 60 or time_diff <= 0:
            return None

        # 조건 2: 유효한 Vehicle 상태 (RUN, OBS_STOP, JAM, E84_TIMEOUT)
        valid_states = ["1", "6", "7", "9"]
        if curr.state not in valid_states:
            return None

        # 조건 3: Cycle 일치
        if curr.run_cycle != prev.run_cycle or curr.vhl_cycle != prev.vhl_cycle:
            return None

        # 조건 4: 실행 Cycle (ACQUIRE=4, DEPOSIT=3)
        if curr.run_cycle not in ["3", "4"]:
            return None

        # 조건 5: Vehicle Cycle (ACQUIRE_MOVING=4, DEPOSIT_MOVING=2)
        if curr.vhl_cycle not in ["2", "4"]:
            return None

        # 거리 계산
        if curr.current_address == prev.next_address:
            # 연속된 번지로 이동한 경우
            # 이전 RailEdge 잔여 거리 + 현재 위치까지의 거리
            # 간단 버전: 현재 distance 사용
            distance_mm = curr.distance
            if distance_mm == 0:
                distance_mm = 1000  # 기본값
        elif curr.current_address == prev.current_address:
            # 같은 번지 내에서 이동
            distance_mm = abs(curr.distance - prev.distance)
        else:
            # 다른 번지 - 경로 탐색 필요 (간단화: 번지 차이 * 평균 길이)
            distance_mm = abs(curr.current_address - prev.current_address) * 2000

        if distance_mm <= 0:
            return None

        # 속도 계산: v = d / t * 60 (m/min)
        # d: mm → m (÷1000), t: sec → min (×60)
        velocity_mpm = (distance_mm / 1000) / time_diff * 60

        return VhlVelocityData(
            vehicle_id=curr.vehicle_id,
            velocity=round(velocity_mpm, 2),
            distance=distance_mm,
            time_diff=round(time_diff, 3),
            from_address=prev.current_address,
            to_address=curr.current_address
        )

    def get_all(self) -> List[Dict[str, Any]]:
        """전체 차량 조회"""
        with self.lock:
            return [loc.to_dict() for loc in self.current_locations.values()]

    def get_one(self, vehicle_id: str) -> Optional[Dict[str, Any]]:
        """특정 차량 조회"""
        with self.lock:
            loc = self.current_locations.get(vehicle_id)
            if loc:
                result = loc.to_dict()
                vel = self.velocities.get(vehicle_id)
                if vel:
                    result['velocity_data'] = vel.to_dict()
                return result
            return None

    def get_history(self, vehicle_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        """차량 이력 조회"""
        with self.lock:
            history = self.location_history.get(vehicle_id, deque())
            return [loc.to_dict() for loc in list(history)[-limit:]]

    def get_vehicle_count(self) -> int:
        """차량 수"""
        with self.lock:
            return len(self.current_locations)

    def get_active_count(self, seconds: int = 60) -> int:
        """활성 차량 수 (최근 N초 이내 업데이트)"""
        with self.lock:
            now = datetime.now()
            count = 0
            for loc in self.current_locations.values():
                try:
                    loc_time = datetime.fromisoformat(loc.received_time)
                    if (now - loc_time).total_seconds() < seconds:
                        count += 1
                except:
                    pass
            return count


class OhtServer:
    """OHT 위치 데이터 서버"""

    def __init__(self, udp_port: int = 5000, tcp_port: int = 9000):
        self.udp_port = udp_port
        self.tcp_port = tcp_port

        # 컴포넌트
        self.data_store = VehicleDataStore()
        self.udp_receiver = UdpReceiver(port=udp_port)
        self.client_handler = ClientHandler(port=tcp_port)

        # 통계
        self.start_time: Optional[datetime] = None
        self.message_count = 0
        self.last_stats_time = time.time()
        self.last_stats_count = 0

        self.running = False

    def start(self):
        """서버 시작"""
        self.start_time = datetime.now()
        self.running = True

        print("=" * 60)
        print("  OHT Location Data Server")
        print("=" * 60)
        print(f"  UDP Port (MCP 수신)     : {self.udp_port}")
        print(f"  TCP Port (Client 서비스) : {self.tcp_port}")
        print("=" * 60)

        # 콜백 설정
        self.udp_receiver.set_callback(self._on_udp_message)
        self.client_handler.set_callbacks(
            get_all=self.data_store.get_all,
            get_one=self.data_store.get_one,
            get_stats=self._get_stats,
            get_history=self.data_store.get_history
        )

        # 시작
        self.udp_receiver.start()
        self.client_handler.start()

        print("\n서버 실행 중... (Ctrl+C로 종료)\n")

    def _on_udp_message(self, location: VhlLocationData, addr: tuple):
        """UDP 메시지 수신 콜백"""
        self.message_count += 1

        # 데이터 저장 및 속도 계산
        velocity = self.data_store.update_location(location)

        # 구독 클라이언트에 브로드캐스트
        self.client_handler.broadcast_location(location.to_dict())

        # JAM, ABNORMAL 상태면 알림
        if location.state in ["3", "7"]:
            alert = {
                "type": "state_alert",
                "vehicle_id": location.vehicle_id,
                "state": location.state,
                "state_desc": location.state_desc,
                "address": location.current_address,
                "time": location.received_time
            }
            self.client_handler.broadcast_alert(alert)

    def _get_stats(self) -> Dict[str, Any]:
        """서버 통계 조회"""
        now = time.time()
        elapsed = now - self.last_stats_time
        msg_diff = self.message_count - self.last_stats_count
        mps = msg_diff / elapsed if elapsed > 0 else 0

        self.last_stats_time = now
        self.last_stats_count = self.message_count

        uptime = (datetime.now() - self.start_time).total_seconds() if self.start_time else 0

        return ServerStats(
            total_vehicles=self.data_store.get_vehicle_count(),
            active_vehicles=self.data_store.get_active_count(),
            total_messages=self.message_count,
            messages_per_second=round(mps, 2),
            connected_clients=self.client_handler.get_connected_count(),
            uptime_seconds=round(uptime, 1),
            velocity_calculations=self.data_store.velocity_calc_count,
            last_update=datetime.now().isoformat()
        ).to_dict()

    def run(self):
        """서버 실행 (블로킹)"""
        self.start()

        last_print = time.time()

        try:
            while self.running:
                time.sleep(1)

                # 10초마다 상태 출력
                if time.time() - last_print >= 10:
                    stats = self._get_stats()
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] "
                          f"Vehicles: {stats['total_vehicles']} (active: {stats['active_vehicles']}) | "
                          f"Messages: {stats['total_messages']:,} ({stats['messages_per_second']:.1f}/s) | "
                          f"Clients: {stats['connected_clients']} | "
                          f"Velocity Calcs: {stats['velocity_calculations']}")
                    last_print = time.time()

        except KeyboardInterrupt:
            print("\n\n종료 요청...")
        finally:
            self.stop()

    def stop(self):
        """서버 중지"""
        self.running = False
        self.udp_receiver.stop()
        self.client_handler.stop()

        print("\n" + "=" * 60)
        print("  OHT Server 종료")
        print(f"  총 메시지: {self.message_count:,}")
        print(f"  속도 계산: {self.data_store.velocity_calc_count:,}")
        print("=" * 60)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="OHT Location Data Server")
    parser.add_argument("--udp-port", type=int, default=5000, help="UDP 수신 포트")
    parser.add_argument("--tcp-port", type=int, default=9000, help="TCP 서비스 포트")

    args = parser.parse_args()

    server = OhtServer(
        udp_port=args.udp_port,
        tcp_port=args.tcp_port
    )
    server.run()
