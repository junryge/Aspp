"""
server/client_handler.py
TCP 클라이언트 연결 처리
"""
import socket
import threading
import json
from typing import Dict, Set, Optional, Callable, Any, List
from datetime import datetime
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from common.protocol import Message, MessageType, Protocol


class ClientConnection:
    """개별 클라이언트 연결"""

    def __init__(self, conn: socket.socket, addr: tuple,
                 client_id: str, handler: 'ClientHandler'):
        self.conn = conn
        self.addr = addr
        self.client_id = client_id
        self.handler = handler
        self.running = False
        self.thread: Optional[threading.Thread] = None

        # 구독 설정
        self.subscribed = False
        self.subscribe_filter: Set[str] = set()  # 특정 vehicle만 구독 (비어있으면 전체)

        self.connected_time = datetime.now()
        self.last_activity = datetime.now()
        self.message_count = 0

    def start(self):
        """클라이언트 처리 시작"""
        self.running = True
        self.thread = threading.Thread(target=self._handle_loop, daemon=True)
        self.thread.start()

    def _handle_loop(self):
        """클라이언트 메시지 처리 루프"""
        self.conn.settimeout(1.0)
        buffer = b''

        while self.running:
            try:
                data = self.conn.recv(4096)
                if not data:
                    break

                buffer += data

                # 메시지 파싱 (길이 헤더 기반)
                while len(buffer) >= Protocol.HEADER_SIZE:
                    msg_len = int.from_bytes(buffer[:4], 'big')

                    if len(buffer) < Protocol.HEADER_SIZE + msg_len:
                        break

                    msg_data = buffer[Protocol.HEADER_SIZE:Protocol.HEADER_SIZE + msg_len]
                    buffer = buffer[Protocol.HEADER_SIZE + msg_len:]

                    try:
                        message = Message.decode(msg_data)
                        self.last_activity = datetime.now()
                        self.message_count += 1
                        self._process_message(message)
                    except Exception as e:
                        print(f"[Client {self.client_id}] 메시지 처리 오류: {e}")

            except socket.timeout:
                continue
            except ConnectionResetError:
                break
            except Exception as e:
                if self.running:
                    print(f"[Client {self.client_id}] 연결 오류: {e}")
                break

        self.handler.remove_client(self.client_id)

    def _process_message(self, message: Message):
        """메시지 타입별 처리"""
        msg_type = message.msg_type

        if msg_type == MessageType.REQ_ALL_VEHICLES.value:
            self._handle_all_vehicles(message)

        elif msg_type == MessageType.REQ_VEHICLE.value:
            self._handle_vehicle(message)

        elif msg_type == MessageType.REQ_STATS.value:
            self._handle_stats(message)

        elif msg_type == MessageType.REQ_SUBSCRIBE.value:
            self._handle_subscribe(message)

        elif msg_type == MessageType.REQ_UNSUBSCRIBE.value:
            self._handle_unsubscribe(message)

        elif msg_type == MessageType.REQ_VEHICLE_HISTORY.value:
            self._handle_history(message)

        elif msg_type == MessageType.REQ_PING.value:
            self._handle_ping(message)

        else:
            self.send(Protocol.create_error(
                f"Unknown message type: {msg_type}",
                message.request_id
            ))

    def _handle_all_vehicles(self, message: Message):
        """전체 차량 조회"""
        vehicles = self.handler.get_all_vehicles()
        response = Protocol.create_response(
            MessageType.RES_VEHICLES,
            {"vehicles": vehicles, "count": len(vehicles)},
            message.request_id
        )
        self.send(response)

    def _handle_vehicle(self, message: Message):
        """특정 차량 조회"""
        vehicle_id = message.payload.get("vehicle_id")
        vehicle = self.handler.get_vehicle(vehicle_id)

        if vehicle:
            response = Protocol.create_response(
                MessageType.RES_VEHICLE,
                {"vehicle": vehicle},
                message.request_id
            )
        else:
            response = Protocol.create_error(
                f"Vehicle not found: {vehicle_id}",
                message.request_id
            )
        self.send(response)

    def _handle_stats(self, message: Message):
        """서버 통계 조회"""
        stats = self.handler.get_stats()
        response = Protocol.create_response(
            MessageType.RES_STATS,
            stats,
            message.request_id
        )
        self.send(response)

    def _handle_subscribe(self, message: Message):
        """실시간 구독"""
        self.subscribed = True
        vehicle_ids = message.payload.get("vehicle_ids", [])
        self.subscribe_filter = set(vehicle_ids) if vehicle_ids else set()

        response = Protocol.create_response(
            MessageType.RES_SUCCESS,
            {"subscribed": True, "filter": list(self.subscribe_filter)},
            message.request_id
        )
        self.send(response)
        print(f"[Client {self.client_id}] 구독 시작 - 필터: {self.subscribe_filter or 'ALL'}")

    def _handle_unsubscribe(self, message: Message):
        """구독 해제"""
        self.subscribed = False
        self.subscribe_filter.clear()

        response = Protocol.create_response(
            MessageType.RES_SUCCESS,
            {"subscribed": False},
            message.request_id
        )
        self.send(response)
        print(f"[Client {self.client_id}] 구독 해제")

    def _handle_history(self, message: Message):
        """차량 이력 조회"""
        vehicle_id = message.payload.get("vehicle_id")
        limit = message.payload.get("limit", 100)
        history = self.handler.get_vehicle_history(vehicle_id, limit)

        response = Protocol.create_response(
            MessageType.RES_HISTORY,
            {"vehicle_id": vehicle_id, "history": history, "count": len(history)},
            message.request_id
        )
        self.send(response)

    def _handle_ping(self, message: Message):
        """Ping 응답"""
        response = Protocol.create_response(
            MessageType.RES_PONG,
            {"server_time": datetime.now().isoformat()},
            message.request_id
        )
        self.send(response)

    def send(self, message: Message):
        """메시지 전송"""
        try:
            self.conn.sendall(message.encode())
        except Exception as e:
            print(f"[Client {self.client_id}] 전송 오류: {e}")
            self.running = False

    def push_location(self, location_data: Dict[str, Any]):
        """위치 데이터 푸시 (구독 중인 클라이언트에게)"""
        if not self.subscribed:
            return

        vehicle_id = location_data.get("vehicle_id")

        # 필터 체크 (필터가 비어있으면 전체 수신)
        if self.subscribe_filter and vehicle_id not in self.subscribe_filter:
            return

        message = Protocol.create_push(
            MessageType.PUSH_LOCATION,
            {"location": location_data}
        )
        self.send(message)

    def push_alert(self, alert_data: Dict[str, Any]):
        """알림 푸시"""
        if not self.subscribed:
            return

        message = Protocol.create_push(
            MessageType.PUSH_ALERT,
            alert_data
        )
        self.send(message)

    def stop(self):
        """연결 종료"""
        self.running = False
        try:
            self.conn.close()
        except:
            pass


class ClientHandler:
    """클라이언트 연결 관리자"""

    def __init__(self, host: str = "0.0.0.0", port: int = 9000):
        self.host = host
        self.port = port
        self.server_socket: Optional[socket.socket] = None
        self.running = False
        self.thread: Optional[threading.Thread] = None

        # 클라이언트 관리
        self.clients: Dict[str, ClientConnection] = {}
        self.client_counter = 0
        self.lock = threading.Lock()

        # 데이터 접근 콜백
        self.get_all_vehicles_callback: Optional[Callable] = None
        self.get_vehicle_callback: Optional[Callable] = None
        self.get_stats_callback: Optional[Callable] = None
        self.get_history_callback: Optional[Callable] = None

    def set_callbacks(self, get_all: Callable, get_one: Callable,
                      get_stats: Callable, get_history: Callable):
        """데이터 접근 콜백 설정"""
        self.get_all_vehicles_callback = get_all
        self.get_vehicle_callback = get_one
        self.get_stats_callback = get_stats
        self.get_history_callback = get_history

    def get_all_vehicles(self) -> List[Dict]:
        if self.get_all_vehicles_callback:
            return self.get_all_vehicles_callback()
        return []

    def get_vehicle(self, vehicle_id: str) -> Optional[Dict]:
        if self.get_vehicle_callback:
            return self.get_vehicle_callback(vehicle_id)
        return None

    def get_stats(self) -> Dict:
        if self.get_stats_callback:
            return self.get_stats_callback()
        return {}

    def get_vehicle_history(self, vehicle_id: str, limit: int) -> List[Dict]:
        if self.get_history_callback:
            return self.get_history_callback(vehicle_id, limit)
        return []

    def start(self):
        """클라이언트 수신 시작"""
        self.running = True
        self.thread = threading.Thread(target=self._accept_loop, daemon=True)
        self.thread.start()
        print(f"[Client Handler] TCP 서버 시작 - {self.host}:{self.port}")

    def _accept_loop(self):
        """클라이언트 연결 수락 루프"""
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(10)
            self.server_socket.settimeout(1.0)

            while self.running:
                try:
                    conn, addr = self.server_socket.accept()

                    with self.lock:
                        self.client_counter += 1
                        client_id = f"C{self.client_counter:04d}"

                        client = ClientConnection(conn, addr, client_id, self)
                        self.clients[client_id] = client
                        client.start()

                    print(f"[Client Handler] 클라이언트 연결: {client_id} from {addr}")

                except socket.timeout:
                    continue
                except Exception as e:
                    if self.running:
                        print(f"[Client Handler] 연결 수락 오류: {e}")

        except Exception as e:
            print(f"[Client Handler] 서버 소켓 오류: {e}")

    def remove_client(self, client_id: str):
        """클라이언트 제거"""
        with self.lock:
            if client_id in self.clients:
                del self.clients[client_id]
                print(f"[Client Handler] 클라이언트 연결 해제: {client_id}")

    def broadcast_location(self, location_data: Dict[str, Any]):
        """모든 구독 클라이언트에 위치 데이터 브로드캐스트"""
        with self.lock:
            for client in list(self.clients.values()):
                try:
                    client.push_location(location_data)
                except:
                    pass

    def broadcast_alert(self, alert_data: Dict[str, Any]):
        """모든 구독 클라이언트에 알림 브로드캐스트"""
        with self.lock:
            for client in list(self.clients.values()):
                try:
                    client.push_alert(alert_data)
                except:
                    pass

    def get_connected_count(self) -> int:
        """연결된 클라이언트 수"""
        with self.lock:
            return len(self.clients)

    def stop(self):
        """핸들러 중지"""
        self.running = False

        with self.lock:
            for client in list(self.clients.values()):
                client.stop()
            self.clients.clear()

        if self.server_socket:
            try:
                self.server_socket.close()
            except:
                pass

        if self.thread:
            self.thread.join(timeout=2)

        print("[Client Handler] 중지됨")
