"""
server/udp_receiver.py
MCP UDP 메시지 수신기
"""
import socket
import threading
from typing import Callable, Optional
from datetime import datetime
import sys
import os

# 상위 경로 추가
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from common.models import VhlLocationData, STATE_DESC_MAP, RUN_CYCLE_DESC_MAP, VHL_CYCLE_DESC_MAP


class UdpMessageParser:
    """OHT UDP 메시지 파서"""

    @classmethod
    def parse(cls, message: str) -> Optional[VhlLocationData]:
        """
        UDP 메시지 파싱

        형식: 2,OHT,V00001,1,1,0000,1,4176,20,4177,4,4,CARRIER1234,4011,...
        토큰:
            0: message_id (2)
            1: mcp_name (OHT)
            2: vehicle_id (V00001)
            3: state (1=운전중)
            4: is_loaded (0=비적재, 1=적재)
            5: error_code (0000)
            6: comm_status (1=정상)
            7: current_address (4176)
            8: distance (20, 100mm 단위)
            9: next_address (4177)
            10: run_cycle (4=ACQUIRE)
            11: vhl_cycle (4=ACQUIRE_MOVING)
            12: carrier_id
            13: destination
            14: em_status
            15: group_id
            16: source_port
            17: dest_port
            18: priority
            19: detail_state
            20: run_distance
            21: command_id
            22: bay_name
        """
        try:
            tokens = message.strip().split(',')

            if len(tokens) < 16:
                return None

            # message_id 확인 (Vehicle 상태 보고 = "2")
            if tokens[0] != "2":
                return None

            # 각 필드 파싱
            state = tokens[3] if len(tokens) > 3 else ""
            run_cycle = tokens[10] if len(tokens) > 10 else ""
            vhl_cycle = tokens[11] if len(tokens) > 11 else ""

            return VhlLocationData(
                message_id=tokens[0],
                mcp_name=tokens[1],
                vehicle_id=tokens[2],
                state=state,
                state_desc=STATE_DESC_MAP.get(state, "알수없음"),
                is_loaded=(tokens[4] == "1") if len(tokens) > 4 else False,
                error_code=tokens[5] if len(tokens) > 5 else "0000",
                comm_status=tokens[6] if len(tokens) > 6 else "1",
                current_address=int(tokens[7]) if len(tokens) > 7 and tokens[7] else 0,
                distance=int(tokens[8]) * 100 if len(tokens) > 8 and tokens[8] else 0,  # 100mm → mm
                next_address=int(tokens[9]) if len(tokens) > 9 and tokens[9] else 0,
                run_cycle=run_cycle,
                run_cycle_desc=RUN_CYCLE_DESC_MAP.get(run_cycle, "알수없음"),
                vhl_cycle=vhl_cycle,
                vhl_cycle_desc=VHL_CYCLE_DESC_MAP.get(vhl_cycle, "알수없음"),
                carrier_id=tokens[12] if len(tokens) > 12 else "",
                destination=int(tokens[13]) if len(tokens) > 13 and tokens[13].isdigit() else 0,
                em_status=tokens[14] if len(tokens) > 14 else "",
                group_id=tokens[15] if len(tokens) > 15 else "",
                source_port=tokens[16] if len(tokens) > 16 else "",
                dest_port=tokens[17] if len(tokens) > 17 else "",
                priority=int(tokens[18]) if len(tokens) > 18 and tokens[18].isdigit() else 0,
                detail_state=tokens[19] if len(tokens) > 19 else "",
                run_distance=int(tokens[20]) if len(tokens) > 20 and tokens[20].isdigit() else 0,
                command_id=tokens[21] if len(tokens) > 21 else "",
                bay_name=tokens[22] if len(tokens) > 22 else "",
                received_time=datetime.now().isoformat(),
                raw_message=message,
            )

        except Exception as e:
            print(f"[UDP Parser] 파싱 오류: {e}, 메시지: {message[:50]}...")
            return None


class UdpReceiver:
    """UDP 메시지 수신기"""

    def __init__(self, host: str = "0.0.0.0", port: int = 5000,
                 buffer_size: int = 4096):
        self.host = host
        self.port = port
        self.buffer_size = buffer_size
        self.socket: Optional[socket.socket] = None
        self.running = False
        self.thread: Optional[threading.Thread] = None

        # 콜백
        self.on_message_callback: Optional[Callable] = None

        # 통계
        self.message_count = 0
        self.error_count = 0
        self.last_message_time: Optional[datetime] = None

    def set_callback(self, callback: Callable):
        """메시지 수신 콜백 설정"""
        self.on_message_callback = callback

    def start(self):
        """비동기 수신 시작"""
        self.running = True
        self.thread = threading.Thread(target=self._receive_loop, daemon=True)
        self.thread.start()
        print(f"[UDP Receiver] 시작 - {self.host}:{self.port}")

    def _receive_loop(self):
        """수신 루프"""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.socket.bind((self.host, self.port))
            self.socket.settimeout(1.0)

            while self.running:
                try:
                    data, addr = self.socket.recvfrom(self.buffer_size)
                    message = data.decode('utf-8', errors='ignore')
                    self.message_count += 1
                    self.last_message_time = datetime.now()

                    # 파싱
                    location = UdpMessageParser.parse(message)

                    if location and self.on_message_callback:
                        self.on_message_callback(location, addr)

                except socket.timeout:
                    continue
                except Exception as e:
                    self.error_count += 1
                    if self.running:
                        print(f"[UDP Receiver] 수신 오류: {e}")

        except Exception as e:
            print(f"[UDP Receiver] 소켓 오류: {e}")
        finally:
            if self.socket:
                self.socket.close()

    def stop(self):
        """수신 중지"""
        self.running = False
        if self.socket:
            try:
                self.socket.close()
            except:
                pass
        if self.thread:
            self.thread.join(timeout=2)
        print(f"[UDP Receiver] 중지 (총 수신: {self.message_count}건, 오류: {self.error_count}건)")

    def get_stats(self) -> dict:
        """통계 조회"""
        return {
            "message_count": self.message_count,
            "error_count": self.error_count,
            "last_message_time": self.last_message_time.isoformat() if self.last_message_time else None,
            "running": self.running,
        }
