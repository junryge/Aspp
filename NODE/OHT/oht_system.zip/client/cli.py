"""
client/cli.py
OHT 클라이언트 CLI 인터페이스
"""
import cmd
import json
import time
import threading
from datetime import datetime
from typing import Optional
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from client.oht_client import OhtClient


class OhtCli(cmd.Cmd):
    """OHT 클라이언트 CLI"""

    intro = """
================================================================================
  OHT Client CLI
================================================================================
  명령어:
    connect [host] [port]  - 서버 연결 (기본: 127.0.0.1:9000)
    disconnect             - 서버 연결 해제
    status                 - 연결 상태 확인
    ping                   - 서버 핑

    vehicles               - 전체 차량 목록
    vehicle <id>           - 특정 차량 상세 정보
    history <id> [limit]   - 차량 이력 조회
    stats                  - 서버 통계

    subscribe [id1,id2..]  - 실시간 구독 (비어있으면 전체)
    unsubscribe            - 구독 해제
    monitor                - 실시간 모니터링 모드

    help                   - 도움말
    quit                   - 종료
================================================================================
"""
    prompt = "oht> "

    def __init__(self):
        super().__init__()
        self.client: Optional[OhtClient] = None
        self.monitoring = False

    def do_connect(self, arg):
        """서버 연결: connect [host] [port]"""
        args = arg.split()
        host = args[0] if len(args) > 0 else "127.0.0.1"
        port = int(args[1]) if len(args) > 1 else 9000

        self.client = OhtClient(host, port)
        if self.client.connect():
            print(f"연결 성공: {host}:{port}")
        else:
            print("연결 실패")
            self.client = None

    def do_disconnect(self, arg):
        """서버 연결 해제"""
        if self.client:
            self.client.disconnect()
            self.client = None
            print("연결 해제됨")
        else:
            print("연결되지 않음")

    def do_status(self, arg):
        """연결 상태 확인"""
        if self.client and self.client.connected:
            print(f"연결됨: {self.client.host}:{self.client.port}")
        else:
            print("연결되지 않음")

    def do_ping(self, arg):
        """서버 핑"""
        if not self._check_connection():
            return

        start = time.time()
        if self.client.ping():
            elapsed = (time.time() - start) * 1000
            print(f"PONG ({elapsed:.1f}ms)")
        else:
            print("PING 실패")

    def do_vehicles(self, arg):
        """전체 차량 목록"""
        if not self._check_connection():
            return

        vehicles = self.client.get_all_vehicles()
        print(f"\n총 {len(vehicles)}대 차량:")
        print("-" * 80)
        print(f"{'ID':<10} {'Address':<10} {'Distance':<10} {'State':<15} {'Cycle':<12} {'Loaded'}")
        print("-" * 80)

        for v in vehicles:
            vid = v.get('vehicle_id', '')
            addr = v.get('current_address', 0)
            dist = v.get('distance', 0)
            state = v.get('state_desc', '')[:12]
            cycle = v.get('run_cycle_desc', '')[:10]
            loaded = 'Yes' if v.get('is_loaded') else 'No'

            print(f"{vid:<10} {addr:<10} {dist:<10} {state:<15} {cycle:<12} {loaded}")

        print("-" * 80)

    def do_vehicle(self, arg):
        """특정 차량 상세: vehicle <id>"""
        if not self._check_connection():
            return

        if not arg:
            print("사용법: vehicle <vehicle_id>")
            return

        vehicle = self.client.get_vehicle(arg.strip())
        if vehicle:
            print(f"\n=== Vehicle: {vehicle.get('vehicle_id')} ===")
            print(json.dumps(vehicle, indent=2, ensure_ascii=False))
        else:
            print(f"차량을 찾을 수 없음: {arg}")

    def do_history(self, arg):
        """차량 이력: history <id> [limit]"""
        if not self._check_connection():
            return

        args = arg.split()
        if not args:
            print("사용법: history <vehicle_id> [limit]")
            return

        vehicle_id = args[0]
        limit = int(args[1]) if len(args) > 1 else 10

        history = self.client.get_vehicle_history(vehicle_id, limit)
        print(f"\n{vehicle_id} 이력 ({len(history)}건):")
        print("-" * 70)

        for h in history[-10:]:  # 최근 10건만 표시
            time_str = h.get('received_time', '')[:19]
            addr = h.get('current_address', 0)
            dist = h.get('distance', 0)
            state = h.get('state_desc', '')

            print(f"{time_str} | Addr: {addr:>5} | Dist: {dist:>5}mm | {state}")

        print("-" * 70)

    def do_stats(self, arg):
        """서버 통계"""
        if not self._check_connection():
            return

        stats = self.client.get_stats()
        print("\n=== 서버 통계 ===")
        print(f"  총 차량 수      : {stats.get('total_vehicles', 0)}")
        print(f"  활성 차량 수    : {stats.get('active_vehicles', 0)}")
        print(f"  총 메시지       : {stats.get('total_messages', 0):,}")
        print(f"  메시지/초       : {stats.get('messages_per_second', 0):.1f}")
        print(f"  연결된 클라이언트: {stats.get('connected_clients', 0)}")
        print(f"  속도 계산 횟수  : {stats.get('velocity_calculations', 0):,}")
        print(f"  서버 가동 시간  : {stats.get('uptime_seconds', 0):.0f}초")

    def do_subscribe(self, arg):
        """실시간 구독: subscribe [id1,id2,..]"""
        if not self._check_connection():
            return

        vehicle_ids = [v.strip() for v in arg.split(',')] if arg else None

        def on_location(data):
            vid = data.get('vehicle_id', '')
            addr = data.get('current_address', 0)
            dist = data.get('distance', 0)
            state = data.get('state_desc', '')
            time_str = datetime.now().strftime('%H:%M:%S')
            print(f"\r[{time_str}] {vid}: addr={addr}, dist={dist}mm, state={state}")
            print(self.prompt, end='', flush=True)

        def on_alert(data):
            vid = data.get('vehicle_id', '')
            alert_type = data.get('type', '')
            state = data.get('state_desc', '')
            print(f"\r*** ALERT: {vid} - {alert_type}: {state} ***")
            print(self.prompt, end='', flush=True)

        if self.client.subscribe(vehicle_ids, on_location, on_alert):
            print("구독 시작됨. 데이터 수신 중...")
        else:
            print("구독 실패")

    def do_unsubscribe(self, arg):
        """구독 해제"""
        if not self._check_connection():
            return

        if self.client.unsubscribe():
            print("구독 해제됨")
        else:
            print("구독 해제 실패")

    def do_monitor(self, arg):
        """실시간 모니터링 모드"""
        if not self._check_connection():
            return

        print("실시간 모니터링 시작... (Ctrl+C로 종료)")
        print("-" * 80)

        self.monitoring = True
        update_count = 0

        def on_location(data):
            nonlocal update_count
            update_count += 1

            vid = data.get('vehicle_id', '')
            addr = data.get('current_address', 0)
            dist = data.get('distance', 0)
            state = data.get('state_desc', '')
            velocity = data.get('velocity', 0)
            vel_str = f"{velocity:.1f}m/min" if data.get('velocity_valid') else "N/A"

            print(f"[{update_count:>6}] {vid:<10} | Addr: {addr:>5} | "
                  f"Dist: {dist:>5}mm | {state:<12} | Vel: {vel_str}")

        def on_alert(data):
            vid = data.get('vehicle_id', '')
            state = data.get('state_desc', '')
            print(f"*** ALERT: {vid} - {state} ***")

        self.client.subscribe(None, on_location, on_alert)

        try:
            while self.monitoring:
                time.sleep(0.1)
        except KeyboardInterrupt:
            pass
        finally:
            self.monitoring = False
            self.client.unsubscribe()
            print("\n모니터링 종료")

    def do_quit(self, arg):
        """프로그램 종료"""
        if self.client:
            self.client.disconnect()
        print("종료합니다.")
        return True

    def do_exit(self, arg):
        """프로그램 종료"""
        return self.do_quit(arg)

    def _check_connection(self) -> bool:
        """연결 상태 확인"""
        if not self.client or not self.client.connected:
            print("서버에 연결되지 않음. 'connect' 명령으로 연결하세요.")
            return False
        return True

    def emptyline(self):
        """빈 줄 입력 시 아무것도 하지 않음"""
        pass


def main():
    """CLI 메인"""
    cli = OhtCli()

    # 자동 연결 옵션
    if len(sys.argv) > 1:
        host = sys.argv[1]
        port = int(sys.argv[2]) if len(sys.argv) > 2 else 9000
        cli.do_connect(f"{host} {port}")

    try:
        cli.cmdloop()
    except KeyboardInterrupt:
        print("\n종료합니다.")
        if cli.client:
            cli.client.disconnect()


if __name__ == "__main__":
    main()
