"""
client/oht_client.py
OHT 클라이언트 - TCP로 서버 접속, 데이터 조회/구독

기능:
- 서버 연결/해제
- 전체 차량 조회
- 특정 차량 조회
- 차량 이력 조회
- 서버 통계 조회
- 실시간 위치 구독
"""
import socket
import threading
import json
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from common.protocol import Message, MessageType, Protocol


class OhtClient:
    """OHT 서버 클라이언트"""

    def __init__(self, host: str = "127.0.0.1", port: int = 9000):
        self.host = host
        self.port = port
        self.socket: Optional[socket.socket] = None
        self.connected = False

        # 응답 대기
        self.pending_requests: Dict[str, threading.Event] = {}
        self.responses: Dict[str, Message] = {}
        self.lock = threading.Lock()

        # 수신 스레드
        self.receive_thread: Optional[threading.Thread] = None
        self.running = False

        # 구독 콜백
        self.on_location_callback: Optional[Callable] = None
        self.on_alert_callback: Optional[Callable] = None

    def connect(self) -> bool:
        """서버 연결"""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((self.host, self.port))
            self.socket.settimeout(1.0)
            self.connected = True
            self.running = True

            # 수신 스레드 시작
            self.receive_thread = threading.Thread(target=self._receive_loop, daemon=True)
            self.receive_thread.start()

            print(f"[Client] 서버 연결 성공: {self.host}:{self.port}")
            return True

        except Exception as e:
            print(f"[Client] 연결 실패: {e}")
            return False

    def disconnect(self):
        """서버 연결 해제"""
        self.running = False
        self.connected = False

        if self.socket:
            try:
                self.socket.close()
            except:
                pass

        if self.receive_thread:
            self.receive_thread.join(timeout=2)

        print("[Client] 연결 해제됨")

    def _receive_loop(self):
        """메시지 수신 루프"""
        buffer = b''

        while self.running:
            try:
                data = self.socket.recv(4096)
                if not data:
                    break

                buffer += data

                # 메시지 파싱
                while len(buffer) >= Protocol.HEADER_SIZE:
                    msg_len = int.from_bytes(buffer[:4], 'big')

                    if len(buffer) < Protocol.HEADER_SIZE + msg_len:
                        break

                    msg_data = buffer[Protocol.HEADER_SIZE:Protocol.HEADER_SIZE + msg_len]
                    buffer = buffer[Protocol.HEADER_SIZE + msg_len:]

                    try:
                        message = Message.decode(msg_data)
                        self._handle_message(message)
                    except Exception as e:
                        print(f"[Client] 메시지 파싱 오류: {e}")

            except socket.timeout:
                continue
            except ConnectionResetError:
                print("[Client] 서버 연결 끊김")
                break
            except Exception as e:
                if self.running:
                    print(f"[Client] 수신 오류: {e}")
                break

        self.connected = False

    def _handle_message(self, message: Message):
        """메시지 처리"""
        msg_type = message.msg_type

        # 푸시 메시지 처리
        if msg_type == MessageType.PUSH_LOCATION.value:
            if self.on_location_callback:
                self.on_location_callback(message.payload.get("location", {}))
            return

        if msg_type == MessageType.PUSH_ALERT.value:
            if self.on_alert_callback:
                self.on_alert_callback(message.payload)
            return

        # 응답 메시지 처리
        request_id = message.request_id
        with self.lock:
            if request_id in self.pending_requests:
                self.responses[request_id] = message
                self.pending_requests[request_id].set()

    def _send_request(self, message: Message, timeout: float = 5.0) -> Optional[Message]:
        """요청 전송 및 응답 대기"""
        if not self.connected:
            print("[Client] 서버에 연결되지 않음")
            return None

        request_id = message.request_id
        event = threading.Event()

        with self.lock:
            self.pending_requests[request_id] = event

        try:
            self.socket.sendall(message.encode())

            if event.wait(timeout):
                with self.lock:
                    response = self.responses.pop(request_id, None)
                    del self.pending_requests[request_id]
                return response
            else:
                print(f"[Client] 응답 타임아웃: {request_id}")
                with self.lock:
                    del self.pending_requests[request_id]
                return None

        except Exception as e:
            print(f"[Client] 요청 실패: {e}")
            return None

    # ================================================================
    # API 메서드
    # ================================================================

    def ping(self) -> bool:
        """서버 연결 확인"""
        request = Protocol.create_request(MessageType.REQ_PING)
        response = self._send_request(request)

        if response and response.msg_type == MessageType.RES_PONG.value:
            return True
        return False

    def get_all_vehicles(self) -> List[Dict[str, Any]]:
        """전체 차량 조회"""
        request = Protocol.create_request(MessageType.REQ_ALL_VEHICLES)
        response = self._send_request(request)

        if response and response.msg_type == MessageType.RES_VEHICLES.value:
            return response.payload.get("vehicles", [])
        return []

    def get_vehicle(self, vehicle_id: str) -> Optional[Dict[str, Any]]:
        """특정 차량 조회"""
        request = Protocol.create_request(
            MessageType.REQ_VEHICLE,
            {"vehicle_id": vehicle_id}
        )
        response = self._send_request(request)

        if response and response.msg_type == MessageType.RES_VEHICLE.value:
            return response.payload.get("vehicle")
        return None

    def get_vehicle_history(self, vehicle_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        """차량 이력 조회"""
        request = Protocol.create_request(
            MessageType.REQ_VEHICLE_HISTORY,
            {"vehicle_id": vehicle_id, "limit": limit}
        )
        response = self._send_request(request)

        if response and response.msg_type == MessageType.RES_HISTORY.value:
            return response.payload.get("history", [])
        return []

    def get_stats(self) -> Dict[str, Any]:
        """서버 통계 조회"""
        request = Protocol.create_request(MessageType.REQ_STATS)
        response = self._send_request(request)

        if response and response.msg_type == MessageType.RES_STATS.value:
            return response.payload
        return {}

    def subscribe(self, vehicle_ids: List[str] = None,
                  on_location: Callable = None,
                  on_alert: Callable = None) -> bool:
        """
        실시간 구독

        Args:
            vehicle_ids: 구독할 차량 ID 목록 (None이면 전체)
            on_location: 위치 업데이트 콜백
            on_alert: 알림 콜백

        Returns:
            구독 성공 여부
        """
        self.on_location_callback = on_location
        self.on_alert_callback = on_alert

        request = Protocol.create_request(
            MessageType.REQ_SUBSCRIBE,
            {"vehicle_ids": vehicle_ids or []}
        )
        response = self._send_request(request)

        if response and response.msg_type == MessageType.RES_SUCCESS.value:
            print(f"[Client] 구독 시작 - 필터: {vehicle_ids or 'ALL'}")
            return True
        return False

    def unsubscribe(self) -> bool:
        """구독 해제"""
        request = Protocol.create_request(MessageType.REQ_UNSUBSCRIBE)
        response = self._send_request(request)

        self.on_location_callback = None
        self.on_alert_callback = None

        if response and response.msg_type == MessageType.RES_SUCCESS.value:
            print("[Client] 구독 해제됨")
            return True
        return False


if __name__ == "__main__":
    # 테스트
    client = OhtClient()

    if client.connect():
        # 핑
        print(f"Ping: {client.ping()}")

        # 통계
        stats = client.get_stats()
        print(f"Stats: {json.dumps(stats, indent=2)}")

        # 전체 차량
        vehicles = client.get_all_vehicles()
        print(f"Vehicles: {len(vehicles)}")

        for v in vehicles[:3]:
            print(f"  - {v['vehicle_id']}: addr={v['current_address']}, "
                  f"state={v['state_desc']}")

        client.disconnect()
