#!/usr/bin/env python
"""
run_server.py
OHT 서버 실행 스크립트

사용법:
    python run_server.py
    python run_server.py --udp-port 5000 --tcp-port 9000
"""
import sys
import os

# 경로 설정
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from server.oht_server import OhtServer

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="OHT Location Data Server - UDP 수신 및 TCP 클라이언트 서비스",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
예시:
  python run_server.py                              # 기본 포트 (UDP:5000, TCP:9000)
  python run_server.py --udp-port 5001              # UDP 포트 변경
  python run_server.py --tcp-port 9001              # TCP 포트 변경

기능:
  - UDP로 MCP에서 Vehicle 상태 메시지 수신
  - 위치 데이터 파싱 및 저장
  - 속도 계산 (5가지 조건 기반)
  - TCP로 클라이언트에 데이터 제공 (조회/구독)
        """
    )
    parser.add_argument("--udp-port", type=int, default=5000,
                        help="UDP 수신 포트 (기본: 5000)")
    parser.add_argument("--tcp-port", type=int, default=9000,
                        help="TCP 서비스 포트 (기본: 9000)")

    args = parser.parse_args()

    print("\n" + "=" * 60)
    print("  OHT Server 시작")
    print("=" * 60)

    server = OhtServer(
        udp_port=args.udp_port,
        tcp_port=args.tcp_port
    )

    try:
        server.run()
    except KeyboardInterrupt:
        print("\n사용자 종료")
    finally:
        server.stop()
