#!/usr/bin/env python
"""
run_simulator.py
MCP 시뮬레이터 실행 스크립트

사용법:
    python run_simulator.py
    python run_simulator.py --vehicles 20 --interval 0.3
    python run_simulator.py --host 192.168.1.100 --port 5000
"""
import sys
import os

# 경로 설정
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from simulator.mcp_simulator import McpSimulator

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="MCP Simulator - 가짜 OHT 데이터 생성 및 UDP 송신",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
예시:
  python run_simulator.py                           # 기본 설정 (10대, 0.5초 간격)
  python run_simulator.py --vehicles 20             # 20대 차량
  python run_simulator.py --interval 0.3            # 0.3초 간격으로 송신
  python run_simulator.py --fab M14A                # M14A FAB 시뮬레이션
        """
    )
    parser.add_argument("--host", default="127.0.0.1",
                        help="서버 IP 주소 (기본: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=5000,
                        help="서버 UDP 포트 (기본: 5000)")
    parser.add_argument("--vehicles", type=int, default=10,
                        help="시뮬레이션할 Vehicle 수 (기본: 10)")
    parser.add_argument("--interval", type=float, default=0.5,
                        help="메시지 송신 주기 (초, 기본: 0.5)")
    parser.add_argument("--fab", default="M11A",
                        choices=["M11A", "M14A", "M16A"],
                        help="FAB ID (기본: M11A)")

    args = parser.parse_args()

    print("\n" + "=" * 60)
    print("  MCP Simulator 시작")
    print("=" * 60)

    simulator = McpSimulator(
        server_host=args.host,
        server_port=args.port,
        vehicle_count=args.vehicles,
        interval=args.interval,
        fab_id=args.fab
    )

    try:
        simulator.start()
    except KeyboardInterrupt:
        print("\n사용자 종료")
    finally:
        simulator.stop()
