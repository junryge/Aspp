#!/usr/bin/env python
"""
run_client.py
OHT 클라이언트 실행 스크립트

사용법:
    python run_client.py                    # CLI 모드
    python run_client.py 127.0.0.1 9000     # 자동 연결 후 CLI
    python run_client.py --monitor          # 모니터링 모드
"""
import sys
import os

# 경로 설정
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from client.cli import OhtCli
from client.oht_client import OhtClient

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="OHT Client - 서버 접속 및 데이터 조회/모니터링",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
예시:
  python run_client.py                              # CLI 모드 (수동 연결)
  python run_client.py --host 127.0.0.1             # 자동 연결 후 CLI
  python run_client.py --monitor                    # 실시간 모니터링

CLI 명령어:
  connect [host] [port]  - 서버 연결
  vehicles               - 전체 차량 목록
  vehicle <id>           - 특정 차량 정보
  stats                  - 서버 통계
  subscribe              - 실시간 구독
  monitor                - 모니터링 모드
  quit                   - 종료
        """
    )
    parser.add_argument("--host", default="127.0.0.1",
                        help="서버 IP 주소 (기본: 127.0.0.1)")
    parser.add_argument("--port", type=int, default=9000,
                        help="서버 TCP 포트 (기본: 9000)")
    parser.add_argument("--monitor", action="store_true",
                        help="실시간 모니터링 모드로 시작")
    parser.add_argument("--auto-connect", action="store_true",
                        help="자동으로 서버에 연결")

    args = parser.parse_args()

    if args.monitor:
        # 모니터링 모드
        print("\n" + "=" * 60)
        print("  OHT Monitor 시작")
        print("=" * 60)

        client = OhtClient(args.host, args.port)

        if client.connect():
            print("서버 연결 성공")
            print("실시간 모니터링 시작... (Ctrl+C로 종료)")
            print("-" * 60)

            update_count = 0

            def on_location(data):
                global update_count
                update_count += 1
                vid = data.get('vehicle_id', '')
                addr = data.get('current_address', 0)
                dist = data.get('distance', 0)
                state = data.get('state_desc', '')
                velocity = data.get('velocity', 0)
                vel_str = f"{velocity:.1f}m/min" if data.get('velocity_valid') else "N/A"

                print(f"[{update_count:>6}] {vid:<10} | Addr: {addr:>5} | "
                      f"Dist: {dist:>5}mm | {state:<12} | Vel: {vel_str}")

            def on_alert(data):
                vid = data.get('vehicle_id', '')
                state = data.get('state_desc', '')
                print(f"*** ALERT: {vid} - {state} ***")

            client.subscribe(None, on_location, on_alert)

            try:
                import time
                while True:
                    time.sleep(0.1)
            except KeyboardInterrupt:
                pass
            finally:
                client.disconnect()
                print(f"\n모니터링 종료 (총 {update_count}건 수신)")
        else:
            print("서버 연결 실패")
            sys.exit(1)

    else:
        # CLI 모드
        cli = OhtCli()

        # 자동 연결 옵션
        if args.auto_connect:
            cli.do_connect(f"{args.host} {args.port}")

        try:
            cli.cmdloop()
        except KeyboardInterrupt:
            print("\n종료합니다.")
            if cli.client:
                cli.client.disconnect()
