"""
UDP 통신 모듈 - 사용자 데이터그램 프로토콜 (송수신)
====================================================
기능:
  - UDP 서버 (수신 리스너)
  - UDP 클라이언트 (데이터 송신)
  - 브로드캐스트 전송
  - 멀티캐스트 지원
  - 메시지 로깅
"""

import socket
import threading
import json
import logging
from datetime import datetime
from collections import deque

logger = logging.getLogger(__name__)


class UDPServer:
    """UDP 수신 서버"""

    def __init__(self, host="127.0.0.1", port=5005, buffer_size=4096):
        self.host = host
        self.port = port
        self.buffer_size = buffer_size
        self.sock = None
        self.running = False
        self.thread = None
        self.message_log = deque(maxlen=1000)  # 최근 1000개 메시지 보관
        self.callbacks = []  # 메시지 수신 콜백

    def add_callback(self, callback):
        """메시지 수신 시 호출될 콜백 등록"""
        self.callbacks.append(callback)

    def start(self):
        """UDP 서버 시작"""
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.bind((self.host, self.port))
            self.sock.settimeout(1.0)  # 종료 체크를 위한 타임아웃
            self.running = True
            self.thread = threading.Thread(target=self._listen, daemon=True)
            self.thread.start()
            logger.info(f"UDP 서버 시작: {self.host}:{self.port}")
            return {"status": "running", "host": self.host, "port": self.port}
        except Exception as e:
            logger.error(f"UDP 서버 시작 실패: {e}")
            return {"status": "error", "message": str(e)}

    def _listen(self):
        """수신 루프"""
        while self.running:
            try:
                data, addr = self.sock.recvfrom(self.buffer_size)
                msg = {
                    "data": data.decode("utf-8", errors="replace"),
                    "from_ip": addr[0],
                    "from_port": addr[1],
                    "timestamp": datetime.now().isoformat(),
                    "size": len(data),
                }

                # JSON 파싱 시도
                try:
                    msg["parsed"] = json.loads(data.decode("utf-8"))
                except (json.JSONDecodeError, UnicodeDecodeError):
                    msg["parsed"] = None

                self.message_log.append(msg)
                logger.debug(f"UDP 수신 [{addr[0]}:{addr[1]}]: {len(data)} bytes")

                for cb in self.callbacks:
                    try:
                        cb(msg)
                    except Exception as cb_err:
                        logger.error(f"콜백 오류: {cb_err}")

            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    logger.error(f"UDP 수신 오류: {e}")

    def stop(self):
        """서버 중지"""
        self.running = False
        if self.sock:
            self.sock.close()
        logger.info("UDP 서버 중지됨")
        return {"status": "stopped"}

    def get_messages(self, count=50):
        """최근 수신 메시지 조회"""
        messages = list(self.message_log)[-count:]
        return {"status": "ok", "messages": messages, "total": len(self.message_log)}

    def clear_messages(self):
        """메시지 로그 초기화"""
        self.message_log.clear()
        return {"status": "cleared"}

    def get_status(self):
        """서버 상태"""
        return {
            "running": self.running,
            "host": self.host,
            "port": self.port,
            "messages_received": len(self.message_log),
        }


class UDPClient:
    """UDP 송신 클라이언트"""

    def __init__(self, buffer_size=4096):
        self.buffer_size = buffer_size
        self.send_log = deque(maxlen=500)

    def send(self, host, port, data, encoding="utf-8"):
        """데이터 전송"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            if isinstance(data, str):
                data = data.encode(encoding)
            elif isinstance(data, dict):
                data = json.dumps(data).encode(encoding)

            sock.sendto(data, (host, port))
            sock.close()

            log_entry = {
                "to_ip": host,
                "to_port": port,
                "size": len(data),
                "timestamp": datetime.now().isoformat(),
            }
            self.send_log.append(log_entry)
            logger.info(f"UDP 전송 [{host}:{port}]: {len(data)} bytes")

            return {"status": "sent", **log_entry}
        except Exception as e:
            logger.error(f"UDP 전송 실패: {e}")
            return {"status": "error", "message": str(e)}

    def broadcast(self, port, data, encoding="utf-8"):
        """브로드캐스트 전송"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            if isinstance(data, str):
                data = data.encode(encoding)
            elif isinstance(data, dict):
                data = json.dumps(data).encode(encoding)

            sock.sendto(data, ("<broadcast>", port))
            sock.close()
            logger.info(f"UDP 브로드캐스트 [{port}]: {len(data)} bytes")
            return {"status": "broadcast_sent", "port": port, "size": len(data)}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def send_multicast(self, group, port, data, ttl=2):
        """멀티캐스트 전송"""
        try:
            import struct
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, struct.pack("b", ttl))

            if isinstance(data, str):
                data = data.encode("utf-8")
            elif isinstance(data, dict):
                data = json.dumps(data).encode("utf-8")

            sock.sendto(data, (group, port))
            sock.close()
            return {"status": "multicast_sent", "group": group, "port": port, "size": len(data)}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def get_send_log(self, count=50):
        """전송 로그 조회"""
        return {"status": "ok", "log": list(self.send_log)[-count:]}


class TCPServer:
    """TCP 서버 (보너스 - 연결 지향 통신)"""

    def __init__(self, host="127.0.0.1", port=9000):
        self.host = host
        self.port = port
        self.sock = None
        self.running = False
        self.clients = []
        self.message_log = deque(maxlen=1000)

    def start(self):
        """TCP 서버 시작"""
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.sock.bind((self.host, self.port))
            self.sock.listen(5)
            self.sock.settimeout(1.0)
            self.running = True

            thread = threading.Thread(target=self._accept_loop, daemon=True)
            thread.start()
            logger.info(f"TCP 서버 시작: {self.host}:{self.port}")
            return {"status": "running", "host": self.host, "port": self.port}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def _accept_loop(self):
        while self.running:
            try:
                client, addr = self.sock.accept()
                self.clients.append({"socket": client, "address": addr})
                t = threading.Thread(target=self._handle_client, args=(client, addr), daemon=True)
                t.start()
            except socket.timeout:
                continue
            except Exception:
                if self.running:
                    break

    def _handle_client(self, client, addr):
        try:
            while self.running:
                data = client.recv(4096)
                if not data:
                    break
                msg = {
                    "data": data.decode("utf-8", errors="replace"),
                    "from": f"{addr[0]}:{addr[1]}",
                    "timestamp": datetime.now().isoformat(),
                }
                self.message_log.append(msg)
        except Exception:
            pass
        finally:
            client.close()

    def stop(self):
        self.running = False
        for c in self.clients:
            try:
                c["socket"].close()
            except Exception:
                pass
        if self.sock:
            self.sock.close()
        return {"status": "stopped"}

    def get_status(self):
        return {
            "running": self.running,
            "host": self.host,
            "port": self.port,
            "connected_clients": len(self.clients),
            "messages_received": len(self.message_log),
        }
