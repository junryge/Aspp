"""
MongoDB 데모/Mock 모듈 - MongoDB 없이도 대시보드가 동작
========================================================
MongoDB가 설치되지 않은 환경에서 사용.
인메모리 딕셔너리로 MongoDB와 동일한 인터페이스를 제공.
"""

import logging
import json
import uuid
import copy
from datetime import datetime
from collections import defaultdict

logger = logging.getLogger(__name__)


class MongoMockHandler:
    """MongoDB Mock 핸들러 - 인메모리 데이터 저장"""

    def __init__(self, uri="mock://localhost:27017", db_name="comm_hub_demo"):
        self.uri = uri
        self.db_name = db_name
        self.connected = False
        self.databases = {}
        self.start_time = None
        self._init_demo_data()

    def _gen_id(self):
        return str(uuid.uuid4().hex[:24])

    def _get_db(self, db_name=None):
        name = db_name or self.db_name
        if name not in self.databases:
            self.databases[name] = {}
        return self.databases[name]

    def _get_col(self, collection_name, db_name=None):
        db = self._get_db(db_name)
        if collection_name not in db:
            db[collection_name] = []
        return db[collection_name]

    def _init_demo_data(self):
        """데모 데이터 초기화"""
        db = self._get_db()

        # 서버 로그 데모 데이터
        db["server_logs"] = [
            {"_id": self._gen_id(), "level": "INFO", "message": "서버 시작됨",
             "host": "web-01", "timestamp": "2026-02-13T09:00:00", "_created_at": datetime.now().isoformat()},
            {"_id": self._gen_id(), "level": "WARNING", "message": "메모리 사용률 80% 초과",
             "host": "web-02", "timestamp": "2026-02-13T09:15:00", "_created_at": datetime.now().isoformat()},
            {"_id": self._gen_id(), "level": "ERROR", "message": "DB 연결 타임아웃",
             "host": "api-01", "timestamp": "2026-02-13T09:30:00", "_created_at": datetime.now().isoformat()},
            {"_id": self._gen_id(), "level": "INFO", "message": "배치 작업 완료 (1,234건)",
             "host": "batch-01", "timestamp": "2026-02-13T10:00:00", "_created_at": datetime.now().isoformat()},
            {"_id": self._gen_id(), "level": "INFO", "message": "FTP 파일 전송 완료",
             "host": "ftp-01", "timestamp": "2026-02-13T10:15:00", "_created_at": datetime.now().isoformat()},
        ]

        # 네트워크 트래픽 데모 데이터
        db["network_traffic"] = [
            {"_id": self._gen_id(), "protocol": "HTTP", "src": "192.168.1.10", "dst": "10.0.0.5",
             "port": 80, "bytes": 15234, "packets": 42, "timestamp": "2026-02-13T09:00:00"},
            {"_id": self._gen_id(), "protocol": "FTP", "src": "192.168.1.20", "dst": "10.0.0.5",
             "port": 2121, "bytes": 1048576, "packets": 780, "timestamp": "2026-02-13T09:05:00"},
            {"_id": self._gen_id(), "protocol": "UDP", "src": "192.168.1.30", "dst": "10.0.0.10",
             "port": 5005, "bytes": 512, "packets": 4, "timestamp": "2026-02-13T09:10:00"},
            {"_id": self._gen_id(), "protocol": "TCP", "src": "192.168.1.40", "dst": "10.0.0.15",
             "port": 9000, "bytes": 8192, "packets": 16, "timestamp": "2026-02-13T09:15:00"},
            {"_id": self._gen_id(), "protocol": "MongoDB", "src": "192.168.1.50", "dst": "10.0.0.20",
             "port": 27017, "bytes": 32768, "packets": 128, "timestamp": "2026-02-13T09:20:00"},
        ]

        # 사용자 데모 데이터
        db["users"] = [
            {"_id": self._gen_id(), "name": "관리자", "email": "admin@manimohub.local",
             "role": "admin", "last_login": "2026-02-13T08:30:00", "_created_at": datetime.now().isoformat()},
            {"_id": self._gen_id(), "name": "운영자", "email": "operator@manimohub.local",
             "role": "operator", "last_login": "2026-02-13T07:45:00", "_created_at": datetime.now().isoformat()},
            {"_id": self._gen_id(), "name": "모니터", "email": "monitor@manimohub.local",
             "role": "viewer", "last_login": "2026-02-12T22:00:00", "_created_at": datetime.now().isoformat()},
        ]

        # 프로토콜 설정 데모 데이터
        db["protocol_config"] = [
            {"_id": self._gen_id(), "protocol": "FTP", "host": "127.0.0.1", "port": 2121,
             "enabled": True, "max_connections": 50},
            {"_id": self._gen_id(), "protocol": "UDP", "host": "127.0.0.1", "port": 5005,
             "enabled": True, "buffer_size": 4096},
            {"_id": self._gen_id(), "protocol": "TCP", "host": "127.0.0.1", "port": 9000,
             "enabled": True, "max_connections": 100},
            {"_id": self._gen_id(), "protocol": "MongoDB", "host": "localhost", "port": 27017,
             "enabled": False, "note": "데모 모드"},
            {"_id": self._gen_id(), "protocol": "Logpresso", "host": "logpresso.local", "port": 443,
             "enabled": False, "api_key": ""},
        ]

        # 알림 데모 데이터
        db["alerts"] = [
            {"_id": self._gen_id(), "type": "warning", "title": "디스크 사용률 경고",
             "message": "디스크 사용률이 85%를 초과했습니다", "resolved": False,
             "timestamp": "2026-02-13T08:00:00"},
            {"_id": self._gen_id(), "type": "error", "title": "FTP 연결 실패",
             "message": "FTP 서버 연결 3회 실패", "resolved": True,
             "timestamp": "2026-02-13T07:30:00"},
            {"_id": self._gen_id(), "type": "info", "title": "백업 완료",
             "message": "일일 백업이 정상 완료되었습니다", "resolved": True,
             "timestamp": "2026-02-13T06:00:00"},
        ]

        logger.info(f"데모 데이터 초기화 완료: {len(db)}개 컬렉션")

    # ── 연결 관리 ────────────────────────────────────
    def connect(self):
        self.connected = True
        self.start_time = datetime.now()
        logger.info("MongoDB Mock 연결 (데모 모드)")
        return {"status": "connected", "db": self.db_name, "mode": "demo"}

    def disconnect(self):
        self.connected = False
        return {"status": "disconnected"}

    def health_check(self):
        if not self.connected:
            return {"status": "disconnected", "mode": "demo"}
        uptime = (datetime.now() - self.start_time).total_seconds() if self.start_time else 0
        return {
            "status": "healthy",
            "version": "7.0.0-mock",
            "uptime": uptime,
            "connections": {"current": 1, "available": 999},
            "mode": "demo",
        }

    # ── 데이터베이스/컬렉션 메타데이터 ──────────────────
    def list_databases(self):
        dbs = []
        for name, collections in self.databases.items():
            total_size = sum(len(json.dumps(docs)) for docs in collections.values())
            dbs.append({
                "name": name,
                "sizeOnDisk": total_size,
                "empty": len(collections) == 0,
            })
        return {"status": "ok", "databases": dbs}

    def list_collections(self, db_name=None):
        db = self._get_db(db_name)
        collections = []
        for name, docs in db.items():
            size = len(json.dumps(docs))
            collections.append({
                "name": name,
                "count": len(docs),
                "size": size,
                "avgObjSize": size // max(len(docs), 1),
                "storageSize": size,
                "indexes": 1,  # _id 인덱스
            })
        return {"status": "ok", "collections": collections, "db": db_name or self.db_name}

    def get_db_stats(self, db_name=None):
        db = self._get_db(db_name)
        total_docs = sum(len(docs) for docs in db.values())
        total_size = sum(len(json.dumps(docs)) for docs in db.values())
        return {
            "status": "ok",
            "stats": {
                "db": db_name or self.db_name,
                "collections": len(db),
                "objects": total_docs,
                "dataSize": total_size,
                "storageSize": total_size,
                "indexes": len(db),
                "indexSize": len(db) * 100,
            }
        }

    def get_server_status(self):
        uptime = (datetime.now() - self.start_time).total_seconds() if self.start_time else 0
        return {
            "status": "ok",
            "host": "localhost:27017 (mock)",
            "version": "7.0.0-mock",
            "uptime": uptime,
            "connections": {"current": 1, "available": 999, "totalCreated": 5},
            "opcounters": {"insert": 0, "query": 0, "update": 0, "delete": 0},
            "mem": {"resident": 128, "virtual": 256},
            "network": {"bytesIn": 0, "bytesOut": 0, "numRequests": 0},
        }

    # ── CRUD 작업 ──────────────────────────────────────
    def insert_one(self, collection_name, document):
        col = self._get_col(collection_name)
        doc = copy.deepcopy(document)
        doc["_id"] = doc.get("_id", self._gen_id())
        doc["_created_at"] = datetime.now().isoformat()
        col.append(doc)
        logger.info(f"Mock 삽입: {collection_name} / {doc['_id']}")
        return {"status": "inserted", "id": doc["_id"], "collection": collection_name}

    def insert_many(self, collection_name, documents):
        col = self._get_col(collection_name)
        ids = []
        for document in documents:
            doc = copy.deepcopy(document)
            doc["_id"] = doc.get("_id", self._gen_id())
            doc["_created_at"] = datetime.now().isoformat()
            col.append(doc)
            ids.append(doc["_id"])
        return {"status": "inserted", "count": len(ids), "ids": ids}

    def find(self, collection_name, query=None, projection=None,
             sort=None, limit=100, skip=0):
        col = self._get_col(collection_name)
        query = query or {}

        # 간단한 쿼리 매칭
        results = []
        for doc in col:
            if self._match(doc, query):
                results.append(copy.deepcopy(doc))

        total = len(results)
        results = results[skip:skip + limit]

        # OID 형식으로 변환
        for doc in results:
            if isinstance(doc.get("_id"), str):
                doc["_id"] = {"$oid": doc["_id"]}

        return {
            "status": "ok",
            "documents": results,
            "count": len(results),
            "total": total,
        }

    def find_one(self, collection_name, query):
        col = self._get_col(collection_name)
        for doc in col:
            if self._match(doc, query):
                d = copy.deepcopy(doc)
                if isinstance(d.get("_id"), str):
                    d["_id"] = {"$oid": d["_id"]}
                return {"status": "ok", "document": d}
        return {"status": "ok", "document": None}

    def update_one(self, collection_name, query, update_data, upsert=False):
        col = self._get_col(collection_name)
        for doc in col:
            if self._match(doc, query):
                doc.update(update_data)
                doc["_updated_at"] = datetime.now().isoformat()
                return {"status": "updated", "matched": 1, "modified": 1, "upserted_id": None}

        if upsert:
            new_doc = {**query, **update_data, "_id": self._gen_id(), "_created_at": datetime.now().isoformat()}
            col.append(new_doc)
            return {"status": "updated", "matched": 0, "modified": 0, "upserted_id": new_doc["_id"]}

        return {"status": "updated", "matched": 0, "modified": 0, "upserted_id": None}

    def update_many(self, collection_name, query, update_data):
        col = self._get_col(collection_name)
        matched = 0
        for doc in col:
            if self._match(doc, query):
                doc.update(update_data)
                doc["_updated_at"] = datetime.now().isoformat()
                matched += 1
        return {"status": "updated", "matched": matched, "modified": matched}

    def delete_one(self, collection_name, query):
        col = self._get_col(collection_name)
        for i, doc in enumerate(col):
            if self._match(doc, query):
                col.pop(i)
                return {"status": "deleted", "count": 1}
        return {"status": "deleted", "count": 0}

    def delete_many(self, collection_name, query):
        col = self._get_col(collection_name)
        original = len(col)
        self._get_db()[collection_name] = [d for d in col if not self._match(d, query)]
        deleted = original - len(self._get_db()[collection_name])
        return {"status": "deleted", "count": deleted}

    # ── 집계(Aggregation) ──────────────────────────────
    def aggregate(self, collection_name, pipeline):
        """간단한 집계 지원 ($match, $group, $sort, $limit)"""
        col = self._get_col(collection_name)
        results = [copy.deepcopy(d) for d in col]

        for stage in pipeline:
            if "$match" in stage:
                results = [d for d in results if self._match(d, stage["$match"])]
            elif "$limit" in stage:
                results = results[:stage["$limit"]]
            elif "$sort" in stage:
                for key, direction in reversed(list(stage["$sort"].items())):
                    results.sort(key=lambda x: x.get(key, ""), reverse=(direction == -1))
            elif "$group" in stage:
                grouped = defaultdict(list)
                group_key = stage["$group"].get("_id")
                for doc in results:
                    key_val = doc.get(group_key.lstrip("$")) if isinstance(group_key, str) else "all"
                    grouped[key_val].append(doc)
                results = [{"_id": k, "count": len(v)} for k, v in grouped.items()]

        return {"status": "ok", "results": results, "count": len(results)}

    # ── 인덱스 관리 ─────────────────────────────────────
    def list_indexes(self, collection_name):
        return {"status": "ok", "indexes": [
            {"name": "_id_", "key": {"_id": 1}, "unique": True},
        ]}

    def create_index(self, collection_name, keys, **kwargs):
        name = kwargs.get("name", f"idx_{'_'.join(str(k) for k in keys)}")
        return {"status": "created", "index_name": name}

    def drop_index(self, collection_name, index_name):
        return {"status": "dropped", "index": index_name}

    # ── 컬렉션 관리 ─────────────────────────────────────
    def create_collection(self, name, **kwargs):
        db = self._get_db()
        if name in db:
            return {"status": "error", "message": f"Collection '{name}' already exists"}
        db[name] = []
        return {"status": "created", "collection": name}

    def drop_collection(self, name):
        db = self._get_db()
        if name in db:
            del db[name]
            return {"status": "dropped", "collection": name}
        return {"status": "error", "message": f"Collection '{name}' not found"}

    def get_collection_stats(self, collection_name):
        col = self._get_col(collection_name)
        size = len(json.dumps(col))
        return {
            "status": "ok",
            "stats": {
                "ns": f"{self.db_name}.{collection_name}",
                "count": len(col),
                "size": size,
                "avgObjSize": size // max(len(col), 1),
                "storageSize": size,
                "nindexes": 1,
            }
        }

    # ── 매칭 헬퍼 ──────────────────────────────────────
    def _match(self, doc, query):
        """문서가 쿼리 조건에 맞는지 확인"""
        if not query:
            return True
        for key, value in query.items():
            if key == "_id":
                # OID 형식 처리
                doc_id = doc.get("_id")
                if isinstance(doc_id, dict):
                    doc_id = doc_id.get("$oid", doc_id)
                if isinstance(value, dict):
                    value = value.get("$oid", value)
                if str(doc_id) != str(value):
                    return False
            elif key.startswith("$"):
                continue  # 연산자는 스킵
            else:
                if doc.get(key) != value:
                    return False
        return True
