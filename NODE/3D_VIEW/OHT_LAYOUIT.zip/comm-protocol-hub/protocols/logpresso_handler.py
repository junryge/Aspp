"""
로그프레소 API 연동 모듈
========================
기능:
  - 세션 로그인/로그아웃
  - 쿼리 실행 (Logpresso Query Language)
  - 테이블 관리 (목록, 생성, 삭제)
  - 인덱스 관리
  - 스트림 쿼리
  - 대시보드/프리셋 조회
  - 로그 데이터 전송
  - 시스템 상태 확인

참고: https://docs.logpresso.com/ko/sonar/4.0/ui/section-dashboard
"""

import requests
import json
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class LogpressoClient:
    """로그프레소 REST API 클라이언트"""

    def __init__(self, host, login_id="admin", login_pw="", api_key=None):
        self.host = host.rstrip("/")
        self.login_id = login_id
        self.login_pw = login_pw
        self.api_key = api_key
        self.session_id = None
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})

    def _url(self, path):
        return f"{self.host}/api{path}"

    def _headers(self):
        h = {"Content-Type": "application/json"}
        if self.session_id:
            h["Authorization"] = f"Bearer {self.session_id}"
        if self.api_key:
            h["X-API-Key"] = self.api_key
        return h

    # ── 인증 ──────────────────────────────────────────
    def login(self):
        """로그프레소 서버 로그인"""
        try:
            resp = self.session.post(
                self._url("/sessions"),
                json={"loginName": self.login_id, "password": self.login_pw},
                headers={"Content-Type": "application/json"},
                timeout=10,
            )
            if resp.status_code == 200:
                data = resp.json()
                self.session_id = data.get("sessionId") or data.get("session_id")
                logger.info("로그프레소 로그인 성공")
                return {"status": "ok", "session_id": self.session_id}
            return {"status": "error", "code": resp.status_code, "body": resp.text}
        except Exception as e:
            logger.error(f"로그프레소 로그인 실패: {e}")
            return {"status": "error", "message": str(e)}

    def logout(self):
        """세션 로그아웃"""
        try:
            if self.session_id:
                resp = self.session.delete(
                    self._url(f"/sessions/{self.session_id}"),
                    headers=self._headers(),
                    timeout=10,
                )
                self.session_id = None
                return {"status": "logged_out", "code": resp.status_code}
            return {"status": "not_logged_in"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── 쿼리 실행 ────────────────────────────────────
    def execute_query(self, query_string, limit=1000):
        """로그프레소 쿼리 실행 (LQL)"""
        try:
            resp = self.session.post(
                self._url("/query/queries"),
                json={"queryString": query_string, "limit": limit},
                headers=self._headers(),
                timeout=30,
            )
            if resp.status_code == 200:
                return {"status": "ok", "result": resp.json()}
            return {"status": "error", "code": resp.status_code, "body": resp.text}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def get_query_result(self, query_id):
        """쿼리 결과 조회"""
        try:
            resp = self.session.get(
                self._url(f"/query/queries/{query_id}/result"),
                headers=self._headers(),
                timeout=30,
            )
            if resp.status_code == 200:
                return {"status": "ok", "result": resp.json()}
            return {"status": "error", "code": resp.status_code}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def cancel_query(self, query_id):
        """쿼리 취소"""
        try:
            resp = self.session.delete(
                self._url(f"/query/queries/{query_id}"),
                headers=self._headers(),
                timeout=10,
            )
            return {"status": "cancelled" if resp.status_code == 200 else "error"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── 테이블 관리 ──────────────────────────────────
    def list_tables(self):
        """테이블 목록 조회"""
        try:
            resp = self.session.get(
                self._url("/tables"),
                headers=self._headers(),
                timeout=10,
            )
            if resp.status_code == 200:
                return {"status": "ok", "tables": resp.json()}
            return {"status": "error", "code": resp.status_code}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def create_table(self, table_name, table_type="v3p"):
        """테이블 생성"""
        try:
            resp = self.session.post(
                self._url("/tables"),
                json={"name": table_name, "type": table_type},
                headers=self._headers(),
                timeout=10,
            )
            return {"status": "ok" if resp.status_code in (200, 201) else "error",
                    "response": resp.json() if resp.status_code in (200, 201) else resp.text}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def drop_table(self, table_name):
        """테이블 삭제"""
        try:
            resp = self.session.delete(
                self._url(f"/tables/{table_name}"),
                headers=self._headers(),
                timeout=10,
            )
            return {"status": "ok" if resp.status_code == 200 else "error"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── 로그 데이터 전송 ─────────────────────────────
    def send_logs(self, table_name, logs):
        """로그 데이터를 로그프레소에 전송"""
        try:
            resp = self.session.post(
                self._url(f"/tables/{table_name}/data"),
                json={"logs": logs},
                headers=self._headers(),
                timeout=30,
            )
            if resp.status_code in (200, 201):
                return {"status": "ok", "sent": len(logs)}
            return {"status": "error", "code": resp.status_code, "body": resp.text}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── 대시보드/프리셋 ──────────────────────────────
    def list_dashboards(self):
        """대시보드 목록 조회"""
        try:
            resp = self.session.get(
                self._url("/dashboard/presets"),
                headers=self._headers(),
                timeout=10,
            )
            if resp.status_code == 200:
                return {"status": "ok", "dashboards": resp.json()}
            return {"status": "error", "code": resp.status_code}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def get_dashboard(self, preset_id):
        """대시보드 상세 조회"""
        try:
            resp = self.session.get(
                self._url(f"/dashboard/presets/{preset_id}"),
                headers=self._headers(),
                timeout=10,
            )
            if resp.status_code == 200:
                return {"status": "ok", "dashboard": resp.json()}
            return {"status": "error", "code": resp.status_code}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── 인덱스 관리 ──────────────────────────────────
    def list_indexes(self):
        """인덱스 목록"""
        try:
            resp = self.session.get(
                self._url("/indexer/indexes"),
                headers=self._headers(),
                timeout=10,
            )
            if resp.status_code == 200:
                return {"status": "ok", "indexes": resp.json()}
            return {"status": "error", "code": resp.status_code}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── 시스템 상태 ──────────────────────────────────
    def get_system_status(self):
        """시스템 상태 조회"""
        try:
            resp = self.session.get(
                self._url("/system/status"),
                headers=self._headers(),
                timeout=10,
            )
            if resp.status_code == 200:
                return {"status": "ok", "system": resp.json()}
            return {"status": "error", "code": resp.status_code}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def get_license_info(self):
        """라이선스 정보"""
        try:
            resp = self.session.get(
                self._url("/system/license"),
                headers=self._headers(),
                timeout=10,
            )
            if resp.status_code == 200:
                return {"status": "ok", "license": resp.json()}
            return {"status": "error", "code": resp.status_code}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── 스트림 관리 ──────────────────────────────────
    def list_streams(self):
        """스트림 목록"""
        try:
            resp = self.session.get(
                self._url("/streams"),
                headers=self._headers(),
                timeout=10,
            )
            if resp.status_code == 200:
                return {"status": "ok", "streams": resp.json()}
            return {"status": "error", "code": resp.status_code}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── 유틸리티 ─────────────────────────────────────
    def health_check(self):
        """서버 헬스 체크"""
        try:
            resp = self.session.get(
                f"{self.host}/api/ping",
                timeout=5,
            )
            return {
                "status": "ok" if resp.status_code == 200 else "error",
                "host": self.host,
                "response_time_ms": resp.elapsed.total_seconds() * 1000,
            }
        except Exception as e:
            return {"status": "unreachable", "host": self.host, "message": str(e)}
