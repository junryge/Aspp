"""
WebSocket 통신 모듈 - 양방향 실시간 통신
==========================================
기능:
  - WebSocket 서버 (asyncio 기반)
  - 클라이언트 연결 관리
  - 메시지 브로드캐스트
  - 채널(Room) 기반 통신
"""

import json
import logging
import threading
from datetime import datetime
from collections import deque

logger = logging.getLogger(__name__)


class WebSocketManager:
    """Flask-SocketIO 기반 WebSocket 관리자"""

    def __init__(self):
        self.connected_clients = {}
        self.message_log = deque(maxlen=500)
        self.rooms = {}

    def on_connect(self, sid, environ=None):
        """클라이언트 연결"""
        self.connected_clients[sid] = {
            "connected_at": datetime.now().isoformat(),
            "rooms": set(),
        }
        logger.info(f"WebSocket 연결: {sid}")
        return {"status": "connected", "sid": sid}

    def on_disconnect(self, sid):
        """클라이언트 연결 해제"""
        if sid in self.connected_clients:
            for room in self.connected_clients[sid]["rooms"]:
                if room in self.rooms:
                    self.rooms[room].discard(sid)
            del self.connected_clients[sid]
        logger.info(f"WebSocket 연결 해제: {sid}")

    def on_message(self, sid, data):
        """메시지 수신 처리"""
        msg = {
            "from": sid,
            "data": data,
            "timestamp": datetime.now().isoformat(),
        }
        self.message_log.append(msg)
        logger.debug(f"WebSocket 메시지 [{sid}]: {data}")
        return msg

    def join_room(self, sid, room_name):
        """채널(Room) 입장"""
        if room_name not in self.rooms:
            self.rooms[room_name] = set()
        self.rooms[room_name].add(sid)
        if sid in self.connected_clients:
            self.connected_clients[sid]["rooms"].add(room_name)
        return {"status": "joined", "room": room_name}

    def leave_room(self, sid, room_name):
        """채널 퇴장"""
        if room_name in self.rooms:
            self.rooms[room_name].discard(sid)
        if sid in self.connected_clients:
            self.connected_clients[sid]["rooms"].discard(room_name)
        return {"status": "left", "room": room_name}

    def get_status(self):
        """WebSocket 상태"""
        return {
            "connected_clients": len(self.connected_clients),
            "rooms": {k: len(v) for k, v in self.rooms.items()},
            "total_messages": len(self.message_log),
        }

    def get_messages(self, count=50):
        """최근 메시지"""
        return list(self.message_log)[-count:]
