"""
MongoDB 통신 모듈 - NoSQL 데이터베이스 CRUD
=============================================
기능:
  - 연결 관리 (connect / disconnect / health check)
  - 컬렉션 CRUD (생성, 읽기, 수정, 삭제)
  - 인덱스 관리
  - 집계(Aggregation) 파이프라인
  - 데이터베이스/컬렉션 메타데이터 조회
  - 통계 및 모니터링
"""

import logging
from datetime import datetime
from bson import ObjectId, json_util
import json

logger = logging.getLogger(__name__)


def _serialize(doc):
    """MongoDB 문서를 JSON 직렬화 가능한 형태로 변환"""
    if doc is None:
        return None
    return json.loads(json_util.dumps(doc))


class MongoHandler:
    """MongoDB 통신 핸들러"""

    def __init__(self, uri="mongodb://localhost:27017", db_name="comm_hub"):
        self.uri = uri
        self.db_name = db_name
        self.client = None
        self.db = None

    # ── 연결 관리 ────────────────────────────────────
    def connect(self):
        """MongoDB 연결"""
        try:
            from pymongo import MongoClient
            self.client = MongoClient(self.uri, serverSelectionTimeoutMS=5000)
            # 연결 테스트
            self.client.admin.command("ping")
            self.db = self.client[self.db_name]
            logger.info(f"MongoDB 연결 성공: {self.uri}")
            return {"status": "connected", "db": self.db_name}
        except Exception as e:
            logger.error(f"MongoDB 연결 실패: {e}")
            return {"status": "error", "message": str(e)}

    def disconnect(self):
        """연결 해제"""
        if self.client:
            self.client.close()
            self.client = None
            self.db = None
            return {"status": "disconnected"}
        return {"status": "not_connected"}

    def health_check(self):
        """서버 상태 확인"""
        try:
            if not self.client:
                return {"status": "disconnected"}
            info = self.client.server_info()
            return {
                "status": "healthy",
                "version": info.get("version"),
                "uptime": info.get("uptime"),
                "connections": info.get("connections", {}),
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── 데이터베이스/컬렉션 메타데이터 ──────────────────
    def list_databases(self):
        """데이터베이스 목록"""
        try:
            dbs = []
            for db_info in self.client.list_databases():
                dbs.append({
                    "name": db_info["name"],
                    "sizeOnDisk": db_info.get("sizeOnDisk", 0),
                    "empty": db_info.get("empty", False),
                })
            return {"status": "ok", "databases": dbs}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def list_collections(self, db_name=None):
        """컬렉션 목록"""
        try:
            db = self.client[db_name] if db_name else self.db
            collections = []
            for name in db.list_collection_names():
                stats = db.command("collStats", name)
                collections.append({
                    "name": name,
                    "count": stats.get("count", 0),
                    "size": stats.get("size", 0),
                    "avgObjSize": stats.get("avgObjSize", 0),
                    "storageSize": stats.get("storageSize", 0),
                    "indexes": stats.get("nindexes", 0),
                })
            return {"status": "ok", "collections": collections, "db": db.name}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def get_db_stats(self, db_name=None):
        """데이터베이스 통계"""
        try:
            db = self.client[db_name] if db_name else self.db
            stats = db.command("dbStats")
            return {"status": "ok", "stats": _serialize(stats)}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def get_server_status(self):
        """서버 상태 (모니터링용)"""
        try:
            status = self.client.admin.command("serverStatus")
            return {
                "status": "ok",
                "host": status.get("host"),
                "version": status.get("version"),
                "uptime": status.get("uptime"),
                "connections": _serialize(status.get("connections", {})),
                "opcounters": _serialize(status.get("opcounters", {})),
                "mem": _serialize(status.get("mem", {})),
                "network": _serialize(status.get("network", {})),
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── CRUD 작업 ──────────────────────────────────────
    def insert_one(self, collection_name, document):
        """단일 문서 삽입"""
        try:
            col = self.db[collection_name]
            document["_created_at"] = datetime.now()
            result = col.insert_one(document)
            return {
                "status": "inserted",
                "id": str(result.inserted_id),
                "collection": collection_name
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def insert_many(self, collection_name, documents):
        """다수 문서 삽입"""
        try:
            col = self.db[collection_name]
            for doc in documents:
                doc["_created_at"] = datetime.now()
            result = col.insert_many(documents)
            return {
                "status": "inserted",
                "count": len(result.inserted_ids),
                "ids": [str(i) for i in result.inserted_ids],
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def find(self, collection_name, query=None, projection=None,
             sort=None, limit=100, skip=0):
        """문서 조회"""
        try:
            col = self.db[collection_name]
            query = query or {}

            # ObjectId 문자열을 실제 ObjectId로 변환
            if "_id" in query and isinstance(query["_id"], str):
                query["_id"] = ObjectId(query["_id"])

            cursor = col.find(query, projection).skip(skip).limit(limit)
            if sort:
                cursor = cursor.sort(sort)

            docs = [_serialize(doc) for doc in cursor]
            total = col.count_documents(query)
            return {
                "status": "ok",
                "documents": docs,
                "count": len(docs),
                "total": total,
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def find_one(self, collection_name, query):
        """단일 문서 조회"""
        try:
            col = self.db[collection_name]
            if "_id" in query and isinstance(query["_id"], str):
                query["_id"] = ObjectId(query["_id"])
            doc = col.find_one(query)
            return {"status": "ok", "document": _serialize(doc)}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def update_one(self, collection_name, query, update_data, upsert=False):
        """단일 문서 수정"""
        try:
            col = self.db[collection_name]
            if "_id" in query and isinstance(query["_id"], str):
                query["_id"] = ObjectId(query["_id"])

            update_data["_updated_at"] = datetime.now()
            result = col.update_one(query, {"$set": update_data}, upsert=upsert)
            return {
                "status": "updated",
                "matched": result.matched_count,
                "modified": result.modified_count,
                "upserted_id": str(result.upserted_id) if result.upserted_id else None,
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def update_many(self, collection_name, query, update_data):
        """다수 문서 수정"""
        try:
            col = self.db[collection_name]
            update_data["_updated_at"] = datetime.now()
            result = col.update_many(query, {"$set": update_data})
            return {
                "status": "updated",
                "matched": result.matched_count,
                "modified": result.modified_count,
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def delete_one(self, collection_name, query):
        """단일 문서 삭제"""
        try:
            col = self.db[collection_name]
            if "_id" in query and isinstance(query["_id"], str):
                query["_id"] = ObjectId(query["_id"])
            result = col.delete_one(query)
            return {"status": "deleted", "count": result.deleted_count}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def delete_many(self, collection_name, query):
        """다수 문서 삭제"""
        try:
            col = self.db[collection_name]
            result = col.delete_many(query)
            return {"status": "deleted", "count": result.deleted_count}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── 집계(Aggregation) ──────────────────────────────
    def aggregate(self, collection_name, pipeline):
        """Aggregation 파이프라인 실행"""
        try:
            col = self.db[collection_name]
            results = list(col.aggregate(pipeline))
            return {
                "status": "ok",
                "results": [_serialize(r) for r in results],
                "count": len(results),
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── 인덱스 관리 ─────────────────────────────────────
    def list_indexes(self, collection_name):
        """인덱스 목록"""
        try:
            col = self.db[collection_name]
            indexes = list(col.list_indexes())
            return {"status": "ok", "indexes": [_serialize(i) for i in indexes]}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def create_index(self, collection_name, keys, **kwargs):
        """인덱스 생성"""
        try:
            col = self.db[collection_name]
            name = col.create_index(keys, **kwargs)
            return {"status": "created", "index_name": name}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def drop_index(self, collection_name, index_name):
        """인덱스 삭제"""
        try:
            col = self.db[collection_name]
            col.drop_index(index_name)
            return {"status": "dropped", "index": index_name}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # ── 컬렉션 관리 ─────────────────────────────────────
    def create_collection(self, name, **kwargs):
        """컬렉션 생성"""
        try:
            self.db.create_collection(name, **kwargs)
            return {"status": "created", "collection": name}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def drop_collection(self, name):
        """컬렉션 삭제"""
        try:
            self.db.drop_collection(name)
            return {"status": "dropped", "collection": name}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def get_collection_stats(self, collection_name):
        """컬렉션 통계"""
        try:
            stats = self.db.command("collStats", collection_name)
            return {"status": "ok", "stats": _serialize(stats)}
        except Exception as e:
            return {"status": "error", "message": str(e)}
