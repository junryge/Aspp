"""
통신 프로토콜 모듈 패키지
- FTP: 파일 전송 프로토콜
- MongoDB: NoSQL 데이터베이스 통신
- Logpresso: 로그 분석 플랫폼 API
- UDP: 사용자 데이터그램 프로토콜
- TCP: 전송 제어 프로토콜
- WebSocket: 양방향 실시간 통신
- HTTP/REST: RESTful API 통신
"""
