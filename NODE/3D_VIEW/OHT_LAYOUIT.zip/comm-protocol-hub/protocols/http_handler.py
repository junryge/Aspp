"""
HTTP/REST API 통신 모듈
========================
기능:
  - HTTP 클라이언트 (GET, POST, PUT, DELETE, PATCH)
  - 응답 로깅 및 추적
  - 인증 헤더 관리 (Bearer, API Key, Basic)
  - 타임아웃 / 재시도 관리
"""

import requests
import json
import logging
from datetime import datetime
from collections import deque

logger = logging.getLogger(__name__)


class HTTPClient:
    """범용 HTTP/REST API 클라이언트"""

    def __init__(self, base_url="", default_headers=None, timeout=30):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        if default_headers:
            self.session.headers.update(default_headers)
        self.request_log = deque(maxlen=500)

    def set_bearer_token(self, token):
        self.session.headers["Authorization"] = f"Bearer {token}"

    def set_api_key(self, key, header_name="X-API-Key"):
        self.session.headers[header_name] = key

    def set_basic_auth(self, username, password):
        self.session.auth = (username, password)

    def _log_request(self, method, url, status_code, elapsed):
        entry = {
            "method": method,
            "url": url,
            "status": status_code,
            "elapsed_ms": elapsed,
            "timestamp": datetime.now().isoformat(),
        }
        self.request_log.append(entry)

    def request(self, method, path, **kwargs):
        """범용 HTTP 요청"""
        url = f"{self.base_url}{path}" if self.base_url else path
        kwargs.setdefault("timeout", self.timeout)

        try:
            resp = self.session.request(method, url, **kwargs)
            elapsed = resp.elapsed.total_seconds() * 1000
            self._log_request(method, url, resp.status_code, elapsed)

            result = {
                "status_code": resp.status_code,
                "elapsed_ms": elapsed,
                "headers": dict(resp.headers),
            }
            try:
                result["body"] = resp.json()
            except Exception:
                result["body"] = resp.text

            return result
        except requests.Timeout:
            return {"status_code": 0, "error": "timeout"}
        except Exception as e:
            return {"status_code": 0, "error": str(e)}

    def get(self, path, params=None, **kwargs):
        return self.request("GET", path, params=params, **kwargs)

    def post(self, path, data=None, json_data=None, **kwargs):
        return self.request("POST", path, data=data, json=json_data, **kwargs)

    def put(self, path, data=None, json_data=None, **kwargs):
        return self.request("PUT", path, data=data, json=json_data, **kwargs)

    def patch(self, path, data=None, json_data=None, **kwargs):
        return self.request("PATCH", path, data=data, json=json_data, **kwargs)

    def delete(self, path, **kwargs):
        return self.request("DELETE", path, **kwargs)

    def get_log(self, count=50):
        return list(self.request_log)[-count:]
