"""
FTP 통신 모듈 - 파일 전송 프로토콜 (송수신)
==============================================
기능:
  - FTP 서버 실행 (pyftpdlib 기반)
  - 파일 업로드 (클라이언트 → 서버)
  - 파일 다운로드 (서버 → 클라이언트)
  - 디렉토리 목록 조회
  - 파일 삭제
"""

import os
import io
import ftplib
import threading
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


# ============================================================
# FTP 서버 (pyftpdlib 기반)
# ============================================================
class FTPServerManager:
    """내장 FTP 서버 관리자"""

    def __init__(self, host="127.0.0.1", port=2121, user="admin",
                 password="admin123", root_dir="/tmp/ftp_root"):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.root_dir = root_dir
        self.server = None
        self.thread = None

        os.makedirs(self.root_dir, exist_ok=True)

    def start(self):
        """FTP 서버를 백그라운드 스레드로 시작"""
        try:
            from pyftpdlib.authorizers import DummyAuthorizer
            from pyftpdlib.handlers import FTPHandler
            from pyftpdlib.servers import FTPServer

            authorizer = DummyAuthorizer()
            authorizer.add_user(
                self.user, self.password, self.root_dir,
                perm="elradfmwMT"  # 전체 권한
            )
            authorizer.add_anonymous(self.root_dir, perm="elr")  # 익명: 읽기만

            handler = FTPHandler
            handler.authorizer = authorizer
            handler.banner = "ManimoHub FTP Server Ready"
            handler.passive_ports = range(60000, 60100)

            self.server = FTPServer((self.host, self.port), handler)
            self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
            self.thread.start()

            logger.info(f"FTP 서버 시작: {self.host}:{self.port}")
            return {"status": "running", "host": self.host, "port": self.port}

        except ImportError:
            logger.warning("pyftpdlib 미설치 - FTP 서버 기능 비활성화")
            return {"status": "error", "message": "pyftpdlib not installed"}
        except Exception as e:
            logger.error(f"FTP 서버 시작 실패: {e}")
            return {"status": "error", "message": str(e)}

    def stop(self):
        """FTP 서버 중지"""
        if self.server:
            self.server.close_all()
            logger.info("FTP 서버 중지됨")
            return {"status": "stopped"}
        return {"status": "not_running"}

    def get_status(self):
        """FTP 서버 상태 확인"""
        return {
            "running": self.thread is not None and self.thread.is_alive(),
            "host": self.host,
            "port": self.port,
            "root_dir": self.root_dir,
        }


# ============================================================
# FTP 클라이언트 (ftplib 기반)
# ============================================================
class FTPClient:
    """FTP 클라이언트 - 파일 송수신"""

    def __init__(self, host="127.0.0.1", port=2121, user="admin", password="admin123"):
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.connection = None

    def connect(self):
        """FTP 서버에 연결"""
        try:
            self.connection = ftplib.FTP()
            self.connection.connect(self.host, self.port, timeout=10)
            self.connection.login(self.user, self.password)
            logger.info(f"FTP 연결 성공: {self.host}:{self.port}")
            return {"status": "connected", "welcome": self.connection.getwelcome()}
        except Exception as e:
            logger.error(f"FTP 연결 실패: {e}")
            return {"status": "error", "message": str(e)}

    def disconnect(self):
        """FTP 연결 해제"""
        if self.connection:
            try:
                self.connection.quit()
            except Exception:
                self.connection.close()
            self.connection = None
            return {"status": "disconnected"}
        return {"status": "not_connected"}

    def upload_file(self, local_path, remote_path=None):
        """파일 업로드 (로컬 → 서버)"""
        if not self.connection:
            return {"status": "error", "message": "Not connected"}

        if remote_path is None:
            remote_path = os.path.basename(local_path)

        try:
            with open(local_path, "rb") as f:
                self.connection.storbinary(f"STOR {remote_path}", f)
            logger.info(f"파일 업로드 완료: {local_path} → {remote_path}")
            return {
                "status": "uploaded",
                "local": local_path,
                "remote": remote_path,
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"업로드 실패: {e}")
            return {"status": "error", "message": str(e)}

    def upload_bytes(self, data: bytes, remote_path: str):
        """바이트 데이터 직접 업로드"""
        if not self.connection:
            return {"status": "error", "message": "Not connected"}
        try:
            bio = io.BytesIO(data)
            self.connection.storbinary(f"STOR {remote_path}", bio)
            return {"status": "uploaded", "remote": remote_path, "size": len(data)}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def download_file(self, remote_path, local_path=None):
        """파일 다운로드 (서버 → 로컬)"""
        if not self.connection:
            return {"status": "error", "message": "Not connected"}

        if local_path is None:
            local_path = os.path.basename(remote_path)

        try:
            with open(local_path, "wb") as f:
                self.connection.retrbinary(f"RETR {remote_path}", f.write)
            logger.info(f"파일 다운로드 완료: {remote_path} → {local_path}")
            return {
                "status": "downloaded",
                "remote": remote_path,
                "local": local_path,
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"다운로드 실패: {e}")
            return {"status": "error", "message": str(e)}

    def download_bytes(self, remote_path) -> dict:
        """파일을 바이트로 다운로드"""
        if not self.connection:
            return {"status": "error", "message": "Not connected"}
        try:
            bio = io.BytesIO()
            self.connection.retrbinary(f"RETR {remote_path}", bio.write)
            return {"status": "downloaded", "data": bio.getvalue(), "size": bio.tell()}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def list_files(self, path="/"):
        """디렉토리 파일 목록 조회"""
        if not self.connection:
            return {"status": "error", "message": "Not connected"}
        try:
            files = []
            self.connection.retrlines(f"LIST {path}", files.append)
            return {"status": "ok", "path": path, "files": files}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def delete_file(self, remote_path):
        """원격 파일 삭제"""
        if not self.connection:
            return {"status": "error", "message": "Not connected"}
        try:
            self.connection.delete(remote_path)
            return {"status": "deleted", "path": remote_path}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def mkdir(self, dir_path):
        """원격 디렉토리 생성"""
        if not self.connection:
            return {"status": "error", "message": "Not connected"}
        try:
            self.connection.mkd(dir_path)
            return {"status": "created", "path": dir_path}
        except Exception as e:
            return {"status": "error", "message": str(e)}
