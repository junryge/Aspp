# 통신 프로토콜 허브 - 계획서

## 1. 프로젝트 개요

| 항목 | 내용 |
|------|------|
| 프로젝트명 | ManimoHub - 통신 프로토콜 관리 허브 |
| 목적 | 다양한 통신 프로토콜을 통합 관리하는 PoC |
| 기술 스택 | Python (Flask) + HTML/CSS/JS |
| UI 스타일 | 로그프레소 스타일 다크 대시보드 |

---

## 2. 지원 통신 프로토콜

### 2-1. FTP (File Transfer Protocol)
- **유형**: 파일 전송 (TCP 기반)
- **포트**: 2121 (커스텀)
- **기능**: 서버 실행, 파일 업로드/다운로드, 디렉토리 관리
- **라이브러리**: pyftpdlib (서버), ftplib (클라이언트)

### 2-2. MongoDB (NoSQL Database)
- **유형**: 데이터베이스 통신 (TCP)
- **포트**: 27017
- **기능**: CRUD, 집계, 인덱스 관리, 모니터링
- **라이브러리**: pymongo

### 2-3. UDP (User Datagram Protocol)
- **유형**: 비연결 데이터그램 전송
- **포트**: 5005 (수신), 5006 (송신)
- **기능**: 메시지 송수신, 브로드캐스트, 멀티캐스트
- **라이브러리**: socket (내장)

### 2-4. TCP (Transmission Control Protocol)
- **유형**: 연결 지향 스트림 전송
- **포트**: 9000
- **기능**: 클라이언트-서버 통신, 메시지 교환
- **라이브러리**: socket (내장)

### 2-5. HTTP/REST API
- **유형**: 웹 API 통신
- **포트**: 5000
- **기능**: REST API 호출 (GET/POST/PUT/DELETE)
- **라이브러리**: requests, Flask

### 2-6. WebSocket
- **유형**: 양방향 실시간 통신
- **포트**: 8765
- **기능**: 실시간 메시지, 채널(Room) 관리
- **라이브러리**: flask-socketio

### 2-7. 로그프레소 API
- **유형**: 로그 분석 플랫폼 REST API
- **포트**: 443 (HTTPS)
- **기능**: 쿼리 실행, 테이블 관리, 로그 전송, 대시보드 조회
- **라이브러리**: requests

---

## 3. 시스템 아키텍처

```
┌──────────────────────────────────────────────────┐
│                  웹 브라우저                        │
│          (로그프레소 스타일 대시보드)                  │
└─────────────────────┬────────────────────────────┘
                      │ HTTP/WebSocket
┌─────────────────────▼────────────────────────────┐
│              Flask 웹 서버 (포트 5000)              │
│              ┌─────────────────┐                  │
│              │   REST API      │                  │
│              │   라우팅 계층    │                  │
│              └────────┬────────┘                  │
├───────────────────────┼──────────────────────────┤
│  ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐    │
│  │  FTP   │ │MongoDB │ │  UDP   │ │  TCP   │    │
│  │Handler │ │Handler │ │Handler │ │Handler │    │
│  └────┬───┘ └────┬───┘ └────┬───┘ └────┬───┘    │
│  ┌────┴───┐ ┌────┴───┐ ┌────┴───┐ ┌────┴───┐    │
│  │Logpress│ │  HTTP  │ │WebSock │ │Config  │    │
│  │Handler │ │Handler │ │Handler │ │Manager │    │
│  └────────┘ └────────┘ └────────┘ └────────┘    │
└──────────────────────────────────────────────────┘
```

---

## 4. 프로젝트 폴더 구조

```
comm-protocol-hub/
├── app.py                    # 메인 서버 (Flask)
├── requirements.txt          # Python 의존성
├── config/
│   ├── settings.py           # 전역 설정
│   └── .env.example          # 환경변수 예시
├── protocols/
│   ├── __init__.py
│   ├── ftp_handler.py        # FTP 서버/클라이언트
│   ├── mongo_handler.py      # MongoDB CRUD
│   ├── udp_handler.py        # UDP/TCP 송수신
│   ├── logpresso_handler.py  # 로그프레소 API
│   ├── websocket_handler.py  # WebSocket 관리
│   └── http_handler.py       # HTTP/REST 클라이언트
├── dashboard/
│   ├── templates/
│   │   └── index.html        # 메인 대시보드 HTML
│   └── static/
│       ├── css/
│       │   └── dashboard.css # 로그프레소 스타일 CSS
│       └── js/
│           └── dashboard.js  # 대시보드 JavaScript
├── docs/
│   └── PROTOCOL_PLAN.md      # 이 문서
├── logs/                     # 로그 파일
└── tests/                    # 테스트 코드
```

---

## 5. API 엔드포인트 목록

### MongoDB
| Method | Endpoint | 설명 |
|--------|----------|------|
| GET | /api/mongo/health | 헬스 체크 |
| GET | /api/mongo/stats | DB 통계 |
| GET | /api/mongo/collections | 컬렉션 목록 |
| POST | /api/mongo/collections | 컬렉션 생성 |
| DELETE | /api/mongo/collections/:name | 컬렉션 삭제 |
| GET/POST | /api/mongo/find | 문서 조회 |
| POST | /api/mongo/insert | 문서 삽입 |
| POST | /api/mongo/update | 문서 수정 |
| POST | /api/mongo/delete | 문서 삭제 |
| POST | /api/mongo/aggregate | 집계 파이프라인 |

### FTP
| Method | Endpoint | 설명 |
|--------|----------|------|
| GET | /api/ftp/status | 서버 상태 |
| POST | /api/ftp/start | 서버 시작 |
| POST | /api/ftp/stop | 서버 중지 |
| GET | /api/ftp/list | 파일 목록 |
| POST | /api/ftp/upload | 파일 업로드 |

### UDP/TCP
| Method | Endpoint | 설명 |
|--------|----------|------|
| GET | /api/udp/status | UDP 상태 |
| POST | /api/udp/start | UDP 서버 시작 |
| POST | /api/udp/send | UDP 메시지 전송 |
| GET | /api/udp/messages | 수신 메시지 |
| GET | /api/tcp/status | TCP 상태 |
| POST | /api/tcp/start | TCP 서버 시작 |

### 로그프레소
| Method | Endpoint | 설명 |
|--------|----------|------|
| GET | /api/logpresso/health | 헬스 체크 |
| POST | /api/logpresso/login | 로그인 |
| POST | /api/logpresso/query | 쿼리 실행 |
| GET | /api/logpresso/tables | 테이블 목록 |
| POST | /api/logpresso/send-logs | 로그 전송 |

### 시스템
| Method | Endpoint | 설명 |
|--------|----------|------|
| GET | /api/system/info | 전체 상태 요약 |
| POST | /api/http/request | HTTP 프록시 |

---

## 6. 실행 방법

```bash
# 1. 의존성 설치
pip install -r requirements.txt

# 2. 환경변수 설정
cp config/.env.example .env
# .env 파일 편집하여 MongoDB 접속 정보 등 입력

# 3. 서버 실행
python app.py

# 4. 대시보드 접속
# http://localhost:5000
```
