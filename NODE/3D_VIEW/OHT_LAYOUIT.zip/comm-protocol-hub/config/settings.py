"""
통신 프로토콜 허브 - 설정 파일
모든 인증 정보는 .env 파일에서 관리
"""
import os
from dotenv import load_dotenv

load_dotenv()

# ============================================================
# MongoDB 설정 + 인증
# ============================================================
MONGO_HOST = os.getenv("MONGO_HOST", "localhost")
MONGO_PORT = int(os.getenv("MONGO_PORT", 27017))
MONGO_DB = os.getenv("MONGO_DB", "comm_hub")
MONGO_USER = os.getenv("MONGO_USER", "")
MONGO_PASS = os.getenv("MONGO_PASS", "")
MONGO_AUTH_SOURCE = os.getenv("MONGO_AUTH_SOURCE", "admin")  # 인증 DB
MONGO_AUTH_MECHANISM = os.getenv("MONGO_AUTH_MECHANISM", "SCRAM-SHA-256")
MONGO_TLS = os.getenv("MONGO_TLS", "false").lower() == "true"
MONGO_TLS_CA_FILE = os.getenv("MONGO_TLS_CA_FILE", "")
MONGO_REPLICA_SET = os.getenv("MONGO_REPLICA_SET", "")

# MongoDB URI 자동 생성 (인증 정보 포함)
if os.getenv("MONGO_URI"):
    MONGO_URI = os.getenv("MONGO_URI")
elif MONGO_USER and MONGO_PASS:
    _auth = f"{MONGO_USER}:{MONGO_PASS}@"
    _params = f"?authSource={MONGO_AUTH_SOURCE}&authMechanism={MONGO_AUTH_MECHANISM}"
    if MONGO_TLS:
        _params += "&tls=true"
        if MONGO_TLS_CA_FILE:
            _params += f"&tlsCAFile={MONGO_TLS_CA_FILE}"
    if MONGO_REPLICA_SET:
        _params += f"&replicaSet={MONGO_REPLICA_SET}"
    MONGO_URI = f"mongodb://{_auth}{MONGO_HOST}:{MONGO_PORT}/{MONGO_DB}{_params}"
else:
    MONGO_URI = f"mongodb://{MONGO_HOST}:{MONGO_PORT}/{MONGO_DB}"

# MongoDB 데모 모드 (MongoDB 미설치 시)
MONGO_DEMO_MODE = os.getenv("MONGO_DEMO_MODE", "false").lower() == "true"

# ============================================================
# FTP 설정 + 인증
# ============================================================
FTP_HOST = os.getenv("FTP_HOST", "127.0.0.1")
FTP_PORT = int(os.getenv("FTP_PORT", 2121))
FTP_USER = os.getenv("FTP_USER", "admin")
FTP_PASS = os.getenv("FTP_PASS", "admin123")
FTP_ROOT_DIR = os.getenv("FTP_ROOT_DIR", "/tmp/ftp_root")
FTP_PASSIVE_PORTS_START = int(os.getenv("FTP_PASSIVE_PORTS_START", 60000))
FTP_PASSIVE_PORTS_END = int(os.getenv("FTP_PASSIVE_PORTS_END", 60100))
FTP_MAX_CONNECTIONS = int(os.getenv("FTP_MAX_CONNECTIONS", 50))
FTP_ANONYMOUS_ENABLED = os.getenv("FTP_ANONYMOUS_ENABLED", "false").lower() == "true"
# 추가 FTP 사용자 (JSON 형태: [{"user":"u1","pass":"p1","perm":"elradfmwMT"}])
FTP_ADDITIONAL_USERS = os.getenv("FTP_ADDITIONAL_USERS", "[]")
# FTP TLS/SSL 설정
FTP_TLS_ENABLED = os.getenv("FTP_TLS_ENABLED", "false").lower() == "true"
FTP_TLS_CERT = os.getenv("FTP_TLS_CERT", "")
FTP_TLS_KEY = os.getenv("FTP_TLS_KEY", "")

# ============================================================
# UDP 설정
# ============================================================
UDP_HOST = os.getenv("UDP_HOST", "127.0.0.1")
UDP_SEND_PORT = int(os.getenv("UDP_SEND_PORT", 5005))
UDP_RECV_PORT = int(os.getenv("UDP_RECV_PORT", 5006))
UDP_BUFFER_SIZE = int(os.getenv("UDP_BUFFER_SIZE", 4096))

# ============================================================
# 로그프레소 API 설정 + 인증
# ============================================================
LOGPRESSO_HOST = os.getenv("LOGPRESSO_HOST", "https://your-logpresso-server.com")
LOGPRESSO_API_KEY = os.getenv("LOGPRESSO_API_KEY", "")
LOGPRESSO_LOGIN_ID = os.getenv("LOGPRESSO_LOGIN_ID", "admin")
LOGPRESSO_LOGIN_PW = os.getenv("LOGPRESSO_LOGIN_PW", "")
LOGPRESSO_TLS_VERIFY = os.getenv("LOGPRESSO_TLS_VERIFY", "true").lower() == "true"
LOGPRESSO_TIMEOUT = int(os.getenv("LOGPRESSO_TIMEOUT", 30))

# ============================================================
# Flask 웹서버 설정 + 대시보드 인증
# ============================================================
FLASK_HOST = os.getenv("FLASK_HOST", "0.0.0.0")
FLASK_PORT = int(os.getenv("FLASK_PORT", 5000))
FLASK_DEBUG = os.getenv("FLASK_DEBUG", "True").lower() == "true"
SECRET_KEY = os.getenv("SECRET_KEY", "manimo-hub-secret-key-change-me")

# 대시보드 로그인 인증
DASHBOARD_AUTH_ENABLED = os.getenv("DASHBOARD_AUTH_ENABLED", "true").lower() == "true"
DASHBOARD_ADMIN_USER = os.getenv("DASHBOARD_ADMIN_USER", "admin")
DASHBOARD_ADMIN_PASS = os.getenv("DASHBOARD_ADMIN_PASS", "admin")
# 추가 사용자 (JSON: [{"user":"op1","pass":"p1","role":"operator"}])
DASHBOARD_USERS = os.getenv("DASHBOARD_USERS", "[]")
# 세션 만료 (초)
SESSION_TIMEOUT = int(os.getenv("SESSION_TIMEOUT", 3600))

# ============================================================
# TCP 설정
# ============================================================
TCP_HOST = os.getenv("TCP_HOST", "127.0.0.1")
TCP_PORT = int(os.getenv("TCP_PORT", 9000))

# ============================================================
# HTTP/HTTPS (REST API) 설정 + 인증
# ============================================================
REST_API_BASE_URL = os.getenv("REST_API_BASE_URL", "http://localhost:5000/api")
REST_API_TOKEN = os.getenv("REST_API_TOKEN", "")  # Bearer token
REST_API_KEY = os.getenv("REST_API_KEY", "")       # API key
REST_API_BASIC_USER = os.getenv("REST_API_BASIC_USER", "")
REST_API_BASIC_PASS = os.getenv("REST_API_BASIC_PASS", "")

# ============================================================
# WebSocket 설정
# ============================================================
WS_HOST = os.getenv("WS_HOST", "127.0.0.1")
WS_PORT = int(os.getenv("WS_PORT", 8765))
WS_AUTH_TOKEN = os.getenv("WS_AUTH_TOKEN", "")  # WebSocket 인증 토큰

# ============================================================
# 보안 설정
# ============================================================
# API 요청 제한 (Rate Limit)
RATE_LIMIT_ENABLED = os.getenv("RATE_LIMIT_ENABLED", "true").lower() == "true"
RATE_LIMIT_PER_MINUTE = int(os.getenv("RATE_LIMIT_PER_MINUTE", 60))

# CORS 설정
CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*")

# 로그 레벨
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
