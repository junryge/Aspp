"""
ManimoHub - 통신 프로토콜 허브 메인 서버
======================================
Flask 기반 웹 서버 + REST API
모든 통신 프로토콜을 통합 관리하는 중앙 허브

실행: python app.py
"""

import os
import json
import logging
import functools
from datetime import datetime, timedelta
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_cors import CORS

# 프로토콜 모듈
from protocols.ftp_handler import FTPServerManager, FTPClient
from protocols.udp_handler import UDPServer, UDPClient, TCPServer
from protocols.logpresso_handler import LogpressoClient
from protocols.websocket_handler import WebSocketManager
from protocols.http_handler import HTTPClient

# 설정
from config.settings import *

# ============================================================
# 로깅 설정
# ============================================================
os.makedirs('logs', exist_ok=True)
logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('logs/manimohub.log', encoding='utf-8'),
    ]
)
logger = logging.getLogger('ManimoHub')

# ============================================================
# Flask 앱 초기화
# ============================================================
app = Flask(
    __name__,
    template_folder='dashboard/templates',
    static_folder='dashboard/static',
)
app.secret_key = SECRET_KEY
app.permanent_session_lifetime = timedelta(seconds=SESSION_TIMEOUT)
CORS(app, origins=CORS_ORIGINS.split(','))

# ============================================================
# MongoDB 핸들러 (자동 감지: 실제 / 데모 모드)
# ============================================================
mongo = None

def init_mongo():
    """MongoDB 연결 시도 → 실패 시 자동으로 Mock 모드"""
    global mongo

    if MONGO_DEMO_MODE:
        logger.info("MongoDB 데모 모드 (MONGO_DEMO_MODE=true)")
        from protocols.mongo_mock import MongoMockHandler
        mongo = MongoMockHandler(db_name=MONGO_DB)
        mongo.connect()
        return

    try:
        from protocols.mongo_handler import MongoHandler
        mongo = MongoHandler(uri=MONGO_URI, db_name=MONGO_DB)
        result = mongo.connect()
        if result['status'] == 'connected':
            logger.info(f"MongoDB 연결 성공: {MONGO_URI}")
            return
        raise Exception(result.get('message', 'Connection failed'))
    except Exception as e:
        logger.warning(f"MongoDB 연결 실패: {e}")
        logger.info("→ 자동으로 데모 모드로 전환합니다")
        from protocols.mongo_mock import MongoMockHandler
        mongo = MongoMockHandler(db_name=MONGO_DB)
        mongo.connect()

# ============================================================
# 프로토콜 핸들러 초기화
# ============================================================
# FTP (인증 정보 적용)
ftp_server = FTPServerManager(
    host=FTP_HOST, port=FTP_PORT,
    user=FTP_USER, password=FTP_PASS,
    root_dir=FTP_ROOT_DIR,
)
ftp_client = FTPClient(
    host=FTP_HOST, port=FTP_PORT,
    user=FTP_USER, password=FTP_PASS,
)

# UDP / TCP
udp_server = UDPServer(host=UDP_HOST, port=UDP_RECV_PORT, buffer_size=UDP_BUFFER_SIZE)
udp_client = UDPClient(buffer_size=UDP_BUFFER_SIZE)
tcp_server = TCPServer(host=TCP_HOST, port=TCP_PORT)

# 로그프레소 (인증 정보 적용)
logpresso = LogpressoClient(
    host=LOGPRESSO_HOST,
    login_id=LOGPRESSO_LOGIN_ID,
    login_pw=LOGPRESSO_LOGIN_PW,
    api_key=LOGPRESSO_API_KEY,
)

# WebSocket
ws_manager = WebSocketManager()

# HTTP 클라이언트 (인증 정보 적용)
http_client = HTTPClient(base_url=REST_API_BASE_URL)
if REST_API_TOKEN:
    http_client.set_bearer_token(REST_API_TOKEN)
elif REST_API_KEY:
    http_client.set_api_key(REST_API_KEY)
elif REST_API_BASIC_USER and REST_API_BASIC_PASS:
    http_client.set_basic_auth(REST_API_BASIC_USER, REST_API_BASIC_PASS)


# ============================================================
# 인증 미들웨어
# ============================================================
def login_required(f):
    """대시보드 로그인 필수 데코레이터"""
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        if not DASHBOARD_AUTH_ENABLED:
            return f(*args, **kwargs)
        if session.get('logged_in'):
            return f(*args, **kwargs)
        if request.is_json or request.path.startswith('/api/'):
            return jsonify({"status": "error", "message": "인증 필요"}), 401
        return redirect(url_for('login_page'))
    return decorated_function


def get_all_users():
    """설정에서 모든 사용자 목록 가져오기"""
    users = {DASHBOARD_ADMIN_USER: {"password": DASHBOARD_ADMIN_PASS, "role": "admin"}}
    try:
        extra = json.loads(DASHBOARD_USERS)
        for u in extra:
            users[u['user']] = {"password": u['pass'], "role": u.get('role', 'viewer')}
    except Exception:
        pass
    return users


# ============================================================
# 로그인 / 로그아웃 라우트
# ============================================================
@app.route('/login', methods=['GET'])
def login_page():
    """로그인 페이지"""
    # 로그아웃 후 강제 이동 허용 (force 파라미터)
    force = request.args.get('force', '')
    if force == '1':
        session.clear()
        return render_template('login.html')
    if not DASHBOARD_AUTH_ENABLED or session.get('logged_in'):
        return redirect('/')
    return render_template('login.html')


@app.route('/api/auth/login', methods=['POST'])
def auth_login():
    """로그인 API"""
    data = request.get_json()
    username = data.get('username', '')
    password = data.get('password', '')

    users = get_all_users()
    user = users.get(username)

    if user and user['password'] == password:
        session.permanent = True
        session['logged_in'] = True
        session['username'] = username
        session['role'] = user['role']
        session['login_time'] = datetime.now().isoformat()
        logger.info(f"로그인 성공: {username} (역할: {user['role']})")
        return jsonify({
            "status": "ok",
            "username": username,
            "role": user['role'],
        })

    logger.warning(f"로그인 실패: {username}")
    return jsonify({"status": "error", "message": "잘못된 사용자명 또는 비밀번호"}), 401


@app.route('/api/auth/logout', methods=['POST'])
def auth_logout():
    """로그아웃"""
    username = session.get('username', 'unknown')
    session.clear()
    logger.info(f"로그아웃: {username}")
    return jsonify({"status": "ok", "redirect": "/login"})


@app.route('/api/auth/status')
def auth_status():
    """현재 인증 상태"""
    if session.get('logged_in'):
        return jsonify({
            "logged_in": True,
            "username": session.get('username'),
            "role": session.get('role'),
            "login_time": session.get('login_time'),
        })
    return jsonify({"logged_in": False})


# ============================================================
# 웹 페이지 라우트
# ============================================================
@app.route('/')
@login_required
def index():
    """메인 대시보드 페이지"""
    return render_template('index.html')


# ============================================================
# MongoDB API
# ============================================================
@app.route('/api/mongo/health')
@login_required
def mongo_health():
    return jsonify(mongo.health_check())


@app.route('/api/mongo/stats')
@login_required
def mongo_stats():
    return jsonify(mongo.get_db_stats())


@app.route('/api/mongo/server-status')
@login_required
def mongo_server_status():
    return jsonify(mongo.get_server_status())


@app.route('/api/mongo/databases')
@login_required
def mongo_databases():
    return jsonify(mongo.list_databases())


@app.route('/api/mongo/collections', methods=['GET', 'POST'])
@login_required
def mongo_collections():
    if request.method == 'POST':
        data = request.get_json()
        return jsonify(mongo.create_collection(data['name']))
    db_name = request.args.get('db')
    return jsonify(mongo.list_collections(db_name))


@app.route('/api/mongo/collections/<name>', methods=['DELETE'])
@login_required
def mongo_drop_collection(name):
    return jsonify(mongo.drop_collection(name))


@app.route('/api/mongo/collections/<name>/stats')
@login_required
def mongo_collection_stats(name):
    return jsonify(mongo.get_collection_stats(name))


@app.route('/api/mongo/find', methods=['GET', 'POST'])
@login_required
def mongo_find():
    if request.method == 'POST':
        data = request.get_json()
        return jsonify(mongo.find(
            data.get('collection'),
            data.get('query', {}),
            data.get('projection'),
            data.get('sort'),
            data.get('limit', 100),
            data.get('skip', 0),
        ))
    collection = request.args.get('collection')
    limit = int(request.args.get('limit', 50))
    skip = int(request.args.get('skip', 0))
    return jsonify(mongo.find(collection, limit=limit, skip=skip))


@app.route('/api/mongo/find-one', methods=['POST'])
@login_required
def mongo_find_one():
    data = request.get_json()
    return jsonify(mongo.find_one(data['collection'], data.get('query', {})))


@app.route('/api/mongo/insert', methods=['POST'])
@login_required
def mongo_insert():
    data = request.get_json()
    if isinstance(data.get('document'), list):
        return jsonify(mongo.insert_many(data['collection'], data['document']))
    return jsonify(mongo.insert_one(data['collection'], data['document']))


@app.route('/api/mongo/update', methods=['POST'])
@login_required
def mongo_update():
    data = request.get_json()
    return jsonify(mongo.update_one(
        data['collection'], data.get('query', {}),
        data.get('update', {}), data.get('upsert', False),
    ))


@app.route('/api/mongo/delete', methods=['POST'])
@login_required
def mongo_delete():
    data = request.get_json()
    return jsonify(mongo.delete_one(data['collection'], data.get('query', {})))


@app.route('/api/mongo/aggregate', methods=['POST'])
@login_required
def mongo_aggregate():
    data = request.get_json()
    return jsonify(mongo.aggregate(data['collection'], data['pipeline']))


@app.route('/api/mongo/indexes/<collection>')
@login_required
def mongo_indexes(collection):
    return jsonify(mongo.list_indexes(collection))


# ============================================================
# FTP API
# ============================================================
@app.route('/api/ftp/status')
@login_required
def ftp_status():
    return jsonify(ftp_server.get_status())


@app.route('/api/ftp/start', methods=['POST'])
@login_required
def ftp_start():
    return jsonify(ftp_server.start())


@app.route('/api/ftp/stop', methods=['POST'])
@login_required
def ftp_stop():
    return jsonify(ftp_server.stop())


@app.route('/api/ftp/list')
@login_required
def ftp_list():
    path = request.args.get('path', '/')
    result = ftp_client.connect()
    if result['status'] == 'connected':
        files = ftp_client.list_files(path)
        ftp_client.disconnect()
        return jsonify(files)
    return jsonify(result)


@app.route('/api/ftp/upload', methods=['POST'])
@login_required
def ftp_upload():
    data = request.get_json()
    result = ftp_client.connect()
    if result['status'] == 'connected':
        if 'data' in data:
            upload = ftp_client.upload_bytes(data['data'].encode(), data['remote_path'])
        else:
            upload = ftp_client.upload_file(data['local_path'], data.get('remote_path'))
        ftp_client.disconnect()
        return jsonify(upload)
    return jsonify(result)


# ============================================================
# UDP / TCP API
# ============================================================
@app.route('/api/udp/status')
@login_required
def udp_status():
    return jsonify(udp_server.get_status())


@app.route('/api/udp/start', methods=['POST'])
@login_required
def udp_start():
    return jsonify(udp_server.start())


@app.route('/api/udp/stop', methods=['POST'])
@login_required
def udp_stop():
    return jsonify(udp_server.stop())


@app.route('/api/udp/send', methods=['POST'])
@login_required
def udp_send():
    data = request.get_json()
    return jsonify(udp_client.send(data['host'], data['port'], data['data']))


@app.route('/api/udp/broadcast', methods=['POST'])
@login_required
def udp_broadcast():
    data = request.get_json()
    return jsonify(udp_client.broadcast(data['port'], data['data']))


@app.route('/api/udp/messages')
@login_required
def udp_messages():
    count = int(request.args.get('count', 50))
    return jsonify(udp_server.get_messages(count))


@app.route('/api/tcp/status')
@login_required
def tcp_status():
    return jsonify(tcp_server.get_status())


@app.route('/api/tcp/start', methods=['POST'])
@login_required
def tcp_start():
    return jsonify(tcp_server.start())


@app.route('/api/tcp/stop', methods=['POST'])
@login_required
def tcp_stop():
    return jsonify(tcp_server.stop())


# ============================================================
# 로그프레소 API
# ============================================================
@app.route('/api/logpresso/health')
@login_required
def logpresso_health():
    return jsonify(logpresso.health_check())


@app.route('/api/logpresso/login', methods=['POST'])
@login_required
def logpresso_login():
    data = request.get_json() or {}
    if 'host' in data:
        logpresso.host = data['host']
    if 'login_id' in data:
        logpresso.login_id = data['login_id']
    if 'login_pw' in data:
        logpresso.login_pw = data['login_pw']
    return jsonify(logpresso.login())


@app.route('/api/logpresso/logout', methods=['POST'])
@login_required
def logpresso_logout():
    return jsonify(logpresso.logout())


@app.route('/api/logpresso/query', methods=['POST'])
@login_required
def logpresso_query():
    data = request.get_json()
    return jsonify(logpresso.execute_query(data['query'], data.get('limit', 1000)))


@app.route('/api/logpresso/tables')
@login_required
def logpresso_tables():
    return jsonify(logpresso.list_tables())


@app.route('/api/logpresso/send-logs', methods=['POST'])
@login_required
def logpresso_send_logs():
    data = request.get_json()
    return jsonify(logpresso.send_logs(data['table'], data['logs']))


@app.route('/api/logpresso/dashboards')
@login_required
def logpresso_dashboards():
    return jsonify(logpresso.list_dashboards())


@app.route('/api/logpresso/system')
@login_required
def logpresso_system():
    return jsonify(logpresso.get_system_status())


# ============================================================
# WebSocket & HTTP API
# ============================================================
@app.route('/api/ws/status')
@login_required
def ws_status():
    return jsonify(ws_manager.get_status())


@app.route('/api/http/request', methods=['POST'])
@login_required
def http_request_proxy():
    data = request.get_json()
    result = http_client.request(
        data.get('method', 'GET').upper(),
        data.get('url', ''),
        headers=data.get('headers', {}),
        json=data.get('body') if isinstance(data.get('body'), dict) else None,
        data=data.get('body') if isinstance(data.get('body'), str) else None,
    )
    return jsonify(result)


@app.route('/api/http/log')
@login_required
def http_log():
    count = int(request.args.get('count', 50))
    return jsonify({"status": "ok", "log": http_client.get_log(count)})


# ============================================================
# 시스템 API
# ============================================================
@app.route('/api/system/info')
@login_required
def system_info():
    return jsonify({
        "status": "ok",
        "timestamp": datetime.now().isoformat(),
        "mongo_mode": "demo" if MONGO_DEMO_MODE else "live",
        "auth_enabled": DASHBOARD_AUTH_ENABLED,
        "protocols": {
            "mongodb": mongo.health_check(),
            "ftp_server": ftp_server.get_status(),
            "udp_server": udp_server.get_status(),
            "tcp_server": tcp_server.get_status(),
            "websocket": ws_manager.get_status(),
        },
        "version": "1.0.0",
    })


# ============================================================
# 에러 핸들러
# ============================================================
@app.errorhandler(404)
def not_found(e):
    return jsonify({"status": "error", "message": "Not Found"}), 404


@app.errorhandler(500)
def server_error(e):
    return jsonify({"status": "error", "message": "Internal Server Error"}), 500


# ============================================================
# 서버 시작
# ============================================================
if __name__ == '__main__':
    os.makedirs('logs', exist_ok=True)
    os.makedirs(FTP_ROOT_DIR, exist_ok=True)

    logger.info("=" * 60)
    logger.info("ManimoHub - 통신 프로토콜 허브 시작")
    logger.info("=" * 60)

    # MongoDB 초기화 (자동 감지)
    init_mongo()

    # 인증 정보 표시
    if DASHBOARD_AUTH_ENABLED:
        logger.info(f"대시보드 인증: 활성화 (admin: {DASHBOARD_ADMIN_USER})")
    else:
        logger.info("대시보드 인증: 비활성화")

    if MONGO_USER:
        logger.info(f"MongoDB 인증: {MONGO_USER}@{MONGO_HOST}:{MONGO_PORT}")
    logger.info(f"FTP 인증: {FTP_USER}@{FTP_HOST}:{FTP_PORT}")
    if LOGPRESSO_API_KEY:
        logger.info(f"로그프레소: API Key 설정됨 ({LOGPRESSO_HOST})")

    logger.info(f"대시보드: http://{FLASK_HOST}:{FLASK_PORT}")
    logger.info("=" * 60)

    app.run(host=FLASK_HOST, port=FLASK_PORT, debug=FLASK_DEBUG)
