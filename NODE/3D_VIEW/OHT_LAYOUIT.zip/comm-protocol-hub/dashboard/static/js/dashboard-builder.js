/**
 * ManimoHub 동적 대시보드 빌더
 * ============================
 * 로그프레소 스타일로 위젯을 추가/편집/배치하여
 * 데이터 기반 대시보드를 직접 만들 수 있는 기능
 */

// ============================================================
// 대시보드 빌더 상태
// ============================================================
const dashboardBuilder = {
    presets: [],          // 저장된 대시보드 프리셋 목록
    currentPreset: null,  // 현재 편집 중인 프리셋
    editMode: false,      // 편집 모드 여부
    widgets: [],          // 현재 대시보드의 위젯들
    dragTarget: null,     // 드래그 중인 위젯
};

// 사용 가능한 위젯 타입
const WIDGET_TYPES = {
    chart_line: { name: '라인 차트', icon: '📈', description: '시계열 데이터를 라인으로 시각화' },
    chart_bar: { name: '바 차트', icon: '📊', description: '카테고리별 수치 비교' },
    chart_doughnut: { name: '도넛 차트', icon: '🍩', description: '비율/구성 시각화' },
    chart_area: { name: '영역 차트', icon: '📉', description: '추이를 영역으로 표현' },
    data_table: { name: '데이터 테이블', icon: '📋', description: '컬렉션 데이터를 테이블로 표시' },
    stat_card: { name: '통계 카드', icon: '🔢', description: '단일 수치 강조 (카운트, 합계 등)' },
    json_viewer: { name: 'JSON 뷰어', icon: '{ }', description: '원본 JSON 데이터 표시' },
    log_stream: { name: '로그 스트림', icon: '📜', description: '실시간 로그 메시지 표시' },
    status_indicator: { name: '상태 표시기', icon: '🚦', description: '프로토콜/서비스 상태 표시' },
    query_widget: { name: '쿼리 위젯', icon: '▶', description: 'MongoDB 쿼리 결과를 자동 표시' },
};

// ============================================================
// 프리셋 관리 (로컬 스토리지 + API)
// ============================================================
function loadPresets() {
    try {
        const saved = localStorage.getItem('manimohub_presets');
        dashboardBuilder.presets = saved ? JSON.parse(saved) : getDefaultPresets();
    } catch {
        dashboardBuilder.presets = getDefaultPresets();
    }
    renderPresetList();
}

function savePresets() {
    localStorage.setItem('manimohub_presets', JSON.stringify(dashboardBuilder.presets));
}

function getDefaultPresets() {
    return [
        {
            id: 'default-overview',
            name: '시스템 개요',
            description: '전체 시스템 상태 모니터링',
            created: new Date().toISOString(),
            widgets: [
                { id: 'w1', type: 'stat_card', title: '총 문서 수', col: 3,
                  config: { source: 'mongo', endpoint: '/api/mongo/stats', field: 'stats.objects', color: 'blue' } },
                { id: 'w2', type: 'stat_card', title: '컬렉션 수', col: 3,
                  config: { source: 'mongo', endpoint: '/api/mongo/stats', field: 'stats.collections', color: 'green' } },
                { id: 'w3', type: 'stat_card', title: '스토리지', col: 3,
                  config: { source: 'mongo', endpoint: '/api/mongo/stats', field: 'stats.storageSize', color: 'orange', format: 'bytes' } },
                { id: 'w4', type: 'status_indicator', title: '프로토콜 상태', col: 3,
                  config: { protocols: ['mongo', 'ftp', 'udp', 'tcp'] } },
                { id: 'w5', type: 'chart_line', title: '트래픽 추이', col: 6,
                  config: { source: 'mongo', collection: 'network_traffic', xField: 'timestamp', yField: 'bytes' } },
                { id: 'w6', type: 'data_table', title: '최근 로그', col: 6,
                  config: { source: 'mongo', collection: 'server_logs', limit: 10, fields: ['level', 'message', 'host', 'timestamp'] } },
            ]
        },
        {
            id: 'default-network',
            name: '네트워크 모니터링',
            description: 'UDP/TCP/FTP 트래픽 모니터링',
            created: new Date().toISOString(),
            widgets: [
                { id: 'w1', type: 'chart_doughnut', title: '프로토콜별 트래픽', col: 4,
                  config: { source: 'mongo', collection: 'network_traffic', groupField: 'protocol', valueField: 'bytes' } },
                { id: 'w2', type: 'chart_bar', title: '호스트별 패킷 수', col: 4,
                  config: { source: 'mongo', collection: 'network_traffic', groupField: 'src', valueField: 'packets' } },
                { id: 'w3', type: 'log_stream', title: 'UDP 수신 메시지', col: 4,
                  config: { source: 'udp', endpoint: '/api/udp/messages' } },
            ]
        }
    ];
}

// ============================================================
// 프리셋 UI 렌더링
// ============================================================
function renderPresetList() {
    const container = document.getElementById('preset-list');
    if (!container) return;

    container.innerHTML = dashboardBuilder.presets.map(preset => `
        <div class="protocol-status" style="cursor:pointer;" onclick="loadPreset('${preset.id}')">
            <div class="dot ${dashboardBuilder.currentPreset?.id === preset.id ? 'online' : 'offline'}"></div>
            <span class="protocol-name">${escapeHtml(preset.name)}</span>
            <span class="protocol-detail">${preset.widgets.length}개 위젯</span>
            <button class="btn btn-sm btn-danger" onclick="event.stopPropagation();deletePreset('${preset.id}')" title="삭제">×</button>
        </div>
    `).join('');
}

// ============================================================
// 프리셋 CRUD
// ============================================================
function createNewPreset() {
    const name = prompt('새 대시보드 이름:');
    if (!name) return;

    const preset = {
        id: 'preset-' + Date.now(),
        name: name,
        description: '',
        created: new Date().toISOString(),
        widgets: [],
    };

    dashboardBuilder.presets.push(preset);
    savePresets();
    loadPreset(preset.id);
    renderPresetList();
    addLog('success', `대시보드 "${name}" 생성됨`);
}

function loadPreset(presetId) {
    const preset = dashboardBuilder.presets.find(p => p.id === presetId);
    if (!preset) return;

    dashboardBuilder.currentPreset = preset;
    dashboardBuilder.widgets = [...preset.widgets];
    renderDashboardWidgets();
    renderPresetList();

    document.getElementById('builder-preset-name').textContent = preset.name;
    addLog('info', `대시보드 "${preset.name}" 로드됨`);
}

function saveCurrentPreset() {
    if (!dashboardBuilder.currentPreset) return;

    const idx = dashboardBuilder.presets.findIndex(p => p.id === dashboardBuilder.currentPreset.id);
    if (idx >= 0) {
        dashboardBuilder.presets[idx].widgets = [...dashboardBuilder.widgets];
        dashboardBuilder.presets[idx].updated = new Date().toISOString();
        savePresets();
        addLog('success', `대시보드 "${dashboardBuilder.currentPreset.name}" 저장됨`);
    }
}

function deletePreset(presetId) {
    if (!confirm('이 대시보드를 삭제하시겠습니까?')) return;
    dashboardBuilder.presets = dashboardBuilder.presets.filter(p => p.id !== presetId);
    if (dashboardBuilder.currentPreset?.id === presetId) {
        dashboardBuilder.currentPreset = null;
        dashboardBuilder.widgets = [];
        renderDashboardWidgets();
    }
    savePresets();
    renderPresetList();
}

// ============================================================
// 위젯 추가/편집/삭제
// ============================================================
function openAddWidgetModal() {
    const modal = document.getElementById('add-widget-modal');
    const typeList = document.getElementById('widget-type-list');

    typeList.innerHTML = Object.entries(WIDGET_TYPES).map(([type, info]) => `
        <div class="protocol-status" style="cursor:pointer;" onclick="addWidget('${type}')">
            <span style="font-size:20px;">${info.icon}</span>
            <div style="flex:1;">
                <div class="protocol-name">${info.name}</div>
                <div class="protocol-detail">${info.description}</div>
            </div>
        </div>
    `).join('');

    modal.classList.add('active');
}

function addWidget(type) {
    const info = WIDGET_TYPES[type];
    const widget = {
        id: 'w-' + Date.now(),
        type: type,
        title: info.name,
        col: 6,  // 기본 6/12 그리드
        config: getDefaultWidgetConfig(type),
    };

    dashboardBuilder.widgets.push(widget);
    closeModal('add-widget-modal');
    renderDashboardWidgets();
    openWidgetConfigModal(widget.id);  // 바로 설정 창 열기
    addLog('info', `위젯 추가: ${info.name}`);
}

function getDefaultWidgetConfig(type) {
    switch (type) {
        case 'chart_line':
        case 'chart_bar':
        case 'chart_area':
            return { source: 'mongo', collection: '', xField: '', yField: '', refreshInterval: 5 };
        case 'chart_doughnut':
            return { source: 'mongo', collection: '', groupField: '', valueField: '', refreshInterval: 5 };
        case 'data_table':
            return { source: 'mongo', collection: '', limit: 20, fields: [], query: '{}' };
        case 'stat_card':
            return { source: 'mongo', endpoint: '', field: '', color: 'blue', format: 'number' };
        case 'json_viewer':
            return { source: 'mongo', collection: '', query: '{}', limit: 1 };
        case 'log_stream':
            return { source: 'udp', endpoint: '/api/udp/messages', maxLines: 50 };
        case 'status_indicator':
            return { protocols: ['mongo', 'ftp', 'udp', 'tcp', 'logpresso'] };
        case 'query_widget':
            return { source: 'mongo', collection: '', query: '{}', limit: 100, visualization: 'table' };
        default:
            return {};
    }
}

function removeWidget(widgetId) {
    dashboardBuilder.widgets = dashboardBuilder.widgets.filter(w => w.id !== widgetId);
    renderDashboardWidgets();
}

function openWidgetConfigModal(widgetId) {
    const widget = dashboardBuilder.widgets.find(w => w.id === widgetId);
    if (!widget) return;

    const modal = document.getElementById('widget-config-modal');
    const body = document.getElementById('widget-config-body');

    body.innerHTML = `
        <div class="form-group">
            <label class="form-label">위젯 제목</label>
            <input class="form-input" id="wc-title" value="${escapeHtml(widget.title)}">
        </div>
        <div class="form-group">
            <label class="form-label">그리드 크기 (1~12)</label>
            <select class="form-select" id="wc-col">
                ${[3, 4, 6, 8, 12].map(n => `<option value="${n}" ${widget.col === n ? 'selected' : ''}>${n}/12 (${Math.round(n / 12 * 100)}%)</option>`).join('')}
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">데이터 소스</label>
            <select class="form-select" id="wc-source" onchange="updateSourceFields('${widgetId}')">
                <option value="mongo" ${widget.config.source === 'mongo' ? 'selected' : ''}>MongoDB 컬렉션</option>
                <option value="udp" ${widget.config.source === 'udp' ? 'selected' : ''}>UDP 메시지</option>
                <option value="ftp" ${widget.config.source === 'ftp' ? 'selected' : ''}>FTP 파일</option>
                <option value="api" ${widget.config.source === 'api' ? 'selected' : ''}>커스텀 API</option>
                <option value="logpresso" ${widget.config.source === 'logpresso' ? 'selected' : ''}>로그프레소</option>
            </select>
        </div>
        <div id="wc-source-fields">
            ${renderSourceFields(widget)}
        </div>
        <div class="form-group">
            <label class="form-label">자동 새로고침 (초, 0=꺼짐)</label>
            <input class="form-input" id="wc-refresh" type="number" value="${widget.config.refreshInterval || 0}" min="0">
        </div>
    `;

    document.getElementById('widget-config-save').onclick = () => {
        widget.title = document.getElementById('wc-title').value;
        widget.col = parseInt(document.getElementById('wc-col').value);
        widget.config.source = document.getElementById('wc-source').value;
        widget.config.refreshInterval = parseInt(document.getElementById('wc-refresh').value) || 0;

        // 소스별 추가 필드
        const colInput = document.getElementById('wc-collection');
        if (colInput) widget.config.collection = colInput.value;
        const queryInput = document.getElementById('wc-query');
        if (queryInput) widget.config.query = queryInput.value;
        const fieldsInput = document.getElementById('wc-fields');
        if (fieldsInput) widget.config.fields = fieldsInput.value.split(',').map(f => f.trim()).filter(Boolean);
        const xInput = document.getElementById('wc-xfield');
        if (xInput) widget.config.xField = xInput.value;
        const yInput = document.getElementById('wc-yfield');
        if (yInput) widget.config.yField = yInput.value;
        const groupInput = document.getElementById('wc-groupfield');
        if (groupInput) widget.config.groupField = groupInput.value;
        const valueInput = document.getElementById('wc-valuefield');
        if (valueInput) widget.config.valueField = valueInput.value;
        const endpointInput = document.getElementById('wc-endpoint');
        if (endpointInput) widget.config.endpoint = endpointInput.value;
        const limitInput = document.getElementById('wc-limit');
        if (limitInput) widget.config.limit = parseInt(limitInput.value) || 20;

        closeModal('widget-config-modal');
        renderDashboardWidgets();
        addLog('success', `위젯 "${widget.title}" 설정 저장됨`);
    };

    modal.classList.add('active');
}

function renderSourceFields(widget) {
    const c = widget.config;
    const type = widget.type;

    let html = '';

    if (c.source === 'mongo' || !c.source) {
        html += `
            <div class="form-group">
                <label class="form-label">컬렉션 이름</label>
                <input class="form-input" id="wc-collection" value="${c.collection || ''}" placeholder="server_logs">
            </div>
            <div class="form-group">
                <label class="form-label">쿼리 (JSON)</label>
                <input class="form-input" id="wc-query" value='${c.query || "{}"}' placeholder='{"level":"ERROR"}'>
            </div>
            <div class="form-group">
                <label class="form-label">제한 (limit)</label>
                <input class="form-input" id="wc-limit" type="number" value="${c.limit || 20}">
            </div>
        `;

        if (['chart_line', 'chart_bar', 'chart_area'].includes(type)) {
            html += `
                <div class="form-group">
                    <label class="form-label">X축 필드</label>
                    <input class="form-input" id="wc-xfield" value="${c.xField || ''}" placeholder="timestamp">
                </div>
                <div class="form-group">
                    <label class="form-label">Y축 필드</label>
                    <input class="form-input" id="wc-yfield" value="${c.yField || ''}" placeholder="bytes">
                </div>
            `;
        } else if (type === 'chart_doughnut') {
            html += `
                <div class="form-group">
                    <label class="form-label">그룹 필드</label>
                    <input class="form-input" id="wc-groupfield" value="${c.groupField || ''}" placeholder="protocol">
                </div>
                <div class="form-group">
                    <label class="form-label">값 필드</label>
                    <input class="form-input" id="wc-valuefield" value="${c.valueField || ''}" placeholder="bytes">
                </div>
            `;
        } else if (type === 'data_table') {
            html += `
                <div class="form-group">
                    <label class="form-label">표시할 필드 (쉼표 구분)</label>
                    <input class="form-input" id="wc-fields" value="${(c.fields || []).join(', ')}" placeholder="level, message, host">
                </div>
            `;
        }
    } else if (c.source === 'udp' || c.source === 'ftp' || c.source === 'api' || c.source === 'logpresso') {
        html += `
            <div class="form-group">
                <label class="form-label">API 엔드포인트</label>
                <input class="form-input" id="wc-endpoint" value="${c.endpoint || ''}" placeholder="/api/udp/messages">
            </div>
        `;
    }

    return html;
}

function updateSourceFields(widgetId) {
    const widget = dashboardBuilder.widgets.find(w => w.id === widgetId);
    if (!widget) return;
    widget.config.source = document.getElementById('wc-source').value;
    document.getElementById('wc-source-fields').innerHTML = renderSourceFields(widget);
}

// ============================================================
// 위젯 렌더링 + 데이터 로딩
// ============================================================
function renderDashboardWidgets() {
    const container = document.getElementById('builder-canvas');
    if (!container) return;

    if (dashboardBuilder.widgets.length === 0) {
        container.innerHTML = `
            <div style="text-align:center;padding:80px 20px;color:var(--text-muted);">
                <div style="font-size:48px;margin-bottom:16px;">📊</div>
                <h3 style="color:var(--text-secondary);margin-bottom:8px;">대시보드가 비어있습니다</h3>
                <p>"위젯 추가" 버튼으로 차트, 테이블, 통계 카드 등을 추가하세요</p>
                <button class="btn btn-primary" style="margin-top:16px;" onclick="openAddWidgetModal()">+ 위젯 추가</button>
            </div>
        `;
        return;
    }

    container.innerHTML = `<div class="dashboard-grid" style="grid-template-columns:repeat(12,1fr);">
        ${dashboardBuilder.widgets.map(widget => {
            const info = WIDGET_TYPES[widget.type] || { icon: '?', name: widget.type };
            return `
                <div class="widget-card fade-in" style="grid-column:span ${widget.col};" id="widget-${widget.id}">
                    <div class="widget-header">
                        <h3><span class="widget-icon">${info.icon}</span> ${escapeHtml(widget.title)}</h3>
                        <div class="widget-actions">
                            <button onclick="refreshWidget('${widget.id}')" title="새로고침">&#8635;</button>
                            <button onclick="openWidgetConfigModal('${widget.id}')" title="설정">&#9881;</button>
                            <button onclick="removeWidget('${widget.id}')" title="삭제" style="color:var(--accent-red);">×</button>
                        </div>
                    </div>
                    <div class="widget-body" id="widget-body-${widget.id}" style="min-height:150px;">
                        <p style="color:var(--text-muted);text-align:center;">로딩중...</p>
                    </div>
                </div>
            `;
        }).join('')}
    </div>`;

    // 각 위젯 데이터 로드
    dashboardBuilder.widgets.forEach(w => refreshWidget(w.id));
}

async function refreshWidget(widgetId) {
    const widget = dashboardBuilder.widgets.find(w => w.id === widgetId);
    if (!widget) return;

    const body = document.getElementById(`widget-body-${widgetId}`);
    if (!body) return;

    const c = widget.config;

    try {
        switch (widget.type) {
            case 'stat_card':
                await renderStatWidget(body, c);
                break;
            case 'data_table':
                await renderTableWidget(body, c);
                break;
            case 'chart_line':
            case 'chart_bar':
            case 'chart_area':
            case 'chart_doughnut':
                await renderChartWidget(body, widget);
                break;
            case 'json_viewer':
                await renderJsonWidget(body, c);
                break;
            case 'log_stream':
                await renderLogWidget(body, c);
                break;
            case 'status_indicator':
                await renderStatusWidget(body, c);
                break;
            case 'query_widget':
                await renderQueryWidget(body, c);
                break;
            default:
                body.innerHTML = `<p style="color:var(--text-muted);">미지원 위젯 타입: ${widget.type}</p>`;
        }
    } catch (err) {
        body.innerHTML = `<p style="color:var(--accent-red);">오류: ${err.message}</p>`;
    }
}

// ── 위젯 렌더러들 ──────────────────────────────────
async function renderStatWidget(body, config) {
    if (config.endpoint) {
        const data = await fetchAPI(config.endpoint.replace('/api', ''));
        const value = getNestedValue(data, config.field);
        const formatted = config.format === 'bytes' ? formatBytes(value || 0) : formatNumber(value || 0);
        const color = config.color || 'blue';
        body.innerHTML = `
            <div class="builder-stat-card">
                <div class="builder-stat-value ${color}">${formatted}</div>
                <div class="builder-stat-label">${config.field ? config.field.split('.').pop() : 'VALUE'}</div>
            </div>`;
    } else {
        body.innerHTML = `<div style="text-align:center;color:var(--text-muted);padding:20px;">엔드포인트를 설정하세요</div>`;
    }
}

async function renderTableWidget(body, config) {
    if (!config.collection) {
        body.innerHTML = '<p style="color:var(--text-muted);">컬렉션을 설정하세요</p>';
        return;
    }

    let query = {};
    try { query = JSON.parse(config.query || '{}'); } catch {}

    const result = await fetchAPI('/mongo/find', {
        method: 'POST',
        body: JSON.stringify({ collection: config.collection, query, limit: config.limit || 20 }),
    });

    if (result.status === 'ok' && result.documents.length > 0) {
        const fields = config.fields?.length > 0 ? config.fields : Object.keys(result.documents[0]).filter(k => k !== '_id');
        body.innerHTML = `
            <div class="data-table-wrapper">
                <table class="data-table">
                    <thead><tr>${fields.map(f => `<th>${f}</th>`).join('')}</tr></thead>
                    <tbody>${result.documents.map(doc =>
                        `<tr>${fields.map(f => `<td>${escapeHtml(String(doc[f] ?? ''))}</td>`).join('')}</tr>`
                    ).join('')}</tbody>
                </table>
            </div>
            <p style="color:var(--text-muted);font-size:11px;margin-top:8px;">${result.count}/${result.total}건</p>
        `;
    } else {
        body.innerHTML = '<p style="color:var(--text-muted);">데이터 없음</p>';
    }
}

async function renderChartWidget(body, widget) {
    const c = widget.config;
    if (!c.collection) {
        body.innerHTML = '<p style="color:var(--text-muted);">컬렉션을 설정하세요</p>';
        return;
    }

    let query = {};
    try { query = JSON.parse(c.query || '{}'); } catch {}

    const result = await fetchAPI('/mongo/find', {
        method: 'POST',
        body: JSON.stringify({ collection: c.collection, query, limit: c.limit || 50 }),
    });

    if (result.status !== 'ok' || !result.documents.length) {
        body.innerHTML = '<p style="color:var(--text-muted);">데이터 없음</p>';
        return;
    }

    const canvasId = `chart-${widget.id}-${Date.now()}`;
    body.innerHTML = `<canvas id="${canvasId}" style="width:100%;height:200px;"></canvas>`;

    const ctx = document.getElementById(canvasId);
    if (!ctx || !window.Chart) return;

    const docs = result.documents;
    const chartType = widget.type.replace('chart_', '');

    if (chartType === 'doughnut') {
        // 그룹핑
        const groups = {};
        docs.forEach(d => {
            const key = d[c.groupField] || 'Unknown';
            groups[key] = (groups[key] || 0) + (parseFloat(d[c.valueField]) || 1);
        });
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: Object.keys(groups),
                datasets: [{ data: Object.values(groups), backgroundColor: ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#a855f7', '#06b6d4'], borderWidth: 0 }]
            },
            options: { responsive: true, plugins: { legend: { position: 'right', labels: { color: '#a0a3ab' } } } }
        });
    } else {
        const labels = docs.map(d => d[c.xField] || '');
        const data = docs.map(d => parseFloat(d[c.yField]) || 0);
        new Chart(ctx, {
            type: chartType === 'area' ? 'line' : chartType,
            data: {
                labels,
                datasets: [{
                    label: c.yField || '값',
                    data,
                    borderColor: '#3b82f6',
                    backgroundColor: chartType === 'area' ? 'rgba(59,130,246,0.15)' : '#3b82f6',
                    fill: chartType === 'area',
                    tension: 0.4,
                    borderRadius: chartType === 'bar' ? 6 : 0,
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { labels: { color: '#a0a3ab' } } },
                scales: {
                    x: { ticks: { color: '#6b7280' }, grid: { color: '#2d323b' } },
                    y: { ticks: { color: '#6b7280' }, grid: { color: '#2d323b' } }
                }
            }
        });
    }
}

async function renderJsonWidget(body, config) {
    if (!config.collection) {
        body.innerHTML = '<p style="color:var(--text-muted);">컬렉션을 설정하세요</p>';
        return;
    }
    let query = {};
    try { query = JSON.parse(config.query || '{}'); } catch {}
    const result = await fetchAPI('/mongo/find', {
        method: 'POST',
        body: JSON.stringify({ collection: config.collection, query, limit: config.limit || 1 }),
    });
    if (result.status === 'ok') {
        body.innerHTML = `<div class="json-viewer">${syntaxHighlight(result.documents)}</div>`;
    }
}

async function renderLogWidget(body, config) {
    const endpoint = (config.endpoint || '/api/udp/messages').replace('/api', '');
    const result = await fetchAPI(endpoint);
    const messages = result.messages || result.log || [];
    if (messages.length > 0) {
        body.innerHTML = `<div class="console-output" style="max-height:250px;">` +
            messages.slice(-(config.maxLines || 50)).map(m => {
                const time = m.timestamp || m.time || '';
                const text = m.data || m.message || JSON.stringify(m);
                return `<span class="log-time">[${time}]</span> ${escapeHtml(text)}`;
            }).join('\n') +
            `</div>`;
    } else {
        body.innerHTML = '<p style="color:var(--text-muted);">메시지 없음</p>';
    }
}

async function renderStatusWidget(body, config) {
    const protocols = config.protocols || ['mongo', 'ftp', 'udp', 'tcp'];
    const endpoints = {
        mongo: '/mongo/health', ftp: '/ftp/status', udp: '/udp/status',
        tcp: '/tcp/status', logpresso: '/logpresso/health', ws: '/ws/status'
    };

    let html = '';
    for (const p of protocols) {
        const result = await fetchAPI(endpoints[p] || `/api/${p}/status`);
        const online = ['ok', 'running', 'healthy', 'connected'].includes(result.status);
        html += `<div class="protocol-status"><div class="dot ${online ? 'online' : 'offline'}"></div>
            <span class="protocol-name">${p.toUpperCase()}</span>
            <span class="badge ${online ? 'success' : 'danger'}">${online ? 'ON' : 'OFF'}</span></div>`;
    }
    body.innerHTML = html;
}

async function renderQueryWidget(body, config) {
    if (!config.collection) {
        body.innerHTML = '<p style="color:var(--text-muted);">컬렉션과 쿼리를 설정하세요</p>';
        return;
    }
    let query = {};
    try { query = JSON.parse(config.query || '{}'); } catch {}
    const result = await fetchAPI('/mongo/find', {
        method: 'POST',
        body: JSON.stringify({ collection: config.collection, query, limit: config.limit || 100 }),
    });
    if (result.status === 'ok') {
        body.innerHTML = `<div class="json-viewer" style="max-height:300px;">${syntaxHighlight(result.documents)}</div>
        <p style="color:var(--text-muted);font-size:11px;margin-top:4px;">${result.count}건</p>`;
    }
}

// ── 유틸리티 ───────────────────────────────────────
function getNestedValue(obj, path) {
    if (!path) return obj;
    return path.split('.').reduce((o, k) => o?.[k], obj);
}

// ============================================================
// 편집 모드 토글
// ============================================================
function toggleEditMode() {
    dashboardBuilder.editMode = !dashboardBuilder.editMode;
    document.getElementById('builder-edit-btn').textContent =
        dashboardBuilder.editMode ? '편집 완료' : '편집 모드';
    document.getElementById('builder-toolbar').style.display =
        dashboardBuilder.editMode ? 'flex' : 'none';
}

// ============================================================
// 초기화
// ============================================================
function initDashboardBuilder() {
    loadPresets();
    if (dashboardBuilder.presets.length > 0) {
        loadPreset(dashboardBuilder.presets[0].id);
    }
}
