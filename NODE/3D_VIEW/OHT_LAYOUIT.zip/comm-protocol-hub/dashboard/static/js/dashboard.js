/**
 * ManimoHub 대시보드 - 메인 JavaScript
 * 로그프레소 스타일 MongoDB 관리자 대시보드
 */

// ============================================================
// 전역 상태
// ============================================================
const state = {
    currentPage: 'overview',
    darkMode: true,
    refreshInterval: null,
    refreshRate: 5000,
    collections: [],
    dbStats: {},
    protocolStatus: {},
};

// API 기본 URL
const API = '/api';

// ============================================================
// 유틸리티 함수
// ============================================================
async function fetchAPI(endpoint, options = {}) {
    try {
        const resp = await fetch(`${API}${endpoint}`, {
            headers: { 'Content-Type': 'application/json' },
            ...options,
        });
        return await resp.json();
    } catch (err) {
        console.error(`API Error [${endpoint}]:`, err);
        addLog('error', `API 오류: ${endpoint} - ${err.message}`);
        return { status: 'error', message: err.message };
    }
}

function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}

function timeAgo(date) {
    const now = new Date();
    const d = new Date(date);
    const diff = Math.floor((now - d) / 1000);
    if (diff < 60) return `${diff}초 전`;
    if (diff < 3600) return `${Math.floor(diff / 60)}분 전`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}시간 전`;
    return `${Math.floor(diff / 86400)}일 전`;
}

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// JSON 하이라이터
function syntaxHighlight(json) {
    if (typeof json !== 'string') json = JSON.stringify(json, null, 2);
    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return json.replace(
        /("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
        function (match) {
            let cls = 'json-number';
            if (/^"/.test(match)) {
                cls = /:$/.test(match) ? 'json-key' : 'json-string';
            } else if (/true|false/.test(match)) {
                cls = 'json-boolean';
            } else if (/null/.test(match)) {
                cls = 'json-null';
            }
            return `<span class="${cls}">${match}</span>`;
        }
    );
}

// ============================================================
// 콘솔 로그
// ============================================================
const logBuffer = [];

function addLog(level, message) {
    const time = new Date().toLocaleTimeString();
    logBuffer.push({ time, level, message });
    if (logBuffer.length > 200) logBuffer.shift();

    const consoleEl = document.getElementById('console-output');
    if (consoleEl) {
        const line = `<span class="log-time">[${time}]</span> <span class="log-${level}">[${level.toUpperCase()}]</span> ${escapeHtml(message)}`;
        consoleEl.innerHTML += line + '\n';
        consoleEl.scrollTop = consoleEl.scrollHeight;
    }
}

// ============================================================
// 네비게이션
// ============================================================
function navigate(page) {
    state.currentPage = page;

    // 네비게이션 활성 상태 업데이트
    document.querySelectorAll('.nav-item').forEach(el => {
        el.classList.toggle('active', el.dataset.page === page);
    });

    // 페이지 표시/숨김
    document.querySelectorAll('.page-section').forEach(el => {
        el.style.display = el.id === `page-${page}` ? 'block' : 'none';
    });

    // 브레드크럼 업데이트
    const titles = {
        overview: '대시보드 개요',
        collections: '컬렉션 관리',
        documents: '문서 탐색기',
        protocols: '통신 프로토콜',
        ftp: 'FTP 관리',
        udp: 'UDP 통신',
        logpresso: '로그프레소 API',
        query: '쿼리 실행',
        logs: '시스템 로그',
        settings: '설정',
    };

    const breadcrumb = document.getElementById('breadcrumb-current');
    if (breadcrumb) breadcrumb.textContent = titles[page] || page;

    // 페이지별 데이터 로드
    loadPageData(page);
}

// ============================================================
// 페이지별 데이터 로드
// ============================================================
async function loadPageData(page) {
    switch (page) {
        case 'overview':
            await loadOverview();
            break;
        case 'collections':
            await loadCollections();
            break;
        case 'protocols':
            loadProtocolStatus();
            break;
    }
}

// ── 대시보드 개요 ──────────────────────────────────
async function loadOverview() {
    addLog('info', '대시보드 데이터 로딩...');

    // MongoDB 상태
    const health = await fetchAPI('/mongo/health');
    const statEl = document.getElementById('stat-mongo-status');
    if (statEl) {
        if (health.status === 'healthy') {
            statEl.innerHTML = `<span class="badge success">연결됨</span>`;
            document.getElementById('stat-mongo-version').textContent = health.version || '-';
            document.getElementById('stat-mongo-uptime').textContent =
                health.uptime ? Math.floor(health.uptime / 3600) + 'h' : '-';
        } else {
            statEl.innerHTML = `<span class="badge danger">오프라인</span>`;
        }
    }

    // DB 통계
    const stats = await fetchAPI('/mongo/stats');
    if (stats.status === 'ok' && stats.stats) {
        const s = stats.stats;
        updateStat('stat-collections', s.collections || 0);
        updateStat('stat-documents', formatNumber(s.objects || 0));
        updateStat('stat-storage', formatBytes(s.storageSize || 0));
        updateStat('stat-indexes', s.indexes || 0);
    }

    // 컬렉션 목록
    const cols = await fetchAPI('/mongo/collections');
    if (cols.status === 'ok') {
        state.collections = cols.collections || [];
        renderCollectionTable(state.collections.slice(0, 5), 'overview-collections-table');
    }

    // 프로토콜 상태
    loadProtocolStatus();

    addLog('success', '대시보드 데이터 로딩 완료');
}

function updateStat(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
}

// ── 컬렉션 관리 ────────────────────────────────────
async function loadCollections() {
    addLog('info', '컬렉션 목록 로딩...');
    const result = await fetchAPI('/mongo/collections');
    if (result.status === 'ok') {
        state.collections = result.collections || [];
        renderCollectionTable(state.collections, 'collections-table');
    }
}

function renderCollectionTable(collections, tableId) {
    const tbody = document.getElementById(tableId);
    if (!tbody) return;

    if (collections.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:40px;">컬렉션이 없습니다</td></tr>';
        return;
    }

    tbody.innerHTML = collections.map(col => `
        <tr>
            <td><strong>${escapeHtml(col.name)}</strong></td>
            <td>${formatNumber(col.count || 0)}</td>
            <td>${formatBytes(col.size || 0)}</td>
            <td>${formatBytes(col.avgObjSize || 0)}</td>
            <td>${col.indexes || 0}</td>
            <td>
                <button class="btn btn-sm btn-secondary" onclick="browseCollection('${escapeHtml(col.name)}')">탐색</button>
                <button class="btn btn-sm btn-danger" onclick="confirmDropCollection('${escapeHtml(col.name)}')">삭제</button>
            </td>
        </tr>
    `).join('');
}

// ── 문서 탐색기 ────────────────────────────────────
async function browseCollection(name) {
    navigate('documents');
    document.getElementById('doc-collection-name').textContent = name;
    document.getElementById('doc-collection-select').value = name;

    const result = await fetchAPI(`/mongo/find?collection=${name}&limit=50`);
    if (result.status === 'ok') {
        renderDocuments(result.documents || []);
        document.getElementById('doc-total-count').textContent = `총 ${result.total || 0}건`;
    }
}

function renderDocuments(docs) {
    const container = document.getElementById('documents-container');
    if (!container) return;

    if (docs.length === 0) {
        container.innerHTML = '<p style="text-align:center;color:var(--text-muted);padding:40px;">문서가 없습니다</p>';
        return;
    }

    container.innerHTML = docs.map((doc, i) => `
        <div class="widget-card fade-in" style="margin-bottom:12px;">
            <div class="widget-header">
                <h3>#${i + 1} - ${doc._id ? doc._id.$oid || doc._id : 'N/A'}</h3>
                <div class="widget-actions">
                    <button onclick='editDocument("${doc._id?.$oid || doc._id}")' title="편집">&#9998;</button>
                    <button onclick='deleteDocument("${doc._id?.$oid || doc._id}")' title="삭제">&#128465;</button>
                </div>
            </div>
            <div class="widget-body">
                <div class="json-viewer">${syntaxHighlight(doc)}</div>
            </div>
        </div>
    `).join('');
}

// ── 쿼리 실행기 ────────────────────────────────────
async function executeQuery() {
    const collection = document.getElementById('query-collection').value;
    const queryText = document.getElementById('query-input').value;
    const resultEl = document.getElementById('query-result');

    if (!collection || !queryText) {
        addLog('warning', '컬렉션과 쿼리를 입력하세요');
        return;
    }

    addLog('info', `쿼리 실행: ${collection} - ${queryText}`);

    try {
        const query = JSON.parse(queryText);
        const result = await fetchAPI('/mongo/find', {
            method: 'POST',
            body: JSON.stringify({ collection, query }),
        });

        if (result.status === 'ok') {
            resultEl.innerHTML = `<div class="json-viewer">${syntaxHighlight(result.documents)}</div>
            <p style="margin-top:10px;color:var(--text-muted);">${result.count}건 조회 (총 ${result.total}건)</p>`;
            addLog('success', `쿼리 성공: ${result.count}건 조회`);
        } else {
            resultEl.innerHTML = `<p style="color:var(--accent-red);">오류: ${result.message}</p>`;
        }
    } catch (e) {
        resultEl.innerHTML = `<p style="color:var(--accent-red);">JSON 파싱 오류: ${e.message}</p>`;
        addLog('error', `JSON 파싱 오류: ${e.message}`);
    }
}

// ── 프로토콜 상태 ──────────────────────────────────
async function loadProtocolStatus() {
    const protocols = [
        { id: 'ftp', name: 'FTP', endpoint: '/ftp/status' },
        { id: 'udp', name: 'UDP', endpoint: '/udp/status' },
        { id: 'tcp', name: 'TCP', endpoint: '/tcp/status' },
        { id: 'ws', name: 'WebSocket', endpoint: '/ws/status' },
        { id: 'mongo', name: 'MongoDB', endpoint: '/mongo/health' },
        { id: 'logpresso', name: '로그프레소', endpoint: '/logpresso/health' },
    ];

    const container = document.getElementById('protocol-status-list');
    if (!container) return;

    let html = '';
    for (const p of protocols) {
        const result = await fetchAPI(p.endpoint);
        const isOnline = result.status === 'ok' || result.status === 'running' ||
            result.status === 'healthy' || result.status === 'connected';
        const statusClass = isOnline ? 'online' : 'offline';
        const detail = isOnline ?
            (result.host ? `${result.host}:${result.port}` : '연결됨') :
            (result.message || '연결 안됨');

        html += `
            <div class="protocol-status">
                <div class="dot ${statusClass}"></div>
                <span class="protocol-name">${p.name}</span>
                <span class="protocol-detail">${detail}</span>
                <span class="badge ${isOnline ? 'success' : 'danger'}">${isOnline ? 'ONLINE' : 'OFFLINE'}</span>
            </div>
        `;
    }
    container.innerHTML = html;
}

// ── FTP 관리 ───────────────────────────────────────
async function ftpStartServer() {
    const result = await fetchAPI('/ftp/start', { method: 'POST' });
    addLog(result.status === 'running' ? 'success' : 'error',
        `FTP 서버: ${result.status}`);
    loadProtocolStatus();
}

async function ftpStopServer() {
    const result = await fetchAPI('/ftp/stop', { method: 'POST' });
    addLog('info', `FTP 서버 중지: ${result.status}`);
    loadProtocolStatus();
}

async function ftpListFiles() {
    const result = await fetchAPI('/ftp/list');
    const container = document.getElementById('ftp-file-list');
    if (container && result.status === 'ok') {
        container.innerHTML = (result.files || []).map(f =>
            `<div class="protocol-status"><span class="protocol-name">${escapeHtml(f)}</span></div>`
        ).join('') || '<p style="color:var(--text-muted);">파일 없음</p>';
    }
}

// ── UDP 통신 ───────────────────────────────────────
async function udpStartServer() {
    const result = await fetchAPI('/udp/start', { method: 'POST' });
    addLog(result.status === 'running' ? 'success' : 'error',
        `UDP 서버: ${result.status}`);
    loadProtocolStatus();
}

async function udpSendMessage() {
    const host = document.getElementById('udp-target-host').value;
    const port = document.getElementById('udp-target-port').value;
    const message = document.getElementById('udp-message').value;

    if (!host || !port || !message) {
        addLog('warning', 'UDP: 모든 필드를 입력하세요');
        return;
    }

    const result = await fetchAPI('/udp/send', {
        method: 'POST',
        body: JSON.stringify({ host, port: parseInt(port), data: message }),
    });
    addLog(result.status === 'sent' ? 'success' : 'error',
        `UDP 전송: ${result.status} (${result.size || 0} bytes)`);
}

async function udpGetMessages() {
    const result = await fetchAPI('/udp/messages');
    const container = document.getElementById('udp-messages');
    if (container && result.status === 'ok') {
        container.innerHTML = (result.messages || []).map(m =>
            `<div class="protocol-status">
                <span class="log-time">[${m.timestamp}]</span>
                <span class="protocol-name">${m.from_ip}:${m.from_port}</span>
                <span class="protocol-detail">${escapeHtml(m.data).substring(0, 100)}</span>
            </div>`
        ).join('') || '<p style="color:var(--text-muted);">수신 메시지 없음</p>';
    }
}

// ── 컬렉션 생성/삭제 ──────────────────────────────
async function createCollection() {
    const name = document.getElementById('new-collection-name').value.trim();
    if (!name) {
        addLog('warning', '컬렉션 이름을 입력하세요');
        return;
    }

    const result = await fetchAPI('/mongo/collections', {
        method: 'POST',
        body: JSON.stringify({ name }),
    });

    if (result.status === 'created') {
        addLog('success', `컬렉션 생성: ${name}`);
        closeModal('create-collection-modal');
        loadCollections();
    } else {
        addLog('error', `컬렉션 생성 실패: ${result.message}`);
    }
}

function confirmDropCollection(name) {
    if (confirm(`정말 '${name}' 컬렉션을 삭제하시겠습니까?`)) {
        dropCollection(name);
    }
}

async function dropCollection(name) {
    const result = await fetchAPI(`/mongo/collections/${name}`, { method: 'DELETE' });
    if (result.status === 'dropped') {
        addLog('success', `컬렉션 삭제: ${name}`);
        loadCollections();
    }
}

// ── 문서 CRUD ──────────────────────────────────────
async function insertDocument() {
    const collection = document.getElementById('insert-collection').value;
    const docText = document.getElementById('insert-document').value;

    try {
        const doc = JSON.parse(docText);
        const result = await fetchAPI('/mongo/insert', {
            method: 'POST',
            body: JSON.stringify({ collection, document: doc }),
        });

        if (result.status === 'inserted') {
            addLog('success', `문서 삽입: ${result.id}`);
            closeModal('insert-document-modal');
            browseCollection(collection);
        }
    } catch (e) {
        addLog('error', `JSON 파싱 오류: ${e.message}`);
    }
}

async function deleteDocument(id) {
    const collection = document.getElementById('doc-collection-select').value;
    if (!confirm('이 문서를 삭제하시겠습니까?')) return;

    const result = await fetchAPI('/mongo/delete', {
        method: 'POST',
        body: JSON.stringify({ collection, query: { _id: id } }),
    });

    if (result.status === 'deleted') {
        addLog('success', '문서 삭제 완료');
        browseCollection(collection);
    }
}

// ── 모달 관리 ──────────────────────────────────────
function openModal(id) {
    document.getElementById(id).classList.add('active');
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
}

// ── 테마 토글 ──────────────────────────────────────
function toggleTheme() {
    state.darkMode = !state.darkMode;
    document.body.classList.toggle('light-theme', !state.darkMode);
    addLog('info', `테마 변경: ${state.darkMode ? '다크' : '라이트'}`);
}

// ── 자동 새로고침 ──────────────────────────────────
function toggleAutoRefresh() {
    if (state.refreshInterval) {
        clearInterval(state.refreshInterval);
        state.refreshInterval = null;
        addLog('info', '자동 새로고침 중지');
    } else {
        state.refreshInterval = setInterval(() => {
            loadPageData(state.currentPage);
        }, state.refreshRate);
        addLog('info', `자동 새로고침 시작 (${state.refreshRate / 1000}초)`);
    }
}

// ── 탭 전환 ────────────────────────────────────────
function switchTab(tabGroup, tabId) {
    document.querySelectorAll(`[data-tab-group="${tabGroup}"] .tab-btn`).forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tabId);
    });
    document.querySelectorAll(`[data-tab-content="${tabGroup}"]`).forEach(content => {
        content.classList.toggle('active', content.id === tabId);
    });
}

// ============================================================
// 차트 초기화 (Chart.js)
// ============================================================
function initCharts() {
    // 연결 수 차트 (개요 페이지)
    const connCtx = document.getElementById('chart-connections');
    if (connCtx && window.Chart) {
        new Chart(connCtx, {
            type: 'line',
            data: {
                labels: ['1분전', '50초', '40초', '30초', '20초', '10초', '현재'],
                datasets: [{
                    label: 'MongoDB 연결',
                    data: [12, 15, 13, 17, 14, 16, 15],
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59,130,246,0.1)',
                    fill: true,
                    tension: 0.4,
                }, {
                    label: 'FTP 연결',
                    data: [3, 2, 4, 3, 5, 3, 4],
                    borderColor: '#22c55e',
                    backgroundColor: 'rgba(34,197,94,0.1)',
                    fill: true,
                    tension: 0.4,
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { labels: { color: '#a0a3ab', font: { size: 11 } } }
                },
                scales: {
                    x: { ticks: { color: '#6b7280' }, grid: { color: '#2d323b' } },
                    y: { ticks: { color: '#6b7280' }, grid: { color: '#2d323b' } }
                }
            }
        });
    }

    // 프로토콜 트래픽 차트
    const trafficCtx = document.getElementById('chart-traffic');
    if (trafficCtx && window.Chart) {
        new Chart(trafficCtx, {
            type: 'doughnut',
            data: {
                labels: ['MongoDB', 'FTP', 'UDP', 'TCP', 'HTTP', 'WebSocket'],
                datasets: [{
                    data: [45, 15, 20, 10, 8, 2],
                    backgroundColor: ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#a855f7', '#06b6d4'],
                    borderWidth: 0,
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: { color: '#a0a3ab', font: { size: 11 }, padding: 12 }
                    }
                }
            }
        });
    }

    // 작업량 차트
    const opsCtx = document.getElementById('chart-operations');
    if (opsCtx && window.Chart) {
        new Chart(opsCtx, {
            type: 'bar',
            data: {
                labels: ['Insert', 'Find', 'Update', 'Delete', 'Aggregate'],
                datasets: [{
                    label: '작업 수',
                    data: [120, 450, 80, 25, 60],
                    backgroundColor: ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#a855f7'],
                    borderRadius: 6,
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    x: { ticks: { color: '#6b7280' }, grid: { display: false } },
                    y: { ticks: { color: '#6b7280' }, grid: { color: '#2d323b' } }
                }
            }
        });
    }
}

// ============================================================
// 초기화
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    addLog('info', 'ManimoHub 대시보드 초기화...');

    // 네비게이션 이벤트
    document.querySelectorAll('.nav-item').forEach(el => {
        el.addEventListener('click', () => navigate(el.dataset.page));
    });

    // 차트 초기화
    setTimeout(initCharts, 500);

    // 초기 페이지 로드
    navigate('overview');

    addLog('success', '대시보드 준비 완료');
});
