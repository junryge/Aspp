"""
반도체 AI 개인비서 — MCP Manager
Manages MCP server connections and tool execution.
"""

import json
import asyncio
import logging
import time
import threading
from pathlib import Path
from typing import Optional

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

logger = logging.getLogger("semi-ai.mcp")


class MCPManager:
    """Manages MCP server lifecycle and tool calls."""

    def __init__(self, tools_dir: str = "./mcp_tools"):
        self.tools_dir = Path(tools_dir)
        self.servers: dict[str, dict] = {}
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._contexts: dict[str, tuple] = {}

    def _ensure_loop(self):
        """Ensure we have a running event loop in a background thread."""
        if self._loop and self._loop.is_running():
            return

        def run_loop(loop):
            asyncio.set_event_loop(loop)
            loop.run_forever()

        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(target=run_loop, args=(self._loop,), daemon=True)
        self._thread.start()

    def _run_async(self, coro):
        """Run async coroutine from sync context."""
        self._ensure_loop()
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result(timeout=30)

    # ── Scanning ──

    def scan_configs(self) -> list[dict]:
        """Scan mcp_tools/ for .json server configs."""
        configs = []
        if not self.tools_dir.exists():
            self.tools_dir.mkdir(parents=True, exist_ok=True)
            return configs

        for f in sorted(self.tools_dir.glob("*.json")):
            if f.name.startswith("_"):
                continue
            try:
                with open(f, encoding="utf-8") as fh:
                    cfg = json.load(fh)
                cfg["_file"] = str(f)
                cfg.setdefault("name", f.stem)
                cfg.setdefault("enabled", True)
                configs.append(cfg)
            except Exception as e:
                logger.warning(f"Config parse error {f}: {e}")
        return configs

    # ── Connection ──

    def connect(self, name: str, config: dict) -> dict:
        """Connect to an MCP server (sync wrapper)."""
        return self._run_async(self._connect(name, config))

    async def _connect(self, name: str, config: dict) -> dict:
        if name in self.servers:
            return {"status": "already_connected", "name": name, "tools": self.servers[name]["tools"]}

        command = config.get("command", "")
        args = config.get("args", [])
        env = config.get("env")
        cwd = config.get("cwd")

        if not command:
            raise ValueError(f"No command for '{name}'")

        server_params = StdioServerParameters(
            command=command, args=args, env=env, cwd=cwd
        )

        stdio_ctx = stdio_client(server_params)
        streams = await stdio_ctx.__aenter__()
        read_stream, write_stream = streams

        session = ClientSession(read_stream, write_stream)
        await session.__aenter__()
        await session.initialize()

        tools_result = await session.list_tools()
        tools = []
        for t in tools_result.tools:
            tools.append({
                "name": t.name,
                "description": t.description or "",
                "input_schema": t.inputSchema if hasattr(t, "inputSchema") else {}
            })

        self.servers[name] = {
            "session": session,
            "tools": tools,
            "config": config,
            "connected_at": time.time()
        }
        self._contexts[name] = (stdio_ctx, session)

        logger.info(f"✅ MCP '{name}' — {len(tools)} tools")
        return {"status": "connected", "name": name, "tools": tools}

    def disconnect(self, name: str):
        """Disconnect from an MCP server."""
        if name not in self.servers:
            return
        try:
            self._run_async(self._disconnect(name))
        except:
            pass
        self.servers.pop(name, None)
        self._contexts.pop(name, None)

    async def _disconnect(self, name: str):
        ctx = self._contexts.get(name)
        if ctx:
            session, stdio_ctx = ctx[1], ctx[0]
            try:
                await session.__aexit__(None, None, None)
            except:
                pass
            try:
                await stdio_ctx.__aexit__(None, None, None)
            except:
                pass

    def disconnect_all(self):
        for name in list(self.servers.keys()):
            self.disconnect(name)

    # ── Tool Calling ──

    def call_tool(self, server_name: str, tool_name: str, arguments: dict) -> str:
        """Call a tool on a connected server."""
        return self._run_async(self._call_tool(server_name, tool_name, arguments))

    async def _call_tool(self, server_name: str, tool_name: str, arguments: dict) -> str:
        if server_name not in self.servers:
            raise ValueError(f"Server '{server_name}' not connected")

        session = self.servers[server_name]["session"]
        result = await session.call_tool(tool_name, arguments)

        parts = []
        for content in result.content:
            if hasattr(content, "text"):
                parts.append(content.text)
            elif hasattr(content, "data"):
                parts.append(f"[binary: {len(content.data)} bytes]")
            else:
                parts.append(str(content))
        return "\n".join(parts)

    # ── Tool Registry ──

    def get_all_tools_openai(self) -> list[dict]:
        """Get all tools in OpenAI function-calling format."""
        all_tools = []
        for name, info in self.servers.items():
            for tool in info["tools"]:
                all_tools.append({
                    "type": "function",
                    "function": {
                        "name": f"{name}__{tool['name']}",
                        "description": f"[{name}] {tool['description']}",
                        "parameters": tool.get("input_schema", {"type": "object", "properties": {}})
                    }
                })
        return all_tools

    def resolve_tool(self, full_name: str) -> tuple[str, str]:
        """Parse 'server__tool' → (server_name, tool_name)."""
        if "__" in full_name:
            srv, tool = full_name.split("__", 1)
            return srv, tool
        for name, info in self.servers.items():
            for tool in info["tools"]:
                if tool["name"] == full_name:
                    return name, full_name
        raise ValueError(f"Tool not found: {full_name}")

    def total_tools(self) -> int:
        return sum(len(info["tools"]) for info in self.servers.values())

    # ── Config Save/Delete ──

    def save_config(self, name: str, config: dict):
        self.tools_dir.mkdir(parents=True, exist_ok=True)
        filepath = self.tools_dir / f"{name}.json"
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2, ensure_ascii=False)

    def delete_config(self, name: str):
        filepath = self.tools_dir / f"{name}.json"
        if filepath.exists():
            filepath.unlink()
        self.disconnect(name)
