"""
반도체 AI 개인비서 — LLM Client
Handles communication with SK Hynix internal LLM endpoints.
"""

import json
import threading
import http.client
from urllib.parse import urlparse
from typing import Callable, Optional


class LLMClient:
    """Synchronous LLM client with streaming support (thread-safe)."""

    def __init__(self):
        self.api_key: str = ""
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def chat(
        self,
        url: str,
        model: str,
        messages: list[dict],
        max_tokens: int = 4096,
        temperature: float = 0.7,
        stream: bool = True,
        tools: list[dict] | None = None,
        on_chunk: Callable[[str], None] | None = None,
        on_done: Callable[[str], None] | None = None,
        on_error: Callable[[str], None] | None = None,
        on_tool_call: Callable[[list], None] | None = None,
    ):
        """
        Send chat completion request.
        For streaming: calls on_chunk(delta) repeatedly, then on_done(full_text).
        For non-streaming: calls on_done(full_text) once.
        If tool_calls detected: calls on_tool_call(tool_calls_list).
        """
        self._cancel = False

        parsed = urlparse(url)
        host = parsed.hostname
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        path = parsed.path

        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "stream": stream,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"
            payload["stream"] = False  # No stream with tool use

        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")

        headers = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream" if stream and not tools else "application/json",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        try:
            if parsed.scheme == "https":
                import ssl
                conn = http.client.HTTPSConnection(host, port, timeout=120,
                    context=ssl.create_default_context())
            else:
                conn = http.client.HTTPConnection(host, port, timeout=120)

            conn.request("POST", path, body=body, headers=headers)
            resp = conn.getresponse()

            if resp.status != 200:
                err_body = resp.read().decode("utf-8", errors="replace")[:500]
                if on_error:
                    on_error(f"HTTP {resp.status}: {err_body}")
                return

            if stream and not tools:
                self._handle_stream(resp, on_chunk, on_done, on_error)
            else:
                self._handle_normal(resp, on_done, on_error, on_tool_call)

            conn.close()

        except Exception as e:
            if not self._cancel and on_error:
                on_error(str(e))

    def _handle_stream(self, resp, on_chunk, on_done, on_error):
        full = ""
        buf = ""
        while not self._cancel:
            chunk = resp.read(4096)
            if not chunk:
                break
            buf += chunk.decode("utf-8", errors="replace")
            lines = buf.split("\n")
            buf = lines[-1]

            for line in lines[:-1]:
                line = line.strip()
                if not line or line == "data: [DONE]":
                    continue
                if not line.startswith("data: "):
                    continue
                try:
                    data = json.loads(line[6:])
                    delta = data.get("choices", [{}])[0].get("delta", {}).get("content", "")
                    if delta:
                        full += delta
                        if on_chunk:
                            on_chunk(delta)
                except json.JSONDecodeError:
                    pass

        if on_done:
            on_done(full)

    def _handle_normal(self, resp, on_done, on_error, on_tool_call):
        raw = resp.read().decode("utf-8", errors="replace")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            if on_error:
                on_error(f"JSON 파싱 오류: {raw[:300]}")
            return

        choice = data.get("choices", [{}])[0]
        message = choice.get("message", {})
        finish = choice.get("finish_reason", "")

        tool_calls = message.get("tool_calls")
        if tool_calls and on_tool_call:
            on_tool_call(tool_calls)
            return

        content = message.get("content", "")
        if on_done:
            on_done(content)

    def chat_threaded(self, **kwargs):
        """Run chat in background thread."""
        t = threading.Thread(target=self.chat, kwargs=kwargs, daemon=True)
        t.start()
        return t
