# 🤖 반도체 AI 개인비서 v1.0

SK Hynix 내부 LLM + MCP 도구 연동 데스크톱 앱

## 구조

```
semi-ai/
├── main.py                 ← 메인 앱 (CustomTkinter GUI)
├── llm_client.py           ← LLM API 통신 (스트리밍 지원)
├── mcp_manager.py          ← MCP 서버 관리/도구 호출
├── mcp_example_server.py   ← 예제 MCP 서버 (테스트용)
├── config.json             ← 모델 설정
├── TOKEN.TXT               ← API 키 저장
├── chat_history.json       ← 대화 기록 (자동 생성)
├── run.bat                 ← Windows 실행
├── run.sh                  ← Linux/Mac 실행
└── mcp_tools/              ← MCP 서버 설정 폴더
    └── calculator.json     ← 예제 설정
```

## 설치 & 실행

```bash
# 의존성 설치
pip install customtkinter httpx mcp

# API 키 설정
echo "your-api-key" > TOKEN.TXT

# 실행
python main.py
```

또는 run.bat (Windows) / run.sh (Linux) 실행

## 모델

| ID     | 모델                              | Max Tokens |
|--------|-----------------------------------|------------|
| DEV    | Qwen3-Next-80B-A3B-Instruct      | 8192       |
| PROD   | Qwen3-235B-A22B-Instruct-2507    | 8192       |
| COMMON | gpt-oss-120b                      | 4096       |

## MCP 도구 연결

`mcp_tools/` 폴더에 JSON 설정 파일을 추가하면 앱에서 자동 인식합니다.

### JSON 형식

```json
{
  "name": "서버이름",
  "command": "python",
  "args": ["-m", "my_mcp_server"],
  "cwd": "/path/to/server",
  "env": {"KEY": "value"},
  "description": "설명",
  "enabled": true
}
```

### 예시들

**파일시스템 MCP:**
```json
{
  "name": "filesystem",
  "command": "npx",
  "args": ["-y", "@modelcontextprotocol/server-filesystem", "/home/user/docs"],
  "description": "파일 읽기/쓰기/검색"
}
```

**커스텀 Python MCP:**
```json
{
  "name": "data-analyzer",
  "command": "python",
  "args": ["my_analyzer.py"],
  "cwd": "/home/user/projects",
  "description": "데이터 분석 도구"
}
```

**포함된 예제 테스트:**
calculator.json의 `enabled`를 `true`로 바꾸고 앱 재시작, 또는 앱 내 MCP 관리 패널에서 연결

## 기능

- **3개 모델 전환**: DEV(80B) / PROD(235B) / COMMON(120B) 실시간 전환
- **MCP 도구 연동**: 폴더 지정 → JSON 자동 인식 → 연결/해제/추가/삭제
- **스트리밍 응답**: SSE 실시간 토큰 표시
- **Tool Calling Loop**: LLM이 MCP 도구 호출 → 결과 피드백 → 최대 5라운드
- **대화 히스토리**: 자동 저장/불러오기 (최근 50개)
- **System Prompt**: 커스터마이징 + Temperature 조절
- **Export**: Markdown 내보내기
- **TOKEN.TXT**: 파일 기반 API 키 관리

## 의존성

```
customtkinter >= 5.2
httpx >= 0.25
mcp >= 1.0
```

nanobot-ai 0.1.4 설치 시 `mcp`는 이미 포함됩니다.
