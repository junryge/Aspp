"""
═══════════════════════════════════════════════════════
  반도체 AI 개인비서 v1.0
  SK Hynix 내부 LLM + MCP 도구 연동 데스크톱 앱
═══════════════════════════════════════════════════════
"""

import os
import sys
import json
import time
import threading
import tkinter as tk
from tkinter import filedialog, messagebox
from datetime import datetime
from pathlib import Path

import customtkinter as ctk

from llm_client import LLMClient
from mcp_manager import MCPManager

# ─── Paths ───
BASE_DIR = Path(__file__).parent
CONFIG_PATH = BASE_DIR / "config.json"
TOKEN_PATH = BASE_DIR / "TOKEN.TXT"
HISTORY_PATH = BASE_DIR / "chat_history.json"

# ─── Theme ───
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# Colors
C = {
    "bg":       "#0c0c14",
    "bg1":      "#111119",
    "bg2":      "#181824",
    "bg3":      "#1f1f30",
    "bg4":      "#282840",
    "border":   "#2a2a3e",
    "text":     "#e4e4ee",
    "text2":    "#8888a8",
    "text3":    "#555570",
    "dev":      "#00d4ff",
    "prod":     "#ff6b8a",
    "common":   "#a78bfa",
    "green":    "#34d399",
    "red":      "#f87171",
    "orange":   "#fb923c",
    "yellow":   "#fbbf24",
}

MODELS = {
    "dev": {
        "url": "http://dev.hcp.llm.skhynix.com/v1/chat/completions",
        "model": "Qwen3-Next-80B-A3B-Instruct",
        "name": "DEV (80B)",
        "max_tokens": 8192,
        "color": C["dev"],
    },
    "prod": {
        "url": "http://dev.hcp.llm.skhynix.com/v1/chat/completions",
        "model": "Qwen3-235B-A22B-Instruct-2507",
        "name": "PROD (235B)",
        "max_tokens": 8192,
        "color": C["prod"],
    },
    "common": {
        "url": "http://dev.hcp.llm.skhynix.com/v1/chat/completions",
        "model": "gpt-oss-120b",
        "name": "COMMON (120B)",
        "max_tokens": 4096,
        "color": C["common"],
    },
}


# ═══════════════════════════════════════
# Scrollable Chat Frame
# ═══════════════════════════════════════

class ChatDisplay(ctk.CTkScrollableFrame):
    """Scrollable message display area."""

    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color=C["bg"], corner_radius=0, **kwargs)
        self.messages: list[tk.Frame] = []
        self._configure_scroll()

    def _configure_scroll(self):
        # Make scrollbar thin
        pass

    def add_message(self, role: str, text: str, timestamp: str = ""):
        """Add a message bubble."""
        if not timestamp:
            timestamp = datetime.now().strftime("%H:%M")

        frame = ctk.CTkFrame(self, fg_color="transparent", corner_radius=0)
        frame.pack(fill="x", padx=16, pady=(6, 2))

        # Header row
        hdr = ctk.CTkFrame(frame, fg_color="transparent")
        hdr.pack(fill="x", anchor="w")

        if role == "user":
            icon, name, color = "👤", "You", C["text2"]
        elif role == "tool":
            icon, name, color = "🔧", "Tool", C["orange"]
        else:
            icon, name, color = "🤖", "AI 비서", C["dev"]

        ctk.CTkLabel(hdr, text=icon, font=("", 14), text_color=color).pack(side="left", padx=(0, 4))
        ctk.CTkLabel(hdr, text=name, font=("JetBrains Mono", 11, "bold"), text_color=color).pack(side="left")
        ctk.CTkLabel(hdr, text=timestamp, font=("JetBrains Mono", 9), text_color=C["text3"]).pack(side="left", padx=(8, 0))

        # Body
        body = ctk.CTkLabel(
            frame, text=text, font=("Noto Sans KR", 13),
            text_color=C["text"], wraplength=680,
            justify="left", anchor="w"
        )
        body.pack(fill="x", padx=(24, 8), pady=(2, 0), anchor="w")

        self.messages.append(frame)
        self.after(50, self._scroll_bottom)
        return body  # Return body label for streaming updates

    def add_streaming_message(self) -> ctk.CTkLabel:
        """Add placeholder for streaming response."""
        frame = ctk.CTkFrame(self, fg_color="transparent", corner_radius=0)
        frame.pack(fill="x", padx=16, pady=(6, 2))

        hdr = ctk.CTkFrame(frame, fg_color="transparent")
        hdr.pack(fill="x", anchor="w")
        ctk.CTkLabel(hdr, text="🤖", font=("", 14), text_color=C["dev"]).pack(side="left", padx=(0, 4))
        ctk.CTkLabel(hdr, text="AI 비서", font=("JetBrains Mono", 11, "bold"), text_color=C["dev"]).pack(side="left")
        ts = datetime.now().strftime("%H:%M")
        ctk.CTkLabel(hdr, text=ts, font=("JetBrains Mono", 9), text_color=C["text3"]).pack(side="left", padx=(8, 0))

        body = ctk.CTkLabel(
            frame, text="⏳ 생성 중...", font=("Noto Sans KR", 13),
            text_color=C["text2"], wraplength=680,
            justify="left", anchor="w"
        )
        body.pack(fill="x", padx=(24, 8), pady=(2, 0), anchor="w")

        self.messages.append(frame)
        self.after(50, self._scroll_bottom)
        return body

    def clear_all(self):
        for m in self.messages:
            m.destroy()
        self.messages.clear()

    def _scroll_bottom(self):
        self._parent_canvas.yview_moveto(1.0)


# ═══════════════════════════════════════
# MCP Panel (Toplevel)
# ═══════════════════════════════════════

class MCPPanel(ctk.CTkToplevel):
    """MCP Tool Management Window."""

    def __init__(self, master, mcp_mgr: MCPManager, on_change=None):
        super().__init__(master)
        self.title("🔧 MCP 도구 관리")
        self.geometry("560x520")
        self.configure(fg_color=C["bg1"])
        self.mcp = mcp_mgr
        self.on_change = on_change
        self.transient(master)

        self._build_ui()
        self.refresh()
        self.after(100, self.focus)

    def _build_ui(self):
        # Directory
        dir_frame = ctk.CTkFrame(self, fg_color="transparent")
        dir_frame.pack(fill="x", padx=16, pady=(16, 8))

        ctk.CTkLabel(dir_frame, text="MCP 도구 폴더:", font=("JetBrains Mono", 11),
                     text_color=C["text2"]).pack(side="left")
        self.dir_entry = ctk.CTkEntry(dir_frame, font=("JetBrains Mono", 11), height=30,
                                       fg_color=C["bg3"], border_color=C["border"])
        self.dir_entry.pack(side="left", fill="x", expand=True, padx=(8, 4))
        self.dir_entry.insert(0, str(self.mcp.tools_dir))

        ctk.CTkButton(dir_frame, text="📂", width=34, height=30, command=self._browse_dir,
                      fg_color=C["bg3"], hover_color=C["bg4"], text_color=C["text2"]).pack(side="left")

        ctk.CTkButton(dir_frame, text="적용", width=50, height=30, command=self._apply_dir,
                      fg_color=C["bg3"], hover_color=C["bg4"], text_color=C["text"]).pack(side="left", padx=(4, 0))

        # Server list (scrollable)
        self.srv_frame = ctk.CTkScrollableFrame(self, fg_color=C["bg"], corner_radius=8)
        self.srv_frame.pack(fill="both", expand=True, padx=16, pady=8)

        # Add button
        btn_frame = ctk.CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill="x", padx=16, pady=(0, 12))

        ctk.CTkButton(btn_frame, text="+ MCP 서버 추가", height=34, command=self._open_add,
                      fg_color=C["bg3"], hover_color=C["bg4"], text_color=C["text"],
                      font=("JetBrains Mono", 11)).pack(fill="x")

    def refresh(self):
        for w in self.srv_frame.winfo_children():
            w.destroy()

        configs = self.mcp.scan_configs()
        connected = set(self.mcp.servers.keys())

        if not configs and not connected:
            ctk.CTkLabel(self.srv_frame, text="설정된 MCP 서버가 없습니다.\n'+ MCP 서버 추가'를 클릭하세요.",
                        font=("Noto Sans KR", 12), text_color=C["text3"]).pack(pady=30)
            return

        for cfg in configs:
            name = cfg["name"]
            is_conn = name in connected
            self._add_server_row(cfg, is_conn)

    def _add_server_row(self, cfg, is_connected):
        name = cfg["name"]
        frame = ctk.CTkFrame(self.srv_frame, fg_color=C["bg2"], corner_radius=8, height=70)
        frame.pack(fill="x", pady=3)
        frame.pack_propagate(False)

        inner = ctk.CTkFrame(frame, fg_color="transparent")
        inner.pack(fill="both", expand=True, padx=12, pady=8)

        # Left: status + info
        left = ctk.CTkFrame(inner, fg_color="transparent")
        left.pack(side="left", fill="y")

        dot_color = C["green"] if is_connected else C["red"]
        status = "● 연결됨" if is_connected else "○ 미연결"
        tools_count = len(self.mcp.servers.get(name, {}).get("tools", []))

        hdr = ctk.CTkFrame(left, fg_color="transparent")
        hdr.pack(anchor="w")
        ctk.CTkLabel(hdr, text=status, font=("JetBrains Mono", 9), text_color=dot_color).pack(side="left", padx=(0, 6))
        ctk.CTkLabel(hdr, text=name, font=("JetBrains Mono", 12, "bold"), text_color=C["text"]).pack(side="left")
        if is_connected:
            ctk.CTkLabel(hdr, text=f"({tools_count} tools)", font=("JetBrains Mono", 9),
                        text_color=C["text3"]).pack(side="left", padx=(6, 0))

        desc = cfg.get("description", f"{cfg.get('command', '')} {' '.join(cfg.get('args', []))}")
        ctk.CTkLabel(left, text=desc[:60], font=("JetBrains Mono", 9), text_color=C["text3"],
                    anchor="w").pack(anchor="w")

        # Right: buttons
        right = ctk.CTkFrame(inner, fg_color="transparent")
        right.pack(side="right")

        if is_connected:
            ctk.CTkButton(right, text="해제", width=50, height=28, font=("JetBrains Mono", 10),
                         fg_color=C["red"] + "22", hover_color=C["red"] + "44", text_color=C["red"],
                         border_width=1, border_color=C["red"] + "44",
                         command=lambda n=name: self._disconnect(n)).pack(side="left", padx=2)
        else:
            ctk.CTkButton(right, text="연결", width=50, height=28, font=("JetBrains Mono", 10),
                         fg_color=C["green"] + "22", hover_color=C["green"] + "44", text_color=C["green"],
                         border_width=1, border_color=C["green"] + "44",
                         command=lambda n=name, c=cfg: self._connect(n, c)).pack(side="left", padx=2)

        ctk.CTkButton(right, text="🗑", width=30, height=28, font=("", 12),
                     fg_color=C["bg3"], hover_color=C["red"] + "33", text_color=C["text3"],
                     command=lambda n=name: self._delete(n)).pack(side="left", padx=2)

    def _connect(self, name, config):
        try:
            self.mcp.connect(name, config)
            self.refresh()
            if self.on_change:
                self.on_change()
        except Exception as e:
            messagebox.showerror("연결 실패", str(e), parent=self)

    def _disconnect(self, name):
        self.mcp.disconnect(name)
        self.refresh()
        if self.on_change:
            self.on_change()

    def _delete(self, name):
        if messagebox.askyesno("삭제", f"'{name}' 설정을 삭제하시겠습니까?", parent=self):
            self.mcp.delete_config(name)
            self.refresh()
            if self.on_change:
                self.on_change()

    def _browse_dir(self):
        d = filedialog.askdirectory(parent=self, title="MCP 도구 폴더 선택")
        if d:
            self.dir_entry.delete(0, "end")
            self.dir_entry.insert(0, d)

    def _apply_dir(self):
        d = self.dir_entry.get().strip()
        if d:
            self.mcp.tools_dir = Path(d)
            self.refresh()

    def _open_add(self):
        win = ctk.CTkToplevel(self)
        win.title("MCP 서버 추가")
        win.geometry("420x360")
        win.configure(fg_color=C["bg1"])
        win.transient(self)

        pad = {"padx": 16, "pady": (8, 0)}

        ctk.CTkLabel(win, text="이름 *", font=("JetBrains Mono", 10), text_color=C["text2"]).pack(anchor="w", **pad)
        name_e = ctk.CTkEntry(win, font=("JetBrains Mono", 12), fg_color=C["bg3"], border_color=C["border"])
        name_e.pack(fill="x", padx=16)

        ctk.CTkLabel(win, text="Command *", font=("JetBrains Mono", 10), text_color=C["text2"]).pack(anchor="w", **pad)
        cmd_e = ctk.CTkEntry(win, font=("JetBrains Mono", 12), fg_color=C["bg3"], border_color=C["border"],
                             placeholder_text="python")
        cmd_e.pack(fill="x", padx=16)

        ctk.CTkLabel(win, text="Args (쉼표 구분)", font=("JetBrains Mono", 10), text_color=C["text2"]).pack(anchor="w", **pad)
        args_e = ctk.CTkEntry(win, font=("JetBrains Mono", 12), fg_color=C["bg3"], border_color=C["border"],
                              placeholder_text="-m, my_server, /path")
        args_e.pack(fill="x", padx=16)

        ctk.CTkLabel(win, text="설명", font=("JetBrains Mono", 10), text_color=C["text2"]).pack(anchor="w", **pad)
        desc_e = ctk.CTkEntry(win, font=("JetBrains Mono", 12), fg_color=C["bg3"], border_color=C["border"])
        desc_e.pack(fill="x", padx=16)

        def do_add():
            n = name_e.get().strip()
            c = cmd_e.get().strip()
            if not n or not c:
                messagebox.showwarning("입력 오류", "이름과 Command는 필수입니다.", parent=win)
                return
            a = [x.strip() for x in args_e.get().split(",") if x.strip()]
            config = {"name": n, "command": c, "args": a, "description": desc_e.get().strip(), "enabled": True}
            self.mcp.save_config(n, config)
            try:
                self.mcp.connect(n, config)
            except Exception as e:
                messagebox.showwarning("연결 실패", f"설정은 저장됨. 연결 오류: {e}", parent=win)
            win.destroy()
            self.refresh()
            if self.on_change:
                self.on_change()

        btn_f = ctk.CTkFrame(win, fg_color="transparent")
        btn_f.pack(fill="x", padx=16, pady=16)
        ctk.CTkButton(btn_f, text="취소", width=80, fg_color=C["bg3"], hover_color=C["bg4"],
                     text_color=C["text2"], command=win.destroy).pack(side="right")
        ctk.CTkButton(btn_f, text="추가 & 연결", width=110, fg_color=C["green"] + "22",
                     hover_color=C["green"] + "44", text_color=C["green"],
                     border_width=1, border_color=C["green"] + "44",
                     command=do_add).pack(side="right", padx=(0, 8))


# ═══════════════════════════════════════
# Main Application
# ═══════════════════════════════════════

class SemiAIApp(ctk.CTk):
    """반도체 AI 개인비서 Main Window."""

    def __init__(self):
        super().__init__()

        self.title("반도체 AI 개인비서")
        self.geometry("1100x720")
        self.minsize(800, 500)
        self.configure(fg_color=C["bg"])

        # State
        self.current_model = "dev"
        self.api_key = ""
        self.chat_history: list[dict] = []  # [{id, title, model, messages}]
        self.current_chat_id: str | None = None
        self.is_generating = False
        self.streaming_label: ctk.CTkLabel | None = None
        self.stream_text = ""
        self.settings = {
            "stream": True,
            "sys_prompt": True,
            "use_mcp": True,
            "sys_msg": "당신은 SK Hynix 반도체 전문 AI 비서입니다. 한국어로 정확하고 실용적인 답변을 제공합니다.",
            "temperature": 0.7,
        }

        # Modules
        self.llm = LLMClient()
        self.mcp = MCPManager(str(BASE_DIR / "mcp_tools"))

        # Load state
        self._load_token()
        self._load_history()

        # Build UI
        self._build_ui()
        self._update_model_buttons()
        self._update_history_list()
        self._update_api_status()
        self._update_mcp_badge()

        # Auto-connect MCP servers
        self.after(500, self._auto_connect_mcp)

        # Focus input
        self.after(200, lambda: self.input_box.focus())

        # Window close
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ─── UI Build ───

    def _build_ui(self):
        # Main grid: sidebar | content
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self._build_sidebar()
        self._build_main()

    def _build_sidebar(self):
        sb = ctk.CTkFrame(self, width=250, fg_color=C["bg1"], corner_radius=0,
                          border_width=1, border_color=C["border"])
        sb.grid(row=0, column=0, sticky="nsw")
        sb.grid_propagate(False)

        # ── Logo ──
        logo_f = ctk.CTkFrame(sb, fg_color="transparent")
        logo_f.pack(fill="x", padx=14, pady=(14, 0))

        ctk.CTkLabel(logo_f, text="🤖", font=("", 28)).pack(side="left", padx=(0, 8))
        title_f = ctk.CTkFrame(logo_f, fg_color="transparent")
        title_f.pack(side="left")
        ctk.CTkLabel(title_f, text="반도체 AI 개인비서", font=("Noto Sans KR", 15, "bold"),
                    text_color=C["text"]).pack(anchor="w")
        ctk.CTkLabel(title_f, text="SK Hynix · MCP 연동", font=("JetBrains Mono", 9),
                    text_color=C["text3"]).pack(anchor="w")

        # Divider
        ctk.CTkFrame(sb, height=1, fg_color=C["border"]).pack(fill="x", padx=14, pady=10)

        # ── Model Buttons ──
        ctk.CTkLabel(sb, text="MODEL", font=("JetBrains Mono", 9, "bold"),
                    text_color=C["text3"]).pack(anchor="w", padx=16)

        self.model_btns: dict[str, ctk.CTkButton] = {}
        for mid, mcfg in MODELS.items():
            btn = ctk.CTkButton(
                sb, text=f"  ● {mcfg['name']}", anchor="w", height=36,
                font=("JetBrains Mono", 11), fg_color="transparent",
                hover_color=C["bg4"], text_color=C["text2"],
                command=lambda m=mid: self._select_model(m)
            )
            btn.pack(fill="x", padx=10, pady=1)
            self.model_btns[mid] = btn

        # Divider
        ctk.CTkFrame(sb, height=1, fg_color=C["border"]).pack(fill="x", padx=14, pady=10)

        # ── MCP Tools ──
        mcp_f = ctk.CTkFrame(sb, fg_color="transparent")
        mcp_f.pack(fill="x", padx=10)

        self.mcp_btn = ctk.CTkButton(
            mcp_f, text="🔧 MCP 도구 관리", anchor="w", height=34,
            font=("JetBrains Mono", 11), fg_color=C["bg3"],
            hover_color=C["bg4"], text_color=C["text2"],
            border_width=1, border_color=C["border"],
            command=self._open_mcp_panel
        )
        self.mcp_btn.pack(side="left", fill="x", expand=True)

        self.mcp_badge = ctk.CTkLabel(mcp_f, text="0", font=("JetBrains Mono", 9, "bold"),
                                       text_color=C["green"], width=28)
        self.mcp_badge.pack(side="right")

        # Divider
        ctk.CTkFrame(sb, height=1, fg_color=C["border"]).pack(fill="x", padx=14, pady=10)

        # ── Chat History ──
        hist_hdr = ctk.CTkFrame(sb, fg_color="transparent")
        hist_hdr.pack(fill="x", padx=14)
        ctk.CTkLabel(hist_hdr, text="HISTORY", font=("JetBrains Mono", 9, "bold"),
                    text_color=C["text3"]).pack(side="left")
        ctk.CTkButton(hist_hdr, text="+ New", width=56, height=24, font=("JetBrains Mono", 10),
                     fg_color=C["bg3"], hover_color=C["bg4"], text_color=C["text2"],
                     command=self._new_chat).pack(side="right")

        self.hist_frame = ctk.CTkScrollableFrame(sb, fg_color="transparent", corner_radius=0)
        self.hist_frame.pack(fill="both", expand=True, padx=6, pady=(4, 0))

        # ── Bottom ──
        bot = ctk.CTkFrame(sb, fg_color="transparent")
        bot.pack(fill="x", side="bottom", padx=10, pady=10)

        # API Status
        self.api_btn = ctk.CTkButton(
            bot, text="🔑 API Key 설정", anchor="w", height=30,
            font=("JetBrains Mono", 10), fg_color=C["bg3"],
            hover_color=C["bg4"], text_color=C["text2"],
            border_width=1, border_color=C["border"],
            command=self._open_api_dialog
        )
        self.api_btn.pack(fill="x", pady=(0, 6))

        # Setting toggles
        sets_f = ctk.CTkFrame(bot, fg_color="transparent")
        sets_f.pack(fill="x")

        self.toggle_vars = {}
        for key, label in [("stream", "Stream"), ("sys_prompt", "Sys Prompt"), ("use_mcp", "MCP Auto")]:
            row = ctk.CTkFrame(sets_f, fg_color="transparent")
            row.pack(fill="x", pady=1)
            ctk.CTkLabel(row, text=label, font=("JetBrains Mono", 10),
                        text_color=C["text2"]).pack(side="left")
            var = ctk.BooleanVar(value=self.settings[key])
            self.toggle_vars[key] = var
            sw = ctk.CTkSwitch(row, text="", variable=var, width=40, height=20,
                              switch_width=36, switch_height=18,
                              command=lambda k=key: self._toggle_setting(k))
            sw.pack(side="right")

    def _build_main(self):
        main = ctk.CTkFrame(self, fg_color=C["bg"], corner_radius=0)
        main.grid(row=0, column=1, sticky="nsew")
        main.grid_rowconfigure(1, weight=1)
        main.grid_columnconfigure(0, weight=1)

        # ── Top Bar ──
        top = ctk.CTkFrame(main, height=44, fg_color=C["bg1"], corner_radius=0,
                           border_width=0)
        top.grid(row=0, column=0, sticky="ew")
        top.grid_propagate(False)

        top_inner = ctk.CTkFrame(top, fg_color="transparent")
        top_inner.pack(fill="both", expand=True, padx=14)

        self.top_model_lbl = ctk.CTkLabel(top_inner, text="", font=("JetBrains Mono", 11, "bold"))
        self.top_model_lbl.pack(side="left")

        self.top_title_lbl = ctk.CTkLabel(top_inner, text="New Chat", font=("Noto Sans KR", 12),
                                          text_color=C["text2"])
        self.top_title_lbl.pack(side="left", padx=(12, 0))

        self.top_tools_lbl = ctk.CTkLabel(top_inner, text="", font=("JetBrains Mono", 9),
                                          text_color=C["text3"])
        self.top_tools_lbl.pack(side="left", padx=(10, 0))

        # Right buttons
        ctk.CTkButton(top_inner, text="↓", width=30, height=28, font=("", 14),
                     fg_color="transparent", hover_color=C["bg4"],
                     text_color=C["text2"], command=self._export_chat).pack(side="right", padx=2)
        ctk.CTkButton(top_inner, text="✕", width=30, height=28, font=("", 14),
                     fg_color="transparent", hover_color=C["bg4"],
                     text_color=C["text2"], command=self._clear_chat).pack(side="right", padx=2)
        ctk.CTkButton(top_inner, text="⚙", width=30, height=28, font=("", 14),
                     fg_color="transparent", hover_color=C["bg4"],
                     text_color=C["text2"], command=self._open_sys_prompt_dialog).pack(side="right", padx=2)

        # Separator
        ctk.CTkFrame(main, height=1, fg_color=C["border"]).grid(row=0, column=0, sticky="sew")

        # ── Chat Display ──
        self.chat_display = ChatDisplay(main)
        self.chat_display.grid(row=1, column=0, sticky="nsew")

        # Show welcome
        self._show_welcome()

        # ── Input Area ──
        input_frame = ctk.CTkFrame(main, fg_color=C["bg1"], corner_radius=0, height=90)
        input_frame.grid(row=2, column=0, sticky="sew")
        input_frame.grid_propagate(False)

        # Separator
        ctk.CTkFrame(input_frame, height=1, fg_color=C["border"]).pack(fill="x")

        box = ctk.CTkFrame(input_frame, fg_color=C["bg3"], corner_radius=10,
                           border_width=1, border_color=C["border"])
        box.pack(fill="x", padx=16, pady=(10, 4), ipady=2)

        self.input_box = ctk.CTkTextbox(
            box, height=38, font=("Noto Sans KR", 13),
            fg_color="transparent", text_color=C["text"],
            border_width=0, wrap="word"
        )
        self.input_box.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=4)
        self.input_box.bind("<Return>", self._on_enter)
        self.input_box.bind("<Shift-Return>", lambda e: None)

        self.send_btn = ctk.CTkButton(
            box, text="▶", width=38, height=34, font=("", 14),
            fg_color=C["dev"], hover_color=C["dev"] + "cc",
            text_color=C["bg"], corner_radius=8,
            command=self._handle_send
        )
        self.send_btn.pack(side="right", padx=6, pady=4)

        # Hint
        hint_f = ctk.CTkFrame(input_frame, fg_color="transparent")
        hint_f.pack(fill="x", padx=20)
        ctk.CTkLabel(hint_f, text="Enter 전송 · Shift+Enter 줄바꿈",
                    font=("JetBrains Mono", 9), text_color=C["text3"]).pack(side="left")
        self.status_lbl = ctk.CTkLabel(hint_f, text="", font=("JetBrains Mono", 9),
                                       text_color=C["text3"])
        self.status_lbl.pack(side="right")

    # ─── Welcome ───

    def _show_welcome(self):
        self.chat_display.clear_all()
        w = ctk.CTkFrame(self.chat_display, fg_color="transparent")
        w.pack(expand=True, pady=60)

        ctk.CTkLabel(w, text="🤖", font=("", 48)).pack()
        ctk.CTkLabel(w, text="반도체 AI 개인비서", font=("Noto Sans KR", 22, "bold"),
                    text_color=C["text"]).pack(pady=(8, 4))
        ctk.CTkLabel(w, text="SK Hynix 내부 LLM + MCP 도구로 구동됩니다",
                    font=("Noto Sans KR", 12), text_color=C["text2"]).pack()

        qa_f = ctk.CTkFrame(w, fg_color="transparent")
        qa_f.pack(pady=24)

        quick_actions = [
            ("📋", "오늘 할 일 정리해줘"),
            ("🔍", "Python 코드를 리뷰해줘"),
            ("✉️", "이메일 초안 작성해줘"),
            ("🔧", "연결된 MCP 도구 알려줘"),
        ]
        for i, (icon, text) in enumerate(quick_actions):
            r, c = divmod(i, 2)
            btn = ctk.CTkButton(
                qa_f, text=f" {icon}  {text}", anchor="w", width=220, height=42,
                font=("Noto Sans KR", 11), fg_color=C["bg2"],
                hover_color=C["bg4"], text_color=C["text2"],
                border_width=1, border_color=C["border"],
                command=lambda t=text: self._quick_send(t)
            )
            btn.grid(row=r, column=c, padx=4, pady=3)

    # ─── Model ───

    def _select_model(self, mid):
        self.current_model = mid
        self._update_model_buttons()

    def _update_model_buttons(self):
        for mid, btn in self.model_btns.items():
            m = MODELS[mid]
            if mid == self.current_model:
                btn.configure(fg_color=m["color"] + "18", text_color=m["color"],
                             border_width=1, border_color=m["color"] + "44")
            else:
                btn.configure(fg_color="transparent", text_color=C["text2"],
                             border_width=0, border_color="transparent")

        m = MODELS[self.current_model]
        self.top_model_lbl.configure(text=m["name"], text_color=m["color"])
        self.send_btn.configure(fg_color=m["color"])

    # ─── Chat ───

    def _get_current_chat(self):
        if not self.current_chat_id:
            return None
        return next((c for c in self.chat_history if c["id"] == self.current_chat_id), None)

    def _new_chat(self):
        chat = {
            "id": f"{int(time.time())}_{len(self.chat_history)}",
            "title": "New Chat",
            "model": self.current_model,
            "messages": [],
        }
        self.chat_history.insert(0, chat)
        self.current_chat_id = chat["id"]
        self._show_welcome()
        self._update_history_list()
        self.input_box.focus()

    def _select_chat(self, cid):
        self.current_chat_id = cid
        chat = self._get_current_chat()
        if chat:
            self.current_model = chat.get("model", "dev")
            self._update_model_buttons()
            self._render_chat_messages(chat)
        self._update_history_list()

    def _render_chat_messages(self, chat):
        self.chat_display.clear_all()
        if not chat["messages"]:
            self._show_welcome()
            return
        for m in chat["messages"]:
            self.chat_display.add_message(m["role"], m["content"], m.get("time", ""))

    def _clear_chat(self):
        chat = self._get_current_chat()
        if chat:
            chat["messages"] = []
            chat["title"] = "New Chat"
            self._show_welcome()
            self._update_history_list()
            self._save_history()

    def _update_history_list(self):
        for w in self.hist_frame.winfo_children():
            w.destroy()

        self.top_title_lbl.configure(text=self._get_current_chat()["title"] if self._get_current_chat() else "New Chat")

        for chat in self.chat_history:
            f = ctk.CTkFrame(self.hist_frame, fg_color="transparent")
            f.pack(fill="x", pady=1)

            is_active = chat["id"] == self.current_chat_id
            fg = C["bg3"] if is_active else "transparent"
            tc = C["text"] if is_active else C["text2"]

            btn = ctk.CTkButton(
                f, text=f"💬 {chat['title'][:28]}", anchor="w", height=30,
                font=("Noto Sans KR", 10), fg_color=fg,
                hover_color=C["bg4"], text_color=tc,
                command=lambda cid=chat["id"]: self._select_chat(cid)
            )
            btn.pack(side="left", fill="x", expand=True)

            del_btn = ctk.CTkButton(
                f, text="✕", width=24, height=24, font=("", 10),
                fg_color="transparent", hover_color=C["red"] + "33",
                text_color=C["text3"],
                command=lambda cid=chat["id"]: self._delete_chat(cid)
            )
            del_btn.pack(side="right")

    def _delete_chat(self, cid):
        self.chat_history = [c for c in self.chat_history if c["id"] != cid]
        if self.current_chat_id == cid:
            self.current_chat_id = self.chat_history[0]["id"] if self.chat_history else None
            if self.current_chat_id:
                self._render_chat_messages(self._get_current_chat())
            else:
                self._show_welcome()
        self._update_history_list()
        self._save_history()

    # ─── Send ───

    def _on_enter(self, event):
        if event.state & 0x1:  # Shift held
            return
        self._handle_send()
        return "break"

    def _handle_send(self):
        if self.is_generating:
            self.llm.cancel()
            self._set_generating(False)
            return

        text = self.input_box.get("1.0", "end").strip()
        if not text:
            return

        self.input_box.delete("1.0", "end")

        if not self.api_key:
            self._open_api_dialog()
            return

        if not self.current_chat_id:
            self._new_chat()

        chat = self._get_current_chat()
        chat["model"] = self.current_model

        # Add user message
        ts = datetime.now().strftime("%H:%M")
        chat["messages"].append({"role": "user", "content": text, "time": ts})
        if len(chat["messages"]) == 1:
            chat["title"] = text[:32] + ("..." if len(text) > 32 else "")
            self._update_history_list()

        # Render
        if len(chat["messages"]) == 1:
            self.chat_display.clear_all()
        self.chat_display.add_message("user", text, ts)

        self._set_generating(True)
        self._send_to_llm(chat)

    def _quick_send(self, text):
        if not self.current_chat_id:
            self._new_chat()
        self.input_box.delete("1.0", "end")
        self.input_box.insert("1.0", text)
        self._handle_send()

    def _send_to_llm(self, chat):
        """Send messages to LLM in background thread."""
        model = MODELS[self.current_model]

        # Build messages
        api_msgs = []
        if self.settings["sys_prompt"] and self.settings["sys_msg"]:
            api_msgs.append({"role": "system", "content": self.settings["sys_msg"]})

        # Last 20 user/assistant messages
        context = [m for m in chat["messages"] if m["role"] in ("user", "assistant")][-20:]
        for m in context:
            api_msgs.append({"role": m["role"], "content": m["content"]})

        # MCP tools
        tools = None
        if self.settings["use_mcp"] and self.mcp.servers:
            tools = self.mcp.get_all_tools_openai()

        self.llm.api_key = self.api_key
        self.stream_text = ""
        self.streaming_label = self.chat_display.add_streaming_message()

        def on_chunk(delta):
            self.stream_text += delta
            self.after(0, lambda: self._update_stream(self.stream_text))

        def on_done(full):
            ts = datetime.now().strftime("%H:%M")
            final = full or self.stream_text
            chat["messages"].append({"role": "assistant", "content": final, "time": ts})

            def finish():
                self._set_generating(False)
                self._render_chat_messages(chat)
                self._save_history()

            self.after(0, finish)

        def on_error(err):
            ts = datetime.now().strftime("%H:%M")
            msg = f"⚠️ 오류: {err}\n\n모델: {model['name']}"
            chat["messages"].append({"role": "assistant", "content": msg, "time": ts})

            def finish():
                self._set_generating(False)
                self._render_chat_messages(chat)

            self.after(0, finish)

        def on_tool_call(tool_calls):
            """Handle LLM requesting tool calls."""
            self.after(0, lambda: self._handle_tool_calls(chat, api_msgs, model, tool_calls))

        self.llm.chat_threaded(
            url=model["url"],
            model=model["model"],
            messages=api_msgs,
            max_tokens=model["max_tokens"],
            temperature=self.settings["temperature"],
            stream=self.settings["stream"] and not tools,
            tools=tools,
            on_chunk=on_chunk,
            on_done=on_done,
            on_error=on_error,
            on_tool_call=on_tool_call,
        )

    def _handle_tool_calls(self, chat, api_msgs, model, tool_calls, round_num=0):
        """Execute MCP tool calls and feed results back to LLM."""
        if round_num >= 5:
            ts = datetime.now().strftime("%H:%M")
            chat["messages"].append({"role": "assistant", "content": "⚠️ 도구 호출 횟수 제한(5회) 도달", "time": ts})
            self._set_generating(False)
            self._render_chat_messages(chat)
            return

        # Add assistant tool call to context
        tc_msg = {"role": "assistant", "content": "", "tool_calls": tool_calls}
        api_msgs.append(tc_msg)

        # Execute each tool
        for tc in tool_calls:
            func = tc.get("function", {})
            full_name = func.get("name", "")
            try:
                args = json.loads(func.get("arguments", "{}"))
            except:
                args = {}

            try:
                srv, tool_name = self.mcp.resolve_tool(full_name)
                result = self.mcp.call_tool(srv, tool_name, args)
                self.after(0, lambda r=result, n=full_name:
                    self._update_stream(f"🔧 {n}: {r[:200]}"))
            except Exception as e:
                result = f"Error: {e}"

            api_msgs.append({
                "role": "tool",
                "tool_call_id": tc.get("id", ""),
                "content": result
            })

        # Send back to LLM with tool results
        tools = self.mcp.get_all_tools_openai() if self.mcp.servers else None
        self.stream_text = ""

        def on_done2(full):
            ts = datetime.now().strftime("%H:%M")
            chat["messages"].append({"role": "assistant", "content": full, "time": ts})
            def finish():
                self._set_generating(False)
                self._render_chat_messages(chat)
                self._save_history()
            self.after(0, finish)

        def on_error2(err):
            ts = datetime.now().strftime("%H:%M")
            chat["messages"].append({"role": "assistant", "content": f"⚠️ 도구 결과 처리 오류: {err}", "time": ts})
            def finish():
                self._set_generating(False)
                self._render_chat_messages(chat)
            self.after(0, finish)

        def on_tool_call2(more_calls):
            self.after(0, lambda: self._handle_tool_calls(chat, api_msgs, model, more_calls, round_num + 1))

        self.llm.chat_threaded(
            url=model["url"], model=model["model"],
            messages=api_msgs, max_tokens=model["max_tokens"],
            temperature=self.settings["temperature"],
            stream=False, tools=tools,
            on_done=on_done2, on_error=on_error2, on_tool_call=on_tool_call2,
        )

    def _update_stream(self, text):
        if self.streaming_label and self.streaming_label.winfo_exists():
            display = text if len(text) <= 2000 else text[-2000:]
            self.streaming_label.configure(text=display, text_color=C["text"])
            self.chat_display._scroll_bottom()

    def _set_generating(self, val):
        self.is_generating = val
        if val:
            self.send_btn.configure(text="■", fg_color=C["red"])
            self.status_lbl.configure(text="생성 중...")
        else:
            m = MODELS[self.current_model]
            self.send_btn.configure(text="▶", fg_color=m["color"])
            self.status_lbl.configure(text="")
            self.streaming_label = None
            self.stream_text = ""

    # ─── API Key ───

    def _load_token(self):
        if TOKEN_PATH.exists():
            self.api_key = TOKEN_PATH.read_text().strip()
        self.llm.api_key = self.api_key

    def _open_api_dialog(self):
        dialog = ctk.CTkInputDialog(
            text="TOKEN.TXT 또는 API Key 입력:",
            title="🔑 API Key 설정",
        )
        val = dialog.get_input()
        if val and val.strip():
            self.api_key = val.strip()
            self.llm.api_key = self.api_key
            TOKEN_PATH.write_text(self.api_key)
            self._update_api_status()

    def _update_api_status(self):
        if self.api_key:
            masked = self.api_key[:8] + "..." if len(self.api_key) > 8 else "***"
            self.api_btn.configure(text=f"🟢 {masked}", text_color=C["green"])
        else:
            self.api_btn.configure(text="🔴 API Key 설정", text_color=C["red"])

    # ─── MCP ───

    def _auto_connect_mcp(self):
        def do():
            configs = self.mcp.scan_configs()
            for cfg in configs:
                if cfg.get("enabled", True):
                    try:
                        self.mcp.connect(cfg["name"], cfg)
                    except Exception as e:
                        print(f"MCP auto-connect failed '{cfg['name']}': {e}")
            self.after(0, self._update_mcp_badge)

        threading.Thread(target=do, daemon=True).start()

    def _open_mcp_panel(self):
        MCPPanel(self, self.mcp, on_change=self._update_mcp_badge)

    def _update_mcp_badge(self):
        total = self.mcp.total_tools()
        self.mcp_badge.configure(text=str(total))
        servers = ", ".join(self.mcp.servers.keys())
        self.top_tools_lbl.configure(text=f"🔧 {total} tools" if total else "")
        if total:
            self.status_lbl.configure(text=f"MCP: {servers}")

    # ─── System Prompt ───

    def _open_sys_prompt_dialog(self):
        win = ctk.CTkToplevel(self)
        win.title("⚙ System Prompt")
        win.geometry("480x320")
        win.configure(fg_color=C["bg1"])
        win.transient(self)

        ctk.CTkLabel(win, text="System Message", font=("JetBrains Mono", 10),
                    text_color=C["text2"]).pack(anchor="w", padx=16, pady=(16, 4))
        sys_tb = ctk.CTkTextbox(win, height=140, font=("Noto Sans KR", 12),
                                fg_color=C["bg3"], text_color=C["text"], border_color=C["border"])
        sys_tb.pack(fill="x", padx=16)
        sys_tb.insert("1.0", self.settings["sys_msg"])

        ctk.CTkLabel(win, text="Temperature (0.0 ~ 1.0)", font=("JetBrains Mono", 10),
                    text_color=C["text2"]).pack(anchor="w", padx=16, pady=(12, 4))
        temp_e = ctk.CTkEntry(win, font=("JetBrains Mono", 12), fg_color=C["bg3"],
                              border_color=C["border"], width=80)
        temp_e.pack(anchor="w", padx=16)
        temp_e.insert(0, str(self.settings["temperature"]))

        def save():
            self.settings["sys_msg"] = sys_tb.get("1.0", "end").strip()
            try:
                self.settings["temperature"] = float(temp_e.get())
            except:
                pass
            win.destroy()

        ctk.CTkButton(win, text="저장", width=80, fg_color=C["dev"],
                     text_color=C["bg"], command=save).pack(pady=16)

    # ─── Settings ───

    def _toggle_setting(self, key):
        self.settings[key] = self.toggle_vars[key].get()

    # ─── Export ───

    def _export_chat(self):
        chat = self._get_current_chat()
        if not chat or not chat["messages"]:
            return

        path = filedialog.asksaveasfilename(
            defaultextension=".md",
            filetypes=[("Markdown", "*.md"), ("Text", "*.txt")],
            initialfile=f"chat_{chat['id']}.md"
        )
        if not path:
            return

        md = f"# {chat['title']}\n> Model: {MODELS.get(chat['model'], {}).get('name', chat['model'])}\n\n"
        for m in chat["messages"]:
            role = "👤 You" if m["role"] == "user" else "🤖 AI 비서"
            md += f"### {role} ({m.get('time', '')})\n\n{m['content']}\n\n---\n\n"

        with open(path, "w", encoding="utf-8") as f:
            f.write(md)
        self.status_lbl.configure(text=f"✓ 내보내기 완료")
        self.after(3000, lambda: self.status_lbl.configure(text=""))

    # ─── Persistence ───

    def _save_history(self):
        try:
            # Keep last 50 chats
            data = self.chat_history[:50]
            with open(HISTORY_PATH, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
        except Exception as e:
            print(f"History save error: {e}")

    def _load_history(self):
        try:
            if HISTORY_PATH.exists():
                with open(HISTORY_PATH, "r", encoding="utf-8") as f:
                    self.chat_history = json.load(f)
                if self.chat_history:
                    self.current_chat_id = self.chat_history[0]["id"]
        except:
            self.chat_history = []

    # ─── Cleanup ───

    def _on_close(self):
        self._save_history()
        self.mcp.disconnect_all()
        self.destroy()


# ═══════════════════════════════════════
# Entry Point
# ═══════════════════════════════════════

if __name__ == "__main__":
    app = SemiAIApp()
    app.mainloop()
