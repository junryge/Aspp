"""
반도체 AI 개인비서 — 예제 MCP 서버
계산기/단위변환/시간 도구 (테스트용)

mcp_tools/calculator.json 으로 등록:
{
  "name": "calculator",
  "command": "python",
  "args": ["mcp_example_server.py"],
  "description": "계산기, 단위변환, 시간 도구",
  "enabled": true
}
"""

import asyncio
import math
from datetime import datetime

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp import types

server = Server("calculator")


@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name="calculate",
            description="수학 계산 (사칙연산, 제곱, 제곱근, 삼각함수 등)",
            inputSchema={
                "type": "object",
                "properties": {
                    "expression": {"type": "string", "description": "수식 (예: 2+3*4, sqrt(144), 2**10)"}
                },
                "required": ["expression"]
            }
        ),
        types.Tool(
            name="unit_convert",
            description="단위 변환 (길이, 무게, 온도)",
            inputSchema={
                "type": "object",
                "properties": {
                    "value": {"type": "number", "description": "값"},
                    "from_unit": {"type": "string", "description": "원래 단위"},
                    "to_unit": {"type": "string", "description": "변환 단위"}
                },
                "required": ["value", "from_unit", "to_unit"]
            }
        ),
        types.Tool(
            name="datetime_now",
            description="현재 날짜/시간 정보",
            inputSchema={"type": "object", "properties": {}}
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    if name == "calculate":
        expr = arguments.get("expression", "")
        try:
            ns = {"__builtins__": {}, "abs": abs, "round": round, "min": min, "max": max, "pow": pow}
            ns.update({k: getattr(math, k) for k in ["sqrt", "sin", "cos", "tan", "log", "log10", "pi", "e", "ceil", "floor", "factorial"]})
            result = eval(expr, ns)
            return [types.TextContent(type="text", text=f"{expr} = {result}")]
        except Exception as e:
            return [types.TextContent(type="text", text=f"오류: {e}")]

    elif name == "unit_convert":
        v = arguments.get("value", 0)
        f, t = arguments.get("from_unit", "").lower(), arguments.get("to_unit", "").lower()
        convs = {
            ("km","mile"):lambda x:x*0.621371, ("mile","km"):lambda x:x*1.60934,
            ("kg","lb"):lambda x:x*2.20462, ("lb","kg"):lambda x:x*0.453592,
            ("celsius","fahrenheit"):lambda x:x*9/5+32, ("fahrenheit","celsius"):lambda x:(x-32)*5/9,
            ("m","ft"):lambda x:x*3.28084, ("ft","m"):lambda x:x*0.3048,
            ("cm","inch"):lambda x:x*0.393701, ("inch","cm"):lambda x:x*2.54,
            ("mm","inch"):lambda x:x*0.0393701, ("inch","mm"):lambda x:x*25.4,
        }
        fn = convs.get((f, t))
        if fn:
            return [types.TextContent(type="text", text=f"{v} {f} = {fn(v):.4f} {t}")]
        return [types.TextContent(type="text", text=f"미지원 변환: {f} → {t}")]

    elif name == "datetime_now":
        now = datetime.now()
        return [types.TextContent(type="text", text=f"{now.strftime('%Y-%m-%d %H:%M:%S')} ({now.strftime('%A')})")]

    return [types.TextContent(type="text", text=f"알 수 없는 도구: {name}")]


async def main():
    async with stdio_server() as (read, write):
        await server.run(read, write)

if __name__ == "__main__":
    asyncio.run(main())
