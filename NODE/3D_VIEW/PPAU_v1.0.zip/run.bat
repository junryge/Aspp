@echo off
title 반도체 AI 개인비서
echo ==========================================
echo   반도체 AI 개인비서 v1.0
echo   SK Hynix Internal LLM + MCP
echo ==========================================
echo.

cd /d "%~dp0"

REM Check TOKEN.TXT
if exist TOKEN.TXT (
    echo [OK] TOKEN.TXT 발견
) else (
    echo [!!] TOKEN.TXT 없음 - 앱에서 API Key 설정 필요
)

REM Check dependencies
python -c "import customtkinter" 2>nul
if errorlevel 1 (
    echo [설치] customtkinter 설치 중...
    pip install customtkinter httpx mcp
)

echo.
echo 앱 시작 중...
python main.py

pause
