#!/bin/bash
# 반도체 AI 개인비서 v1.0

echo "=========================================="
echo "  반도체 AI 개인비서 v1.0"
echo "  SK Hynix Internal LLM + MCP"
echo "=========================================="

cd "$(dirname "$0")"

# Check TOKEN.TXT
if [ -f TOKEN.TXT ]; then
    echo "[OK] TOKEN.TXT 발견"
else
    echo "[!!] TOKEN.TXT 없음 - 앱에서 API Key 설정 필요"
fi

# Check deps
python3 -c "import customtkinter" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "[설치] 의존성 설치 중..."
    pip install customtkinter httpx mcp
fi

echo ""
echo "앱 시작..."
python3 main.py
