@echo off
title 반도체 AI 개인비서
echo ==========================================
echo   반도체 AI 개인비서 v1.1
echo   SK Hynix Internal LLM + 내장 도구
echo ==========================================
echo.

cd /d "%~dp0"

if exist TOKEN.TXT (echo [OK] TOKEN.TXT 발견) else (echo [!!] TOKEN.TXT 없음)

python -c "import customtkinter" 2>nul
if errorlevel 1 (
    echo [설치] 패키지 설치 중...
    pip install customtkinter openpyxl pandas
)

echo.
echo 앱 시작...
python main.py
pause
