"""
반도체 AI 개인비서 — LLM Client
스트리밍 + 도구 자동 호출 루프 내장
"""

import json
import threading
import http.client
from urllib.parse import urlparse
from typing import Callable


class LLMClient:

    def __init__(self):
        self.api_key: str = ""
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def chat(
        self,
        url: str,
        model: str,
        messages: list[dict],
        max_tokens: int = 4096,
        temperature: float = 0.7,
        stream: bool = True,
        tools: list[dict] | None = None,
        tool_executor: Callable[[str, dict], str] | None = None,
        on_chunk: Callable[[str], None] | None = None,
        on_done: Callable[[str], None] | None = None,
        on_error: Callable[[str], None] | None = None,
        on_tool_log: Callable[[str, str, str], None] | None = None,
        max_tool_rounds: int = 5,
    ):
        """
        LLM 호출. 도구가 있으면 자동 루프.
        on_tool_log(tool_name, args_str, result_str) - 도구 호출 시 UI에 알림
        """
        self._cancel = False

        # 도구 있으면 스트리밍 끄기 (tool_calls 파싱 필요)
        use_stream = stream and not tools

        current_messages = list(messages)

        for round_num in range(max_tool_rounds + 1):
            if self._cancel:
                return

            payload = {
                "model": model,
                "messages": current_messages,
                "max_tokens": max_tokens,
                "temperature": temperature,
                "stream": use_stream,
            }
            if tools and round_num < max_tool_rounds:
                payload["tools"] = tools
                payload["tool_choice"] = "auto"

            try:
                resp = self._request(url, payload)
            except Exception as e:
                if on_error and not self._cancel:
                    on_error(str(e))
                return

            if use_stream and round_num == 0 and not tools:
                # 순수 스트리밍 (도구 없음)
                self._stream(resp, on_chunk, on_done, on_error)
                return

            # Non-streaming 응답 파싱
            raw = resp.read().decode("utf-8", errors="replace")
            try:
                data = json.loads(raw)
            except json.JSONDecodeError:
                if on_error:
                    on_error(f"JSON 파싱 오류: {raw[:300]}")
                return

            choice = data.get("choices", [{}])[0]
            message = choice.get("message", {})
            finish = choice.get("finish_reason", "")
            tool_calls = message.get("tool_calls")

            # 도구 호출이 없으면 최종 응답
            if not tool_calls or not tool_executor:
                content = message.get("content", "") or ""
                if on_done:
                    on_done(content)
                return

            # 도구 호출 실행
            current_messages.append(message)

            for tc in tool_calls:
                func = tc.get("function", {})
                tool_name = func.get("name", "")
                try:
                    args = json.loads(func.get("arguments", "{}"))
                except json.JSONDecodeError:
                    args = {}

                args_str = json.dumps(args, ensure_ascii=False)[:200]

                try:
                    result = tool_executor(tool_name, args)
                except Exception as e:
                    result = f"오류: {e}"

                if on_tool_log:
                    on_tool_log(tool_name, args_str, result[:300])

                current_messages.append({
                    "role": "tool",
                    "tool_call_id": tc.get("id", ""),
                    "content": result
                })

            # 마지막 라운드면 도구 없이 최종 호출
            if round_num == max_tool_rounds - 1:
                tools = None

        # 라운드 초과
        if on_done:
            on_done("⚠️ 도구 호출 횟수 제한에 도달했습니다.")

    def _request(self, url: str, payload: dict):
        parsed = urlparse(url)
        host = parsed.hostname
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        path = parsed.path

        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if payload.get("stream"):
            headers["Accept"] = "text/event-stream"
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        if parsed.scheme == "https":
            import ssl
            conn = http.client.HTTPSConnection(host, port, timeout=120,
                                                context=ssl.create_default_context())
        else:
            conn = http.client.HTTPConnection(host, port, timeout=120)

        conn.request("POST", path, body=body, headers=headers)
        resp = conn.getresponse()

        if resp.status != 200:
            err = resp.read().decode("utf-8", errors="replace")[:500]
            raise ConnectionError(f"HTTP {resp.status}: {err}")

        return resp

    def _stream(self, resp, on_chunk, on_done, on_error):
        full = ""
        buf = ""
        while not self._cancel:
            chunk = resp.read(4096)
            if not chunk:
                break
            buf += chunk.decode("utf-8", errors="replace")
            lines = buf.split("\n")
            buf = lines[-1]
            for line in lines[:-1]:
                line = line.strip()
                if not line or line == "data: [DONE]":
                    continue
                if not line.startswith("data: "):
                    continue
                try:
                    data = json.loads(line[6:])
                    delta = data.get("choices", [{}])[0].get("delta", {}).get("content", "")
                    if delta:
                        full += delta
                        if on_chunk:
                            on_chunk(delta)
                except json.JSONDecodeError:
                    pass
        if on_done:
            on_done(full)

    def chat_threaded(self, **kwargs):
        t = threading.Thread(target=self.chat, kwargs=kwargs, daemon=True)
        t.start()
        return t
