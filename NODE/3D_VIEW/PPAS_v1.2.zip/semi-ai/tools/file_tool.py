"""
반도체 AI 개인비서 — 파일 도구
파일 탐색, 읽기, 쓰기, 검색
"""

import os
import glob
from datetime import datetime
from pathlib import Path

WORK_DIR = os.getcwd()


def set_work_dir(path: str):
    global WORK_DIR
    WORK_DIR = path


def _resolve(filename: str) -> str:
    p = Path(filename)
    if not p.is_absolute():
        p = Path(WORK_DIR) / p
    return str(p)


# ═══════════════════════════════════════
# 도구 정의
# ═══════════════════════════════════════

TOOLS = [
    {
        "name": "file_list",
        "description": "폴더 내 파일/디렉토리 목록을 보여줍니다 (크기, 수정일 포함)",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "폴더 경로 (미지정=작업폴더)", "default": ""},
                "pattern": {"type": "string", "description": "파일 패턴 (예: *.py, *.log, *report*)", "default": "*"},
                "recursive": {"type": "boolean", "description": "하위 폴더 포함 여부", "default": False}
            }
        }
    },
    {
        "name": "file_read",
        "description": "텍스트 파일 내용을 읽습니다 (txt, py, json, xml, csv, log, md, yaml 등)",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "파일 경로"},
                "start_line": {"type": "integer", "description": "시작 줄 번호 (1부터)", "default": 1},
                "end_line": {"type": "integer", "description": "끝 줄 번호 (0=전체)", "default": 0},
                "max_lines": {"type": "integer", "description": "최대 줄 수", "default": 200}
            },
            "required": ["file"]
        }
    },
    {
        "name": "file_write",
        "description": "파일에 텍스트를 씁니다 (새 파일 생성 또는 덮어쓰기)",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "파일 경로"},
                "content": {"type": "string", "description": "쓸 내용"},
                "mode": {"type": "string", "description": "w=덮어쓰기, a=추가", "default": "w"}
            },
            "required": ["file", "content"]
        }
    },
    {
        "name": "file_search",
        "description": "파일 내용에서 텍스트를 검색합니다 (grep 기능)",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "검색할 폴더 또는 파일 경로"},
                "keyword": {"type": "string", "description": "검색어"},
                "pattern": {"type": "string", "description": "파일 패턴 (예: *.py)", "default": "*"},
                "case_sensitive": {"type": "boolean", "default": False},
                "max_results": {"type": "integer", "default": 50}
            },
            "required": ["path", "keyword"]
        }
    },
    {
        "name": "file_info",
        "description": "파일 상세 정보 (크기, 줄 수, 인코딩, 수정일)",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "파일 경로"}
            },
            "required": ["file"]
        }
    },
    {
        "name": "file_tree",
        "description": "폴더 구조를 트리 형태로 보여줍니다",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "폴더 경로", "default": ""},
                "max_depth": {"type": "integer", "description": "최대 깊이", "default": 3},
                "show_hidden": {"type": "boolean", "default": False}
            }
        }
    },
]


# ═══════════════════════════════════════
# 실행
# ═══════════════════════════════════════

def execute(name: str, a: dict) -> str:

    if name == "file_list":
        target = a.get("path", "") or WORK_DIR
        target = _resolve(target) if not Path(target).is_absolute() else target
        pat = a.get("pattern", "*")
        recursive = a.get("recursive", False)

        if not os.path.isdir(target):
            return f"❌ 폴더 없음: {target}"

        if recursive:
            items = glob.glob(os.path.join(target, "**", pat), recursive=True)
        else:
            items = glob.glob(os.path.join(target, pat))

        items = sorted(items)[:200]

        lines = [f"📁 {target}\n"]
        dirs, files = [], []
        for item in items:
            if os.path.isdir(item):
                dirs.append(item)
            else:
                files.append(item)

        for d in dirs[:30]:
            n = os.path.basename(d)
            lines.append(f"  📂 {n}/")

        for f in files[:100]:
            p = Path(f)
            try:
                sz = p.stat().st_size
                mod = datetime.fromtimestamp(p.stat().st_mtime).strftime("%m-%d %H:%M")
                s = f"{sz / 1e6:.1f}MB" if sz > 1e6 else f"{sz // 1000}KB" if sz > 1000 else f"{sz}B"
                rel = os.path.relpath(f, target)
                lines.append(f"  📄 {rel}  ({s}, {mod})")
            except:
                lines.append(f"  📄 {os.path.basename(f)}")

        return "\n".join(lines) + f"\n\n폴더 {len(dirs)}개, 파일 {len(files)}개"

    elif name == "file_read":
        path = _resolve(a["file"])
        if not os.path.exists(path):
            return f"❌ 파일 없음: {path}"

        sz = os.path.getsize(path)
        if sz > 5_000_000:
            return f"❌ 파일 너무 큼: {sz / 1e6:.1f}MB (5MB 제한)"

        # Try multiple encodings
        content = None
        for enc in ["utf-8", "cp949", "euc-kr", "latin-1"]:
            try:
                with open(path, "r", encoding=enc) as f:
                    content = f.read()
                break
            except (UnicodeDecodeError, UnicodeError):
                continue

        if content is None:
            return f"❌ 인코딩 감지 실패: {path}"

        lines = content.split("\n")
        total = len(lines)
        start = max(1, a.get("start_line", 1))
        end = a.get("end_line", 0) or total
        mx = a.get("max_lines", 200)

        sel = lines[start - 1:end]
        if len(sel) > mx:
            sel = sel[:mx]
            truncated = True
        else:
            truncated = False

        # Add line numbers
        numbered = []
        for i, line in enumerate(sel, start=start):
            numbered.append(f"{i:>5} │ {line}")

        result = f"📄 {a['file']} ({total}줄)\n{'─' * 50}\n"
        result += "\n".join(numbered)
        if truncated:
            result += f"\n\n... ({mx}줄까지 표시, 총 {total}줄)"
        return result

    elif name == "file_write":
        path = _resolve(a["file"])
        mode = a.get("mode", "w")
        content = a.get("content", "")

        # Create parent dirs
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

        with open(path, mode, encoding="utf-8") as f:
            f.write(content)

        lines = content.count("\n") + 1
        return f"✅ {a['file']} 저장 완료 ({lines}줄, {len(content)}자)"

    elif name == "file_search":
        target = _resolve(a["path"])
        keyword = a["keyword"]
        pat = a.get("pattern", "*")
        case = a.get("case_sensitive", False)
        mx = a.get("max_results", 50)

        if not case:
            keyword_lower = keyword.lower()

        if os.path.isfile(target):
            search_files = [target]
        elif os.path.isdir(target):
            search_files = glob.glob(os.path.join(target, "**", pat), recursive=True)
            search_files = [f for f in search_files if os.path.isfile(f)]
        else:
            return f"❌ 경로 없음: {target}"

        results = []
        for filepath in search_files[:500]:
            try:
                with open(filepath, "r", encoding="utf-8", errors="replace") as f:
                    for i, line in enumerate(f, 1):
                        if case:
                            match = keyword in line
                        else:
                            match = keyword_lower in line.lower()
                        if match:
                            rel = os.path.relpath(filepath, WORK_DIR) if os.path.isdir(target) else os.path.basename(filepath)
                            results.append(f"  {rel}:{i}  {line.rstrip()[:120]}")
                            if len(results) >= mx:
                                break
                if len(results) >= mx:
                    break
            except:
                continue

        if not results:
            return f"🔍 '{keyword}' 결과 없음"

        return f"🔍 '{keyword}' → {len(results)}건\n\n" + "\n".join(results)

    elif name == "file_info":
        path = _resolve(a["file"])
        if not os.path.exists(path):
            return f"❌ 파일 없음: {path}"

        p = Path(path)
        stat = p.stat()
        sz = stat.st_size
        mod = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
        crt = datetime.fromtimestamp(stat.st_ctime).strftime("%Y-%m-%d %H:%M:%S")

        info = [
            f"📄 {p.name}",
            f"경로: {path}",
            f"크기: {sz:,} bytes ({sz / 1024:.1f}KB)",
            f"수정: {mod}",
            f"생성: {crt}",
            f"확장자: {p.suffix}",
        ]

        # Count lines for text files
        text_exts = {".txt", ".py", ".java", ".js", ".ts", ".json", ".xml", ".csv",
                     ".log", ".md", ".yaml", ".yml", ".ini", ".cfg", ".sql", ".sh", ".bat", ".html", ".css"}
        if p.suffix.lower() in text_exts:
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    line_count = sum(1 for _ in f)
                info.append(f"줄 수: {line_count:,}")
            except:
                pass

            # Detect encoding
            for enc in ["utf-8", "cp949", "euc-kr"]:
                try:
                    with open(path, "r", encoding=enc) as f:
                        f.read(1000)
                    info.append(f"인코딩: {enc}")
                    break
                except:
                    continue

        return "\n".join(info)

    elif name == "file_tree":
        target = a.get("path", "") or WORK_DIR
        target = _resolve(target) if not Path(target).is_absolute() else target
        max_depth = a.get("max_depth", 3)
        show_hidden = a.get("show_hidden", False)

        if not os.path.isdir(target):
            return f"❌ 폴더 없음: {target}"

        lines = [f"📂 {target}"]
        _tree(target, "", max_depth, 0, lines, show_hidden)
        if len(lines) > 200:
            lines = lines[:200]
            lines.append("... (200줄까지 표시)")
        return "\n".join(lines)

    return f"알 수 없는 도구: {name}"


def _tree(path, prefix, max_depth, depth, lines, show_hidden):
    if depth >= max_depth:
        return
    try:
        entries = sorted(os.listdir(path))
    except PermissionError:
        return

    if not show_hidden:
        entries = [e for e in entries if not e.startswith(".")]

    # Skip common noise
    skip = {"__pycache__", "node_modules", ".git", ".venv", "venv", ".idea"}
    entries = [e for e in entries if e not in skip]

    dirs = [e for e in entries if os.path.isdir(os.path.join(path, e))]
    files = [e for e in entries if os.path.isfile(os.path.join(path, e))]

    all_items = [(d, True) for d in dirs] + [(f, False) for f in files]

    for i, (name, is_dir) in enumerate(all_items):
        is_last = i == len(all_items) - 1
        connector = "└── " if is_last else "├── "
        icon = "📂" if is_dir else "📄"
        lines.append(f"{prefix}{connector}{icon} {name}")

        if is_dir:
            ext = "    " if is_last else "│   "
            _tree(os.path.join(path, name), prefix + ext, max_depth, depth + 1, lines, show_hidden)
