"""
반도체 AI 개인비서 — Excel 도구
엑셀/CSV 읽기, 쓰기, 분석, 생성

필요: pip install openpyxl pandas
"""

import os
import glob
from datetime import datetime
from pathlib import Path

import openpyxl
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
import pandas as pd

# ─── 작업 폴더 (config에서 설정) ───
WORK_DIR = os.getcwd()


def set_work_dir(path: str):
    global WORK_DIR
    WORK_DIR = path


def _resolve(filename: str) -> str:
    p = Path(filename)
    if not p.is_absolute():
        p = Path(WORK_DIR) / p
    return str(p)


def _read_df(file: str, sheet: str = "") -> pd.DataFrame:
    path = _resolve(file)
    if not os.path.exists(path):
        raise FileNotFoundError(f"파일 없음: {path}")
    if path.lower().endswith(".csv"):
        for enc in ["utf-8", "cp949", "euc-kr"]:
            try:
                return pd.read_csv(path, encoding=enc, on_bad_lines="skip", low_memory=False)
            except Exception:
                continue
        return pd.read_csv(path, encoding="utf-8", errors="replace")
    kw = {"sheet_name": sheet} if sheet else {"sheet_name": 0}
    return pd.read_excel(path, **kw)


def _fmt(df: pd.DataFrame, max_rows: int = 80) -> str:
    total = len(df)
    if total > max_rows:
        df = df.head(max_rows)
    txt = df.to_string(index=False, max_colwidth=35)
    note = f"\n\n[{min(total, max_rows)}/{total}행 | 컬럼: {', '.join(df.columns.astype(str))}]"
    return txt + note


# ═══════════════════════════════════════
# 도구 정의 (OpenAI function calling 형식)
# ═══════════════════════════════════════

TOOLS = [
    {
        "name": "excel_list_files",
        "description": "작업 폴더의 엑셀/CSV 파일 목록을 보여줍니다",
        "parameters": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "파일명 패턴 (예: *report*, *2025*)", "default": "*"}
            }
        }
    },
    {
        "name": "excel_get_info",
        "description": "엑셀 파일 정보 (시트 목록, 행/열 수, 헤더, 데이터 타입)",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "파일명 (예: data.xlsx)"}
            },
            "required": ["file"]
        }
    },
    {
        "name": "excel_read",
        "description": "엑셀 시트 데이터를 읽습니다. 전체 또는 셀 범위 지정 가능",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "파일명"},
                "sheet": {"type": "string", "description": "시트명 (미지정=첫번째)", "default": ""},
                "range": {"type": "string", "description": "셀 범위 (예: A1:D10)", "default": ""},
                "max_rows": {"type": "integer", "description": "최대 표시 행", "default": 80}
            },
            "required": ["file"]
        }
    },
    {
        "name": "excel_stats",
        "description": "숫자 컬럼의 통계 (합계, 평균, 최소, 최대, 표준편차, 사분위수)",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "파일명"},
                "sheet": {"type": "string", "default": ""},
                "columns": {"type": "string", "description": "컬럼명 쉼표 구분 (미지정=숫자 전체)", "default": ""}
            },
            "required": ["file"]
        }
    },
    {
        "name": "excel_search",
        "description": "엑셀에서 값을 검색합니다",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "파일명"},
                "keyword": {"type": "string", "description": "검색어"},
                "sheet": {"type": "string", "default": ""},
                "column": {"type": "string", "description": "검색할 컬럼 (미지정=전체)", "default": ""}
            },
            "required": ["file", "keyword"]
        }
    },
    {
        "name": "excel_filter",
        "description": "조건으로 데이터 필터링 (==, !=, >, <, >=, <=, contains)",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "파일명"},
                "sheet": {"type": "string", "default": ""},
                "column": {"type": "string", "description": "컬럼명"},
                "operator": {"type": "string", "description": "==, !=, >, <, >=, <=, contains", "default": "=="},
                "value": {"type": "string", "description": "비교값"},
                "max_rows": {"type": "integer", "default": 50}
            },
            "required": ["file", "column", "value"]
        }
    },
    {
        "name": "excel_sort",
        "description": "데이터를 정렬합니다 (결과 보기 또는 파일 저장)",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "파일명"},
                "sheet": {"type": "string", "default": ""},
                "column": {"type": "string", "description": "정렬 기준 컬럼"},
                "ascending": {"type": "boolean", "default": True},
                "save": {"type": "boolean", "description": "결과를 파일에 저장", "default": False},
                "max_rows": {"type": "integer", "default": 50}
            },
            "required": ["file", "column"]
        }
    },
    {
        "name": "excel_pivot",
        "description": "피벗 테이블 요약 (그룹별 합계/평균/건수 등)",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "파일명"},
                "sheet": {"type": "string", "default": ""},
                "group_by": {"type": "string", "description": "그룹 기준 컬럼"},
                "value_col": {"type": "string", "description": "집계할 값 컬럼"},
                "agg": {"type": "string", "description": "집계 함수: sum/mean/count/min/max", "default": "sum"}
            },
            "required": ["file", "group_by", "value_col"]
        }
    },
    {
        "name": "excel_write_cells",
        "description": "셀에 값을 씁니다 (단일/다중 셀)",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "파일명 (없으면 새로 생성)"},
                "sheet": {"type": "string", "default": ""},
                "cells": {
                    "type": "array",
                    "description": '[{"cell":"A1","value":"hello"},{"cell":"B2","value":100}]',
                    "items": {"type": "object"}
                }
            },
            "required": ["file", "cells"]
        }
    },
    {
        "name": "excel_write_rows",
        "description": "여러 행을 한번에 추가합니다",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "파일명"},
                "sheet": {"type": "string", "default": ""},
                "headers": {"type": "array", "items": {"type": "string"}, "description": "헤더 (첫 행일 때만)", "default": []},
                "rows": {"type": "array", "items": {"type": "array"}, "description": "데이터 행들"},
                "start_row": {"type": "integer", "description": "시작 행 (0=마지막 다음)", "default": 0}
            },
            "required": ["file", "rows"]
        }
    },
    {
        "name": "excel_create",
        "description": "새 엑셀 파일을 생성합니다 (헤더+데이터, 자동 서식)",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "파일명 (예: output.xlsx)"},
                "sheet_name": {"type": "string", "default": "Sheet1"},
                "headers": {"type": "array", "items": {"type": "string"}},
                "data": {"type": "array", "items": {"type": "array"}, "default": []}
            },
            "required": ["file", "headers"]
        }
    },
    {
        "name": "excel_delete_rows",
        "description": "행을 삭제합니다",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string"},
                "sheet": {"type": "string", "default": ""},
                "start_row": {"type": "integer", "description": "삭제 시작 행 (1부터)"},
                "count": {"type": "integer", "default": 1}
            },
            "required": ["file", "start_row"]
        }
    },
]


# ═══════════════════════════════════════
# 실행
# ═══════════════════════════════════════

def execute(name: str, a: dict) -> str:

    if name == "excel_list_files":
        pat = a.get("pattern", "*")
        files = []
        for ext in ["xlsx", "xls", "csv"]:
            files.extend(glob.glob(os.path.join(WORK_DIR, f"*{pat}*.{ext}")))
            if pat == "*":
                files.extend(glob.glob(os.path.join(WORK_DIR, f"*.{ext}")))
        files = sorted(set(files))
        if not files:
            return f"📁 {WORK_DIR}\n엑셀/CSV 파일 없음"
        lines = [f"📁 {WORK_DIR}\n"]
        for f in files:
            p = Path(f)
            sz = p.stat().st_size
            mod = datetime.fromtimestamp(p.stat().st_mtime).strftime("%m-%d %H:%M")
            s = f"{sz / 1_000_000:.1f}MB" if sz > 1e6 else f"{sz // 1000}KB" if sz > 1000 else f"{sz}B"
            lines.append(f"  {p.name}  ({s}, {mod})")
        return "\n".join(lines) + f"\n\n총 {len(files)}개"

    elif name == "excel_get_info":
        path = _resolve(a["file"])
        if path.lower().endswith(".csv"):
            df = _read_df(a["file"])
            return (f"📄 {a['file']} (CSV)\n행: {len(df)}, 열: {len(df.columns)}\n"
                    f"컬럼: {', '.join(df.columns.astype(str))}\n\n타입:\n{df.dtypes.to_string()}")
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        lines = [f"📄 {a['file']}  시트 {len(wb.sheetnames)}개\n"]
        for sn in wb.sheetnames:
            ws = wb[sn]
            lines.append(f"  [{sn}] {ws.max_row}행 × {ws.max_column}열")
            hdrs = [str(c.value) for c in ws[1] if c.value is not None][:20]
            if hdrs:
                lines.append(f"    헤더: {', '.join(hdrs)}")
        wb.close()
        return "\n".join(lines)

    elif name == "excel_read":
        rng = a.get("range", "")
        mx = a.get("max_rows", 80)
        if rng:
            path = _resolve(a["file"])
            wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
            sn = a.get("sheet", "") or wb.sheetnames[0]
            ws = wb[sn]
            rows = [[c.value for c in row] for row in ws[rng]]
            wb.close()
            if not rows:
                return "빈 범위"
            df = pd.DataFrame(rows[1:], columns=rows[0]) if len(rows) > 1 else pd.DataFrame(rows)
            return f"📊 {a['file']} [{sn}] {rng}\n\n{_fmt(df, mx)}"
        df = _read_df(a["file"], a.get("sheet", ""))
        return f"📊 {a['file']} ({len(df)}행 × {len(df.columns)}열)\n\n{_fmt(df, mx)}"

    elif name == "excel_stats":
        df = _read_df(a["file"], a.get("sheet", ""))
        cols = a.get("columns", "")
        if cols:
            cl = [c.strip() for c in cols.split(",")]
            dn = df[cl].select_dtypes(include=["number"])
        else:
            dn = df.select_dtypes(include=["number"])
        if dn.empty:
            return "숫자 컬럼 없음"
        st = dn.describe().T
        st["sum"] = dn.sum()
        st = st[["count", "sum", "mean", "std", "min", "25%", "50%", "75%", "max"]]
        return f"📈 {a['file']} 통계\n\n{st.to_string()}"

    elif name == "excel_search":
        kw = str(a["keyword"]).lower()
        df = _read_df(a["file"], a.get("sheet", ""))
        col = a.get("column", "")
        if col:
            mask = df[col].astype(str).str.lower().str.contains(kw, na=False)
        else:
            mask = df.apply(lambda r: any(kw in str(v).lower() for v in r), axis=1)
        found = df[mask]
        if found.empty:
            return f"'{a['keyword']}' 결과 없음"
        return f"🔍 '{a['keyword']}' → {len(found)}건\n\n{_fmt(found, 50)}"

    elif name == "excel_filter":
        df = _read_df(a["file"], a.get("sheet", ""))
        col, op, val = a["column"], a.get("operator", "=="), a["value"]
        mx = a.get("max_rows", 50)
        if col not in df.columns:
            return f"❌ 컬럼 '{col}' 없음. 사용 가능: {', '.join(df.columns.astype(str))}"
        if op == "contains":
            mask = df[col].astype(str).str.contains(str(val), case=False, na=False)
        else:
            try:
                vn = float(val)
                cd = pd.to_numeric(df[col], errors="coerce")
                ops = {"==": cd == vn, "!=": cd != vn, ">": cd > vn, "<": cd < vn, ">=": cd >= vn, "<=": cd <= vn}
                mask = ops.get(op, cd == vn)
            except (ValueError, TypeError):
                mask = df[col].astype(str) == str(val) if op == "==" else df[col].astype(str) != str(val)
        found = df[mask]
        return f"🔍 {col} {op} {val} → {len(found)}건\n\n{_fmt(found, mx)}"

    elif name == "excel_sort":
        df = _read_df(a["file"], a.get("sheet", ""))
        col = a["column"]
        asc = a.get("ascending", True)
        mx = a.get("max_rows", 50)
        if col not in df.columns:
            return f"❌ 컬럼 '{col}' 없음"
        df_s = df.sort_values(by=col, ascending=asc, na_position="last")
        if a.get("save", False):
            path = _resolve(a["file"])
            if path.lower().endswith(".csv"):
                df_s.to_csv(path, index=False, encoding="utf-8-sig")
            else:
                df_s.to_excel(path, index=False)
            return f"✅ 정렬 저장 완료 ({col} {'↑' if asc else '↓'})\n\n{_fmt(df_s, mx)}"
        return f"📊 정렬 결과 ({col} {'↑' if asc else '↓'})\n\n{_fmt(df_s, mx)}"

    elif name == "excel_pivot":
        df = _read_df(a["file"], a.get("sheet", ""))
        g, vc, ag = a["group_by"], a["value_col"], a.get("agg", "sum")
        for c in [g, vc]:
            if c not in df.columns:
                return f"❌ 컬럼 '{c}' 없음"
        df[vc] = pd.to_numeric(df[vc], errors="coerce")
        pv = df.groupby(g)[vc].agg(ag).reset_index()
        pv.columns = [g, f"{vc}_{ag}"]
        pv = pv.sort_values(f"{vc}_{ag}", ascending=False)
        return f"📊 피벗: {g} → {vc} ({ag})\n\n{pv.to_string(index=False)}"

    elif name == "excel_write_cells":
        path = _resolve(a["file"])
        wb = openpyxl.load_workbook(path) if os.path.exists(path) else openpyxl.Workbook()
        sn = a.get("sheet", "") or wb.sheetnames[0]
        if sn not in wb.sheetnames:
            wb.create_sheet(sn)
        ws = wb[sn]
        written = []
        for item in a.get("cells", []):
            ws[item["cell"]] = item["value"]
            written.append(f"{item['cell']}={item['value']}")
        wb.save(path)
        return f"✅ {a['file']} 저장 → {', '.join(written)}"

    elif name == "excel_write_rows":
        path = _resolve(a["file"])
        wb = openpyxl.load_workbook(path) if os.path.exists(path) else openpyxl.Workbook()
        sn = a.get("sheet", "") or wb.sheetnames[0]
        if sn not in wb.sheetnames:
            wb.create_sheet(sn)
        ws = wb[sn]
        start = a.get("start_row", 0)
        if start <= 0:
            start = (ws.max_row or 0) + 1
        hdrs = a.get("headers", [])
        if hdrs:
            for j, h in enumerate(hdrs):
                ws.cell(row=start, column=j + 1, value=h).font = Font(bold=True)
            start += 1
        rows = a.get("rows", [])
        for i, row in enumerate(rows):
            for j, val in enumerate(row):
                ws.cell(row=start + i, column=j + 1, value=val)
        wb.save(path)
        return f"✅ {a['file']} — {len(rows)}행 추가"

    elif name == "excel_create":
        path = _resolve(a["file"])
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = a.get("sheet_name", "Sheet1")
        headers = a.get("headers", [])
        hdr_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
        hdr_font = Font(bold=True, color="FFFFFF", size=11)
        thin = Side(style="thin", color="CCCCCC")
        hdr_border = Border(bottom=Side(style="medium", color="1F4E79"))
        for j, h in enumerate(headers):
            c = ws.cell(row=1, column=j + 1, value=h)
            c.font = hdr_font
            c.fill = hdr_fill
            c.alignment = Alignment(horizontal="center")
            c.border = hdr_border
        data = a.get("data", [])
        for i, row in enumerate(data):
            for j, val in enumerate(row):
                ws.cell(row=i + 2, column=j + 1, value=val)
        for ci in range(1, len(headers) + 1):
            mx = len(str(headers[ci - 1])) if ci <= len(headers) else 8
            for ri in range(2, len(data) + 2):
                cv = ws.cell(row=ri, column=ci).value
                if cv:
                    mx = max(mx, len(str(cv)))
            ws.column_dimensions[get_column_letter(ci)].width = min(mx + 4, 50)
        ws.auto_filter.ref = ws.dimensions
        wb.save(path)
        return f"✅ {a['file']} 생성 완료 ({len(headers)}열, {len(data)}행)"

    elif name == "excel_delete_rows":
        path = _resolve(a["file"])
        wb = openpyxl.load_workbook(path)
        sn = a.get("sheet", "") or wb.sheetnames[0]
        ws = wb[sn]
        sr, cnt = a["start_row"], a.get("count", 1)
        ws.delete_rows(sr, cnt)
        wb.save(path)
        return f"✅ {a['file']} 행 {sr}~{sr + cnt - 1} 삭제"

    return f"알 수 없는 도구: {name}"
