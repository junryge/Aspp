"""
반도체 AI 개인비서 — 코드 분석 도구
코드 구조 분석, 함수/클래스 추출, 복잡도 측정, diff 비교
"""

import os
import re
import ast
import glob
import difflib
from pathlib import Path
from collections import Counter

WORK_DIR = os.getcwd()


def set_work_dir(path: str):
    global WORK_DIR
    WORK_DIR = path


def _resolve(filename: str) -> str:
    p = Path(filename)
    if not p.is_absolute():
        p = Path(WORK_DIR) / p
    return str(p)


def _read(filepath: str) -> str:
    path = _resolve(filepath)
    if not os.path.exists(path):
        raise FileNotFoundError(f"파일 없음: {path}")
    for enc in ["utf-8", "cp949", "euc-kr", "latin-1"]:
        try:
            with open(path, "r", encoding=enc) as f:
                return f.read()
        except (UnicodeDecodeError, UnicodeError):
            continue
    raise ValueError(f"인코딩 감지 실패: {path}")


# ═══════════════════════════════════════
# 도구 정의
# ═══════════════════════════════════════

TOOLS = [
    {
        "name": "code_analyze",
        "description": "코드 파일의 구조를 분석합니다 (함수, 클래스, import, 줄 수, 복잡도). Python/Java/JS/C 등 지원",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "코드 파일 경로"}
            },
            "required": ["file"]
        }
    },
    {
        "name": "code_functions",
        "description": "파일에서 함수/메서드 목록을 추출합니다 (이름, 줄 번호, 파라미터, docstring)",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "코드 파일 경로"},
                "include_body": {"type": "boolean", "description": "함수 본문도 포함", "default": False}
            },
            "required": ["file"]
        }
    },
    {
        "name": "code_classes",
        "description": "파일에서 클래스 목록을 추출합니다 (이름, 메서드, 상속 관계)",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "코드 파일 경로"}
            },
            "required": ["file"]
        }
    },
    {
        "name": "code_diff",
        "description": "두 파일의 차이점을 비교합니다 (unified diff)",
        "parameters": {
            "type": "object",
            "properties": {
                "file1": {"type": "string", "description": "첫번째 파일"},
                "file2": {"type": "string", "description": "두번째 파일"},
                "context_lines": {"type": "integer", "description": "차이 주변 표시할 줄 수", "default": 3}
            },
            "required": ["file1", "file2"]
        }
    },
    {
        "name": "code_find_pattern",
        "description": "코드에서 특정 패턴을 찾습니다 (정규식 지원). TODO, FIXME, 특정 함수 호출 등",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "파일 또는 폴더 경로"},
                "pattern": {"type": "string", "description": "검색 패턴 (정규식 가능). 예: TODO, def .*test, import\\s+os"},
                "file_pattern": {"type": "string", "description": "파일 확장자 필터 (예: *.py, *.java)", "default": "*"},
                "max_results": {"type": "integer", "default": 50}
            },
            "required": ["path", "pattern"]
        }
    },
    {
        "name": "code_stats",
        "description": "프로젝트/폴더의 코드 통계 (언어별 파일 수, 줄 수, 빈 줄, 주석 줄)",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "폴더 경로"},
                "extensions": {"type": "string", "description": "분석할 확장자 쉼표 구분 (미지정=자동)", "default": ""}
            },
            "required": ["path"]
        }
    },
    {
        "name": "code_dependencies",
        "description": "Python 파일의 import/의존성 목록을 추출합니다",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "Python 파일 경로"}
            },
            "required": ["file"]
        }
    },
    {
        "name": "code_complexity",
        "description": "Python 함수별 순환 복잡도(Cyclomatic Complexity)를 측정합니다",
        "parameters": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "Python 파일 경로"}
            },
            "required": ["file"]
        }
    },
]


# ═══════════════════════════════════════
# 실행
# ═══════════════════════════════════════

def execute(name: str, a: dict) -> str:

    # ── code_analyze ──
    if name == "code_analyze":
        content = _read(a["file"])
        lines = content.split("\n")
        ext = Path(a["file"]).suffix.lower()
        total = len(lines)
        blank = sum(1 for l in lines if not l.strip())
        comment = _count_comments(lines, ext)
        code_lines = total - blank - comment

        info = [
            f"📊 {a['file']} 분석",
            f"{'─' * 40}",
            f"총 줄 수:    {total:>6}",
            f"코드 줄:     {code_lines:>6}",
            f"빈 줄:       {blank:>6}",
            f"주석 줄:     {comment:>6}",
            f"파일 크기:   {len(content):>6} bytes",
            f"확장자:      {ext}",
        ]

        # Python-specific deep analysis
        if ext == ".py":
            try:
                tree = ast.parse(content)
                funcs = [n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
                classes = [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]
                imports = [n for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))]

                info.append(f"\n🐍 Python 구조")
                info.append(f"클래스:      {len(classes):>6}")
                info.append(f"함수/메서드: {len(funcs):>6}")
                info.append(f"import:      {len(imports):>6}")

                if classes:
                    info.append(f"\n클래스 목록:")
                    for c in classes:
                        methods = [n.name for n in c.body if isinstance(n, ast.FunctionDef)]
                        bases = [_get_name(b) for b in c.bases]
                        info.append(f"  class {c.name}({', '.join(bases)})  [줄 {c.lineno}] — 메서드 {len(methods)}개")

                if funcs:
                    info.append(f"\n함수 목록:")
                    for f in funcs[:30]:
                        params = [arg.arg for arg in f.args.args]
                        info.append(f"  def {f.name}({', '.join(params)})  [줄 {f.lineno}]")

            except SyntaxError as e:
                info.append(f"\n⚠️ 구문 오류: {e}")

        # Java
        elif ext == ".java":
            cls = re.findall(r'(?:public|private|protected)?\s*class\s+(\w+)', content)
            methods = re.findall(r'(?:public|private|protected)\s+\w+\s+(\w+)\s*\(', content)
            info.append(f"\n☕ Java 구조")
            info.append(f"클래스: {len(cls)}: {', '.join(cls[:10])}")
            info.append(f"메서드: {len(methods)}: {', '.join(methods[:20])}")

        # JS/TS
        elif ext in (".js", ".ts", ".jsx", ".tsx"):
            funcs = re.findall(r'(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\()', content)
            classes = re.findall(r'class\s+(\w+)', content)
            info.append(f"\n📜 JS/TS 구조")
            info.append(f"클래스: {len(classes)}")
            names = [f[0] or f[1] for f in funcs]
            info.append(f"함수: {len(names)}: {', '.join(names[:20])}")

        return "\n".join(info)

    # ── code_functions ──
    elif name == "code_functions":
        content = _read(a["file"])
        ext = Path(a["file"]).suffix.lower()
        include_body = a.get("include_body", False)

        if ext == ".py":
            return _py_functions(content, a["file"], include_body)
        elif ext == ".java":
            return _java_functions(content, a["file"])
        else:
            return _generic_functions(content, a["file"], ext)

    # ── code_classes ──
    elif name == "code_classes":
        content = _read(a["file"])
        ext = Path(a["file"]).suffix.lower()

        if ext == ".py":
            return _py_classes(content, a["file"])
        elif ext == ".java":
            return _java_classes(content, a["file"])
        else:
            return f"⚠️ {ext} 클래스 추출은 Python/Java만 지원"

    # ── code_diff ──
    elif name == "code_diff":
        c1 = _read(a["file1"]).splitlines(keepends=True)
        c2 = _read(a["file2"]).splitlines(keepends=True)
        ctx = a.get("context_lines", 3)

        diff = list(difflib.unified_diff(c1, c2, fromfile=a["file1"], tofile=a["file2"], n=ctx))

        if not diff:
            return f"✅ 두 파일이 동일합니다"

        # Count changes
        added = sum(1 for l in diff if l.startswith("+") and not l.startswith("+++"))
        removed = sum(1 for l in diff if l.startswith("-") and not l.startswith("---"))

        result = f"📝 Diff: {a['file1']} ↔ {a['file2']}\n"
        result += f"추가: +{added}줄, 삭제: -{removed}줄\n"
        result += "─" * 50 + "\n"
        result += "".join(diff[:300])
        if len(diff) > 300:
            result += f"\n... ({len(diff)}줄 중 300줄까지 표시)"
        return result

    # ── code_find_pattern ──
    elif name == "code_find_pattern":
        target = _resolve(a["path"])
        pattern = a["pattern"]
        file_pat = a.get("file_pattern", "*")
        mx = a.get("max_results", 50)

        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except re.error:
            regex = re.compile(re.escape(pattern), re.IGNORECASE)

        if os.path.isfile(target):
            search_files = [target]
        elif os.path.isdir(target):
            search_files = glob.glob(os.path.join(target, "**", file_pat), recursive=True)
            search_files = [f for f in search_files if os.path.isfile(f)]
        else:
            return f"❌ 경로 없음: {target}"

        results = []
        for fp in search_files[:300]:
            try:
                with open(fp, "r", encoding="utf-8", errors="replace") as f:
                    for i, line in enumerate(f, 1):
                        if regex.search(line):
                            rel = os.path.relpath(fp, WORK_DIR)
                            results.append(f"  {rel}:{i}  {line.rstrip()[:120]}")
                            if len(results) >= mx:
                                break
                if len(results) >= mx:
                    break
            except:
                continue

        if not results:
            return f"🔍 패턴 '{pattern}' 결과 없음"
        return f"🔍 '{pattern}' → {len(results)}건\n\n" + "\n".join(results)

    # ── code_stats ──
    elif name == "code_stats":
        target = _resolve(a["path"])
        if not os.path.isdir(target):
            return f"❌ 폴더 없음: {target}"

        exts_filter = a.get("extensions", "")
        if exts_filter:
            exts = [e.strip().lstrip(".") for e in exts_filter.split(",")]
        else:
            exts = ["py", "java", "js", "ts", "jsx", "tsx", "c", "cpp", "h", "cs",
                    "sql", "sh", "bat", "json", "xml", "yaml", "yml", "html", "css", "md"]

        stats = {}  # ext -> {files, lines, blank, comment, code}
        for ext in exts:
            files = glob.glob(os.path.join(target, "**", f"*.{ext}"), recursive=True)
            # Skip noise dirs
            files = [f for f in files if not any(s in f for s in ["__pycache__", "node_modules", ".git", "venv"])]
            if not files:
                continue

            total_lines = 0
            total_blank = 0
            total_comment = 0

            for fp in files:
                try:
                    with open(fp, "r", encoding="utf-8", errors="replace") as fh:
                        lines = fh.readlines()
                    total_lines += len(lines)
                    total_blank += sum(1 for l in lines if not l.strip())
                    total_comment += _count_comments(lines, f".{ext}")
                except:
                    pass

            code = total_lines - total_blank - total_comment
            stats[ext] = {"files": len(files), "lines": total_lines, "blank": total_blank,
                         "comment": total_comment, "code": code}

        if not stats:
            return f"📊 {target}\n코드 파일 없음"

        lines = [f"📊 프로젝트 통계: {target}\n", f"{'확장자':<8} {'파일':<6} {'전체줄':<8} {'코드':<8} {'주석':<6} {'빈줄':<6}"]
        lines.append("─" * 50)

        total_f, total_l, total_c, total_cm, total_b = 0, 0, 0, 0, 0
        for ext, s in sorted(stats.items(), key=lambda x: -x[1]["code"]):
            lines.append(f".{ext:<7} {s['files']:<6} {s['lines']:<8} {s['code']:<8} {s['comment']:<6} {s['blank']:<6}")
            total_f += s["files"]
            total_l += s["lines"]
            total_c += s["code"]
            total_cm += s["comment"]
            total_b += s["blank"]

        lines.append("─" * 50)
        lines.append(f"{'합계':<8} {total_f:<6} {total_l:<8} {total_c:<8} {total_cm:<6} {total_b:<6}")

        return "\n".join(lines)

    # ── code_dependencies ──
    elif name == "code_dependencies":
        content = _read(a["file"])
        try:
            tree = ast.parse(content)
        except SyntaxError as e:
            return f"⚠️ 구문 오류: {e}"

        stdlib = set()
        third = set()
        local = set()

        STDLIB = {"os", "sys", "re", "json", "time", "datetime", "pathlib", "collections",
                  "functools", "itertools", "math", "random", "threading", "asyncio",
                  "logging", "subprocess", "shutil", "glob", "io", "copy", "hashlib",
                  "base64", "struct", "socket", "http", "urllib", "csv", "xml", "html",
                  "typing", "abc", "dataclasses", "enum", "contextlib", "ast", "difflib",
                  "argparse", "configparser", "unittest", "traceback", "inspect", "pickle"}

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    mod = alias.name.split(".")[0]
                    if mod in STDLIB:
                        stdlib.add(alias.name)
                    elif mod.startswith("."):
                        local.add(alias.name)
                    else:
                        third.add(alias.name)
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    mod = node.module.split(".")[0]
                    names = [a.name for a in node.names]
                    full = f"from {node.module} import {', '.join(names)}"
                    if node.level > 0:
                        local.add(full)
                    elif mod in STDLIB:
                        stdlib.add(full)
                    else:
                        third.add(full)

        lines = [f"📦 {a['file']} 의존성\n"]

        if stdlib:
            lines.append(f"🔷 표준 라이브러리 ({len(stdlib)})")
            for s in sorted(stdlib):
                lines.append(f"  {s}")
            lines.append("")

        if third:
            lines.append(f"📦 외부 패키지 ({len(third)})")
            for s in sorted(third):
                lines.append(f"  {s}")
            lines.append("")

        if local:
            lines.append(f"📁 로컬 모듈 ({len(local)})")
            for s in sorted(local):
                lines.append(f"  {s}")

        return "\n".join(lines)

    # ── code_complexity ──
    elif name == "code_complexity":
        content = _read(a["file"])
        try:
            tree = ast.parse(content)
        except SyntaxError as e:
            return f"⚠️ 구문 오류: {e}"

        results = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                cc = _cyclomatic_complexity(node)
                level = "🟢" if cc <= 5 else "🟡" if cc <= 10 else "🔴"
                rating = "단순" if cc <= 5 else "보통" if cc <= 10 else "복잡" if cc <= 20 else "매우복잡"
                results.append((cc, node.name, node.lineno, level, rating))

        if not results:
            return f"📊 {a['file']}\n함수 없음"

        results.sort(key=lambda x: -x[0])

        lines = [f"📊 {a['file']} 복잡도 분석\n",
                 f"{'등급':<4} {'복잡도':<6} {'함수명':<30} {'줄':<6} {'판정':<8}",
                 "─" * 60]

        for cc, fname, lineno, level, rating in results:
            lines.append(f"{level}  {cc:<6} {fname:<30} {lineno:<6} {rating}")

        avg = sum(r[0] for r in results) / len(results)
        lines.append(f"\n평균 복잡도: {avg:.1f} | 함수 {len(results)}개")

        high = [r for r in results if r[0] > 10]
        if high:
            lines.append(f"⚠️ 복잡도 높은 함수 {len(high)}개 (리팩토링 권장)")

        return "\n".join(lines)

    return f"알 수 없는 도구: {name}"


# ═══════════════════════════════════════
# 내부 헬퍼
# ═══════════════════════════════════════

def _get_name(node) -> str:
    if isinstance(node, ast.Name):
        return node.id
    elif isinstance(node, ast.Attribute):
        return f"{_get_name(node.value)}.{node.attr}"
    return "?"


def _count_comments(lines, ext: str) -> int:
    count = 0
    ext = ext.lower()
    if ext in (".py",):
        in_docstring = False
        for l in lines:
            s = l.strip()
            if s.startswith('"""') or s.startswith("'''"):
                if s.count('"""') >= 2 or s.count("'''") >= 2:
                    count += 1
                else:
                    in_docstring = not in_docstring
                    count += 1
            elif in_docstring:
                count += 1
            elif s.startswith("#"):
                count += 1
    elif ext in (".java", ".js", ".ts", ".c", ".cpp", ".cs", ".jsx", ".tsx"):
        in_block = False
        for l in lines:
            s = l.strip()
            if in_block:
                count += 1
                if "*/" in s:
                    in_block = False
            elif s.startswith("//"):
                count += 1
            elif s.startswith("/*"):
                count += 1
                if "*/" not in s:
                    in_block = True
    elif ext in (".sql",):
        for l in lines:
            if l.strip().startswith("--"):
                count += 1
    elif ext in (".sh", ".bat"):
        for l in lines:
            if l.strip().startswith(("#", "REM", "rem")):
                count += 1
    return count


def _cyclomatic_complexity(node) -> int:
    """Calculate cyclomatic complexity for a function AST node."""
    cc = 1  # Base complexity
    for child in ast.walk(node):
        if isinstance(child, (ast.If, ast.While, ast.For, ast.AsyncFor)):
            cc += 1
        elif isinstance(child, ast.BoolOp):
            cc += len(child.values) - 1
        elif isinstance(child, ast.ExceptHandler):
            cc += 1
        elif isinstance(child, (ast.With, ast.AsyncWith)):
            cc += 1
        elif isinstance(child, ast.Assert):
            cc += 1
        elif isinstance(child, ast.comprehension):
            cc += 1 + len(child.ifs)
    return cc


def _py_functions(content: str, filename: str, include_body: bool) -> str:
    try:
        tree = ast.parse(content)
    except SyntaxError as e:
        return f"⚠️ 구문 오류: {e}"

    lines = content.split("\n")
    funcs = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]

    if not funcs:
        return f"📋 {filename}\n함수 없음"

    result = [f"📋 {filename} — 함수 {len(funcs)}개\n"]
    for f in funcs:
        params = []
        for arg in f.args.args:
            ann = ""
            if arg.annotation:
                ann = f": {ast.dump(arg.annotation)}" if hasattr(arg.annotation, 'id') else ""
                if hasattr(arg.annotation, 'id'):
                    ann = f": {arg.annotation.id}"
            params.append(f"{arg.arg}{ann}")

        prefix = "async def" if isinstance(f, ast.AsyncFunctionDef) else "def"
        result.append(f"  {prefix} {f.name}({', '.join(params)})  [줄 {f.lineno}]")

        # Docstring
        ds = ast.get_docstring(f)
        if ds:
            result.append(f"    📝 {ds[:100]}")

        if include_body and hasattr(f, 'end_lineno'):
            body = "\n".join(lines[f.lineno - 1:f.end_lineno])
            if len(body) > 500:
                body = body[:500] + "\n    ..."
            result.append(f"    ──\n{body}\n    ──")

        result.append("")

    return "\n".join(result)


def _java_functions(content: str, filename: str) -> str:
    pattern = r'(?:public|private|protected|static|\s)+\s+[\w<>\[\]]+\s+(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,\s]+)?\s*\{'
    matches = re.finditer(pattern, content)

    lines = content.split("\n")
    result = [f"📋 {filename} — Java 메서드\n"]
    count = 0
    for m in matches:
        name = m.group(1)
        params = m.group(2).strip()
        # Find line number
        pos = m.start()
        lineno = content[:pos].count("\n") + 1
        result.append(f"  {name}({params})  [줄 {lineno}]")
        count += 1

    if count == 0:
        return f"📋 {filename}\n메서드 없음"
    result.insert(1, f"총 {count}개\n")
    return "\n".join(result)


def _generic_functions(content: str, filename: str, ext: str) -> str:
    """Generic function extraction using regex."""
    patterns = {
        ".js": r'(?:function\s+(\w+)\s*\(|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\()',
        ".ts": r'(?:function\s+(\w+)\s*\(|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\()',
        ".c": r'\w+\s+(\w+)\s*\([^)]*\)\s*\{',
        ".cpp": r'\w+\s+(\w+)\s*\([^)]*\)\s*\{',
    }
    pat = patterns.get(ext)
    if not pat:
        return f"⚠️ {ext} 함수 추출 미지원"

    matches = re.finditer(pat, content)
    result = [f"📋 {filename}\n"]
    count = 0
    for m in matches:
        name = m.group(1) or (m.group(2) if m.lastindex >= 2 else "?")
        lineno = content[:m.start()].count("\n") + 1
        result.append(f"  {name}  [줄 {lineno}]")
        count += 1

    result.insert(1, f"함수 {count}개\n")
    return "\n".join(result)


def _py_classes(content: str, filename: str) -> str:
    try:
        tree = ast.parse(content)
    except SyntaxError as e:
        return f"⚠️ 구문 오류: {e}"

    classes = [n for n in ast.iter_child_nodes(tree) if isinstance(n, ast.ClassDef)]
    if not classes:
        return f"📋 {filename}\n클래스 없음"

    result = [f"📋 {filename} — 클래스 {len(classes)}개\n"]
    for cls in classes:
        bases = [_get_name(b) for b in cls.bases]
        result.append(f"class {cls.name}({', '.join(bases)})  [줄 {cls.lineno}]")
        ds = ast.get_docstring(cls)
        if ds:
            result.append(f"  📝 {ds[:80]}")

        methods = [n for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        attrs = [n.targets[0].attr for n in ast.walk(cls)
                 if isinstance(n, ast.Assign) and n.targets
                 and isinstance(n.targets[0], ast.Attribute)
                 and isinstance(n.targets[0].value, ast.Name)
                 and n.targets[0].value.id == "self"]
        attrs = sorted(set(attrs))

        if attrs:
            result.append(f"  속성: {', '.join(attrs[:15])}")
        for m in methods:
            prefix = "🔒" if m.name.startswith("_") else "  "
            result.append(f"  {prefix} def {m.name}()  [줄 {m.lineno}]")
        result.append("")

    return "\n".join(result)


def _java_classes(content: str, filename: str) -> str:
    cls_pattern = r'(?:public|private|protected)?\s*(?:abstract|static)?\s*class\s+(\w+)(?:\s+extends\s+(\w+))?(?:\s+implements\s+([\w,\s]+))?\s*\{'
    matches = re.finditer(cls_pattern, content)

    result = [f"📋 {filename} — Java 클래스\n"]
    count = 0
    for m in matches:
        name = m.group(1)
        extends = m.group(2) or ""
        impl = m.group(3) or ""
        lineno = content[:m.start()].count("\n") + 1
        line = f"class {name}"
        if extends:
            line += f" extends {extends}"
        if impl:
            line += f" implements {impl.strip()}"
        result.append(f"  {line}  [줄 {lineno}]")
        count += 1

    if count == 0:
        return f"📋 {filename}\n클래스 없음"
    return "\n".join(result)
