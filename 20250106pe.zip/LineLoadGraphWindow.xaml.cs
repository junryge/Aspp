﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Linq;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.Windows.Input;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Threading;
using System.Threading.Tasks;
using System.Globalization;
using System.Text;  // StringBuilder를 위한 using 문
using System.Windows.Data;
using System.Windows.Controls.Primitives;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data;
using System.Data.Common;
using System.Windows.Media.Animation;



namespace ShipDataViewer
{
    public partial class LineLoadGraphWindow : Window
    {
        private List<MonthlyLoadData> loadData;
        private const double GraphMargin = 40;
        private const double YAxisInterval = 20;
        private const double BarWidth = 30;
        private bool isLineChart = true; // 차트 타입 구분용 플래그
        private DateTime startDate;
        private DateTime endDate;
        private Point? dragStartPoint = null;
        private Rectangle selectionBox = null;
        private bool isMouseDown = false;
        private DateTime originalStartDate;
        private DateTime originalEndDate;
        private bool isZoomed = false;
        private Canvas overlayCanvas; // 클래스 멤버로 추가

        // 각 Canvas별 리미트 데이터 저장용 Dictionary
        private Dictionary<string, double> headquartersLimitValues = new Dictionary<string, double>();
        private Dictionary<string, double> onsanLimitValues = new Dictionary<string, double>();
        private Dictionary<string, double> marineLimitValues = new Dictionary<string, double>();

        //public LineLoadGraphWindow(DateTime minDate, DateTime maxDate)
        //{
        //    InitializeComponent();
        //    startDate = minDate;
        //    endDate = maxDate;

        //    InitializeDatePickers();

        //    // 창 크기가 변경될 때 그래프 다시 그리기
        //    SizeChanged += WindowSizeChanged;
        //}
        private Dictionary<DateTime, Tuple<int, int>> capeData; // 클래스 상단에 필드 추가
        private Dictionary<string, Dictionary<string, Dictionary<string, double>>> limitData;
        private readonly object _lockObject = new object();
        private System.Threading.CancellationTokenSource _filterCancellationTokenSource;

        // 모든 체크박스에 대한 이벤트 핸들러 추가
        //public LineLoadGraphWindow(DateTime minDate, DateTime maxDate, Dictionary<DateTime, Tuple<int, int>> capeData)
        //{
        public LineLoadGraphWindow(
            DateTime minDate,
            DateTime maxDate,
            Dictionary<DateTime, Tuple<int, int>> capeData,
            Dictionary<string, Dictionary<DateTime, Tuple<int, int>>> locationCapeData = null)
        {
            InitializeComponent();
            this.capeData = capeData;
            //locationCapeData 로컬데이터 사용하기
            startDate = minDate;
            endDate = maxDate;
            originalStartDate = minDate;
            originalEndDate = maxDate;

            // 기존 CAPA 체크박스 이벤트 핸들러
            //CAPA1.Checked += CAPA_CheckBox_Changed;
            //CAPA1.Unchecked += CAPA_CheckBox_Changed;
            CAPA2.Checked += CAPA_CheckBox_Changed;
            CAPA2.Unchecked += CAPA_CheckBox_Changed;
            //CAPA1_1.Checked += CAPA_CheckBox_Changed;
            //CAPA1_1.Unchecked += CAPA_CheckBox_Changed;
            CAPA2_1.Checked += CAPA_CheckBox_Changed;
            CAPA2_1.Unchecked += CAPA_CheckBox_Changed;

            // 사업장 체크박스 이벤트 핸들러
            //CheckHVS.Checked += BusinessLocation_CheckBox_Changed;
            //CheckHVS.Unchecked += BusinessLocation_CheckBox_Changed;
            CheckHeadquarters.Checked += BusinessLocation_CheckBox_Changed;
            CheckHeadquarters.Unchecked += BusinessLocation_CheckBox_Changed;
            CheckOnsan.Checked += BusinessLocation_CheckBox_Changed;
            CheckOnsan.Unchecked += BusinessLocation_CheckBox_Changed;
            //CheckYongyeon.Checked += BusinessLocation_CheckBox_Changed;
            //CheckYongyeon.Unchecked += BusinessLocation_CheckBox_Changed;
            CheckMarine.Checked += BusinessLocation_CheckBox_Changed;
            CheckMarine.Unchecked += BusinessLocation_CheckBox_Changed;

            // 장비 체크박스 이벤트 핸들러
            EQPC.Checked += Equipment_CheckBox_Changed;
            EQPC.Unchecked += Equipment_CheckBox_Changed;
            //EQPT.Checked += Equipment_CheckBox_Changed;
            //EQPT.Unchecked += Equipment_CheckBox_Changed;

            // 장소 체크박스 이벤트 핸들러
            //LOC1.Checked += Location_CheckBox_Changed;
            //LOC1.Unchecked += Location_CheckBox_Changed;
            //LOC2.Checked += Location_CheckBox_Changed;
            //LOC2.Unchecked += Location_CheckBox_Changed;
            //LOC3.Checked += Location_CheckBox_Changed;
            //LOC3.Unchecked += Location_CheckBox_Changed;
            LOC4.Checked += Location_CheckBox_Changed;
            LOC4.Unchecked += Location_CheckBox_Changed;
            LOC5.Checked += Location_CheckBox_Changed;
            LOC5.Unchecked += Location_CheckBox_Changed;
            LOC6.Checked += Location_CheckBox_Changed;
            LOC6.Unchecked += Location_CheckBox_Changed;
            LOC7.Checked += Location_CheckBox_Changed;
            LOC7.Unchecked += Location_CheckBox_Changed;

            InitializeDatePickers();
            //ShowValuesCheckBox.Checked += (s, e) => DrawGraph2();
            //ShowValuesCheckBox.Unchecked += (s, e) => DrawGraph2();

            //ShowLimitCheckBox.Checked += (s, e) => DrawGraph2();
            //ShowLimitCheckBox.Unchecked += (s, e) => DrawGraph2();

            // selectionBox가 이미 있다면 제거
            if (selectionBox != null)
            {
                var parent = selectionBox.Parent as Panel;
                if (parent != null)
                {
                    parent.Children.Remove(selectionBox);
                }
            }

            // 새로운 선택 영역 Rectangle 생성
            selectionBox = new Rectangle
            {
                Fill = new SolidColorBrush(Color.FromArgb(80, 0, 120, 215)),     // 반투명한 파란색
                Stroke = new SolidColorBrush(Color.FromArgb(255, 0, 120, 215)),  // 진한 파란색 테두리
                StrokeThickness = 2,
                Visibility = Visibility.Collapsed
            };

            // GraphCanvas2에 추가하기 전에 ZIndex 설정
            Panel.SetZIndex(selectionBox, 9999);
            GraphCanvas2.Children.Add(selectionBox);

            // 이벤트 핸들러 등록
            GraphCanvas2.MouseLeftButtonDown += new MouseButtonEventHandler(GraphCanvas2_MouseLeftButtonDown);
            GraphCanvas2.MouseMove += new MouseEventHandler(GraphCanvas2_MouseMove);
            GraphCanvas2.MouseLeftButtonUp += new MouseButtonEventHandler(GraphCanvas2_MouseLeftButtonUp);

            ChartTypeComboBox.SelectionChanged += ChartTypeComboBox_SelectionChanged;

            //LimitLineTextBox.TextChanged += (s, e) =>
            //{
            DrawGraph2();
            //};

            SizeChanged += WindowSizeChanged;

            LoadData();
            if (loadData != null && loadData.Count > 0)
            {
                //DrawGraph();
                DrawGraph2();
                UpdateDataGrid();
            }
        }


        //이부분 그래프 그어주는 부분 수정필요
        private void DrawLimitLinesForLocation(Canvas canvas, string location, double graphWidth, double graphHeight, double maxValue)
        {
            if (filteredLimitData == null || filteredCapeData == null || filteredCapeData.Count == 0)
                return;

            // 기존 리미트 라인 제거
            List<UIElement> elementsToRemove = new List<UIElement>();
            foreach (UIElement element in canvas.Children)
            {
                Line line = element as Line;
                if (line != null)
                {
                    FrameworkElement fe = line as FrameworkElement;
                    if (fe != null && fe.Tag != null && fe.Tag.ToString().StartsWith("Limit_"))
                    {
                        elementsToRemove.Add(element);
                    }
                }
            }
            foreach (UIElement element in elementsToRemove)
            {
                canvas.Children.Remove(element);
            }

            // 날짜 정렬
            List<DateTime> sortedDates = new List<DateTime>(filteredCapeData.Keys);
            sortedDates.Sort();

            // 이전 값을 추적할 딕셔너리
            Dictionary<string, double> previousValues = new Dictionary<string, double>();

            // Y축 최대값 계산 (그래프와 동일한 스케일 사용)
            double graphMaxValue = 250; // 실제 데이터 범위에 맞게 조정

            foreach (DateTime date in sortedDates)
            {
                string yearMonth = string.Format("{0}/{1:00}", date.Year, date.Month);
                if (!filteredLimitData.ContainsKey(yearMonth))
                    continue;

                Dictionary<string, Dictionary<string, double>> monthData = filteredLimitData[yearMonth];
                int dateIndex = sortedDates.IndexOf(date);

                // CAPA2 체크박스가 체크되어 있는 경우에만 CAPA2 라인 그리기
                if (CAPA2.IsChecked == true && monthData.ContainsKey("CAPA2"))
                {
                    double locationValue = monthData["CAPA2"].ContainsKey(location)
                        ? monthData["CAPA2"][location]
                        : 0;

                    if (locationValue > 0)
                    {
                        double x = GraphMargin + (graphWidth * dateIndex / (sortedDates.Count - 1));
                        // CAPA2 라인의 Y축 위치 계산 수정
                        double y;
                        if (location == "본사")
                        {
                            y = GraphMargin + (graphHeight * (1 - (locationValue * 5 / graphMaxValue))) - 14;
                        }
                        else if (location == "온산")
                        {
                            y = GraphMargin + (graphHeight * (1 - (locationValue * 5 / graphMaxValue))) + 14;
                        }
                        else if (location == "해양")
                        {
                            y = GraphMargin + (graphHeight * (1 - (locationValue * 5 / graphMaxValue))) - 14;
                        }
                        else
                        {
                            y = GraphMargin + (graphHeight * (1 - (locationValue * 5 / graphMaxValue)));
                        }

                        Line limitLine = new Line
                        {
                            X1 = x - (graphWidth / (sortedDates.Count * 2)),
                            X2 = x + (graphWidth / (sortedDates.Count * 2)),
                            Y1 = y,
                            Y2 = y,
                            Stroke = Brushes.Orange,
                            StrokeThickness = 2
                        };

                        FrameworkElement feLimitLine = limitLine as FrameworkElement;
                        if (feLimitLine != null)
                        {
                            feLimitLine.Tag = "Limit_CAPA2";
                        }

                        canvas.Children.Add(limitLine);

                        // 값이 변경된 경우에만 레이블 표시
                        if (!previousValues.ContainsKey("CAPA2") ||
                            Math.Abs(previousValues["CAPA2"] - locationValue) > 0.1)
                        {
                            TextBlock valueLabel = new TextBlock
                            {
                                Text = locationValue.ToString("F1"),
                                Foreground = Brushes.Orange,
                                FontSize = 10,
                                FontWeight = FontWeights.Bold
                            };

                            Canvas.SetLeft(valueLabel, x + 10);
                            Canvas.SetTop(valueLabel, y - 15);
                            canvas.Children.Add(valueLabel);

                            previousValues["CAPA2"] = locationValue;
                        }
                    }
                }

                // CAPA2_1 체크박스가 체크되어 있는 경우에만 CAPA2_1 라인 그리기
                if (CAPA2_1.IsChecked == true && monthData.ContainsKey("CAPA2_1"))
                {
                    double locationValue = monthData["CAPA2_1"].ContainsKey(location)
                        ? monthData["CAPA2_1"][location]
                        : 0;

                    if (locationValue > 0)
                    {
                        double x = GraphMargin + (graphWidth * dateIndex / (sortedDates.Count - 1));
                        // CAPA2_1 라인의 Y축 위치 계산 수정
                        double y;
                        if (location == "본사")
                        {
                            y = GraphMargin + (graphHeight * (1 - (locationValue * 5 / graphMaxValue))) - 14;
                        }
                        else if (location == "온산")
                        {
                            y = GraphMargin + (graphHeight * (1 - (locationValue * 5 / graphMaxValue))) + 14;
                        }
                        else if (location == "해양")
                        {
                            y = GraphMargin + (graphHeight * (1 - (locationValue * 5 / graphMaxValue))) - 14;
                        }
                        else
                        {
                            y = GraphMargin + (graphHeight * (1 - (locationValue * 5 / graphMaxValue)));
                        }

                        Line limitLine = new Line
                        {
                            X1 = x - (graphWidth / (sortedDates.Count * 2)),
                            X2 = x + (graphWidth / (sortedDates.Count * 2)),
                            Y1 = y,
                            Y2 = y,
                            Stroke = Brushes.DeepSkyBlue,
                            StrokeThickness = 2
                        };

                        FrameworkElement feLimitLine = limitLine as FrameworkElement;
                        if (feLimitLine != null)
                        {
                            feLimitLine.Tag = "Limit_CAPA2_1";
                        }

                        canvas.Children.Add(limitLine);

                        // 값이 변경된 경우에만 레이블 표시
                        if (!previousValues.ContainsKey("CAPA2_1") ||
                            Math.Abs(previousValues["CAPA2_1"] - locationValue) > 0.1)
                        {
                            TextBlock valueLabel = new TextBlock
                            {
                                Text = locationValue.ToString("F1"),
                                Foreground = Brushes.DeepSkyBlue,
                                FontSize = 10,
                                FontWeight = FontWeights.Bold
                            };

                            Canvas.SetLeft(valueLabel, x + 10);
                            Canvas.SetTop(valueLabel, y - 15);
                            canvas.Children.Add(valueLabel);

                            previousValues["CAPA2_1"] = locationValue;
                        }
                    }
                }
            }
        }


        private void TransposeDataGrid()
        {
            if (loadData == null || loadData.Count == 0) return;

            // 동적으로 DataGrid의 열을 재구성
            DataGrid.Columns.Clear();
            DataGrid.FontSize = 12; // 기본 폰트 크기

            // 구분 열 설정 - 글자 진하게
            var categoryColumn = new DataGridTextColumn();
            categoryColumn.Header = "구분";
            categoryColumn.Binding = new Binding("[Category]");
            categoryColumn.Width = new DataGridLength(90, DataGridLengthUnitType.Pixel);
            categoryColumn.MinWidth = 50;
            categoryColumn.ElementStyle = new Style(typeof(TextBlock));
            categoryColumn.ElementStyle.Setters.Add(new Setter(TextBlock.FontWeightProperty, FontWeights.Bold));
            DataGrid.Columns.Add(categoryColumn);

            // 항목 열 설정 - 글자 진하게
            var itemColumn = new DataGridTextColumn();
            itemColumn.Header = "항목";
            itemColumn.Binding = new Binding("[ItemName]");
            itemColumn.Width = new DataGridLength(120, DataGridLengthUnitType.Pixel);
            itemColumn.MinWidth = 50;
            itemColumn.ElementStyle = new Style(typeof(TextBlock));
            itemColumn.ElementStyle.Setters.Add(new Setter(TextBlock.FontWeightProperty, FontWeights.Bold));
            DataGrid.Columns.Add(itemColumn);

            // 각 월별로 동적 열 추가
            foreach (var monthData in loadData)
            {
                var column = new DataGridTextColumn();
                column.Header = monthData.Month;
                column.Binding = new Binding(string.Format("[{0}]", monthData.Month));
                column.Width = new DataGridLength(100, DataGridLengthUnitType.Pixel);
                column.MinWidth = 120;

                // 셀 스타일 추가 - 음수일 때 빨간색
                column.CellStyle = new Style(typeof(DataGridCell));
                column.CellStyle.Setters.Add(
                    new Setter(
                        DataGridCell.ForegroundProperty,
                        new Binding(string.Format("[{0}]", monthData.Month))
                        {
                            Converter = new NegativeColorConverter()
                        }
                    )
                );

                DataGrid.Columns.Add(column);
            }

            // 표시할 항목들을 배열로 정의 (구분과 항목 분리)
            var items = new[] 
    {
        new { Category = "생산능력", ItemName = "본사", Property = "Headquarters" },
        new { Category = "", ItemName = "해양", Property = "Yeyang" },
        new { Category = "", ItemName = "온산", Property = "Unsan" },
        new { Category = "", ItemName = "계ⓐ", Property = "Total" },
        new { Category = "부하MAX", ItemName = "중일정ⓑ", Property = "MidSchedule" },
        new { Category = "", ItemName = "조정ⓒ", Property = "Adjustment" },
        new { Category = "차이", ItemName = "중일정ⓐ-ⓑ", Property = "MidScheduleDiff" },
        new { Category = "", ItemName = "중일정ⓑ/ⓐ%", Property = "MidSchedulePercent" },
        new { Category = "", ItemName = "조정 ⓐ-ⓒ", Property = "AdjustmentDiff" },
        new { Category = "", ItemName = "조정ⓒ/ⓑ%", Property = "AdjustmentPercent" }
    };

            // 각 항목에 대한 행 데이터 생성
            var rowsData = new List<Dictionary<string, string>>();
            foreach (var item in items)
            {
                var row = new Dictionary<string, string>();
                row["Category"] = item.Category;
                row["ItemName"] = item.ItemName;

                foreach (var monthData in loadData)
                {
                    var prop = monthData.GetType().GetProperty(item.Property);
                    var value = prop != null ? prop.GetValue(monthData, null) : null;
                    string displayValue;

                    if (item.Property.EndsWith("Percent"))
                    {
                        displayValue = value != null ? value.ToString() + "" : "0%";
                    }
                    else if (value is double)
                    {
                        // 소수점 제거하고 정수로 표시
                        displayValue = string.Format("{0:N0}", value);
                    }
                    else
                    {
                        displayValue = value != null ? value.ToString() : string.Empty;
                    }

                    row[monthData.Month] = displayValue;
                }

                rowsData.Add(row);
            }

            // DataGrid 속성 설정
            DataGrid.IsReadOnly = false;
            DataGrid.CanUserResizeColumns = true;
            DataGrid.CanUserResizeRows = true;
            DataGrid.ColumnWidth = DataGridLength.Auto;
            DataGrid.RowHeight = 28;
            DataGrid.MinRowHeight = 25;
            DataGrid.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
            DataGrid.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;

            DataGrid.ItemsSource = rowsData;
        }

        // 음수 색상 변환기
        public class NegativeColorConverter : IValueConverter
        {
            public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
            {
                string strValue = value as string;
                if (!string.IsNullOrEmpty(strValue))
                {
                    // 콤마 제거
                    strValue = strValue.Replace(",", "");

                    double number;
                    if (double.TryParse(strValue, out number))
                    {
                        return number < 0 ? Brushes.Red : Brushes.Black;
                    }
                }
                return Brushes.Black;
            }

            public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            {
                throw new NotImplementedException();
            }
        }

        private void GetDataGridContent()
        {
            // DataGrid의 ItemsSource를 가져옵니다.
            var itemsSource = DataGrid.ItemsSource;

            if (itemsSource != null)
            {
                // ItemsSource를 IEnumerable로 처리
                foreach (var item in itemsSource)
                {
                    // TransposeDataGrid에서 Dictionary 형태로 데이터를 바인딩했다면 이를 캐스팅
                    var rowData = item as Dictionary<string, object>;
                    if (rowData != null)
                    {
                        // Dictionary의 Key-Value를 출력
                        foreach (var key in rowData.Keys)
                        {
                            Console.WriteLine(string.Format("{0}: {1}", key, rowData[key]));
                        }
                    }
                    else
                    {
                        // Dictionary 형태가 아닌 경우 객체로 처리
                        Console.WriteLine(item.ToString());
                    }
                }
            }
            else
            {
                // ItemsSource가 설정되지 않았을 경우 DataGrid.Items를 순회
                foreach (var item in DataGrid.Items)
                {
                    Console.WriteLine(item.ToString());
                }
            }
        }
        // 사용 예시
        private void SomeButton_Click(object sender, RoutedEventArgs e)
        {
            TransposeDataGrid();
        }

        private void RestoreOriginalDataGrid()
        {
            // 원래 DataGrid 열 및 데이터 소스 복원
            DataGrid.Columns.Clear();

            // 여기에 원래 DataGrid 열 재정의 코드 추가
            // 예: DataGridTextColumn 재추가

            DataGrid.ItemsSource = loadData;
        }

        private void DrawLocationGraph(Canvas canvas, string location)
        {
            // 기존 TextBlock 저장
            TextBlock titleBlock = null;
            foreach (UIElement element in canvas.Children)
            {
                if (element is TextBlock)
                {
                    titleBlock = element as TextBlock;
                    break;
                }
            }

            canvas.Children.Clear();

            // 저장한 TextBlock 다시 추가
            if (titleBlock != null)
            {
                canvas.Children.Add(titleBlock);
            }

            if (filteredCapeData == null || filteredCapeData.Count == 0) return;
            double maxValue = 50; // Y축 최대값 고정
            double canvasWidth = canvas.ActualWidth;
            double canvasHeight = canvas.ActualHeight;
            double graphWidth = canvasWidth - (GraphMargin * 2);
            double graphHeight = canvasHeight - (GraphMargin * 2);

            // 해당 사업장의 데이터만 필터링 
            var locationData = filteredCapeData.Select(kvp => new KeyValuePair<DateTime, Tuple<int, int>>(
                kvp.Key,
                new Tuple<int, int>(
                    GetLocationCount(kvp.Key, location, true),  // AS-IS (파란색) 데이터
                    GetLocationCount(kvp.Key, location, false)  // TO-BE (빨간색) 데이터  
                )
            )).ToDictionary(kvp => kvp.Key, kvp => kvp.Value);

            if (locationData.Count == 0) return;

            // 최대값 계산 및 그리드 그리기
            //double maxValue = locationData.Values.Max(v => Math.Max(v.Item1, v.Item2));
            maxValue = Math.Ceiling((maxValue + 10) / 20.0) * 20;

            DrawGrid2ForLocation(canvas, graphWidth, graphHeight, maxValue);
            DrawXAxis2ForLocation(canvas, graphWidth, graphHeight, locationData);

            // 데이터 선 그리기
            List<KeyValuePair<DateTime, Tuple<int, int>>> sortedData =
                locationData.OrderBy(kvp => kvp.Key).ToList();

            // AS-IS 선 (파란색)
            DrawDataLineForLocation(canvas, sortedData, x => x.Value.Item1,
                Brushes.Blue, graphWidth, graphHeight, maxValue);

            // TO-BE 선 (빨간색)
            DrawDataLineForLocation(canvas, sortedData, x => x.Value.Item2,
                Brushes.Red, graphWidth, graphHeight, maxValue);
        }


        //와 신경질 나네!!
        private int GetLocationCount(DateTime date, string location, bool isOriginal)
        {
            var mainWindow = Owner as MainWindow;
            if (mainWindow != null && mainWindow.ShipDataGrid.ItemsSource != null)
            {
                var items = mainWindow.ShipDataGrid.ItemsSource as List<ShipSchedule>;
                int count = 0;

                foreach (var schedule in items)
                {
                    if (schedule != null &&
                        schedule.S_KIND != "CAPE 중일정개수" &&
                        schedule.S_KIND != "CAPE 조정 개수" &&
                        schedule.S_KIND != "CAPE 조정결과개수")
                    {
                        //bool shouldCount = false;
                        //string mfgField = (Business_Check.IsChecked == true && !isOriginal)
                        //    ? schedule.MFG_IND_After
                        //    : schedule.MFG_IND;
                        bool shouldCount = false;
                        string mfgField;
                        if (Business_Check.IsChecked == true)
                        {
                            mfgField = isOriginal ? schedule.MFG_IND_After : schedule.MFG_IND;
                        }
                        else
                        {
                            mfgField = schedule.MFG_IND_After;
                        }
                        // 본사 데이터 특별 처리
                        if (location == "본사" && mfgField == "본사")
                        {
                            bool anyChecked = LOC4.IsChecked == true || LOC5.IsChecked == true ||
                                            LOC6.IsChecked == true || LOC7.IsChecked == true;

                            if (anyChecked)
                            {
                                shouldCount =
                                    (LOC4.IsChecked == true && schedule.LOC_DESC == "1D 서") ||
                                    (LOC5.IsChecked == true && schedule.LOC_DESC == "총조장") ||
                                    (LOC6.IsChecked == true && schedule.LOC_DESC == "2 - 3D") ||
                                    (LOC7.IsChecked == true && schedule.LOC_DESC == "4D 동");
                            }
                            else
                            {
                                shouldCount = true;
                            }
                        }
                        else if (mfgField == location)
                        {
                            shouldCount = true;
                        }

                        if (shouldCount)
                        {
                            DateTime endDate;
                            if (schedule.STG_CD == "90")
                            {
                                endDate = schedule.ERECT_PLDT;
                            }
                            else if (schedule.STG_CD == "70" || schedule.STG_CD == "80")
                            {
                                endDate = schedule.WKFIPLDT;
                            }
                            else
                            {
                                endDate = schedule.WKFIPLDT1;
                            }

                            if (date >= schedule.WKSTPLDT1 && date <= endDate)
                            {
                                if (isOriginal)
                                {
                                    count++;
                                }
                                else
                                {
                                    bool isCrimsonDate = false;
                                    if (schedule.MonthlyDates != null)
                                    {
                                        foreach (List<DateCell> monthDates in schedule.MonthlyDates)
                                        {
                                            if (monthDates != null)
                                            {
                                                foreach (DateCell cell in monthDates)
                                                {
                                                    if (cell.Day == date.Day.ToString("00") &&
                                                        cell.Color == Brushes.Crimson)
                                                    {
                                                        isCrimsonDate = true;
                                                        break;
                                                    }
                                                }
                                            }
                                            if (isCrimsonDate) break;
                                        }
                                    }
                                    if (!isCrimsonDate)
                                    {
                                        count++;
                                    }
                                }
                            }
                        }
                    }
                }
                return count;
            }
            return 0;
        }

        public Dictionary<string, Dictionary<string, Dictionary<string, double>>> GetFilteredLimitData()
        {
            return filteredLimitData;
        }

        private void DataGridCell_Loaded(object sender, RoutedEventArgs e)
        {
            DataGridCell cell = sender as DataGridCell;
            if (cell != null && cell.Content is TextBlock)
            {
                TextBlock textBlock = cell.Content as TextBlock;
                string text = textBlock.Text;
                double value;

                // 숫자로 변환 시도
                if (double.TryParse(text, out value))
                {
                    // 음수일 경우 빨간색으로 설정
                    if (value < 0)
                    {
                        textBlock.Foreground = Brushes.Red;
                    }
                    else
                    {
                        textBlock.Foreground = Brushes.Black;
                    }
                }
            }
        }
        private void MAINDATA_BOX_CheckBox_Changed(object sender, RoutedEventArgs e)
        {
            CAPA2.IsChecked = MAINDATA_BOX.IsChecked;
            DrawGraph2(); // 그래프 다시 그리기
        }
        private void MAINDATA_BOX1_CheckBox_Changed(object sender, RoutedEventArgs e)
        {
            CAPA2_1.IsChecked = MAINDATA_BOX1.IsChecked;
            DrawGraph2(); // 그래프 다시 그리기
        }


        //private void Exit_DAY_CheckBox_Changed(object sender, RoutedEventArgs e)
        //{
        //    var mainWindow = Owner as MainWindow;
        //    if (mainWindow != null)
        //    {
        //        CheckBox checkbox = sender as CheckBox;
        //        if (checkbox.IsChecked == true)
        //        {
        //            // PreviewMouseDown 이벤트 핸들러 제거
        //            mainWindow.PeApplyButton.PreviewMouseDown -= BlockPeApplyButton_Click;
        //            // 메시지 표시
        //            MessageBox.Show("배열_반출일 조정가능", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
        //        }
        //        else
        //        {
        //            // CheckBox 해제 및 PE 적용
        //            mainWindow.ResetTextBoxesAndApplyPE();
        //            // PeApplyButton에 PreviewMouseDown 이벤트 핸들러 추가
        //            mainWindow.PeApplyButton.PreviewMouseDown += BlockPeApplyButton_Click;
        //            // 메시지 표시
        //            MessageBox.Show("배열_반출일 조정불가(배열/반출일조정 아이콘 사용불가)", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
        //        }
        //    }
        //}

        private void Exit_DAY_CheckBox_Changed(object sender, RoutedEventArgs e)
        {
            var mainWindow = Owner as MainWindow;
            if (mainWindow != null)
            {
                CheckBox checkbox = sender as CheckBox;
                if (checkbox.IsChecked == true)
                {
                    // PreviewMouseDown 이벤트 핸들러 제거
                    mainWindow.PeApplyButton.PreviewMouseDown -= BlockPeApplyButton_Click;

                    // ResetTextBoxesAndApplyPE1 호출
                    mainWindow.ResetTextBoxesAndApplyPE1();
                    //mainWindow.PeApplyButton.PreviewMouseDown += BlockPeApplyButton_Click;

                    // 메시지 표시
                    MessageBox.Show("배열_반출일 조정가능(클릭후 수동으로 조정버튼을 눌러주세요)", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    // CheckBox 해제 및 ResetTextBoxesAndApplyPE 호출
                    mainWindow.ResetTextBoxesAndApplyPE();

                    // PeApplyButton에 PreviewMouseDown 이벤트 핸들러 추가
                    mainWindow.PeApplyButton.PreviewMouseDown += BlockPeApplyButton_Click;

                    // 메시지 표시
                    MessageBox.Show("배열_반출일 조정불가(배열/반출일조정 아이콘 사용불가)", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        // 버튼 클릭을 차단하는 이벤트 핸들러
        private void BlockPeApplyButton_Click(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;  // 이벤트 전파 중단
            MessageBox.Show("배열_반출일 조정이 되어 체크후 사용가능합니다. .", "알림", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        //private void Business_Check_CheckBox_Changed(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        var mainWindow = Owner as MainWindow;
        //        if (mainWindow != null && mainWindow.ShipDataGrid.ItemsSource != null)
        //        {
        //            // 데이터 다시 로드 및 그래프 업데이트
        //            LoadData();
        //            FilterCapeDataByDate();
        //            DrawGraph2();
        //            TransposeDataGrid();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show(string.Format("사업장 체크박스 처리 중 오류가 발생했습니다: {0}", ex.Message),
        //            "오류", MessageBoxButton.OK, MessageBoxImage.Error);
        //    }
        //}
        private void Business_Check_CheckBox_Changed(object sender, RoutedEventArgs e)
        {
            try
            {
                var mainWindow = Owner as MainWindow;
                if (mainWindow != null && mainWindow.ShipDataGrid.ItemsSource != null)
                {
                    // 데이터 다시 로드 및 그래프 업데이트
                    LoadData();
                    FilterCapeDataByDate();
                    DrawGraph2();
                    TransposeDataGrid();

                    // DailyLoadWindow 업데이트
                    foreach (Window window in Application.Current.Windows)
                    {
                        DailyLoadWindow dailyLoadWindow = window as DailyLoadWindow;
                        if (dailyLoadWindow != null)
                        {
                            var items = mainWindow.ShipDataGrid.ItemsSource as List<ShipSchedule>;
                            if (items != null)
                            {
                                string month = dailyLoadWindow.CurrentMonth;
                                string location = dailyLoadWindow.Location;

                                // 사업장별 데이터 필터링
                                List<ShipSchedule> locationData;
                                if (location == "통합")
                                {
                                    locationData = items;
                                }
                                else
                                {
                                    locationData = new List<ShipSchedule>();
                                    foreach (ShipSchedule item in items)
                                    {
                                        string mfgField = Business_Check.IsChecked == true ?
                                            item.MFG_IND : item.MFG_IND;
                                        if (mfgField == location)
                                        {
                                            locationData.Add(item);
                                        }
                                    }
                                }

                                // 리미트 데이터 가져오기
                                Dictionary<string, Dictionary<DateTime, double>> limitDataForMonth =
                                    GetLimitDataForMonth(month, location);

                                dailyLoadWindow.UpdateData(locationData, limitDataForMonth);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("사업장 체크박스 처리 중 오류가 발생했습니다: {0}", ex.Message),
                    "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        //private void Interim_schedule_CheckBox_Changed(object sender, RoutedEventArgs e)
        //{
        //    var mainWindow = Owner as MainWindow;
        //    if (mainWindow != null)
        //    {
        //        if (Interim_schedule_CheckBox.IsChecked.HasValue && Interim_schedule_CheckBox.IsChecked.Value)
        //        {
        //            // 잠금 해제
        //            mainWindow.UnlockScheduleEditing();
        //            MessageBox.Show("일정 잠금이 해제되었습니다.",
        //                "알림", MessageBoxButton.OK, MessageBoxImage.Information);
        //        }
        //        else
        //        {
        //            try
        //            {
        //                // 현재 데이터를 가져옵니다
        //                var items = mainWindow.ShipDataGrid.ItemsSource as List<ShipSchedule>;
        //                if (items != null)
        //                {
        //                    foreach (var schedule in items)
        //                    {
        //                        // LOAD 관련 행은 제외
        //                        if (schedule.S_KIND == "LOAD 중일정개수" ||
        //                            schedule.S_KIND == "LOAD 조정 개수" ||
        //                            schedule.S_KIND == "LOAD 조정결과개수")
        //                            continue;
        //                        // 수정된 플래그가 있는 경우 원본 데이터로 복원
        //                        if (schedule.IsWKSTPLDT1Modified)
        //                        {
        //                            schedule.WKSTPLDT1 = schedule.WKSTPLDT;  // 원본 착수실적일로 복원
        //                            schedule.IsWKSTPLDT1Modified = false;
        //                        }
        //                        if (schedule.IsWKFIPLDTModified)
        //                        {
        //                            schedule.WKFIPLDT = schedule.WKFIPLDT1;  // 원본 완료실적일로 복원
        //                            schedule.IsWKFIPLDTModified = false;
        //                        }
        //                        if (schedule.IsERPLDTModified)
        //                        {
        //                            schedule.ERECT_PLDT = schedule.WKFIPLDT1;  // 원본 완료실적일로 복원
        //                            schedule.IsERPLDTModified = false;
        //                        }
        //                    }
        //                    // UI 업데이트 및 데이터 잠금
        //                    mainWindow.ProcessAndDisplayData(items);
        //                    mainWindow.LockScheduleEditing();
        //                    MessageBox.Show("일정이 원본 데이터로 복원되고 잠금 처리되었습니다.",
        //                        "알림", MessageBoxButton.OK, MessageBoxImage.Information);
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                MessageBox.Show("데이터 복원 중 오류가 발생했습니다: " + ex.Message,
        //                    "오류", MessageBoxButton.OK, MessageBoxImage.Error);
        //            }
        //        }
        //    }
        //}

        //비동기 처리 완료
        private async void Interim_schedule_CheckBox_Changed(object sender, RoutedEventArgs e)
        {
            var mainWindow = Owner as MainWindow;
            if (mainWindow == null) return;

            var items = mainWindow.ShipDataGrid.ItemsSource as List<ShipSchedule>;
            if (items == null) return;

            if (Interim_schedule_CheckBox.IsChecked.HasValue && Interim_schedule_CheckBox.IsChecked.Value)
            {
                mainWindow.UnlockScheduleEditing();
                MessageBox.Show("일정 잠금이 해제되었습니다.",
                    "알림", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                await Task.Run(() =>
                {
                    foreach (var schedule in items)
                    {
                        if (schedule.S_KIND == "LOAD 중일정개수" ||
                            schedule.S_KIND == "LOAD 조정 개수" ||
                            schedule.S_KIND == "LOAD 조정결과개수")
                            continue;

                        if (schedule.IsWKSTPLDT1Modified)
                        {
                            schedule.WKSTPLDT1 = schedule.WKSTPLDT;
                            schedule.IsWKSTPLDT1Modified = false;
                        }
                        if (schedule.IsWKFIPLDTModified)
                        {
                            schedule.WKFIPLDT = schedule.WKFIPLDT1;
                            schedule.IsWKFIPLDTModified = false;
                        }
                        if (schedule.IsERPLDTModified)
                        {
                            schedule.ERECT_PLDT = schedule.WKFIPLDT1;
                            schedule.IsERPLDTModified = false;
                        }
                    }
                });

                mainWindow.ProcessAndDisplayData(items);
                mainWindow.LockScheduleEditing();
                MessageBox.Show("일정이 원본 데이터로 복원되고 잠금 처리되었습니다.",
                    "알림", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void PE_Dismantle_CheckBox_Changed(object sender, RoutedEventArgs e)
        {
            try
            {
                bool isDismantleChecked = PE_Dismantle.IsChecked == true;
                var mainWindow = Owner as MainWindow;
                if (mainWindow != null)
                {
                    // MainWindow의 IsColorChangeEnabled 속성 설정
                    mainWindow.IsColorChangeEnabled = isDismantleChecked;  // 변경된 부분: 부정 연산자 제거
                    if (filteredCapeData != null)
                    {
                        var mainData = mainWindow.ShipDataGrid.ItemsSource as List<ShipSchedule>;
                        if (mainData != null)
                        {
                            if (!isDismantleChecked)  // 변경된 부분: 조건 반전
                            {
                                // 현재 Crimson 상태 저장
                                mainWindow.SaveCrimsonCellState();
                                // 모든 Crimson 색상을 Orange로 변경
                                foreach (ShipSchedule shipSchedule in mainData)
                                {
                                    if (shipSchedule.MonthlyDates != null)
                                    {
                                        foreach (List<DateCell> monthDates in shipSchedule.MonthlyDates)
                                        {
                                            if (monthDates != null)
                                            {
                                                foreach (DateCell cell in monthDates)
                                                {
                                                    if (cell.Color == Brushes.Crimson)
                                                    {
                                                        cell.Color = Brushes.Orange;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else  // 변경된 부분: else 블록의 조건이 반전됨
                            {
                                // Crimson 상태 복원
                                mainWindow.RestoreCrimsonCellState();
                            }
                            // 그래프 다시 그리기
                            DrawGraph2();
                        }
                    }
                    if (isDismantleChecked)
                    {
                        MessageBox.Show(
                            "PE 해체가 설정되었습니다.\n 잠금해제되었습니다 (기존 PE해체 진행)",  // 메시지 변경
                            "알림",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information
                        );
                    }
                    else
                    {
                        MessageBox.Show(
                            "PE 해체가 해제되었습니다.\n 잠금되었습니다 사용시 PE해체 체크(기존 PE해체 초기화)",  // 메시지 변경
                            "알림",
                            MessageBoxButton.OK,
                            MessageBoxImage.Information
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "PE 해체 처리 중 오류가 발생했습니다:\n" + ex.Message,
                    "ERROR(오류)/PE해체실패"
                );
            }
        }

        // CAPA 체크박스 상태가 변경될 때 호출되는 메서드
        private void CAPA_CheckBox_Changed(object sender, RoutedEventArgs e)
        {
            DrawGraph2(); // 리미트선을 다시 그리기 위해 그래프를 다시 그림
        }

        private void GraphCanvas2_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (filteredCapeData == null || filteredCapeData.Count == 0) return;

            isMouseDown = true;
            dragStartPoint = e.GetPosition(GraphCanvas2);

            Canvas.SetLeft(selectionBox, dragStartPoint.Value.X);
            Canvas.SetTop(selectionBox, dragStartPoint.Value.Y);
            selectionBox.Width = 0;
            selectionBox.Height = 0;
            selectionBox.Visibility = Visibility.Visible;

            GraphCanvas2.CaptureMouse();
        }


        private void DataGrid_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // 클릭된 요소가 헤더인지 셀인지 확인
            DataGridCell cell = FindVisualParent<DataGridCell>(e.OriginalSource as DependencyObject);
            string selectedMonth;

            if (cell != null)
            {
                // 셀이 클릭된 경우 
                int columnIndex = cell.Column.DisplayIndex;
                if (columnIndex == 0) return; // 첫번째 열("항목") 무시

                DataGridColumn column = DataGrid.Columns[columnIndex];
                if (column == null || column.Header == null) return;

                selectedMonth = column.Header.ToString();
            }
            else
            {
                // 헤더가 클릭된 경우
                DataGridColumnHeader header = FindVisualParent<DataGridColumnHeader>(e.OriginalSource as DependencyObject);
                if (header == null || header.Column == null || header.Column.Header == null) return;

                if (header.Column.DisplayIndex == 0) return;

                selectedMonth = header.Column.Header.ToString();
            }

            // 선택된 월의 데이터 찾기
            MonthlyLoadData selectedData = null;
            foreach (MonthlyLoadData data in loadData)
            {
                if (data.Month == selectedMonth)
                {
                    selectedData = data;
                    break;
                }
            }

            if (selectedData != null)
            {
                MainWindow mainWindow = Owner as MainWindow;
                if (mainWindow != null && mainWindow.ShipDataGrid.ItemsSource != null)
                {
                    List<ShipSchedule> items = mainWindow.ShipDataGrid.ItemsSource as List<ShipSchedule>;
                    if (items != null)
                    {
                        // 데이터 분류
                        List<ShipSchedule> allData = new List<ShipSchedule>();
                        List<ShipSchedule> headquartersData = new List<ShipSchedule>();
                        List<ShipSchedule> onsanData = new List<ShipSchedule>();
                        List<ShipSchedule> marineData = new List<ShipSchedule>();

                        //foreach (ShipSchedule item in items)
                        //{
                        //    if (item != null)
                        //    {
                        //        allData.Add(item);

                        //        if (item.MFG_IND_After == "본사")
                        //            headquartersData.Add(item);
                        //        else if (item.MFG_IND_After == "온산")
                        //            onsanData.Add(item);
                        //        else if (item.MFG_IND_After == "해양")
                        //            marineData.Add(item);
                        //    }
                        //}
                        foreach (ShipSchedule item in items)
                        {
                            if (item != null)
                            {
                                allData.Add(item);

                                // Business_Check 상태에 따라 MFG_IND 또는 MFG_IND_After 사용
                                string mfgField = Business_Check.IsChecked == true ? item.MFG_IND : item.MFG_IND_After;

                                if (mfgField == "본사")
                                    headquartersData.Add(item);
                                else if (mfgField == "온산")
                                    onsanData.Add(item);
                                else if (mfgField == "해양")
                                    marineData.Add(item);
                            }
                        }
                        // 각 위치별 리미트 데이터 가져오기
                        Dictionary<string, Dictionary<DateTime, double>> limitDataByType = GetLimitDataForMonth(selectedData.Month, "통합");
                        Dictionary<string, Dictionary<DateTime, double>> headquartersLimitData = GetLimitDataForMonth(selectedData.Month, "본사");
                        Dictionary<string, Dictionary<DateTime, double>> onsanLimitData = GetLimitDataForMonth(selectedData.Month, "온산");
                        Dictionary<string, Dictionary<DateTime, double>> marineLimitData = GetLimitDataForMonth(selectedData.Month, "해양");

                        // 화면 크기 계산 및 창 위치 설정 부분만 수정
                        // 통합 데이터 창 (상단 전체)
                        DailyLoadWindow totalWindow = new DailyLoadWindow(selectedData.Month, allData, limitDataByType, "통합");
                        totalWindow.WindowStartupLocation = WindowStartupLocation.Manual;
                        totalWindow.Top = 0;  // 최상단
                        totalWindow.Left = 0;
                        totalWindow.Width = SystemParameters.WorkArea.Width;  // 화면 전체 너비
                        totalWindow.Height = SystemParameters.WorkArea.Height / 2;  // 화면 높이의 절반
                        totalWindow.Title = string.Format("[통합] {0}월 부하현황", selectedData.Month);
                        totalWindow.Owner = this;
                        totalWindow.Show();

                        // 하단 창들의 크기 계산
                        double bottomWindowWidth = SystemParameters.WorkArea.Width / 3;  // 화면 너비를 3등분
                        double bottomWindowHeight = SystemParameters.WorkArea.Height / 2;  // 화면 높이의 절반
                        double bottomTop = SystemParameters.WorkArea.Height / 2;  // 하단 시작 위치

                        // 본사 데이터 창 (하단 좌측)
                        DailyLoadWindow headquartersWindow = new DailyLoadWindow(selectedData.Month, headquartersData, headquartersLimitData, "본사");
                        headquartersWindow.WindowStartupLocation = WindowStartupLocation.Manual;
                        headquartersWindow.Top = bottomTop;
                        headquartersWindow.Left = 0;
                        headquartersWindow.Width = bottomWindowWidth;
                        headquartersWindow.Height = bottomWindowHeight;
                        headquartersWindow.Title = string.Format("[본사] {0}월 부하현황", selectedData.Month);
                        headquartersWindow.Owner = this;
                        headquartersWindow.Show();

                        // 온산 데이터 창 (하단 중앙)
                        DailyLoadWindow onsanWindow = new DailyLoadWindow(selectedData.Month, onsanData, onsanLimitData, "온산");
                        onsanWindow.WindowStartupLocation = WindowStartupLocation.Manual;
                        onsanWindow.Top = bottomTop;
                        onsanWindow.Left = bottomWindowWidth;
                        onsanWindow.Width = bottomWindowWidth;
                        onsanWindow.Height = bottomWindowHeight;
                        onsanWindow.Title = string.Format("[온산] {0}월 부하현황", selectedData.Month);
                        onsanWindow.Owner = this;
                        onsanWindow.Show();

                        // 해양 데이터 창 (하단 우측)
                        DailyLoadWindow marineWindow = new DailyLoadWindow(selectedData.Month, marineData, marineLimitData, "해양");
                        marineWindow.WindowStartupLocation = WindowStartupLocation.Manual;
                        marineWindow.Top = bottomTop;
                        marineWindow.Left = bottomWindowWidth * 2;
                        marineWindow.Width = bottomWindowWidth;
                        marineWindow.Height = bottomWindowHeight;
                        marineWindow.Title = string.Format("[해양] {0}월 부하현황", selectedData.Month);
                        marineWindow.Owner = this;
                        marineWindow.Show();
                    }
                }
            }
        }

        private T FindVisualParent<T>(DependencyObject child) where T : DependencyObject
        {
            DependencyObject parentObject = VisualTreeHelper.GetParent(child);

            if (parentObject == null)
                return null;

            T parent = parentObject as T;
            if (parent != null)
                return parent;

            return FindVisualParent<T>(parentObject);
        }

        // GetLimitDataForMonth 메서드 업데이트
        private Dictionary<string, Dictionary<DateTime, double>> GetLimitDataForMonth(string month, string location)
        {
            Dictionary<string, Dictionary<DateTime, double>> limitDataByType = new Dictionary<string, Dictionary<DateTime, double>>();

            if (filteredLimitData != null && filteredLimitData.ContainsKey(month))
            {
                Dictionary<string, Dictionary<string, double>> monthData = filteredLimitData[month];

                // CAPA2와 CAPA2_1 데이터를 각각 처리
                if (monthData.ContainsKey("CAPA2"))
                {
                    Dictionary<DateTime, double> capa2Data = new Dictionary<DateTime, double>();
                    double capa2Value = 0;

                    if (location == "통합")
                    {
                        // 모든 위치의 값을 합산
                        capa2Value = monthData["CAPA2"].Values.Sum();
                    }
                    else if (monthData["CAPA2"].ContainsKey(location))
                    {
                        capa2Value = monthData["CAPA2"][location];
                    }

                    string[] dateParts = month.Split('/');
                    int year = int.Parse(dateParts[0]);
                    int monthNum = int.Parse(dateParts[1]);
                    int daysInMonth = DateTime.DaysInMonth(year, monthNum);

                    for (int day = 1; day <= daysInMonth; day++)
                    {
                        capa2Data[new DateTime(year, monthNum, day)] = capa2Value;
                    }
                    limitDataByType["CAPA2"] = capa2Data;
                }

                // CAPA2_1 데이터 처리
                if (monthData.ContainsKey("CAPA2_1"))
                {
                    Dictionary<DateTime, double> capa2_1Data = new Dictionary<DateTime, double>();
                    double capa2_1Value = 0;

                    if (location == "통합")
                    {
                        // 모든 위치의 값을 합산
                        capa2_1Value = monthData["CAPA2_1"].Values.Sum();
                    }
                    else if (monthData["CAPA2_1"].ContainsKey(location))
                    {
                        capa2_1Value = monthData["CAPA2_1"][location];
                    }

                    string[] dateParts = month.Split('/');
                    int year = int.Parse(dateParts[0]);
                    int monthNum = int.Parse(dateParts[1]);
                    int daysInMonth = DateTime.DaysInMonth(year, monthNum);

                    for (int day = 1; day <= daysInMonth; day++)
                    {
                        capa2_1Data[new DateTime(year, monthNum, day)] = capa2_1Value;
                    }
                    limitDataByType["CAPA2_1"] = capa2_1Data;
                }
            }

            return limitDataByType;
        }


        private void GraphCanvas2_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown && dragStartPoint.HasValue)
            {
                Point currentPoint = e.GetPosition(GraphCanvas2);

                double x = Math.Min(currentPoint.X, dragStartPoint.Value.X);
                double y = Math.Min(currentPoint.Y, dragStartPoint.Value.Y);
                double width = Math.Abs(currentPoint.X - dragStartPoint.Value.X);
                double height = Math.Abs(currentPoint.Y - dragStartPoint.Value.Y);

                Canvas.SetLeft(selectionBox, x);
                Canvas.SetTop(selectionBox, y);
                selectionBox.Width = width;
                selectionBox.Height = height;
            }
        }

        private void GraphCanvas2_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (isMouseDown && dragStartPoint.HasValue)
            {
                GraphCanvas2.ReleaseMouseCapture();
                isMouseDown = false;
                Point endPoint = e.GetPosition(GraphCanvas2);

                // 최소 드래그 거리 체크
                if (Math.Abs(endPoint.X - dragStartPoint.Value.X) < 20)
                {
                    selectionBox.Visibility = Visibility.Collapsed;
                    return;
                }
                selectionBox.Visibility = Visibility.Collapsed;
                // 선택 영역의 X좌표를 날짜로 변환
                double canvasWidth = GraphCanvas2.ActualWidth - (GraphMargin * 2);
                List<DateTime> sortedDates = new List<DateTime>(filteredCapeData.Keys);
                sortedDates.Sort();

                // 선택 영역의 시작과 끝 X좌표를 상대적인 위치(0~1)로 변환
                double startX = (Math.Min(dragStartPoint.Value.X, endPoint.X) - GraphMargin) / canvasWidth;
                double endX = (Math.Max(dragStartPoint.Value.X, endPoint.X) - GraphMargin) / canvasWidth;

                // 위치를 인덱스로 변환
                int startIndex = Math.Max(0, (int)(startX * (sortedDates.Count - 1)));
                int endIndex = Math.Min(sortedDates.Count - 1, (int)(endX * (sortedDates.Count - 1)));

                // 새로운 날짜 범위 설정
                startDate = sortedDates[startIndex];
                endDate = sortedDates[endIndex];

                // DatePicker 업데이트
                StartDatePicker.Text = startDate.Year.ToString() + startDate.Month.ToString().PadLeft(2, '0');
                EndDatePicker.Text = endDate.Year.ToString() + endDate.Month.ToString().PadLeft(2, '0');

                isZoomed = true;
                selectionBox.Visibility = Visibility.Collapsed;

                // 그래프 다시 그리기
                //SearchButton_Click(null, null);
            }
        }

        private void WindowSizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (loadData != null && loadData.Count > 0)
            {
                //DrawGraph();    // GraphCanvas 업데이트
                DrawGraph2();   // GraphCanvas2 업데이트
            }
        }


        private void ChartTypeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            isLineChart = ChartTypeComboBox.SelectedIndex == 0;
            if (loadData != null && loadData.Count > 0)
            {
                //DrawGraph();
                DrawGraph2(); // 추가
            }
        }

        private void InitializeDatePickers()
        {
            // TextBox에 맞게 수정
            StartDatePicker.Text = startDate.Year.ToString() + startDate.Month.ToString().PadLeft(2, '0');
            EndDatePicker.Text = endDate.Year.ToString() + endDate.Month.ToString().PadLeft(2, '0');
        }

        private class CapaData
        {
            public string MfgDesc { get; set; }
            public string PeEquip { get; set; }
            public string PeMocNm { get; set; }
            public string Yyyy { get; set; }
            public string Mm { get; set; }
            public double Capa1 { get; set; }
            public double Capa2 { get; set; }
            public double Capa1_1 { get; set; }
            public double Capa2_1 { get; set; }
        }

        private List<CapaData> masterCapaData;
        private Dictionary<string, Dictionary<string, Dictionary<string, double>>> filteredLimitData;

        public class MonthlyLoadData
        //private class MonthlyLoadData
        {

            public double MaxMidSchedule { get; set; }
            public DateTime MaxMidScheduleDate { get; set; }
            public double MaxAdjustment { get; set; }
            public DateTime MaxAdjustmentDate { get; set; }

            public string Month { get; set; }
            public double Headquarters { get; set; }
            public double Yeyang { get; set; }
            public double Unsan { get; set; }
            public double Total { get; set; }
            public double MidSchedule { get; set; }
            public double Adjustment { get; set; }
            public double MidScheduleDiff { get; set; }
            public string MidSchedulePercent { get; set; }
            public double AdjustmentDiff { get; set; }
            public string AdjustmentPercent { get; set; }
            public string CapacityIndex_ch { get; set; } // 지번수[조정후]
            public string CapacityIndex { get; set; } // 지번수[조정전]
            public string CapacityIndex_pch
            {
                get
                {
                    double original = 0;
                    double changed = 0;

                    // CapacityIndex와 CapacityIndex_ch가 모두 유효한 숫자인 경우에만 계산
                    if (double.TryParse(CapacityIndex, out original) && original > 0 &&
                        double.TryParse(CapacityIndex_ch, out changed))
                    {
                        return Math.Floor((changed / original) * 100).ToString() + "%";
                    }
                    return "0%"; // 계산 불가 시 기본값
                }
            }

        }


        private void FilterCapaData()
        {
            if (masterCapaData == null)
            {
                return;
            }

            try
            {
                filteredLimitData = new Dictionary<string, Dictionary<string, Dictionary<string, double>>>();

                // 입력된 날짜 범위 파싱
                string startText = StartYearMonthTextBox.Text;
                string endText = EndYearMonthTextBox.Text;

                int startYear = Int32.Parse(startText.Substring(0, 4));
                int startMonth = Int32.Parse(startText.Substring(4, 2));
                int endYear = Int32.Parse(endText.Substring(0, 4));
                int endMonth = Int32.Parse(endText.Substring(4, 2));

                DateTime startDate = new DateTime(startYear, startMonth, 1);
                DateTime endDate = new DateTime(endYear, endMonth, 1);

                // 장소 체크박스 상태 확인
                bool hasLocationChecked = (LOC4.IsChecked == true ||
                                         LOC5.IsChecked == true ||
                                         LOC6.IsChecked == true ||
                                         LOC7.IsChecked == true);

                // 데이터 필터링
                List<CapaData> filteredData = new List<CapaData>();

                foreach (CapaData data in masterCapaData)
                {
                    // 날짜 범위 체크
                    int dataYear = Int32.Parse(data.Yyyy);
                    int dataMonth = Int32.Parse(data.Mm);
                    DateTime dataDate = new DateTime(dataYear, dataMonth, 1);

                    if (dataDate < startDate || dataDate > endDate)
                        continue;

                    // PE_EQUIP이 'C'인지 확인
                    if (data.PeEquip != "C")
                        continue;

                    bool shouldInclude = false;

                    // 본사 데이터 처리
                    if (data.MfgDesc == "본사" && CheckHeadquarters.IsChecked == true)
                    {
                        if (hasLocationChecked)
                        {
                            if ((data.PeMocNm == "1D 서" && LOC4.IsChecked == true) ||
                                (data.PeMocNm == "총조장" && LOC5.IsChecked == true) ||
                                (data.PeMocNm == "2 - 3D" && LOC6.IsChecked == true) ||
                                (data.PeMocNm == "4D 동" && LOC7.IsChecked == true))
                            {
                                shouldInclude = true;
                            }
                        }
                        else
                        {
                            shouldInclude = true;
                        }
                    }
                    else if (data.MfgDesc == "해양" && CheckMarine.IsChecked == true)
                    {
                        shouldInclude = true;
                    }
                    else if (data.MfgDesc == "온산" && CheckOnsan.IsChecked == true)
                    {
                        shouldInclude = true;
                    }

                    if (shouldInclude)
                    {
                        filteredData.Add(data);
                    }
                }

                // 필터링된 데이터로 리미트 데이터 생성
                foreach (CapaData data in filteredData)
                {
                    string yearMonth = string.Format("{0}/{1}", data.Yyyy, data.Mm.PadLeft(2, '0'));

                    if (!filteredLimitData.ContainsKey(yearMonth))
                    {
                        Dictionary<string, Dictionary<string, double>> monthDict =
                            new Dictionary<string, Dictionary<string, double>>();
                        monthDict["CAPA2"] = new Dictionary<string, double>();
                        monthDict["CAPA2_1"] = new Dictionary<string, double>();
                        filteredLimitData[yearMonth] = monthDict;
                    }

                    if (!filteredLimitData[yearMonth]["CAPA2"].ContainsKey(data.MfgDesc))
                    {
                        filteredLimitData[yearMonth]["CAPA2"][data.MfgDesc] = 0;
                        filteredLimitData[yearMonth]["CAPA2_1"][data.MfgDesc] = 0;
                    }

                    // 값 누적
                    filteredLimitData[yearMonth]["CAPA2"][data.MfgDesc] += data.Capa2;
                    filteredLimitData[yearMonth]["CAPA2_1"][data.MfgDesc] += data.Capa2_1;
                }

                // 그래프 업데이트
                DrawGraph2();
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("데이터 필터링 중 오류가 발생했습니다: {0}", ex.Message),
                               "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private Dictionary<string, double> GetFilteredCapa2Data()
        {
            Dictionary<string, double> monthlySum = new Dictionary<string, double>();

            try
            {
                if (masterCapaData == null)
                    return monthlySum;

                string startYearMonth = StartYearMonthTextBox.Text;
                string endYearMonth = EndYearMonthTextBox.Text;

                string startYear = startYearMonth.Substring(0, 4);
                string endYear = endYearMonth.Substring(0, 4);
                int startMonth = Int32.Parse(startYearMonth.Substring(4, 2));
                int endMonth = Int32.Parse(endYearMonth.Substring(4, 2));

                var filteredData = from data in masterCapaData
                                   where data.Yyyy == startYear  // 시작 년도와 같은 데이터만
                                   && int.Parse(data.Mm) >= startMonth
                                   && int.Parse(data.Mm) <= endMonth
                                   && data.PeEquip == "C"
                                   && (
                                       (data.MfgDesc == "본사" && CheckHeadquarters.IsChecked == true) ||
                                       (data.MfgDesc == "해양" && CheckMarine.IsChecked == true) ||
                                       (data.MfgDesc == "온산" && CheckOnsan.IsChecked == true)
                                   )
                                   select data;

                foreach (var data in filteredData)
                {
                    string yearMonth = data.Yyyy + "/" + data.Mm.PadLeft(2, '0');

                    switch (data.MfgDesc)
                    {
                        case "본사":
                            if (CheckHeadquarters.IsChecked == true)
                            {
                                if (!monthlySum.ContainsKey(yearMonth))
                                    monthlySum[yearMonth] = 0;
                                monthlySum[yearMonth] += data.Capa2;
                            }
                            break;

                        case "해양":
                            if (CheckMarine.IsChecked == true)
                            {
                                if (!monthlySum.ContainsKey(yearMonth))
                                    monthlySum[yearMonth] = 0;
                                monthlySum[yearMonth] += data.Capa2;
                            }
                            break;

                        case "온산":
                            if (CheckOnsan.IsChecked == true)
                            {
                                if (!monthlySum.ContainsKey(yearMonth))
                                    monthlySum[yearMonth] = 0;
                                monthlySum[yearMonth] += data.Capa2;
                            }
                            break;
                    }
                }

                string message = "";
                foreach (var kvp in monthlySum)
                {
                    message += string.Format("기간: {0}, LOAD2 합계: {1}\n", kvp.Key, kvp.Value);
                }
                MessageBox.Show(message, "LOAD2 합산 결과");
            }
            catch (Exception ex)
            {
                MessageBox.Show("LOAD2 데이터 처리 중 오류 발생: " + ex.Message);
            }

            return monthlySum;
        }

        private void BusinessLocation_CheckBox_Changed(object sender, RoutedEventArgs e)
        {
            try
            {
                //UpdateFilteredData();
                GetFilteredCapa2Data(); // 새로운 메서드 호출
            }
            catch (Exception ex)
            {
                MessageBox.Show("데이터 필터링 중 오류가 발생했습니다: " + ex.Message, "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void Location_CheckBox_Changed(object sender, RoutedEventArgs e)
        {
            try
            {
                // 장소 체크박스가 변경될 때마다 CAPA 리미트 데이터를 다시 필터링
                if (masterCapaData != null)
                {
                    FilterCapaData();
                }

                // 기존 데이터도 다시 로드
                LoadData();

                // capeData 필터링
                FilterCapeDataByDate();

                // 그래프 다시 그리기
                DrawGraph2();

                // 데이터 그리드 업데이트
                UpdateDataGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("데이터 필터링 중 오류가 발생했습니다: " + ex.Message,
                    "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Equipment_CheckBox_Changed(object sender, RoutedEventArgs e)
        {
            try
            {
                UpdateFilteredData(); // 동기 메서드 호출
            }
            catch (Exception ex)
            {
                MessageBox.Show("데이터 필터링 중 오류가 발생했습니다: " + ex.Message, "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        //디버그 나중에 제거완료
        private void UpdateFilteredData()
        {
            lock (_lockObject)
            {
                // masterCapaData가 null인 경우 조기 반환
                if (masterCapaData == null)
                {
                    return;
                }

                // UI 값 가져오기
                string startYearMonth = StartYearMonthTextBox.Text;
                string endYearMonth = EndYearMonthTextBox.Text;

                // 입력값 검증
                if (string.IsNullOrEmpty(startYearMonth) || string.IsNullOrEmpty(endYearMonth))
                {
                    MessageBox.Show("년도와 월을 모두 입력해주세요.", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                try
                {
                    // GraphCanvas2 초기화
                    GraphCanvas2.Children.Clear();

                    // 필터링 로직
                    filteredLimitData = new Dictionary<string, Dictionary<string, Dictionary<string, double>>>();
                    List<CapaData> filteredList = new List<CapaData>();

                    // yearText, startMonth, endMonth 추출
                    string yearValue = startYearMonth.Substring(0, 4);
                    string startMonthValue = startYearMonth.Substring(4, 2);
                    string endMonthValue = endYearMonth.Substring(4, 2);

                    // 데이터 필터링
                    foreach (CapaData data in masterCapaData)
                    {
                        if (data.Yyyy == yearValue &&
                            int.Parse(data.Mm) >= int.Parse(startMonthValue) &&
                            int.Parse(data.Mm) <= int.Parse(endMonthValue) &&
                            data.PeEquip == "C")
                        {
                            bool isValidLocation = false;
                            if (data.MfgDesc == "본사" && CheckHeadquarters.IsChecked == true)
                                isValidLocation = true;
                            else if (data.MfgDesc == "해양" && CheckMarine.IsChecked == true)
                                isValidLocation = true;
                            else if (data.MfgDesc == "온산" && CheckOnsan.IsChecked == true)
                                isValidLocation = true;

                            if (isValidLocation)
                            {
                                filteredList.Add(data);
                                string yearMonth = data.Yyyy + "/" + data.Mm;

                                if (!filteredLimitData.ContainsKey(yearMonth))
                                {
                                    filteredLimitData[yearMonth] = new Dictionary<string, Dictionary<string, double>>();
                                    filteredLimitData[yearMonth]["CAPA2"] = new Dictionary<string, double>();
                                }

                                if (!filteredLimitData[yearMonth]["CAPA2"].ContainsKey(data.MfgDesc))
                                {
                                    filteredLimitData[yearMonth]["CAPA2"][data.MfgDesc] = 0;
                                }
                                filteredLimitData[yearMonth]["CAPA2"][data.MfgDesc] += data.Capa2;
                            }
                        }
                    }

                    // 그래프 업데이트
                    if (filteredList.Count > 0)
                    {
                        // 메인 그래프 업데이트
                        DrawGraph2();

                        // 각 위치별 그래프 업데이트
                        if (CheckHeadquarters.IsChecked == true)
                            DrawLocationGraph(HeadquartersCanvas, "본사");
                        if (CheckOnsan.IsChecked == true)
                            DrawLocationGraph(OnsanCanvas, "온산");
                        if (CheckMarine.IsChecked == true)
                            DrawLocationGraph(MarineCanvas, "해양");

                        // 캔버스 제목 추가
                        AddCanvasTitles();
                    }
                    else
                    {
                        MessageBox.Show("표시할 데이터가 없습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(string.Format("데이터 처리 중 오류 발생: {0}", ex.Message),
                        "오류", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }



        // Window Closing 이벤트에서 리소스 정리
        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            base.OnClosing(e);

            if (_filterCancellationTokenSource != null)
            {
                _filterCancellationTokenSource.Cancel();
                _filterCancellationTokenSource.Dispose();
            }

            if (loadData != null)
            {
                loadData.Clear();
                loadData = null;
            }
            GC.Collect();
        }


        private bool IsEquipmentSelected(string peEquip)
        {
            return Dispatcher.Invoke(() =>
            {
                switch (peEquip)
                {
                    case "C":
                        return EQPC.IsChecked == true;
                    //case "T":
                    //return EQPT.IsChecked == true;
                    default:
                        return false;
                }
            });
        }

        private bool IsLocationSelected(string peMocNm)
        {
            return Dispatcher.Invoke(() =>
            {
                switch (peMocNm)
                {
                    case "1D 서":
                        return LOC4.IsChecked == true;
                    case "총조장":
                        return LOC5.IsChecked == true;
                    case "2 - 3D":
                        return LOC6.IsChecked == true;
                    case "4D 동":
                        return LOC7.IsChecked == true;
                    default:
                        return false;
                }
            });
        }

        private void ProcessCapaValue(object[,] values, int row, Dictionary<string, int> headers,
            string yearMonth, string mfgDesc)
        {
            string[] capaTypes = new string[] { "CAPA1", "CAPA2", "CAPA1_1", "CAPA2_1" };
            foreach (string capaType in capaTypes)
            {
                if (headers.ContainsKey(capaType))
                {
                    double capaValue;
                    if (Double.TryParse(Convert.ToString(values[row, headers[capaType]]), out capaValue))
                    {
                        if (!limitData[yearMonth][capaType].ContainsKey(mfgDesc))
                        {
                            limitData[yearMonth][capaType][mfgDesc] = 0;
                        }
                        limitData[yearMonth][capaType][mfgDesc] += capaValue;
                    }
                }
            }
        }
        private void UpdateLimitLinesLegacy()
        {
            if (filteredCapeData == null || filteredCapeData.Count == 0) return;

            double canvasWidth = GraphCanvas2.ActualWidth;
            double canvasHeight = GraphCanvas2.ActualHeight;
            double graphWidth = canvasWidth - (GraphMargin * 2);
            double graphHeight = canvasHeight - (GraphMargin * 2);

            // 기존 리미트 라인 제거
            List<UIElement> elementsToRemove = new List<UIElement>();
            foreach (UIElement element in GraphCanvas2.Children)
            {
                Line line = element as Line;
                if (line != null && line.Tag != null && line.Tag.ToString().StartsWith("Limit_"))
                {
                    elementsToRemove.Add(element);
                }
            }
            foreach (UIElement element in elementsToRemove)
            {
                GraphCanvas2.Children.Remove(element);
            }

            // 날짜 정렬
            List<DateTime> sortedDates = new List<DateTime>(filteredCapeData.Keys);
            sortedDates.Sort();

            foreach (DateTime date in sortedDates)
            {
                string yearMonth = string.Format("{0}/{1:00}", date.Year, date.Month);
                if (!limitData.ContainsKey(yearMonth)) continue;

                Dictionary<string, Dictionary<string, double>> monthData = limitData[yearMonth];
                int dateIndex = sortedDates.IndexOf(date);

                //if (CAPA1.IsChecked == true)
                //DrawCapaLimitLine(monthData, "CAPA1", Brushes.Green, dateIndex, sortedDates.Count, graphWidth, graphHeight);
                if (CAPA2.IsChecked == true)
                    DrawCapaLimitLine(monthData, "CAPA2", Brushes.Orange, dateIndex, sortedDates.Count, graphWidth, graphHeight);
                //if (CAPA1_1.IsChecked == true)
                //DrawCapaLimitLine(monthData, "CAPA1_1", Brushes.Purple, dateIndex, sortedDates.Count, graphWidth, graphHeight);
                if (CAPA2_1.IsChecked == true)
                    DrawCapaLimitLine(monthData, "CAPA2_1", Brushes.DeepSkyBlue, dateIndex, sortedDates.Count, graphWidth, graphHeight);
            }
        }


        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!ValidateDateRange())
                    return;

                LoadData();

                if (loadData == null || loadData.Count == 0)
                {
                    MessageBox.Show("조회된 데이터가 없습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                // capeData 필터링
                FilterCapeDataByDate();

                // 리미트 데이터 필터링
                if (masterCapaData != null)
                {
                    FilterCapaData();
                }

                // 데이터 그리드 업데이트
                UpdateDataGrid();
                // Business_Check가 체크되어 있을 때만 ShowMaxDataPanel 표시
                //if (Business_Check != null && Business_Check.IsChecked == true)
                //{
                //ShowMaxDataPanel();
                //}

                // 개별 위치별 창 업데이트를 먼저 수행
                foreach (Window window in Application.Current.Windows)
                {
                    DailyLoadWindow dailyLoadWindow = window as DailyLoadWindow;
                    if (dailyLoadWindow != null && dailyLoadWindow.Location != "통합") // 통합 창 제외
                    {
                        try
                        {
                            MonthlyLoadData selectedData = null;
                            foreach (MonthlyLoadData data in loadData)
                            {
                                if (data.Month == dailyLoadWindow.CurrentMonth)
                                {
                                    selectedData = data;
                                    break;
                                }
                            }

                            if (selectedData != null)
                            {
                                var mainWindow = Owner as MainWindow;
                                if (mainWindow != null && mainWindow.ShipDataGrid.ItemsSource != null)
                                {
                                    var items = mainWindow.ShipDataGrid.ItemsSource as List<ShipSchedule>;
                                    if (items != null)
                                    {
                                        List<ShipSchedule> locationData = new List<ShipSchedule>();
                                        foreach (ShipSchedule item in items)
                                        {
                                            if (item != null &&
                                                item.MFG_IND_After == dailyLoadWindow.Location &&
                                                ValidateShipSchedule(item))
                                            {
                                                locationData.Add(item);
                                            }
                                        }

                                        var limitDataForLocation = GetLimitDataForMonth(selectedData.Month, dailyLoadWindow.Location);
                                        if (ValidateLimitData(limitDataForLocation))
                                        {
                                            dailyLoadWindow.UpdateData(locationData, limitDataForLocation);
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception windowEx)
                        {
                            MessageBox.Show(string.Format("{0} 창 업데이트 중 오류 발생: {1}",
                                dailyLoadWindow.Location, windowEx.Message),
                                "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    }
                }

                // 메인 그래프 업데이트
                DrawGraph2();
                // 트랜스포즈된 데이터 그리드 표시
                TransposeDataGrid();
                // 마지막으로 통합 창 업데이트
                foreach (Window window in Application.Current.Windows)
                {
                    DailyLoadWindow dailyLoadWindow = window as DailyLoadWindow;
                    if (dailyLoadWindow != null && dailyLoadWindow.Location == "통합")
                    {
                        try
                        {
                            MonthlyLoadData selectedData = null;
                            foreach (MonthlyLoadData data in loadData)
                            {
                                if (data.Month == dailyLoadWindow.CurrentMonth)
                                {
                                    selectedData = data;
                                    break;
                                }
                            }

                            if (selectedData != null)
                            {
                                var mainWindow = Owner as MainWindow;
                                if (mainWindow != null && mainWindow.ShipDataGrid.ItemsSource != null)
                                {
                                    var items = mainWindow.ShipDataGrid.ItemsSource as List<ShipSchedule>;
                                    if (items != null)
                                    {
                                        var limitDataForLocation = GetLimitDataForMonth(selectedData.Month, "통합");
                                        if (ValidateLimitData(limitDataForLocation))
                                        {
                                            // 데이터 유효성 검사 후 통합 창 업데이트
                                            List<ShipSchedule> validItems = new List<ShipSchedule>();
                                            foreach (ShipSchedule item in items)
                                            {
                                                if (item != null && ValidateShipSchedule(item))
                                                {
                                                    validItems.Add(item);
                                                }
                                            }

                                            //dailyLoadWindow.UpdateData(validItems, limitDataForLocation);
                                        }
                                    }
                                }
                            }
                        }

                        catch (Exception windowEx)
                        {
                            MessageBox.Show("통합 창 업데이트 중 오류 발생: " + windowEx.Message,
                                "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("데이터 조회 중 오류가 발생했습니다: {0}", ex.Message),
                    "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // 데이터 유효성 검사 메서드 추가
        private bool ValidateShipSchedule(ShipSchedule schedule)
        {
            return schedule.WKSTPLDT1 != DateTime.MinValue &&
                   schedule.WKFIPLDT != DateTime.MinValue &&
                   schedule.ERECT_PLDT != DateTime.MinValue;
        }

        private bool ValidateLimitData(Dictionary<string, Dictionary<DateTime, double>> limitData)
        {
            if (limitData == null)
                return false;

            foreach (var typeData in limitData)
            {
                foreach (var dateValue in typeData.Value)
                {
                    if (double.IsNaN(dateValue.Value) || double.IsInfinity(dateValue.Value))
                        return false;
                }
            }
            return true;
        }
        private Dictionary<DateTime, Tuple<int, int>> filteredCapeData;

        private void FilterCapeDataByDate()
        {
            if (capeData == null) return;

            // 선택한 날짜 범위 가져오기
            DateTime startDate = ParseYearMonth(StartDatePicker.Text);
            DateTime endDate = ParseYearMonth(EndDatePicker.Text);

            // 날짜 범위에 포함되는 데이터만 필터링
            filteredCapeData = capeData
                .Where(kv => kv.Key >= startDate && kv.Key <= endDate)
                .ToDictionary(kv => kv.Key, kv => kv.Value);
        }


        private bool ValidateDateRange()
        {
            if (string.IsNullOrEmpty(StartYearMonthTextBox.Text) || string.IsNullOrEmpty(EndYearMonthTextBox.Text))
            {
                MessageBox.Show("시작일과 종료일을 모두 입력해주세요. (예: 202401)", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            try
            {
                string startText = StartYearMonthTextBox.Text;
                string endText = EndYearMonthTextBox.Text;

                if (startText.Length != 6 || endText.Length != 6)
                {
                    MessageBox.Show("날짜는 YYYYMM 형식으로 입력해주세요. (예: 202401)", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                int startYear = int.Parse(startText.Substring(0, 4));
                int startMonth = int.Parse(startText.Substring(4, 2));
                int endYear = int.Parse(endText.Substring(0, 4));
                int endMonth = int.Parse(endText.Substring(4, 2));

                if (startMonth < 1 || startMonth > 12 || endMonth < 1 || endMonth > 12)
                {
                    MessageBox.Show("월은 1~12 사이의 값이어야 합니다.", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                DateTime startDate = new DateTime(startYear, startMonth, 1);
                DateTime endDate = new DateTime(endYear, endMonth, 1);

                if (startDate > endDate)
                {
                    MessageBox.Show("시작일이 종료일보다 늦을 수 없습니다.", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }

                return true;
            }
            catch
            {
                MessageBox.Show("올바른 날짜를 입력해주세요. (예: 202401)", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
        }

        //private DateTime ParseYearMonth(string yearMonth)
        //{
        //    try
        //    {
        //        if (yearMonth.Length != 6)
        //            throw new Exception("Invalid date format");

        //        int year = Convert.ToInt32(yearMonth.Substring(0, 4));
        //        int month = Convert.ToInt32(yearMonth.Substring(4, 2));
        //        return new DateTime(year, month, 1);
        //    }
        //    catch
        //    {
        //        throw new Exception("Invalid date format");
        //    }
        //}
        //private DateTime ParseYearMonth(string yearMonth)
        //{
        //    try
        //    {
        //        // 입력값 로깅
        //        Console.WriteLine("Input yearMonth: " + yearMonth);

        //        if (string.IsNullOrEmpty(yearMonth))
        //            throw new Exception("yearMonth is null or empty");

        //        if (yearMonth.Length != 6)
        //            throw new Exception("Invalid length: " + yearMonth.Length);

        //        int year = Convert.ToInt32(yearMonth.Substring(0, 4));
        //        int month = Convert.ToInt32(yearMonth.Substring(4, 2));

        //        // 월 유효성 검사
        //        if (month < 1 || month > 12)
        //            throw new Exception("Invalid month: " + month);

        //        return new DateTime(year, month, 1);
        //    }
        //    catch (Exception ex)
        //    {
        //        // 구체적인 오류 메시지 출력
        //        Console.WriteLine("Error details: " + ex.Message);
        //        throw;
        //    }
        //}
        private DateTime ParseYearMonth(string yearMonth)
        {
            try
            {
                // null 또는 빈 문자열 체크
                if (string.IsNullOrEmpty(yearMonth))
                {
                    // 기본값으로 현재 날짜 반환
                    return DateTime.Now;
                }

                // 입력값 정리
                string cleanYearMonth = yearMonth.Trim();

                // 길이 체크
                if (cleanYearMonth.Length != 6)
                {
                    // 기본값으로 현재 날짜 반환
                    return DateTime.Now;
                }

                // 숫자가 아닌 문자가 있는지 체크
                if (!cleanYearMonth.All(char.IsDigit))
                {
                    // 기본값으로 현재 날짜 반환
                    return DateTime.Now;
                }

                // 년도와 월 파싱
                int year = Convert.ToInt32(cleanYearMonth.Substring(0, 4));
                int month = Convert.ToInt32(cleanYearMonth.Substring(4, 2));

                // 유효한 범위 체크
                if (year < 2000 || year > 2100 || month < 1 || month > 12)
                {
                    // 기본값으로 현재 날짜 반환
                    return DateTime.Now;
                }

                return new DateTime(year, month, 1);
            }
            catch (Exception)
            {
                // 어떤 예외가 발생하더라도 현재 날짜 반환
                return DateTime.Now;
            }
        }

        private bool ValidateDateInput(string input)
        {
            if (input.Length != 6) return false;

            try
            {
                int year = Convert.ToInt32(input.Substring(0, 4));
                int month = Convert.ToInt32(input.Substring(4, 2));

                if (year < 1900 || year > 9999 || month < 1 || month > 12)
                    return false;

                return true;
            }
            catch
            {
                return false;
            }
        }

        private string connectionString = ConfigurationManager.ConnectionStrings["DevShipDbOracle"].ConnectionString;

        private string CalculateCapacityIndex(MonthlyLoadData data, Dictionary<string, Dictionary<string, double>> productionData)
        {
            // CAPA1 값을 계산
            if (productionData.ContainsKey(data.Month) && productionData[data.Month].ContainsKey("CAPA1"))
            {
                double capa1 = productionData[data.Month]["CAPA1"];
                return capa1.ToString(); // CAPA1 값을 문자열로 반환
            }
            return "0"; // 데이터가 없을 경우 0 반환
        }

        private string CalculateCapacityIndex_ch(MonthlyLoadData data, Dictionary<string, Dictionary<string, double>> productionData)
        {
            // 해당 월에 CAPA1_1 데이터가 존재하는지 확인
            if (productionData.ContainsKey(data.Month) && productionData[data.Month].ContainsKey("CAPA1_1"))
            {
                double capa1_1 = productionData[data.Month]["CAPA1_1"];
                return capa1_1.ToString(); // CAPA1_1 값을 문자열로 반환
            }
            return "0"; // 데이터가 없을 경우 0 반환
        }

        private void LoadData()
        {
            if (loadData == null)
                loadData = new List<MonthlyLoadData>();
            else
                loadData.Clear();

            DateTime startDateValue = ParseYearMonth(StartDatePicker.Text);
            DateTime endDateValue = ParseYearMonth(EndDatePicker.Text);

            var mainWindow = Owner as MainWindow;
            if (mainWindow != null && mainWindow.ShipDataGrid.ItemsSource != null)
            {
                var items = mainWindow.ShipDataGrid.ItemsSource as List<ShipSchedule>;

                for (DateTime date = startDateValue; date <= endDateValue; date = date.AddMonths(1))
                {
                    string formattedMonth = string.Format("{0}/{1:00}", date.Year, date.Month);

                    double maxMidSchedule = 0;
                    double maxAdjustment = 0;

                    if (items != null)
                    {
                        ShipSchedule capeCountRow = null;
                        ShipSchedule capeResultRow = null;

                        foreach (var item in items)
                        {
                            if (item.S_KIND == "LOAD 중일정개수")
                                capeCountRow = item;
                            else if (item.S_KIND == "LOAD 조정결과개수")
                                capeResultRow = item;

                            if (capeCountRow != null && capeResultRow != null)
                                break;
                        }

                        if (capeCountRow != null && capeResultRow != null &&
                            capeCountRow.MonthlyDates != null && capeResultRow.MonthlyDates != null)
                        {
                            DateTime baseDate = startDateValue;  // 기준 날짜를 시작일로 변경
                            int monthDiff = ((date.Year - baseDate.Year) * 12) + (date.Month - baseDate.Month);

                            if (monthDiff >= 0 && monthDiff < capeCountRow.MonthlyDates.Count)
                            {
                                var countMonthDates = capeCountRow.MonthlyDates[monthDiff] as List<DateCell>;
                                var resultMonthDates = capeResultRow.MonthlyDates[monthDiff] as List<DateCell>;

                                if (countMonthDates != null)
                                {
                                    foreach (DateCell cell in countMonthDates)
                                    {
                                        int tempValue;
                                        if (int.TryParse(cell.Day, out tempValue))
                                        {
                                            maxMidSchedule = Math.Max(maxMidSchedule, tempValue);
                                        }
                                    }
                                }

                                if (resultMonthDates != null)
                                {
                                    foreach (DateCell cell in resultMonthDates)
                                    {
                                        int tempValue;
                                        if (int.TryParse(cell.Day, out tempValue))
                                        {
                                            maxAdjustment = Math.Max(maxAdjustment, tempValue);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    MonthlyLoadData monthData = new MonthlyLoadData();
                    monthData.Month = formattedMonth;

                    if (productionData != null && productionData.ContainsKey(formattedMonth))
                    {
                        var prodData = productionData[formattedMonth];
                        monthData.Headquarters = prodData["Headquarters"];
                        monthData.Yeyang = prodData["Yeyang"];
                        monthData.Unsan = prodData["Unsan"];
                        monthData.Total = prodData["Headquarters"] + prodData["Yeyang"] + prodData["Unsan"];
                    }
                    else
                    {
                        monthData.Headquarters = 0;
                        monthData.Yeyang = 0;
                        monthData.Unsan = 0;
                        monthData.Total = maxMidSchedule > 0 ? maxMidSchedule : maxAdjustment > 0 ? maxAdjustment : 50;
                    }

                    monthData.MidSchedule = maxMidSchedule;
                    monthData.Adjustment = maxAdjustment;
                    monthData.MidScheduleDiff = monthData.Total - maxMidSchedule;

                    if (monthData.Total > 0)
                    {
                        monthData.MidSchedulePercent = maxMidSchedule != 0 ?
                            string.Format("{0}%", Math.Round((maxMidSchedule / monthData.Total) * 100)) : "0%";
                        monthData.AdjustmentPercent = maxAdjustment != 0 ?
                            string.Format("{0}%", Math.Round((maxAdjustment / monthData.Total) * 100)) : "0%";
                    }
                    else
                    {
                        monthData.MidSchedulePercent = "0%";
                        monthData.AdjustmentPercent = "0%";
                    }

                    monthData.AdjustmentDiff = monthData.Total - maxAdjustment;
                    monthData.CapacityIndex_ch = CalculateCapacityIndex_ch(monthData, productionData);
                    monthData.CapacityIndex = CalculateCapacityIndex(monthData, productionData);
                    loadData.Add(monthData);
                }
            }
        }


        private void DrawGrid2ForLocation(Canvas canvas, double graphWidth, double graphHeight, double maxValue)
        {
            // Y축의 그리드 라인과 레이블 그리기
            for (int i = 0; i <= maxValue; i += 50)
            {
                double y = GraphMargin + (graphHeight * (1 - (i / maxValue)));

                // 그리드 라인
                var gridLine = new Line
                {
                    X1 = GraphMargin,
                    Y1 = y,
                    X2 = graphWidth + GraphMargin,
                    Y2 = y,
                    Stroke = new SolidColorBrush(Color.FromArgb(40, 0, 0, 0)),
                    StrokeThickness = 1
                };
                canvas.Children.Add(gridLine);

                // Y축 레이블
                TextBlock label = new TextBlock
                {
                    Text = i.ToString(),
                    FontSize = 10
                };
                Canvas.SetLeft(label, 5);
                Canvas.SetTop(label, y - 8);
                canvas.Children.Add(label);
            }

            // Y축 라인
            var yAxis = new Line
            {
                X1 = GraphMargin,
                Y1 = GraphMargin,
                X2 = GraphMargin,
                Y2 = graphHeight + GraphMargin,
                Stroke = Brushes.Black,
                StrokeThickness = 1
            };
            canvas.Children.Add(yAxis);
        }

        private void DrawXAxis2ForLocation(Canvas canvas, double graphWidth, double graphHeight,
            Dictionary<DateTime, Tuple<int, int>> locationData)
        {
            // X축 기본 라인
            Line xAxis = new Line
            {
                X1 = GraphMargin,
                Y1 = graphHeight + GraphMargin,
                X2 = graphWidth + GraphMargin,
                Y2 = graphHeight + GraphMargin,
                Stroke = Brushes.Black,
                StrokeThickness = 1
            };
            canvas.Children.Add(xAxis);

            if (locationData.Count <= 1) return;

            // X축 레이블 (월 표시)
            var sortedDates = locationData.Keys.OrderBy(d => d).ToList();
            double xInterval = graphWidth / (sortedDates.Count - 1);
            HashSet<string> displayedMonths = new HashSet<string>();

            for (int i = 0; i < sortedDates.Count; i++)
            {
                string currentMonth = sortedDates[i].ToString("yyyy/MM");
                if (displayedMonths.Contains(currentMonth)) continue;

                displayedMonths.Add(currentMonth);

                TextBlock label = new TextBlock
                {
                    Text = currentMonth,
                    FontSize = 10
                };

                double x = GraphMargin + (i * xInterval);
                Canvas.SetLeft(label, x - 20);
                Canvas.SetTop(label, graphHeight + GraphMargin + 5);
                canvas.Children.Add(label);
            }
        }

        private void DrawDataLineForLocation(Canvas canvas,
            List<KeyValuePair<DateTime, Tuple<int, int>>> sortedData,
            Func<KeyValuePair<DateTime, Tuple<int, int>>, double> getValue,
            Brush color, double graphWidth, double graphHeight, double maxValue)
        {
            Polyline polyline = new Polyline
            {
                Stroke = color,
                StrokeThickness = 2
            };

            PointCollection points = new PointCollection();
            double xInterval = graphWidth / (sortedData.Count - 1);

            // 월별 최대값을 저장할 Dictionary
            Dictionary<string, KeyValuePair<double, Point>> monthlyMaxValues = new Dictionary<string, KeyValuePair<double, Point>>();

            // 모든 데이터 포인트를 그리되, 월별 최대값만 따로 저장
            for (int i = 0; i < sortedData.Count; i++)
            {
                double x = GraphMargin + (i * xInterval);
                double value = getValue(sortedData[i]);
                double y = GraphMargin + (graphHeight * (1 - (value / maxValue)));
                Point currentPoint = new Point(x, y);
                points.Add(currentPoint);

                string monthKey = sortedData[i].Key.ToString("yyyy/MM");

                if (!monthlyMaxValues.ContainsKey(monthKey) ||
                    value > monthlyMaxValues[monthKey].Key)
                {
                    monthlyMaxValues[monthKey] = new KeyValuePair<double, Point>(value, currentPoint);
                }

                // 데이터 포인트 마커 추가
                Ellipse marker = new Ellipse
                {
                    Width = 6,
                    Height = 6,
                    Fill = color,
                    Stroke = Brushes.White,
                    StrokeThickness = 1
                };

                Canvas.SetLeft(marker, x - 3);
                Canvas.SetTop(marker, y - 3);
                canvas.Children.Add(marker);
            }

            // 각 월의 최대값만 텍스트로 표시
            foreach (var monthMax in monthlyMaxValues)
            {
                TextBlock valueLabel = new TextBlock
                {
                    Text = monthMax.Value.Key.ToString("F1"),
                    Foreground = color,
                    FontSize = 10,
                    FontWeight = FontWeights.Bold
                };

                Canvas.SetLeft(valueLabel, monthMax.Value.Value.X - 15);
                Canvas.SetTop(valueLabel, monthMax.Value.Value.Y - 15);
                canvas.Children.Add(valueLabel);
            }

            polyline.Points = points;
            canvas.Children.Add(polyline);
        }


        private void DrawGridOnCanvas(Canvas targetCanvas, double maxValue)
        {
            targetCanvas.Children.Clear();

            double canvasWidth = targetCanvas.ActualWidth;
            double canvasHeight = targetCanvas.ActualHeight;
            double graphWidth = canvasWidth - (GraphMargin * 2);
            double graphHeight = canvasHeight - (GraphMargin * 2);

        }

        private void AddCanvasTitles()
        {
            // 본사 캔버스 제목과 체크박스
            TextBlock headquartersTitle = new TextBlock
            {
                Text = "본사",
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black
            };
            Canvas.SetLeft(headquartersTitle, 10);
            Canvas.SetTop(headquartersTitle, 10);
            HeadquartersCanvas.Children.Add(headquartersTitle);

            CheckBox headquartersBox1 = new CheckBox
            {
                Content = "PE 수량",
                FontSize = 11
            };
            Canvas.SetLeft(headquartersBox1, 10);
            Canvas.SetTop(headquartersBox1, 40);
            //HeadquartersCanvas.Children.Add(headquartersBox1);

            CheckBox headquartersBox2 = new CheckBox
            {
                Content = "PE 수량조정",
                FontSize = 11
            };
            Canvas.SetLeft(headquartersBox2, 100);
            Canvas.SetTop(headquartersBox2, 40);
            // HeadquartersCanvas.Children.Add(headquartersBox2);

            // 온산 캔버스 제목과 체크박스
            TextBlock onsanTitle = new TextBlock
            {
                Text = "온산",
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black
            };
            Canvas.SetLeft(onsanTitle, 10);
            Canvas.SetTop(onsanTitle, 10);
            OnsanCanvas.Children.Add(onsanTitle);

            CheckBox onsanBox1 = new CheckBox
            {
                Content = "PE 수량",
                FontSize = 11
            };
            Canvas.SetLeft(onsanBox1, 10);
            Canvas.SetTop(onsanBox1, 40);
            //OnsanCanvas.Children.Add(onsanBox1);

            CheckBox onsanBox2 = new CheckBox
            {
                Content = "PE 수량조정",
                FontSize = 11
            };
            Canvas.SetLeft(onsanBox2, 100);
            Canvas.SetTop(onsanBox2, 40);
            // OnsanCanvas.Children.Add(onsanBox2);

            // 해양 캔버스 제목과 체크박스
            TextBlock marineTitle = new TextBlock
            {
                Text = "해양",
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.Black
            };
            Canvas.SetLeft(marineTitle, 10);
            Canvas.SetTop(marineTitle, 10);
            MarineCanvas.Children.Add(marineTitle);

            CheckBox marineBox1 = new CheckBox
            {
                Content = "PE 수량",
                FontSize = 11
            };
            Canvas.SetLeft(marineBox1, 10);
            Canvas.SetTop(marineBox1, 40);
            //MarineCanvas.Children.Add(marineBox1);

            CheckBox marineBox2 = new CheckBox
            {
                Content = "PE 수량조정",
                FontSize = 11
            };
            Canvas.SetLeft(marineBox2, 100);
            Canvas.SetTop(marineBox2, 40);
            //MarineCanvas.Children.Add(marineBox2);
        }

        private void DrawGraph2()
        {
            // 기존 DockPanel/Border 저장
            Border dataBoxBorder = null;
            DockPanel existingDockPanel = null;

            foreach (UIElement element in GraphCanvas2.Children)
            {
                Border border = element as Border;
                if (border != null)
                {
                    DockPanel dockPanel = border.Child as DockPanel;
                    if (dockPanel != null &&
                        Canvas.GetTop(border) == 10 &&
                        Canvas.GetRight(border) == 10)
                    {
                        dataBoxBorder = border;
                        existingDockPanel = dockPanel;
                        break;
                    }
                }
            }

            // Canvas 초기화 전에 필요한 컨트롤 백업
            if (dataBoxBorder == null)
            {
                // 처음 실행 시에만 새로 생성
                Border newBorder = new Border();
                newBorder.Background = new SolidColorBrush(Color.FromArgb(230, 255, 255, 255));
                newBorder.Padding = new Thickness(5);
                newBorder.CornerRadius = new CornerRadius(3);

                DockPanel dockPanel = new DockPanel();
                TextBlock hmdText = new TextBlock();
                hmdText.Text = "[HMD]";
                hmdText.FontWeight = FontWeights.Bold;
                hmdText.VerticalAlignment = VerticalAlignment.Center;
                hmdText.Margin = new Thickness(0, 0, 5, 0);
                DockPanel.SetDock(hmdText, Dock.Left);

                CheckBox mainDataBox = new CheckBox();
                mainDataBox.Content = "PE 수량";
                mainDataBox.FontSize = 11;
                mainDataBox.VerticalAlignment = VerticalAlignment.Center;
                mainDataBox.Name = "MAINDATA_BOX";
                mainDataBox.Checked += MAINDATA_BOX_CheckBox_Changed;
                mainDataBox.Unchecked += MAINDATA_BOX_CheckBox_Changed;

                CheckBox mainDataBox1 = new CheckBox();
                mainDataBox1.Content = "PE 수량조정";
                mainDataBox1.FontSize = 11;
                mainDataBox1.VerticalAlignment = VerticalAlignment.Center;
                mainDataBox1.Name = "MAINDATA_BOX1";
                mainDataBox1.Margin = new Thickness(15, 0, 5, 0);
                mainDataBox1.Checked += MAINDATA_BOX1_CheckBox_Changed;
                mainDataBox1.Unchecked += MAINDATA_BOX1_CheckBox_Changed;

                dockPanel.Children.Add(hmdText);
                dockPanel.Children.Add(mainDataBox);
                dockPanel.Children.Add(mainDataBox1);
                newBorder.Child = dockPanel;

                dataBoxBorder = newBorder;
            }

            GraphCanvas2.Children.Clear();

            // Border 재추가
            if (dataBoxBorder != null)
            {
                Canvas.SetTop(dataBoxBorder, 10);
                Canvas.SetRight(dataBoxBorder, 10);
                GraphCanvas2.Children.Add(dataBoxBorder);
            }

            // selectionBox 재추가
            if (selectionBox != null)
            {
                Panel.SetZIndex(selectionBox, 9999);
                GraphCanvas2.Children.Add(selectionBox);
            }

            if (filteredCapeData == null || filteredCapeData.Count == 0) return;


            // 데이터의 최대값 계산

            double maxValue = filteredCapeData.Values.Max(v => Math.Max(v.Item1, v.Item2));
            maxValue = Math.Max(250, Math.Ceiling((maxValue + 50) / 50.0) * 50); // 300까지 보이도록 수정

            double canvasWidth = GraphCanvas2.ActualWidth;
            double canvasHeight = GraphCanvas2.ActualHeight;
            double graphWidth = canvasWidth - (GraphMargin * 2);
            double graphHeight = canvasHeight - (GraphMargin * 2);

            // 그리드 및 축 그리기
            DrawGrid2(graphWidth, graphHeight, maxValue);
            DrawXAxis2(graphWidth, graphHeight);

            // 각 추가 Canvas에도 축 및 그리드 추가
            DrawGridOnCanvas(HeadquartersCanvas, maxValue);
            DrawGridOnCanvas(OnsanCanvas, maxValue);
            DrawGridOnCanvas(MarineCanvas, maxValue);

            var mainWindow = Owner as MainWindow;
            if (mainWindow != null && mainWindow.ShipDataGrid.ItemsSource != null)
            {
                var displayedData = mainWindow.ShipDataGrid.ItemsSource as List<ShipSchedule>;
                if (displayedData != null && displayedData.Count > 0)
                {
                    // 각 날짜별 CAPE 데이터 수집
                    Dictionary<DateTime, Tuple<int, int>> capeData = new Dictionary<DateTime, Tuple<int, int>>();
                    foreach (var kvp in filteredCapeData)
                    {
                        DateTime date = kvp.Key;
                        int originalCapeCount = 0;
                        int adjustedCapeCount = 0;

                        foreach (ShipSchedule schedule in displayedData)
                        {
                            if (schedule != null && schedule.S_KIND != "LOAD 중일정개수" &&
                                schedule.S_KIND != "LOAD 조정결과개수")
                            {
                                DateTime endDate;
                                if (schedule.STG_CD == "90")
                                {
                                    endDate = schedule.ERECT_PLDT;  // 탑재계획일
                                }
                                else if (schedule.STG_CD == "70" || schedule.STG_CD == "80")
                                {
                                    endDate = schedule.WKFIPLDT;   // 완료계획일 
                                }
                                else
                                {
                                    endDate = schedule.WKFIPLDT1;  // 완료실적일
                                }

                                if (date >= schedule.WKSTPLDT1 && date <= endDate)
                                {
                                    originalCapeCount++;

                                    // Crimson 색상 체크
                                    bool isCrimsonDate = false;
                                    if (schedule.MonthlyDates != null)
                                    {
                                        foreach (List<DateCell> monthDates in schedule.MonthlyDates)
                                        {
                                            if (monthDates != null)
                                            {
                                                foreach (DateCell cell in monthDates)
                                                {
                                                    if (cell.Day == date.Day.ToString("00") && cell.Color == Brushes.Crimson)
                                                    {
                                                        isCrimsonDate = true;
                                                        break;
                                                    }
                                                }
                                            }
                                            if (isCrimsonDate) break;
                                        }
                                    }

                                    if (!isCrimsonDate)
                                    {
                                        adjustedCapeCount++;
                                    }
                                }
                            }
                        }

                        capeData[date] = new Tuple<int, int>(originalCapeCount, adjustedCapeCount);
                    }

                    // 데이터 선 그리기
                    List<KeyValuePair<DateTime, Tuple<int, int>>> sortedData = new List<KeyValuePair<DateTime, Tuple<int, int>>>(capeData);
                    sortedData.Sort((x, y) => x.Key.CompareTo(y.Key));

                    double xInterval = graphWidth / (sortedData.Count - 1);

                    // AS-IS 선 (파란색)
                    Polyline midScheduleLine = new Polyline
                    {
                        Stroke = Brushes.Blue,
                        StrokeThickness = 2
                    };

                    // TO-BE 선 (빨간색)
                    Polyline adjustmentLine = new Polyline
                    {
                        Stroke = Brushes.Red,
                        StrokeThickness = 2
                    };

                    for (int i = 0; i < sortedData.Count; i++)
                    {
                        double x = GraphMargin + (i * xInterval);
                        double midScheduleY = GraphMargin + (graphHeight * (1 - (sortedData[i].Value.Item1 / maxValue)));
                        double adjustmentY = GraphMargin + (graphHeight * (1 - (sortedData[i].Value.Item2 / maxValue)));

                        midScheduleLine.Points.Add(new Point(x, midScheduleY));
                        adjustmentLine.Points.Add(new Point(x, adjustmentY));

                        // AS-IS 데이터 포인트
                        Ellipse midSchedulePoint = new Ellipse
                        {
                            Width = 6,
                            Height = 6,
                            Fill = Brushes.Blue,
                            Stroke = Brushes.White,
                            StrokeThickness = 1
                        };
                        Canvas.SetLeft(midSchedulePoint, x - 3);
                        Canvas.SetTop(midSchedulePoint, midScheduleY - 3);
                        GraphCanvas2.Children.Add(midSchedulePoint);

                        // TO-BE 데이터 포인트
                        Ellipse adjustmentPoint = new Ellipse
                        {
                            Width = 6,
                            Height = 6,
                            Fill = Brushes.Red,
                            Stroke = Brushes.White,
                            StrokeThickness = 1
                        };
                        Canvas.SetLeft(adjustmentPoint, x - 3);
                        Canvas.SetTop(adjustmentPoint, adjustmentY - 3);
                        GraphCanvas2.Children.Add(adjustmentPoint);
                    }

                    GraphCanvas2.Children.Add(midScheduleLine);
                    GraphCanvas2.Children.Add(adjustmentLine);
                    // 각 월별 최대값 계산 및 표시
                    Dictionary<string, double> maxValuePerMonth_TO = new Dictionary<string, double>();  // TO-BE용
                    Dictionary<string, DateTime> maxDatePerMonth_TO = new Dictionary<string, DateTime>();  // TO-BE용
                    Dictionary<string, double> maxValuePerMonth_AS = new Dictionary<string, double>();  // AS-IS용
                    Dictionary<string, DateTime> maxDatePerMonth_AS = new Dictionary<string, DateTime>();  // AS-IS용

                    foreach (var kvp in sortedData)
                    {
                        string currentMonth = kvp.Key.ToString("yyyy/MM");

                        // TO-BE (빨간색) 데이터
                        double currentValue_TO = kvp.Value.Item2;
                        if (!maxValuePerMonth_TO.ContainsKey(currentMonth) || currentValue_TO > maxValuePerMonth_TO[currentMonth])
                        {
                            maxValuePerMonth_TO[currentMonth] = currentValue_TO;
                            maxDatePerMonth_TO[currentMonth] = kvp.Key;
                        }

                        // AS-IS (파란색) 데이터
                        double currentValue_AS = kvp.Value.Item1;
                        if (!maxValuePerMonth_AS.ContainsKey(currentMonth) || currentValue_AS > maxValuePerMonth_AS[currentMonth])
                        {
                            maxValuePerMonth_AS[currentMonth] = currentValue_AS;
                            maxDatePerMonth_AS[currentMonth] = kvp.Key;
                        }
                    }

                    // TO-BE (빨간색) 최대값 텍스트 표시
                    foreach (var kvp in maxValuePerMonth_TO)
                    {
                        string month = kvp.Key;
                        double monthMaxValue = kvp.Value;
                        DateTime maxDate = maxDatePerMonth_TO[month];

                        TextBlock maxValueText = new TextBlock
                        {
                            Text = string.Format("{0:F1} ({1:yyyy/MM/dd})", monthMaxValue, maxDate),
                            FontSize = 11,
                            FontWeight = FontWeights.Bold,
                            Foreground = Brushes.Red
                        };

                        double xPosition = sortedData.FindIndex(data => data.Key.ToString("yyyy/MM") == month);
                        double yPosition = GraphMargin + (graphHeight * (1 - (monthMaxValue / maxValue)));

                        Canvas.SetLeft(maxValueText, GraphMargin + (xPosition * xInterval) - 10);
                        Canvas.SetTop(maxValueText, yPosition - 15);
                        GraphCanvas2.Children.Add(maxValueText);
                    }

                    // AS-IS (파란색) 최대값 텍스트 표시
                    foreach (var kvp in maxValuePerMonth_AS)
                    {
                        string month = kvp.Key;
                        double monthMaxValue = kvp.Value;
                        DateTime maxDate = maxDatePerMonth_AS[month];

                        TextBlock maxValueText = new TextBlock
                        {
                            Text = string.Format("{0:F1}", monthMaxValue),
                            FontSize = 11,
                            FontWeight = FontWeights.Bold,
                            Foreground = Brushes.Blue
                        };

                        double xPosition = sortedData.FindIndex(data => data.Key.ToString("yyyy/MM") == month);
                        double yPosition = GraphMargin + (graphHeight * (1 - (monthMaxValue / maxValue)));

                        Canvas.SetLeft(maxValueText, GraphMargin + (xPosition * xInterval) - 10);
                        Canvas.SetTop(maxValueText, yPosition + 5);  // 파란색 텍스트는 아래쪽에 표시
                        GraphCanvas2.Children.Add(maxValueText);
                    }
                }

                DrawLocationGraph(HeadquartersCanvas, "본사");
                DrawLocationGraph(OnsanCanvas, "온산");
                DrawLocationGraph(MarineCanvas, "해양");
                AddCanvasTitles();
            }

            // CAPA 리미트 라인 그리기
            if (filteredLimitData != null)
            {
                DrawLimitLines(graphWidth, graphHeight, maxValue);
            }

            if (CheckHeadquarters.IsChecked == true)
                DrawLimitLinesForLocation(HeadquartersCanvas, "본사", graphWidth, graphHeight, maxValue);
            if (CheckOnsan.IsChecked == true)
                DrawLimitLinesForLocation(OnsanCanvas, "온산", graphWidth, graphHeight, maxValue);
            if (CheckMarine.IsChecked == true)
                DrawLimitLinesForLocation(MarineCanvas, "해양", graphWidth, graphHeight, maxValue);


            DrawLegend2();
        }



        private void DrawDataLines(double graphWidth, double graphHeight, double maxValue)
        {
            if (filteredCapeData == null || filteredCapeData.Count == 0) return;

            List<KeyValuePair<DateTime, Tuple<int, int>>> sortedData = filteredCapeData.ToList();
            sortedData.Sort((x, y) => x.Key.CompareTo(y.Key));

            Polyline midScheduleLine = new Polyline
            {
                Stroke = Brushes.Blue,
                StrokeThickness = 2
            };

            Polyline adjustmentLine = new Polyline
            {
                Stroke = Brushes.Red,
                StrokeThickness = 2
            };

            double xInterval = graphWidth / (sortedData.Count - 1);

            for (int i = 0; i < sortedData.Count; i++)
            {
                double x = GraphMargin + (i * xInterval);
                double midScheduleY = GraphMargin + (graphHeight * (1 - (sortedData[i].Value.Item1 / maxValue)));
                double adjustmentY = GraphMargin + (graphHeight * (1 - (sortedData[i].Value.Item2 / maxValue)));

                midScheduleLine.Points.Add(new Point(x, midScheduleY));
                adjustmentLine.Points.Add(new Point(x, adjustmentY));
            }

            GraphCanvas2.Children.Add(midScheduleLine);
            GraphCanvas2.Children.Add(adjustmentLine);
        }

        // 리미트선
        private void DrawLimitLines(double graphWidth, double graphHeight, double maxValue)
        {
            if (filteredLimitData == null || filteredCapeData == null || filteredCapeData.Count == 0)
                return;

            // 기존 리미트 라인 제거
            List<UIElement> elementsToRemove = new List<UIElement>();
            foreach (UIElement element in GraphCanvas2.Children)
            {
                Line line = element as Line;
                if (line != null)
                {
                    FrameworkElement fe = line as FrameworkElement;
                    if (fe != null && fe.Tag != null && fe.Tag.ToString().StartsWith("Limit_"))
                    {
                        elementsToRemove.Add(element);
                    }
                }
            }
            foreach (UIElement element in elementsToRemove)
            {
                GraphCanvas2.Children.Remove(element);
            }

            List<DateTime> sortedDates = new List<DateTime>(filteredCapeData.Keys);
            sortedDates.Sort();

            // 이전 값을 추적할 딕셔너리
            Dictionary<string, double> previousValues = new Dictionary<string, double>();

            foreach (DateTime date in sortedDates)
            {
                string yearMonth = string.Format("{0}/{1:00}", date.Year, date.Month);
                if (!filteredLimitData.ContainsKey(yearMonth)) continue;

                Dictionary<string, Dictionary<string, double>> monthData = filteredLimitData[yearMonth];
                int dateIndex = sortedDates.IndexOf(date);

                // CAPA2 체크박스가 체크되어 있는 경우에만 CAPA2 라인 그리기
                if (CAPA2.IsChecked == true && monthData.ContainsKey("CAPA2"))
                {
                    double totalCapa2 = monthData["CAPA2"].Values.Sum();
                    double x = GraphMargin + (graphWidth * dateIndex / (sortedDates.Count - 1));
                    double y = GraphMargin + (graphHeight * (1 - (totalCapa2 / maxValue)));

                    // 리미트 라인 그리기 (모든 년월에 대해)
                    Line limitLine = new Line
                    {
                        X1 = x - (graphWidth / (sortedDates.Count * 2)),
                        X2 = x + (graphWidth / (sortedDates.Count * 2)),
                        Y1 = y,
                        Y2 = y,
                        Stroke = Brushes.Orange,
                        StrokeThickness = 2
                    };

                    FrameworkElement feLimitLine = limitLine as FrameworkElement;
                    if (feLimitLine != null)
                    {
                        feLimitLine.Tag = "Limit_CAPA2";
                    }

                    GraphCanvas2.Children.Add(limitLine);

                    // 값의 변화가 있거나 첫 번째 년월인 경우에만 레이블 표시
                    bool shouldShowLabel = !previousValues.ContainsKey("CAPA2") ||
                        Math.Abs(previousValues["CAPA2"] - totalCapa2) > 0.1;

                    if (shouldShowLabel)
                    {
                        // 값 레이블 표시
                        TextBlock valueLabel = new TextBlock
                        {
                            Text = totalCapa2.ToString("F1"),
                            Foreground = Brushes.Orange,
                            FontSize = 10,
                            FontWeight = FontWeights.Bold
                        };

                        Canvas.SetLeft(valueLabel, x + 10);
                        Canvas.SetTop(valueLabel, y + 10);
                        GraphCanvas2.Children.Add(valueLabel);

                        // 이전 값 업데이트
                        previousValues["CAPA2"] = totalCapa2;
                    }
                }

                // CAPA2_1 체크박스가 체크되어 있는 경우에만 CAPA2_1 라인 그리기
                if (CAPA2_1.IsChecked == true && monthData.ContainsKey("CAPA2_1"))
                {
                    double totalCapa2_1 = monthData["CAPA2_1"].Values.Sum();
                    double x = GraphMargin + (graphWidth * dateIndex / (sortedDates.Count - 1));
                    double y = GraphMargin + (graphHeight * (1 - (totalCapa2_1 / maxValue)));

                    // 리미트 라인 그리기 (모든 년월에 대해)
                    Line limitLine = new Line
                    {
                        X1 = x - (graphWidth / (sortedDates.Count * 2)),
                        X2 = x + (graphWidth / (sortedDates.Count * 2)),
                        Y1 = y,
                        Y2 = y,
                        Stroke = Brushes.DeepSkyBlue,
                        StrokeThickness = 2
                    };

                    FrameworkElement feLimitLine = limitLine as FrameworkElement;
                    if (feLimitLine != null)
                    {
                        feLimitLine.Tag = "Limit_CAPA2_1";
                    }

                    GraphCanvas2.Children.Add(limitLine);

                    // 값의 변화가 있거나 첫 번째 년월인 경우에만 레이블 표시
                    bool shouldShowLabel = !previousValues.ContainsKey("CAPA2_1") ||
                        Math.Abs(previousValues["CAPA2_1"] - totalCapa2_1) > 0.1;

                    if (shouldShowLabel)
                    {
                        // 값 레이블 표시
                        TextBlock valueLabel = new TextBlock
                        {
                            Text = totalCapa2_1.ToString("F1"),
                            Foreground = Brushes.DeepSkyBlue,
                            FontSize = 10,
                            FontWeight = FontWeights.Bold
                        };

                        Canvas.SetLeft(valueLabel, x + 10);
                        Canvas.SetTop(valueLabel, y + 10);
                        GraphCanvas2.Children.Add(valueLabel);

                        // 이전 값 업데이트
                        previousValues["CAPA2_1"] = totalCapa2_1;
                    }
                }
            }
        }

        private void DrawXAxis2(double graphWidth, double graphHeight)
        {
            Line xAxis = new Line
            {
                X1 = GraphMargin,
                Y1 = graphHeight + GraphMargin,
                X2 = graphWidth + GraphMargin,
                Y2 = graphHeight + GraphMargin,
                Stroke = Brushes.Black,
                StrokeThickness = 1
            };
            GraphCanvas2.Children.Add(xAxis);

            if (filteredCapeData == null || filteredCapeData.Count <= 1) return;

            List<KeyValuePair<DateTime, Tuple<int, int>>> sortedData = new List<KeyValuePair<DateTime, Tuple<int, int>>>(filteredCapeData);
            sortedData.Sort((x, y) => x.Key.CompareTo(y.Key));

            double xInterval = graphWidth / (sortedData.Count - 1);
            HashSet<string> displayedMonths = new HashSet<string>();

            for (int i = 0; i < sortedData.Count; i++)
            {
                string currentMonth = sortedData[i].Key.ToString("yyyy/MM");
                if (displayedMonths.Contains(currentMonth)) continue;

                displayedMonths.Add(currentMonth);

                TextBlock label = new TextBlock
                {
                    Text = currentMonth,
                    TextAlignment = TextAlignment.Center,
                    FontSize = 11
                };

                double x = GraphMargin + (i * xInterval);
                Canvas.SetLeft(label, x - 20); // 레이블 중심 정렬
                Canvas.SetTop(label, graphHeight + GraphMargin + 5);
                GraphCanvas2.Children.Add(label);
            }
        }

        private void DrawGrid2(double graphWidth, double graphHeight, double maxValue)
        {
            // Draw horizontal grid lines and Y-axis labels
            for (int i = 0; i <= maxValue; i += 50)
            {
                double y = GraphMargin + (graphHeight * (1 - (i / maxValue)));

                // Draw grid line
                var gridLine = new Line
                {
                    X1 = GraphMargin,
                    Y1 = y,
                    X2 = graphWidth + GraphMargin,
                    Y2 = y,
                    Stroke = new SolidColorBrush(Color.FromArgb(40, 0, 0, 0)),
                    StrokeThickness = 1
                };
                GraphCanvas2.Children.Add(gridLine);

                // Draw Y-axis tick mark
                var tickMark = new Line
                {
                    X1 = GraphMargin - 5,
                    Y1 = y,
                    X2 = GraphMargin,
                    Y2 = y,
                    Stroke = Brushes.Black,
                    StrokeThickness = 1
                };
                GraphCanvas2.Children.Add(tickMark);

                // Add Y-axis label
                TextBlock label = new TextBlock
                {
                    Text = i.ToString(),
                    TextAlignment = TextAlignment.Right,
                    FontSize = 11
                };

                Canvas.SetLeft(label, 5);  // Position label to the left of the Y-axis
                Canvas.SetTop(label, y - 10);  // Center label vertically with the grid line
                GraphCanvas2.Children.Add(label);
            }

            // Draw vertical Y-axis line
            var yAxis = new Line
            {
                X1 = GraphMargin,
                Y1 = GraphMargin,
                X2 = GraphMargin,
                Y2 = graphHeight + GraphMargin,
                Stroke = Brushes.Black,
                StrokeThickness = 1
            };
            GraphCanvas2.Children.Add(yAxis);
        }
        //일단 보류
        private void DrawBarChart(double graphWidth, double graphHeight, double maxValue)
        {
            double xInterval = graphWidth / (loadData.Count);
            double barWidth = Math.Min(BarWidth, xInterval / 3);

            for (int i = 0; i < loadData.Count; i++)
            {
                double x = GraphMargin + (i * xInterval) + (xInterval / 2);

                // 중일정% 막대
                double midScheduleValue = double.Parse(loadData[i].MidSchedulePercent.TrimEnd('%'));
                double midScheduleHeight = (graphHeight * midScheduleValue) / maxValue;

                Rectangle midScheduleBar = new Rectangle
                {
                    Width = barWidth,
                    Height = midScheduleHeight,
                    Fill = new SolidColorBrush(Color.FromRgb(0, 0, 180)),
                    Opacity = 0.7,
                    ToolTip = string.Format("중일정%\n날짜: {0}\n값: {1:F1}%",
                        loadData[i].Month, midScheduleValue)
                };

                midScheduleBar.MouseEnter += (s, e) => ((Rectangle)s).Opacity = 1.0;
                midScheduleBar.MouseLeave += (s, e) => ((Rectangle)s).Opacity = 0.7;

                Canvas.SetLeft(midScheduleBar, x - barWidth - 2);
                Canvas.SetTop(midScheduleBar, graphHeight + GraphMargin - midScheduleHeight);
                //GraphCanvas.Children.Add(midScheduleBar);

                // 중일정% 값 표시
                TextBlock midScheduleText = new TextBlock
                {
                    Text = string.Format("{0:F1}%", midScheduleValue),
                    TextAlignment = TextAlignment.Center,
                    FontSize = 11,
                    Foreground = Brushes.White,
                    Background = new SolidColorBrush(Color.FromRgb(0, 0, 180))
                };

                // 텍스트 위치 조정 (막대 위에 표시)
                Canvas.SetLeft(midScheduleText, x - barWidth - 2);
                Canvas.SetTop(midScheduleText, graphHeight + GraphMargin - midScheduleHeight - 20);
                //GraphCanvas.Children.Add(midScheduleText);

                // 조정% 막대
                double adjustmentValue = double.Parse(loadData[i].AdjustmentPercent.TrimEnd('%'));
                double adjustmentHeight = (graphHeight * adjustmentValue) / maxValue;

                Rectangle adjustmentBar = new Rectangle
                {
                    Width = barWidth,
                    Height = adjustmentHeight,
                    Fill = new SolidColorBrush(Color.FromRgb(180, 0, 0)),
                    Opacity = 0.7,
                    ToolTip = string.Format("조정%\n날짜: {0}\n값: {1:F1}%",
                        loadData[i].Month, adjustmentValue)
                };

                adjustmentBar.MouseEnter += (s, e) => ((Rectangle)s).Opacity = 1.0;
                adjustmentBar.MouseLeave += (s, e) => ((Rectangle)s).Opacity = 0.7;

                Canvas.SetLeft(adjustmentBar, x + 2);
                Canvas.SetTop(adjustmentBar, graphHeight + GraphMargin - adjustmentHeight);
                //GraphCanvas.Children.Add(adjustmentBar);

                // 조정% 값 표시
                TextBlock adjustmentText = new TextBlock
                {
                    Text = string.Format("{0:F1}%", adjustmentValue),
                    TextAlignment = TextAlignment.Center,
                    FontSize = 11,
                    Foreground = Brushes.White,
                    Background = new SolidColorBrush(Color.FromRgb(180, 0, 0))
                };

                // 텍스트 위치 조정 (막대 위에 표시)
                Canvas.SetLeft(adjustmentText, x + 2);
                Canvas.SetTop(adjustmentText, graphHeight + GraphMargin - adjustmentHeight - 20);
                //GraphCanvas.Children.Add(adjustmentText);

                // 텍스트 너비를 막대 너비에 맞추기
                midScheduleText.Width = barWidth;
                adjustmentText.Width = barWidth;

                // 텍스트 패딩 추가
                midScheduleText.Padding = new Thickness(2);
                adjustmentText.Padding = new Thickness(2);
            }
        }

        private void DrawLineChart(double graphWidth, double graphHeight, double maxValue)
        {
            // maxValue를 100 대신 실제 maxValue 값을 사용하도록 수정
            DrawLine(graphWidth, graphHeight, maxValue,
                delegate(MonthlyLoadData d) { return double.Parse(d.MidSchedulePercent.TrimEnd('%')); },
                new SolidColorBrush(Color.FromRgb(0, 0, 180)), "중일정%", true, 3);

            DrawLine(graphWidth, graphHeight, maxValue,
                delegate(MonthlyLoadData d) { return double.Parse(d.AdjustmentPercent.TrimEnd('%')); },
                new SolidColorBrush(Color.FromRgb(180, 0, 0)), "조정%", false, 3);
        }

        private void DrawGrid(double graphWidth, double graphHeight, double maxValue)
        {
            // 20 단위로 그리드 라인 그리기
            for (int i = 0; i <= maxValue; i += 20)
            {
                double y = GraphMargin + (graphHeight * (1 - (i / maxValue)));

                var gridLine = new Line
                {
                    X1 = GraphMargin,
                    Y1 = y,
                    X2 = graphWidth + GraphMargin,
                    Y2 = y,
                    Stroke = new SolidColorBrush(Color.FromArgb(40, 0, 0, 0)),
                    StrokeThickness = 1
                };
                //GraphCanvas.Children.Add(gridLine);
            }
        }

        private void DrawYAxis(double graphHeight, double maxValue)
        {
            // Y축 레이블에 % 추가
            for (int i = 0; i <= maxValue; i += 20)
            {
                double y = GraphMargin + (graphHeight * (1 - (i / maxValue)));

                var tick = new Line();
                tick.X1 = GraphMargin - 5;
                tick.Y1 = y;
                tick.X2 = GraphMargin;
                tick.Y2 = y;
                tick.Stroke = Brushes.Black;
                tick.StrokeThickness = 1;
                //GraphCanvas.Children.Add(tick);

                var label = new TextBlock();
                label.Text = i.ToString() + "%";
                label.TextAlignment = TextAlignment.Right;
                label.FontSize = 11;

                Canvas.SetLeft(label, 5);
                Canvas.SetTop(label, y - 10);
                //GraphCanvas.Children.Add(label);
            }
        }

        private Window maxDataWindow;
        private DataGrid maxDataGrid;
        private ComboBox modeSelector;

        /// <summary>
        /// 월별 사업장 MAX값 또는 합계 월별 사업장 SUM합산 보기를 선택할 수 있는 데이터 패널을 표시합니다.
        /// </summary>
        private void ShowMaxDataPanel()
        {
            // 데이터 로드 및 필터링 확인
            if (loadData == null || loadData.Count == 0)
            {
                MessageBox.Show("로드된 데이터가 없습니다.", "알림");
                return;
            }

            MainWindow mainWindow = Owner as MainWindow;
            if (mainWindow == null || mainWindow.ShipDataGrid.ItemsSource == null)
            {
                MessageBox.Show("데이터를 먼저 로드해주세요.", "알림");
                return;
            }

            List<ShipSchedule> items = mainWindow.ShipDataGrid.ItemsSource as List<ShipSchedule>;
            if (items == null)
            {
                MessageBox.Show("유효한 데이터가 없습니다.", "알림");
                return;
            }

            // LOAD 관련 데이터 필터링
            List<ShipSchedule> loadRows = new List<ShipSchedule>();
            foreach (var item in items)
            {
                if (item.S_KIND.Contains("LOAD 중일정개수") || item.S_KIND.Contains("LOAD 조정결과개수"))
                {
                    loadRows.Add(item);
                }
            }

            // Window 생성
            if (maxDataWindow == null || !maxDataWindow.IsLoaded)
            {
                maxDataWindow = new Window
                {
                    Title = "사업장 데이터 확인",
                    Width = 600,
                    Height = 400,
                    WindowStartupLocation = WindowStartupLocation.CenterOwner,
                    Owner = this
                };

                var panel = new StackPanel { Margin = new Thickness(10) };

                // ComboBox (모드 선택)
                modeSelector = new ComboBox
                {
                    Margin = new Thickness(0, 0, 0, 10)
                };
                modeSelector.Items.Add("월별 사업장 MAX값");
                modeSelector.Items.Add("월별 사업장 SUM합산");
                modeSelector.SelectedIndex = 0;
                modeSelector.SelectionChanged += delegate { UpdateMaxDataGrid(loadRows); };
                panel.Children.Add(modeSelector);

                // 소제목
                var subtitle = new Label
                {
                    Content = "사업장 월별 데이터",
                    FontSize = 14,
                    FontWeight = FontWeights.Bold,
                    HorizontalAlignment = HorizontalAlignment.Left
                };
                panel.Children.Add(subtitle);

                // DataGrid
                maxDataGrid = new DataGrid
                {
                    AutoGenerateColumns = false,
                    CanUserAddRows = false
                };
                panel.Children.Add(maxDataGrid);
                maxDataWindow.Content = panel;
                maxDataWindow.Closed += delegate { maxDataWindow = null; };
                maxDataWindow.Show();
            }

            UpdateMaxDataGrid(loadRows);
        }

        /// <summary>
        /// 데이터 비교 및 강조 표시
        /// </summary>
        private void HighlightComparisonResults()
        {
            foreach (var item in maxDataGrid.Items)
            {
                var row = item as Dictionary<string, string>;
                if (row == null) continue;

                // 본사 데이터 비교
                CompareAndHighlight(row, "본사 중일정 개수 (SUM)", "본사 조정 결과 개수 (SUM)");

                // 온산 데이터 비교
                CompareAndHighlight(row, "온산 중일정 개수 (SUM)", "온산 조정 결과 개수 (SUM)");

                // 해양 데이터 비교
                CompareAndHighlight(row, "해양 중일정 개수 (SUM)", "해양 조정 결과 개수 (SUM)");
            }
        }

        /// <summary>
        /// 두 데이터 값을 비교하고 DataGrid의 셀 배경색을 변경합니다.
        /// </summary>
        private void CompareAndHighlight(Dictionary<string, string> row, string key1, string key2)
        {
            if (!row.ContainsKey(key1) || !row.ContainsKey(key2)) return;

            double value1, value2;
            if (double.TryParse(row[key1], out value1) && double.TryParse(row[key2], out value2))
            {
                foreach (var column in maxDataGrid.Columns)
                {
                    var textColumn = column as DataGridTextColumn;
                    if (textColumn != null && textColumn.Header.ToString() == key2)
                    {
                        // 배경색 설정
                        textColumn.ElementStyle = new Style(typeof(TextBlock));
                        if (value2 < value1)
                        {
                            textColumn.ElementStyle.Setters.Add(new Setter(TextBlock.BackgroundProperty, Brushes.LightCoral));
                        }
                        else
                        {
                            textColumn.ElementStyle.Setters.Add(new Setter(TextBlock.BackgroundProperty, Brushes.LightGreen));
                        }
                        break;
                    }
                }
            }
        }


        /// <summary>
        /// DataGrid를 업데이트합니다. 모드에 따라 MAX 값 또는 합계 값을 계산합니다.
        /// </summary>
        private void UpdateMaxDataGrid(List<ShipSchedule> loadRows)
        {
            if (maxDataGrid == null) return;

            maxDataGrid.Columns.Clear();
            maxDataGrid.ItemsSource = null;

            // 항목 컬럼 추가
            var itemColumn = new DataGridTextColumn
            {
                Header = "항목",
                Binding = new Binding("[ItemName]"),
                IsReadOnly = true
            };
            maxDataGrid.Columns.Add(itemColumn);

            // 월별 컬럼 추가
            foreach (var monthData in loadData)
            {
                var column = new DataGridTextColumn
                {
                    Header = monthData.Month,
                    Binding = new Binding("[" + monthData.Month + "]"),
                    Width = new DataGridLength(1, DataGridLengthUnitType.Star)
                };

                // 셀 스타일 추가
                Style cellStyle = new Style(typeof(DataGridCell));
                cellStyle.Setters.Add(
                    new Setter(
                        DataGridCell.BackgroundProperty,
                        new Binding("[" + monthData.Month + "_Background]")
                    )
                );
                column.CellStyle = cellStyle;

                maxDataGrid.Columns.Add(column);
            }

            // 데이터 생성
            var rowsData = new List<Dictionary<string, object>>();
            string selectedMode = modeSelector.SelectedItem as string;

            // 월별 사업장 MAX값 로직
            if (selectedMode == "월별 사업장 MAX값")
            {
                foreach (var rowName in new[]
        {
            "LOAD 중일정개수", "LOAD 조정결과개수",
            "(본사)사업장 MAX", "(본사)사업장 조정 MAX",
            "(온산)사업장 MAX", "(온산)사업장 조정 MAX",
            "(해양)사업장 MAX", "(해양)사업장 조정 MAX"
        })
                {
                    var row = new Dictionary<string, object> { { "ItemName", rowName } };
                    ShipSchedule targetRow = null;

                    foreach (var item in loadRows)
                    {
                        // 기존 데이터 포함 조건 추가
                        if (rowName == "LOAD 중일정개수" || rowName == "LOAD 조정결과개수")
                        {
                            if (item.S_KIND == rowName)
                            {
                                targetRow = item;
                                break;
                            }
                        }
                        else if ((rowName.Contains("본사") && item.S_KIND.Contains("본사")) ||
                                 (rowName.Contains("온산") && item.S_KIND.Contains("온산")) ||
                                 (rowName.Contains("해양") && item.S_KIND.Contains("해양")))
                        {
                            if ((rowName.Contains("MAX") && item.S_KIND.Contains("중일정개수")) ||
                                (rowName.Contains("조정 MAX") && item.S_KIND.Contains("조정결과개수")))
                            {
                                targetRow = item;
                                break;
                            }
                        }
                    }

                    foreach (var monthData in loadData)
                    {
                        double maxValue = 0;
                        if (targetRow != null && targetRow.MonthlyDates != null)
                        {
                            int monthIndex = loadData.IndexOf(monthData);
                            if (monthIndex >= 0 && monthIndex < targetRow.MonthlyDates.Count)
                            {
                                var monthDates = targetRow.MonthlyDates[monthIndex] as List<DateCell>;
                                if (monthDates != null)
                                {
                                    foreach (var cell in monthDates)
                                    {
                                        double value;
                                        if (double.TryParse(cell.Day, out value))
                                        {
                                            maxValue = Math.Max(maxValue, value);
                                        }
                                    }
                                }
                            }
                        }
                        row[monthData.Month] = maxValue.ToString();
                    }
                    rowsData.Add(row);
                }
            }
            // 월별 사업장 합산 로직
            else if (selectedMode == "월별 사업장 SUM합산")
            {
                foreach (var rowName in new[]
        {
            "LOAD 중일정개수",
            "LOAD 조정결과개수",
            "LOAD 중일정개수(본사)",
            "LOAD 조정결과개수(본사)",
            "LOAD 중일정개수(온산)",
            "LOAD 조정결과개수(온산)",
            "LOAD 중일정개수(해양)",
            "LOAD 조정결과개수(해양)"
        })
                {
                    // 항목 이름 명칭 변경
                    string displayName = "";
                    switch (rowName)
                    {
                        case "LOAD 중일정개수":
                            displayName = "전체 중일정 개수 (SUM)";
                            break;
                        case "LOAD 조정결과개수":
                            displayName = "전체 조정 결과 개수 (SUM)";
                            break;
                        case "LOAD 중일정개수(본사)":
                            displayName = "본사 중일정 개수 (SUM)";
                            break;
                        case "LOAD 조정결과개수(본사)":
                            displayName = "본사 조정 결과 개수 (SUM)";
                            break;
                        case "LOAD 중일정개수(온산)":
                            displayName = "온산 중일정 개수 (SUM)";
                            break;
                        case "LOAD 조정결과개수(온산)":
                            displayName = "온산 조정 결과 개수 (SUM)";
                            break;
                        case "LOAD 중일정개수(해양)":
                            displayName = "해양 중일정 개수 (SUM)";
                            break;
                        case "LOAD 조정결과개수(해양)":
                            displayName = "해양 조정 결과 개수 (SUM)";
                            break;
                        default:
                            displayName = rowName;
                            break;
                    }

                    var row = new Dictionary<string, object> { { "ItemName", displayName } };
                    ShipSchedule targetRow = null;

                    foreach (var item in loadRows)
                    {
                        if (item.S_KIND == rowName)
                        {
                            targetRow = item;
                            break;
                        }
                    }

                    foreach (var monthData in loadData)
                    {
                        int totalSum = 0;
                        if (targetRow != null && targetRow.MonthlyDates != null)
                        {
                            int monthIndex = loadData.IndexOf(monthData);
                            if (monthIndex >= 0 && monthIndex < targetRow.MonthlyDates.Count)
                            {
                                var monthDates = targetRow.MonthlyDates[monthIndex] as List<DateCell>;
                                if (monthDates != null)
                                {
                                    foreach (var cell in monthDates)
                                    {
                                        int value;
                                        if (int.TryParse(cell.Day, out value))
                                        {
                                            totalSum += value;
                                        }
                                    }
                                }
                            }
                        }
                        row[monthData.Month] = totalSum.ToString();

                        // 조정결과개수 행에 대해 이전 행(중일정개수)과 비교하여 색상 설정
                        if (rowsData.Count > 0 && rowName.Contains("조정결과개수"))
                        {
                            var prevRow = rowsData[rowsData.Count - 1];
                            int prevValue;
                            int.TryParse(prevRow[monthData.Month] as string, out prevValue);

                            if (totalSum < prevValue)
                            {
                                row[monthData.Month + "_Background"] = new SolidColorBrush(Color.FromArgb(255, 255, 182, 193)); // 연한 빨강
                            }
                            else if (totalSum > prevValue)
                            {
                                row[monthData.Month + "_Background"] = new SolidColorBrush(Color.FromArgb(255, 144, 238, 144)); // 연한 초록
                            }
                        }
                    }
                    rowsData.Add(row);
                }
            }

            maxDataGrid.ItemsSource = rowsData;
        }

        // 메서드 시그니처 변경
        private double GetLocationMaxValueModified(ShipSchedule targetRow)
        {
            if (targetRow == null || targetRow.MonthlyDates == null)
            {
                System.Diagnostics.Debug.WriteLine("대상 행이 null이거나 MonthlyDates가 없습니다.");
                return 0;
            }

            double maxValue = 0;
            foreach (object monthDatesList in targetRow.MonthlyDates)
            {
                List<DateCell> dateCells = monthDatesList as List<DateCell>;
                if (dateCells != null)
                {
                    foreach (DateCell cell in dateCells)
                    {
                        double value;
                        if (double.TryParse(cell.Day, out value))
                        {
                            maxValue = Math.Max(maxValue, value);
                        }
                    }
                }
            }

            //System.Diagnostics.Debug.WriteLine(string.Format("계산된 최대값: {0}", maxValue));
            return maxValue;
        }

        private bool ValidateShipScheduleData(List<ShipSchedule> items)
        {
            if (items == null || items.Count == 0)
            {
                MessageBox.Show("데이터가 없습니다.");
                return false;
            }

            // LINQ 대신 foreach 사용
            bool hasLoadRows = false;
            foreach (var item in items)
            {
                if (item.S_KIND.Contains("LOAD 중일정개수") ||
                    item.S_KIND.Contains("LOAD 조정결과개수"))
                {
                    hasLoadRows = true;
                    break;
                }
            }

            if (!hasLoadRows)
            {
                MessageBox.Show("LOAD 관련 데이터가 없습니다.");
                return false;
            }

            return true;
        }





        private void DrawXAxis(double graphWidth, double graphHeight)
        {
            var xAxis = new Line
            {
                X1 = GraphMargin,
                Y1 = graphHeight + GraphMargin,
                X2 = graphWidth + GraphMargin,
                Y2 = graphHeight + GraphMargin,
                Stroke = Brushes.Black,
                StrokeThickness = 1
            };
            //GraphCanvas.Children.Add(xAxis);

            // loadData가 비어있거나 1개인 경우 처리
            if (loadData == null || loadData.Count <= 1) return;

            double xInterval;
            if (isLineChart)
            {
                // 라인 차트일 때는 기존 방식대로
                xInterval = graphWidth / (loadData.Count - 1);
            }
            else
            {
                // 막대 차트일 때는 간격 조정
                xInterval = graphWidth / loadData.Count;
            }

            for (int i = 0; i < loadData.Count; i++)
            {
                var label = new TextBlock
                {
                    Text = loadData[i].Month,
                    TextAlignment = TextAlignment.Center,
                    Width = 50  // 레이블 너비 고정
                };

                // X축 레이블 위치 조정
                double labelX;
                if (isLineChart)
                {
                    labelX = GraphMargin + (i * xInterval) - (label.Width / 2);
                }
                else
                {
                    labelX = GraphMargin + (i * xInterval) + (xInterval / 2) - (label.Width / 2);
                }

                Canvas.SetLeft(label, labelX);
                Canvas.SetTop(label, graphHeight + GraphMargin + 5);
                //GraphCanvas.Children.Add(label);
            }
        }

        private void DrawDataLine(
            List<KeyValuePair<DateTime, Tuple<int, int>>> data,
            Func<KeyValuePair<DateTime, Tuple<int, int>>, double> getValue,
            Brush color, double graphWidth, double graphHeight, double maxValue,
            string name, bool isDashed = false, double thickness = 2)
        {
            // 위 코드를 아래와 같이 변경하세요:
            Color originalColor = ((SolidColorBrush)color).Color;
            Brush semiTransparentBrush = new SolidColorBrush(Color.FromArgb(64, originalColor.R, originalColor.G, originalColor.B));

            Polyline polyline = new Polyline
            {
                Stroke = semiTransparentBrush,  // 변경된 부분
                StrokeThickness = thickness
            };

            if (isDashed)
            {
                polyline.StrokeDashArray = new DoubleCollection { 6, 3 };
            }

            PointCollection points = new PointCollection();
            double xInterval = graphWidth / (data.Count - 1);
            double lastY = double.MinValue;

            for (int i = 0; i < data.Count; i++)
            {
                double x = GraphMargin + (i * xInterval);
                double value = getValue(data[i]);
                double y = GraphMargin + (graphHeight * (1 - (value / maxValue)));
                points.Add(new Point(x, y));

                // 데이터 포인트 마커
                Ellipse marker = new Ellipse
                {
                    Width = 8,
                    Height = 8,
                    Fill = color,
                    Stroke = Brushes.White,
                    StrokeThickness = 2
                };

                Canvas.SetLeft(marker, x - 4);
                Canvas.SetTop(marker, y - 4);
                GraphCanvas2.Children.Add(marker);
            }

            polyline.Points = points;
            GraphCanvas2.Children.Add(polyline);
        }

        private void DrawLine(double graphWidth, double graphHeight, double maxValue,
            Func<MonthlyLoadData, double> getValue, Brush color, string name, bool isDashed = false, double thickness = 2)
        {
            if (loadData.Count <= 1) return;

            Polyline polyline = new Polyline();
            polyline.Stroke = color;
            polyline.StrokeThickness = thickness;

            if (isDashed)
            {
                DoubleCollection dashArray = new DoubleCollection();
                dashArray.Add(6);
                dashArray.Add(3);
                polyline.StrokeDashArray = dashArray;
            }

            PointCollection points = new PointCollection();
            double xInterval = graphWidth / (loadData.Count - 1);
            double lastY = double.MinValue;

            for (int i = 0; i < loadData.Count; i++)
            {
                double x = GraphMargin + (i * xInterval);
                double value = getValue(loadData[i]);
                double y = GraphMargin + (graphHeight * (1 - (value / maxValue)));
                points.Add(new Point(x, y));

                // 데이터 포인트 마커
                Ellipse marker = new Ellipse();
                marker.Width = 8;
                marker.Height = 8;
                marker.Fill = color;
                marker.Stroke = Brushes.White;
                marker.StrokeThickness = 2;

                // 툴팁 생성
                string tooltipValue = string.Format("{0:F1}%", value);
                string tooltipContent = string.Format("{0}\n날짜: {1}\n값: {2}",
                    name, loadData[i].Month, tooltipValue);
                marker.ToolTip = tooltipContent;

                Canvas.SetLeft(marker, x - 4);
                Canvas.SetTop(marker, y - 4);
                //GraphCanvas.Children.Add(marker);

                // 데이터 레이블
                TextBlock valueText = new TextBlock();
                valueText.Text = tooltipValue;
                valueText.Foreground = color;
                valueText.FontSize = 11;
                valueText.FontWeight = FontWeights.Bold;

                // 레이블 위치 조정
                double textY = y - 20;
                if (i > 0 && Math.Abs(y - lastY) < 25)
                {
                    textY = y + 20;
                }
                lastY = y;

                Canvas.SetLeft(valueText, x - valueText.ActualWidth / 2);
                Canvas.SetTop(valueText, textY);
                //GraphCanvas.Children.Add(valueText);
            }

            polyline.Points = points;
            //GraphCanvas.Children.Add(polyline);
        }

        private void DrawLegend()
        {
            StackPanel legendPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Background = new SolidColorBrush(Color.FromArgb(200, 255, 255, 255))
            };

            if (isLineChart)
            {
                AddLegendItemWithPattern(legendPanel, "중일정%", new SolidColorBrush(Color.FromRgb(0, 0, 180)), true);
                AddLegendItemWithPattern(legendPanel, "조정%", new SolidColorBrush(Color.FromRgb(180, 0, 0)), false);
            }
            else
            {
                AddLegendItem(legendPanel, "중일정%", new SolidColorBrush(Color.FromRgb(0, 0, 180)));
                AddLegendItem(legendPanel, "조정%", new SolidColorBrush(Color.FromRgb(180, 0, 0)));
            }

            AddLegendItem(legendPanel, "리미트%", new SolidColorBrush(Color.FromRgb(0, 100, 0)));

            Canvas.SetRight(legendPanel, GraphMargin);
            Canvas.SetTop(legendPanel, GraphMargin);
            //GraphCanvas.Children.Add(legendPanel);
        }
        private bool isDragging = false;
        private Point startPoint;

        private void DrawLegend2()
        {
            // StackPanel 생성
            StackPanel controlPanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Background = new SolidColorBrush(Color.FromArgb(200, 240, 240, 240)),
                Margin = new Thickness(10),
                Opacity = 0.8 // 흐리게 설정
            };

            // 흐림 정도 조절 텍스트 박스
            StackPanel opacityControlPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(5)
            };
            TextBlock opacityLabel = new TextBlock
            {
                Text = "☀:",
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 5, 0)
            };

            TextBox opacityTextBox = new TextBox
            {
                Width = 50,
                Text = "0.8", // 초기값
                Margin = new Thickness(0, 0, 5, 0)
            };
            Button applyOpacityButton = new Button
            {
                Content = "조정",
                Margin = new Thickness(5, 0, 0, 0)
            };

            // Apply 버튼 클릭 이벤트
            applyOpacityButton.Click += (sender, e) =>
            {
                double newOpacity;
                if (double.TryParse(opacityTextBox.Text, out newOpacity) && newOpacity >= 0 && newOpacity <= 1)
                {
                    controlPanel.Opacity = newOpacity;
                }
                else
                {
                    MessageBox.Show("Please enter a valid opacity value (0.0 to 1.0).", "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            };

            opacityControlPanel.Children.Add(opacityLabel);
            opacityControlPanel.Children.Add(opacityTextBox);
            opacityControlPanel.Children.Add(applyOpacityButton);

            // 체크박스: 중일정 AS-IS(조정 전)
            CheckBox asIsCheckBox = new CheckBox
            {
                Content = "중일정 AS-IS(조정 전)",
                IsChecked = true,
                Margin = new Thickness(5)
            };

            // 체크박스: 중일정 TO-BE(조정 후)
            CheckBox toBeCheckBox = new CheckBox
            {
                Content = "중일정 TO-BE(조정 후)",
                IsChecked = true,
                Margin = new Thickness(5)
            };

            // 범례를 포함할 StackPanel 생성
            StackPanel legendPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Background = new SolidColorBrush(Color.FromArgb(200, 255, 255, 255)),
                Margin = new Thickness(5)
            };

            // 원본 데이터 범례
            StackPanel asIsLegend = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(5) };
            asIsLegend.Children.Add(new Rectangle
            {
                Width = 20,
                Height = 3,
                Fill = Brushes.Blue,
                Margin = new Thickness(0, 7, 5, 0)
            });
            asIsLegend.Children.Add(new TextBlock
            {
                Text = "중일정 AS-IS(조정 전)",
                VerticalAlignment = VerticalAlignment.Center
            });

            // 조정된 데이터 범례
            StackPanel toBeLegend = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(5) };
            toBeLegend.Children.Add(new Rectangle
            {
                Width = 20,
                Height = 3,
                Fill = Brushes.Red,
                Margin = new Thickness(0, 7, 5, 0)
            });
            toBeLegend.Children.Add(new TextBlock
            {
                Text = "중일정 TO-BE(조정 후)",
                VerticalAlignment = VerticalAlignment.Center
            });

            // 그래프와 연동된 UIElement 관리
            List<UIElement> asIsGraphElements = new List<UIElement>();
            List<UIElement> toBeGraphElements = new List<UIElement>();

            // 그래프 데이터 수집 (GraphCanvas2, HeadquartersCanvas, OnsanCanvas, MarineCanvas)
            Canvas[] canvases = { GraphCanvas2, HeadquartersCanvas, OnsanCanvas, MarineCanvas };

            foreach (Canvas canvas in canvases)
            {
                foreach (UIElement item in canvas.Children)
                {
                    // Polyline (선) 확인
                    Polyline polyline = item as Polyline;
                    if (polyline != null)
                    {
                        if (polyline.Stroke == Brushes.Blue) // AS-IS 데이터
                        {
                            asIsGraphElements.Add(polyline);
                        }
                        else if (polyline.Stroke == Brushes.Red) // TO-BE 데이터
                        {
                            toBeGraphElements.Add(polyline);
                        }
                    }

                    // Ellipse (점) 확인
                    Ellipse ellipse = item as Ellipse;
                    if (ellipse != null)
                    {
                        if (ellipse.Fill == Brushes.Blue) // AS-IS 데이터 점
                        {
                            asIsGraphElements.Add(ellipse);
                        }
                        else if (ellipse.Fill == Brushes.Red) // TO-BE 데이터 점
                        {
                            toBeGraphElements.Add(ellipse);
                        }
                    }

                    // TextBlock (글자) 확인
                    TextBlock textBlock = item as TextBlock;
                    if (textBlock != null)
                    {
                        if (textBlock.Foreground == Brushes.Blue) // AS-IS 데이터 텍스트
                        {
                            asIsGraphElements.Add(textBlock);
                        }
                        else if (textBlock.Foreground == Brushes.Red) // TO-BE 데이터 텍스트
                        {
                            toBeGraphElements.Add(textBlock);
                        }
                    }
                }
            }

            // 이벤트 핸들러 설정
            asIsCheckBox.Checked += delegate
            {
                foreach (UIElement element in asIsGraphElements)
                {
                    element.Visibility = Visibility.Visible;
                }
                asIsLegend.Visibility = Visibility.Visible;
            };

            asIsCheckBox.Unchecked += delegate
            {
                foreach (UIElement element in asIsGraphElements)
                {
                    element.Visibility = Visibility.Collapsed;
                }
                asIsLegend.Visibility = Visibility.Collapsed;
            };

            toBeCheckBox.Checked += delegate
            {
                foreach (UIElement element in toBeGraphElements)
                {
                    element.Visibility = Visibility.Visible;
                }
                toBeLegend.Visibility = Visibility.Visible;
            };

            toBeCheckBox.Unchecked += delegate
            {
                foreach (UIElement element in toBeGraphElements)
                {
                    element.Visibility = Visibility.Collapsed;
                }
                toBeLegend.Visibility = Visibility.Collapsed;
            };

            // 초기 상태 설정
            asIsLegend.Visibility = (bool)asIsCheckBox.IsChecked ? Visibility.Visible : Visibility.Collapsed;
            toBeLegend.Visibility = (bool)toBeCheckBox.IsChecked ? Visibility.Visible : Visibility.Collapsed;

            legendPanel.Children.Add(asIsLegend);
            legendPanel.Children.Add(toBeLegend);

            // 체크박스와 범례를 StackPanel에 추가
            controlPanel.Children.Add(opacityControlPanel); // Opacity 조절 UI 추가
            controlPanel.Children.Add(asIsCheckBox);
            controlPanel.Children.Add(toBeCheckBox);
            controlPanel.Children.Add(legendPanel);

            // 캔버스에 추가
            Canvas.SetRight(controlPanel, GraphMargin);
            Canvas.SetTop(controlPanel, GraphMargin);
            GraphCanvas2.Children.Add(controlPanel);
        }



        //private void DrawLegend2()
        //{
        //    var legendPanel = new StackPanel
        //    {
        //        Orientation = Orientation.Horizontal,
        //        Background = new SolidColorBrush(Color.FromArgb(200, 255, 255, 255))
        //    };

        //    // 원본 데이터 범례
        //    var originalLegend = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(5) };
        //    originalLegend.Children.Add(new Rectangle
        //    {
        //        Width = 20,
        //        Height = 3,
        //        Fill = Brushes.Blue,
        //        Margin = new Thickness(0, 7, 5, 0)
        //    });
        //    originalLegend.Children.Add(new TextBlock
        //    {
        //        Text = "중일정 AS-IS(조정 전)",
        //        VerticalAlignment = VerticalAlignment.Center
        //    });

        //    // 조정된 데이터 범례
        //    var adjustedLegend = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(5) };
        //    adjustedLegend.Children.Add(new Rectangle
        //    {
        //        Width = 20,
        //        Height = 3,
        //        Fill = Brushes.Red,
        //        Margin = new Thickness(0, 7, 5, 0)
        //    });
        //    adjustedLegend.Children.Add(new TextBlock
        //    {
        //        Text = "중일정 TO-BE(조정 후)",
        //        VerticalAlignment = VerticalAlignment.Center
        //    });

        //    legendPanel.Children.Add(originalLegend);
        //    legendPanel.Children.Add(adjustedLegend);

        //    Canvas.SetRight(legendPanel, GraphMargin);
        //    Canvas.SetTop(legendPanel, GraphMargin);
        //    GraphCanvas2.Children.Add(legendPanel);
        //}

        private void AddLegendItemWithPattern(StackPanel panel, string text, Brush color, bool isDashed)
        {
            StackPanel itemPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(5)
            };

            Rectangle marker = new Rectangle
            {
                Width = 20,
                Height = 3,
                Fill = color,
                Margin = new Thickness(0, 7, 5, 0)
            };

            // 점선 패턴 추가
            if (isDashed)
            {
                DoubleCollection dashArray = new DoubleCollection();
                dashArray.Add(4);
                dashArray.Add(2);
                marker.StrokeDashArray = dashArray;
            }

            TextBlock textBlock = new TextBlock
            {
                Text = text,
                VerticalAlignment = VerticalAlignment.Center
            };

            itemPanel.Children.Add(marker);
            itemPanel.Children.Add(textBlock);
            panel.Children.Add(itemPanel);
        }
        private void AddLegendItem(StackPanel panel, string text, Brush color)
        {
            StackPanel itemPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(5)
            };

            Rectangle marker = new Rectangle
            {
                Width = 20,
                Height = 3,
                Fill = color,
                Margin = new Thickness(0, 7, 5, 0)
            };

            TextBlock textBlock = new TextBlock
            {
                Text = text,
                VerticalAlignment = VerticalAlignment.Center
            };

            itemPanel.Children.Add(marker);
            itemPanel.Children.Add(textBlock);
            panel.Children.Add(itemPanel);
        }

        private void UpdateDataGrid()
        {
            DataGrid.ItemsSource = null;
            DataGrid.ItemsSource = loadData;
        }


        private void ExportButton_Click(object sender, RoutedEventArgs e)
        {
            if (loadData == null || !loadData.Any())
            {
                MessageBox.Show("내보낼 데이터가 없습니다.", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            SaveFileDialog dialog = new SaveFileDialog
            {
                Filter = "Excel Files (*.xlsx)|*.xlsx|All files (*.*)|*.*",
                FilterIndex = 1,
                DefaultExt = "xlsx"
            };

            if (dialog.ShowDialog() == true)
            {
                try
                {
                    ExportToExcel(dialog.FileName);
                    MessageBox.Show("Excel 파일이 성공적으로 저장되었습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(string.Format("Excel 저장 중 오류가 발생했습니다: {0}", ex.Message),
                        "오류", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        // 생산 데이터를 저장할 Dictionary 추가
        private Dictionary<string, Dictionary<string, double>> productionData;

        private void Searchload_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Excel Files (*.xlsx;*.xls)|*.xlsx;*.xls|All files (*.*)|*.*";
            dialog.FilterIndex = 1;

            if (dialog.ShowDialog() == true)
            {
                Excel.Application excel = null;
                Excel.Workbook workbook = null;
                Excel._Worksheet worksheet = null;

                try
                {
                    excel = new Excel.Application();
                    workbook = excel.Workbooks.Open(dialog.FileName);
                    worksheet = workbook.Sheets[1];

                    // 마스터 데이터와 생산 데이터를 모두 저장하기 위한 구조 초기화
                    masterCapaData = new List<CapaData>();
                    productionData = new Dictionary<string, Dictionary<string, double>>();

                    Excel.Range usedRange = worksheet.UsedRange;
                    object[,] values = usedRange.Value2;

                    // 헤더 인덱스 찾기
                    Dictionary<string, int> headerIndexes = new Dictionary<string, int>();
                    for (int i = 1; i <= usedRange.Columns.Count; i++)
                    {
                        string header = Convert.ToString(values[1, i]);
                        if (!string.IsNullOrEmpty(header))
                        {
                            headerIndexes[header] = i;
                        }
                    }

                    // 데이터 처리
                    for (int row = 2; row <= usedRange.Rows.Count; row++)
                    {
                        string yyyy = Convert.ToString(values[row, headerIndexes["YYYY"]]);
                        string mm = Convert.ToString(values[row, headerIndexes["MM"]]).PadLeft(2, '0');
                        string yearMonth = yyyy + "/" + mm;
                        string mfgDesc = Convert.ToString(values[row, headerIndexes["MFG_DESC"]]);

                        // masterCapaData를 위한 객체 생성
                        CapaData capaData = new CapaData();
                        capaData.Yyyy = yyyy;
                        capaData.Mm = mm;
                        capaData.MfgDesc = mfgDesc;
                        capaData.PeEquip = Convert.ToString(values[row, headerIndexes["PE_EQUIP"]]);
                        capaData.PeMocNm = Convert.ToString(values[row, headerIndexes["PE_MOC_NM"]]);
                        capaData.Capa1 = Convert.ToDouble(values[row, headerIndexes["CAPA1"]]);
                        capaData.Capa2 = Convert.ToDouble(values[row, headerIndexes["CAPA2"]]);
                        capaData.Capa1_1 = Convert.ToDouble(values[row, headerIndexes["CAPA1_1"]]);
                        capaData.Capa2_1 = Convert.ToDouble(values[row, headerIndexes["CAPA2_1"]]);
                        masterCapaData.Add(capaData);

                        // productionData를 위한 처리
                        if (!productionData.ContainsKey(yearMonth))
                        {
                            productionData[yearMonth] = new Dictionary<string, double>();
                            productionData[yearMonth]["CAPA1"] = 0;
                            productionData[yearMonth]["CAPA1_1"] = 0;
                            productionData[yearMonth]["Headquarters"] = 0;
                            productionData[yearMonth]["Yeyang"] = 0;
                            productionData[yearMonth]["Unsan"] = 0;
                        }

                        // CAPA1과 CAPA1_1 값을 합산
                        productionData[yearMonth]["CAPA1"] += capaData.Capa1;
                        productionData[yearMonth]["CAPA1_1"] += capaData.Capa1_1;

                        // MFG_DESC 별 CAPA2 데이터 처리
                        if (mfgDesc == "본사")
                        {
                            productionData[yearMonth]["Headquarters"] += capaData.Capa2;
                        }
                        else if (mfgDesc == "해양")
                        {
                            productionData[yearMonth]["Yeyang"] += capaData.Capa2;
                        }
                        else if (mfgDesc == "온산")
                        {
                            productionData[yearMonth]["Unsan"] += capaData.Capa2;
                        }
                    }

                    // 필터링 수행
                    FilterCapaData();

                    MessageBox.Show("데이터가 성공적으로 로드되었습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("데이터 로드 중 오류 발생: " + ex.Message, "오류", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    // 리소스 해제
                    if (worksheet != null) Marshal.ReleaseComObject(worksheet);
                    if (workbook != null)
                    {
                        workbook.Close(true);
                        Marshal.ReleaseComObject(workbook);
                    }
                    if (excel != null)
                    {
                        excel.Quit();
                        Marshal.ReleaseComObject(excel);
                    }
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
        }
        private void DrawLimitLine(double graphWidth, double graphHeight, double maxValue)
        {
            // 기존 CapacityIndex_pch 기반 리미트 라인
            if (loadData != null && loadData.Count > 0)
            {
                for (int i = 0; i < loadData.Count; i++)
                {
                    MonthlyLoadData data = loadData[i];
                    double pchValue = 0;
                    if (data.CapacityIndex_pch != null && double.TryParse(data.CapacityIndex_pch.TrimEnd('%'), out pchValue))
                    {
                        double y = GraphMargin + (graphHeight * (1 - (pchValue / maxValue)));
                        double xStart = GraphMargin + (i * (graphWidth / loadData.Count));
                        double xEnd = GraphMargin + ((i + 1) * (graphWidth / loadData.Count));

                        Line limitLine = new Line();
                        limitLine.X1 = xStart;
                        limitLine.Y1 = y;
                        limitLine.X2 = xEnd;
                        limitLine.Y2 = y;
                        limitLine.Stroke = new SolidColorBrush(Color.FromRgb(0, 100, 0));
                        limitLine.StrokeThickness = 2.5;
                        //GraphCanvas.Children.Add(limitLine);

                        TextBlock limitText = new TextBlock();
                        limitText.Text = string.Format("{0:F1}%", pchValue);
                        limitText.Foreground = Brushes.DarkGreen;
                        limitText.FontSize = 11;
                        limitText.FontWeight = FontWeights.Bold;

                        Canvas.SetLeft(limitText, xStart + 5);
                        Canvas.SetTop(limitText, y - 15);
                        //GraphCanvas.Children.Add(limitText);
                    }
                }
            }

            // 새로운 CAPA 기반 리미트 라인들 (GraphCanvas2에만 적용)
            if (limitData != null && filteredCapeData != null && filteredCapeData.Count > 0)
            {
                List<DateTime> sortedDates = new List<DateTime>(filteredCapeData.Keys);
                sortedDates.Sort();

                foreach (DateTime date in sortedDates)
                {
                    string yearMonth = string.Format("{0}/{1:00}", date.Year, date.Month);
                    if (!limitData.ContainsKey(yearMonth)) continue;

                    Dictionary<string, Dictionary<string, double>> monthData = limitData[yearMonth];
                    int dateIndex = sortedDates.IndexOf(date);

                    // CAPA 체크박스 상태에 따라 리미트 라인 그리기
                    //if (CAPA1.IsChecked == true)
                    //DrawCapaLimitLine(monthData, "CAPA1", Brushes.Green, dateIndex, sortedDates.Count, graphWidth, graphHeight);
                    if (CAPA2.IsChecked == true)
                        DrawCapaLimitLine(monthData, "CAPA2", Brushes.Orange, dateIndex, sortedDates.Count, graphWidth, graphHeight);
                    //if (CAPA1_1.IsChecked == true)
                    //DrawCapaLimitLine(monthData, "CAPA1_1", Brushes.Purple, dateIndex, sortedDates.Count, graphWidth, graphHeight);
                    if (CAPA2_1.IsChecked == true)
                        DrawCapaLimitLine(monthData, "CAPA2_1", Brushes.DeepSkyBlue, dateIndex, sortedDates.Count, graphWidth, graphHeight);
                }
            }
        }

        private Dictionary<string, double> previousValues = new Dictionary<string, double>();

        private void DrawCapaLimitLine(Dictionary<string, Dictionary<string, double>> monthData, string capaType, Brush color, int dateIndex, int totalDates, double graphWidth, double graphHeight)
        {
            if (!monthData.ContainsKey(capaType)) return;

            double totalValue = monthData[capaType].Values.Sum();
            if (totalValue <= 0) return;

            // maxValue를 50으로 고정
            double maxValue = 50;

            // 리미트 선의 위치를 Y축에 맞게 조정
            double y = GraphMargin + (graphHeight * (1 - (totalValue / maxValue)));

            double x = GraphMargin + (graphWidth * dateIndex / (totalDates - 1));

            Line limitLine = new Line
            {
                X1 = x - (graphWidth / (totalDates * 2)),
                X2 = x + (graphWidth / (totalDates * 2)),
                Y1 = y,
                Y2 = y,
                Stroke = color,
                StrokeThickness = 2,
                Tag = "Limit_" + capaType
            };

            GraphCanvas2.Children.Add(limitLine);

            // 이전 값과 비교하여 변화가 있는 경우에만 레이블 표시
            bool shouldShowLabel = false;
            if (!previousValues.ContainsKey(capaType))
            {
                shouldShowLabel = true; // 첫 번째 값은 항상 표시
                previousValues[capaType] = totalValue;
            }
            else if (Math.Abs(previousValues[capaType] - totalValue) > 0.1) // 0.1은 허용 오차
            {
                shouldShowLabel = true;
                previousValues[capaType] = totalValue;
            }

            if (shouldShowLabel)
            {
                TextBlock valueLabel = new TextBlock
                {
                    Text = totalValue.ToString("F1"),
                    Foreground = color,
                    FontSize = 10,
                    FontWeight = FontWeights.Bold
                };

                Canvas.SetLeft(valueLabel, x + 5);
                Canvas.SetTop(valueLabel, y - 15); // 레이블을 선 위에 표시
                GraphCanvas2.Children.Add(valueLabel);
            }
        }


        private void ExportToExcel(string filePath)
        {
            Excel.Application excel = null;
            Excel.Workbook workbook = null;
            Excel._Worksheet worksheet = null;
            Excel.Range range = null;
            Excel.ChartObjects chartObjects = null;
            Excel.ChartObject chartObject = null;
            Excel.Chart chart = null;

            try
            {
                excel = new Excel.Application();
                excel.Visible = false;
                workbook = excel.Workbooks.Add(true);

                worksheet = (Excel._Worksheet)workbook.Sheets[1];
                worksheet.Name = "부하율 현황";

                chartObjects = (Excel.ChartObjects)worksheet.ChartObjects();
                chartObject = chartObjects.Add(10, 30, 620, 400); // 차트 크기 조정
                chart = chartObject.Chart;

                int dataStartRow = 30;
                // 헤더 추가
                worksheet.Cells[dataStartRow, 1] = "월";
                worksheet.Cells[dataStartRow, 2] = "본사";
                worksheet.Cells[dataStartRow, 3] = "예양";
                worksheet.Cells[dataStartRow, 4] = "운산";
                worksheet.Cells[dataStartRow, 5] = "전체";
                worksheet.Cells[dataStartRow, 6] = "중일정";
                worksheet.Cells[dataStartRow, 7] = "조정";
                worksheet.Cells[dataStartRow, 8] = "중일정차이";
                worksheet.Cells[dataStartRow, 9] = "중일정%";
                worksheet.Cells[dataStartRow, 10] = "조정차이";
                worksheet.Cells[dataStartRow, 11] = "조정%";
                worksheet.Cells[dataStartRow, 12] = "리미트";

                // 헤더 스타일 설정
                Excel.Range headerRange = worksheet.Range[worksheet.Cells[dataStartRow, 1], worksheet.Cells[dataStartRow, 12]];
                headerRange.Font.Bold = true;
                headerRange.Interior.Color = Excel.XlRgbColor.rgbLightGray;
                headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;

                double limitValue;
                //bool hasLimitValue = double.TryParse(LimitLineTextBox.Text, out limitValue);

                // 데이터 추가
                for (int i = 0; i < loadData.Count; i++)
                {
                    worksheet.Cells[i + dataStartRow + 1, 1] = loadData[i].Month;
                    worksheet.Cells[i + dataStartRow + 1, 2] = loadData[i].Headquarters;
                    worksheet.Cells[i + dataStartRow + 1, 3] = loadData[i].Yeyang;
                    worksheet.Cells[i + dataStartRow + 1, 4] = loadData[i].Unsan;
                    worksheet.Cells[i + dataStartRow + 1, 5] = loadData[i].Total;
                    worksheet.Cells[i + dataStartRow + 1, 6] = loadData[i].MidSchedule;
                    worksheet.Cells[i + dataStartRow + 1, 7] = loadData[i].Adjustment;
                    worksheet.Cells[i + dataStartRow + 1, 8] = loadData[i].MidScheduleDiff;
                    worksheet.Cells[i + dataStartRow + 1, 9] = double.Parse(loadData[i].MidSchedulePercent.TrimEnd('%'));
                    worksheet.Cells[i + dataStartRow + 1, 10] = loadData[i].AdjustmentDiff;
                    worksheet.Cells[i + dataStartRow + 1, 11] = double.Parse(loadData[i].AdjustmentPercent.TrimEnd('%'));

                    //if (hasLimitValue)
                    {
                        //worksheet.Cells[i + dataStartRow + 1, 12] = limitValue;
                    }
                }

                // 데이터 범위 테두리 및 자동 맞춤
                Excel.Range dataRange = worksheet.Range[
                    worksheet.Cells[dataStartRow, 1],
                    worksheet.Cells[dataStartRow + loadData.Count, 12]
                ];
                dataRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                dataRange.Columns.AutoFit();

                // 차트 유형 선택
                chart.ChartType = isLineChart ? Excel.XlChartType.xlLineMarkers : Excel.XlChartType.xlColumnClustered;

                // 중일정% 시리즈 추가
                chart.SeriesCollection().NewSeries();
                Excel.Series series1 = (Excel.Series)chart.SeriesCollection(1);
                series1.Name = "중일정%";
                series1.Values = worksheet.Range[
                    worksheet.Cells[dataStartRow + 1, 9],
                    worksheet.Cells[dataStartRow + loadData.Count, 9]
                ];
                series1.XValues = worksheet.Range[
                    worksheet.Cells[dataStartRow + 1, 1],
                    worksheet.Cells[dataStartRow + loadData.Count, 1]
                ];
                series1.Border.Weight = 4;
                series1.Border.LineStyle = Excel.XlLineStyle.xlDash;
                series1.Border.ColorIndex = 5; // 파란색
                series1.MarkerSize = 8;
                series1.HasDataLabels = true; // 데이터 레이블 활성화
                series1.DataLabels().Font.Size = 10;

                // 조정% 시리즈 추가
                chart.SeriesCollection().NewSeries();
                Excel.Series series2 = (Excel.Series)chart.SeriesCollection(2);
                series2.Name = "조정%";
                series2.Values = worksheet.Range[
                    worksheet.Cells[dataStartRow + 1, 11],
                    worksheet.Cells[dataStartRow + loadData.Count, 11]
                ];
                series2.XValues = worksheet.Range[
                    worksheet.Cells[dataStartRow + 1, 1],
                    worksheet.Cells[dataStartRow + loadData.Count, 1]
                ];
                series2.Border.Weight = 4;
                series2.Border.LineStyle = Excel.XlLineStyle.xlContinuous;
                series2.Border.ColorIndex = 3; // 빨간색
                series2.MarkerSize = 8;
                series2.HasDataLabels = true; // 데이터 레이블 활성화
                series2.DataLabels().Font.Size = 10;

                // 리미트선 시리즈 추가
                //if (hasLimitValue)
                //{
                //    chart.SeriesCollection().NewSeries();
                //    Excel.Series limitSeries = (Excel.Series)chart.SeriesCollection(3);
                //    limitSeries.Name = "리미트선";
                //    limitSeries.Values = worksheet.Range[
                //        worksheet.Cells[dataStartRow + 1, 12],
                //        worksheet.Cells[dataStartRow + loadData.Count, 12]
                //    ];
                //    limitSeries.XValues = worksheet.Range[
                //        worksheet.Cells[dataStartRow + 1, 1],
                //        worksheet.Cells[dataStartRow + loadData.Count, 1]
                //    ];
                //    limitSeries.ChartType = Excel.XlChartType.xlLine; // 리미트선을 선형으로 설정
                //    limitSeries.Border.Weight = 3; // 굵은 선
                //    limitSeries.Border.LineStyle = Excel.XlLineStyle.xlContinuous;
                //    limitSeries.Border.ColorIndex = 10; // 초록색
                //    limitSeries.MarkerStyle = Excel.XlMarkerStyle.xlMarkerStyleNone;
                //}

                // 차트 제목 및 축 설정
                chart.HasTitle = true;
                chart.ChartTitle.Text = string.Format("{0}~{1} 부하율 현황", loadData[0].Month, loadData[loadData.Count - 1].Month);
                chart.ChartTitle.Font.Size = 14;
                chart.ChartTitle.Font.Bold = true;

                ((Excel.Axis)chart.Axes(Excel.XlAxisType.xlCategory)).HasTitle = true;
                ((Excel.Axis)chart.Axes(Excel.XlAxisType.xlCategory)).AxisTitle.Text = "월";
                ((Excel.Axis)chart.Axes(Excel.XlAxisType.xlValue)).HasTitle = true;
                ((Excel.Axis)chart.Axes(Excel.XlAxisType.xlValue)).AxisTitle.Text = "부하율 (%)";

                // Y축 범위 설정
                ((Excel.Axis)chart.Axes(Excel.XlAxisType.xlValue)).MinimumScale = 0;
                ((Excel.Axis)chart.Axes(Excel.XlAxisType.xlValue)).MaximumScale = 120;

                // 범례 설정
                chart.HasLegend = true;
                chart.Legend.Position = Excel.XlLegendPosition.xlLegendPositionTop;
                chart.Legend.Font.Size = 10;

                // 차트 저장
                workbook.SaveAs(filePath);
            }
            finally
            {
                // 리소스 해제
                if (chart != null) Marshal.ReleaseComObject(chart);
                if (chartObject != null) Marshal.ReleaseComObject(chartObject);
                if (chartObjects != null) Marshal.ReleaseComObject(chartObjects);
                if (range != null) Marshal.ReleaseComObject(range);
                if (worksheet != null) Marshal.ReleaseComObject(worksheet);
                if (workbook != null)
                {
                    workbook.Close(true);
                    Marshal.ReleaseComObject(workbook);
                }
                if (excel != null)
                {
                    excel.Quit();
                    Marshal.ReleaseComObject(excel);
                }
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        private void SearchDataButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateDateRange()) return;
            LoadData();
            //DrawGraph();
            DrawGraph2();
            UpdateDataGrid();
        }

        private void SearchButton1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // 날짜 범위가 유효한지 확인
                if (!ValidateDateRange())
                    return;

                // 데이터를 새로 로드
                LoadData();

                // capeData를 필터링
                FilterCapeDataByDate();

                // GraphCanvas2 다시 그리기
                DrawGraph2();

                MessageBox.Show("데이터가 새로 로드되고 GraphCanvas2가 업데이트되었습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("데이터를 로드하고 GraphCanvas2를 업데이트하는 중 오류가 발생했습니다: " + ex.Message,
                    "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        //private void SQLOpenMenuItem_Click(object sender, RoutedEventArgs e)
        //{
        //    MessageBox.Show("미포 SQL은 마지막에 예정 준비중입니다..");
        //}
        private void SQLOpenMenuItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // 입력 창 생성
                Window dialog = new Window();
                dialog.Title = "년도 범위 입력";
                dialog.Width = 300;
                dialog.Height = 180;
                dialog.WindowStartupLocation = WindowStartupLocation.CenterOwner;
                dialog.Owner = this;
                dialog.ResizeMode = ResizeMode.NoResize;

                // 메인 패널
                StackPanel panel = new StackPanel();
                panel.Margin = new Thickness(10);

                // 입력 그리드 생성
                Grid inputGrid = new Grid();
                inputGrid.Margin = new Thickness(0, 10, 0, 0);

                // 행과 열 정의
                ColumnDefinition col1 = new ColumnDefinition();
                col1.Width = new GridLength(80);
                ColumnDefinition col2 = new ColumnDefinition();
                inputGrid.ColumnDefinitions.Add(col1);
                inputGrid.ColumnDefinitions.Add(col2);

                RowDefinition row1 = new RowDefinition();
                RowDefinition row2 = new RowDefinition();
                inputGrid.RowDefinitions.Add(row1);
                inputGrid.RowDefinitions.Add(row2);

                // 라벨과 텍스트박스 생성
                TextBlock startLabel = new TextBlock();
                startLabel.Text = "시작년도:";
                startLabel.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetRow(startLabel, 0);
                Grid.SetColumn(startLabel, 0);

                TextBox startYearBox = new TextBox();
                startYearBox.Width = 100;
                startYearBox.HorizontalAlignment = HorizontalAlignment.Left;
                startYearBox.Margin = new Thickness(5);
                Grid.SetRow(startYearBox, 0);
                Grid.SetColumn(startYearBox, 1);

                TextBlock endLabel = new TextBlock();
                endLabel.Text = "종료년도:";
                endLabel.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetRow(endLabel, 1);
                Grid.SetColumn(endLabel, 0);

                TextBox endYearBox = new TextBox();
                endYearBox.Width = 100;
                endYearBox.HorizontalAlignment = HorizontalAlignment.Left;
                endYearBox.Margin = new Thickness(5);
                Grid.SetRow(endYearBox, 1);
                Grid.SetColumn(endYearBox, 1);

                // 컨트롤 추가
                inputGrid.Children.Add(startLabel);
                inputGrid.Children.Add(startYearBox);
                inputGrid.Children.Add(endLabel);
                inputGrid.Children.Add(endYearBox);

                // 버튼 패널
                StackPanel buttonPanel = new StackPanel();
                buttonPanel.Orientation = Orientation.Horizontal;
                buttonPanel.HorizontalAlignment = HorizontalAlignment.Center;
                buttonPanel.Margin = new Thickness(0, 20, 0, 0);

                Button okButton = new Button();
                okButton.Content = "확인";
                okButton.Width = 70;
                okButton.Height = 25;
                okButton.Margin = new Thickness(5);
                okButton.IsDefault = true;

                Button cancelButton = new Button();
                cancelButton.Content = "취소";
                cancelButton.Width = 70;
                cancelButton.Height = 25;
                cancelButton.Margin = new Thickness(5);
                cancelButton.IsCancel = true;

                buttonPanel.Children.Add(okButton);
                buttonPanel.Children.Add(cancelButton);

                panel.Children.Add(inputGrid);
                panel.Children.Add(buttonPanel);

                dialog.Content = panel;

                bool dialogResult = false;
                okButton.Click += delegate
                {
                    int startYear, endYear;
                    if (int.TryParse(startYearBox.Text, out startYear) &&
                        int.TryParse(endYearBox.Text, out endYear))
                    {
                        if (startYear > endYear)
                        {
                            MessageBox.Show("시작년도는 종료년도보다 작아야 합니다.",
                                "오류", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }
                        dialogResult = true;
                        dialog.Close();
                    }
                    else
                    {
                        MessageBox.Show("올바른 년도를 입력해주세요.",
                            "오류", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                };

                cancelButton.Click += delegate
                {
                    dialog.Close();
                };

                dialog.ShowDialog();

                if (dialogResult)
                {
                    Cursor = Cursors.Wait;
                    try
                    {
                        DataAccessService dataService = new DataAccessService();
                        DataTable craneData = dataService.GetCranePeData(startYearBox.Text, endYearBox.Text);

                        if (craneData != null && craneData.Rows.Count > 0)
                        {
                            ProcessSqlData(craneData);

                            // 년월 텍스트박스 업데이트 - YYYYMM 형식으로 변경
                            StartYearMonthTextBox.Text = startYearBox.Text + "01";  // 시작 연도의 1월
                            EndYearMonthTextBox.Text = startYearBox.Text + "12";   // 시작 연도의 12월

                            // UI 업데이트
                            LoadData();
                            FilterCapaData();
                            FilterCapeDataByDate();
                            DrawGraph2();
                            TransposeDataGrid();
                            UpdateDataGrid();

                            MessageBox.Show(string.Format(
                                "데이터가 성공적으로 로드되었습니다. (총 {0}건)",
                                craneData.Rows.Count),
                                "완료", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        else
                        {
                            MessageBox.Show("해당 기간에 데이터가 없습니다.",
                                "알림", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(string.Format(
                            "데이터 로드 중 오류가 발생했습니다: {0}", ex.Message),
                            "오류", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    finally
                    {
                        Cursor = Cursors.Arrow;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format(
                    "작업 중 오류가 발생했습니다: {0}", ex.Message),
                    "오류", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public class DataAccessService
        {
            private readonly Database _database;

            public DataAccessService()
            {
                // DatabaseFactory에서 설정 파일을 읽어 DevShipDbOracle 연결 설정을 가져옵니다.
                //_database = DatabaseFactory.CreateDatabase("DevShipDbOracle");//개발
                _database = DatabaseFactory.CreateDatabase("DevShipDbOracleOp");//운영
            }

            public DataTable GetCranePeData(string startYear, string endYear)
            {
                StringBuilder query = new StringBuilder();
                query.Append(@"
        SELECT
            A1.YYYY,
            A1.MM,
            A1.MFG_IND,
            A4.MFG_DESC,
            A1.PE_EQUIP,
            A2.PE_TOOLS_NM,
            A1.PE_MOC,
            A3.PE_MOC_NM,
            A1.CAPA1,
            A1.CAPA2
        FROM
            PTB_PEEQUIP_CAPA_NEW A1,
            PTB_PEEQUIP_TOOL A2,
            PTB_PEEQUIP_PE_MOC A3,
            PTB_STD_MFGIND A4
        WHERE
            (A1.YYYY BETWEEN :startYear AND :endYear)
            AND A1.PE_EQUIP = A2.PE_TOOLS
            AND A1.PE_MOC = A3.PE_MOC
            AND A1.MFG_IND = A4.MFG_IND
            AND A4.MFG_DESC IN ('본사', '온산', '해양') -- 본사, 온산, 해양만 선택
            AND A1.PE_EQUIP = 'C' -- PE_EQUIP는 C만 선택
        ORDER BY
            A1.YYYY, A1.MM");

                using (DbCommand dbCommand = _database.GetSqlStringCommand(query.ToString()))
                {
                    // 파라미터 추가
                    _database.AddInParameter(dbCommand, "startYear", DbType.String, startYear);
                    _database.AddInParameter(dbCommand, "endYear", DbType.String, endYear);

                    // SQL 실행 및 결과 반환
                    DataSet dataSet = _database.ExecuteDataSet(dbCommand);
                    return dataSet.Tables[0];
                }
            }
        }

        private void ProcessSqlData(DataTable craneData)
        {
            try
            {
                // 마스터 데이터와 생산 데이터를 모두 저장하기 위한 구조 초기화
                masterCapaData = new List<CapaData>();
                productionData = new Dictionary<string, Dictionary<string, double>>();

                foreach (DataRow row in craneData.Rows)
                {
                    string yyyy = row["YYYY"].ToString();
                    string mm = row["MM"].ToString().PadLeft(2, '0');
                    string yearMonth = yyyy + "/" + mm;
                    string mfgDesc = row["MFG_DESC"].ToString();

                    // masterCapaData를 위한 객체 생성
                    CapaData capaData = new CapaData();
                    capaData.Yyyy = yyyy;
                    capaData.Mm = mm;
                    capaData.MfgDesc = mfgDesc;
                    capaData.PeEquip = row["PE_EQUIP"].ToString();
                    capaData.PeMocNm = row["PE_MOC_NM"].ToString();
                    capaData.Capa1 = Convert.ToDouble(row["CAPA1"]);
                    capaData.Capa2 = Convert.ToDouble(row["CAPA2"]);
                    // CAPA1_1과 CAPA2_1 값 처리 - 데이터가 있으면 해당 값 사용, 없으면 0으로 처리
                    capaData.Capa1_1 = row.Table.Columns.Contains("CAPA1_1") && row["CAPA1_1"] != DBNull.Value
                        ? Convert.ToDouble(row["CAPA1_1"])
                        : 0;
                    capaData.Capa2_1 = row.Table.Columns.Contains("CAPA2_1") && row["CAPA2_1"] != DBNull.Value
                        ? Convert.ToDouble(row["CAPA2_1"])
                        : 0;
                    masterCapaData.Add(capaData);

                    // productionData를 위한 처리
                    if (!productionData.ContainsKey(yearMonth))
                    {
                        productionData[yearMonth] = new Dictionary<string, double>();
                        productionData[yearMonth]["CAPA1"] = 0;
                        productionData[yearMonth]["CAPA1_1"] = 0;
                        productionData[yearMonth]["Headquarters"] = 0;
                        productionData[yearMonth]["Yeyang"] = 0;
                        productionData[yearMonth]["Unsan"] = 0;
                    }

                    // CAPA1과 CAPA1_1 값을 합산
                    productionData[yearMonth]["CAPA1"] += capaData.Capa1;
                    productionData[yearMonth]["CAPA1_1"] += capaData.Capa1_1;

                    // MFG_DESC 별 CAPA2 데이터 처리
                    switch (mfgDesc)
                    {
                        case "본사":
                            productionData[yearMonth]["Headquarters"] += capaData.Capa2;
                            break;
                        case "해양":
                            productionData[yearMonth]["Yeyang"] += capaData.Capa2;
                            break;
                        case "온산":
                            productionData[yearMonth]["Unsan"] += capaData.Capa2;
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("데이터 처리 중 오류 발생: " + ex.Message);
            }
        }

        private void Production_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("생산자료는 리미트선은 준비중입니다..");
        }
        private void AboutMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("버전V1.0 미포조선 CRANE PE 부하률 시뮬레이션입니다.");
        }
        private void ExitMenuItem_Click(object sender, RoutedEventArgs e)
        {
            // 종료 여부를 묻는 메시지 표시
            MessageBoxResult result = MessageBox.Show("프로그램을 종료하시겠습니까?", "종료 확인", MessageBoxButton.YesNo, MessageBoxImage.Question);

            // 사용자가 "Yes"를 선택한 경우에만 종료
            if (result == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }

        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            startDate = originalStartDate;
            endDate = originalEndDate;

            StartDatePicker.Text = startDate.Year.ToString() +
                startDate.Month.ToString().PadLeft(2, '0');
            EndDatePicker.Text = endDate.Year.ToString() +
                endDate.Month.ToString().PadLeft(2, '0');

            isZoomed = false;

            SearchButton_Click(null, null);
        }

        private void MFDButton_Click(object sender, RoutedEventArgs e)
        {
            ShowMaxDataPanel();
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // 리소스 정리
            if (loadData != null)
            {
                loadData.Clear();
                loadData = null;
            }
            GC.Collect();
        }

        private void YYYYComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}