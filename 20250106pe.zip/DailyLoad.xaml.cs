﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

//using System;
//using System.Collections.Generic;
//using System.Windows;
//using System.Windows.Controls;
//using System.Windows.Media;
//using System.Windows.Shapes;
//using Microsoft.Win32;
//using Excel = Microsoft.Office.Interop.Excel;
//using System.Runtime.InteropServices;
//using System.Drawing;
//using System.Windows.Media;
//using System.Windows.Shapes;
namespace ShipDataViewer
{
    public partial class DailyLoadWindow : Window
    {

        private string selectedMonth;
        public string CurrentMonth
        {
            get { return selectedMonth; }
        }

        private string currentLocation;
        public string Location
        {
            get { return currentLocation; }
        }

        private List<DailyData> dailyDataList;
        //private string selectedMonth;
        private const int GRAPH_MARGIN = 40;
        public class DailyData
        {
            public string Date { get; set; }
            public int OriginalCount { get; set; }
            public int AdjustedCount { get; set; }
            public double LimitValue { get; set; } // 리미트선 값 추가
            public int Difference
            {
                get { return OriginalCount - AdjustedCount; }
            }
            public string AdjustmentRate
            {
                get
                {
                    if (OriginalCount == 0) return "0%";
                    return ((double)AdjustedCount / OriginalCount * 100).ToString("F1") + "%";
                }
            }
        }
        private Dictionary<string, string> holidays = new Dictionary<string, string>
        {
            // 2024년 공휴일
            {"2024-01-01", "신정"},
            {"2024-01-02", "신정연휴"},
            {"2024-02-09", "설날연휴"},
            {"2024-02-10", "설날"},
            {"2024-02-11", "설날연휴"},
            {"2024-02-12", "설날연휴"},
            {"2024-02-13", "휴일중복"},
            {"2024-03-01", "삼일절"},
            {"2024-04-10", "국회의원 선거"},
            {"2024-05-01", "근로자의날"},
            {"2024-05-05", "어린이날"},
            {"2024-05-06", "대체공휴일"},
            {"2024-05-15", "석가탄신일"},
            {"2024-06-06", "현충일"},
            {"2024-07-15", "노조창립일"},
            {"2024-07-29", "하기휴가"},
            {"2024-07-30", "하기휴가"},
            {"2024-07-31", "하기휴가"},
            {"2024-08-01", "하기휴가"},
            {"2024-08-02", "하기휴가"},
            {"2024-08-05", "하기휴가"},
            {"2024-08-06", "하기휴가"},
            {"2024-08-07", "하기휴가"},
            {"2024-08-08", "하기휴가"},
            {"2024-08-15", "광복절"},
            {"2024-09-16", "추석연휴"},
            {"2024-09-17", "추석"},
            {"2024-09-18", "추석연휴"},
            {"2024-09-19", "추석연휴"},
            {"2024-10-01", "창립기념일"},
            {"2024-10-03", "개천절"},
            {"2024-10-09", "한글날"},
            {"2024-12-25", "성탄절"},

            // 2025년 공휴일
            {"2025-01-01", "신정"},
            {"2025-01-02", "신정연휴"},
            {"2025-01-27", "임시공휴일"},
            {"2025-01-28", "설날연휴"},
            {"2025-01-29", "설날"},
            {"2025-01-30", "설날연휴"},
            {"2025-01-31", "설날연휴"},
            {"2025-03-01", "삼일절"},
            {"2025-03-03", "대체공휴일"},
            {"2025-05-01", "근로자의날"},
            {"2025-05-05", "어린이날,석가탄신"},
            {"2025-05-06", "대체공휴일"},
            {"2025-06-06", "현충일"},
            {"2025-07-15", "노조창립기념일"},
            {"2025-08-04", "하기휴가"},
            {"2025-08-05", "하기휴가"},
            {"2025-08-06", "하기휴가"},
            {"2025-08-07", "하기휴가"},
            {"2025-08-08", "하기휴가"},
            {"2025-08-11", "하기휴가"},
            {"2025-08-12", "하기휴가"},
            {"2025-08-13", "하기휴가"},
            {"2025-08-14", "하기휴가"},
            {"2025-08-15", "광복절"},
            {"2025-10-01", "창립기념일"},
            {"2025-10-03", "개천절"},
            {"2025-10-05", "추석연휴"},
            {"2025-10-06", "추석"},
            {"2025-10-07", "추석연휴"},
            {"2025-10-08", "추석연휴"},
            {"2025-10-09", "한글날"},
            {"2025-12-25", "성탄절"},

            // 2026년 공휴일
            {"2026-01-01", "신정"},
            {"2026-01-02", "신정연휴"},
            {"2026-02-16", "설연휴"},
            {"2026-02-17", "설날"},
            {"2026-02-18", "설연휴"},
            {"2026-02-19", "설연휴"},
            {"2026-03-01", "삼일절"},
            {"2026-03-02", "대체공휴일"},
            {"2026-05-01", "근로자의 날"},
            {"2026-05-05", "어린이 날"},
            {"2026-05-24", "석가탄신일"},
            {"2026-05-25", "대체공휴일"},
            {"2026-06-06", "현충일"},
            {"2026-07-15", "노조창립일"},
            {"2026-08-03", "하기휴가"},
            {"2026-08-04", "하기휴가"},
            {"2026-08-05", "하기휴가"},
            {"2026-08-06", "하기휴가"},
            {"2026-08-07", "하기휴가"},
            {"2026-08-10", "하기휴가"},
            {"2026-08-11", "하기휴가"},
            {"2026-08-12", "하기휴가"},
            {"2026-08-13", "하기휴가"},
            {"2026-08-15", "광복절"},
            {"2026-08-17", "대체공휴일"},
            {"2026-09-24", "추석연휴"},
            {"2026-09-25", "추석"},
            {"2026-09-26", "추석연휴"},
            {"2026-09-28", "대체공휴일"},
            {"2026-10-01", "창립기념일"},
            {"2026-10-03", "개천절"},
            {"2026-10-05", "대체공휴일"},
            {"2026-10-09", "한글날"},
            {"2026-12-25", "성탄절"},

            // 2027년 공휴일
            {"2027-01-01", "신정"},
            {"2027-01-02", "신정연휴"},
            {"2027-02-06", "설날연휴"},
            {"2027-02-08", "설날연휴"},
            {"2027-02-09", "설날연휴"},
            {"2027-02-10", "중복휴무"},
            {"2027-03-01", "삼일절"},
            {"2027-03-03", "21대 대선"},
            {"2027-05-01", "근로자의날"},
            {"2027-05-05", "어린이날"},
            {"2027-05-13", "석가탄신일"},
            {"2027-07-15", "노조창립기념일"},
            {"2027-08-02", "하기휴가"},
            {"2027-08-03", "하기휴가"},
            {"2027-08-04", "하기휴가"},
            {"2027-08-05", "하기휴가"},
            {"2027-08-06", "하기휴가"},
            {"2027-08-09", "하기휴가"},
            {"2027-08-10", "하기휴가"},
            {"2027-08-11", "하기휴가"},
            {"2027-08-12", "하기휴가"},
            {"2027-08-15", "광복절"},
            {"2027-08-16", "대체공휴일"},
            {"2027-09-14", "추석연휴"},
            {"2027-09-15", "추석"},
            {"2027-09-16", "추석연휴"},
            {"2027-09-17", "추석연휴"},
            {"2027-10-01", "창사기념일"},
            {"2027-10-03", "개천절"},
            {"2027-10-04", "대체공휴일"},
            {"2027-10-09", "한글날"},
            {"2027-10-11", "대체공휴일"},
            {"2027-12-25", "성탄절"},
            {"2027-12-27", "대체공휴일"},

            // 2028년 공휴일
            {"2028-01-01", "신정"},
            {"2028-01-02", "신정연휴"},
            {"2028-01-26", "설날연휴"},
            {"2028-01-27", "설날"},
            {"2028-01-28", "설날연휴"},
            {"2028-01-31", "중복휴무"},
            {"2028-03-01", "삼일절"},
            {"2028-04-12", "23대 총선"},
            {"2028-05-02", "석가탄신일"},
            {"2028-05-05", "어린이날"},
            {"2028-06-06", "현충일"},
            {"2028-07-31", "하기휴가"},
            {"2028-08-01", "하기휴가"},
            {"2028-08-02", "하기휴가"},
            {"2028-08-03", "하기휴가"},
            {"2028-08-04", "하기휴가"},
            {"2028-08-07", "하기휴가"},
            {"2028-08-08", "하기휴가"},
            {"2028-08-09", "하기휴가"},
            {"2028-08-10", "하기휴가"},
            {"2028-08-15", "광복절"},
            {"2028-10-02", "추석연휴"},
            {"2028-10-03", "추석"},
            {"2028-10-04", "추석연휴"},
            {"2028-10-05", "추석연휴"},
            {"2028-10-09", "한글날"},
            {"2028-12-25", "성탄절"}
        };

        // 공휴일 및 주말 체크 메서드 추가
        private bool IsWorkingDay(DateTime date)
        {
            // 주말 체크 (토요일 = 6, 일요일 = 0)
            if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday)
                return false;

            // 공휴일 체크
            string dateKey = date.ToString("yyyy-MM-dd");
            return !holidays.ContainsKey(dateKey);
        }

        private Dictionary<string, Dictionary<DateTime, double>> limitDataByType;
        public DailyLoadWindow(string month, List<ShipSchedule> shipData,
            Dictionary<string, Dictionary<DateTime, double>> limitDataByType, string location)
        {
            InitializeComponent();
            this.limitDataByType = limitDataByType;
            this.selectedMonth = month;
            this.currentLocation = location;  // 추가
            txtSelectedMonth.Text = string.Format("{0} - {1}", month, location);

            List<ShipSchedule> filteredShipData = new List<ShipSchedule>();
            if (location == "통합")
            {
                filteredShipData = shipData;
            }
            else
            {
                //foreach (ShipSchedule schedule in shipData)
                //{
                //    if (schedule.MFG_IND == location)
                //    {
                //        filteredShipData.Add(schedule);
                //    }
                //}
                foreach (ShipSchedule schedule in shipData)
                {
                    if (schedule.MFG_IND_After == location)
                    {
                        filteredShipData.Add(schedule);
                    }
                }
            }

            Dictionary<DateTime, double> combinedLimitData = CombineLimitData();
            InitializeData(filteredShipData, combinedLimitData, location);
            DrawGraph();
            DisplayGridData();
            SizeChanged += new SizeChangedEventHandler(Window_SizeChanged);
        }

        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            DrawGraph();
        }

        // 기존 생성자는 그대로 두고, UpdateData 메서드만 추가
        public void UpdateData(List<ShipSchedule> shipData, Dictionary<string, Dictionary<DateTime, double>> limitDataByType)
        {
            this.limitDataByType = limitDataByType;

            List<ShipSchedule> filteredShipData = new List<ShipSchedule>();
            if (currentLocation == "통합")
            {
                filteredShipData = shipData;
            }
            else
            {
                foreach (ShipSchedule schedule in shipData)
                {
                    if (schedule.MFG_IND == currentLocation)
                    {
                        filteredShipData.Add(schedule);
                    }
                }
            }

            Dictionary<DateTime, double> combinedLimitData = CombineLimitData();
            InitializeData(filteredShipData, combinedLimitData, currentLocation);
            DrawGraph();
            DisplayGridData();
        }

        private Dictionary<DateTime, double> CombineLimitData()
        {
            Dictionary<DateTime, double> combinedLimitData = new Dictionary<DateTime, double>();
            if (limitDataByType == null) return combinedLimitData;

            // CAPA2와 CAPA2_1 데이터 합치기
            if (limitDataByType.ContainsKey("CAPA2"))
            {
                foreach (var kvp in limitDataByType["CAPA2"])
                {
                    combinedLimitData[kvp.Key] = kvp.Value;
                }
            }
            if (limitDataByType.ContainsKey("CAPA2_1"))
            {
                foreach (var kvp in limitDataByType["CAPA2_1"])
                {
                    if (combinedLimitData.ContainsKey(kvp.Key))
                        combinedLimitData[kvp.Key] += kvp.Value;
                    else
                        combinedLimitData[kvp.Key] = kvp.Value;
                }
            }
            return combinedLimitData;
        }

        private void InitializeData(List<ShipSchedule> shipData, Dictionary<DateTime, double> limitData, string location)
        {
            //dailyDataList = new List<DailyData>();

            //string[] dateParts = selectedMonth.Split('/');
            //int year = int.Parse(dateParts[0]);
            //int month = int.Parse(dateParts[1]);
            //int daysInMonth = DateTime.DaysInMonth(year, month);

            dailyDataList = new List<DailyData>();

            string[] dateParts = selectedMonth.Split('/');
            int year = int.Parse(dateParts[0]);
            int month = int.Parse(dateParts[1]);
            int daysInMonth = DateTime.DaysInMonth(year, month);

            // Business_Check 상태를 Owner를 통해 가져오기
            var lineLoadWindow = Owner as LineLoadGraphWindow;
            bool useOriginalField = lineLoadWindow != null && lineLoadWindow.Business_Check != null &&
                                   lineLoadWindow.Business_Check.IsChecked == true;

            for (int day = 1; day <= daysInMonth; day++)
            {
                DateTime currentDate = new DateTime(year, month, day);

                if (!IsWorkingDay(currentDate))
                {
                    dailyDataList.Add(new DailyData
                    {
                        Date = string.Format("{0}/{1:00}/{2:00}", year, month, day),
                        OriginalCount = 0,
                        AdjustedCount = 0,
                        LimitValue = 0
                    });
                    continue;
                }

                int originalCount = 0;
                int adjustedCount = 0;

                double limitValue = 0;
                if (limitData != null && limitData.ContainsKey(currentDate))
                {
                    limitValue = limitData[currentDate];
                }

                if (shipData != null)
                {
                    foreach (ShipSchedule schedule in shipData)
                    {
                        if (schedule == null) continue;

                        if (schedule.S_KIND == "CAPE 중일정개수" ||
                            schedule.S_KIND == "CAPE 조정결과개수")
                            continue;

                        // 통합 데이터가 아닌 경우 해당 위치의 데이터만 처리
                        string mfgField = useOriginalField ? schedule.MFG_IND : schedule.MFG_IND_After;
                        if (location != "통합" && mfgField != location)
                            continue;

                        DateTime endDate;
                        if (schedule.STG_CD == "90")
                        {
                            endDate = schedule.ERECT_PLDT;
                        }
                        else if (schedule.STG_CD == "70" || schedule.STG_CD == "80")
                        {
                            endDate = schedule.WKFIPLDT;
                        }
                        else
                        {
                            endDate = schedule.WKFIPLDT1;
                        }

                        if (currentDate >= schedule.WKSTPLDT1 && currentDate <= endDate)
                        {
                            originalCount++;
                            bool isCrimson = false;

                            if (schedule.MonthlyDates != null)
                            {
                                foreach (var monthDates in schedule.MonthlyDates)
                                {
                                    if (monthDates == null) continue;

                                    var dateList = monthDates as List<DateCell>;
                                    if (dateList != null)
                                    {
                                        foreach (DateCell cell in dateList)
                                        {
                                            if (cell != null && cell.Day == day.ToString("00") &&
                                                cell.Color == Brushes.Crimson)
                                            {
                                                isCrimson = true;
                                                break;
                                            }
                                        }
                                    }
                                    if (isCrimson) break;
                                }
                            }

                            if (!isCrimson)
                                adjustedCount++;
                        }
                    }
                }

                dailyDataList.Add(new DailyData
                {
                    Date = string.Format("{0}/{1:00}/{2:00}", year, month, day),
                    OriginalCount = originalCount,
                    AdjustedCount = adjustedCount,
                    LimitValue = limitValue
                });
            }
        }

        //private void DrawLimitLines(double width, double height, int maxValue)
        //{
        //    if (dailyDataList == null || dailyDataList.Count == 0 || limitDataByType == null) return;
        //    double xInterval = width / (dailyDataList.Count - 1);

        //    // CAPA2 리미트선 (주황색)
        //    if (limitDataByType.ContainsKey("CAPA2"))
        //    {
        //        bool isFirstDay = true;
        //        foreach (var kvp in limitDataByType["CAPA2"])
        //        {
        //            int dayIndex = kvp.Key.Day - 1;
        //            double x = GRAPH_MARGIN + (dayIndex * xInterval);
        //            double y = GRAPH_MARGIN + (height * (1 - (kvp.Value / maxValue)));

        //            Line limitLine = new Line
        //            {
        //                X1 = x,
        //                Y1 = y,
        //                X2 = x + xInterval,
        //                Y2 = y,
        //                Stroke = Brushes.Orange,
        //                StrokeThickness = 2
        //            };
        //            canvasGraph.Children.Add(limitLine);

        //            // 첫 번째 날짜에만 레이블 추가
        //            if (isFirstDay)
        //            {
        //                TextBlock label = new TextBlock
        //                {
        //                    Text = kvp.Value.ToString("F1"),
        //                    FontSize = 10,
        //                    Foreground = Brushes.Orange
        //                };
        //                Canvas.SetLeft(label, x + 5);
        //                Canvas.SetTop(label, y - 15);
        //                canvasGraph.Children.Add(label);
        //                isFirstDay = false;
        //            }
        //        }
        //    }

        //    // CAPA2_1 리미트선 (하늘색)
        //    if (limitDataByType.ContainsKey("CAPA2_1"))
        //    {
        //        bool isFirstDay = true;
        //        foreach (var kvp in limitDataByType["CAPA2_1"])
        //        {
        //            int dayIndex = kvp.Key.Day - 1;
        //            double x = GRAPH_MARGIN + (dayIndex * xInterval);
        //            double y = GRAPH_MARGIN + (height * (1 - (kvp.Value / maxValue)));

        //            Line limitLine = new Line
        //            {
        //                X1 = x,
        //                Y1 = y,
        //                X2 = x + xInterval,
        //                Y2 = y,
        //                Stroke = Brushes.DeepSkyBlue,
        //                StrokeThickness = 2
        //            };
        //            canvasGraph.Children.Add(limitLine);

        //            // 첫 번째 날짜에만 레이블 추가
        //            if (isFirstDay)
        //            {
        //                TextBlock label = new TextBlock
        //                {
        //                    Text = kvp.Value.ToString("F1"),
        //                    FontSize = 10,
        //                    Foreground = Brushes.DeepSkyBlue
        //                };
        //                Canvas.SetLeft(label, x + 5);
        //                Canvas.SetTop(label, y + 5);
        //                canvasGraph.Children.Add(label);
        //                isFirstDay = false;
        //            }
        //        }
        //    }
        //}

        //버그 메모리 제한 설정
        private void DrawLimitLines(double width, double height, int maxValue)
        {
            if (dailyDataList == null || dailyDataList.Count == 0 || limitDataByType == null || maxValue <= 0) return;

            double xInterval = width / (dailyDataList.Count - 1);

            // CAPA2 리미트선 (주황색)
            if (limitDataByType.ContainsKey("CAPA2"))
            {
                bool isFirstDay = true;
                foreach (var kvp in limitDataByType["CAPA2"])
                {
                    int dayIndex = kvp.Key.Day - 1;
                    if (dayIndex < 0 || dayIndex >= dailyDataList.Count) continue;

                    // 안전한 Y 좌표 계산
                    double yValue = kvp.Value / maxValue;
                    if (double.IsInfinity(yValue) || double.IsNaN(yValue))
                        continue;

                    double y = GRAPH_MARGIN + (height * (1 - Math.Min(Math.Max(yValue, 0), 1)));
                    double x = GRAPH_MARGIN + (dayIndex * xInterval);

                    // 좌표가 유효한지 확인
                    if (double.IsInfinity(x) || double.IsNaN(x) ||
                        double.IsInfinity(y) || double.IsNaN(y))
                        continue;

                    Line limitLine = new Line
                    {
                        X1 = x,
                        Y1 = y,
                        X2 = x + xInterval,
                        Y2 = y,
                        Stroke = Brushes.Orange,
                        StrokeThickness = 2
                    };
                    canvasGraph.Children.Add(limitLine);

                    if (isFirstDay)
                    {
                        TextBlock label = new TextBlock
                        {
                            Text = kvp.Value.ToString("F1"),
                            FontSize = 10,
                            Foreground = Brushes.Orange
                        };
                        Canvas.SetLeft(label, x + 5);
                        Canvas.SetTop(label, y - 15);
                        canvasGraph.Children.Add(label);
                        isFirstDay = false;
                    }
                }
            }

            // CAPA2_1 리미트선 (하늘색)
            if (limitDataByType.ContainsKey("CAPA2_1"))
            {
                bool isFirstDay = true;
                foreach (var kvp in limitDataByType["CAPA2_1"])
                {
                    int dayIndex = kvp.Key.Day - 1;
                    if (dayIndex < 0 || dayIndex >= dailyDataList.Count) continue;

                    // 안전한 Y 좌표 계산
                    double yValue = kvp.Value / maxValue;
                    if (double.IsInfinity(yValue) || double.IsNaN(yValue))
                        continue;

                    double y = GRAPH_MARGIN + (height * (1 - Math.Min(Math.Max(yValue, 0), 1)));
                    double x = GRAPH_MARGIN + (dayIndex * xInterval);

                    // 좌표가 유효한지 확인
                    if (double.IsInfinity(x) || double.IsNaN(x) ||
                        double.IsInfinity(y) || double.IsNaN(y))
                        continue;

                    Line limitLine = new Line
                    {
                        X1 = x,
                        Y1 = y,
                        X2 = x + xInterval,
                        Y2 = y,
                        Stroke = Brushes.DeepSkyBlue,
                        StrokeThickness = 2
                    };
                    canvasGraph.Children.Add(limitLine);

                    if (isFirstDay)
                    {
                        TextBlock label = new TextBlock
                        {
                            Text = kvp.Value.ToString("F1"),
                            FontSize = 10,
                            Foreground = Brushes.DeepSkyBlue
                        };
                        Canvas.SetLeft(label, x + 5);
                        Canvas.SetTop(label, y + 5);
                        canvasGraph.Children.Add(label);
                        isFirstDay = false;
                    }
                }
            }
        }
        private void DrawGraph()
        {
            canvasGraph.Children.Clear();

            double width = canvasGraph.ActualWidth;
            double height = canvasGraph.ActualHeight;

            if (width <= 0 || height <= 0 || dailyDataList == null || dailyDataList.Count == 0)
                return;

            // 그래프 영역 계산
            double graphWidth = width - (GRAPH_MARGIN * 2);
            double graphHeight = height - (GRAPH_MARGIN * 2);

            // 최대값 계산
            int maxValue = 0;
            foreach (var data in dailyDataList)
            {
                maxValue = Math.Max(maxValue, Math.Max(data.OriginalCount, data.AdjustedCount));
            }
            maxValue = ((maxValue + 4) / 5) * 5; // 5단위로 올림

            // 그리드 그리기
            DrawGridLines(graphWidth, graphHeight, maxValue);

            // 데이터 선 그리기
            DrawDataLines(graphWidth, graphHeight, maxValue);

            // 축 그리기
            DrawAxes(graphWidth, graphHeight, maxValue);

            // 범례 그리기
            DrawLegend(graphWidth);
            // 리미트선 그리기
            DrawLimitLines(graphWidth, graphHeight, maxValue); // 리미트선 추가
        }

        //private void DrawGridLines(double width, double height, int maxValue)
        //{
        //    // 수평 그리드 라인
        //    for (int i = 0; i <= maxValue; i += 5)
        //    {
        //        double y = GRAPH_MARGIN + (height * (1 - ((double)i / maxValue)));

        //        Line gridLine = new Line
        //        {
        //            X1 = GRAPH_MARGIN,
        //            Y1 = y,
        //            X2 = GRAPH_MARGIN + width,
        //            Y2 = y,
        //            Stroke = new SolidColorBrush(Color.FromArgb(40, 0, 0, 0)),
        //            StrokeThickness = 1
        //        };
        //        canvasGraph.Children.Add(gridLine);

        //        // Y축 레이블
        //        TextBlock label = new TextBlock
        //        {
        //            Text = i.ToString(),
        //            FontSize = 10
        //        };
        //        Canvas.SetLeft(label, 5);
        //        Canvas.SetTop(label, y - 8);
        //        canvasGraph.Children.Add(label);
        //    }
        //}
        private void DrawGridLines(double width, double height, int maxValue)
        {
            // 안전한 최대값 계산
            if (maxValue <= 0)
            {
                maxValue = 5; // 기본 최대값 설정
            }

            // 안전한 그리드 간격 계산
            int interval = Math.Max(1, maxValue / 5);

            for (int i = 0; i <= maxValue; i += interval)
            {
                // 안전한 Y 좌표 계산
                double y = GRAPH_MARGIN + (height * (1 - (Math.Min(i, maxValue) / (double)maxValue)));

                // NaN 또는 무한대 값 체크
                if (double.IsNaN(y) || double.IsInfinity(y))
                {
                    y = GRAPH_MARGIN; // 기본값으로 설정
                }

                Line gridLine = new Line
                {
                    X1 = GRAPH_MARGIN,
                    Y1 = y,
                    X2 = GRAPH_MARGIN + width,
                    Y2 = y,
                    Stroke = new SolidColorBrush(Color.FromArgb(40, 0, 0, 0)),
                    StrokeThickness = 1
                };
                canvasGraph.Children.Add(gridLine);

                // Y축 레이블
                TextBlock label = new TextBlock
                {
                    Text = i.ToString(),
                    FontSize = 10
                };
                Canvas.SetLeft(label, 5);
                Canvas.SetTop(label, y - 8);
                canvasGraph.Children.Add(label);
            }
        }
        //private void DrawDataLines(double width, double height, int maxValue)
        //{
        //    // 간격 계산
        //    double xInterval = width / (dailyDataList.Count - 1);

        //    // 중일정 라인
        //    Polyline originalLine = new Polyline
        //    {
        //        Stroke = Brushes.Blue,
        //        StrokeThickness = 2
        //    };

        //    // 조정 라인
        //    Polyline adjustedLine = new Polyline
        //    {
        //        Stroke = Brushes.Red,
        //        StrokeThickness = 2
        //    };

        //    for (int i = 0; i < dailyDataList.Count; i++)
        //    {
        //        double x = GRAPH_MARGIN + (i * xInterval);

        //        // 중일정 데이터 포인트
        //        double y1 = GRAPH_MARGIN + (height * (1 - ((double)dailyDataList[i].OriginalCount / maxValue)));
        //        originalLine.Points.Add(new Point(x, y1));

        //        // 조정 데이터 포인트
        //        double y2 = GRAPH_MARGIN + (height * (1 - ((double)dailyDataList[i].AdjustedCount / maxValue)));
        //        adjustedLine.Points.Add(new Point(x, y2));

        //        // 데이터 포인트 마커 그리기
        //        DrawDataPoint(x, y1, Brushes.Blue, dailyDataList[i].OriginalCount.ToString());
        //        DrawDataPoint(x, y2, Brushes.Red, dailyDataList[i].AdjustedCount.ToString());
        //    }

        //    canvasGraph.Children.Add(originalLine);
        //    canvasGraph.Children.Add(adjustedLine);
        //}
        private void DrawDataLines(double width, double height, int maxValue)
        {
            // 간격 계산
            double xInterval = width / (dailyDataList.Count - 1);

            // 중일정 라인
            Polyline originalLine = new Polyline
            {
                Stroke = Brushes.Blue,
                StrokeThickness = 2
            };

            // 조정 라인
            Polyline adjustedLine = new Polyline
            {
                Stroke = Brushes.Red,
                StrokeThickness = 2
            };

            for (int i = 0; i < dailyDataList.Count; i++)
            {
                double x = GRAPH_MARGIN + (i * xInterval);

                // 중일정 데이터 포인트
                double y1 = GRAPH_MARGIN + (height * (1 - ((double)dailyDataList[i].OriginalCount / maxValue)));

                // 조정 데이터 포인트
                double y2 = GRAPH_MARGIN + (height * (1 - ((double)dailyDataList[i].AdjustedCount / maxValue)));

                // 데이터 포인트 마커 그리기
                DrawDataPoint(x, y1, Brushes.Blue, dailyDataList[i].OriginalCount.ToString());
                DrawDataPoint(x, y2, Brushes.Red, dailyDataList[i].AdjustedCount.ToString());

                // 공휴일 또는 주말은 건너뛰고 연결만 수행
                DateTime currentDate = DateTime.Parse(dailyDataList[i].Date);
                if (!IsWorkingDay(currentDate))
                {
                    // 이전 점과 다음 유효한 점을 직선으로 연결
                    if (i > 0 && i < dailyDataList.Count - 1)
                    {
                        int nextIndex = i + 1;
                        while (nextIndex < dailyDataList.Count && !IsWorkingDay(DateTime.Parse(dailyDataList[nextIndex].Date)))
                        {
                            nextIndex++;
                        }

                        if (nextIndex < dailyDataList.Count)
                        {
                            double nextX = GRAPH_MARGIN + (nextIndex * xInterval);
                            double nextY1 = GRAPH_MARGIN + (height * (1 - ((double)dailyDataList[nextIndex].OriginalCount / maxValue)));
                            double nextY2 = GRAPH_MARGIN + (height * (1 - ((double)dailyDataList[nextIndex].AdjustedCount / maxValue)));

                            // 중일정 라인 연결
                            originalLine.Points.Add(new Point(nextX, nextY1));
                            adjustedLine.Points.Add(new Point(nextX, nextY2));
                        }
                    }

                    continue; // 그래프 점 추가 생략
                }

                // 유효한 데이터는 선을 이어줌
                originalLine.Points.Add(new Point(x, y1));
                adjustedLine.Points.Add(new Point(x, y2));
            }

            canvasGraph.Children.Add(originalLine);
            canvasGraph.Children.Add(adjustedLine);
        }


        private void DrawDataPoint(double x, double y, Brush color, string tooltip)
        {
            Ellipse point = new Ellipse
            {
                Width = 6,
                Height = 6,
                Fill = color,
                Stroke = Brushes.White,
                StrokeThickness = 1,
                ToolTip = tooltip
            };

            Canvas.SetLeft(point, x - 3);
            Canvas.SetTop(point, y - 3);
            canvasGraph.Children.Add(point);
        }

        private void DrawAxes(double width, double height, int maxValue)
        {
            // X축
            Line xAxis = new Line
            {
                X1 = GRAPH_MARGIN,
                Y1 = GRAPH_MARGIN + height,
                X2 = GRAPH_MARGIN + width,
                Y2 = GRAPH_MARGIN + height,
                Stroke = Brushes.Black,
                StrokeThickness = 1
            };
            canvasGraph.Children.Add(xAxis);

            // Y축
            Line yAxis = new Line
            {
                X1 = GRAPH_MARGIN,
                Y1 = GRAPH_MARGIN,
                X2 = GRAPH_MARGIN,
                Y2 = GRAPH_MARGIN + height,
                Stroke = Brushes.Black,
                StrokeThickness = 1
            };
            canvasGraph.Children.Add(yAxis);

            // X축 레이블
            int labelInterval = Math.Max(1, dailyDataList.Count / 10);
            for (int i = 0; i < dailyDataList.Count; i += labelInterval)
            {
                TextBlock label = new TextBlock
                {
                    Text = dailyDataList[i].Date.Split('/')[2],
                    FontSize = 10
                };

                double x = GRAPH_MARGIN + (i * (width / (dailyDataList.Count - 1)));
                Canvas.SetLeft(label, x - 8);
                Canvas.SetTop(label, height + GRAPH_MARGIN + 5);
                canvasGraph.Children.Add(label);
            }
        }

        private void DrawLegend(double width)
        {
            StackPanel legend = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Background = new SolidColorBrush(Color.FromArgb(200, 255, 255, 255))
            };

            // 중일정 범례
            StackPanel originalLegend = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(5)
            };
            originalLegend.Children.Add(new Rectangle
            {
                Width = 20,
                Height = 3,
                Fill = Brushes.Blue,
                Margin = new Thickness(0, 7, 5, 0)
            });
            originalLegend.Children.Add(new TextBlock
            {
                Text = "중일정",
                VerticalAlignment = VerticalAlignment.Center
            });

            // 조정 범례
            StackPanel adjustedLegend = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(5)
            };
            adjustedLegend.Children.Add(new Rectangle
            {
                Width = 20,
                Height = 3,
                Fill = Brushes.Red,
                Margin = new Thickness(0, 7, 5, 0)
            });
            adjustedLegend.Children.Add(new TextBlock
            {
                Text = "조정",
                VerticalAlignment = VerticalAlignment.Center
            });

            legend.Children.Add(originalLegend);
            legend.Children.Add(adjustedLegend);

            Canvas.SetRight(legend, GRAPH_MARGIN);
            Canvas.SetTop(legend, GRAPH_MARGIN);
            canvasGraph.Children.Add(legend);
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            base.OnClosing(e);

            try
            {
                // .NET 4.5에 맞는 방식으로 창 목록 수집
                var windowsToClose = new List<DailyLoadWindow>();
                foreach (Window window in Application.Current.Windows)
                {
                    if (window is DailyLoadWindow && window != this)
                    {
                        windowsToClose.Add(window as DailyLoadWindow);
                    }
                }

                // 수집된 창들을 순차적으로 닫기
                foreach (var window in windowsToClose)
                {
                    Application.Current.Dispatcher.BeginInvoke(
                        System.Windows.Threading.DispatcherPriority.Normal,
                        new Action(() =>
                        {
                            try
                            {
                                if (window != null && window.IsLoaded)
                                {
                                    window.Close();
                                }
                            }
                            catch (Exception closeEx)
                            {
                                System.Diagnostics.Debug.WriteLine("Window closing error: " + closeEx.Message);
                            }
                        })
                    );
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Error in OnClosing: " + ex.Message);
            }
        }

        private void DisplayGridData()
        {
            gridDailyData.ItemsSource = dailyDataList;
        }

        private void btnExcel_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveDialog = new SaveFileDialog
            {
                Filter = "Excel Files (*.xls)|*.xls",
                FileName = string.Format("일별부하현황_{0}", selectedMonth.Replace("/", "")),
                DefaultExt = "xls"
            };

            if (saveDialog.ShowDialog() == true)
            {
                Excel.Application excel = null;
                Excel.Workbook wb = null;
                Excel._Worksheet ws = null;

                try
                {
                    excel = new Excel.Application();
                    excel.Visible = false;
                    wb = excel.Workbooks.Add();
                    ws = wb.Sheets[1];

                    // 제목 추가
                    ws.Cells[1, 1] = string.Format("{0} 일별 부하율 현황", selectedMonth);
                    Excel.Range titleRange = ws.Range[ws.Cells[1, 1], ws.Cells[1, 5]];
                    titleRange.Merge();
                    titleRange.Font.Bold = true;
                    titleRange.Font.Size = 14;
                    titleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                    // 헤더 추가
                    string[] headers = { "일자", "중일정건수", "조정건수", "차이", "조정율" };
                    for (int i = 0; i < headers.Length; i++)
                    {
                        ws.Cells[3, i + 1] = headers[i];
                        ws.Cells[3, i + 1].Font.Bold = true;
                        ws.Cells[3, i + 1].Interior.Color = Excel.XlRgbColor.rgbLightGray; // ColorTranslator 대신 Excel 색상 상수 사용
                    }

                    // 데이터 추가
                    for (int i = 0; i < dailyDataList.Count; i++)
                    {
                        ws.Cells[i + 4, 1] = dailyDataList[i].Date;
                        ws.Cells[i + 4, 2] = dailyDataList[i].OriginalCount;
                        ws.Cells[i + 4, 3] = dailyDataList[i].AdjustedCount;
                        ws.Cells[i + 4, 4] = dailyDataList[i].Difference;
                        ws.Cells[i + 4, 5] = dailyDataList[i].AdjustmentRate;
                    }

                    // 차트 추가
                    Excel.ChartObjects charts = (Excel.ChartObjects)ws.ChartObjects();
                    Excel.ChartObject chartObject = charts.Add(350, 50, 400, 250);
                    Excel.Chart chart = chartObject.Chart;

                    // 차트 데이터 범위 설정
                    string lastRow = (dailyDataList.Count + 3).ToString();
                    Excel.Range chartData = ws.Range["B4:C" + lastRow];
                    Excel.Range chartXValues = ws.Range["A4:A" + lastRow];

                    chart.ChartType = Excel.XlChartType.xlLine;
                    chart.HasLegend = true;
                    chart.HasTitle = true;
                    chart.ChartTitle.Text = "일별 중일정/조정 건수";

                    Excel.SeriesCollection seriesCollection = (Excel.SeriesCollection)chart.SeriesCollection();

                    // 중일정 데이터
                    Excel.Series series1 = seriesCollection.NewSeries();
                    series1.XValues = chartXValues;
                    series1.Values = ws.Range["B4:B" + lastRow];
                    series1.Name = "중일정";

                    // 조정 데이터
                    Excel.Series series2 = seriesCollection.NewSeries();
                    series2.XValues = chartXValues;
                    series2.Values = ws.Range["C4:C" + lastRow];
                    series2.Name = "조정";

                    // 열 너비 자동 조정
                    ws.Columns.AutoFit();

                    // 저장
                    wb.SaveAs(saveDialog.FileName);
                    MessageBox.Show("Excel 파일이 저장되었습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Excel 저장 중 오류가 발생했습니다: " + ex.Message,
                        "오류", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    if (ws != null)
                        Marshal.ReleaseComObject(ws);
                    if (wb != null)
                    {
                        wb.Close(true);
                        Marshal.ReleaseComObject(wb);
                    }
                    if (excel != null)
                    {
                        excel.Quit();
                        Marshal.ReleaseComObject(excel);
                    }
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
        }
    }
}