﻿using System;
using System.Collections;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace ShipDataViewer
{
    public partial class DateEditorWindow : Window
    {
        private ShipSchedule _schedule;
        private DateTime[] _originalDates;  // 원래 날짜들을 저장
        private bool[] _dateModificationFlags; // 날짜 수정 상태 추적
        private string _originalMfgInd;//추가 사업장

        public DateEditorWindow(ShipSchedule schedule)
        {
            InitializeComponent();
            _schedule = schedule;
            _originalMfgInd = schedule.MFG_IND;

            // 원래 날짜 저장
            _originalDates = new DateTime[5]
            {
                schedule.WKSTPLDT,
                schedule.WKSTPLDT1,
                schedule.WKFIPLDT,
                schedule.WKFIPLDT1,
                schedule.ERECT_PLDT
            };

            // 날짜 수정 상태 초기화
            _dateModificationFlags = new bool[5]
            {
                false,
                schedule.IsWKSTPLDT1Modified,
                schedule.IsWKFIPLDTModified,
                false,
                schedule.IsERPLDTModified
            };

            LoadData();

            // DatePicker의 SelectedDateChanged 이벤트 처리기 등록
            //WkstpldtPicker.SelectedDateChanged += DatePicker_SelectedDateChanged;
            Wkstpldt1Picker.SelectedDateChanged += DatePicker_SelectedDateChanged;
            WkfipldtPicker.SelectedDateChanged += DatePicker_SelectedDateChanged;
            Wkfipldt1Picker.SelectedDateChanged += DatePicker_SelectedDateChanged;
            ErectPldtPicker.SelectedDateChanged += DatePicker_SelectedDateChanged;

            // 기존 수정 상태에 따른 색상 설정
            UpdateDatePickerColors();
        }

        private void LoadData()
        {
            try
            {
                // 정보 표시
                SKindText.Text = _schedule.S_KIND;
                STypeText.Text = _schedule.S_TYPE;
                OwnerText.Text = _schedule.OWNER;
                ShipDispText.Text = _schedule.SHIP_DISP;
                BlockText.Text = _schedule.BLOCK;
                StageText.Text = _schedule.STG_CD;
                SNameText.Text = _schedule.S_NAME;
                //MfgIndText.Text = _schedule.MFG_IND;
                LocDescText.Text = _schedule.LOC_DESC;
                PeTypeText.Text = _schedule.PE_TYPE;

                // ComboBox 초기값 설정
                foreach (ComboBoxItem item in MfgIndComboBox.Items)
                {
                    if (item.Content.ToString() == _schedule.MFG_IND)
                    {
                        MfgIndComboBox.SelectedItem = item;
                        break;
                    }
                }

                // DatePicker 설정
                //WkstpldtPicker.SelectedDate = _schedule.WKSTPLDT;
                Wkstpldt1Picker.SelectedDate = _schedule.WKSTPLDT1;
                WkfipldtPicker.SelectedDate = _schedule.WKFIPLDT;
                Wkfipldt1Picker.SelectedDate = _schedule.WKFIPLDT1;
                ErectPldtPicker.SelectedDate = _schedule.ERECT_PLDT;

                // 콤보박스 SelectionChanged 이벤트 등록
                MfgIndComboBox.SelectionChanged += MfgIndComboBox_SelectionChanged;

                // 기존 날짜 색상 설정
                UpdateDatePickerColors();
                // 창 제목 설정
                this.Title = "데이터 수정표[날짜/사업장]";
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "데이터 로드 중 오류가 발생했습니다: {ex.Message}",
                    "ERROR(오류)/데이터로드실패"
                );
                this.Close();
            }
        }

        private void MfgIndComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem selectedItem = MfgIndComboBox.SelectedItem as ComboBoxItem;
            if (selectedItem != null)
            {
                // 사업장이 변경되었는지 확인
                bool isModified = selectedItem.Content.ToString() != _originalMfgInd;

                // 사업장 텍스트를 빨간색으로 설정
                MfgIndComboBox.Foreground = isModified ? Brushes.Red : Brushes.Black;

                // 수정 상태 플래그 설정
                _schedule.IsMfgModified = isModified;
            }
        }


        private void UpdateDatePickerColors()
        {
            // 기존 수정 상태에 따른 색상 설정
            if (_schedule.IsWKSTPLDT1Modified)
                Wkstpldt1Picker.Foreground = Brushes.Red;
            if (_schedule.IsWKFIPLDTModified)
                WkfipldtPicker.Foreground = Brushes.Blue;
            if (_schedule.IsERPLDTModified)
                ErectPldtPicker.Foreground = Brushes.Blue;
        }

        private void DatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            var datePicker = sender as DatePicker;
            if (datePicker != null && datePicker.SelectedDate.HasValue)
            {
                int index = -1;
                //if (datePicker == WkstpldtPicker) index = 0;
                if (datePicker == Wkstpldt1Picker) index = 1;
                else if (datePicker == WkfipldtPicker) index = 2;
                else if (datePicker == Wkfipldt1Picker) index = 3;
                else if (datePicker == ErectPldtPicker) index = 4;

                if (index != -1)
                {
                    // 날짜가 변경되었는지 확인
                    bool isModified = datePicker.SelectedDate.Value.Date != _originalDates[index].Date;
                    _dateModificationFlags[index] = isModified;

                    // 색상 설정
                    if (isModified)
                    {
                        if (datePicker == Wkstpldt1Picker)
                            datePicker.Foreground = Brushes.Red;
                        else if (datePicker == WkfipldtPicker || datePicker == ErectPldtPicker)
                            datePicker.Foreground = Brushes.Blue;
                        else
                            datePicker.Foreground = Brushes.Green;
                    }
                    else
                    {
                        datePicker.Foreground = Brushes.Black;
                    }
                }
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!ValidateDates())
                    return;

                // 날짜 저장
                //_schedule.WKSTPLDT = WkstpldtPicker.SelectedDate ?? DateTime.Now;
                _schedule.WKSTPLDT1 = Wkstpldt1Picker.SelectedDate ?? DateTime.Now;
                _schedule.WKFIPLDT = WkfipldtPicker.SelectedDate ?? DateTime.Now;
                _schedule.WKFIPLDT1 = Wkfipldt1Picker.SelectedDate ?? DateTime.Now;
                _schedule.ERECT_PLDT = ErectPldtPicker.SelectedDate ?? DateTime.Now;
                // 사업장 저장
                ComboBoxItem selectedItem = MfgIndComboBox.SelectedItem as ComboBoxItem;
                if (selectedItem != null)
                {
                    _schedule.MFG_IND = selectedItem.Content.ToString();
                    _schedule.IsMfgModified = selectedItem.Content.ToString() != _originalMfgInd; // 사업장 변경 플래그 설정
                }


                // 수정 상태 플래그 설정
                _schedule.IsWKSTPLDT1Modified = _dateModificationFlags[1];
                _schedule.IsWKFIPLDTModified = _dateModificationFlags[2];
                _schedule.IsERPLDTModified = _dateModificationFlags[4];

                // MonthlyDates 초기화
                _schedule.MonthlyDates = new ArrayList();

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "저장 중 오류가 발생했습니다: {ex.Message}",
                    "ERROR(오류)/저장실패"
                );
            }
        }

        private bool ValidateDates()
        {
            // 필수 입력 확인
            //if (!WkstpldtPicker.SelectedDate.HasValue ||
            if (!Wkstpldt1Picker.SelectedDate.HasValue ||
                !WkfipldtPicker.SelectedDate.HasValue ||
                !Wkfipldt1Picker.SelectedDate.HasValue ||
                !ErectPldtPicker.SelectedDate.HasValue)
            {
                MessageBox.Show("모든 날짜를 입력해주세요.", "INFO(정보)/입력확인");
                return false;
            }

            // 날짜 순서 검증
            if (Wkstpldt1Picker.SelectedDate > WkfipldtPicker.SelectedDate)
            {
                MessageBox.Show("시작계획일이 완료계획일보다 늦을 수 없습니다.", "INFO(정보)/날짜확인");
                return false;
            }

            if (WkfipldtPicker.SelectedDate > ErectPldtPicker.SelectedDate)
            {
                MessageBox.Show("완료계획일이 탑재계획일보다 늦을 수 없습니다.", "INFO(정보)/날짜확인");
                return false;
            }

            return true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}