﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Data;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;
using System.ComponentModel;
using System.Text;  // StringBuilder를 위한 using 추가
using System.Collections;  // ArrayList를 위한 using 추가
using System;
using System.Windows.Data;
using System.Windows.Media;
using System.Globalization;
using System.Threading.Tasks;  // Parallel을 위한 namespace
using System.Windows.Threading; // DispatcherPriority를 위한 namespace
using System.Windows.Input;
using System.IO;  // StreamReader, StreamWriter 사용을 위해
using Microsoft.Win32;  // SaveFileDialog, OpenFileDialog 사용을 위해
using System.ComponentModel;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data;
using System.Data.Common;

namespace ShipDataViewer
{
    public class ColoredDaysCountConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value != null)
            {
                int days;
                if (int.TryParse(value.ToString(), out days))
                {
                    return days < 0 ? System.Windows.Media.Brushes.Red : System.Windows.Media.Brushes.Black;
                }
            }
            return System.Windows.Media.Brushes.Black;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
    public class SavedPeState
    {
        public DateTime SaveTime { get; set; }
        public bool IsSunPeChecked { get; set; }
        public bool IsSunPe1Checked { get; set; }
        public bool IsPe1Checked { get; set; }
        public bool IsPe1_1Checked { get; set; }
        public bool IsPe2Checked { get; set; }
        public bool IsPe2_1Checked { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string SelectedMfg { get; set; }
        public string SelectedPe { get; set; }
        public string SelectedPeEqp { get; set; }
        public string SelectedStage { get; set; }
        public string SelectedPeType { get; set; }
        public List<ShipSchedule> ScheduleData { get; set; }
    }

    public class PeCheckBoxState
    {
        public bool IsSunPeChecked { get; set; }
        public bool IsPe1Checked { get; set; }
        public bool IsPe2Checked { get; set; }
        public bool IsSunPe1Checked { get; set; }
        public bool IsPe1_1Checked { get; set; }
        public bool IsPe2_1Checked { get; set; }
    }

    public partial class MainWindow : Window
    {
        private List<ShipSchedule> allData;
        public bool IsColorChangeEnabled { get; set; }

        private Dictionary<string, DateTime> _originalDates;
        private bool _isScheduleLocked;

        private bool isLineLoadGraphLoaded = false;

        public MainWindow()
        {
            InitializeComponent();
            // 버튼 초기 상태 설정
            //PeApplyButton.IsEnabled = false;
            PeApplyButton.IsEnabled = true;
            PeApplyButton.ToolTip = "MAX 부하 그래프 화면을 먼저 실행해주세요.";

            _originalDates = new Dictionary<string, DateTime>();
            _isScheduleLocked = false;


            MfgComboBox.SelectedIndex = 0;
            PeComboBox.SelectedIndex = 0;
            PeEqpBox.SelectedIndex = 0;
            PeTypeComboBox.SelectedIndex = 0;  // 추가
            // 새로운 이벤트 핸들러 추가
            //LoadData();
            //ShipDataGrid.MouseLeftButtonDown += new System.Windows.Input.MouseButtonEventHandler(ShipDataGrid_MouseLeftButtonDown);
            //ShipDataGrid.MouseRightButtonDown += new System.Windows.Input.MouseButtonEventHandler(ShipDataGrid_MouseRightButtonDown); // 이 줄 추가
            //ShipDataGrid.MouseLeftButtonDown += new System.Windows.Input.MouseButtonEventHandler(ShipDataGrid_MouseLeftButtonDown);
            ShipDataGrid.MouseDoubleClick += new System.Windows.Input.MouseButtonEventHandler(ShipDataGrid_MouseDoubleClick);
            ShipDataGrid.MouseRightButtonDown += new MouseButtonEventHandler(ShipDataGrid_RightClick);
            // Ctrl+더블클릭 이벤트 핸들러 추가
            ShipDataGrid.PreviewMouseDoubleClick += new System.Windows.Input.MouseButtonEventHandler(ShipDataGrid_CtrlDoubleClick);
            // Pe2CheckBox 비활성화 추가
            //Pe2CheckBox.IsEnabled = false;
            // 초기에 모든 컨트롤 비활성화 (LoadData 후 활성화됨)
            EnableControls(false);
            InitializeSorting();  // 이 줄 추가
            // 파일 메뉴 항목들은 항상 활성화
            ResetButton.IsEnabled = true;
            MfgComboBox.SelectionChanged += new SelectionChangedEventHandler(MfgComboBox_SelectionChanged);
            //EnableControls(false);
            Loaded += (s, e) => InitializeScrollSync();
            KeyDown += MainWindow_KeyDown;
            IsColorChangeEnabled = true;
        }
        public void LockScheduleEditing()
        {
            try
            {
                _isScheduleLocked = true;
                SaveOriginalDates();

                // DataGrid 컬럼들의 읽기 전용 상태 설정
                foreach (var column in ShipDataGrid.Columns)
                {
                    DataGridTextColumn textColumn = column as DataGridTextColumn;
                    if (textColumn != null)
                    {
                        Binding binding = textColumn.Binding as Binding;
                        if (binding != null)
                        {
                            string path = binding.Path.Path;
                            if (path == "WKSTPLDT1" || path == "WKFIPLDT" || path == "ERECT_PLDT")
                            {
                                textColumn.IsReadOnly = true;
                            }
                        }
                    }
                }

                // 초기 데이터로 복원
                RestoreOriginalDates();
            }
            catch (Exception ex)
            {
                MessageBox.Show("일정 잠금 처리 중 오류가 발생했습니다: " + ex.Message);
            }
        }

        public void UnlockScheduleEditing()
        {
            try
            {
                _isScheduleLocked = false;

                // DataGrid 컬럼들의 읽기 전용 상태 해제
                foreach (var column in ShipDataGrid.Columns)
                {
                    DataGridTextColumn textColumn = column as DataGridTextColumn;
                    if (textColumn != null)
                    {
                        Binding binding = textColumn.Binding as Binding;
                        if (binding != null)
                        {
                            string path = binding.Path.Path;
                            if (path == "WKSTPLDT1" || path == "WKFIPLDT" || path == "ERECT_PLDT")
                            {
                                textColumn.IsReadOnly = false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("일정 잠금 해제 중 오류가 발생했습니다: " + ex.Message);
            }
        }

        private void SaveOriginalDates()
        {
            try
            {
                _originalDates.Clear();
                var items = ShipDataGrid.ItemsSource as List<ShipSchedule>;

                if (items != null)
                {
                    foreach (ShipSchedule schedule in items)
                    {
                        if (schedule != null)
                        {
                            string key = string.Format("{0}_{1}_{2}",
                                schedule.SHIP_DISP,
                                schedule.BLOCK,
                                schedule.STG_CD);

                            _originalDates[key + "_WKSTPLDT1"] = schedule.WKSTPLDT1;
                            _originalDates[key + "_WKFIPLDT"] = schedule.WKFIPLDT;
                            _originalDates[key + "_ERECT_PLDT"] = schedule.ERECT_PLDT;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("원본 일정 저장 중 오류가 발생했습니다: " + ex.Message);
            }
        }

        private void RestoreOriginalDates()
        {
            try
            {
                var items = ShipDataGrid.ItemsSource as List<ShipSchedule>;
                if (items != null)
                {
                    foreach (ShipSchedule schedule in items)
                    {
                        if (schedule != null)
                        {
                            string key = string.Format("{0}_{1}_{2}",
                                schedule.SHIP_DISP,
                                schedule.BLOCK,
                                schedule.STG_CD);

                            if (_originalDates.ContainsKey(key + "_WKSTPLDT1"))
                                schedule.WKSTPLDT1 = _originalDates[key + "_WKSTPLDT1"];

                            if (_originalDates.ContainsKey(key + "_WKFIPLDT"))
                                schedule.WKFIPLDT = _originalDates[key + "_WKFIPLDT"];

                            if (_originalDates.ContainsKey(key + "_ERECT_PLDT"))
                                schedule.ERECT_PLDT = _originalDates[key + "_ERECT_PLDT"];
                        }
                    }
                }

                // UI 갱신
                ShipDataGrid.Items.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("원본 일정 복원 중 오류가 발생했습니다: " + ex.Message);
            }
        }
        public class DataAccessService
        {
            private readonly Database _database;

            public DataAccessService()
            {
                // DatabaseFactory에서 설정 파일을 읽어 DevShipDbOracle 연결 설정을 가져옵니다.
                //_database = DatabaseFactory.CreateDatabase("DevShipDbOracle");//개발
                _database = DatabaseFactory.CreateDatabase("DevShipDbOracleOp");//운영
            }

            public DataTable GetCranePeData(string selDateDiv, string startDate, string endDate, string shipNo)
            {
                StringBuilder query = new StringBuilder();
                query.Append(@"
                SELECT
                    B1.S_KIND,
                    B1.S_TYPE,
                    B1.OWNER,
                    B1.SHIP_DISP,
                    B1.BLOCK,
                    B1.STG_CD,
                    MAX(B1.S_NAME) AS S_NAME,
                    CASE WHEN B1.STG_CD IN ('41', '42') 
                         THEN F_GET_MFG_IND_NM(MAX(B1.JO_MFG_IND)) 
                         ELSE MAX(CASE WHEN B6.MFG_DESC IN ('본사', '온산', '해양') THEN B6.MFG_DESC END)
                    END AS MFG_IND,
                    MAX(TO_CHAR(B1.WKSTPLDT,'YYYY/MM/DD')) AS WKSTPLDT,
                    MAX(TO_CHAR(B1.WKFIPLDT,'YYYY/MM/DD')) AS WKFIPLDT,
                    MAX(TO_CHAR(B1.ERECT_PLDT,'YYYY/MM/DD')) AS ERECT_PLDT,
                    MAX(TO_CHAR(B1.WKSTDT_PP,'YYYY/MM/DD')) AS WKSTDT_PP,
                    MAX(TO_CHAR(B1.WKFIDT_PP,'YYYY/MM/DD')) AS WKFIDT_PP,
                    MAX(B1.PE_TOOLS) AS PE_TOOLS,
                    MIN(B8.LOC_DESC) AS LOC_DESC,
                    MAX(B1.DUR) AS DUR
                FROM (
                    SELECT AA1.*,
                           F_GET_NET_DUR_CASE(AA1.CASE_NO, AA1.WKSTPLDT, AA1.WKFIPLDT) AS DUR
                    FROM (
                        SELECT A2.CASE_NO, A1.S_KIND, A1.S_TYPE, A1.OWNER, A1.SHIP_DISP,
                               A2.BLOCK,
                               A2.STG_CD,
                               MIN(A14.PE_TOOLS) PE_TOOLS,
                               MIN(A14.PE_LOC_CODE) PE_LOC_CODE,
                               MIN(DECODE(SUBSTR(A2.STG_CD,1,1), '4', F_GET_JO_WKSTPLDT_CASE(A2.CASE_NO,A2.SHIP_NO, A2.BLOCK),A2.WKSTPLDT)) WKSTPLDT,
                               MAX(DECODE(SUBSTR(A2.STG_CD,1,1), '4', A11.WKFIPLDT, A2.WKFIPLDT)) WKFIPLDT,
                               MIN(A8.WKSTPLDT) AS ERECT_PLDT,
                               MIN(A3.WKSTDT_PP) WKSTDT_PP,
                               MIN(A3.WKFIDT_PP) WKFIDT_PP,
                               MIN(A2.MFG_IND) MFG_IND,
                               MIN(A11.MFG_IND) AS JO_MFG_IND,
                               MIN(CASE WHEN TRIM(A5.B_TYPE) IS NOT NULL THEN A4.S_NAME || '/' || A5.B_TYPE ELSE A4.S_NAME END) S_NAME,
                               MIN(DECODE(SUBSTR(A2.STG_CD,1,1), '4', A11.WKVOL_YN, A2.WKVOL_YN)) AS WKVOL_YN
                        FROM PTB_CASE_SHIP_BASIC A1
                        JOIN PTB_CASE_BEF_MACT_REV A2 ON A1.CASE_NO = A2.CASE_NO AND A1.SHIP_NO = A2.SHIP_NO
                        LEFT JOIN PTB_SHIP_MACT A3 ON A2.SHIP_NO = A3.SHIP_NO AND A2.M_ACT = A3.M_ACT AND A3.USE_YN = 'Y'
                        LEFT JOIN PTB_STD_BLK_SAREA A4 ON A2.BLK_SGBN = A4.S_CODE
                        LEFT JOIN PTB_CASE_DTB_BLK_REV A5 ON A2.SHIP_NO = A5.SHIP_NO AND (A2.BLOCK = A5.ERECT_BLK OR A2.BLOCK = A5.PRE_PE OR A2.BLOCK = A5.P1_BLK OR A2.BLOCK = A5.BLOCK)
                        LEFT JOIN PTB_CASE_BEF_MACT_REV A8 ON A2.SHIP_NO = A8.SHIP_NO AND A2.ERECT_BLK = A8.BLOCK AND A8.STG_CD = 'A0'
                        LEFT JOIN PTB_CASE_BEF_MACT_REV A11 ON A5.SHIP_NO = A11.SHIP_NO AND A5.BLOCK = A11.BLOCK AND A11.STG_CD IN ('41','42')
                        LEFT JOIN PTB_CASE_STG_LOAD_CRITERIA A14 ON A2.SHIP_NO = A14.SHIP_NO AND A2.BLOCK = A14.BLOCK AND A2.WK_KIND = A14.WK_KIND AND A2.STG_CD = A14.STG_CD
                        WHERE A1.CASE_NO = 'CASE_ING_HMD'
                        AND A2.CASE_NO = 'CASE_ING_HMD'
                        AND A5.CASE_NO = 'CASE_ING_HMD'
                        AND A8.CASE_NO = 'CASE_ING_HMD'
                        AND A11.CASE_NO = 'CASE_ING_HMD'
                        AND A2.STG_CD IN ('90', '80', '70')
                        AND A14.PE_TOOLS = 'C'
                        AND A2.").Append(selDateDiv == "착수" ? "WKSTPLDT" : "WKFIPLDT")
                                .Append(@" BETWEEN TO_DATE(:startDate,'YYYYMMDD') AND TO_DATE(:endDate,'YYYYMMDD')
                        AND A1.SHIP_NO LIKE :shipNo
                        AND A1.CONTRACT NOT IN ('D', 'C')
                        GROUP BY A2.CASE_NO, A1.S_KIND, A1.S_TYPE, A1.OWNER, A1.SHIP_DISP, A1.CONTRACT, A2.BLOCK, A2.STG_CD
                    ) AA1
                    WHERE AA1.WKVOL_YN LIKE 'Y'
                      AND AA1.MFG_IND IN (
                          SELECT MFG_IND 
                          FROM PTB_STD_MFGIND 
                          WHERE MFG_DESC IN ('본사', '온산', '해양')
                      )
                ) B1
                LEFT JOIN PTB_STD_MFGIND B6 ON B1.MFG_IND = B6.MFG_IND
                LEFT JOIN PTB_CRANE_PE_LOC_CODE B8 ON B1.PE_LOC_CODE = B8.LOC_CODE
                GROUP BY 
                    B1.S_KIND,
                    B1.S_TYPE,
                    B1.OWNER,
                    B1.SHIP_DISP,
                    B1.BLOCK,
                    B1.STG_CD
                ORDER BY 
                    B1.OWNER,
                    B1.SHIP_DISP,
                    B1.BLOCK,
                    B1.STG_CD");

                using (DbCommand dbCommand = _database.GetSqlStringCommand(query.ToString()))
                {
                    _database.AddInParameter(dbCommand, "startDate", DbType.String, startDate);
                    _database.AddInParameter(dbCommand, "endDate", DbType.String, endDate);
                    _database.AddInParameter(dbCommand, "shipNo", DbType.String, string.IsNullOrEmpty(shipNo) ? "%" : shipNo);

                    DataSet dataSet = _database.ExecuteDataSet(dbCommand);
                    return dataSet.Tables[0];
                }
            }
        }

        public void FilterSchedulesByDate(DateTime selectedDate)
        {
            if (allData == null || allData.Count == 0)
            {
                MessageBox.Show("데이터가 없습니다.", "알림");
                return;
            }

            // LINQ 대신 일반 리스트 필터링
            List<ShipSchedule> filteredData = new List<ShipSchedule>();
            foreach (ShipSchedule schedule in allData)
            {
                if (schedule.S_KIND != "LOAD 중일정개수" &&
                    schedule.S_KIND != "LOAD 조정결과개수")
                {
                    if ((schedule.WKSTPLDT1 <= selectedDate && schedule.WKFIPLDT1 >= selectedDate) ||
                        (schedule.WKSTPLDT <= selectedDate && schedule.WKFIPLDT >= selectedDate) ||
                        (schedule.ERECT_PLDT == selectedDate))
                    {
                        filteredData.Add(schedule);
                    }
                }
            }

            if (filteredData.Count == 0)
            {
                MessageBox.Show(string.Format("{0:yyyy-MM-dd}에 해당하는 스케줄이 없습니다.", selectedDate), "검색 결과");
                return;
            }

            // 검색 조건 초기화
            StartDatePicker.SelectedDate = selectedDate;
            EndDatePicker.SelectedDate = selectedDate;
            MfgComboBox.SelectedIndex = 0;
            PeComboBox.SelectedIndex = 0;
            PeEqpBox.SelectedIndex = 0;
            STAGEComboBox.SelectedIndex = 0;
            PeTypeComboBox.SelectedIndex = 0;

            // 필터링된 데이터로 화면 업데이트
            ProcessAndDisplayData(filteredData);

            // 검색 결과 메시지
            MessageBox.Show(
                string.Format("{0:yyyy-MM-dd}에 해당하는 스케줄 {1}건을 찾았습니다.",
                selectedDate, filteredData.Count),
                "검색 결과"
            );
        }
        //데이터 찾기기능
        private Window searchWindow;
        private int currentSearchIndex = -1;

        private void MainWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.F && (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)))
            {
                ShowSearchWindow();
                e.Handled = true;
            }
        }

        private void ShowSearchWindow()
        {
            if (searchWindow != null && searchWindow.IsVisible)
            {
                searchWindow.Focus();
                return;
            }

            // 검색 창 생성
            searchWindow = new Window
            {
                Title = "찾기",
                Width = 400,
                Height = 160,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                ResizeMode = ResizeMode.NoResize,
                Owner = this
            };

            var grid = new Grid { Margin = new Thickness(10) };
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // 검색어 입력
            var searchPanel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
            searchPanel.Children.Add(new Label { Content = "찾을 내용:" });
            var searchTextBox = new TextBox { Width = 200, Margin = new Thickness(5, 0, 0, 0) };
            searchPanel.Children.Add(searchTextBox);
            Grid.SetRow(searchPanel, 0);
            grid.Children.Add(searchPanel);

            // 검색 옵션
            var optionsPanel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
            var matchCaseCheckBox = new CheckBox { Content = "대/소문자 구분", Margin = new Thickness(5, 0, 0, 0) };
            optionsPanel.Children.Add(matchCaseCheckBox);
            Grid.SetRow(optionsPanel, 1);
            grid.Children.Add(optionsPanel);

            // 버튼 패널
            var buttonPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 10, 0, 0)
            };

            var findNextButton = new Button { Content = "다음 찾기", Width = 80, Margin = new Thickness(5, 0, 0, 0) };
            findNextButton.Click += (s, e) => FindNext(searchTextBox.Text, matchCaseCheckBox.IsChecked ?? false);

            var closeButton = new Button { Content = "닫기", Width = 80, Margin = new Thickness(5, 0, 0, 0) };
            closeButton.Click += (s, e) => searchWindow.Close();

            buttonPanel.Children.Add(findNextButton);
            buttonPanel.Children.Add(closeButton);
            Grid.SetRow(buttonPanel, 2);
            grid.Children.Add(buttonPanel);

            searchWindow.Content = grid;

            // Enter 키로 다음 찾기
            searchTextBox.KeyDown += (s, e) =>
            {
                if (e.Key == Key.Enter)
                    FindNext(searchTextBox.Text, matchCaseCheckBox.IsChecked ?? false);
            };

            // 검색 창이 닫힐 때 검색 인덱스 초기화
            searchWindow.Closed += (s, e) =>
            {
                currentSearchIndex = -1;
                searchWindow = null;
            };

            searchWindow.Show();
            searchTextBox.Focus();
        }

        private void FindNext(string searchText, bool matchCase)
        {
            if (string.IsNullOrWhiteSpace(searchText) || ShipDataGrid.ItemsSource == null)
                return;

            var items = ShipDataGrid.ItemsSource as List<ShipSchedule>;
            if (items == null || items.Count == 0)
                return;

            if (!matchCase)
                searchText = searchText.ToLower();

            bool found = false;
            for (int i = currentSearchIndex + 1; i < items.Count; i++)
            {
                if (IsMatch(items[i], searchText, matchCase))
                {
                    ShipDataGrid.SelectedItem = items[i];
                    ShipDataGrid.ScrollIntoView(items[i]);
                    currentSearchIndex = i;
                    found = true;
                    break;
                }
            }

            if (!found)
            {
                if (currentSearchIndex >= 0)
                {
                    // 처음부터 다시 검색
                    currentSearchIndex = -1;
                    FindNext(searchText, matchCase);
                }
                else
                {
                    MessageBox.Show(
                        "검색 결과가 없습니다.",
                        "검색 완료",
                        MessageBoxButton.OK,
                        MessageBoxImage.Information
                    );
                }
            }
        }

        private bool IsMatch(ShipSchedule schedule, string searchText, bool matchCase)
        {
            // 모든 검색 가능한 필드들을 포함하는 문자열 생성
            var searchableText = string.Format("{0} {1} {2} {3} {4} {5} {6} {7} {8} {9} {10}",
                schedule.S_KIND,
                schedule.S_TYPE,
                schedule.OWNER,
                schedule.SHIP_DISP,
                schedule.BLOCK,
                schedule.STG_CD,
                schedule.S_NAME,
                schedule.MFG_IND,
                schedule.LOC_DESC,
                schedule.LOC_EQP,
                schedule.PE_TYPE
            );

            if (!matchCase)
                searchableText = searchableText.ToLower();

            return searchableText.Contains(searchText);
        }

        private void InitializeSorting()
        {
            ShipDataGrid.Sorting += new DataGridSortingEventHandler(ShipDataGrid_Sorting);
        }
        private void ShipDataGrid_Sorting(object sender, DataGridSortingEventArgs e)
        {
            try
            {
                e.Handled = true;
                DataGridColumn column = e.Column;
                DataGridTextColumn textColumn = column as DataGridTextColumn;

                if (textColumn == null) return;

                // Get binding path
                Binding binding = textColumn.Binding as Binding;
                if (binding == null) return;
                string propertyName = binding.Path.Path;

                // Get current direction
                ListSortDirection direction;
                if (column.SortDirection == null)
                    direction = ListSortDirection.Ascending;
                else if (column.SortDirection == ListSortDirection.Ascending)
                    direction = ListSortDirection.Descending;
                else
                {
                    column.SortDirection = null;
                    return;
                }

                // Clear other columns
                foreach (DataGridColumn col in ShipDataGrid.Columns)
                {
                    if (col != column) col.SortDirection = null;
                }

                // Set new direction
                column.SortDirection = direction;

                // Get data
                List<ShipSchedule> items = ShipDataGrid.ItemsSource as List<ShipSchedule>;
                if (items == null) return;

                // Sort
                List<ShipSchedule> sortedItems = new List<ShipSchedule>(items);
                sortedItems.Sort(delegate(ShipSchedule x, ShipSchedule y)
                {
                    object xValue = GetPropertyValue(x, propertyName);
                    object yValue = GetPropertyValue(y, propertyName);

                    int result;
                    if (xValue == null && yValue == null)
                        result = 0;
                    else if (xValue == null)
                        result = -1;
                    else if (yValue == null)
                        result = 1;
                    else if (xValue is DateTime && yValue is DateTime)
                        result = ((DateTime)xValue).CompareTo((DateTime)yValue);
                    else
                        result = xValue.ToString().CompareTo(yValue.ToString());

                    return direction == ListSortDirection.Ascending ? result : -result;
                });

                ShipDataGrid.ItemsSource = sortedItems;
            }
            catch (Exception ex)
            {
                MessageBox.Show("정렬 중 오류가 발생했습니다: " + ex.Message, "ERROR(오류)/정렬실패");
            }
        }

        private object GetPropertyValue(ShipSchedule item, string propertyName)
        {
            try
            {
                System.Reflection.PropertyInfo prop = typeof(ShipSchedule).GetProperty(propertyName);
                if (prop == null) return null;
                return prop.GetValue(item, null);
            }
            catch
            {
                return null;
            }
        }
        private PeCheckBoxState _peState = new PeCheckBoxState();
        private bool _isUpdatingData = false;
        private double previousOffset = 0;
        private const double SCROLL_THRESHOLD = 1510; // 20cm를 픽셀로 변환 (약 200픽셀)

        private List<SavedPeState> savedStates = new List<SavedPeState>();


        //private void AdjustDataGridSizes(bool showShipDataGrid1)
        //{
        //    var rowDefinitions = MainGrid.RowDefinitions;

        //    if (showShipDataGrid1)
        //    {
        //        // ShipDataGrid와 ShipDataGrid1 모두 표시
        //        rowDefinitions[1].Height = new GridLength(1, GridUnitType.Star); // ShipDataGrid
        //        rowDefinitions[3].Height = new GridLength(1, GridUnitType.Star); // ShipDataGrid1
        //    }
        //    else
        //    {
        //        // ShipDataGrid1 숨기고 ShipDataGrid만 표시
        //        rowDefinitions[1].Height = new GridLength(1, GridUnitType.Star); // ShipDataGrid
        //        rowDefinitions[3].Height = new GridLength(0); // ShipDataGrid1
        //    }
        //}


        private void ShipDataGrid_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            AdjustDataGridSizes();
        }

        private void ShipDataGrid1_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            AdjustDataGridSizes();
        }

        private void AdjustDataGridSizes()
        {
            // ShipDataGrid1의 데이터 확인
            bool hasDataInShipDataGrid1 = ShipDataGrid1.ItemsSource != null &&
                                          ((System.Collections.IList)ShipDataGrid1.ItemsSource).Count > 0;

            if (hasDataInShipDataGrid1)
            {
                // ShipDataGrid와 ShipDataGrid1 모두 동일한 크기
                MainGrid.RowDefinitions[1].Height = new GridLength(1, GridUnitType.Star); // ShipDataGrid
                MainGrid.RowDefinitions[3].Height = new GridLength(1, GridUnitType.Star); // ShipDataGrid1
            }
            else
            {
                // ShipDataGrid만 표시
                MainGrid.RowDefinitions[1].Height = new GridLength(1, GridUnitType.Star); // ShipDataGrid
                MainGrid.RowDefinitions[3].Height = new GridLength(0); // ShipDataGrid1 숨김
            }
        }

        // MainWindow 클래스에 추가할 메서드들
        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var currentState = new SavedPeState();

                // 체크박스 상태 저장
                currentState.SaveTime = DateTime.Now;
                currentState.IsSunPeChecked = SunPeCheckBox.IsChecked.HasValue ? SunPeCheckBox.IsChecked.Value : false;
                currentState.IsSunPe1Checked = SunPeCheckBox1.IsChecked.HasValue ? SunPeCheckBox1.IsChecked.Value : false;
                currentState.IsPe1Checked = Pe1CheckBox.IsChecked.HasValue ? Pe1CheckBox.IsChecked.Value : false;
                currentState.IsPe1_1Checked = Pe1CheckBox1.IsChecked.HasValue ? Pe1CheckBox1.IsChecked.Value : false;
                currentState.IsPe2Checked = Pe2CheckBox.IsChecked.HasValue ? Pe2CheckBox.IsChecked.Value : false;
                currentState.IsPe2_1Checked = Pe2CheckBox1.IsChecked.HasValue ? Pe2CheckBox1.IsChecked.Value : false;

                // 날짜 저장
                currentState.StartDate = StartDatePicker.SelectedDate;
                currentState.EndDate = EndDatePicker.SelectedDate;

                // ComboBox 선택값 저장
                if (MfgComboBox.SelectedItem != null)
                {
                    ComboBoxItem mfgItem = MfgComboBox.SelectedItem as ComboBoxItem;
                    if (mfgItem != null && mfgItem.Content != null)
                    {
                        currentState.SelectedMfg = mfgItem.Content.ToString();
                    }
                }

                if (PeComboBox.SelectedItem != null)
                {
                    ComboBoxItem peItem = PeComboBox.SelectedItem as ComboBoxItem;
                    if (peItem != null && peItem.Content != null)
                    {
                        currentState.SelectedPe = peItem.Content.ToString();
                    }
                }

                if (PeEqpBox.SelectedItem != null)
                {
                    ComboBoxItem peEqpItem = PeEqpBox.SelectedItem as ComboBoxItem;
                    if (peEqpItem != null && peEqpItem.Content != null)
                    {
                        currentState.SelectedPeEqp = peEqpItem.Content.ToString();
                    }
                }

                if (STAGEComboBox.SelectedItem != null)
                {
                    ComboBoxItem stageItem = STAGEComboBox.SelectedItem as ComboBoxItem;
                    if (stageItem != null && stageItem.Content != null)
                    {
                        currentState.SelectedStage = stageItem.Content.ToString();
                    }
                }

                if (PeTypeComboBox.SelectedItem != null)
                {
                    ComboBoxItem peTypeItem = PeTypeComboBox.SelectedItem as ComboBoxItem;
                    if (peTypeItem != null && peTypeItem.Content != null)
                    {
                        currentState.SelectedPeType = peTypeItem.Content.ToString();
                    }
                }

                // 데이터 복사
                currentState.ScheduleData = new List<ShipSchedule>();
                if (ShipDataGrid.ItemsSource != null)
                {
                    foreach (ShipSchedule s in ShipDataGrid.ItemsSource)
                    {
                        if (s != null)
                        {
                            ShipSchedule newSchedule = new ShipSchedule();
                            newSchedule.S_KIND = s.S_KIND;
                            newSchedule.S_TYPE = s.S_TYPE;
                            newSchedule.OWNER = s.OWNER;
                            newSchedule.SHIP_DISP = s.SHIP_DISP;
                            newSchedule.BLOCK = s.BLOCK;
                            newSchedule.STG_CD = s.STG_CD;
                            newSchedule.S_NAME = s.S_NAME;
                            newSchedule.MFG_IND = s.MFG_IND;
                            newSchedule.LOC_DESC = s.LOC_DESC;
                            newSchedule.LOC_EQP = s.LOC_EQP;
                            newSchedule.PE_TYPE = s.PE_TYPE;
                            newSchedule.WKSTPLDT = s.WKSTPLDT;
                            newSchedule.WKSTPLDT1 = s.WKSTPLDT1;
                            newSchedule.WKFIPLDT = s.WKFIPLDT;
                            newSchedule.WKFIPLDT1 = s.WKFIPLDT1;
                            newSchedule.ERECT_PLDT = s.ERECT_PLDT;
                            newSchedule.IsSelected = s.IsSelected;
                            newSchedule.IsWKSTPLDT1Modified = s.IsWKSTPLDT1Modified;
                            newSchedule.IsWKFIPLDTModified = s.IsWKFIPLDTModified;
                            newSchedule.IsERPLDTModified = s.IsERPLDTModified;
                            newSchedule.MonthlyDates = s.MonthlyDates;

                            currentState.ScheduleData.Add(newSchedule);
                        }
                    }
                }

                if (savedStates == null)
                {
                    savedStates = new List<SavedPeState>();
                }

                savedStates.Add(currentState);

                MessageBox.Show(
                    string.Format("현재 상태가 저장되었습니다.\n저장 시각: {0:yyyy-MM-dd HH:mm:ss}",
                    currentState.SaveTime),
                    "INFO(정보)/상태저장");
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    string.Format("상태 저장 중 오류가 발생했습니다:\n{0}", ex.Message),
                    "ERROR(오류)/상태저장실패");
            }
        }
        private List<ShipSchedule> _multipleSchedules = new List<ShipSchedule>();

        //// 마우스 우클릭 이벤트 핸들러
        //private void ShipDataGrid_RightClick(object sender, MouseButtonEventArgs e)
        //{
        //    if (!isLineLoadGraphLoaded)
        //    {
        //        MessageBox.Show(
        //            "MAX 부하 그래프 화면을 먼저 실행해주세요.",
        //            "알림",
        //            MessageBoxButton.OK,
        //            MessageBoxImage.Information
        //        );
        //        return;
        //    }
        //    try
        //    {
        //        // Shift 키가 눌려있을 때만 처리
        //        if (!Keyboard.IsKeyDown(Key.LeftShift) && !Keyboard.IsKeyDown(Key.RightShift))
        //            return;

        //        e.Handled = true;



        //        // 선택된 아이템들 필터링 (LOAD 항목 제외)
        //        var selectedItems = new List<ShipSchedule>();
        //        foreach (var item in ShipDataGrid.SelectedItems)
        //        {
        //            var schedule = item as ShipSchedule;
        //            if (schedule != null &&
        //                schedule.S_KIND != "LOAD 중일정개수" &&
        //                schedule.S_KIND != "LOAD 조정 개수" &&
        //                schedule.S_KIND != "LOAD 조정결과개수")
        //            {
        //                selectedItems.Add(schedule);
        //            }
        //        }

        //        if (selectedItems.Count == 0)
        //            return;

        //        // 컨텍스트 메뉴 생성
        //        var contextMenu = new ContextMenu();

        //        // 복사 메뉴 아이템
        //        var copyMenuItem = new MenuItem();
        //        copyMenuItem.Header = string.Format("선택된 {0}개 행 복사", selectedItems.Count);
        //        copyMenuItem.Click += delegate(object s, RoutedEventArgs args)
        //        {
        //            _multipleSchedules.Clear();

        //            foreach (var schedule in selectedItems)
        //            {
        //                var copiedSchedule = new ShipSchedule
        //                {
        //                    S_KIND = schedule.S_KIND,
        //                    S_TYPE = schedule.S_TYPE,
        //                    OWNER = schedule.OWNER,
        //                    SHIP_DISP = schedule.SHIP_DISP,
        //                    BLOCK = schedule.BLOCK,
        //                    STG_CD = schedule.STG_CD,
        //                    S_NAME = schedule.S_NAME,
        //                    MFG_IND = schedule.MFG_IND,
        //                    LOC_DESC = schedule.LOC_DESC,
        //                    LOC_EQP = schedule.LOC_EQP,
        //                    PE_TYPE = schedule.PE_TYPE,
        //                    WKSTPLDT = schedule.WKSTPLDT,
        //                    WKSTPLDT1 = schedule.WKSTPLDT1,
        //                    WKFIPLDT = schedule.WKFIPLDT,
        //                    WKFIPLDT1 = schedule.WKFIPLDT1,
        //                    ERECT_PLDT = schedule.ERECT_PLDT,
        //                    Dur = schedule.Dur
        //                };
        //                _multipleSchedules.Add(copiedSchedule);
        //            }
        //            MessageBox.Show(string.Format("{0}개 행이 복사되었습니다.", selectedItems.Count), "복사 완료");
        //        };

        //        // 붙여넣기 메뉴 아이템
        //        var pasteMenuItem = new MenuItem();
        //        pasteMenuItem.Header = "붙여넣기";
        //        pasteMenuItem.IsEnabled = _multipleSchedules.Count > 0;
        //        pasteMenuItem.Click += delegate(object s, RoutedEventArgs args)
        //        {
        //            if (_multipleSchedules.Count == 0)
        //            {
        //                MessageBox.Show("붙여넣을 데이터가 없습니다.", "알림");
        //                return;
        //            }

        //            // 선택된 대상 행 가져오기
        //            var targetItems = new List<ShipSchedule>();
        //            foreach (var item in ShipDataGrid.SelectedItems)
        //            {
        //                var schedule = item as ShipSchedule;
        //                if (schedule != null &&
        //                    schedule.S_KIND != "LOAD 중일정개수" &&
        //                    schedule.S_KIND != "LOAD 조정 개수" &&
        //                    schedule.S_KIND != "LOAD 조정결과개수")
        //                {
        //                    targetItems.Add(schedule);
        //                }
        //            }

        //            if (targetItems.Count == 0)
        //            {
        //                MessageBox.Show("붙여넣을 대상을 선택해주세요.", "알림");
        //                return;
        //            }

        //            var count = Math.Min(targetItems.Count, _multipleSchedules.Count);

        //            // 붙여넣기 작업 수행
        //            for (int i = 0; i < count; i++)
        //            {
        //                var target = targetItems[i];
        //                var source = _multipleSchedules[i];

        //                target.S_KIND = source.S_KIND;
        //                target.S_TYPE = source.S_TYPE;
        //                target.OWNER = source.OWNER;
        //                target.SHIP_DISP = source.SHIP_DISP;
        //                target.BLOCK = source.BLOCK;
        //                target.STG_CD = source.STG_CD;
        //                target.S_NAME = source.S_NAME;
        //                target.MFG_IND = source.MFG_IND;
        //                target.LOC_DESC = source.LOC_DESC;
        //                target.LOC_EQP = source.LOC_EQP;
        //                target.PE_TYPE = source.PE_TYPE;
        //                target.WKSTPLDT = source.WKSTPLDT;
        //                target.WKSTPLDT1 = source.WKSTPLDT1;
        //                target.WKFIPLDT = source.WKFIPLDT;
        //                target.WKFIPLDT1 = source.WKFIPLDT1;
        //                target.ERECT_PLDT = source.ERECT_PLDT;
        //                target.Dur = source.Dur;
        //            }

        //            ProcessAndDisplayData(allData);
        //            MessageBox.Show(string.Format("{0}개 행이 붙여넣기 되었습니다.", count), "붙여넣기 완료");
        //        };

        //        // 삭제 메뉴 아이템
        //        var deleteMenuItem = new MenuItem();
        //        deleteMenuItem.Header = string.Format("선택된 {0}개 행 삭제", selectedItems.Count);
        //        deleteMenuItem.Click += delegate(object s, RoutedEventArgs args)
        //        {
        //            var result = MessageBox.Show(
        //                string.Format("선택된 {0}개 행을 삭제하시겠습니까?", selectedItems.Count),
        //                "삭제 확인",
        //                MessageBoxButton.YesNo,
        //                MessageBoxImage.Question
        //            );

        //            if (result == MessageBoxResult.Yes)
        //            {
        //                var items = ShipDataGrid.ItemsSource as List<ShipSchedule>;
        //                if (items != null)
        //                {
        //                    foreach (var item in selectedItems)
        //                    {
        //                        items.Remove(item);
        //                    }
        //                    allData = items;
        //                    ProcessAndDisplayData(items);
        //                    MessageBox.Show(string.Format("{0}개 행이 삭제되었습니다.", selectedItems.Count), "삭제 완료");
        //                }
        //            }
        //        };

        //        // 메뉴에 아이템 추가
        //        contextMenu.Items.Add(copyMenuItem);
        //        contextMenu.Items.Add(pasteMenuItem);
        //        contextMenu.Items.Add(new Separator());
        //        contextMenu.Items.Add(deleteMenuItem);

        //        // 메뉴 표시
        //        contextMenu.IsOpen = true;
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("작업 중 오류가 발생했습니다: " + ex.Message, "오류");
        //    }
        //}

        private void ShipDataGrid_RightClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                // 현재 클릭된 셀의 컬럼과 아이템 정보 가져오기
                var cell = UIHelpers.GetParent<DataGridCell>((DependencyObject)e.OriginalSource);
                if (cell == null) return;

                var column = cell.Column as DataGridTextColumn;

                // "MFG_IND(후)" 열을 클릭했는지 확인
                if (column != null && column.Header.ToString() == "사업장(MFG_IND후)")
                {
                    MessageBox.Show("해당 열은 수정할 수 없습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                // Shift 키가 눌려있는지 확인
                if (!Keyboard.IsKeyDown(Key.LeftShift) && !Keyboard.IsKeyDown(Key.RightShift))
                    return;

                e.Handled = true;

                // 나머지 컨텍스트 메뉴 로직
                var selectedItems = new List<ShipSchedule>();
                foreach (var item in ShipDataGrid.SelectedItems)
                {
                    var schedule = item as ShipSchedule;
                    if (schedule != null &&
                        schedule.S_KIND != "LOAD 중일정개수" &&
                        schedule.S_KIND != "LOAD 조정 개수" &&
                        schedule.S_KIND != "LOAD 조정결과개수")
                    {
                        selectedItems.Add(schedule);
                    }
                }

                if (selectedItems.Count == 0) return;

                // 컨텍스트 메뉴 생성
                var contextMenu = new ContextMenu();

                // 복사 메뉴 아이템
                var copyMenuItem = new MenuItem
                {
                    Header = string.Format("선택된 {0}개 행 복사", selectedItems.Count)
                };
                copyMenuItem.Click += delegate(object s, RoutedEventArgs args)
                {
                    _multipleSchedules.Clear();
                    foreach (var schedule in selectedItems)
                    {
                        var copiedSchedule = new ShipSchedule
                        {
                            S_KIND = schedule.S_KIND,
                            S_TYPE = schedule.S_TYPE,
                            OWNER = schedule.OWNER,
                            SHIP_DISP = schedule.SHIP_DISP,
                            BLOCK = schedule.BLOCK,
                            STG_CD = schedule.STG_CD,
                            S_NAME = schedule.S_NAME,
                            MFG_IND = schedule.MFG_IND,
                            MFG_IND_After = schedule.MFG_IND,
                            LOC_DESC = schedule.LOC_DESC,
                            LOC_EQP = schedule.LOC_EQP,
                            PE_TYPE = schedule.PE_TYPE,
                            WKSTPLDT = schedule.WKSTPLDT,
                            WKSTPLDT1 = schedule.WKSTPLDT1,
                            WKFIPLDT = schedule.WKFIPLDT,
                            WKFIPLDT1 = schedule.WKFIPLDT1,
                            ERECT_PLDT = schedule.ERECT_PLDT,
                            Dur = schedule.Dur
                        };
                        _multipleSchedules.Add(copiedSchedule);
                    }
                    MessageBox.Show(string.Format("{0}개 행이 복사되었습니다.", selectedItems.Count), "복사 완료");
                };

                // 붙여넣기 메뉴 아이템
                var pasteMenuItem = new MenuItem
                {
                    Header = "붙여넣기",
                    IsEnabled = _multipleSchedules.Count > 0
                };
                pasteMenuItem.Click += delegate(object s, RoutedEventArgs args)
                {
                    if (_multipleSchedules.Count == 0)
                    {
                        MessageBox.Show("붙여넣을 데이터가 없습니다.", "알림");
                        return;
                    }

                    var targetItems = new List<ShipSchedule>();
                    foreach (var item in ShipDataGrid.SelectedItems)
                    {
                        var schedule = item as ShipSchedule;
                        if (schedule != null &&
                            schedule.S_KIND != "LOAD 중일정개수" &&
                            schedule.S_KIND != "LOAD 조정 개수" &&
                            schedule.S_KIND != "LOAD 조정결과개수")
                        {
                            targetItems.Add(schedule);
                        }
                    }

                    if (targetItems.Count == 0)
                    {
                        MessageBox.Show("붙여넣을 대상을 선택해주세요.", "알림");
                        return;
                    }

                    var count = Math.Min(targetItems.Count, _multipleSchedules.Count);

                    for (int i = 0; i < count; i++)
                    {
                        var target = targetItems[i];
                        var source = _multipleSchedules[i];

                        target.S_KIND = source.S_KIND;
                        target.S_TYPE = source.S_TYPE;
                        target.OWNER = source.OWNER;
                        target.SHIP_DISP = source.SHIP_DISP;
                        target.BLOCK = source.BLOCK;
                        target.STG_CD = source.STG_CD;
                        target.S_NAME = source.S_NAME;
                        target.MFG_IND = source.MFG_IND;
                        target.LOC_DESC = source.LOC_DESC;
                        target.LOC_EQP = source.LOC_EQP;
                        target.PE_TYPE = source.PE_TYPE;
                        target.WKSTPLDT = source.WKSTPLDT;
                        target.WKSTPLDT1 = source.WKSTPLDT1;
                        target.WKFIPLDT = source.WKFIPLDT;
                        target.WKFIPLDT1 = source.WKFIPLDT1;
                        target.ERECT_PLDT = source.ERECT_PLDT;
                        target.Dur = source.Dur;
                    }

                    ProcessAndDisplayData(allData);
                    MessageBox.Show(string.Format("{0}개 행이 붙여넣기 되었습니다.", count), "붙여넣기 완료");
                };

                // 삭제 메뉴 아이템
                var deleteMenuItem = new MenuItem
                {
                    Header = string.Format("선택된 {0}개 행 삭제", selectedItems.Count)
                };
                deleteMenuItem.Click += delegate(object s, RoutedEventArgs args)
                {
                    var result = MessageBox.Show(
                        string.Format("선택된 {0}개 행을 삭제하시겠습니까?", selectedItems.Count),
                        "삭제 확인",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question
                    );

                    if (result == MessageBoxResult.Yes)
                    {
                        var items = ShipDataGrid.ItemsSource as List<ShipSchedule>;
                        if (items != null)
                        {
                            foreach (var item in selectedItems)
                            {
                                items.Remove(item);
                            }
                            allData = items;
                            ProcessAndDisplayData(items);
                            MessageBox.Show(string.Format("{0}개 행이 삭제되었습니다.", selectedItems.Count), "삭제 완료");
                        }
                    }
                };

                contextMenu.Items.Add(copyMenuItem);
                contextMenu.Items.Add(pasteMenuItem);
                contextMenu.Items.Add(new Separator());
                contextMenu.Items.Add(deleteMenuItem);

                contextMenu.IsOpen = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("작업 중 오류가 발생했습니다: " + ex.Message, "오류");
            }
        }

        public class SavedPeState
        {
            public DateTime SaveTime { get; set; }
            public bool IsSunPeChecked { get; set; }
            public bool IsSunPe1Checked { get; set; }
            public bool IsPe1Checked { get; set; }
            public bool IsPe1_1Checked { get; set; }
            public bool IsPe2Checked { get; set; }
            public bool IsPe2_1Checked { get; set; }
            public DateTime? StartDate { get; set; }
            public DateTime? EndDate { get; set; }
            public string SelectedMfg { get; set; }
            public string SelectedPe { get; set; }
            public string SelectedPeEqp { get; set; }
            public string SelectedStage { get; set; }
            public string SelectedPeType { get; set; }
            public List<ShipSchedule> ScheduleData { get; set; }
        }
        private void SaveStateToFile_Click(object sender, RoutedEventArgs e)
        {
            // "일반" 체크박스가 선택되어 있지 않으면 저장하지 않음
            if (GeneralCheckBox.IsChecked != true)
            {
                MessageBox.Show("외장 저장은 '일반' 모드에서만 가능합니다.\n일반 모드로 전환 후 다시 시도해주세요.",
                    "저장 불가",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
                return;
            }
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "Text files (*.txt)|*.txt";
                saveFileDialog.DefaultExt = "txt";
                string fileName = string.Format("ShipSchedule_State_{0}.txt",
                    DateTime.Now.ToString("yyyyMMdd_HHmmss"));
                saveFileDialog.FileName = fileName;

                if (saveFileDialog.ShowDialog() == true)
                {
                    StreamWriter writer = new StreamWriter(saveFileDialog.FileName);

                    // 저장 시각
                    writer.WriteLine(DateTime.Now.ToString());

                    // 체크박스 상태
                    writer.WriteLine(SunPeCheckBox.IsChecked.HasValue ? SunPeCheckBox.IsChecked.Value.ToString() : "False");
                    writer.WriteLine(SunPeCheckBox1.IsChecked.HasValue ? SunPeCheckBox1.IsChecked.Value.ToString() : "False");
                    writer.WriteLine(Pe1CheckBox.IsChecked.HasValue ? Pe1CheckBox.IsChecked.Value.ToString() : "False");
                    writer.WriteLine(Pe1CheckBox1.IsChecked.HasValue ? Pe1CheckBox1.IsChecked.Value.ToString() : "False");
                    writer.WriteLine(Pe2CheckBox.IsChecked.HasValue ? Pe2CheckBox.IsChecked.Value.ToString() : "False");
                    writer.WriteLine(Pe2CheckBox1.IsChecked.HasValue ? Pe2CheckBox1.IsChecked.Value.ToString() : "False");

                    // 날짜
                    writer.WriteLine(StartDatePicker.SelectedDate.HasValue ?
                        StartDatePicker.SelectedDate.Value.ToString("yyyy-MM-dd") : "");
                    writer.WriteLine(EndDatePicker.SelectedDate.HasValue ?
                        EndDatePicker.SelectedDate.Value.ToString("yyyy-MM-dd") : "");

                    // ComboBox 선택값
                    ComboBoxItem mfgItem = MfgComboBox.SelectedItem as ComboBoxItem;
                    writer.WriteLine(mfgItem != null ? mfgItem.Content.ToString() : "");

                    ComboBoxItem peItem = PeComboBox.SelectedItem as ComboBoxItem;
                    writer.WriteLine(peItem != null ? peItem.Content.ToString() : "");

                    ComboBoxItem peEqpItem = PeEqpBox.SelectedItem as ComboBoxItem;
                    writer.WriteLine(peEqpItem != null ? peEqpItem.Content.ToString() : "");

                    ComboBoxItem stageItem = STAGEComboBox.SelectedItem as ComboBoxItem;
                    writer.WriteLine(stageItem != null ? stageItem.Content.ToString() : "");

                    ComboBoxItem peTypeItem = PeTypeComboBox.SelectedItem as ComboBoxItem;
                    writer.WriteLine(peTypeItem != null ? peTypeItem.Content.ToString() : "");

                    // 데이터 저장
                    if (ShipDataGrid.ItemsSource != null)
                    {
                        foreach (ShipSchedule s in ShipDataGrid.ItemsSource)
                        {
                            if (s != null)
                            {
                                StringBuilder line = new StringBuilder();
                                // 기본 데이터 저장
                                line.AppendFormat("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t{9}\t{10}\t{11}\t{12}\t{13}\t{14}\t{15}\t{16}\t{17}\t{18}\t{19}\t{20}\t{21}",
                                    s.S_KIND,
                                    s.S_TYPE,
                                    s.OWNER,
                                    s.SHIP_DISP,
                                    s.BLOCK,
                                    s.STG_CD,
                                    s.S_NAME,
                                    s.MFG_IND,
                                    s.MFG_IND_After,
                                    s.LOC_DESC,
                                    s.LOC_EQP,
                                    s.Dur,
                                    s.PE_TYPE,
                                    s.WKSTPLDT.ToString("yyyy-MM-dd"),
                                    s.WKSTPLDT1.ToString("yyyy-MM-dd"),
                                    s.WKFIPLDT.ToString("yyyy-MM-dd"),
                                    s.WKFIPLDT1.ToString("yyyy-MM-dd"),
                                    s.ERECT_PLDT.ToString("yyyy-MM-dd"),
                                    s.IsSelected.ToString(),
                                    s.IsWKSTPLDT1Modified.ToString(),
                                    s.IsWKFIPLDTModified.ToString(),
                                    s.IsERPLDTModified.ToString());

                                // MonthlyDates 색상 정보 저장
                                if (s.MonthlyDates != null)
                                {
                                    line.Append("\t");
                                    foreach (List<DateCell> monthDates in s.MonthlyDates)
                                    {
                                        if (monthDates != null)
                                        {
                                            foreach (DateCell cell in monthDates)
                                            {
                                                // Orange = 1, Crimson = 2, White = 0으로 저장
                                                if (cell.Color == Brushes.Orange)
                                                    line.Append("1");
                                                else if (cell.Color == Brushes.Crimson)
                                                    line.Append("2");
                                                else
                                                    line.Append("0");
                                            }
                                        }
                                        line.Append("|"); // 월 구분자
                                    }
                                }

                                writer.WriteLine(line.ToString());
                            }
                        }
                    }

                    writer.Close();

                    MessageBox.Show(
                        string.Format("현재 상태가 파일로 저장되었습니다.\n저장 시각: {0}\n파일 경로: {1}",
                        DateTime.Now.ToString(),
                        saveFileDialog.FileName),
                        "INFO(정보)/상태저장");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    string.Format("상태 저장 중 오류가 발생했습니다:\n{0}", ex.Message),
                    "ERROR(오류)/상태저장실패");
            }
        }
        //워킹데이 쉬는날
        public Dictionary<string, string> holidays = new Dictionary<string, string>
        {
            // 2024년 공휴일
            {"2024-01-01", "신정"},
            {"2024-01-02", "신정연휴"},
            {"2024-02-09", "설날연휴"},
            {"2024-02-10", "설날"},
            {"2024-02-11", "설날연휴"},
            {"2024-02-12", "설날연휴"},
            {"2024-02-13", "휴일중복"},
            {"2024-03-01", "삼일절"},
            {"2024-04-10", "국회의원 선거"},
            {"2024-05-01", "근로자의날"},
            {"2024-05-05", "어린이날"},
            {"2024-05-06", "대체공휴일"},
            {"2024-05-15", "석가탄신일"},
            {"2024-06-06", "현충일"},
            {"2024-07-15", "노조창립일"},
            {"2024-07-29", "하기휴가"},
            {"2024-07-30", "하기휴가"},
            {"2024-07-31", "하기휴가"},
            {"2024-08-01", "하기휴가"},
            {"2024-08-02", "하기휴가"},
            {"2024-08-05", "하기휴가"},
            {"2024-08-06", "하기휴가"},
            {"2024-08-07", "하기휴가"},
            {"2024-08-08", "하기휴가"},
            {"2024-08-15", "광복절"},
            {"2024-09-16", "추석연휴"},
            {"2024-09-17", "추석"},
            {"2024-09-18", "추석연휴"},
            {"2024-09-19", "추석연휴"},
            {"2024-10-01", "창립기념일"},
            {"2024-10-03", "개천절"},
            {"2024-10-09", "한글날"},
            {"2024-12-25", "성탄절"},

            // 2025년 공휴일
            {"2025-01-01", "신정"},
            {"2025-01-02", "신정연휴"},
            {"2025-01-27", "임시공휴일"},
            {"2025-01-28", "설날연휴"},
            {"2025-01-29", "설날"},
            {"2025-01-30", "설날연휴"},
            {"2025-01-31", "설날연휴"},
            {"2025-03-01", "삼일절"},
            {"2025-03-03", "대체공휴일"},
            {"2025-05-01", "근로자의날"},
            {"2025-05-05", "어린이날,석가탄신"},
            {"2025-05-06", "대체공휴일"},
            {"2025-06-06", "현충일"},
            {"2025-07-15", "노조창립기념일"},
            {"2025-08-04", "하기휴가"},
            {"2025-08-05", "하기휴가"},
            {"2025-08-06", "하기휴가"},
            {"2025-08-07", "하기휴가"},
            {"2025-08-08", "하기휴가"},
            {"2025-08-11", "하기휴가"},
            {"2025-08-12", "하기휴가"},
            {"2025-08-13", "하기휴가"},
            {"2025-08-14", "하기휴가"},
            {"2025-08-15", "광복절"},
            {"2025-10-01", "창립기념일"},
            {"2025-10-03", "개천절"},
            {"2025-10-05", "추석연휴"},
            {"2025-10-06", "추석"},
            {"2025-10-07", "추석연휴"},
            {"2025-10-08", "추석연휴"},
            {"2025-10-09", "한글날"},
            {"2025-12-25", "성탄절"},

            // 2026년 공휴일
            {"2026-01-01", "신정"},
            {"2026-01-02", "신정연휴"},
            {"2026-02-16", "설연휴"},
            {"2026-02-17", "설날"},
            {"2026-02-18", "설연휴"},
            {"2026-02-19", "설연휴"},
            {"2026-03-01", "삼일절"},
            {"2026-03-02", "대체공휴일"},
            {"2026-05-01", "근로자의 날"},
            {"2026-05-05", "어린이 날"},
            {"2026-05-24", "석가탄신일"},
            {"2026-05-25", "대체공휴일"},
            {"2026-06-06", "현충일"},
            {"2026-07-15", "노조창립일"},
            {"2026-08-03", "하기휴가"},
            {"2026-08-04", "하기휴가"},
            {"2026-08-05", "하기휴가"},
            {"2026-08-06", "하기휴가"},
            {"2026-08-07", "하기휴가"},
            {"2026-08-10", "하기휴가"},
            {"2026-08-11", "하기휴가"},
            {"2026-08-12", "하기휴가"},
            {"2026-08-13", "하기휴가"},
            {"2026-08-15", "광복절"},
            {"2026-08-17", "대체공휴일"},
            {"2026-09-24", "추석연휴"},
            {"2026-09-25", "추석"},
            {"2026-09-26", "추석연휴"},
            {"2026-09-28", "대체공휴일"},
            {"2026-10-01", "창립기념일"},
            {"2026-10-03", "개천절"},
            {"2026-10-05", "대체공휴일"},
            {"2026-10-09", "한글날"},
            {"2026-12-25", "성탄절"},

            // 2027년 공휴일
            {"2027-01-01", "신정"},
            {"2027-01-02", "신정연휴"},
            {"2027-02-06", "설날연휴"},
            {"2027-02-08", "설날연휴"},
            {"2027-02-09", "설날연휴"},
            {"2027-02-10", "중복휴무"},
            {"2027-03-01", "삼일절"},
            {"2027-03-03", "21대 대선"},
            {"2027-05-01", "근로자의날"},
            {"2027-05-05", "어린이날"},
            {"2027-05-13", "석가탄신일"},
            {"2027-07-15", "노조창립기념일"},
            {"2027-08-02", "하기휴가"},
            {"2027-08-03", "하기휴가"},
            {"2027-08-04", "하기휴가"},
            {"2027-08-05", "하기휴가"},
            {"2027-08-06", "하기휴가"},
            {"2027-08-09", "하기휴가"},
            {"2027-08-10", "하기휴가"},
            {"2027-08-11", "하기휴가"},
            {"2027-08-12", "하기휴가"},
            {"2027-08-15", "광복절"},
            {"2027-08-16", "대체공휴일"},
            {"2027-09-14", "추석연휴"},
            {"2027-09-15", "추석"},
            {"2027-09-16", "추석연휴"},
            {"2027-09-17", "추석연휴"},
            {"2027-10-01", "창사기념일"},
            {"2027-10-03", "개천절"},
            {"2027-10-04", "대체공휴일"},
            {"2027-10-09", "한글날"},
            {"2027-10-11", "대체공휴일"},
            {"2027-12-25", "성탄절"},
            {"2027-12-27", "대체공휴일"},

            // 2028년 공휴일
            {"2028-01-01", "신정"},
            {"2028-01-02", "신정연휴"},
            {"2028-01-26", "설날연휴"},
            {"2028-01-27", "설날"},
            {"2028-01-28", "설날연휴"},
            {"2028-01-31", "중복휴무"},
            {"2028-03-01", "삼일절"},
            {"2028-04-12", "23대 총선"},
            {"2028-05-02", "석가탄신일"},
            {"2028-05-05", "어린이날"},
            {"2028-06-06", "현충일"},
            {"2028-07-31", "하기휴가"},
            {"2028-08-01", "하기휴가"},
            {"2028-08-02", "하기휴가"},
            {"2028-08-03", "하기휴가"},
            {"2028-08-04", "하기휴가"},
            {"2028-08-07", "하기휴가"},
            {"2028-08-08", "하기휴가"},
            {"2028-08-09", "하기휴가"},
            {"2028-08-10", "하기휴가"},
            {"2028-08-15", "광복절"},
            {"2028-10-02", "추석연휴"},
            {"2028-10-03", "추석"},
            {"2028-10-04", "추석연휴"},
            {"2028-10-05", "추석연휴"},
            {"2028-10-09", "한글날"},
            {"2028-12-25", "성탄절"}
        };
        //private bool IsWorkingDay(DateTime date)
        //{
        //    // 주말 체크 (토요일 = 6, 일요일 = 0)
        //    if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday)
        //        return false;

        //    // 공휴일 체크
        //    string dateKey = date.ToString("yyyy-MM-dd");
        //    return !holidays.ContainsKey(dateKey);
        //}

        public bool IsWorkingDay(DateTime date)
        {
            // 주말 체크 (토요일 = 6, 일요일 = 0)
            if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday)
                return false;

            // 공휴일 체크
            string dateKey = date.ToString("yyyy-MM-dd");
            return !holidays.ContainsKey(dateKey);
        }

        private void LoadStateFromFile_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Text files (*.txt)|*.txt";
                openFileDialog.DefaultExt = "txt";

                if (openFileDialog.ShowDialog() != true)
                    return;

                // 진행 상태를 보여주는 창 생성
                var progressWindow = new Window()
                {
                    Title = "데이터 로딩 중...",
                    Width = 300,
                    Height = 100,
                    WindowStartupLocation = WindowStartupLocation.CenterOwner,
                    Owner = this,
                    ResizeMode = ResizeMode.NoResize
                };

                var progressBar = new ProgressBar()
                {
                    Width = 280,
                    Height = 20,
                    Margin = new Thickness(10),
                    IsIndeterminate = true
                };

                progressWindow.Content = progressBar;
                progressWindow.Show();

                // BackgroundWorker 생성
                BackgroundWorker worker = new BackgroundWorker();

                worker.DoWork += delegate(object s, DoWorkEventArgs args)
                {
                    try
                    {
                        args.Result = File.ReadAllLines(openFileDialog.FileName);
                    }
                    catch (Exception ex)
                    {
                        args.Result = ex;
                    }
                };

                worker.RunWorkerCompleted += delegate(object s, RunWorkerCompletedEventArgs args)
                {
                    progressWindow.Close();

                    try
                    {
                        if (args.Result is Exception)
                        {
                            MessageBox.Show("데이터 로드 중 오류 발생:\n" + ((Exception)args.Result).Message);
                            return;
                        }

                        string[] lines = args.Result as string[];
                        if (lines == null || lines.Length == 0)
                        {
                            MessageBox.Show("파일에서 데이터를 읽을 수 없습니다.", "ERROR(오류)/상태복원실패");
                            return;
                        }

                        int currentLine = 0;

                        // 저장 시각 읽기
                        DateTime saveTime = DateTime.Parse(lines[currentLine++]);

                        // 체크박스 상태 복원
                        SunPeCheckBox.IsChecked = bool.Parse(lines[currentLine++]);
                        SunPeCheckBox1.IsChecked = bool.Parse(lines[currentLine++]);
                        Pe1CheckBox.IsChecked = bool.Parse(lines[currentLine++]);
                        Pe1CheckBox1.IsChecked = bool.Parse(lines[currentLine++]);
                        Pe2CheckBox.IsChecked = bool.Parse(lines[currentLine++]);
                        Pe2CheckBox1.IsChecked = bool.Parse(lines[currentLine++]);

                        // 날짜 복원
                        StartDatePicker.SelectedDate = string.IsNullOrEmpty(lines[currentLine]) ?
                            (DateTime?)null : DateTime.Parse(lines[currentLine]);
                        currentLine++;
                        EndDatePicker.SelectedDate = string.IsNullOrEmpty(lines[currentLine]) ?
                            (DateTime?)null : DateTime.Parse(lines[currentLine]);
                        currentLine++;

                        // ComboBox 선택 복원
                        RestoreComboBoxSelection(MfgComboBox, lines[currentLine++]);
                        RestoreComboBoxSelection(PeComboBox, lines[currentLine++]);
                        RestoreComboBoxSelection(PeEqpBox, lines[currentLine++]);
                        RestoreComboBoxSelection(STAGEComboBox, lines[currentLine++]);
                        RestoreComboBoxSelection(PeTypeComboBox, lines[currentLine++]);

                        // 데이터 복원
                        List<ShipSchedule> loadedData = new List<ShipSchedule>();

                        for (int i = currentLine; i < lines.Length; i++)
                        {
                            if (!string.IsNullOrEmpty(lines[i]))
                            {
                                string[] parts = lines[i].Split('\t');
                                if (parts.Length >= 22)
                                {
                                    ShipSchedule schedule = new ShipSchedule
                                    {
                                        S_KIND = parts[0],
                                        S_TYPE = parts[1],
                                        OWNER = parts[2],
                                        SHIP_DISP = parts[3],
                                        BLOCK = parts[4],
                                        STG_CD = parts[5],
                                        S_NAME = parts[6],
                                        MFG_IND = parts[7],
                                        MFG_IND_After = parts[8],
                                        LOC_DESC = parts[9],
                                        LOC_EQP = parts[10],
                                        Dur = parts[11],
                                        PE_TYPE = parts[12],
                                        WKSTPLDT = DateTime.Parse(parts[13]),
                                        WKSTPLDT1 = DateTime.Parse(parts[14]),
                                        WKFIPLDT = DateTime.Parse(parts[15]),
                                        WKFIPLDT1 = DateTime.Parse(parts[16]),
                                        ERECT_PLDT = DateTime.Parse(parts[17]),
                                        IsSelected = bool.Parse(parts[18]),
                                        IsWKSTPLDT1Modified = bool.Parse(parts[19]),
                                        IsWKFIPLDTModified = bool.Parse(parts[20]),
                                        IsERPLDTModified = bool.Parse(parts[21]),
                                        MonthlyDates = new ArrayList()
                                    };

                                    // 색상 정보 복원
                                    if (parts.Length > 22 && !string.IsNullOrEmpty(parts[22]))
                                    {
                                        string[] monthsData = parts[22].Split('|');
                                        foreach (string monthData in monthsData)
                                        {
                                            if (!string.IsNullOrEmpty(monthData))
                                            {
                                                List<DateCell> monthDates = new List<DateCell>();
                                                for (int j = 0; j < monthData.Length; j++)
                                                {
                                                    DateCell cell = new DateCell
                                                    {
                                                        Day = (j + 1).ToString("00"),
                                                        Color = monthData[j] == '1' ? Brushes.Orange :
                                                               monthData[j] == '2' ? Brushes.Crimson :
                                                               Brushes.White
                                                    };
                                                    monthDates.Add(cell);
                                                }
                                                schedule.MonthlyDates.Add(monthDates);
                                            }
                                        }
                                    }

                                    loadedData.Add(schedule);
                                }
                            }
                        }

                        // 전역 데이터 업데이트
                        allData = loadedData;

                        // UI 업데이트
                        ProcessAndDisplayData(loadedData);

                        // 중요: 컨트롤 활성화 추가
                        EnableControls(true);

                        MessageBox.Show(
                            string.Format("저장된 상태를 불러왔습니다.\n저장 시각: {0:yyyy-MM-dd HH:mm:ss}",
                            saveTime),
                            "INFO(정보)/상태복원");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(
                            string.Format("상태 복원 중 오류가 발생했습니다:\n{0}", ex.Message),
                            "ERROR(오류)/상태복원실패");
                    }
                };

                worker.RunWorkerAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    string.Format("파일 로드 중 오류가 발생했습니다:\n{0}", ex.Message),
                    "ERROR(오류)/파일로드실패");
            }
        }
        private void RestoreState_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (savedStates.Count == 0)
                {
                    MessageBox.Show("저장된 상태가 없습니다.", "INFO(정보)/복원실패");
                    return;
                }

                // 저장된 상태 선택을 위한 윈도우 생성
                var selectWindow = new Window
                {
                    Title = "저장된 상태 선택",
                    Width = 400,
                    Height = 300,
                    WindowStartupLocation = WindowStartupLocation.CenterOwner,
                    Owner = this
                };

                var stackPanel = new StackPanel { Margin = new Thickness(10) };
                var listBox = new ListBox { Height = 200, Margin = new Thickness(0, 0, 0, 10) };

                foreach (var state in savedStates)
                {
                    listBox.Items.Add(string.Format("{0:yyyy-MM-dd HH:mm:ss}", state.SaveTime));
                }

                var buttonPanel = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    HorizontalAlignment = HorizontalAlignment.Right
                };

                var okButton = new Button { Content = "복원", Width = 75, Height = 25, Margin = new Thickness(0, 0, 10, 0) };
                var cancelButton = new Button { Content = "취소", Width = 75, Height = 25 };

                SavedPeState selectedState = null;

                okButton.Click += (s, ev) =>
                {
                    if (listBox.SelectedIndex >= 0)
                    {
                        selectedState = savedStates[listBox.SelectedIndex];
                        selectWindow.DialogResult = true;
                        selectWindow.Close();
                    }
                    else
                    {
                        MessageBox.Show("복원할 상태를 선택해주세요.", "알림");
                    }
                };

                cancelButton.Click += (s, ev) =>
                {
                    selectWindow.DialogResult = false;
                    selectWindow.Close();
                };

                buttonPanel.Children.Add(okButton);
                buttonPanel.Children.Add(cancelButton);

                stackPanel.Children.Add(listBox);
                stackPanel.Children.Add(buttonPanel);
                selectWindow.Content = stackPanel;

                if (selectWindow.ShowDialog() == true && selectedState != null)
                {
                    // 상태 복원
                    SunPeCheckBox.IsChecked = selectedState.IsSunPeChecked;
                    SunPeCheckBox1.IsChecked = selectedState.IsSunPe1Checked;
                    Pe1CheckBox.IsChecked = selectedState.IsPe1Checked;
                    Pe1CheckBox1.IsChecked = selectedState.IsPe1_1Checked;
                    Pe2CheckBox.IsChecked = selectedState.IsPe2Checked;
                    Pe2CheckBox1.IsChecked = selectedState.IsPe2_1Checked;

                    StartDatePicker.SelectedDate = selectedState.StartDate;
                    EndDatePicker.SelectedDate = selectedState.EndDate;

                    // ComboBox 선택 복원
                    RestoreComboBoxSelection(MfgComboBox, selectedState.SelectedMfg);
                    RestoreComboBoxSelection(PeComboBox, selectedState.SelectedPe);
                    RestoreComboBoxSelection(PeEqpBox, selectedState.SelectedPeEqp);
                    RestoreComboBoxSelection(STAGEComboBox, selectedState.SelectedStage);
                    RestoreComboBoxSelection(PeTypeComboBox, selectedState.SelectedPeType);

                    // 데이터 복원
                    if (selectedState.ScheduleData != null)
                    {
                        ProcessAndDisplayData(selectedState.ScheduleData);
                    }

                    MessageBox.Show(
                        string.Format("저장된 상태가 복원되었습니다.\n저장 시각: {0:yyyy-MM-dd HH:mm:ss}",
                        selectedState.SaveTime),
                        "INFO(정보)/상태복원");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    string.Format("상태 복원 중 오류가 발생했습니다:\n{0}", ex.Message),
                    "ERROR(오류)/상태복원실패");
            }
        }
        private void RestoreComboBoxSelection(ComboBox comboBox, string selectedValue)
        {
            if (string.IsNullOrEmpty(selectedValue)) return;

            var item = comboBox.Items.Cast<ComboBoxItem>()
                .FirstOrDefault(i => i.Content.ToString() == selectedValue);
            if (item != null)
            {
                comboBox.SelectedItem = item;
            }
        }
        private void InitializeScrollSync()
        {
            var scrollViewer1 = GetScrollViewer(ShipDataGrid);
            var scrollViewer2 = GetScrollViewer(ShipDataGrid1);

            if (scrollViewer1 != null && scrollViewer2 != null)
            {
                // ShipDataGrid 스크롤 이벤트
                scrollViewer1.ScrollChanged += (sender, e) =>
                {
                    if (Math.Abs(e.HorizontalOffset - previousOffset) > 0.001) // 수평 스크롤 변경 감지
                    {
                        double currentOffset = e.HorizontalOffset;

                        // 20cm(200픽셀) 이상 스크롤된 경우에만 ShipDataGrid1 스크롤 동기화
                        if (currentOffset >= SCROLL_THRESHOLD)
                        {
                            scrollViewer2.ScrollToHorizontalOffset(currentOffset - SCROLL_THRESHOLD);
                        }
                        else
                        {
                            // 20cm 미만인 경우 ShipDataGrid1은 시작 위치에 고정
                            scrollViewer2.ScrollToHorizontalOffset(0);
                        }

                        previousOffset = currentOffset;
                    }
                };

                // ShipDataGrid1 스크롤 방지
                scrollViewer2.ScrollChanged += (sender, e) =>
                {
                    if (e.HorizontalChange != 0)
                    {
                        double targetOffset = scrollViewer1.HorizontalOffset - SCROLL_THRESHOLD;
                        if (targetOffset < 0) targetOffset = 0;

                        // ShipDataGrid1의 스크롤 위치를 강제로 동기화
                        ((ScrollViewer)sender).ScrollToHorizontalOffset(targetOffset);
                    }
                };
            }
        }
        //// 공통 PE 처리 메서드(비동기 처리부분)
        //private void ProcessPeChanges(string peType, Action<ShipSchedule> updateAction)
        //{
        //    if (allData == null || _isUpdatingData) return;

        //    try
        //    {
        //        _isUpdatingData = true;

        //        // 데이터 필터링
        //        var targetSchedules = allData.Where(s => s.PE_TYPE == peType).ToArray();
        //        if (targetSchedules.Length == 0) return;

        //        // UI 업데이트 일시 중지
        //        ShipDataGrid.BeginInit();

        //        // 병렬 처리
        //        if (targetSchedules.Length > 100)
        //        {
        //            Parallel.ForEach(targetSchedules, updateAction);
        //        }
        //        else
        //        {
        //            foreach (var schedule in targetSchedules)
        //            {
        //                updateAction(schedule);
        //            }
        //        }

        //        // UI 업데이트 - .NET 4.0 방식
        //        Application.Current.Dispatcher.BeginInvoke(
        //            DispatcherPriority.Background,
        //            new Action(delegate()
        //            {
        //                ShipDataGrid.EndInit();
        //                ShipDataGrid.Items.Refresh();
        //            })
        //        );
        //    }
        //    finally
        //    {
        //        _isUpdatingData = false;
        //    }
        //}

        // 공통 PE 처리 메서드(비동기 처리부분) 202501
        private void ProcessPeChanges(string peType, Action<ShipSchedule> updateAction)
        {
            if (allData == null || _isUpdatingData) return;

            try
            {
                _isUpdatingData = true;

                // UI 스레드에서 BeginInit 호출
                Dispatcher.Invoke(() => ShipDataGrid.BeginInit());

                // 데이터 필터링
                var targetSchedules = allData.Where(s => s.PE_TYPE == peType).ToArray();
                if (targetSchedules.Length == 0)
                {
                    Dispatcher.Invoke(() => ShipDataGrid.EndInit());
                    return;
                }

                // 병렬 처리
                if (targetSchedules.Length > 100)
                {
                    Parallel.ForEach(targetSchedules, updateAction);
                }
                else
                {
                    foreach (var schedule in targetSchedules)
                    {
                        updateAction(schedule);
                    }
                }

                // UI 업데이트를 UI 스레드에서 실행
                Dispatcher.Invoke(() =>
                {
                    ShipDataGrid.EndInit();
                    ShipDataGrid.Items.Refresh();
                });
            }
            finally
            {
                _isUpdatingData = false;
            }
        }
        // 개별 스케줄 업데이트 메서드
        private void UpdateSchedule(ShipSchedule schedule, DateTime adjustmentValue, string adjustmentType, bool isModified)
        {
            switch (adjustmentType)
            {
                case "WKSTPLDT1":
                    schedule.WKSTPLDT1 = adjustmentValue;
                    schedule.IsWKSTPLDT1Modified = isModified;
                    break;
                case "WKFIPLDT":
                    schedule.WKFIPLDT = adjustmentValue;
                    schedule.IsWKFIPLDTModified = isModified;
                    break;
                case "ERECT_PLDT":
                    schedule.ERECT_PLDT = adjustmentValue;
                    schedule.IsERPLDTModified = isModified;
                    break;
            }
        }
        private void InitializeDataGrid()
        {
            ShipDataGrid.Items.Clear();
            ShipDataGrid.Columns.Clear();
            AddTextColumns();
        }

        // MainWindow 클래스에 아래 메서드를 추가하세요.
        //private void EnableControls(bool isEnabled)
        //{
        //    //LoadDataButton.IsEnabled = !isEnabled;  // 데이터 로드 버튼은 반대로 동작
        //    //LoadDataButton.IsEnabled = true;  // 항상 활성화 상태 유지
        //    ResetButton.IsEnabled = isEnabled;
        //    //ExcelExportButton.IsEnabled = isEnabled;
        //    SearchButton.IsEnabled = isEnabled;

        //    MfgComboBox.IsEnabled = isEnabled;
        //    PeComboBox.IsEnabled = isEnabled;
        //    PeEqpBox.IsEnabled = isEnabled;
        //    STAGEComboBox.IsEnabled = isEnabled;
        //    //WKSTPLDT1ComboBox.IsEnabled = isEnabled;
        //    StartDatePicker.IsEnabled = isEnabled;
        //    EndDatePicker.IsEnabled = isEnabled;

        //    ShipDataGrid.IsEnabled = isEnabled;
        //}
        private void EnableControls(bool isEnabled)
        {
            // 파일 메뉴 항목들
            ResetButton.IsEnabled = isEnabled;
            SearchButton.IsEnabled = isEnabled;
            //CHButton.IsEnabled = isEnabled;
            PeApplyButton.IsEnabled = isEnabled;

            // PE 관련 컨트롤들
            SunPeCheckBox.IsEnabled = isEnabled;
            SunPeCheckBox1.IsEnabled = isEnabled;
            Pe1CheckBox.IsEnabled = isEnabled;
            Pe1CheckBox1.IsEnabled = isEnabled;
            Pe2CheckBox.IsEnabled = isEnabled;
            Pe2CheckBox1.IsEnabled = isEnabled;

            // TextBox들
            SunPeTextBox.IsEnabled = isEnabled;
            SunPeTextBox1.IsEnabled = isEnabled;
            Pe1TextBox.IsEnabled = isEnabled;
            Pe1TextBox1.IsEnabled = isEnabled;
            Pe2TextBox.IsEnabled = isEnabled;
            Pe2TextBox1.IsEnabled = isEnabled;

            // 필터링 관련 컨트롤들
            MfgComboBox.IsEnabled = isEnabled;
            PeComboBox.IsEnabled = isEnabled;
            PeEqpBox.IsEnabled = isEnabled;
            STAGEComboBox.IsEnabled = isEnabled;
            PeTypeComboBox.IsEnabled = isEnabled;
            StartDatePicker.IsEnabled = isEnabled;
            EndDatePicker.IsEnabled = isEnabled;

            // DataGrid
            ShipDataGrid.IsEnabled = isEnabled;
            ShipDataGrid1.IsEnabled = isEnabled;
        }

        private void LoadDataButton_Click(object sender, RoutedEventArgs e)
        {
            // 필터 선택을 위한 윈도우 생성
            Window filterWindow = new Window
            {
                Title = "데이터 로드 필터",
                Width = 480,
                Height = 380,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                ResizeMode = ResizeMode.NoResize
            };

            Grid grid = new Grid { Margin = new Thickness(10) };
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // 사업장 선택 영역
            GroupBox mfgGroup = new GroupBox { Header = "사업장 선택", Margin = new Thickness(0, 5, 0, 10) };
            Grid.SetRow(mfgGroup, 1);

            // 체크박스 컨테이너
            StackPanel checkBoxPanel = new StackPanel { Margin = new Thickness(5) };

            // 전체 선택 체크박스
            CheckBox allCheckBox = new CheckBox
            {
                Content = "전체 선택",
                Margin = new Thickness(0, 0, 0, 4),
                IsChecked = false // 처음부터 체크되지 않음
            };
            checkBoxPanel.Children.Add(allCheckBox);

            // 개별 사업장 체크박스들
            var checkBoxes = new List<CheckBox>();
            string[] locations = new[] { "본사", "해양", "온산" };
            //string[] locations = new[] { "본사", "해양", "온산", "용연", "사외", "사외(HVS)" };
            foreach (string loc in locations)
            {
                var cb = new CheckBox
                {
                    Content = loc,
                    Margin = new Thickness(20, 0, 0, 5),
                    IsChecked = false // 처음부터 체크되지 않음
                };
                checkBoxes.Add(cb);
                checkBoxPanel.Children.Add(cb);

                // 개별 체크박스의 상태가 변경되면 전체 선택 상태 업데이트
                cb.Checked += (s, ev) =>
                {
                    if (checkBoxes.All(x => x.IsChecked == true))
                        allCheckBox.IsChecked = true;
                };
                cb.Unchecked += (s, ev) => allCheckBox.IsChecked = false;
            }

            // 전체 선택 체크박스 이벤트
            allCheckBox.Checked += (s, ev) =>
            {
                foreach (var cb in checkBoxes)
                    cb.IsChecked = true;
            };
            allCheckBox.Unchecked += (s, ev) =>
            {
                foreach (var cb in checkBoxes)
                    cb.IsChecked = false;
            };

            mfgGroup.Content = checkBoxPanel;

            // 날짜 선택 패널
            GroupBox dateGroup = new GroupBox { Header = "계획일 범위 선택", Margin = new Thickness(0, 5, 0, 10) };
            Grid.SetRow(dateGroup, 2);

            StackPanel datePanel = new StackPanel { Orientation = Orientation.Vertical, Margin = new Thickness(5) };

            // 시작계획일 체크박스 및 선택
            CheckBox startPlanDateCheckBox = new CheckBox { Content = "시작계획일 범위", Margin = new Thickness(0, 0, 0, 5) };
            StackPanel startDatePanel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(5, 0, 5, 0), IsEnabled = false };

            DatePicker startDatePicker = new DatePicker { Width = 120, Margin = new Thickness(5, 0, 5, 0) };
            DatePicker endDatePicker = new DatePicker { Width = 120, Margin = new Thickness(5, 0, 5, 0) };

            startDatePanel.Children.Add(new Label { Content = "시작:" });
            startDatePanel.Children.Add(startDatePicker);
            startDatePanel.Children.Add(new Label { Content = "종료:" });
            startDatePanel.Children.Add(endDatePicker);

            startPlanDateCheckBox.Checked += (s, ev) => startDatePanel.IsEnabled = true;
            startPlanDateCheckBox.Unchecked += (s, ev) => startDatePanel.IsEnabled = false;

            datePanel.Children.Add(startPlanDateCheckBox);
            datePanel.Children.Add(startDatePanel);

            // 완료계획일 체크박스 및 선택
            CheckBox finishPlanDateCheckBox = new CheckBox { Content = "완료계획일 범위", Margin = new Thickness(0, 0, 0, 5) };
            StackPanel finishDatePanel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(5, 0, 5, 0), IsEnabled = false };

            DatePicker finishStartDatePicker = new DatePicker { Width = 120, Margin = new Thickness(5, 0, 5, 0) };
            DatePicker finishEndDatePicker = new DatePicker { Width = 120, Margin = new Thickness(5, 0, 5, 0) };

            finishDatePanel.Children.Add(new Label { Content = "시작:" });
            finishDatePanel.Children.Add(finishStartDatePicker);
            finishDatePanel.Children.Add(new Label { Content = "종료:" });
            finishDatePanel.Children.Add(finishEndDatePicker);

            finishPlanDateCheckBox.Checked += (s, ev) => finishDatePanel.IsEnabled = true;
            finishPlanDateCheckBox.Unchecked += (s, ev) => finishDatePanel.IsEnabled = false;

            datePanel.Children.Add(finishPlanDateCheckBox);
            datePanel.Children.Add(finishDatePanel);

            dateGroup.Content = datePanel;

            // 버튼 패널
            StackPanel buttonPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 10, 0, 0)
            };
            Grid.SetRow(buttonPanel, 4);

            Button okButton = new Button
            {
                Content = "확인",
                Width = 75,
                Height = 25,
                Margin = new Thickness(0, 0, 10, 0)
            };

            Button cancelButton = new Button
            {
                Content = "취소",
                Width = 75,
                Height = 25
            };

            HashSet<string> selectedLocations = new HashSet<string>();
            DateTime? startDate = null;
            DateTime? endDate = null;
            DateTime? finishStartDate = null;
            DateTime? finishEndDate = null;
            bool? dialogResult = null;

            okButton.Click += (s, ev) =>
            {
                if (!checkBoxes.Any(cb => cb.IsChecked == true))
                {
                    MessageBox.Show("적어도 하나의 사업장을 선택해주세요.", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                selectedLocations.Clear();
                foreach (var cb in checkBoxes)
                {
                    if (cb.IsChecked == true)
                        selectedLocations.Add(cb.Content.ToString());
                }

                if (startPlanDateCheckBox.IsChecked == true)
                {
                    startDate = startDatePicker.SelectedDate;
                    endDate = endDatePicker.SelectedDate;

                    if (startDate.HasValue && endDate.HasValue && startDate > endDate)
                    {
                        MessageBox.Show("시작일이 종료일보다 늦을 수 없습니다.", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }
                }

                if (finishPlanDateCheckBox.IsChecked == true)
                {
                    finishStartDate = finishStartDatePicker.SelectedDate;
                    finishEndDate = finishEndDatePicker.SelectedDate;

                    if (finishStartDate.HasValue && finishEndDate.HasValue && finishStartDate > finishEndDate)
                    {
                        MessageBox.Show("시작일이 종료일보다 늦을 수 없습니다.", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }
                }

                dialogResult = true;
                filterWindow.Close();
            };

            cancelButton.Click += (s, ev) =>
            {
                dialogResult = false;
                filterWindow.Close();
            };

            buttonPanel.Children.Add(okButton);
            buttonPanel.Children.Add(cancelButton);

            grid.Children.Add(mfgGroup);
            grid.Children.Add(dateGroup);
            grid.Children.Add(buttonPanel);

            filterWindow.Content = grid;
            filterWindow.ShowDialog();

            if (dialogResult != true)
                return;

            Excel.Application excelApp = null;
            Excel.Workbook workbook = null;
            Excel.Worksheet worksheet = null;
            Excel.Range range = null;

            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Excel Files (*.xls;*.xlsx)|*.xls;*.xlsx";
                openFileDialog.DefaultExt = "xls";
                openFileDialog.Title = "Excel 파일 선택";

                if (openFileDialog.ShowDialog() != true)
                    return;

                var progressWindow = new Window()
                {
                    Title = "데이터 로딩 중...",
                    Width = 300,
                    Height = 100,
                    WindowStartupLocation = WindowStartupLocation.CenterOwner,
                    Owner = this,
                    ResizeMode = ResizeMode.NoResize
                };

                var progressBar = new ProgressBar()
                {
                    Width = 280,
                    Height = 20,
                    Margin = new Thickness(10),
                    IsIndeterminate = true
                };

                progressWindow.Content = progressBar;
                progressWindow.Show();

                BackgroundWorker worker = new BackgroundWorker();
                worker.DoWork += (s, args) =>
                {
                    try
                    {
                        excelApp = new Excel.Application();
                        workbook = excelApp.Workbooks.Open(openFileDialog.FileName);
                        worksheet = (Excel.Worksheet)workbook.Sheets[1];
                        range = worksheet.UsedRange;

                        object[,] rawData = range.Value2 as object[,];
                        int rowCount = rawData.GetLength(0);

                        List<ShipSchedule> tempData = new List<ShipSchedule>();

                        // 필요한 열의 인덱스를 찾습니다
                        Dictionary<string, int> columnIndexes = new Dictionary<string, int>();
                        string[] requiredColumns = new[]
                        {
                            "선종", "선형", "선주사", "호선", "블록", "STAGE", "구획이름",
                            "사업장", "PE사용크레인", "PE장비","PE구분","계획공기", "착수실적일", "시작계획일",
                            "완료계획일", "완료실적일", "탑재계획일"
                        }; ///"완료실적일"

                        // 헤더에서 필요한 열의 인덱스를 찾습니다
                        for (int col = 1; col <= rawData.GetLength(1); col++)
                        {
                            string headerValue = Convert.ToString(rawData[1, col]);
                            if (requiredColumns.Contains(headerValue))
                            {
                                columnIndexes[headerValue] = col;
                            }
                        }

                        const int chunkSize = 100;
                        for (int i = 2; i <= rowCount; i += chunkSize)
                        {
                            int endRow = Math.Min(i + chunkSize - 1, rowCount);

                            for (int row = i; row <= endRow; row++)
                            {
                                try
                                {
                                    string sKind = Convert.ToString(rawData[row, columnIndexes["선종"]]);
                                    if (string.IsNullOrEmpty(sKind))
                                        continue;

                                    // 사업장 필터링
                                    string mfgInd = Convert.ToString(rawData[row, columnIndexes["사업장"]]);
                                    if (!selectedLocations.Contains(mfgInd))
                                        continue;

                                    // 시작계획일 필터링
                                    DateTime wkstpldt1 = ConvertExcelDate(rawData[row, columnIndexes["시작계획일"]]);
                                    if (startDate.HasValue && endDate.HasValue)
                                    {
                                        if (wkstpldt1.Date < startDate.Value.Date ||
                                            wkstpldt1.Date > endDate.Value.Date)
                                            continue;
                                    }

                                    // 완료계획일 필터링 추가
                                    DateTime wkfipldt = ConvertExcelDate(rawData[row, columnIndexes["완료계획일"]]);
                                    if (finishStartDate.HasValue && finishEndDate.HasValue)
                                    {
                                        if (wkfipldt.Date < finishStartDate.Value.Date ||
                                            wkfipldt.Date > finishEndDate.Value.Date)
                                            continue;
                                    }

                                    ShipSchedule schedule = new ShipSchedule();
                                    schedule.S_KIND = sKind;
                                    schedule.S_TYPE = Convert.ToString(rawData[row, columnIndexes["선형"]]);
                                    schedule.OWNER = Convert.ToString(rawData[row, columnIndexes["선주사"]]);
                                    schedule.SHIP_DISP = Convert.ToString(rawData[row, columnIndexes["호선"]]);
                                    schedule.BLOCK = Convert.ToString(rawData[row, columnIndexes["블록"]]);
                                    schedule.STG_CD = Convert.ToString(rawData[row, columnIndexes["STAGE"]]);
                                    schedule.S_NAME = Convert.ToString(rawData[row, columnIndexes["구획이름"]]);
                                    schedule.MFG_IND = mfgInd;
                                    schedule.MFG_IND_After = mfgInd;
                                    schedule.OriginalMfgInd = mfgInd;  // 원래 사업장 값을 여기서 저장
                                    schedule.LOC_DESC = Convert.ToString(rawData[row, columnIndexes["PE사용크레인"]]);
                                    schedule.LOC_EQP = Convert.ToString(rawData[row, columnIndexes["PE장비"]]);
                                    schedule.SetPEType();
                                    schedule.Dur = Convert.ToString(rawData[row, columnIndexes["계획공기"]]); // 계획공기 추가

                                    schedule.WKSTPLDT = ConvertExcelDate(rawData[row, columnIndexes["착수실적일"]]);
                                    schedule.WKSTPLDT1 = wkstpldt1;
                                    schedule.WKFIPLDT = ConvertExcelDate(rawData[row, columnIndexes["완료계획일"]]);

                                    schedule.WKFIPLDT1 = ConvertExcelDate(rawData[row, columnIndexes["완료실적일"]]);
                                    schedule.ERECT_PLDT = ConvertExcelDate(rawData[row, columnIndexes["탑재계획일"]]);

                                    tempData.Add(schedule);
                                }
                                catch
                                {
                                    continue;
                                }
                            }
                        }

                        var capeRows = tempData.Where(schedule =>
                            schedule.S_KIND == "LOAD 중일정개수" ||
                            schedule.S_KIND == "LOAD 조정결과개수"
                        ).ToList();

                        var regularRows = tempData.Where(schedule =>
                            schedule.S_KIND != "LOAD 중일정개수" &&
                            schedule.S_KIND != "LOAD 조정결과개수"
                        ).ToList();

                        // 일반 데이터만 시작계획일로 정렬
                        regularRows = regularRows.OrderBy(schedule => schedule.WKSTPLDT1).ToList();

                        // 정렬된 일반 데이터와 LOAD 행 합치기
                        tempData = regularRows.Concat(capeRows).ToList();

                        args.Result = tempData;
                    }
                    catch (Exception ex)
                    {
                        args.Result = ex;
                    }
                };

                worker.RunWorkerCompleted += (s, args) =>
                {
                    try
                    {
                        progressWindow.Close();

                        if (args.Error != null)
                        {
                            MessageBox.Show("데이터 로드 중 오류 발생:\n" + args.Error.Message);
                            return;
                        }

                        if (args.Result is Exception)
                        {
                            MessageBox.Show("데이터 로드 중 오류 발생:\n" + ((Exception)args.Result).Message);
                            return;
                        }

                        allData = args.Result as List<ShipSchedule>;
                        if (allData != null && allData.Count > 0)
                        {
                            // 여기에 원래 사업장 값 저장 코드 추가
                            foreach (ShipSchedule schedule in allData)
                            {
                                schedule.OriginalMfgInd = schedule.MFG_IND;
                            }

                            ProcessAndDisplayData(allData);
                            EnableControls(true);

                            StringBuilder message = new StringBuilder();
                            message.AppendLine(string.Format("데이터 로드 완료: {0}개", allData.Count));
                            message.AppendLine("적용된 필터:");
                            message.AppendLine("- 사업장: " + string.Join(", ", selectedLocations));

                            if (startDate.HasValue && endDate.HasValue)
                            {
                                message.AppendLine(string.Format("- 시작계획일: {0:yyyy-MM-dd} ~ {1:yyyy-MM-dd}",
                                    startDate.Value, endDate.Value));
                            }

                            if (finishStartDate.HasValue && finishEndDate.HasValue)
                            {
                                message.AppendLine(string.Format("- 완료계획일: {0:yyyy-MM-dd} ~ {1:yyyy-MM-dd}",
                                    finishStartDate.Value, finishEndDate.Value));
                            }

                            MessageBox.Show(message.ToString(), "INFO(정보)/데이터로드");
                            // 데이터 로드가 완전히 끝난 후 Reset_Click 실행
                            Dispatcher.BeginInvoke(new Action(() =>
                            {
                                try
                                {
                                    Reset_Click(null, new RoutedEventArgs());
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show("자동 저장 중 오류가 발생했습니다: " + ex.Message,
                                        "ERROR(오류)/자동저장실패",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Warning);
                                }
                            }), DispatcherPriority.Background);
                        }
                    }
                    finally
                    {
                        if (range != null) Marshal.ReleaseComObject(range);
                        if (worksheet != null) Marshal.ReleaseComObject(worksheet);
                        if (workbook != null)
                        {
                            workbook.Close(false);
                            Marshal.ReleaseComObject(workbook);
                        }
                        if (excelApp != null)
                        {
                            excelApp.Quit();
                            Marshal.ReleaseComObject(excelApp);
                        }
                        GC.Collect();
                        GC.WaitForPendingFinalizers();
                    }
                };

                worker.RunWorkerAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Excel 파일 로드 중 오류 발생:\n" + ex.Message);
            }
        }

        private DateTime lastClickTime = DateTime.MinValue;
        //public void ShipDataGrid_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        private void ShipDataGrid_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                var cell = UIHelpers.GetParent<DataGridCell>((DependencyObject)e.OriginalSource);
                if (cell == null) return;

                var column = cell.Column as DataGridTextColumn;
                if (column != null && column.Header.ToString() == "사업장(MFG_IND후)")
                {
                    MessageBox.Show("이 열은 수정할 수 없습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                if ((DateTime.Now - lastClickTime).TotalMilliseconds < 500)
                {
                    // 잠금 상태 체크 추가
                    if (_isScheduleLocked)
                    {
                        MessageBox.Show(
                            "현재 일정이 잠금 상태입니다.\n날짜 수정이 불가능합니다.",
                            "수정 불가",
                            MessageBoxButton.OK,
                            MessageBoxImage.Warning
                        );
                        return;
                    }

                    var row = ItemsControl.ContainerFromElement((DataGrid)sender,
                        e.OriginalSource as DependencyObject) as DataGridRow;

                    if (row != null)
                    {
                        var schedule = row.Item as ShipSchedule;
                        if (schedule != null)
                        {
                            if (schedule.S_KIND == "LOAD 중일정개수" ||
                                schedule.S_KIND == "LOAD 조정 개수" ||
                                schedule.S_KIND == "LOAD 조정결과개수")
                            {
                                MessageBox.Show("LOAD 관련 행은 수정할 수 없습니다.", "INFO(정보)/수정불가");
                                return;
                            }

                            var editor = new DateEditorWindow(schedule);
                            editor.Owner = this;

                            if (editor.ShowDialog() == true)
                            {
                                var displayedData = ShipDataGrid.ItemsSource as List<ShipSchedule>;
                                if (displayedData != null)
                                {
                                    // 현재 표시된 데이터의 해당 항목 업데이트
                                    var displayedItem = displayedData.FirstOrDefault(x =>
                                        x.SHIP_DISP == schedule.SHIP_DISP &&
                                        x.BLOCK == schedule.BLOCK &&
                                        x.STG_CD == schedule.STG_CD);

                                    if (displayedItem != null)
                                    {
                                        displayedItem.WKSTPLDT1 = schedule.WKSTPLDT1;
                                        displayedItem.WKFIPLDT = schedule.WKFIPLDT;
                                        displayedItem.ERECT_PLDT = schedule.ERECT_PLDT;
                                        displayedItem.IsWKSTPLDT1Modified = schedule.IsWKSTPLDT1Modified;
                                        displayedItem.IsWKFIPLDTModified = schedule.IsWKFIPLDTModified;
                                        displayedItem.IsERPLDTModified = schedule.IsERPLDTModified;
                                    }

                                    // 전체 데이터도 업데이트
                                    var originalItem = allData.FirstOrDefault(x =>
                                        x.SHIP_DISP == schedule.SHIP_DISP &&
                                        x.BLOCK == schedule.BLOCK &&
                                        x.STG_CD == schedule.STG_CD);

                                    if (originalItem != null)
                                    {
                                        originalItem.WKSTPLDT1 = schedule.WKSTPLDT1;
                                        originalItem.WKFIPLDT = schedule.WKFIPLDT;
                                        originalItem.ERECT_PLDT = schedule.ERECT_PLDT;
                                        originalItem.IsWKSTPLDT1Modified = schedule.IsWKSTPLDT1Modified;
                                        originalItem.IsWKFIPLDTModified = schedule.IsWKFIPLDTModified;
                                        originalItem.IsERPLDTModified = schedule.IsERPLDTModified;
                                    }

                                    // UI 업데이트
                                    ShipDataGrid.Items.Refresh();
                                    UpdateCapeAdjustCount();
                                }
                            }
                        }
                    }
                }
                lastClickTime = DateTime.Now;
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    string.Format("데이터 처리 중 오류가 발생했습니다: {0}", ex.Message),
                    "ERROR(오류)/처리실패"
                );
            }
        }

        private DateTime ConvertExcelDate(object value)
        {
            try
            {
                if (value == null)
                {
                    // 데이터가 null일 경우 시작계획일을 반환
                    return DateTime.MinValue; // 또는 다른 기본값을 반환하도록 설정할 수 있습니다.
                }

                // 숫자 형식인 경우 (Excel 날짜)
                if (value is double)
                {
                    return DateTime.FromOADate((double)value);
                }

                // 문자열인 경우
                string strValue = value.ToString();
                if (!string.IsNullOrEmpty(strValue))
                {
                    DateTime result;
                    if (DateTime.TryParse(strValue, out result))
                    {
                        return result;
                    }
                }
            }
            catch
            {
                // 오류 발생 시 기본값 반환 (시작계획일이 기본값으로 설정되도록 해야 함)
            }

            // 기본값으로 시작계획일 반환 (여기서 MinValue 대신 특정 기본값 사용 가능)
            return DateTime.MinValue;
        }

        // 셀 값을 문자열로 가져오는 헬퍼 메서드
        private string GetCellValue(Excel.Range cell)
        {
            if (cell.Value2 != null)
            {
                return cell.Value2.ToString().Trim();
            }
            return "";
        }

        // Excel 날짜를 DateTime으로 변환하는 헬퍼 메서드
        private DateTime GetExcelDate(Excel.Range cell)
        {
            try
            {
                if (cell.Value2 != null)
                {
                    // Excel 날짜값인 경우
                    if (cell.Value2 is double)
                    {
                        return DateTime.FromOADate((double)cell.Value2);
                    }
                    // 문자열인 경우
                    return Convert.ToDateTime(cell.Value2);
                }
            }
            catch
            {
                // 오류 발생시 현재 날짜 반환
            }
            return DateTime.Now;
        }


        private void ResetButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // PE 체크박스 상태 확인
                bool anyChecked = SunPeCheckBox.IsChecked == true ||
                                 SunPeCheckBox1.IsChecked == true ||
                                 Pe1CheckBox.IsChecked == true ||
                                 Pe1CheckBox1.IsChecked == true ||
                                 Pe2CheckBox.IsChecked == true ||
                                 Pe2CheckBox1.IsChecked == true;

                if (anyChecked)
                {
                    MessageBox.Show("PE 체크박스를 모두 해제한 후 초기화 버튼을 눌러주세요.", "INFO(정보)/체크박스해제필요");
                    return;
                }

                // 심홍색(Crimson) 셀의 날짜 정보를 저장할 Dictionary
                Dictionary<string, List<string>> monthDates = new Dictionary<string, List<string>>();

                if (allData != null)
                {
                    foreach (ShipSchedule schedule in allData)
                    {
                        if (schedule.MonthlyDates != null)
                        {
                            for (int i = 0; i < schedule.MonthlyDates.Count; i++)
                            {
                                List<DateCell> monthData = schedule.MonthlyDates[i] as List<DateCell>;
                                if (monthData != null)
                                {
                                    // 현재 월 계산
                                    DateTime currentMonth = schedule.WKSTPLDT1.AddMonths(i);
                                    string monthKey = currentMonth.ToString("yyyy년 MM월");

                                    for (int dayIndex = 0; dayIndex < monthData.Count; dayIndex++)
                                    {
                                        if (monthData[dayIndex].Color == Brushes.Crimson)
                                        {
                                            if (!monthDates.ContainsKey(monthKey))
                                            {
                                                monthDates[monthKey] = new List<string>();
                                            }
                                            monthDates[monthKey].Add(dayIndex + 1 + "일");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 심홍색 셀이 있는 경우 확인 메시지 표시
                if (monthDates.Count > 0)
                {
                    StringBuilder confirmMsg = new StringBuilder();
                    confirmMsg.AppendLine("다음 날짜에 조정된 일정(심홍색)이 있습니다.");
                    confirmMsg.AppendLine();

                    foreach (KeyValuePair<string, List<string>> monthInfo in monthDates)
                    {
                        confirmMsg.AppendLine(string.Format("- {0}: {1}",
                            monthInfo.Key,
                            string.Join(", ", monthInfo.Value)));
                    }

                    confirmMsg.AppendLine("\n정말 초기화하시겠습니까?");

                    MessageBoxResult result = MessageBox.Show(
                        confirmMsg.ToString(),
                        "초기화 확인",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);

                    if (result != MessageBoxResult.Yes)
                    {
                        return;
                    }
                }

                // ComboBox들 초기화
                StartDatePicker.SelectedDate = null;
                EndDatePicker.SelectedDate = null;
                MfgComboBox.SelectedIndex = 0;
                PeComboBox.SelectedIndex = 0;
                PeEqpBox.SelectedIndex = 0;
                STAGEComboBox.SelectedIndex = 0;
                PeTypeComboBox.SelectedIndex = 0;

                if (allData != null)
                {
                    // 각 일정 데이터 초기화
                    foreach (ShipSchedule item in allData)
                    {
                        // CAPE 관련 행은 건너뛰기
                        if (item.S_KIND == "LOAD 중일정개수" ||
                            item.S_KIND == "LOAD 조정 개수" ||
                            item.S_KIND == "LOAD 조정결과개수")
                            continue;

                        // 선택 상태 초기화
                        item.IsSelected = false;

                        // 사업장 수정 플래그 초기화
                        item.IsMfgModified = false;
                        item.MFG_IND = item.OriginalMfgInd;  // 원래 사업장으로 복원

                        // 날짜 수정 플래그 초기화
                        item.IsWKSTPLDT1Modified = false;
                        item.IsWKFIPLDTModified = false;
                        item.IsERPLDTModified = false;

                        // 날짜들을 원래 상태로 복원
                        if (item.PE_TYPE == "선PE")
                        {
                            // 선PE 날짜 조정 취소
                            if (item.IsWKSTPLDT1Modified)
                                item.WKSTPLDT1 = item.WKSTPLDT1.AddDays(1);
                            if (item.IsWKFIPLDTModified)
                                item.WKFIPLDT = item.WKFIPLDT.AddDays(-1);
                        }
                        else if (item.PE_TYPE == "1PE")
                        {
                            // 1PE 날짜 조정 취소
                            if (item.IsWKSTPLDT1Modified)
                                item.WKSTPLDT1 = item.WKSTPLDT1.AddDays(1);
                            if (item.IsWKFIPLDTModified)
                                item.WKFIPLDT = item.WKFIPLDT.AddDays(-1);
                        }
                        else if (item.PE_TYPE == "2PE")
                        {
                            // 2PE 날짜 조정 취소
                            if (item.IsERPLDTModified)
                                item.ERECT_PLDT = item.ERECT_PLDT.AddDays(1);
                        }

                        // MonthlyDates 초기화
                        if (item.MonthlyDates != null)
                        {
                            foreach (object monthObj in item.MonthlyDates)
                            {
                                List<DateCell> monthDates1 = monthObj as List<DateCell>;
                                if (monthDates != null)
                                {
                                    foreach (DateCell cell in monthDates1)
                                    {
                                        if (cell.Color == Brushes.Crimson)
                                        {
                                            cell.Color = Brushes.Orange;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 데이터 그리드 새로고침
                    ProcessAndDisplayData(allData);
                }

                // CAPE 조정 개수 업데이트
                UpdateCapeAdjustCount();

                // 초기화 완료 메시지
                StringBuilder resultMsg = new StringBuilder();
                resultMsg.AppendLine("초기화가 완료되었습니다.");
                foreach (KeyValuePair<string, List<string>> monthInfo in monthDates)
                {
                    resultMsg.AppendLine(string.Format("- {0}: {1}의 조정일정이 초기화됨",
                        monthInfo.Key,
                        string.Join(", ", monthInfo.Value)));
                }
                resultMsg.AppendLine("\n- 모든 PE 체크박스 해제됨");
                resultMsg.AppendLine("- 모든 날짜 원복 완료");
                resultMsg.AppendLine("- 모든 선택 상태 초기화");
                resultMsg.AppendLine("- 모든 필터 초기화");
                resultMsg.AppendLine("- 모든 색상 원복 완료");
                resultMsg.AppendLine("- 모든 사업장 변경사항 초기화"); // 추가된 라인

                MessageBox.Show(resultMsg.ToString(), "INFO(정보)/전체초기화완료");
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    string.Format("초기화 중 오류가 발생했습니다:\n{0}", ex.Message),
                    "ERROR(오류)/초기화실패"
                );
            }
        }

        //private void ExportButton_Click(object sender, RoutedEventArgs e)
        //{
        //    SaveFileDialog saveFileDialog = new SaveFileDialog();
        //    saveFileDialog.Filter = "Excel Files (*.xls)|*.xls";
        //    saveFileDialog.DefaultExt = "xls";
        //    saveFileDialog.FileName = "ShipSchedule_" + DateTime.Now.ToString("yyyyMMdd");

        //    if (saveFileDialog.ShowDialog() != true)
        //        return;

        //    Excel.Application excelApp = null;
        //    Excel.Workbook workbook = null;
        //    Excel.Worksheet worksheet = null;
        //    Excel.Range range = null;

        //    try
        //    {
        //        excelApp = new Excel.Application();
        //        excelApp.ScreenUpdating = false;
        //        excelApp.EnableEvents = false;
        //        excelApp.DisplayAlerts = false;

        //        workbook = excelApp.Workbooks.Add(true);
        //        worksheet = (Excel.Worksheet)workbook.Sheets[1];

        //        List<ShipSchedule> currentData = (List<ShipSchedule>)ShipDataGrid.ItemsSource;
        //        if (currentData == null || currentData.Count == 0)
        //        {
        //            MessageBox.Show("저장할 데이터가 없습니다.", "ERROR(오류)/데이터없음");
        //            return;
        //        }

        //        // 기본 헤더 작성
        //        string[] headers = new string[] {
        //            "선종(S_KIND)", "선형(S_TYPE)", "선주사(OWNER)", 
        //            "호선(SHIP_DISP)", "블록(BLOCK)", "STAGE(STG_CD)", 
        //            "구획 이름(S_NAME)", "사업장(MFG_IND)", "PE장소(LOC_DESC)","PE장비(LOC_EQP)","PE구분(LOC_SOT)",
        //            "착수실적일(WKSTPLDT)", "시작 계획일(WKSTPLDT1)", "완료계획일(WKFIPLDT)",
        //            "완료실적일(WKFIPLDT1)", "탑재계획일(ERECT_PLDT)"
        //        };

        //        // 기본 헤더 일괄 작성
        //        for (int i = 0; i < headers.Length; i++)
        //        {
        //            worksheet.Cells[1, i + 1].Value = headers[i];
        //        }

        //        range = worksheet.Range["A1:P1"];
        //        range.Font.Bold = true;
        //        range.Interior.ColorIndex = 15;
        //        range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        //        range.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;

        //        // 월별 날짜 컬럼 추가
        //        int lastColumn = 16;
        //        int columnIndex = lastColumn + 1;

        //        // 첫 번째 일반 데이터 행 찾기
        //        ShipSchedule firstNonCapeData = null;
        //        foreach (ShipSchedule data in currentData)
        //        {
        //            if (data.S_KIND != "CAPE 중일정개수" &&
        //                data.S_KIND != "CAPE 조정 개수" &&
        //                data.S_KIND != "CAPE 조정결과개수")
        //            {
        //                firstNonCapeData = data;
        //                break;
        //            }
        //        }

        //        if (firstNonCapeData != null && firstNonCapeData.MonthlyDates != null)
        //        {
        //            // 각 월별 데이터 처리
        //            for (int monthIndex = 0; monthIndex < firstNonCapeData.MonthlyDates.Count; monthIndex++)
        //            {
        //                List<DateCell> monthDates = (List<DateCell>)firstNonCapeData.MonthlyDates[monthIndex];
        //                if (monthDates != null && monthDates.Count > 0)
        //                {
        //                    DateTime currentMonth = new DateTime(
        //                        firstNonCapeData.WKSTPLDT1.Year,
        //                        firstNonCapeData.WKSTPLDT1.Month, 1).AddMonths(monthIndex);

        //                    // 월 헤더 병합 및 설정
        //                    range = worksheet.Range[
        //                        worksheet.Cells[1, columnIndex],
        //                        worksheet.Cells[1, columnIndex + monthDates.Count - 1]
        //                    ];
        //                    range.Merge(Type.Missing);
        //                    range.Value2 = currentMonth.ToString("yyyy/MM");
        //                    range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        //                    range.Interior.ColorIndex = 15;
        //                    range.Font.Bold = true;

        //                    // 날짜 서브헤더 설정
        //                    for (int i = 0; i < monthDates.Count; i++)
        //                    {
        //                        worksheet.Cells[2, columnIndex + i].Value2 = monthDates[i].Day;
        //                        worksheet.Columns[columnIndex + i].ColumnWidth = 3;
        //                    }

        //                    columnIndex += monthDates.Count;
        //                }
        //            }
        //        }

        //        // 데이터 행 작성
        //        int row = 3;
        //        foreach (ShipSchedule item in currentData)
        //        {
        //            // CAPE 조정 개수 행은 건너뛰기
        //            if (item.S_KIND == "CAPE 조정 개수")
        //                continue;

        //            // 기본 데이터 설정
        //            worksheet.Cells[row, 1].Value2 = item.S_KIND;
        //            worksheet.Cells[row, 2].Value2 = item.S_TYPE;
        //            worksheet.Cells[row, 3].Value2 = item.OWNER;
        //            worksheet.Cells[row, 4].Value2 = item.SHIP_DISP;
        //            worksheet.Cells[row, 5].Value2 = item.BLOCK;
        //            worksheet.Cells[row, 6].Value2 = item.STG_CD;
        //            worksheet.Cells[row, 7].Value2 = item.S_NAME;
        //            worksheet.Cells[row, 8].Value2 = item.MFG_IND;
        //            worksheet.Cells[row, 9].Value2 = item.LOC_DESC;
        //            worksheet.Cells[row, 10].Value2 = item.LOC_EQP;
        //            //worksheet.Cells[row, 12].Value2 = item.LOC_SOT;
        //            worksheet.Cells[row, 11].Value2 = item.WKSTPLDT.ToString("yyyy-MM-dd");
        //            worksheet.Cells[row, 12].Value2 = item.WKSTPLDT1.ToString("yyyy-MM-dd");
        //            worksheet.Cells[row, 13].Value2 = item.WKFIPLDT.ToString("yyyy-MM-dd");
        //            worksheet.Cells[row, 14].Value2 = item.WKFIPLDT1.ToString("yyyy-MM-dd");
        //            worksheet.Cells[row, 15].Value2 = item.ERECT_PLDT.ToString("yyyy-MM-dd");

        //            range = worksheet.Range[worksheet.Cells[row, 1], worksheet.Cells[row, 16]];
        //            range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        //            range.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;

        //            // 계획일정 음수 처리
        //            if (item.ColoredDaysCount < 0)
        //            {
        //                worksheet.Cells[row, 16].Font.ColorIndex = 3;
        //            }

        //            // CAPE 행 스타일 설정
        //            if (item.S_KIND == "CAPE 중일정개수" || item.S_KIND == "CAPE 조정결과개수")
        //            {
        //                range.Interior.ColorIndex = 15;
        //                range.Font.ColorIndex = 1;
        //            }

        //            // 월별 데이터 처리
        //            if (item.MonthlyDates != null)
        //            {
        //                int currentColumn = lastColumn + 1;
        //                foreach (List<DateCell> monthDates in item.MonthlyDates)
        //                {
        //                    if (monthDates != null)
        //                    {
        //                        for (int i = 0; i < monthDates.Count; i++)
        //                        {
        //                            Excel.Range dateCell = worksheet.Cells[row, currentColumn + i];

        //                            if (item.S_KIND == "CAPE 중일정개수" || item.S_KIND == "CAPE 조정결과개수")
        //                            {
        //                                dateCell.Value2 = monthDates[i].Day;
        //                                dateCell.Interior.ColorIndex = 15;
        //                            }
        //                            else
        //                            {
        //                                if (monthDates[i].Color == Brushes.Orange)
        //                                {
        //                                    dateCell.Interior.ColorIndex = 45;
        //                                }
        //                                else if (monthDates[i].Color == Brushes.Crimson)
        //                                {
        //                                    dateCell.Interior.ColorIndex = 3;
        //                                }
        //                            }

        //                            dateCell.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
        //                            dateCell.VerticalAlignment = Excel.XlVAlign.xlVAlignCenter;
        //                        }
        //                        currentColumn += monthDates.Count;
        //                    }
        //                }
        //            }
        //            row++;
        //        }

        //        // 전체 테두리 설정
        //        range = worksheet.Range[
        //            worksheet.Cells[1, 1],
        //            worksheet.Cells[row - 1, columnIndex - 1]
        //        ];
        //        range.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;

        //        // 기본 열 너비 자동 조정
        //        range = worksheet.Range["A:P"];
        //        range.EntireColumn.AutoFit();

        //        workbook.SaveAs(saveFileDialog.FileName, Excel.XlFileFormat.xlWorkbookNormal);
        //        MessageBox.Show("Excel 파일이 성공적으로 저장되었습니다.", "INFO(정보)/저장완료");
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Excel 저장 중 오류가 발생했습니다:\n" + ex.Message, "ERROR(오류)/Excel저장실패");
        //    }
        //    finally
        //    {
        //        if (range != null)
        //            Marshal.ReleaseComObject(range);
        //        if (worksheet != null)
        //            Marshal.ReleaseComObject(worksheet);
        //        if (workbook != null)
        //        {
        //            workbook.Close(true, Type.Missing, Type.Missing);
        //            Marshal.ReleaseComObject(workbook);
        //        }
        //        if (excelApp != null)
        //        {
        //            excelApp.ScreenUpdating = true;
        //            excelApp.EnableEvents = true;
        //            excelApp.DisplayAlerts = true;
        //            excelApp.Quit();
        //            Marshal.ReleaseComObject(excelApp);
        //        }
        //        GC.Collect();
        //        GC.WaitForPendingFinalizers();
        //    }
        //}
        private void ExportButton_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Excel Files (*.xls)|*.xls";
            saveFileDialog.DefaultExt = "xls";
            saveFileDialog.FileName = "ShipSchedule_" + DateTime.Now.ToString("yyyyMMdd");

            if (saveFileDialog.ShowDialog() != true)
                return;

            var progressWindow = new Window()
            {
                Title = "엑셀 저장 중...",
                Width = 300,
                Height = 100,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                ResizeMode = ResizeMode.NoResize
            };

            var progressBar = new ProgressBar()
            {
                Width = 280,
                Height = 20,
                Margin = new Thickness(10),
                IsIndeterminate = true
            };

            progressWindow.Content = progressBar;
            progressWindow.Show();

            BackgroundWorker worker = new BackgroundWorker();
            worker.DoWork += delegate
            {
                Excel.Application excelApp = null;
                Excel.Workbook workbook = null;
                Excel.Worksheet worksheet = null;
                Excel.Range range = null;

                try
                {
                    excelApp = new Excel.Application();
                    excelApp.ScreenUpdating = false;
                    excelApp.EnableEvents = false;
                    excelApp.DisplayAlerts = false;

                    workbook = excelApp.Workbooks.Add(true);
                    worksheet = (Excel.Worksheet)workbook.Sheets[1];

                    // 기본 헤더 작성
                    string[] headers = new string[] {
                "선종(S_KIND)", "선형(S_TYPE)", "선주사(OWNER)", 
                "호선(SHIP_DISP)", "블록(BLOCK)", "STAGE(STG_CD)", 
                "구획 이름(S_NAME)", "사업장(MFG_IND)", "PE장소(LOC_DESC)",
                "PE장비(LOC_EQP)", "PE구분(PE_TYPE)", "계획공기(DUR)", 
                "착수실적일(WKSTPLDT)", "시작 계획일(WKSTPLDT1)", 
                "완료계획일(WKFIPLDT)", "완료실적일(WKFIPLDT1)", 
                "탑재계획일(ERECT_PLDT)"
            };

                    // 열 너비 설정
                    for (int i = 1; i <= headers.Length; i++)
                    {
                        worksheet.Columns[i].ColumnWidth = 15;
                    }

                    // UI의 데이터 가져오기
                    List<ShipSchedule> currentData = ShipDataGrid.ItemsSource as List<ShipSchedule>;
                    object[,] dataArray = new object[currentData.Count + 1, headers.Length];

                    // 헤더 복사
                    for (int i = 0; i < headers.Length; i++)
                        dataArray[0, i] = headers[i];

                    // 모든 데이터 복사 (UI에 표시된 그대로)
                    int rowIndex = 1;
                    foreach (ShipSchedule item in currentData)
                    {
                        dataArray[rowIndex, 0] = item.S_KIND;
                        dataArray[rowIndex, 1] = item.S_TYPE;
                        dataArray[rowIndex, 2] = item.OWNER;
                        dataArray[rowIndex, 3] = item.SHIP_DISP;
                        dataArray[rowIndex, 4] = item.BLOCK;
                        dataArray[rowIndex, 5] = item.STG_CD;
                        dataArray[rowIndex, 6] = item.S_NAME;
                        dataArray[rowIndex, 7] = item.MFG_IND;
                        dataArray[rowIndex, 8] = item.LOC_DESC;
                        dataArray[rowIndex, 9] = item.LOC_EQP;
                        dataArray[rowIndex, 10] = item.PE_TYPE;
                        dataArray[rowIndex, 11] = item.Dur;
                        dataArray[rowIndex, 12] = item.WKSTPLDT.ToString("yyyy-MM-dd");
                        dataArray[rowIndex, 13] = item.WKSTPLDT1.ToString("yyyy-MM-dd");
                        dataArray[rowIndex, 14] = item.WKFIPLDT.ToString("yyyy-MM-dd");
                        dataArray[rowIndex, 15] = item.WKFIPLDT1.ToString("yyyy-MM-dd");
                        dataArray[rowIndex, 16] = item.ERECT_PLDT.ToString("yyyy-MM-dd");

                        // LOAD 관련 행은 회색 배경으로 설정
                        if (item.S_KIND.StartsWith("LOAD"))
                        {
                            range = worksheet.Range[
                                worksheet.Cells[rowIndex + 1, 1],
                                worksheet.Cells[rowIndex + 1, headers.Length]
                            ];
                            range.Interior.ColorIndex = 15;
                        }

                        rowIndex++;
                    }

                    // 데이터 일괄 쓰기
                    range = worksheet.Range["A1"].Resize[rowIndex, headers.Length];
                    range.Value2 = dataArray;

                    // 헤더 스타일링
                    range = worksheet.Range["A1", Type.Missing].Resize[1, headers.Length];
                    range.Font.Bold = true;
                    range.Interior.ColorIndex = 15;
                    range.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                    // 날짜 데이터가 있는 월별 컬럼 처리
                    ShipSchedule firstSchedule = null;
                    foreach (ShipSchedule schedule in currentData)
                    {
                        if (!schedule.S_KIND.StartsWith("LOAD") && schedule.MonthlyDates != null)
                        {
                            firstSchedule = schedule;
                            break;
                        }
                    }

                    if (firstSchedule != null && firstSchedule.MonthlyDates != null)
                    {
                        int currentColumn = headers.Length + 1;

                        for (int monthIndex = 0; monthIndex < firstSchedule.MonthlyDates.Count; monthIndex++)
                        {
                            List<DateCell> monthDates = firstSchedule.MonthlyDates[monthIndex] as List<DateCell>;
                            if (monthDates != null)
                            {
                                // 월 헤더
                                range = worksheet.Range[
                                    worksheet.Cells[1, currentColumn],
                                    worksheet.Cells[1, currentColumn + monthDates.Count - 1]
                                ];
                                range.Merge();
                                range.Value2 = firstSchedule.WKSTPLDT1.AddMonths(monthIndex).ToString("yyyy/MM");
                                range.Interior.ColorIndex = 15;
                                range.Font.Bold = true;

                                // 날짜별 데이터
                                for (rowIndex = 0; rowIndex < currentData.Count; rowIndex++)
                                {
                                    var schedule = currentData[rowIndex];
                                    if (schedule.MonthlyDates != null && monthIndex < schedule.MonthlyDates.Count)
                                    {
                                        var dates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
                                        for (int dayIndex = 0; dayIndex < dates.Count; dayIndex++)
                                        {
                                            worksheet.Cells[rowIndex + 2, currentColumn + dayIndex].Value2 = dates[dayIndex].Day;

                                            // 색상 설정
                                            if (schedule.S_KIND.StartsWith("LOAD"))
                                            {
                                                worksheet.Cells[rowIndex + 2, currentColumn + dayIndex].Interior.ColorIndex = 15;
                                            }
                                            else if (dates[dayIndex].Color == Brushes.Orange)
                                            {
                                                worksheet.Cells[rowIndex + 2, currentColumn + dayIndex].Interior.ColorIndex = 45;
                                            }
                                            else if (dates[dayIndex].Color == Brushes.Crimson)
                                            {
                                                worksheet.Cells[rowIndex + 2, currentColumn + dayIndex].Interior.ColorIndex = 3;
                                            }
                                        }
                                    }
                                }

                                currentColumn += monthDates.Count;
                            }
                        }
                    }

                    workbook.SaveAs(saveFileDialog.FileName, Excel.XlFileFormat.xlWorkbookNormal);
                }
                finally
                {
                    if (range != null) Marshal.ReleaseComObject(range);
                    if (worksheet != null) Marshal.ReleaseComObject(worksheet);
                    if (workbook != null)
                    {
                        workbook.Close(true);
                        Marshal.ReleaseComObject(workbook);
                    }
                    if (excelApp != null)
                    {
                        excelApp.Quit();
                        Marshal.ReleaseComObject(excelApp);
                    }
                }
            };

            worker.RunWorkerCompleted += delegate
            {
                progressWindow.Close();
                MessageBox.Show("Excel 파일이 성공적으로 저장되었습니다.", "저장 완료");
            };

            worker.RunWorkerAsync();
        }

        // 데이터 로드 후 DatePicker 초기 데이터 설정
        private void SetInitialDatePickerRange()
        {
            if (allData != null && allData.Count > 0)
            {
                // LOAD 관련 행 제외하고 실제 스케줄 데이터만 필터링
                var schedules = allData.Where(s =>
                    s.S_KIND != "LOAD 중일정개수" &&
                    s.S_KIND != "LOAD 조정결과개수").ToList();

                if (schedules.Any())
                {
                    // 시작 계획일 중 가장 빠른 날짜
                    DateTime minDate = schedules.Min(s => s.WKSTPLDT1);

                    // 완료 계획일 중 가장 늦은 날짜
                    DateTime maxDate = schedules.Max(s => s.WKFIPLDT);

                    // DatePicker에 초기 날짜 범위 설정
                    StartDatePicker.SelectedDate = minDate;
                    EndDatePicker.SelectedDate = maxDate;
                }
            }
        }


        //private void ProcessAndDisplayData(List<ShipSchedule> data)
        public void ProcessAndDisplayData(List<ShipSchedule> data)
        {
            if (data == null || data.Count == 0)
            {
                ShipDataGrid.ItemsSource = null;
                return;
            }

            ShipDataGrid.Columns.Clear();
            AddTextColumns();

            // 최소/최대 날짜 찾기
            DateTime minDate = DateTime.MaxValue;
            DateTime maxDate = DateTime.MinValue;

            foreach (ShipSchedule schedule in data)
            {
                if (schedule != null && schedule.S_KIND != "LOAD 중일정개수" &&
                    schedule.S_KIND != "LOAD 조정 개수" && schedule.S_KIND != "LOAD 조정결과개수")
                {
                    if (schedule.WKSTPLDT1 < minDate)
                        minDate = schedule.WKSTPLDT1;
                    if (schedule.WKFIPLDT > maxDate)
                        maxDate = schedule.WKFIPLDT;
                }
            }

            // 모든 월 목록 생성
            ArrayList monthList = new ArrayList();
            DateTime currentDate = new DateTime(minDate.Year, minDate.Month, 1);

            while (currentDate <= new DateTime(maxDate.Year, maxDate.Month, 1))
            {
                // 각 월별 정보 저장
                DateTime monthStart = currentDate;
                DateTime monthEnd = currentDate.AddMonths(1).AddDays(-1);

                // 각 일정에 대해 해당 월의 날짜 데이터 생성
                foreach (ShipSchedule schedule in data)
                {
                    if (schedule.S_KIND != "LOAD 중일정개수" &&
                        schedule.S_KIND != "LOAD 조정 개수" &&
                        schedule.S_KIND != "LOAD 조정결과개수")
                    {
                        if (schedule.MonthlyDates == null)
                        {
                            schedule.MonthlyDates = new ArrayList();
                        }

                        List<DateCell> monthDates = GenerateDateCells(
                            schedule.WKSTPLDT1,
                            monthStart,
                            monthEnd,
                            schedule
                        );

                        schedule.MonthlyDates.Add(monthDates);
                    }
                }

                // 각 월별 컬럼 생성
                DataGridTemplateColumn monthColumn = new DataGridTemplateColumn();
                monthColumn.Header = string.Format("{0}/{1:00}", currentDate.Year, currentDate.Month);
                monthColumn.Width = DateTime.DaysInMonth(currentDate.Year, currentDate.Month) * 20;

                monthColumn.HeaderTemplate = CreateMonthHeaderTemplate(
                    string.Format("{0}/{1:00}", currentDate.Year, currentDate.Month)
                );

                monthColumn.CellTemplate = CreateDateTemplate(
                    string.Format("MonthlyDates[{0}]", monthList.Count)
                );

                ShipDataGrid.Columns.Add(monthColumn);
                monthList.Add(currentDate);

                currentDate = currentDate.AddMonths(1);
            }

            // LOAD 중일정개수 행 생성
            ShipSchedule capeCountRow = new ShipSchedule
            {
                S_KIND = "LOAD 중일정개수",
                MonthlyDates = new ArrayList()
            };

            // CAPE 조정 개수 행 생성 (화면에는 표시되지 않지만 계산을 위해 유지)
            ShipSchedule capeAdjustRow = new ShipSchedule
            {
                S_KIND = "LOAD 조정 개수",
                MonthlyDates = new ArrayList()
            };

            // LOAD 조정결과개수 행 생성
            ShipSchedule capeResultRow = new ShipSchedule
            {
                S_KIND = "LOAD 조정결과개수",
                MonthlyDates = new ArrayList()
            };

            // 각 월별 LOAD 데이터 생성
            foreach (DateTime month in monthList)
            {
                int daysInMonth = DateTime.DaysInMonth(month.Year, month.Month);

                List<DateCell> countDates = new List<DateCell>();
                List<DateCell> adjustDates = new List<DateCell>();
                List<DateCell> resultDates = new List<DateCell>();

                // 해당 월의 각 날짜별로 데이터 생성
                for (int day = 1; day <= daysInMonth; day++)
                {
                    DateTime currentDay = new DateTime(month.Year, month.Month, day);

                    // 휴일 체크
                    if (!IsWorkingDay(currentDay))
                    {
                        // 휴일인 경우 모두 0으로 설정
                        countDates.Add(new DateCell
                        {
                            Day = "0",
                            Color = Brushes.LightGray
                        });

                        adjustDates.Add(new DateCell
                        {
                            Day = "0",
                            Color = Brushes.LightGray
                        });

                        resultDates.Add(new DateCell
                        {
                            Day = "0",
                            Color = Brushes.LightGray
                        });

                        continue;
                    }

                    // 중일정개수 계산
                    int overlappingCount = 0;
                    foreach (ShipSchedule schedule in data)
                    {
                        if (schedule.S_KIND != "LOAD 중일정개수" &&
                            schedule.S_KIND != "LOAD 조정 개수" &&
                            schedule.S_KIND != "LOAD 조정결과개수")
                        {
                            DateTime endDate = schedule.STG_CD == "90" ?
                                schedule.ERECT_PLDT : schedule.WKFIPLDT1;

                            if (currentDay >= schedule.WKSTPLDT1 && currentDay <= endDate)
                            {
                                overlappingCount++;
                            }
                        }
                    }

                    // LOAD 중일정개수 셀 추가
                    DateCell countCell = new DateCell
                    {
                        Day = overlappingCount.ToString(),
                        Color = Brushes.LightGray
                    };
                    countDates.Add(countCell);

                    // LOAD 조정 개수는 초기에 0으로 설정
                    DateCell adjustCell = new DateCell
                    {
                        Day = "0",
                        Color = Brushes.LightGray
                    };
                    adjustDates.Add(adjustCell);

                    // LOAD 조정결과개수 (중일정개수 - 조정개수)
                    DateCell resultCell = new DateCell
                    {
                        Day = overlappingCount.ToString(), // 초기값은 중일정개수와 동일
                        Color = Brushes.LightGray
                    };
                    resultDates.Add(resultCell);
                }

                capeCountRow.MonthlyDates.Add(countDates);
                capeAdjustRow.MonthlyDates.Add(adjustDates);
                capeResultRow.MonthlyDates.Add(resultDates);
            }

            // 최종 데이터 생성 (CAPE 조정 개수 행 제외)
            List<ShipSchedule> finalData = new List<ShipSchedule>(data);
            finalData.Add(capeCountRow);
            // capeAdjustRow는 화면에 표시하지 않음
            finalData.Add(capeResultRow);

            // DataGrid에 데이터 바인딩
            ShipDataGrid.ItemsSource = finalData;
            List<ShipSchedule> capeData = new List<ShipSchedule>();

            // CAPE 행들만 추출하여 ShipDataGrid1에 바인딩
            var capeRows = finalData.Where(x => x.S_KIND == "LOAD 중일정개수" || x.S_KIND == "LOAD 조정결과개수").ToList();

            // ShipDataGrid1 컬럼 초기화
            ShipDataGrid1.Columns.Clear();

            //CASE 컬럼 추가
            DataGridTextColumn caseColumn = new DataGridTextColumn();
            caseColumn.Header = "CASE";
            caseColumn.Binding = new Binding("S_KIND");
            caseColumn.Width = 150;
            ShipDataGrid1.Columns.Add(caseColumn);

            SetInitialDatePickerRange();
            // 월별 컬럼 추가 (monthList 재사용)
            foreach (DateTime month in monthList)
            {
                DataGridTemplateColumn monthColumn = new DataGridTemplateColumn();
                monthColumn.Header = string.Format("{0}/{1:00}", month.Year, month.Month);
                monthColumn.Width = DateTime.DaysInMonth(month.Year, month.Month) * 20;
                monthColumn.HeaderTemplate = CreateMonthHeaderTemplate(string.Format("{0}/{1:00}", month.Year, month.Month));
                monthColumn.CellTemplate = CreateDateTemplate(string.Format("MonthlyDates[{0}]", monthList.IndexOf(month)));
                ShipDataGrid1.Columns.Add(monthColumn);
            }

            ShipDataGrid1.ItemsSource = capeRows;
        }



        private void LineLoadGraphButton_Click(object sender, RoutedEventArgs e)
        {
            // 항상 일반 모드로 설정
            MainGrid.RowDefinitions[1].Height = new GridLength(5.5, GridUnitType.Star); // ShipDataGrid (90%)
            MainGrid.RowDefinitions[3].Height = new GridLength(1, GridUnitType.Star);  // ShipDataGrid1 (10%)

            // 먼저 일반 모드로 변경
            CHButton_Click(sender, e);

            var displayedData = ShipDataGrid.ItemsSource as List<ShipSchedule>;
            if (displayedData != null && displayedData.Count > 0)
            {
                // 최소/최대 날짜 찾기
                DateTime minDate = DateTime.MaxValue;
                DateTime maxDate = DateTime.MinValue;

                // LOAD 데이터를 저장할 Dictionary
                Dictionary<DateTime, Tuple<int, int>> capeData = new Dictionary<DateTime, Tuple<int, int>>();

                // 최소/최대 날짜 찾기
                foreach (ShipSchedule schedule in displayedData)
                {
                    if (schedule != null && schedule.S_KIND != "LOAD 중일정개수" &&
                        schedule.S_KIND != "LOAD 조정 개수" && schedule.S_KIND != "LOAD 조정결과개수")
                    {
                        if (schedule.WKSTPLDT1 < minDate)
                            minDate = schedule.WKSTPLDT1;
                        if (schedule.WKSTPLDT1 > maxDate)
                            maxDate = schedule.WKSTPLDT1;
                    }
                }
                // `maxDate`를 한 달 추가
                maxDate = maxDate.AddMonths(1);

                // 각 날짜별 CAPE 데이터 수집
                for (DateTime date = minDate; date <= maxDate; date = date.AddDays(1))
                {
                    // 주말과 공휴일은 제외
                    if (!IsWorkingDay(date))
                        continue;

                    int originalCapeCount = 0;
                    int adjustedCapeCount = 0;

                    foreach (ShipSchedule schedule in displayedData)
                    {
                        if (schedule != null &&
                            schedule.S_KIND != "LOAD 중일정개수" &&
                            schedule.S_KIND != "LOAD 조정 개수" &&
                            schedule.S_KIND != "LOAD 조정결과개수")
                        {
                            DateTime endDate = schedule.STG_CD == "90" ? schedule.ERECT_PLDT : schedule.WKFIPLDT1;

                            if (date >= schedule.WKSTPLDT1 && date <= endDate)
                            {
                                originalCapeCount++;

                                // Crimson 색상 체크
                                bool isCrimsonDate = false;
                                if (schedule.MonthlyDates != null)
                                {
                                    foreach (List<DateCell> monthDates in schedule.MonthlyDates)
                                    {
                                        if (monthDates != null)
                                        {
                                            foreach (DateCell cell in monthDates)
                                            {
                                                if (cell.Day == date.Day.ToString("00") && cell.Color == Brushes.Crimson)
                                                {
                                                    isCrimsonDate = true;
                                                    break;
                                                }
                                            }
                                        }
                                        if (isCrimsonDate) break;
                                    }
                                }

                                if (!isCrimsonDate)
                                {
                                    adjustedCapeCount++;
                                }
                            }
                        }
                    }

                    // 모든 날짜의 데이터 저장 (0인 경우도 포함)
                    capeData[date] = new Tuple<int, int>(originalCapeCount, adjustedCapeCount);
                }

                // 추가로 본사, 온산, 해양별 LOAD 데이터 수집
                Dictionary<string, Dictionary<DateTime, Tuple<int, int>>> locationCapeData =
                    new Dictionary<string, Dictionary<DateTime, Tuple<int, int>>>();

                // 위치 초기화
                locationCapeData["본사"] = new Dictionary<DateTime, Tuple<int, int>>();
                locationCapeData["온산"] = new Dictionary<DateTime, Tuple<int, int>>();
                locationCapeData["해양"] = new Dictionary<DateTime, Tuple<int, int>>();

                // LOAD 행 타입들
                string[] loadTypes = new string[] { 
            "LOAD 중일정개수(본사)", 
            "LOAD 조정결과개수(본사)", 
            "LOAD 중일정개수(온산)", 
            "LOAD 조정결과개수(온산)", 
            "LOAD 중일정개수(해양)", 
            "LOAD 조정결과개수(해양)" 
        };

                // 각 LOAD 행 순회
                foreach (string loadType in loadTypes)
                {
                    ShipSchedule loadRow = null;
                    for (int i = 0; i < displayedData.Count; i++)
                    {
                        if (displayedData[i].S_KIND == loadType)
                        {
                            loadRow = displayedData[i];
                            break;
                        }
                    }

                    if (loadRow != null && loadRow.MonthlyDates != null)
                    {
                        // 위치 결정
                        string location = loadType.Contains("본사") ? "본사" :
                                          loadType.Contains("온산") ? "온산" : "해양";

                        // 월별 순회
                        for (int monthIndex = 0; monthIndex < loadRow.MonthlyDates.Count; monthIndex++)
                        {
                            DateTime monthStart = loadRow.WKSTPLDT1.AddMonths(monthIndex);
                            List<DateCell> monthDates = loadRow.MonthlyDates[monthIndex] as List<DateCell>;

                            if (monthDates != null)
                            {
                                // 일자별 순회
                                for (int dayIndex = 0; dayIndex < monthDates.Count; dayIndex++)
                                {
                                    DateTime currentDate = monthStart.AddDays(dayIndex);
                                    int loadValue = 0;

                                    // 문자열을 정수로 변환 시도
                                    if (int.TryParse(monthDates[dayIndex].Day, out loadValue))
                                    {
                                        // 해당 날짜의 데이터가 없으면 추가
                                        if (!locationCapeData[location].ContainsKey(currentDate))
                                        {
                                            locationCapeData[location][currentDate] =
                                                new Tuple<int, int>(loadValue, loadValue);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                var graphWindow = new LineLoadGraphWindow(minDate, maxDate, capeData, locationCapeData);
                graphWindow.Owner = this;
                graphWindow.Closed += LineLoadGraphWindow_Closed;  // 기존 이벤트 핸들러 유지
                graphWindow.Show();
                isLineLoadGraphLoaded = true;
            }
            else
            {
                MessageBox.Show("표시할 데이터가 없습니다.", "알림", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // LineLoadGraphWindow가 닫힐 때 처리
        private void LineLoadGraphWindow_Closed(object sender, EventArgs e)
        {
            isLineLoadGraphLoaded = false;
            //PeApplyButton.IsEnabled = false;
            PeApplyButton.IsEnabled = true;
            PeApplyButton.ToolTip = "MAX 부하 그래프 화면을 먼저 실행해주세요.";
        }

        // DateCapeCount 클래스 추가
        public class DateCapeCount
        {
            public int Count { get; set; }
            public DateTime Date { get; set; }
        }

        private List<DateCell> GenerateDateCells(DateTime startDate, DateTime rangeStart, DateTime rangeEnd, ShipSchedule schedule)
        {
            List<DateCell> dates = new List<DateCell>();
            DateTime currentDate = rangeStart;

            DateTime effectiveEndDate = schedule.STG_CD == "90" ? schedule.ERECT_PLDT : schedule.WKFIPLDT;

            while (currentDate <= rangeEnd)
            {
                DateCell cell = new DateCell();
                cell.Day = currentDate.Day.ToString("00");

                if (schedule.S_KIND == "LOAD 중일정개수" ||
                    schedule.S_KIND == "LOAD 조정 개수" ||
                    schedule.S_KIND == "LOAD 조정결과개수")
                {
                    cell.Color = Brushes.White;
                }
                else
                {
                    bool isInRange = (currentDate.Date >= startDate.Date &&
                                      currentDate.Date <= effectiveEndDate.Date);

                    // 평일이고 날짜 범위 안에 있을 때만 색상 설정
                    if (isInRange && IsWorkingDay(currentDate))
                    {
                        cell.Color = Brushes.Orange;
                    }
                    else
                    {
                        cell.Color = Brushes.White;
                    }
                }

                dates.Add(cell);
                currentDate = currentDate.AddDays(1);
            }

            return dates;
        }



        // 기본 텍스트 컬럼 추가 메서드
        //private void AddTextColumns()
        //{
        //    // 체크박스 컬럼 추가
        //    DataGridTemplateColumn checkColumn = new DataGridTemplateColumn();
        //    checkColumn.Header = "CASE";
        //    checkColumn.Width = 40;

        //    // 체크박스를 위한 데이터 템플릿 생성
        //    FrameworkElementFactory checkBoxElement = new FrameworkElementFactory(typeof(CheckBox));
        //    checkBoxElement.SetBinding(CheckBox.IsCheckedProperty, new Binding("IsSelected") { Mode = BindingMode.TwoWay });
        //    checkBoxElement.SetValue(CheckBox.HorizontalAlignmentProperty, HorizontalAlignment.Center);
        //    checkBoxElement.SetValue(CheckBox.VerticalAlignmentProperty, VerticalAlignment.Center);
        //    checkBoxElement.SetValue(CheckBox.IsEnabledProperty, false);
        //    checkBoxElement.SetValue(CheckBox.OpacityProperty, 0.8);

        //    DataTemplate checkTemplate = new DataTemplate();
        //    checkTemplate.VisualTree = checkBoxElement;

        //    checkColumn.CellTemplate = checkTemplate;
        //    ShipDataGrid.Columns.Add(checkColumn);

        //    // 읽기 전용 컬럼들
        //    AddColumn("선종(S_KIND)", "S_KIND", null, true);
        //    AddColumn("선형(S_TYPE)", "S_TYPE", null, true);
        //    AddColumn("선주사(OWNER)", "OWNER", null, true);
        //    AddColumn("호선(SHIP_DISP)", "SHIP_DISP", null, true);
        //    AddColumn("블록(BLOCK)", "BLOCK", null, true);
        //    AddColumn("STAGE(STG_CD)", "STG_CD", null, true);
        //    AddColumn("구획 이름(S_NAME)", "S_NAME", null, true);
        //    AddColumn("사업장(MFG_IND)", "MFG_IND", null, true);
        //    AddColumn("PE장소(LOC_DESC)", "LOC_DESC", null, true);
        //    AddColumn("PE장비(LOC_EQP)", "LOC_EQP", null, true);
        //    AddColumn("PE구분(LOC_SOT)", "PE_TYPE", null, true);

        //    // 착수실적일 컬럼
        //    AddColumn("착수실적일", "WKSTPLDT", "yyyy-MM-dd", false);

        //    // 시작계획일 컬럼 - 특별 스타일 적용
        //    var startDateColumn = new DataGridTextColumn();
        //    startDateColumn.Header = "시작계획일\n(WKSTPLDT1)";
        //    startDateColumn.Width = 100;
        //    startDateColumn.Binding = new Binding("WKSTPLDT1") { StringFormat = "yyyy-MM-dd" };
        //    startDateColumn.IsReadOnly = false;

        //    // 완료계획일 컬럼 - 특별 스타일 적용
        //    var completionDateColumn = new DataGridTextColumn();
        //    completionDateColumn.Header = "완료계획일\n(WKFIPLDT)";
        //    completionDateColumn.Width = 100;
        //    completionDateColumn.Binding = new Binding("WKFIPLDT") { StringFormat = "yyyy-MM-dd" };
        //    completionDateColumn.IsReadOnly = false;

        //    // 시작계획일 스타일 설정
        //    Style startDateStyle = new Style(typeof(TextBlock));

        //    // 기본 정렬 설정
        //    startDateStyle.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Center));

        //    // 탑재계획일 컬럼 - 특별 스타일 적용
        //    var erectDateColumn = new DataGridTextColumn();
        //    erectDateColumn.Header = "탑재계획일\n(ERECT_PLDT)";
        //    erectDateColumn.Width = 100;
        //    erectDateColumn.Binding = new Binding("ERECT_PLDT") { StringFormat = "yyyy-MM-dd" };
        //    erectDateColumn.IsReadOnly = false;

        //    // 탑재계획일 스타일 설정
        //    Style erectDateStyle = new Style(typeof(TextBlock));
        //    erectDateStyle.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Center));

        //    // 수정된 날짜 표시를 위한 트리거
        //    DataTrigger startDateModifiedTrigger = new DataTrigger();
        //    startDateModifiedTrigger.Binding = new Binding("IsWKSTPLDT1Modified");
        //    startDateModifiedTrigger.Value = true;
        //    startDateModifiedTrigger.Setters.Add(new Setter(TextBlock.ForegroundProperty, Brushes.Red));
        //    startDateStyle.Triggers.Add(startDateModifiedTrigger);

        //    startDateColumn.ElementStyle = startDateStyle;
        //    ShipDataGrid.Columns.Add(startDateColumn);

        //    // 수정된 날짜 표시를 위한 트리거
        //    DataTrigger erectDateModifiedTrigger = new DataTrigger();
        //    erectDateModifiedTrigger.Binding = new Binding("IsERPLDTModified");
        //    erectDateModifiedTrigger.Value = true;
        //    erectDateModifiedTrigger.Setters.Add(new Setter(TextBlock.ForegroundProperty, Brushes.Blue));
        //    erectDateStyle.Triggers.Add(erectDateModifiedTrigger);

        //    erectDateColumn.ElementStyle = erectDateStyle;
        //    ShipDataGrid.Columns.Add(erectDateColumn);
        //    // 완료계획일 스타일 설정
        //    Style completionDateStyle = new Style(typeof(TextBlock));
        //    completionDateStyle.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Center));

        //    // 수정된 날짜 표시를 위한 트리거
        //    DataTrigger completionDateModifiedTrigger = new DataTrigger();
        //    completionDateModifiedTrigger.Binding = new Binding("IsWKFIPLDTModified");
        //    completionDateModifiedTrigger.Value = true;
        //    completionDateModifiedTrigger.Setters.Add(new Setter(TextBlock.ForegroundProperty, Brushes.Blue));
        //    completionDateStyle.Triggers.Add(completionDateModifiedTrigger);
        //    // 사업장 변경시 진행
        //    Style mfgStyle = new Style(typeof(TextBlock));
        //    mfgStyle.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Center));

        //    DataTrigger mfgModifiedTrigger = new DataTrigger();
        //    mfgModifiedTrigger.Binding = new Binding("IsMfgModified");
        //    mfgModifiedTrigger.Value = true;
        //    mfgModifiedTrigger.Setters.Add(new Setter(TextBlock.ForegroundProperty, Brushes.Red));

        //    mfgStyle.Triggers.Add(mfgModifiedTrigger);
        //    AddColumn("Header", "Binding", "Format", true, Brushes.Red);



        //    completionDateColumn.ElementStyle = completionDateStyle;
        //    ShipDataGrid.Columns.Add(completionDateColumn);

        //    // 나머지 날짜 컬럼들

        //    AddColumn("완료실적일(WKFIPLDT1)", "WKFIPLDT1", "yyyy-MM-dd", false);


        //    // 계획일정(일수) 컬럼
        //    DataGridTextColumn daysColumn = new DataGridTextColumn();
        //    daysColumn.Header = "계획일정(일수)";
        //    daysColumn.Binding = new Binding("ColoredDaysCount");
        //    daysColumn.IsReadOnly = true;

        //    // 음수일 때 붉은색으로 표시하기 위한 스타일 설정
        //    Style daysStyle = new Style(typeof(TextBlock));
        //    Binding colorBinding = new Binding("ColoredDaysCount");
        //    colorBinding.Converter = new ColoredDaysCountConverter();
        //    daysStyle.Setters.Add(new Setter(TextBlock.ForegroundProperty, colorBinding));
        //    daysStyle.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Center));
        //    daysColumn.ElementStyle = daysStyle;

        //    ShipDataGrid.Columns.Add(daysColumn);
        //}

        private void AddTextColumns()
        {
            // 체크박스 컬럼 추가
            //DataGridTemplateColumn checkColumn = new DataGridTemplateColumn();
            //checkColumn.Header = "CASE";
            //checkColumn.Width = 40;

            // 체크박스를 위한 데이터 템플릿 생성
            FrameworkElementFactory checkBoxElement = new FrameworkElementFactory(typeof(CheckBox));
            checkBoxElement.SetBinding(CheckBox.IsCheckedProperty, new Binding("IsSelected") { Mode = BindingMode.TwoWay });
            checkBoxElement.SetValue(CheckBox.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            checkBoxElement.SetValue(CheckBox.VerticalAlignmentProperty, VerticalAlignment.Center);
            checkBoxElement.SetValue(CheckBox.IsEnabledProperty, false);
            checkBoxElement.SetValue(CheckBox.OpacityProperty, 0.8);

            DataTemplate checkTemplate = new DataTemplate();
            checkTemplate.VisualTree = checkBoxElement;

            //checkColumn.CellTemplate = checkTemplate;
            //ShipDataGrid.Columns.Add(checkColumn);

            // 읽기 전용 컬럼들
            AddColumn("선종(S_KIND)", "S_KIND", null, true);
            AddColumn("선형(S_TYPE)", "S_TYPE", null, true);
            AddColumn("선주사(OWNER)", "OWNER", null, true);
            AddColumn("호선(SHIP_DISP)", "SHIP_DISP", null, true);
            AddColumn("블록(BLOCK)", "BLOCK", null, true);
            AddColumn("STAGE(STG_CD)", "STG_CD", null, true);
            AddColumn("구획 이름(S_NAME)", "S_NAME", null, true);

            // **사업장(MFG_IND) 컬럼 추가**
            DataGridTextColumn mfgColumn1 = new DataGridTextColumn();
            mfgColumn1.Header = "사업장(MFG_IND(O))";
            mfgColumn1.Binding = new Binding("MFG_IND_After");
            mfgColumn1.IsReadOnly = true;

            // **사업장(MFG_IND) 컬럼 추가**
            DataGridTextColumn mfgColumn = new DataGridTextColumn();
            mfgColumn.Header = "사업장(MFG_IND(C))";
            mfgColumn.Binding = new Binding("MFG_IND");
            mfgColumn.IsReadOnly = true;


            // 스타일 설정
            Style mfgStyle = new Style(typeof(TextBlock));
            mfgStyle.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Center));

            // `IsMfgModified` 플래그가 true일 때 텍스트 색상 변경
            DataTrigger mfgModifiedTrigger = new DataTrigger();
            mfgModifiedTrigger.Binding = new Binding("IsMfgModified");
            mfgModifiedTrigger.Value = true;
            mfgModifiedTrigger.Setters.Add(new Setter(TextBlock.ForegroundProperty, Brushes.Red));

            // MFG_IND와 MFG_IND_After가 다를 때 텍스트 색상 변경하는 트리거
            DataTrigger mfgChangedTrigger = new DataTrigger();
            mfgChangedTrigger.Binding = new Binding("MFG_IND_After");
            mfgChangedTrigger.Value = null;
            mfgChangedTrigger.Setters.Add(new Setter(TextBlock.ForegroundProperty, Brushes.Black));

            DataTrigger mfgDifferentTrigger = new DataTrigger();
            mfgDifferentTrigger.Binding = new Binding("IsMfgModified");
            mfgDifferentTrigger.Value = true;
            mfgDifferentTrigger.Setters.Add(new Setter(TextBlock.ForegroundProperty, Brushes.Red));

            mfgStyle.Triggers.Add(mfgModifiedTrigger);
            mfgStyle.Triggers.Add(mfgChangedTrigger);
            mfgStyle.Triggers.Add(mfgDifferentTrigger);

            // 스타일 적용
            mfgColumn.ElementStyle = mfgStyle;
            ShipDataGrid.Columns.Add(mfgColumn);

            // 중앙 정렬만 적용
            Style mfgStyle1 = new Style(typeof(TextBlock));
            mfgStyle1.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Center));
            mfgColumn1.ElementStyle = mfgStyle1;
            ShipDataGrid.Columns.Add(mfgColumn1);

            AddColumn("PE장소(LOC_DESC)", "LOC_DESC", null, true);
            AddColumn("PE장비(LOC_EQP)", "LOC_EQP", null, true);
            AddColumn("PE구분(LOC_SOT)", "PE_TYPE", null, true);
            AddColumn("계획공기", "Dur", null, true);  // 계획공기 컬럼 추가

            // 착수실적일 컬럼
            AddColumn("착수실적일", "WKSTPLDT", "yyyy-MM-dd", false);

            // 시작계획일 컬럼
            var startDateColumn = new DataGridTextColumn();
            startDateColumn.Header = "시작계획일\n(WKSTPLDT1)";
            startDateColumn.Width = 100;
            startDateColumn.Binding = new Binding("WKSTPLDT1") { StringFormat = "yyyy-MM-dd" };
            startDateColumn.IsReadOnly = false;

            // 스타일 설정
            Style startDateStyle = new Style(typeof(TextBlock));
            startDateStyle.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Center));

            DataTrigger startDateModifiedTrigger = new DataTrigger();
            startDateModifiedTrigger.Binding = new Binding("IsWKSTPLDT1Modified");
            startDateModifiedTrigger.Value = true;
            startDateModifiedTrigger.Setters.Add(new Setter(TextBlock.ForegroundProperty, Brushes.Red));
            startDateStyle.Triggers.Add(startDateModifiedTrigger);

            startDateColumn.ElementStyle = startDateStyle;
            ShipDataGrid.Columns.Add(startDateColumn);

            // 완료계획일 컬럼
            var completionDateColumn = new DataGridTextColumn();
            completionDateColumn.Header = "완료계획일\n(WKFIPLDT)";
            completionDateColumn.Width = 100;
            completionDateColumn.Binding = new Binding("WKFIPLDT") { StringFormat = "yyyy-MM-dd" };
            completionDateColumn.IsReadOnly = false;

            Style completionDateStyle = new Style(typeof(TextBlock));
            completionDateStyle.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Center));

            DataTrigger completionDateModifiedTrigger = new DataTrigger();
            completionDateModifiedTrigger.Binding = new Binding("IsWKFIPLDTModified");
            completionDateModifiedTrigger.Value = true;
            completionDateModifiedTrigger.Setters.Add(new Setter(TextBlock.ForegroundProperty, Brushes.Blue));
            completionDateStyle.Triggers.Add(completionDateModifiedTrigger);

            completionDateColumn.ElementStyle = completionDateStyle;
            ShipDataGrid.Columns.Add(completionDateColumn);
            // 탑재계획일 컬럼 추가
            var erectDateColumn = new DataGridTextColumn();
            erectDateColumn.Header = "탑재계획일\n(ERECT_PLDT)";
            erectDateColumn.Width = 100;
            erectDateColumn.Binding = new Binding("ERECT_PLDT") { StringFormat = "yyyy-MM-dd" };
            erectDateColumn.IsReadOnly = false;

            Style erectDateStyle = new Style(typeof(TextBlock));
            erectDateStyle.Setters.Add(new Setter(TextBlock.TextAlignmentProperty, TextAlignment.Center));

            DataTrigger erectDateModifiedTrigger = new DataTrigger();
            erectDateModifiedTrigger.Binding = new Binding("IsERPLDTModified");
            erectDateModifiedTrigger.Value = true;
            erectDateModifiedTrigger.Setters.Add(new Setter(TextBlock.ForegroundProperty, Brushes.Blue));
            erectDateStyle.Triggers.Add(erectDateModifiedTrigger);

            //// 계획공기 컬럼 추가
            //DataGridTextColumn durationColumn = new DataGridTextColumn();
            //durationColumn.Header = "계획공기";
            //durationColumn.Binding = new Binding("Dur");
            //durationColumn.IsReadOnly = true;
            //ShipDataGrid.Columns.Add(durationColumn);


            erectDateColumn.ElementStyle = erectDateStyle;
            ShipDataGrid.Columns.Add(erectDateColumn);

        }

        // MainWindow 클래스에 추가할 메서드
        private void AllCheckBox_Click(object sender, RoutedEventArgs e)
        {
            bool isChecked = ((CheckBox)sender).IsChecked ?? false;
            foreach (ShipSchedule item in allData)
            {
                item.IsSelected = isChecked;
            }
            ShipDataGrid.Items.Refresh();
        }
        // 체크된 항목 처리 메서드
        private void ProcessCheckedItems()
        {
            StringBuilder message = new StringBuilder();
            int checkedCount = 0;

            foreach (ShipSchedule item in allData)
            {
                if (item.IsSelected)
                {
                    checkedCount++;
                    message.AppendFormat("{0}. 호선: {1}, 블록: {2}\n",
                        checkedCount, item.SHIP_DISP, item.BLOCK);
                }
            }

            if (checkedCount > 0)
            {
                message.Insert(0, string.Format("총 {0}개 항목이 선택되었습니다.\n\n", checkedCount));
                MessageBox.Show(message.ToString(), "선택항목 확인");
            }
            else
            {
                MessageBox.Show("선택된 항목이 없습니다.", "알림");
            }
        }

        // AddColumn 메서드 수정
        private void AddColumn(string header, string binding, string format = null, bool isReadOnly = true)
        {
            DataGridTextColumn column = new DataGridTextColumn();
            column.Header = header;
            column.IsReadOnly = isReadOnly; // 읽기 전용 여부 설정

            if (format != null)
                column.Binding = new Binding(binding) { StringFormat = format };
            else
                column.Binding = new Binding(binding);

            ShipDataGrid.Columns.Add(column);
        }

        private List<DateCell> GenerateMonthDates(DateTime startDate, DateTime endDate,
            DateTime rangeStart, DateTime rangeEnd)
        {
            List<DateCell> dates = new List<DateCell>();
            DateTime currentDate = rangeStart;

            while (currentDate <= rangeEnd)
            {
                Brush color = Brushes.White;
                if (currentDate >= startDate && currentDate <= endDate)
                {
                    color = Brushes.Orange;
                }

                DateCell cell = new DateCell();
                cell.Day = currentDate.Day.ToString("00");
                cell.Color = color;
                dates.Add(cell);

                currentDate = currentDate.AddDays(1);
            }

            return dates;
        }

        private int CountOrangeCells(List<DateCell> dates)
        {
            int count = 0;
            if (dates != null)
            {
                foreach (DateCell cell in dates)
                {
                    if (cell.Color == Brushes.Orange)
                    {
                        count++;
                    }
                }
            }
            return count;
        }

        private int GetMinMonth(List<ShipSchedule> data)
        {
            int minMonth = 12;
            foreach (ShipSchedule schedule in data)
            {
                if (schedule.WKSTPLDT1.Month < minMonth)
                    minMonth = schedule.WKSTPLDT1.Month;
            }
            return minMonth;
        }

        private int GetMaxMonth(List<ShipSchedule> data)
        {
            int maxMonth = 1;
            foreach (ShipSchedule schedule in data)
            {
                if (schedule.WKFIPLDT1.Month > maxMonth)
                    maxMonth = schedule.WKFIPLDT1.Month;
            }
            return maxMonth;
        }

        private DateTime GetMinStartDate(List<ShipSchedule> data, int month)
        {
            DateTime minDate = DateTime.MaxValue;
            foreach (ShipSchedule schedule in data)
            {
                if (schedule.WKSTPLDT1.Month == month && schedule.WKSTPLDT1 < minDate)
                    minDate = schedule.WKSTPLDT1;
            }
            return minDate;
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ComboBoxItem selectedMfgItem = MfgComboBox.SelectedItem as ComboBoxItem;
                ComboBoxItem selectedPeItem = PeComboBox.SelectedItem as ComboBoxItem;
                ComboBoxItem selectedPeEqpItem = PeEqpBox.SelectedItem as ComboBoxItem;
                ComboBoxItem selectedStageItem = STAGEComboBox.SelectedItem as ComboBoxItem;
                ComboBoxItem selectedPeTypeItem = PeTypeComboBox.SelectedItem as ComboBoxItem;

                string selectedMfg = selectedMfgItem != null ? selectedMfgItem.Content.ToString() : "전체";
                string selectedPe = selectedPeItem != null ? selectedPeItem.Content.ToString() : "전체";
                string selectedPeEqp = selectedPeEqpItem != null ? selectedPeEqpItem.Content.ToString() : "전체";
                string selectedStage = selectedStageItem != null ? selectedStageItem.Content.ToString() : "전체";
                string selectedPeType = selectedPeTypeItem != null ? selectedPeTypeItem.Content.ToString() : "전체";

                List<ShipSchedule> filteredData = new List<ShipSchedule>();

                foreach (ShipSchedule schedule in allData)
                {
                    // LOAD 관련 행은 그대로 추가
                    if (schedule.S_KIND == "LOAD 중일정개수" || schedule.S_KIND == "LOAD 조정결과개수")
                    {
                        filteredData.Add(schedule);
                        continue;
                    }

                    bool dateCondition = true;
                    if (StartDatePicker.SelectedDate.HasValue && EndDatePicker.SelectedDate.HasValue)
                    {
                        DateTime startDate = StartDatePicker.SelectedDate.Value;
                        DateTime endDate = EndDatePicker.SelectedDate.Value;
                        dateCondition = (schedule.WKSTPLDT1.Date >= startDate.Date &&
                                       schedule.WKSTPLDT1.Date <= endDate.Date);
                    }

                    bool mfgCondition = true;
                    if (selectedMfg != "전체")
                    {
                        if (selectedMfg == "본사,해양,온산")
                        {
                            mfgCondition = schedule.MFG_IND == "본사" || schedule.MFG_IND == "해양" || schedule.MFG_IND == "온산";
                        }
                        else
                        {
                            mfgCondition = schedule.MFG_IND == selectedMfg;
                        }
                    }

                    bool peCondition = true;
                    if (selectedPe != "전체")
                    {
                        // New condition: Exclude specific PE locations within Headquarters
                        if (selectedPe == "전체ALL 본사(1PE,2PE,3PE,4PE)")
                        {
                            // 본사의 경우: PE 장소가 이 4개에 없는 데이터 제외
                            if (schedule.MFG_IND == "본사")
                            {
                                peCondition = false;  // 기본적으로 제외

                                // 4개의 특정 PE 장소 중 하나라도 있으면 포함
                                if (schedule.LOC_DESC == "1D 서" ||
                                    schedule.LOC_DESC == "4D 동" ||
                                    schedule.LOC_DESC == "2 - 3D" ||
                                    schedule.LOC_DESC == "총조장")
                                {
                                    peCondition = true;
                                }
                            }
                            else
                            {
                                // 해양, 온산은 모든 스케줄 포함
                                peCondition = true;
                            }
                        }

                        else if (selectedPe == "전체ALL 본사(1PE)")
                        {
                            // 본사의 1D 서 PE 장소만 포함 또는 다른 사업장 전체 포함
                            if (schedule.MFG_IND == "본사")
                            {
                                peCondition = schedule.LOC_DESC == "1D 서";
                            }
                            else
                            {
                                // 다른 사업장은 전체 포함
                                peCondition = true;
                            }
                        }
                        else if (selectedPe == "전체ALL 본사(2PE)")
                        {
                            // 본사의 총조장 PE 장소만 포함 또는 다른 사업장 전체 포함
                            if (schedule.MFG_IND == "본사")
                            {
                                peCondition = schedule.LOC_DESC == "총조장";
                            }
                            else
                            {
                                // 다른 사업장은 전체 포함
                                peCondition = true;
                            }
                        }
                        else if (selectedPe == "전체ALL 본사(3PE)")
                        {
                            // 본사의 2 - 3D PE 장소만 포함 또는 다른 사업장 전체 포함
                            if (schedule.MFG_IND == "본사")
                            {
                                peCondition = schedule.LOC_DESC == "2 - 3D";
                            }
                            else
                            {
                                // 다른 사업장은 전체 포함
                                peCondition = true;
                            }
                        }
                        else if (selectedPe == "전체ALL 본사(4PE)")
                        {
                            // 본사의 4D 동 PE 장소만 포함 또는 다른 사업장 전체 포함
                            if (schedule.MFG_IND == "본사")
                            {
                                peCondition = schedule.LOC_DESC == "4D 동";
                            }
                            else
                            {
                                // 다른 사업장은 전체 포함
                                peCondition = true;
                            }
                        }


                        else if (schedule.MFG_IND == "본사")
                        {
                            if (selectedPe == "1PE(1D 서)")
                                peCondition = schedule.LOC_DESC == "1D 서";
                            else if (selectedPe == "2PE(총조장)")
                                peCondition = schedule.LOC_DESC == "총조장";
                            else if (selectedPe == "3PE(2 - 3D)")
                                peCondition = schedule.LOC_DESC == "2 - 3D";
                            else if (selectedPe == "4PE(4D 동)")
                                peCondition = schedule.LOC_DESC == "4D 동";
                            else if (selectedPe == "2 - 3D")
                                peCondition = schedule.LOC_DESC == "2 - 3D";
                            else
                                peCondition = false;
                        }
                        else
                        {
                            peCondition = false;
                        }
                    }

                    // 나머지 기존 필터링 조건들 (PE Type, PE 장비, STAGE 등)은 그대로 유지
                    bool peTypeCondition = true;
                    if (selectedPeType != "전체")
                    {
                        switch (selectedPeType)
                        {
                            case "선PE":
                                peTypeCondition = schedule.PE_TYPE == "선PE";
                                break;
                            case "1PE":
                                peTypeCondition = schedule.PE_TYPE == "1PE";
                                break;
                            case "2PE":
                                peTypeCondition = schedule.PE_TYPE == "2PE";
                                break;
                            case "일반":
                                peTypeCondition = schedule.PE_TYPE == "일반";
                                break;
                            default:
                                peTypeCondition = false;
                                break;
                        }
                    }

                    bool peEqpCondition = true;
                    if (selectedPeEqp != "전체")
                    {
                        if (selectedPeEqp == "C(CRANE)")
                            peEqpCondition = schedule.LOC_EQP == "C";
                        else if (selectedPeEqp == "T(T.P)")
                            peEqpCondition = schedule.LOC_EQP == "T";
                        else
                            peEqpCondition = false;
                    }

                    bool stageCondition = true;
                    if (selectedStage != "전체")
                    {
                        stageCondition = schedule.STG_CD == selectedStage;
                    }

                    if (dateCondition && mfgCondition && peCondition && stageCondition && peEqpCondition && peTypeCondition)
                    {
                        // 원본 객체를 그대로 사용하여 색상 정보 유지
                        filteredData.Add(schedule);
                    }
                }

                if (filteredData.Count == 0)
                {
                    StringBuilder message = new StringBuilder();
                    message.AppendLine("검색 결과가 없습니다.");
                    message.AppendLine("사업장: " + selectedMfg);
                    message.AppendLine("PE장소: " + selectedPe);
                    message.AppendLine("STAGE: " + selectedStage);
                    message.AppendLine("PE Type: " + selectedPeType);

                    if (StartDatePicker.SelectedDate.HasValue && EndDatePicker.SelectedDate.HasValue)
                    {
                        message.AppendLine("기간: " +
                                           StartDatePicker.SelectedDate.Value.ToString("yyyy/MM/dd") + " ~ " +
                                           EndDatePicker.SelectedDate.Value.ToString("yyyy/MM/dd"));
                    }

                    MessageBox.Show(message.ToString(), "INFO(정보)/검색결과없음");
                    return;
                }

                StringBuilder resultMessage = new StringBuilder();
                resultMessage.AppendLine("검색 결과: " + (filteredData.Count - 2) + "건"); // LOAD 행 2개 제외
                resultMessage.AppendLine("사업장: " + selectedMfg);
                resultMessage.AppendLine("PE장소: " + selectedPe);
                resultMessage.AppendLine("STAGE: " + selectedStage);

                if (StartDatePicker.SelectedDate.HasValue && EndDatePicker.SelectedDate.HasValue)
                {
                    resultMessage.AppendLine("기간: " +
                                       StartDatePicker.SelectedDate.Value.ToString("yyyy/MM/dd") + " ~ " +
                                       EndDatePicker.SelectedDate.Value.ToString("yyyy/MM/dd"));
                }

                MessageBox.Show(resultMessage.ToString(), "INFO(정보)/검색결과");

                // 필터링된 데이터로 DataGrid 업데이트
                ShipDataGrid.ItemsSource = filteredData;

                // LOAD 데이터만 따로 추출하여 ShipDataGrid1에 표시
                var capeData = filteredData.Where(x =>
                    x.S_KIND == "LOAD 중일정개수" ||
                    x.S_KIND == "LOAD 조정결과개수").ToList();
                ShipDataGrid1.ItemsSource = capeData;


            }
            catch (Exception ex)
            {
                MessageBox.Show("검색 중 오류가 발생했습니다:\n" + ex.Message, "ERROR(오류)/검색실패");
            }
        }

        // CheckBox 해제 및 PE 적용
        public void ResetTextBoxesAndApplyPE()
        {
            // CheckBox들 체크 해제
            SunPeCheckBox.IsChecked = false;
            SunPeCheckBox1.IsChecked = false;
            Pe1CheckBox.IsChecked = false;
            Pe1CheckBox1.IsChecked = false;
            Pe2CheckBox.IsChecked = false;
            Pe2CheckBox1.IsChecked = false;

            // PE 적용 버튼 클릭
            PeApplyButton_Click(this, new RoutedEventArgs());
        }


        // CheckBox 해제 및 PE 적용
        public void ResetTextBoxesAndApplyPE1()
        {
            // CheckBox들 체크 해제
            SunPeCheckBox.IsChecked = true;
            SunPeCheckBox1.IsChecked = true;
            Pe1CheckBox.IsChecked = true;
            Pe1CheckBox1.IsChecked = true;
            Pe2CheckBox.IsChecked = true;
            Pe2CheckBox1.IsChecked = true;

            // PE 적용 버튼 클릭
            PeApplyButton_Click(this, new RoutedEventArgs());
        }

        //private async void PeApplyButton_Click(object sender, RoutedEventArgs e)
        //{
        //    if (allData == null) return;

        //    try
        //    {
        //        // UI 스레드에서 체크박스 상태를 읽어옵니다.
        //        bool isSunPeChecked = SunPeCheckBox.IsChecked == true;
        //        bool isSunPe1Checked = SunPeCheckBox1.IsChecked == true;
        //        bool isPe1Checked = Pe1CheckBox.IsChecked == true;
        //        bool isPe1_1Checked = Pe1CheckBox1.IsChecked == true;
        //        bool isPe2_1Checked = Pe2CheckBox1.IsChecked == true;

        //        // Progress 표시를 위한 간단한 작업 창
        //        var progressWindow = new Window()
        //        {
        //            Title = "PE 조정 적용 중...",
        //            Width = 300,
        //            Height = 100,
        //            WindowStartupLocation = WindowStartupLocation.CenterOwner,
        //            Owner = this,
        //            ResizeMode = ResizeMode.NoResize
        //        };

        //        var progressBar = new ProgressBar()
        //        {
        //            Width = 280,
        //            Height = 20,
        //            Margin = new Thickness(10),
        //            IsIndeterminate = true
        //        };

        //        progressWindow.Content = progressBar;
        //        progressWindow.Show();

        //        // 비동기 처리
        //        List<ShipSchedule> filteredData = await Task.Run(() =>
        //        {
        //            List<ShipSchedule> tempData = new List<ShipSchedule>();

        //            foreach (ShipSchedule schedule in allData)
        //            {
        //                // CAPE 데이터는 그대로 복사
        //                if (schedule.S_KIND == "CAPE 중일정개수" || schedule.S_KIND == "CAPE 조정결과개수")
        //                {
        //                    tempData.Add(schedule);
        //                    continue;
        //                }

        //                // 일반 데이터 복사
        //                ShipSchedule newSchedule = new ShipSchedule
        //                {
        //                    S_KIND = schedule.S_KIND,
        //                    S_TYPE = schedule.S_TYPE,
        //                    OWNER = schedule.OWNER,
        //                    SHIP_DISP = schedule.SHIP_DISP,
        //                    BLOCK = schedule.BLOCK,
        //                    STG_CD = schedule.STG_CD,
        //                    S_NAME = schedule.S_NAME,
        //                    MFG_IND = schedule.MFG_IND,
        //                    LOC_DESC = schedule.LOC_DESC,
        //                    LOC_EQP = schedule.LOC_EQP,
        //                    PE_TYPE = schedule.PE_TYPE,
        //                    WKSTPLDT = schedule.WKSTPLDT,
        //                    WKSTPLDT1 = schedule.WKSTPLDT1,
        //                    WKFIPLDT = schedule.WKFIPLDT,
        //                    WKFIPLDT1 = schedule.WKFIPLDT1,
        //                    ERECT_PLDT = schedule.ERECT_PLDT,
        //                    IsSelected = schedule.IsSelected,
        //                    MonthlyDates = new ArrayList()
        //                };

        //                // PE 체크박스 상태를 활용한 플래그 설정
        //                switch (schedule.PE_TYPE)
        //                {
        //                    case "선PE":
        //                        newSchedule.IsWKSTPLDT1Modified = isSunPeChecked;
        //                        newSchedule.IsWKFIPLDTModified = isSunPe1Checked;
        //                        break;
        //                    case "1PE":
        //                        newSchedule.IsWKSTPLDT1Modified = isPe1Checked;
        //                        newSchedule.IsWKFIPLDTModified = isPe1_1Checked;
        //                        break;
        //                    case "2PE":
        //                        newSchedule.IsERPLDTModified = isPe2_1Checked;
        //                        break;
        //                }

        //                tempData.Add(newSchedule);
        //            }

        //            return tempData;
        //        });

        //        progressWindow.Close();

        //        // UI 업데이트
        //        ProcessAndDisplayData(filteredData);
        //        MessageBox.Show("PE 조정이 적용되었습니다.", "INFO(정보)/PE적용");
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("PE 적용 중 오류가 발생했습니다:\n{ex.Message}", "ERROR(오류)/PE적용실패");
        //    }
        //}

        private async void PeApplyButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isLineLoadGraphLoaded)
            {
                MessageBox.Show(
                    "MAX 부하 그래프 화면을 먼저 실행해주세요.",
                    "알림",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information
                );
                return;
            }

            if (allData == null) return;

            try
            {
                // UI 스레드에서 체크박스 상태를 읽기
                bool isSunPeChecked = SunPeCheckBox.IsChecked == true;
                bool isSunPe1Checked = SunPeCheckBox1.IsChecked == true;
                bool isPe1Checked = Pe1CheckBox.IsChecked == true;
                bool isPe1_1Checked = Pe1CheckBox1.IsChecked == true;
                bool isPe2Checked = Pe2CheckBox.IsChecked == true;  // 2PE 시작계획일 체크박스 추가
                bool isPe2_1Checked = Pe2CheckBox1.IsChecked == true;

                var progressWindow = new Window()
                {
                    Title = "PE 조정 적용 중...",
                    Width = 300,
                    Height = 100,
                    WindowStartupLocation = WindowStartupLocation.CenterOwner,
                    Owner = this,
                    ResizeMode = ResizeMode.NoResize
                };

                var progressBar = new ProgressBar()
                {
                    Width = 280,
                    Height = 20,
                    Margin = new Thickness(10),
                    IsIndeterminate = true
                };

                progressWindow.Content = progressBar;
                progressWindow.Show();

                List<ShipSchedule> filteredData = await Task.Run(() =>
                {
                    List<ShipSchedule> tempData = new List<ShipSchedule>();

                    foreach (ShipSchedule schedule in allData)
                    {
                        // CAPE 데이터는 그대로 복사
                        if (schedule.S_KIND == "LOAD 중일정개수" || schedule.S_KIND == "LOAD 조정결과개수")
                        {
                            tempData.Add(schedule);
                            continue;
                        }

                        ShipSchedule newSchedule = new ShipSchedule
                        {
                            S_KIND = schedule.S_KIND,
                            S_TYPE = schedule.S_TYPE,
                            OWNER = schedule.OWNER,
                            SHIP_DISP = schedule.SHIP_DISP,
                            BLOCK = schedule.BLOCK,
                            STG_CD = schedule.STG_CD,
                            S_NAME = schedule.S_NAME,
                            MFG_IND = schedule.MFG_IND,
                            MFG_IND_After = schedule.MFG_IND_After,
                            LOC_DESC = schedule.LOC_DESC,
                            LOC_EQP = schedule.LOC_EQP,
                            PE_TYPE = schedule.PE_TYPE,
                            WKSTPLDT = schedule.WKSTPLDT,
                            WKSTPLDT1 = schedule.WKSTPLDT1,
                            WKFIPLDT = schedule.WKFIPLDT,
                            WKFIPLDT1 = schedule.WKFIPLDT1,
                            ERECT_PLDT = schedule.ERECT_PLDT,
                            IsSelected = schedule.IsSelected,
                            MonthlyDates = new ArrayList(),
                            Dur = schedule.Dur  // 계획공기 복사 추가
                        };

                        // PE 체크박스 상태를 활용한 플래그 설정
                        switch (schedule.PE_TYPE)
                        {
                            case "선PE":
                                newSchedule.IsWKSTPLDT1Modified = isSunPeChecked;
                                newSchedule.IsWKFIPLDTModified = isSunPe1Checked;
                                break;
                            case "1PE":
                                newSchedule.IsWKSTPLDT1Modified = isPe1Checked;
                                newSchedule.IsWKFIPLDTModified = isPe1_1Checked;
                                break;
                            case "2PE":
                                newSchedule.IsWKSTPLDT1Modified = isPe2Checked;  // 이 부분을 추가
                                newSchedule.IsERPLDTModified = isPe2_1Checked;
                                break;
                        }

                        tempData.Add(newSchedule);
                    }

                    return tempData;
                });

                progressWindow.Close();

                ProcessAndDisplayData(filteredData);
                MessageBox.Show("PE 조정이 적용되었습니다.", "INFO(정보)/PE적용");
            }
            catch (Exception ex)
            {
                MessageBox.Show("PE 적용 중 오류가 발생했습니다:\n{ex.Message}", "ERROR(오류)/PE적용실패");
            }
        }
        //public void UpdateAllData(List<ShipSchedule> newData)
        //{
        //    allData = new List<ShipSchedule>(newData);
        //}
        private void OKApplyButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var currentData = ShipDataGrid.ItemsSource as List<ShipSchedule>;
                if (currentData == null || currentData.Count == 0)
                {
                    MessageBox.Show("저장할 데이터가 없습니다.", "INFO(정보)/데이터없음");
                    return;
                }

                // 필터링 상태 확인
                int totalDataCount = (allData ?? new List<ShipSchedule>())
                    .Count(s => s.S_KIND != "LOAD 중일정개수" && s.S_KIND != "LOAD 조정결과개수");

                int currentDataCount = currentData
                    .Count(s => s.S_KIND != "LOAD 중일정개수" && s.S_KIND != "LOAD 조정결과개수");

                // 필터링 여부 판단
                if (totalDataCount != currentDataCount)
                {
                    MessageBox.Show(
                        "필터링된 상태에서는 저장할 수 없습니다.\n" +
                        "전체 데이터를 보기 위해 필터를 초기화해주세요.",
                        "저장 불가",
                        MessageBoxButton.OK,
                        MessageBoxImage.Warning
                    );
                    return;
                }

                // 현재 상태 확인
                int orangeCount = 0;
                int crimsonCount = 0;
                Dictionary<string, List<string>> modifiedDates = new Dictionary<string, List<string>>();

                // 현재 상태 카운트 및 정보 수집
                foreach (ShipSchedule schedule in currentData)
                {
                    if (schedule.S_KIND == "LOAD 중일정개수" ||
                        schedule.S_KIND == "LOAD 조정결과개수")
                        continue;

                    if (schedule.MonthlyDates != null)
                    {
                        for (int monthIndex = 0; monthIndex < schedule.MonthlyDates.Count; monthIndex++)
                        {
                            List<DateCell> monthDates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
                            if (monthDates != null)
                            {
                                DateTime currentMonth = schedule.WKSTPLDT1.AddMonths(monthIndex);
                                string monthKey = string.Format("{0}년 {1}월", currentMonth.Year, currentMonth.Month.ToString("00"));

                                for (int dayIndex = 0; dayIndex < monthDates.Count; dayIndex++)
                                {
                                    if (monthDates[dayIndex].Color == Brushes.Orange)
                                    {
                                        orangeCount++;
                                    }
                                    else if (monthDates[dayIndex].Color == Brushes.Crimson)
                                    {
                                        crimsonCount++;
                                        if (!modifiedDates.ContainsKey(monthKey))
                                        {
                                            modifiedDates[monthKey] = new List<string>();
                                        }
                                        modifiedDates[monthKey].Add(string.Format("{0}일", dayIndex + 1));
                                    }
                                }
                            }
                        }
                    }
                }

                // 확인 메시지 구성
                StringBuilder confirmMsg = new StringBuilder();
                confirmMsg.AppendLine("현재 상태를 저장하시겠습니까?");
                confirmMsg.AppendLine();
                confirmMsg.AppendFormat("- 기존 일정(주황색): {0}개\n", orangeCount);
                confirmMsg.AppendFormat("- 조정 일정(심홍색): {0}개\n", crimsonCount);


                MessageBoxResult result = MessageBox.Show(
                    confirmMsg.ToString(),
                    "상태 저장 확인",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question
                );

                if (result == MessageBoxResult.Yes)
                {
                    // 깊은 복사로 현재 상태를 저장
                    allData = new List<ShipSchedule>();
                    foreach (ShipSchedule schedule in currentData)
                    {
                        ShipSchedule newSchedule = new ShipSchedule
                        {
                            S_KIND = schedule.S_KIND,
                            S_TYPE = schedule.S_TYPE,
                            OWNER = schedule.OWNER,
                            SHIP_DISP = schedule.SHIP_DISP,
                            BLOCK = schedule.BLOCK,
                            STG_CD = schedule.STG_CD,
                            S_NAME = schedule.S_NAME,
                            MFG_IND = schedule.MFG_IND,
                            LOC_DESC = schedule.LOC_DESC,
                            LOC_EQP = schedule.LOC_EQP,
                            PE_TYPE = schedule.PE_TYPE,
                            WKSTPLDT = schedule.WKSTPLDT,
                            WKSTPLDT1 = schedule.WKSTPLDT1,
                            WKFIPLDT = schedule.WKFIPLDT,
                            WKFIPLDT1 = schedule.WKFIPLDT1,
                            ERECT_PLDT = schedule.ERECT_PLDT,
                            IsSelected = schedule.IsSelected,
                            IsWKSTPLDT1Modified = schedule.IsWKSTPLDT1Modified,
                            IsWKFIPLDTModified = schedule.IsWKFIPLDTModified,
                            IsERPLDTModified = schedule.IsERPLDTModified,
                            IsMfgModified = schedule.IsMfgModified,
                            OriginalMfgInd = schedule.OriginalMfgInd,
                            Dur = schedule.Dur,
                            MonthlyDates = new ArrayList()
                        };

                        // MonthlyDates 깊은 복사
                        if (schedule.MonthlyDates != null)
                        {
                            foreach (List<DateCell> monthDates in schedule.MonthlyDates)
                            {
                                List<DateCell> newMonthDates = new List<DateCell>();
                                foreach (DateCell cell in monthDates)
                                {
                                    DateCell newCell = new DateCell
                                    {
                                        Day = cell.Day,
                                        Color = cell.Color // 현재 색상 그대로 유지
                                    };
                                    newMonthDates.Add(newCell);
                                }
                                newSchedule.MonthlyDates.Add(newMonthDates);
                            }
                        }

                        allData.Add(newSchedule);
                    }

                    MessageBox.Show(
                        string.Format(
                            "현재 상태가 저장되었습니다.\n" +
                            "기존 일정(주황색): {0}개\n" +
                            "조정 일정(심홍색): {1}개",
                            orangeCount,
                            crimsonCount
                        ),
                        "INFO(정보)/상태저장완료"
                    );

                    // 저장 버튼 상태 설정
                    OKApplyButton.IsEnabled = true;
                    OKApplyButton.Content = "해체 저장";
                    OKApplyButton.ToolTip = "현재 상태가 이미 저장되었습니다";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    string.Format("상태 저장 중 오류가 발생했습니다:\n{0}", ex.Message),
                    "ERROR(오류)/저장실패"
                );
            }
        }
        //private async void PeApplyButton_Click(object sender, RoutedEventArgs e)
        //{
        //    if (allData == null) return;

        //    try
        //    {
        //        // UI 스레드에서 체크박스 상태를 읽기
        //        bool isSunPeChecked = SunPeCheckBox.IsChecked == true;
        //        bool isSunPe1Checked = SunPeCheckBox1.IsChecked == true;
        //        bool isPe1Checked = Pe1CheckBox.IsChecked == true;
        //        bool isPe1_1Checked = Pe1CheckBox1.IsChecked == true;
        //        bool isPe2Checked = Pe2CheckBox.IsChecked == true;
        //        bool isPe2_1Checked = Pe2CheckBox1.IsChecked == true;

        //        var progressWindow = new Window()
        //        {
        //            Title = "PE 조정 적용 중...",
        //            Width = 300,
        //            Height = 100,
        //            WindowStartupLocation = WindowStartupLocation.CenterOwner,
        //            Owner = this,
        //            ResizeMode = ResizeMode.NoResize
        //        };

        //        var progressBar = new ProgressBar()
        //        {
        //            Width = 280,
        //            Height = 20,
        //            Margin = new Thickness(10),
        //            IsIndeterminate = true
        //        };

        //        progressWindow.Content = progressBar;
        //        progressWindow.Show();

        //        List<ShipSchedule> filteredData = await Task.Run(() =>
        //        {
        //            List<ShipSchedule> tempData = new List<ShipSchedule>();

        //            foreach (ShipSchedule schedule in allData)
        //            {
        //                // LOAD 데이터는 그대로 복사
        //                if (schedule.S_KIND == "LOAD 중일정개수" || schedule.S_KIND == "LOAD 조정결과개수")
        //                {
        //                    tempData.Add(schedule);
        //                    continue;
        //                }

        //                // 일반 데이터를 처리하기 전에 심홍색 날짜 체크
        //                bool hasCrimsonDates = false;
        //                Dictionary<int, List<int>> crimsonDates = new Dictionary<int, List<int>>();

        //                if (schedule.MonthlyDates != null)
        //                {
        //                    for (int monthIndex = 0; monthIndex < schedule.MonthlyDates.Count; monthIndex++)
        //                    {
        //                        List<DateCell> monthDates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
        //                        if (monthDates != null)
        //                        {
        //                            crimsonDates[monthIndex] = new List<int>();
        //                            for (int dayIndex = 0; dayIndex < monthDates.Count; dayIndex++)
        //                            {
        //                                if (monthDates[dayIndex].Color == Brushes.Crimson)
        //                                {
        //                                    hasCrimsonDates = true;
        //                                    crimsonDates[monthIndex].Add(dayIndex);
        //                                }
        //                            }
        //                        }
        //                    }
        //                }

        //                // 심홍색이 있는 데이터는 조정하지 않고 그대로 복사
        //                if (hasCrimsonDates)
        //                {
        //                    tempData.Add(schedule);
        //                    continue;
        //                }

        //                // 심홍색이 없는 데이터만 PE 조정 적용
        //                ShipSchedule newSchedule = new ShipSchedule
        //                {
        //                    S_KIND = schedule.S_KIND,
        //                    S_TYPE = schedule.S_TYPE,
        //                    OWNER = schedule.OWNER,
        //                    SHIP_DISP = schedule.SHIP_DISP,
        //                    BLOCK = schedule.BLOCK,
        //                    STG_CD = schedule.STG_CD,
        //                    S_NAME = schedule.S_NAME,
        //                    MFG_IND = schedule.MFG_IND,
        //                    LOC_DESC = schedule.LOC_DESC,
        //                    LOC_EQP = schedule.LOC_EQP,
        //                    PE_TYPE = schedule.PE_TYPE,
        //                    WKSTPLDT = schedule.WKSTPLDT,
        //                    WKSTPLDT1 = schedule.WKSTPLDT1,
        //                    WKFIPLDT = schedule.WKFIPLDT,
        //                    WKFIPLDT1 = schedule.WKFIPLDT1,
        //                    ERECT_PLDT = schedule.ERECT_PLDT,
        //                    IsSelected = schedule.IsSelected,
        //                    MonthlyDates = new ArrayList(),
        //                    Dur = schedule.Dur
        //                };

        //                // PE 체크박스 상태를 활용한 플래그 설정
        //                switch (schedule.PE_TYPE)
        //                {
        //                    case "선PE":
        //                        newSchedule.IsWKSTPLDT1Modified = isSunPeChecked;
        //                        newSchedule.IsWKFIPLDTModified = isSunPe1Checked;
        //                        break;
        //                    case "1PE":
        //                        newSchedule.IsWKSTPLDT1Modified = isPe1Checked;
        //                        newSchedule.IsWKFIPLDTModified = isPe1_1Checked;
        //                        break;
        //                    case "2PE":
        //                        newSchedule.IsWKSTPLDT1Modified = isPe2Checked;
        //                        newSchedule.IsERPLDTModified = isPe2_1Checked;
        //                        break;
        //                }

        //                tempData.Add(newSchedule);
        //            }

        //            return tempData;
        //        });

        //        progressWindow.Close();

        //        ProcessAndDisplayData(filteredData);
        //        MessageBox.Show("PE 조정이 적용되었습니다. (심홍색 날짜는 유지됨)", "INFO(정보)/PE적용");
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("PE 적용 중 오류가 발생했습니다:\n" + ex.Message, "ERROR(오류)/PE적용실패");
        //    }
        //}


        //private async void PeApplyButton1_Click(object sender, RoutedEventArgs e)
        //{
        //    if (allData == null) return;

        //    try
        //    {
        //        // UI 스레드에서 체크박스 상태 읽기
        //        bool isSunPeChecked = SunPeCheckBox.IsChecked == true;
        //        bool isSunPe1Checked = SunPeCheckBox1.IsChecked == true;
        //        bool isPe1Checked = Pe1CheckBox.IsChecked == true;
        //        bool isPe1_1Checked = Pe1CheckBox1.IsChecked == true;
        //        bool isPe2_1Checked = Pe2CheckBox1.IsChecked == true;

        //        // Progress 표시를 위한 창 생성
        //        var progressWindow = new Window
        //        {
        //            Title = "PE 조정 적용 중...",
        //            Width = 300,
        //            Height = 100,
        //            WindowStartupLocation = WindowStartupLocation.CenterOwner,
        //            Owner = this,
        //            ResizeMode = ResizeMode.NoResize
        //        };

        //        var progressBar = new ProgressBar
        //        {
        //            Width = 280,
        //            Height = 20,
        //            Margin = new Thickness(10),
        //            IsIndeterminate = true
        //        };

        //        progressWindow.Content = progressBar;
        //        progressWindow.Show();

        //        // 비동기 처리
        //        List<ShipSchedule> updatedData = await Task.Run(() =>
        //        {
        //            foreach (ShipSchedule schedule in allData)
        //            {
        //                // CAPE 데이터는 건너뛰기
        //                if (schedule.S_KIND == "LOAD 중일정개수" ||
        //                    schedule.S_KIND == "LOAD 조정 개수" ||
        //                    schedule.S_KIND == "LOAD 조정결과개수")
        //                    continue;

        //                bool needsUpdate = false;

        //                // PE 타입에 따른 날짜 조정 및 플래그 설정
        //                switch (schedule.PE_TYPE)
        //                {
        //                    case "선PE":
        //                        if (isSunPeChecked && !schedule.IsWKSTPLDT1Modified)
        //                        {
        //                            schedule.WKSTPLDT1 = schedule.WKSTPLDT1.AddDays(-1);
        //                            schedule.IsWKSTPLDT1Modified = true;
        //                            needsUpdate = true;
        //                        }
        //                        if (isSunPe1Checked && !schedule.IsWKFIPLDTModified)
        //                        {
        //                            schedule.WKFIPLDT = schedule.WKFIPLDT.AddDays(1);
        //                            schedule.IsWKFIPLDTModified = true;
        //                            needsUpdate = true;
        //                        }
        //                        break;

        //                    case "1PE":
        //                        if (isPe1Checked && !schedule.IsWKSTPLDT1Modified)
        //                        {
        //                            schedule.WKSTPLDT1 = schedule.WKSTPLDT1.AddDays(-1);
        //                            schedule.IsWKSTPLDT1Modified = true;
        //                            needsUpdate = true;
        //                        }
        //                        if (isPe1_1Checked && !schedule.IsWKFIPLDTModified)
        //                        {
        //                            schedule.WKFIPLDT = schedule.WKFIPLDT.AddDays(1);
        //                            schedule.IsWKFIPLDTModified = true;
        //                            needsUpdate = true;
        //                        }
        //                        break;

        //                    case "2PE":
        //                        if (isPe2_1Checked && !schedule.IsERPLDTModified)
        //                        {
        //                            schedule.ERECT_PLDT = schedule.ERECT_PLDT.AddDays(-1);
        //                            schedule.IsERPLDTModified = true;
        //                            needsUpdate = true;
        //                        }
        //                        break;
        //                }

        //                // 날짜 변경이 있으면 MonthlyDates 업데이트
        //                if (needsUpdate && schedule.MonthlyDates != null)
        //                {
        //                    DateTime startDate = schedule.WKSTPLDT1;
        //                    DateTime endDate = schedule.STG_CD == "90" ? schedule.ERECT_PLDT : schedule.WKFIPLDT;

        //                    for (int monthIndex = 0; monthIndex < schedule.MonthlyDates.Count; monthIndex++)
        //                    {
        //                        List<DateCell> monthDates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
        //                        if (monthDates != null)
        //                        {
        //                            DateTime currentMonthStart = startDate.AddMonths(monthIndex);
        //                            DateTime monthFirstDay = new DateTime(currentMonthStart.Year, currentMonthStart.Month, 1);
        //                            DateTime monthLastDay = monthFirstDay.AddMonths(1).AddDays(-1);

        //                            for (int day = 0; day < monthDates.Count; day++)
        //                            {
        //                                DateTime currentDate = new DateTime(monthFirstDay.Year, monthFirstDay.Month, day + 1);

        //                                if (monthDates[day].Color != Brushes.Crimson)
        //                                {
        //                                    if (currentDate >= startDate && currentDate <= endDate)
        //                                    {
        //                                        monthDates[day].Color = Brushes.Orange;
        //                                    }
        //                                    else
        //                                    {
        //                                        monthDates[day].Color = Brushes.White;
        //                                    }
        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //            return allData;
        //        });

        //        progressWindow.Close();

        //        // UI 업데이트
        //        ProcessAndDisplayData(updatedData);
        //        MessageBox.Show("PE 조정이 적용되었습니다.", "INFO(정보)/PE적용");
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("PE 적용 중 오류가 발생했습니다:\n{ex.Message}", "ERROR(오류)/PE적용실패");
        //    }
        //}

        private async void PeApplyButton1_Click(object sender, RoutedEventArgs e)
        {
            if (allData == null) return;

            try
            {
                // UI 스레드에서 체크박스 상태 읽기
                bool isSunPeChecked = SunPeCheckBox.IsChecked == true;
                bool isSunPe1Checked = SunPeCheckBox1.IsChecked == true;
                bool isPe1Checked = Pe1CheckBox.IsChecked == true;
                bool isPe1_1Checked = Pe1CheckBox1.IsChecked == true;
                bool isPe2_1Checked = Pe2CheckBox1.IsChecked == true;

                var progressWindow = new Window
                {
                    Title = "PE 조정 적용 중...",
                    Width = 300,
                    Height = 100,
                    WindowStartupLocation = WindowStartupLocation.CenterOwner,
                    Owner = this,
                    ResizeMode = ResizeMode.NoResize
                };

                var progressBar = new ProgressBar
                {
                    Width = 280,
                    Height = 20,
                    Margin = new Thickness(10),
                    IsIndeterminate = true
                };

                progressWindow.Content = progressBar;
                progressWindow.Show();

                // 비동기 처리
                await Task.Run(() =>
                {
                    foreach (ShipSchedule schedule in allData)
                    {
                        // CAPE 데이터는 건너뛰기
                        if (schedule.S_KIND == "LOAD 중일정개수" ||
                            schedule.S_KIND == "LOAD 조정 개수" ||
                            schedule.S_KIND == "LOAD 조정결과개수")
                            continue;

                        bool needsUpdate = false;
                        DateTime oldStart = schedule.WKSTPLDT1;
                        DateTime oldEnd = schedule.STG_CD == "90" ? schedule.ERECT_PLDT : schedule.WKFIPLDT;

                        // PE 타입에 따른 날짜 조정 및 플래그 설정
                        switch (schedule.PE_TYPE)
                        {
                            case "선PE":
                                if (isSunPeChecked && !schedule.IsWKSTPLDT1Modified)
                                {
                                    schedule.WKSTPLDT1 = schedule.WKSTPLDT1.AddDays(-1);
                                    schedule.IsWKSTPLDT1Modified = true;
                                    needsUpdate = true;
                                }
                                if (isSunPe1Checked && !schedule.IsWKFIPLDTModified)
                                {
                                    schedule.WKFIPLDT = schedule.WKFIPLDT.AddDays(1);
                                    schedule.IsWKFIPLDTModified = true;
                                    needsUpdate = true;
                                }
                                break;

                            case "1PE":
                                if (isPe1Checked && !schedule.IsWKSTPLDT1Modified)
                                {
                                    schedule.WKSTPLDT1 = schedule.WKSTPLDT1.AddDays(-1);
                                    schedule.IsWKSTPLDT1Modified = true;
                                    needsUpdate = true;
                                }
                                if (isPe1_1Checked && !schedule.IsWKFIPLDTModified)
                                {
                                    schedule.WKFIPLDT = schedule.WKFIPLDT.AddDays(1);
                                    schedule.IsWKFIPLDTModified = true;
                                    needsUpdate = true;
                                }
                                break;

                            case "2PE":
                                if (isPe2_1Checked && !schedule.IsERPLDTModified)
                                {
                                    schedule.ERECT_PLDT = schedule.ERECT_PLDT.AddDays(-1);
                                    schedule.IsERPLDTModified = true;
                                    needsUpdate = true;
                                }
                                break;
                        }

                        // 날짜 변경이 있으면 MonthlyDates 업데이트
                        if (needsUpdate && schedule.MonthlyDates != null)
                        {
                            DateTime newEnd = schedule.STG_CD == "90" ? schedule.ERECT_PLDT : schedule.WKFIPLDT;

                            for (int monthIndex = 0; monthIndex < schedule.MonthlyDates.Count; monthIndex++)
                            {
                                List<DateCell> monthDates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
                                if (monthDates != null)
                                {
                                    DateTime currentMonthStart = schedule.WKSTPLDT1.AddMonths(monthIndex);
                                    DateTime monthFirstDay = new DateTime(currentMonthStart.Year, currentMonthStart.Month, 1);

                                    for (int day = 0; day < monthDates.Count; day++)
                                    {
                                        DateTime currentDate = monthFirstDay.AddDays(day);

                                        // 이전에 Crimson이었던 날짜는 유지
                                        if (monthDates[day].Color == Brushes.Crimson)
                                            continue;

                                        // 작업일이고 날짜 범위 안에 있는 경우만 색상 변경
                                        if (IsWorkingDay(currentDate))
                                        {
                                            if (currentDate >= schedule.WKSTPLDT1 && currentDate <= newEnd)
                                            {
                                                // 새로 수정된 날짜는 Crimson으로 표시
                                                if (currentDate == schedule.WKSTPLDT1 && schedule.IsWKSTPLDT1Modified ||
                                                    currentDate == schedule.WKFIPLDT && schedule.IsWKFIPLDTModified ||
                                                    currentDate == schedule.ERECT_PLDT && schedule.IsERPLDTModified)
                                                {
                                                    monthDates[day].Color = Brushes.Crimson;
                                                }
                                                else
                                                {
                                                    monthDates[day].Color = Brushes.Orange;
                                                }
                                            }
                                            else
                                            {
                                                monthDates[day].Color = Brushes.White;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                });

                progressWindow.Close();

                // UI 업데이트
                ProcessAndDisplayData(allData);
                MessageBox.Show("PE 조정이 적용되었습니다.", "INFO(정보)/PE적용");
            }
            catch (Exception ex)
            {
                MessageBox.Show("PE 적용 중 오류가 발생했습니다:\n" + ex.Message, "ERROR(오류)/PE적용실패");
            }
        }

        private void ResetDatePickerButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // DatePicker 초기화
                StartDatePicker.SelectedDate = null;
                EndDatePicker.SelectedDate = null;

                // 데이터가 있다면 초기 날짜 범위 다시 설정
                SetInitialDatePickerRange();

                // 사용자에게 초기화 완료 알림
                MessageBox.Show(
                    "날짜 필터가 초기화되었습니다.",
                    "정보",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "날짜 초기화 중 오류가 발생했습니다: " + ex.Message,
                    "오류",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
            }
        }
        //private async void PeApplyButton_Click(object sender, RoutedEventArgs e)
        //{
        //    if (allData == null || _isUpdatingData) return;

        //    try
        //    {
        //        _isUpdatingData = true;

        //        // UI 스레드에서 체크박스 상태 확인
        //        _peState.IsSunPeChecked = SunPeCheckBox.IsChecked == true;
        //        _peState.IsSunPe1Checked = SunPeCheckBox1.IsChecked == true;
        //        _peState.IsPe1Checked = Pe1CheckBox.IsChecked == true;
        //        _peState.IsPe1_1Checked = Pe1CheckBox1.IsChecked == true;
        //        _peState.IsPe2_1Checked = Pe2CheckBox1.IsChecked == true;

        //        // 선PE 처리
        //        if (_peState.IsSunPeChecked || _peState.IsSunPe1Checked)
        //        {
        //            ProcessPeChanges("선PE", schedule =>
        //            {
        //                if (_peState.IsSunPeChecked)
        //                {
        //                    schedule.WKSTPLDT1 = schedule.WKSTPLDT1.AddDays(-1);
        //                    schedule.IsWKSTPLDT1Modified = true;
        //                }
        //                if (_peState.IsSunPe1Checked)
        //                {
        //                    schedule.WKFIPLDT = schedule.WKFIPLDT.AddDays(1);
        //                    schedule.IsWKFIPLDTModified = true;
        //                }
        //            });
        //        }

        //        // 1PE 처리
        //        if (_peState.IsPe1Checked || _peState.IsPe1_1Checked)
        //        {
        //            ProcessPeChanges("1PE", schedule =>
        //            {
        //                if (_peState.IsPe1Checked)
        //                {
        //                    schedule.WKSTPLDT1 = schedule.WKSTPLDT1.AddDays(-1);
        //                    schedule.IsWKSTPLDT1Modified = true;
        //                }
        //                if (_peState.IsPe1_1Checked)
        //                {
        //                    schedule.WKFIPLDT = schedule.WKFIPLDT.AddDays(1);
        //                    schedule.IsWKFIPLDTModified = true;
        //                }
        //            });
        //        }

        //        // 2PE 처리
        //        if (_peState.IsPe2_1Checked)
        //        {
        //            ProcessPeChanges("2PE", schedule =>
        //            {
        //                schedule.ERECT_PLDT = schedule.ERECT_PLDT.AddDays(-1);
        //                schedule.IsERPLDTModified = true;
        //            });
        //        }

        //        // 데이터 그리드 업데이트
        //        ProcessAndDisplayData(allData);
        //        MessageBox.Show("PE 조정이 적용되었습니다.", "INFO(정보)/PE적용");
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("PE 적용 중 오류가 발생했습니다:\n" + ex.Message, "ERROR(오류)/PE적용실패");
        //    }
        //    finally
        //    {
        //        _isUpdatingData = false;
        //    }
        //}


        // MfgComboBox의 선택이 변경될 때의 이벤트 핸들러
        private void MfgComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem selectedItem = MfgComboBox.SelectedItem as ComboBoxItem;
            if (selectedItem != null)
            {
                string content = selectedItem.Content.ToString();
                if (content != "본사" && content != "본사,해양,온산")
                {
                    PeComboBox.IsEnabled = false; // 본사 관련이 아닐 때 비활성화
                }
                else
                {
                    PeComboBox.IsEnabled = true; // 본사 관련일 때 활성화
                    PeComboBox.SelectedIndex = 0; // 기본값(전체)으로 초기화
                }
            }
        }

        //데이터 정렬
        private ShipSchedule _copiedSchedule;

        private void ShipDataGrid_CtrlDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            // Ctrl 키가 눌려있는지 확인
            if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
            {
                e.Handled = true;

                var cell = UIHelpers.GetParent<DataGridCell>((DependencyObject)e.OriginalSource);
                if (cell == null) return;

                var row = UIHelpers.GetParent<DataGridRow>(cell);
                if (row == null) return;

                var schedule = row.Item as ShipSchedule;
                if (schedule == null ||
                    schedule.S_KIND == "LOAD 중일정개수" ||
                    schedule.S_KIND == "LOAD 조정 개수" ||
                    schedule.S_KIND == "LOAD 조정결과개수")
                    return;

                // 컨텍스트 메뉴 생성
                ContextMenu menu = new ContextMenu();

                // 컬럼 기반 정렬 메뉴 항목
                var column = cell.Column as DataGridTextColumn;
                if (column != null)
                {
                    MenuItem ascendingItem = new MenuItem { Header = "오름차순 정렬" };
                    ascendingItem.Click += (s, args) => SortData(column, ListSortDirection.Ascending);

                    MenuItem descendingItem = new MenuItem { Header = "내림차순 정렬" };
                    descendingItem.Click += (s, args) => SortData(column, ListSortDirection.Descending);

                    //MenuItem clearSortItem = new MenuItem { Header = "정렬 해제" };
                    //clearSortItem.Click += (s, args) =>
                    {
                        column.SortDirection = null;
                        foreach (DataGridColumn col in ShipDataGrid.Columns)
                        {
                            col.SortDirection = null;
                        }
                    };

                    menu.Items.Add(ascendingItem);
                    menu.Items.Add(descendingItem);
                    menu.Items.Add(new Separator());
                    //menu.Items.Add(clearSortItem);
                    menu.Items.Add(new Separator());
                }

                // 행 복사 메뉴 아이템
                MenuItem copyItem = new MenuItem { Header = "행 복사" };
                copyItem.Click += (s, args) =>
                {
                    _copiedSchedule = new ShipSchedule
                    {
                        S_KIND = schedule.S_KIND,
                        S_TYPE = schedule.S_TYPE,
                        OWNER = schedule.OWNER,
                        SHIP_DISP = schedule.SHIP_DISP,
                        BLOCK = schedule.BLOCK,
                        STG_CD = schedule.STG_CD,
                        S_NAME = schedule.S_NAME,
                        MFG_IND = schedule.MFG_IND,
                        LOC_DESC = schedule.LOC_DESC,
                        LOC_EQP = schedule.LOC_EQP,
                        PE_TYPE = schedule.PE_TYPE,
                        WKSTPLDT = schedule.WKSTPLDT,
                        WKSTPLDT1 = schedule.WKSTPLDT1,
                        WKFIPLDT = schedule.WKFIPLDT,
                        WKFIPLDT1 = schedule.WKFIPLDT1,
                        ERECT_PLDT = schedule.ERECT_PLDT,
                        Dur = schedule.Dur
                    };
                    MessageBox.Show("선택한 행이 복사되었습니다.", "INFO(정보)/복사완료");
                };

                // 행 붙여넣기 메뉴 아이템
                MenuItem pasteItem = new MenuItem { Header = "행 붙여넣기" };
                pasteItem.IsEnabled = _copiedSchedule != null;
                pasteItem.Click += (s, args) =>
                {
                    if (_copiedSchedule == null)
                    {
                        MessageBox.Show("복사된 데이터가 없습니다.", "INFO(정보)/붙여넣기불가");
                        return;
                    }

                    schedule.S_KIND = _copiedSchedule.S_KIND;
                    schedule.S_TYPE = _copiedSchedule.S_TYPE;
                    schedule.OWNER = _copiedSchedule.OWNER;
                    schedule.SHIP_DISP = _copiedSchedule.SHIP_DISP;
                    schedule.BLOCK = _copiedSchedule.BLOCK;
                    schedule.STG_CD = _copiedSchedule.STG_CD;
                    schedule.S_NAME = _copiedSchedule.S_NAME;
                    schedule.MFG_IND = _copiedSchedule.MFG_IND;
                    schedule.LOC_DESC = _copiedSchedule.LOC_DESC;
                    schedule.LOC_EQP = _copiedSchedule.LOC_EQP;
                    schedule.PE_TYPE = _copiedSchedule.PE_TYPE;
                    schedule.WKSTPLDT = _copiedSchedule.WKSTPLDT;
                    schedule.WKSTPLDT1 = _copiedSchedule.WKSTPLDT1;
                    schedule.WKFIPLDT = _copiedSchedule.WKFIPLDT;
                    schedule.WKFIPLDT1 = _copiedSchedule.WKFIPLDT1;
                    schedule.ERECT_PLDT = _copiedSchedule.ERECT_PLDT;
                    schedule.Dur = _copiedSchedule.Dur;

                    ShipDataGrid.Items.Refresh();
                    ProcessAndDisplayData(allData);
                    MessageBox.Show("데이터가 성공적으로 붙여넣기 되었습니다.", "INFO(정보)/붙여넣기완료");
                };

                // 행 삭제 메뉴 아이템
                MenuItem deleteItem = new MenuItem { Header = "행 삭제" };
                deleteItem.Click += (s, args) =>
                {
                    MessageBoxResult result = MessageBox.Show(
                        "선택한 행을 삭제하시겠습니까?",
                        "삭제 확인",
                        MessageBoxButton.YesNo,
                        MessageBoxImage.Question);

                    if (result == MessageBoxResult.Yes)
                    {
                        var items = ShipDataGrid.ItemsSource as List<ShipSchedule>;
                        if (items != null)
                        {
                            items.Remove(schedule);
                            allData = items;
                            ProcessAndDisplayData(items);
                            MessageBox.Show("선택한 행이 삭제되었습니다.", "INFO(정보)/삭제완료");
                        }
                    }
                };

                menu.Items.Add(copyItem);
                menu.Items.Add(pasteItem);
                menu.Items.Add(new Separator());
                menu.Items.Add(deleteItem);

                // 메뉴 표시
                menu.IsOpen = true;
            }
        }

        private void SortData(DataGridColumn column, ListSortDirection direction)
        {
            try
            {
                var textColumn = column as DataGridTextColumn;
                if (textColumn == null) return;

                // Get binding path
                Binding binding = textColumn.Binding as Binding;
                if (binding == null) return;
                string propertyName = binding.Path.Path;

                // Clear other columns
                foreach (DataGridColumn col in ShipDataGrid.Columns)
                {
                    if (col != column) col.SortDirection = null;
                }

                // Set new direction
                column.SortDirection = direction;

                // Get data
                List<ShipSchedule> items = ShipDataGrid.ItemsSource as List<ShipSchedule>;
                if (items == null) return;

                // 일반 항목과 CAPE 항목 분리
                List<ShipSchedule> regularItems = new List<ShipSchedule>();
                List<ShipSchedule> capeItems = new List<ShipSchedule>();

                foreach (var item in items)
                {
                    if (item.S_KIND == "LOAD 중일정개수" || item.S_KIND == "LOAD 조정결과개수")
                        capeItems.Add(item);
                    else
                        regularItems.Add(item);
                }

                // 일반 항목만 정렬
                regularItems.Sort(delegate(ShipSchedule x, ShipSchedule y)
                {
                    object xValue = GetPropertyValue(x, propertyName);
                    object yValue = GetPropertyValue(y, propertyName);

                    int result;
                    if (xValue == null && yValue == null)
                        result = 0;
                    else if (xValue == null)
                        result = -1;
                    else if (yValue == null)
                        result = 1;
                    else if (xValue is DateTime && yValue is DateTime)
                        result = ((DateTime)xValue).CompareTo((DateTime)yValue);
                    else
                        result = xValue.ToString().CompareTo(yValue.ToString());

                    return direction == ListSortDirection.Ascending ? result : -result;
                });

                // 정렬된 일반 항목과 CAPE 항목 합치기
                regularItems.AddRange(capeItems);
                ShipDataGrid.ItemsSource = regularItems;
            }
            catch (Exception ex)
            {
                MessageBox.Show("정렬 중 오류가 발생했습니다: " + ex.Message, "ERROR(오류)/정렬실패");
            }
        }

        // UIHelpers 클래스 추가
        public static class UIHelpers
        {
            public static T GetParent<T>(DependencyObject child) where T : DependencyObject
            {
                DependencyObject parentObject = VisualTreeHelper.GetParent(child);

                if (parentObject == null) return null;

                T parent = parentObject as T;
                if (parent != null)
                    return parent;
                else
                    return GetParent<T>(parentObject);
            }
        }

        private Dictionary<ShipSchedule, List<Tuple<int, int>>> crimsonCellMemory = new Dictionary<ShipSchedule, List<Tuple<int, int>>>();

        public void SaveCrimsonCellState()
        {
            crimsonCellMemory.Clear();
            var currentData = ShipDataGrid.ItemsSource as List<ShipSchedule>;

            if (currentData != null)
            {
                foreach (ShipSchedule schedule in currentData)
                {
                    var crimsonCells = new List<Tuple<int, int>>();

                    if (schedule.MonthlyDates != null)
                    {
                        for (int monthIndex = 0; monthIndex < schedule.MonthlyDates.Count; monthIndex++)
                        {
                            List<DateCell> monthDates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
                            if (monthDates != null)
                            {
                                for (int dayIndex = 0; dayIndex < monthDates.Count; dayIndex++)
                                {
                                    if (monthDates[dayIndex].Color == Brushes.Crimson)
                                    {
                                        crimsonCells.Add(new Tuple<int, int>(monthIndex, dayIndex));
                                    }
                                }
                            }
                        }
                    }

                    if (crimsonCells.Count > 0)
                    {
                        crimsonCellMemory[schedule] = crimsonCells;
                    }
                }
            }
        }

        public void RestoreCrimsonCellState()
        {
            var currentData = ShipDataGrid.ItemsSource as List<ShipSchedule>;

            if (currentData != null)
            {
                foreach (var kvp in crimsonCellMemory)
                {
                    ShipSchedule schedule = kvp.Key;
                    List<Tuple<int, int>> crimsonCells = kvp.Value;

                    if (schedule.MonthlyDates != null)
                    {
                        foreach (var cellLocation in crimsonCells)
                        {
                            List<DateCell> monthDates = schedule.MonthlyDates[cellLocation.Item1] as List<DateCell>;
                            if (monthDates != null && cellLocation.Item2 < monthDates.Count)
                            {
                                monthDates[cellLocation.Item2].Color = Brushes.Crimson;
                            }
                        }
                    }
                }

                crimsonCellMemory.Clear();
            }
        }

        //여기에 새로운 메서드를 추가
        private void ShipDataGrid_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (!isLineLoadGraphLoaded)
            {
                MessageBox.Show(
                    "MAX 부하 그래프 화면을 먼저 실행해주세요.",
                    "알림",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information
                );
                return;
            }

            // 왼쪽 버튼인 경우에만 처리
            if (e.ChangedButton != System.Windows.Input.MouseButton.Left)
                return;

            // IsColorChangeEnabled가 false이면 더블클릭 무시
            if (!IsColorChangeEnabled)
            {
                MessageBox.Show(
                    "PE 해체 상태 잠금상태입니다.체크상태확인 부탁합니다.",
                    "알림",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information
                );
                return;
            }

            DataGridRow row = ItemsControl.ContainerFromElement((DataGrid)sender,
                e.OriginalSource as DependencyObject) as DataGridRow;

            if (row != null)
            {
                // 현재 스크롤 위치 저장
                var scrollViewer = GetScrollViewer(ShipDataGrid);
                double verticalOffset = 0;
                double horizontalOffset = 0;
                if (scrollViewer != null)
                {
                    verticalOffset = scrollViewer.VerticalOffset;
                    horizontalOffset = scrollViewer.HorizontalOffset;
                }

                ShipSchedule schedule = row.Item as ShipSchedule;
                if (schedule != null && ShipDataGrid.SelectedItem == schedule &&
                    schedule.S_KIND != "LOAD 중일정개수" && schedule.S_KIND != "LOAD 조정 개수")
                {
                    if (!string.IsNullOrEmpty(schedule.STG_CD))
                    {
                        bool isCrimson = false;

                        if (schedule.MonthlyDates != null)
                        {
                            DateTime startDate = schedule.WKSTPLDT1;
                            DateTime endDate = schedule.STG_CD == "90" ? schedule.ERECT_PLDT : schedule.WKFIPLDT;

                            for (int monthIndex = 0; monthIndex < schedule.MonthlyDates.Count; monthIndex++)
                            {
                                List<DateCell> monthDates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
                                if (monthDates != null)
                                {
                                    foreach (DateCell date in monthDates)
                                    {
                                        try
                                        {
                                            int currentDay;
                                            if (int.TryParse(date.Day, out currentDay))
                                            {
                                                if (currentDay > 0 &&
                                                    currentDay <= DateTime.DaysInMonth(startDate.Year, startDate.Month))
                                                {
                                                    if (date.Color == Brushes.Crimson)
                                                    {
                                                        date.Color = Brushes.Orange;
                                                        isCrimson = false;
                                                    }
                                                    // Orange에서 Crimson으로의 변경만 제한

                                                    else if (date.Color == Brushes.Orange)
                                                    {
                                                        date.Color = Brushes.Crimson;
                                                        isCrimson = true;
                                                    }
                                                }
                                            }
                                        }
                                        catch (ArgumentOutOfRangeException)
                                        {
                                            continue;
                                        }
                                    }
                                }
                            }
                        }

                        schedule.IsSelected = !isCrimson;
                        UpdateCapeAdjustCount();

                        // 데이터그리드 새로고침 후 스크롤 위치 복원
                        ShipDataGrid.Items.Refresh();
                        ShipDataGrid.UpdateLayout();

                        // 스크롤 위치 복원
                        ShipDataGrid.Dispatcher.BeginInvoke(new Action(() =>
                        {
                            var newScrollViewer = GetScrollViewer(ShipDataGrid);
                            if (newScrollViewer != null)
                            {
                                newScrollViewer.ScrollToVerticalOffset(verticalOffset);
                                newScrollViewer.ScrollToHorizontalOffset(horizontalOffset);
                            }
                        }), DispatcherPriority.Loaded);
                    }
                }
            }
        }

        //private void ShipDataGrid_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        //{
        //    // IsColorChangeEnabled가 false인 경우 색상 변경을 허용하지 않음
        //    if (!IsColorChangeEnabled)
        //        return;

        //    // 왼쪽 버튼인 경우에만 처리
        //    if (e.ChangedButton != System.Windows.Input.MouseButton.Left)
        //        return;

        //    DataGridRow row = ItemsControl.ContainerFromElement((DataGrid)sender,
        //        e.OriginalSource as DependencyObject) as DataGridRow;

        //    if (row != null)
        //    {
        //        // 현재 스크롤 위치 저장
        //        var scrollViewer = GetScrollViewer(ShipDataGrid);
        //        double verticalOffset = 0;
        //        double horizontalOffset = 0;
        //        if (scrollViewer != null)
        //        {
        //            verticalOffset = scrollViewer.VerticalOffset;
        //            horizontalOffset = scrollViewer.HorizontalOffset;
        //        }

        //        ShipSchedule schedule = row.Item as ShipSchedule;
        //        if (schedule != null && ShipDataGrid.SelectedItem == schedule &&
        //            schedule.S_KIND != "LOAD 중일정개수" && schedule.S_KIND != "LOAD 조정 개수")
        //        {
        //            if (!string.IsNullOrEmpty(schedule.STG_CD))
        //            {
        //                bool isCrimson = false;

        //                if (schedule.MonthlyDates != null)
        //                {
        //                    DateTime startDate = schedule.WKSTPLDT1;
        //                    DateTime endDate = schedule.STG_CD == "90" ? schedule.ERECT_PLDT : schedule.WKFIPLDT;

        //                    for (int monthIndex = 0; monthIndex < schedule.MonthlyDates.Count; monthIndex++)
        //                    {
        //                        List<DateCell> monthDates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
        //                        if (monthDates != null)
        //                        {
        //                            foreach (DateCell date in monthDates)
        //                            {
        //                                try
        //                                {
        //                                    int currentDay;
        //                                    if (int.TryParse(date.Day, out currentDay))
        //                                    {
        //                                        if (currentDay > 0 &&
        //                                            currentDay <= DateTime.DaysInMonth(startDate.Year, startDate.Month))
        //                                        {
        //                                            // Orange에서 Crimson으로의 변경만 제한
        //                                            if (date.Color == Brushes.Crimson)
        //                                            {
        //                                                date.Color = Brushes.Orange;
        //                                                isCrimson = false;
        //                                            }
        //                                            else if (date.Color == Brushes.Orange && IsColorChangeEnabled)
        //                                            {
        //                                                date.Color = Brushes.Crimson;
        //                                                isCrimson = true;
        //                                            }
        //                                        }
        //                                    }
        //                                }
        //                                catch (ArgumentOutOfRangeException)
        //                                {
        //                                    continue;
        //                                }
        //                            }
        //                        }
        //                    }
        //                }

        //                schedule.IsSelected = !isCrimson;
        //                UpdateCapeAdjustCount();

        //                // 데이터그리드 새로고침 후 스크롤 위치 복원
        //                ShipDataGrid.Items.Refresh();
        //                ShipDataGrid.UpdateLayout();

        //                // 스크롤 위치 복원
        //                ShipDataGrid.Dispatcher.BeginInvoke(new Action(() =>
        //                {
        //                    var newScrollViewer = GetScrollViewer(ShipDataGrid);
        //                    if (newScrollViewer != null)
        //                    {
        //                        newScrollViewer.ScrollToVerticalOffset(verticalOffset);
        //                        newScrollViewer.ScrollToHorizontalOffset(horizontalOffset);
        //                    }
        //                }), DispatcherPriority.Loaded);
        //            }
        //        }
        //    }
        //}

        // 이 헬퍼 메서드가 없다면 추가
        private ScrollViewer GetScrollViewer(DependencyObject depObj)
        {
            if (depObj == null) return null;

            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(depObj); i++)
            {
                var child = VisualTreeHelper.GetChild(depObj, i);

                if (child is ScrollViewer)
                    return child as ScrollViewer;

                var result = GetScrollViewer(child);
                if (result != null)
                    return result;
            }
            return null;
        }
        //2024년12월26일 수정
        // UpdateCapeAdjustCount 메서드는 그대로 유지 (조정 개수 계산은 내부적으로 계속 수행)
        //public void UpdateCapeAdjustCount()
        //{
        //    List<ShipSchedule> itemsSource = ShipDataGrid.ItemsSource as List<ShipSchedule>;
        //    if (itemsSource != null)
        //    {
        //        ShipSchedule capeCountRow = null;
        //        ShipSchedule capeResultRow = null;

        //        foreach (ShipSchedule item in itemsSource)
        //        {
        //            if (item.S_KIND == "LOAD 중일정개수")
        //                capeCountRow = item;
        //            if (item.S_KIND == "LOAD 조정결과개수")
        //                capeResultRow = item;
        //        }

        //        // 화면에는 표시되지 않지만 계산을 위한 조정 개수 행 생성
        //        ShipSchedule capeAdjustRow = new ShipSchedule
        //        {
        //            S_KIND = "LOAD 조정 개수",
        //            MonthlyDates = new ArrayList()
        //        };

        //        if (capeCountRow != null && capeResultRow != null &&
        //            capeCountRow.MonthlyDates != null && capeResultRow.MonthlyDates != null)
        //        {
        //            for (int monthIndex = 0; monthIndex < capeCountRow.MonthlyDates.Count; monthIndex++)
        //            {
        //                List<DateCell> countMonthDates = capeCountRow.MonthlyDates[monthIndex] as List<DateCell>;
        //                List<DateCell> resultMonthDates = capeResultRow.MonthlyDates[monthIndex] as List<DateCell>;

        //                if (countMonthDates != null && resultMonthDates != null)
        //                {
        //                    DateTime currentMonth = capeCountRow.WKSTPLDT1.AddMonths(monthIndex);

        //                    for (int i = 0; i < countMonthDates.Count; i++)
        //                    {
        //                        // 현재 날짜 생성
        //                        DateTime currentDate = new DateTime(currentMonth.Year, currentMonth.Month, i + 1);

        //                        // 휴일인 경우 0으로 설정
        //                        if (!IsWorkingDay(currentDate))
        //                        {
        //                            countMonthDates[i].Day = "0";
        //                            resultMonthDates[i].Day = "0";
        //                            continue;
        //                        }

        //                        // 평일인 경우 기존 로직대로 처리
        //                        int crimsonCount = 0;
        //                        foreach (ShipSchedule sch in itemsSource)
        //                        {
        //                            if (sch.S_KIND != "LOAD 중일정개수" &&
        //                                sch.S_KIND != "LOAD 조정 개수" &&
        //                                sch.S_KIND != "LOAD 조정결과개수" &&
        //                                sch.MonthlyDates != null &&
        //                                sch.MonthlyDates.Count > monthIndex)
        //                            {
        //                                List<DateCell> schMonthDates = sch.MonthlyDates[monthIndex] as List<DateCell>;
        //                                if (schMonthDates != null && schMonthDates.Count > i)
        //                                {
        //                                    if (schMonthDates[i].Color == Brushes.Crimson)
        //                                    {
        //                                        crimsonCount++;
        //                                    }
        //                                }
        //                            }

        //                            // 결과 개수 계산 (중일정개수 - 조정개수)
        //                            int countValue;
        //                            int.TryParse(countMonthDates[i].Day, out countValue);
        //                            int resultValue = countValue - crimsonCount;

        //                            resultMonthDates[i].Day = resultValue.ToString();
        //                            if (resultValue < 0) resultMonthDates[i].Day = "0";
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }
        //}

        //메모리 최적화 진행 완료 꺼짐문제 메모리 진행
        public void UpdateCapeAdjustCount()
        {
            try
            {
                List<ShipSchedule> itemsSource = ShipDataGrid.ItemsSource as List<ShipSchedule>;
                if (itemsSource == null)
                {
                    return;
                }

                ShipSchedule capeCountRow = null;
                ShipSchedule capeResultRow = null;

                // CAPE 행 찾기
                foreach (ShipSchedule item in itemsSource)
                {
                    if (item.S_KIND == "LOAD 중일정개수")
                    {
                        capeCountRow = item;
                    }
                    if (item.S_KIND == "LOAD 조정결과개수")
                    {
                        capeResultRow = item;
                    }
                }

                if (capeCountRow != null && capeResultRow != null &&
                    capeCountRow.MonthlyDates != null && capeResultRow.MonthlyDates != null)
                {
                    DateTime referenceDate = DateTime.Today;

                    // 기준 날짜 찾기
                    foreach (ShipSchedule schedule in itemsSource)
                    {
                        if (schedule.S_KIND != "LOAD 중일정개수" &&
                            schedule.S_KIND != "LOAD 조정결과개수" &&
                            schedule.MonthlyDates != null &&
                            schedule.MonthlyDates.Count > 0)
                        {
                            referenceDate = schedule.WKSTPLDT1;
                            break;
                        }
                    }

                    // 각 월별 데이터 처리
                    for (int monthIndex = 0; monthIndex < capeCountRow.MonthlyDates.Count; monthIndex++)
                    {
                        List<DateCell> countMonthDates = capeCountRow.MonthlyDates[monthIndex] as List<DateCell>;
                        List<DateCell> resultMonthDates = capeResultRow.MonthlyDates[monthIndex] as List<DateCell>;

                        if (countMonthDates != null && resultMonthDates != null)
                        {
                            // 현재 월의 첫날 계산
                            DateTime currentMonthStart = new DateTime(
                                referenceDate.Year,
                                referenceDate.Month,
                                1
                            ).AddMonths(monthIndex);

                            // 각 일자별 처리
                            for (int dayIndex = 0; dayIndex < countMonthDates.Count; dayIndex++)
                            {
                                try
                                {
                                    DateTime currentDate;
                                    try
                                    {
                                        currentDate = currentMonthStart.AddDays(dayIndex);
                                    }
                                    catch
                                    {
                                        // 잘못된 날짜인 경우 처리 스킵
                                        countMonthDates[dayIndex].Day = "0";
                                        resultMonthDates[dayIndex].Day = "0";
                                        continue;
                                    }

                                    // 휴일 체크
                                    if (!IsWorkingDay(currentDate))
                                    {
                                        countMonthDates[dayIndex].Day = "0";
                                        resultMonthDates[dayIndex].Day = "0";
                                        continue;
                                    }

                                    // 일별 카운트 계산
                                    int crimsonCount = 0;
                                    int totalCount = 0;

                                    foreach (ShipSchedule schedule in itemsSource)
                                    {
                                        if (schedule.S_KIND == "LOAD 중일정개수" ||
                                            schedule.S_KIND == "LOAD 조정결과개수")
                                        {
                                            continue;
                                        }

                                        if (schedule.MonthlyDates != null &&
                                            monthIndex < schedule.MonthlyDates.Count)
                                        {
                                            List<DateCell> scheduleDates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
                                            if (scheduleDates != null &&
                                                dayIndex < scheduleDates.Count)
                                            {
                                                DateCell dateCell = scheduleDates[dayIndex];
                                                if (dateCell.Color == Brushes.Orange ||
                                                    dateCell.Color == Brushes.Crimson)
                                                {
                                                    totalCount++;
                                                    if (dateCell.Color == Brushes.Crimson)
                                                    {
                                                        crimsonCount++;
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // 결과 업데이트
                                    countMonthDates[dayIndex].Day = totalCount.ToString();
                                    int resultCount = totalCount - crimsonCount;
                                    if (resultCount < 0)
                                    {
                                        resultCount = 0;
                                    }
                                    resultMonthDates[dayIndex].Day = resultCount.ToString();
                                }
                                catch (Exception)
                                {
                                    // 개별 날짜 처리 중 오류 발생 시 0으로 설정
                                    countMonthDates[dayIndex].Day = "0";
                                    resultMonthDates[dayIndex].Day = "0";
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("UpdateCapeAdjustCount Error: " + ex.Message);
            }
        }
        private void ShipDataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (e.EditAction != DataGridEditAction.Commit)
                return;

            var editedItem = e.Row.Item as ShipSchedule;
            if (editedItem == null)
                return;

            // LOAD 관련 행은 수정 불가
            if (editedItem.S_KIND == "LOAD 중일정개수" ||
                editedItem.S_KIND == "LOAD 조정 개수" ||
                editedItem.S_KIND == "LOAD 조정결과개수")
            {
                e.Cancel = true;
                MessageBox.Show("LOAD 관련 행은 수정할 수 없습니다.", "수정 불가");
                return;
            }

            // 잠금 상태 체크 추가
            if (_isScheduleLocked)
            {
                DataGridTextColumn textColumn = e.Column as DataGridTextColumn;
                if (textColumn != null)
                {
                    // Split으로 나누기 전에 null 체크
                    string headerText = textColumn.Header != null ? textColumn.Header.ToString() : string.Empty;
                    string[] headerParts = headerText.Split(new[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);

                    if (headerParts.Length > 0)
                    {
                        string headerValue = headerParts[0];
                        if (headerValue == "시작계획일" ||
                            headerValue == "완료계획일" ||
                            headerValue == "탑재계획일")
                        {
                            e.Cancel = true;
                            MessageBox.Show("현재 일정이 잠금 상태입니다.", "수정 불가",
                                MessageBoxButton.OK, MessageBoxImage.Warning);
                            return;
                        }
                    }
                }
            }

            var editedTextBox = e.EditingElement as TextBox;
            if (editedTextBox == null)
                return;

            string newValue = editedTextBox.Text;
            DateTime parsedDate;

            // 날짜 형식 검증
            if (!DateTime.TryParse(newValue, out parsedDate))
            {
                e.Cancel = true;
                MessageBox.Show("올바른 날짜 형식으로 입력해주세요. (예: 2024-01-01)", "입력 오류");
                return;
            }

            // 날짜 범위 검증 및 업데이트
            var column = e.Column as DataGridTextColumn;
            if (column != null)
            {
                try
                {
                    switch (column.Header.ToString().Split('\n')[0])
                    {
                        case "착수실적일":
                            editedItem.WKSTPLDT = parsedDate;
                            break;
                        case "시작계획일":
                            editedItem.WKSTPLDT1 = parsedDate;
                            break;
                        case "완료계획일":
                            editedItem.WKFIPLDT = parsedDate;
                            break;
                        case "완료실적일":
                            editedItem.WKFIPLDT1 = parsedDate;
                            break;
                        case "탑재계획일":
                            editedItem.ERECT_PLDT = parsedDate;
                            break;
                    }

                    // 데이터 갱신 후 화면 업데이트
                    ProcessAndDisplayData(allData);
                }
                catch (Exception ex)
                {
                    e.Cancel = true;
                    MessageBox.Show("날짜 업데이트 중 오류가 발생했습니다: {ex.Message}", "오류");
                }
            }
        }

        // 근무일 기준으로 날짜를 조정하는 헬퍼 메서드 추가
        private DateTime AdjustWorkingDays(DateTime startDate, int days)
        {
            DateTime resultDate = startDate;
            int remainingDays = Math.Abs(days);
            int direction = days >= 0 ? 1 : -1;

            while (remainingDays > 0)
            {
                resultDate = resultDate.AddDays(direction);
                if (IsWorkingDay(resultDate))
                {
                    remainingDays--;
                }
            }
            return resultDate;
        }

        // TextBox의 KeyDown 이벤트 핸들러 추가
        private void SunPeTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                int inputDays = 0;
                if (int.TryParse(SunPeTextBox.Text, out inputDays))
                {
                    // 실제 이동할 날짜 수 계산 (주말/공휴일 제외)
                    DateTime testDate = DateTime.Today;
                    DateTime endDate = AdjustWorkingDays(testDate, inputDays);
                    int actualWorkingDays = 0;

                    // 실제 근무일수 계산
                    for (DateTime date = testDate; date <= endDate; date = date.AddDays(1))
                    {
                        if (IsWorkingDay(date))
                        {
                            actualWorkingDays++;
                        }
                    }

                    // TextBox에 실제 근무일수 표시
                    SunPeTextBox.Text = actualWorkingDays.ToString();
                }
            }
        }

        private void SunPeCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            int adjustDays = 0;
            if (!int.TryParse(SunPeTextBox.Text, out adjustDays))
            {
                MessageBox.Show("올바른 조정값을 입력해주세요.", "잘못된 입력", MessageBoxButton.OK, MessageBoxImage.Warning);
                SunPeCheckBox.IsChecked = false;
                return;
            }

            ProcessPeChanges("선PE", delegate(ShipSchedule schedule)
            {
                // 근무일 기준으로 날짜 조정
                DateTime adjustedDate = AdjustWorkingDays(schedule.WKSTPLDT1, adjustDays);
                schedule.WKSTPLDT1 = adjustedDate;
                schedule.IsWKSTPLDT1Modified = true;
            });
        }

        private void SunPeCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            int adjustDays = 0;
            if (!int.TryParse(SunPeTextBox.Text, out adjustDays))
            {
                MessageBox.Show("올바른 조정값을 입력해주세요.", "잘못된 입력", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ProcessPeChanges("선PE", delegate(ShipSchedule schedule)
            {
                // 근무일 기준으로 날짜 조정 (음수로 변환하여 반대 방향으로)
                DateTime adjustedDate = AdjustWorkingDays(schedule.WKSTPLDT1, -adjustDays);
                schedule.WKSTPLDT1 = adjustedDate;
                schedule.IsWKSTPLDT1Modified = false;
            });
        }


        // PE 체크박스 이벤트 핸들러 예시
        private void Pe1CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            int adjustDays = 0;
            if (!int.TryParse(Pe1TextBox.Text, out adjustDays))
            {
                MessageBox.Show("올바른 조정값을 입력해주세요.", "잘못된 입력", MessageBoxButton.OK, MessageBoxImage.Warning);
                Pe1CheckBox.IsChecked = false;
                return;
            }

            ProcessPeChanges("1PE", delegate(ShipSchedule schedule)
            {
                schedule.WKSTPLDT1 = AdjustWorkingDays(schedule.WKSTPLDT1, adjustDays);
                schedule.IsWKSTPLDT1Modified = true;
            });
        }

        private void Pe1CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            int adjustDays = 0;
            if (!int.TryParse(Pe1TextBox.Text, out adjustDays))
            {
                MessageBox.Show("올바른 조정값을 입력해주세요.", "잘못된 입력", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ProcessPeChanges("1PE", delegate(ShipSchedule schedule)
            {
                schedule.WKSTPLDT1 = AdjustWorkingDays(schedule.WKSTPLDT1, -adjustDays);
                schedule.IsWKSTPLDT1Modified = false;
            });
        }

        private void Pe2CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            int adjustDays = 0;
            if (!int.TryParse(Pe2TextBox.Text, out adjustDays))
            {
                MessageBox.Show("올바른 조정값을 입력해주세요.", "잘못된 입력", MessageBoxButton.OK, MessageBoxImage.Warning);
                Pe2CheckBox.IsChecked = false;
                return;
            }

            ProcessPeChanges("2PE", delegate(ShipSchedule schedule)
            {
                schedule.WKSTPLDT1 = AdjustWorkingDays(schedule.WKSTPLDT1, adjustDays);
                schedule.IsWKSTPLDT1Modified = true;
            });
        }

        private void Pe2CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            int adjustDays = 0;
            if (!int.TryParse(Pe2TextBox.Text, out adjustDays))
            {
                MessageBox.Show("올바른 조정값을 입력해주세요.", "잘못된 입력", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ProcessPeChanges("2PE", delegate(ShipSchedule schedule)
            {
                schedule.WKSTPLDT1 = AdjustWorkingDays(schedule.WKSTPLDT1, -adjustDays);
                schedule.IsWKSTPLDT1Modified = false;
            });
        }

        private void SunPeCheckBox1_Checked(object sender, RoutedEventArgs e)
        {
            int adjustDays = 0;
            if (!int.TryParse(SunPeTextBox1.Text, out adjustDays))
            {
                MessageBox.Show("올바른 조정값을 입력해주세요.", "잘못된 입력", MessageBoxButton.OK, MessageBoxImage.Warning);
                SunPeCheckBox1.IsChecked = false;
                return;
            }

            ProcessPeChanges("선PE", delegate(ShipSchedule schedule)
            {
                schedule.WKFIPLDT = AdjustWorkingDays(schedule.WKFIPLDT, adjustDays);
                schedule.IsWKFIPLDTModified = true;
            });
        }

        private void SunPeCheckBox1_Unchecked(object sender, RoutedEventArgs e)
        {
            int adjustDays = 0;
            if (!int.TryParse(SunPeTextBox1.Text, out adjustDays))
            {
                MessageBox.Show("올바른 조정값을 입력해주세요.", "잘못된 입력", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ProcessPeChanges("선PE", delegate(ShipSchedule schedule)
            {
                schedule.WKFIPLDT = AdjustWorkingDays(schedule.WKFIPLDT, -adjustDays);
                schedule.IsWKFIPLDTModified = false;
            });
        }

        private void Pe1CheckBox1_Checked(object sender, RoutedEventArgs e)
        {
            int adjustDays = 0;
            if (!int.TryParse(Pe1TextBox1.Text, out adjustDays))
            {
                MessageBox.Show("올바른 조정값을 입력해주세요.", "잘못된 입력", MessageBoxButton.OK, MessageBoxImage.Warning);
                Pe1CheckBox1.IsChecked = false;
                return;
            }

            ProcessPeChanges("1PE", delegate(ShipSchedule schedule)
            {
                schedule.WKFIPLDT = AdjustWorkingDays(schedule.WKFIPLDT, adjustDays);
                schedule.IsWKFIPLDTModified = true;
            });
        }

        private void Pe1CheckBox1_Unchecked(object sender, RoutedEventArgs e)
        {
            int adjustDays = 0;
            if (!int.TryParse(Pe1TextBox1.Text, out adjustDays))
            {
                MessageBox.Show("올바른 조정값을 입력해주세요.", "잘못된 입력", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ProcessPeChanges("1PE", delegate(ShipSchedule schedule)
            {
                schedule.WKFIPLDT = AdjustWorkingDays(schedule.WKFIPLDT, -adjustDays);
                schedule.IsWKFIPLDTModified = false;
            });
        }

        private void Pe2CheckBox1_Checked(object sender, RoutedEventArgs e)
        {
            int adjustDays = 0;
            if (!int.TryParse(Pe2TextBox1.Text, out adjustDays))
            {
                MessageBox.Show("올바른 조정값을 입력해주세요.", "잘못된 입력", MessageBoxButton.OK, MessageBoxImage.Warning);
                Pe2CheckBox1.IsChecked = false;
                return;
            }

            ProcessPeChanges("2PE", delegate(ShipSchedule schedule)
            {
                schedule.ERECT_PLDT = AdjustWorkingDays(schedule.ERECT_PLDT, adjustDays);
                schedule.IsERPLDTModified = true;
            });
        }

        private void Pe2CheckBox1_Unchecked(object sender, RoutedEventArgs e)
        {
            int adjustDays = 0;
            if (!int.TryParse(Pe2TextBox1.Text, out adjustDays))
            {
                MessageBox.Show("올바른 조정값을 입력해주세요.", "잘못된 입력", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            ProcessPeChanges("2PE", delegate(ShipSchedule schedule)
            {
                schedule.ERECT_PLDT = AdjustWorkingDays(schedule.ERECT_PLDT, -adjustDays);
                schedule.IsERPLDTModified = false;
            });
        }


        // 일괄 처리를 위한 최적화된 ProcessAndDisplayData 메서드
        private void ProcessAndDisplayDataOptimized(List<ShipSchedule> data, bool requireFullUpdate = false)
        {
            if (data == null || data.Count == 0)
            {
                ShipDataGrid.ItemsSource = null;
                return;
            }

            // 전체 업데이트가 필요한 경우에만 모든 처리 수행
            if (requireFullUpdate)
            {
                ProcessAndDisplayData(data);
                return;
            }

            // 부분 업데이트: UI 관련 속성만 업데이트
            Application.Current.Dispatcher.BeginInvoke(new Action(() =>
            {
                ShipDataGrid.Items.Refresh();
            }), DispatcherPriority.Background);
        }

        private DataTemplate CreateMonthHeaderTemplate(string monthText)
        {
            var template = new DataTemplate();
            var textBlock = new FrameworkElementFactory(typeof(TextBlock));
            textBlock.SetValue(TextBlock.TextProperty, monthText);
            textBlock.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            textBlock.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            textBlock.SetValue(TextBlock.FontSizeProperty, 12.0);
            template.VisualTree = textBlock;
            return template;
        }

        private DataTemplate CreateDateTemplate(string bindingPath)
        {
            var template = new DataTemplate();

            var itemsControl = new FrameworkElementFactory(typeof(ItemsControl));
            var stackPanel = new FrameworkElementFactory(typeof(StackPanel));
            stackPanel.SetValue(StackPanel.OrientationProperty, Orientation.Horizontal);

            var itemsPanelTemplate = new ItemsPanelTemplate(stackPanel);
            itemsControl.SetValue(ItemsControl.ItemsPanelProperty, itemsPanelTemplate);
            itemsControl.SetValue(ItemsControl.ItemsSourceProperty, new Binding(bindingPath));

            var itemTemplate = new DataTemplate();
            var border = new FrameworkElementFactory(typeof(Border));
            border.SetValue(Border.WidthProperty, 20.0);
            border.SetValue(Border.HeightProperty, 25.0);
            border.SetValue(Border.BorderBrushProperty, Brushes.Black);
            border.SetValue(Border.BorderThicknessProperty, new Thickness(0.5));
            border.SetValue(Border.BackgroundProperty, new Binding("Color"));

            var textBlock = new FrameworkElementFactory(typeof(TextBlock));
            textBlock.SetValue(TextBlock.TextProperty, new Binding("Day"));
            textBlock.SetValue(TextBlock.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            textBlock.SetValue(TextBlock.VerticalAlignmentProperty, VerticalAlignment.Center);
            textBlock.SetValue(TextBlock.FontSizeProperty, 11.0);

            border.AppendChild(textBlock);
            itemTemplate.VisualTree = border;
            itemsControl.SetValue(ItemsControl.ItemTemplateProperty, itemTemplate);

            template.VisualTree = itemsControl;
            return template;
        }
        private bool showCapeRows = false;

        //private void CHButton_Click(object sender, RoutedEventArgs e)
        //{
        //    try
        //    {
        //        // 현재 DataGrid의 데이터를 가져옴
        //        var displayData = ShipDataGrid.ItemsSource as List<ShipSchedule>;
        //        if (displayData == null || displayData.Count == 0)
        //        {
        //            MessageBox.Show("처리할 데이터가 없습니다.", "INFO(정보)/데이터없음");
        //            return;
        //        }

        //        // CAPE 행 생성
        //        ShipSchedule capeCountRow = new ShipSchedule
        //        {
        //            S_KIND = "LOAD 중일정개수",
        //            MonthlyDates = new ArrayList()
        //        };

        //        ShipSchedule capeResultRow = new ShipSchedule
        //        {
        //            S_KIND = "LOAD 조정결과개수",
        //            MonthlyDates = new ArrayList()
        //        };

        //        // 일반 데이터 찾기
        //        ShipSchedule firstSchedule = null;
        //        foreach (ShipSchedule schedule in displayData)
        //        {
        //            if (schedule.S_KIND != "LOAD 중일정개수" &&
        //                schedule.S_KIND != "LOAD 조정결과개수" &&
        //                schedule.MonthlyDates != null &&
        //                schedule.MonthlyDates.Count > 0)
        //            {
        //                firstSchedule = schedule;
        //                break;
        //            }
        //        }

        //        if (firstSchedule != null)
        //        {
        //            // 각 월별로 데이터 처리
        //            for (int monthIndex = 0; monthIndex < firstSchedule.MonthlyDates.Count; monthIndex++)
        //            {
        //                List<DateCell> countMonthDates = new List<DateCell>();
        //                List<DateCell> resultMonthDates = new List<DateCell>();
        //                List<DateCell> firstMonthDates = firstSchedule.MonthlyDates[monthIndex] as List<DateCell>;

        //                if (firstMonthDates != null)
        //                {
        //                    for (int dayIndex = 0; dayIndex < firstMonthDates.Count; dayIndex++)
        //                    {
        //                        // 현재 날짜에 대한 카운트
        //                        int totalCount = 0;      // 주황색 + 심홍색
        //                        int crimsonCount = 0;    // 심홍색만

        //                        foreach (ShipSchedule schedule in displayData)
        //                        {
        //                            if (schedule.S_KIND != "LOAD 중일정개수" &&
        //                                schedule.S_KIND != "LOAD 조정결과개수" &&
        //                                schedule.MonthlyDates != null &&
        //                                monthIndex < schedule.MonthlyDates.Count)
        //                            {
        //                                List<DateCell> monthDates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
        //                                if (monthDates != null && dayIndex < monthDates.Count)
        //                                {
        //                                    if (monthDates[dayIndex].Color == Brushes.Orange ||
        //                                        monthDates[dayIndex].Color == Brushes.Crimson)
        //                                    {
        //                                        totalCount++;
        //                                        if (monthDates[dayIndex].Color == Brushes.Crimson)
        //                                        {
        //                                            crimsonCount++;
        //                                        }
        //                                    }
        //                                }
        //                            }
        //                        }

        //                        // LOAD 중일정개수에는 전체 개수
        //                        countMonthDates.Add(new DateCell
        //                        {
        //                            Day = totalCount.ToString(),
        //                            Color = Brushes.LightGray
        //                        });

        //                        // LOAD 조정결과개수에는 전체 개수 - 심홍색 개수
        //                        resultMonthDates.Add(new DateCell
        //                        {
        //                            Day = (totalCount - crimsonCount).ToString(),
        //                            Color = Brushes.LightGray
        //                        });
        //                    }
        //                }

        //                capeCountRow.MonthlyDates.Add(countMonthDates);
        //                capeResultRow.MonthlyDates.Add(resultMonthDates);
        //            }

        //            // 현재 데이터에서 기존 LOAD 행 제거하고 새로운 LOAD 행 추가
        //            List<ShipSchedule> currentData = new List<ShipSchedule>();
        //            foreach (ShipSchedule item in displayData)
        //            {
        //                if (item.S_KIND != "LOAD 중일정개수" &&
        //                    item.S_KIND != "LOAD 조정결과개수")
        //                {
        //                    currentData.Add(item);
        //                }
        //            }
        //            currentData.Add(capeCountRow);
        //            currentData.Add(capeResultRow);

        //            ShipDataGrid.ItemsSource = currentData;
        //            ShipDataGrid1.ItemsSource = new List<ShipSchedule> { capeCountRow, capeResultRow };
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("LOAD 데이터 처리 중 오류가 발생했습니다:\n" + ex.Message,
        //                       "ERROR(오류)/LOAD처리실패");
        //    }
        //}
        private void CHButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // 현재 DataGrid의 데이터를 가져옴
                var displayData = ShipDataGrid.ItemsSource as List<ShipSchedule>;
                if (displayData == null || displayData.Count == 0)
                {
                    MessageBox.Show("처리할 데이터가 없습니다.", "INFO(정보)/데이터없음");
                    return;
                }

                // 삭제할 S_KIND 값 리스트
                var rowsToRemove = new HashSet<string>
        {
            "LOAD 중일정개수(본사)", "LOAD 조정결과개수(본사)",
            "LOAD 중일정개수(온산)", "LOAD 조정결과개수(온산)",
            "LOAD 중일정개수(해양)", "LOAD 조정결과개수(해양)"
        };

                // 기존의 'LOAD 중일정개수'와 'LOAD 조정결과개수' 행 찾기
                var existingCapeCountRow = displayData.FirstOrDefault(x => x.S_KIND == "LOAD 중일정개수");
                var existingCapeResultRow = displayData.FirstOrDefault(x => x.S_KIND == "LOAD 조정결과개수");

                // CAPE 행 초기화 또는 새로 생성
                ShipSchedule capeCountRow = existingCapeCountRow ?? new ShipSchedule
                {
                    S_KIND = "LOAD 중일정개수",
                    MonthlyDates = new ArrayList()
                };

                ShipSchedule capeResultRow = existingCapeResultRow ?? new ShipSchedule
                {
                    S_KIND = "LOAD 조정결과개수",
                    MonthlyDates = new ArrayList()
                };

                // 일반 데이터 찾기
                ShipSchedule firstSchedule = null;
                foreach (ShipSchedule schedule in displayData)
                {
                    if (!rowsToRemove.Contains(schedule.S_KIND) &&
                        schedule.MonthlyDates != null &&
                        schedule.MonthlyDates.Count > 0)
                    {
                        firstSchedule = schedule;
                        break;
                    }
                }

                if (firstSchedule != null)
                {
                    // 각 월별로 데이터 처리
                    capeCountRow.MonthlyDates.Clear();
                    capeResultRow.MonthlyDates.Clear();

                    for (int monthIndex = 0; monthIndex < firstSchedule.MonthlyDates.Count; monthIndex++)
                    {
                        List<DateCell> countMonthDates = new List<DateCell>();
                        List<DateCell> resultMonthDates = new List<DateCell>();
                        List<DateCell> firstMonthDates = firstSchedule.MonthlyDates[monthIndex] as List<DateCell>;

                        if (firstMonthDates != null)
                        {
                            for (int dayIndex = 0; dayIndex < firstMonthDates.Count; dayIndex++)
                            {
                                // 현재 날짜에 대한 카운트
                                int totalCount = 0;      // 주황색 + 심홍색
                                int crimsonCount = 0;    // 심홍색만

                                foreach (ShipSchedule schedule in displayData)
                                {
                                    if (!rowsToRemove.Contains(schedule.S_KIND) &&
                                        schedule.MonthlyDates != null &&
                                        monthIndex < schedule.MonthlyDates.Count)
                                    {
                                        List<DateCell> monthDates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
                                        if (monthDates != null && dayIndex < monthDates.Count)
                                        {
                                            if (monthDates[dayIndex].Color == Brushes.Orange ||
                                                monthDates[dayIndex].Color == Brushes.Crimson)
                                            {
                                                totalCount++;
                                                if (monthDates[dayIndex].Color == Brushes.Crimson)
                                                {
                                                    crimsonCount++;
                                                }
                                            }
                                        }
                                    }
                                }

                                // LOAD 중일정개수에는 전체 개수
                                countMonthDates.Add(new DateCell
                                {
                                    Day = totalCount.ToString(),
                                    Color = Brushes.LightGray
                                });

                                // LOAD 조정결과개수에는 전체 개수 - 심홍색 개수
                                resultMonthDates.Add(new DateCell
                                {
                                    Day = (totalCount - crimsonCount).ToString(),
                                    Color = Brushes.LightGray
                                });
                            }
                        }

                        capeCountRow.MonthlyDates.Add(countMonthDates);
                        capeResultRow.MonthlyDates.Add(resultMonthDates);
                    }

                    // 현재 데이터에서 삭제할 S_KIND 값에 해당하지 않는 데이터만 유지
                    List<ShipSchedule> currentData = new List<ShipSchedule>();
                    foreach (ShipSchedule item in displayData)
                    {
                        if (!rowsToRemove.Contains(item.S_KIND) &&
                            item.S_KIND != "LOAD 중일정개수" &&
                            item.S_KIND != "LOAD 조정결과개수")
                        {
                            currentData.Add(item);
                        }
                    }

                    // 기존 CAPE 행 유지 후 데이터 추가
                    currentData.Add(capeCountRow);
                    currentData.Add(capeResultRow);

                    // DataGrid 업데이트
                    ShipDataGrid.ItemsSource = currentData;
                    ShipDataGrid1.ItemsSource = new List<ShipSchedule> { capeCountRow, capeResultRow };
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("LOAD 데이터 처리 중 오류가 발생했습니다:\n" + ex.Message,
                               "ERROR(오류)/LOAD처리실패");
            }
        }

        //선택
        //private void CH2Button_Click(object sender, RoutedEventArgs e)
        //{
        //    if (GeneralCheckBox.IsChecked == true && MfdCheckBox.IsChecked == false)
        //    {
        //        // "일반" 체크박스가 선택된 경우
        //        CHButton_Click(sender, e); // 이벤트 매개변수 전달
        //    }
        //    else if (MfdCheckBox.IsChecked == true && GeneralCheckBox.IsChecked == false)
        //    {
        //        // "사업장" 체크박스가 선택된 경우
        //        CHButtonMFD_Click(sender, e); // 이벤트 매개변수 전달
        //    }
        //    else
        //    {
        //        MessageBox.Show("하나의 체크박스를 선택해주세요.", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
        //    }
        //}

        private void CH2Button_Click(object sender, RoutedEventArgs e)
        {
            // 기본 모드는 "일반"
            bool isGeneralChecked = GeneralCheckBox.IsChecked == true;
            bool isMfdChecked = MfdCheckBox.IsChecked == true;

            if (isGeneralChecked && !isMfdChecked)
            {
                // "일반" 모드: ShipDataGrid 80%, ShipDataGrid1 20%
                MainGrid.RowDefinitions[1].Height = new GridLength(5.5, GridUnitType.Star); // ShipDataGrid (90%)
                MainGrid.RowDefinitions[3].Height = new GridLength(1, GridUnitType.Star); // ShipDataGrid1 (10%)

                // "일반" 모드 로직 실행
                CHButton_Click(sender, e); // 일반 모드 로직
            }
            else if (!isGeneralChecked && isMfdChecked)
            {
                // "사업장" 모드: ShipDataGrid 60%, ShipDataGrid1 40%
                MainGrid.RowDefinitions[1].Height = new GridLength(5, GridUnitType.Star); // ShipDataGrid (70%)
                MainGrid.RowDefinitions[3].Height = new GridLength(2, GridUnitType.Star); // ShipDataGrid1 (30%)

                // "사업장" 모드 로직 실행
                CHButtonMFD_Click(sender, e); // 사업장 모드 로직
            }
            else
            {
                // 아무 모드도 선택되지 않은 경우 기본적으로 "일반"으로 처리
                MainGrid.RowDefinitions[1].Height = new GridLength(5.5, GridUnitType.Star); // ShipDataGrid (90%)
                MainGrid.RowDefinitions[3].Height = new GridLength(1, GridUnitType.Star); // ShipDataGrid1 (10%)

                // 기본적으로 "일반" 모드 로직 실행
                CHButton_Click(sender, e);
            }
        }


        private void CHButtonMFD_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var displayData = ShipDataGrid.ItemsSource as List<ShipSchedule>;
                if (displayData == null || displayData.Count == 0)
                {
                    MessageBox.Show("처리할 데이터가 없습니다.", "INFO(정보)/데이터없음");
                    return;
                }

                // 기존 전체 LOAD 행 생성
                ShipSchedule capeCountRow = new ShipSchedule
                {
                    S_KIND = "LOAD 중일정개수",
                    MonthlyDates = new ArrayList()
                };

                ShipSchedule capeResultRow = new ShipSchedule
                {
                    S_KIND = "LOAD 조정결과개수",
                    MonthlyDates = new ArrayList()
                };

                // 일반 데이터 찾기 (기존 코드 유지)
                ShipSchedule firstSchedule = null;
                foreach (ShipSchedule schedule in displayData)
                {
                    if (schedule.S_KIND != "LOAD 중일정개수" &&
                        schedule.S_KIND != "LOAD 조정결과개수" &&
                        schedule.MonthlyDates != null &&
                        schedule.MonthlyDates.Count > 0)
                    {
                        firstSchedule = schedule;
                        break;
                    }
                }

                if (firstSchedule != null)
                {
                    // 기존 전체 LOAD 계산 (기존 코드 유지)
                    for (int monthIndex = 0; monthIndex < firstSchedule.MonthlyDates.Count; monthIndex++)
                    {
                        List<DateCell> countMonthDates = new List<DateCell>();
                        List<DateCell> resultMonthDates = new List<DateCell>();
                        List<DateCell> firstMonthDates = firstSchedule.MonthlyDates[monthIndex] as List<DateCell>;

                        if (firstMonthDates != null)
                        {
                            for (int dayIndex = 0; dayIndex < firstMonthDates.Count; dayIndex++)
                            {
                                int totalCount = 0;
                                int crimsonCount = 0;

                                foreach (ShipSchedule schedule in displayData)
                                {
                                    if (schedule.S_KIND != "LOAD 중일정개수" &&
                                        schedule.S_KIND != "LOAD 조정결과개수" &&
                                        schedule.MonthlyDates != null &&
                                        monthIndex < schedule.MonthlyDates.Count)
                                    {
                                        List<DateCell> monthDates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
                                        if (monthDates != null && dayIndex < monthDates.Count)
                                        {
                                            if (monthDates[dayIndex].Color == Brushes.Orange ||
                                                monthDates[dayIndex].Color == Brushes.Crimson)
                                            {
                                                totalCount++;
                                                if (monthDates[dayIndex].Color == Brushes.Crimson)
                                                {
                                                    crimsonCount++;
                                                }
                                            }
                                        }
                                    }
                                }

                                countMonthDates.Add(new DateCell
                                {
                                    Day = totalCount.ToString(),
                                    Color = Brushes.LightGray
                                });

                                resultMonthDates.Add(new DateCell
                                {
                                    Day = (totalCount - crimsonCount).ToString(),
                                    Color = Brushes.LightGray
                                });
                            }
                        }

                        capeCountRow.MonthlyDates.Add(countMonthDates);
                        capeResultRow.MonthlyDates.Add(resultMonthDates);
                    }

                    // 사업장별 LOAD 행 생성 및 계산 추가
                    List<ShipSchedule> locationLoadRows = new List<ShipSchedule>();
                    string[] locations = new[] { "본사", "온산", "해양" };

                    foreach (string location in locations)
                    {
                        var locationCountRow = new ShipSchedule
                        {
                            S_KIND = "LOAD 중일정개수(" + location + ")",
                            MonthlyDates = new ArrayList()
                        };

                        var locationResultRow = new ShipSchedule
                        {
                            S_KIND = "LOAD 조정결과개수(" + location + ")",
                            MonthlyDates = new ArrayList()
                        };

                        // 각 월별 데이터 처리
                        for (int monthIndex = 0; monthIndex < firstSchedule.MonthlyDates.Count; monthIndex++)
                        {
                            List<DateCell> countMonthDates = new List<DateCell>();
                            List<DateCell> resultMonthDates = new List<DateCell>();
                            List<DateCell> firstMonthDates = firstSchedule.MonthlyDates[monthIndex] as List<DateCell>;

                            if (firstMonthDates != null)
                            {
                                for (int dayIndex = 0; dayIndex < firstMonthDates.Count; dayIndex++)
                                {
                                    int locationCount = 0;
                                    int locationResult = 0;

                                    foreach (ShipSchedule schedule in displayData)
                                    {
                                        if (schedule.S_KIND != "LOAD 중일정개수" &&
                                            schedule.S_KIND != "LOAD 조정결과개수" &&
                                            schedule.MonthlyDates != null &&
                                            monthIndex < schedule.MonthlyDates.Count)
                                        {
                                            if (schedule.MFG_IND_After == location)
                                            {
                                                List<DateCell> monthDates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
                                                if (monthDates != null && dayIndex < monthDates.Count)
                                                {
                                                    if (monthDates[dayIndex].Color == Brushes.Orange ||
                                                        monthDates[dayIndex].Color == Brushes.Crimson)
                                                    {
                                                        locationCount++;
                                                    }
                                                }
                                            }

                                            if (schedule.MFG_IND == location)
                                            {
                                                List<DateCell> monthDates = schedule.MonthlyDates[monthIndex] as List<DateCell>;
                                                if (monthDates != null && dayIndex < monthDates.Count)
                                                {
                                                    if (monthDates[dayIndex].Color == Brushes.Orange ||
                                                        monthDates[dayIndex].Color == Brushes.Crimson)
                                                    {
                                                        locationResult++;
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    countMonthDates.Add(new DateCell
                                    {
                                        Day = locationCount.ToString(),
                                        Color = Brushes.LightGray
                                    });

                                    resultMonthDates.Add(new DateCell
                                    {
                                        Day = locationResult.ToString(),
                                        Color = locationResult < locationCount
                                            ? new SolidColorBrush(Color.FromRgb(255, 127, 127)) // 밝은 빨간색 (LightCoral)
                                            : locationResult > locationCount
                                                ? new SolidColorBrush(Color.FromRgb(81, 240, 169)) // 밝은 초록색 (LightGreen)
                                                : Brushes.LightGray
                                    });
                                }
                            }

                            locationCountRow.MonthlyDates.Add(countMonthDates);
                            locationResultRow.MonthlyDates.Add(resultMonthDates);
                        }

                        locationLoadRows.Add(locationCountRow);
                        locationLoadRows.Add(locationResultRow);
                    }

                    // 현재 데이터 유지 및 LOAD 행 추가
                    List<ShipSchedule> currentData = new List<ShipSchedule>();
                    foreach (ShipSchedule item in displayData)
                    {
                        if (item.S_KIND != "LOAD 중일정개수" &&
                            item.S_KIND != "LOAD 조정결과개수" &&
                            !item.S_KIND.StartsWith("LOAD 중일정개수(") &&
                            !item.S_KIND.StartsWith("LOAD 조정결과개수("))
                        {
                            currentData.Add(item);
                        }
                    }

                    currentData.Add(capeCountRow);
                    currentData.Add(capeResultRow);
                    foreach (ShipSchedule row in locationLoadRows)
                    {
                        currentData.Add(row);
                    }

                    // UI 업데이트
                    ShipDataGrid.ItemsSource = currentData;

                    // ShipDataGrid1 업데이트
                    List<ShipSchedule> grid1Data = new List<ShipSchedule> { capeCountRow, capeResultRow };
                    grid1Data.AddRange(locationLoadRows);
                    ShipDataGrid1.ItemsSource = grid1Data;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("LOAD 데이터 처리 중 오류가 발생했습니다:\n" + ex.Message,
                               "ERROR(오류)/LOAD처리실패");
            }
        }


        //private void SQLOpenMenuItem_Click(object sender, RoutedEventArgs e)
        //{
        //    MessageBox.Show("미포 SQL은 마지막에 예정 준비중입니다..");
        //}
        private void SQLOpenMenuItem_Click(object sender, RoutedEventArgs e)
        {
            // 필터 선택을 위한 윈도우 생성
            Window filterWindow = new Window
            {
                Title = "미포조선 SQL로드",
                Width = 300,
                Height = 300,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = this,
                ResizeMode = ResizeMode.NoResize
            };

            StackPanel mainPanel = new StackPanel
            {
                Margin = new Thickness(10)
            };

            // 착수/완료 선택 라디오 버튼 그룹
            StackPanel radioPanel = new StackPanel
            {
                Margin = new Thickness(0, 0, 0, 10)
            };

            RadioButton startDateRadio = new RadioButton
            {
                Content = "착수",
                IsChecked = true,
                Margin = new Thickness(0, 0, 0, 5)
            };

            RadioButton endDateRadio = new RadioButton
            {
                Content = "완료",
                Margin = new Thickness(0, 0, 0, 5)
            };

            radioPanel.Children.Add(startDateRadio);
            radioPanel.Children.Add(endDateRadio);

            // 날짜 선택 패널
            StackPanel datePanel = new StackPanel();

            // 시작 날짜
            StackPanel startDatePanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 5)
            };
            Label startLabel = new Label { Content = "시작: " };
            DatePicker startDatePicker = new DatePicker { Width = 120 };
            startDatePanel.Children.Add(startLabel);
            startDatePanel.Children.Add(startDatePicker);

            // 종료 날짜
            StackPanel endDatePanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 0, 0, 10)
            };
            Label endLabel = new Label { Content = "종료: " };
            DatePicker endDatePicker = new DatePicker { Width = 120 };
            endDatePanel.Children.Add(endLabel);
            endDatePanel.Children.Add(endDatePicker);

            // 호선 입력
            Label shipNoLabel = new Label { Content = "호선 (부분 입력 가능):" };
            TextBox shipNoTextBox = new TextBox
            {
                Width = 200,
                Margin = new Thickness(0, 0, 0, 10)
            };

            // 버튼 패널
            StackPanel buttonPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            Button okButton = new Button
            {
                Content = "확인",
                Width = 75,
                Height = 23,
                Margin = new Thickness(0, 0, 5, 0)
            };
            Button cancelButton = new Button
            {
                Content = "취소",
                Width = 75,
                Height = 23
            };

            buttonPanel.Children.Add(okButton);
            buttonPanel.Children.Add(cancelButton);

            // 메인 패널에 컨트롤 추가
            mainPanel.Children.Add(radioPanel);
            mainPanel.Children.Add(startDatePanel);
            mainPanel.Children.Add(endDatePanel);
            mainPanel.Children.Add(shipNoLabel);
            mainPanel.Children.Add(shipNoTextBox);
            mainPanel.Children.Add(buttonPanel);

            filterWindow.Content = mainPanel;

            string selDateDiv = "착수";
            DateTime? startDate = null;
            DateTime? endDate = null;
            string shipNo = "";
            bool? dialogResult = null;

            okButton.Click += (s, ev) =>
            {
                if (startDatePicker.SelectedDate.HasValue && endDatePicker.SelectedDate.HasValue)
                {
                    startDate = startDatePicker.SelectedDate.Value;
                    endDate = endDatePicker.SelectedDate.Value;

                    if (startDate > endDate)
                    {
                        MessageBox.Show("시작일이 종료일보다 늦을 수 없습니다.", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }

                    selDateDiv = startDateRadio.IsChecked == true ? "착수" : "완료";
                    shipNo = shipNoTextBox.Text;
                    dialogResult = true;
                    filterWindow.Close();
                }
                else
                {
                    MessageBox.Show("날짜 범위를 선택해주세요.", "경고", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            };

            cancelButton.Click += (s, ev) =>
            {
                dialogResult = false;
                filterWindow.Close();
            };

            filterWindow.ShowDialog();

            if (dialogResult != true)
                return;

            try
            {
                var progressWindow = new Window()
                {
                    Title = "데이터 로딩 중...",
                    Width = 300,
                    Height = 100,
                    WindowStartupLocation = WindowStartupLocation.CenterOwner,
                    Owner = this,
                    ResizeMode = ResizeMode.NoResize
                };

                var progressBar = new ProgressBar()
                {
                    Width = 280,
                    Height = 20,
                    Margin = new Thickness(10),
                    IsIndeterminate = true
                };

                progressWindow.Content = progressBar;
                progressWindow.Show();

                BackgroundWorker worker = new BackgroundWorker();

                worker.DoWork += delegate(object s, DoWorkEventArgs args)
                {
                    try
                    {
                        var dataAccessService = new DataAccessService();
                        string startDateStr = startDate.Value.ToString("yyyyMMdd");
                        string endDateStr = endDate.Value.ToString("yyyyMMdd");
                        DataTable resultData = dataAccessService.GetCranePeData(selDateDiv, startDateStr, endDateStr, shipNo);
                        args.Result = resultData;
                    }
                    catch (Exception ex)
                    {
                        args.Result = ex;
                    }
                };

                worker.RunWorkerCompleted += delegate(object s, RunWorkerCompletedEventArgs args)
                {
                    progressWindow.Close();

                    if (args.Result is Exception)
                    {
                        MessageBox.Show("데이터 로드 중 오류 발생:\n" + ((Exception)args.Result).Message);
                        return;
                    }

                    DataTable loadedData = args.Result as DataTable;
                    if (loadedData != null && loadedData.Rows.Count > 0)
                    {
                        List<ShipSchedule> scheduleData = ConvertDataTableToShipSchedule(loadedData);
                        scheduleData = scheduleData.OrderBy(schedule => schedule.WKSTPLDT1).ToList();

                        if (scheduleData.Count > 0)
                        {
                            allData = scheduleData;
                            ProcessAndDisplayData(allData);
                            EnableControls(true);

                            string message = string.Format(
                                "SQL에서 데이터 로드 완료: {0}건\n기간: {1:yyyy/MM/dd} ~ {2:yyyy/MM/dd}",
                                scheduleData.Count,
                                startDate.Value,
                                endDate.Value
                            );
                            MessageBox.Show(message, "INFO(정보)/데이터로드");
                            // 데이터 로드가 완전히 끝난 후 Reset_Click 실행
                            Dispatcher.BeginInvoke(new Action(() =>
                            {
                                try
                                {
                                    Reset_Click(null, new RoutedEventArgs());
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show(
                                        "자동 저장 중 오류가 발생했습니다: " + ex.Message,
                                        "ERROR(오류)/자동저장실패",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Warning
                                    );
                                }
                            }), DispatcherPriority.Background);
                        }
                    }
                    else
                    {
                        MessageBox.Show("로드된 데이터가 없습니다.", "INFO(정보)/데이터없음");
                    }
                };

                worker.RunWorkerAsync();
            }
            catch (Exception ex)
            {
                MessageBox.Show("SQL 데이터 로드 중 오류 발생:\n" + ex.Message, "ERROR(오류)/데이터로드실패");
            }
        }


        // DataTable을 ShipSchedule로 변환하는 메서드 추가
        private List<ShipSchedule> ConvertDataTableToShipSchedule(DataTable dataTable)
        {
            List<ShipSchedule> schedules = new List<ShipSchedule>();

            foreach (DataRow row in dataTable.Rows)
            {
                ShipSchedule schedule = new ShipSchedule
                {
                    S_KIND = Convert.ToString(row["S_KIND"]),
                    S_TYPE = Convert.ToString(row["S_TYPE"]),
                    OWNER = Convert.ToString(row["OWNER"]),
                    SHIP_DISP = Convert.ToString(row["SHIP_DISP"]),
                    BLOCK = Convert.ToString(row["BLOCK"]),
                    STG_CD = Convert.ToString(row["STG_CD"]),
                    S_NAME = Convert.ToString(row["S_NAME"]),
                    MFG_IND = Convert.ToString(row["MFG_IND"]),
                    MFG_IND_After = Convert.ToString(row["MFG_IND"]),
                    LOC_DESC = Convert.ToString(row["LOC_DESC"]),
                    LOC_EQP = Convert.ToString(row["PE_TOOLS"]),  // PE_TOOLS 컬럼을 LOC_EQP에 매핑
                    Dur = Convert.ToString(row["DUR"]),  // DUR 컬럼을 Dur에 매핑
                    PE_TYPE = "일반"  // 기본값
                };

                // 날짜 변환
                DateTime wkstpldt, wkfipldt, erectPldt, wkstpldtPp, wkfipldtPp;

                // 시작계획일
                if (DateTime.TryParse(Convert.ToString(row["WKSTPLDT"]), out wkstpldt))
                    schedule.WKSTPLDT1 = wkstpldt;

                // 완료계획일
                if (DateTime.TryParse(Convert.ToString(row["WKFIPLDT"]), out wkfipldt))
                    schedule.WKFIPLDT = wkfipldt;

                // 탑재계획일
                if (DateTime.TryParse(Convert.ToString(row["ERECT_PLDT"]), out erectPldt))
                    schedule.ERECT_PLDT = erectPldt;

                // 착수실적일
                if (DateTime.TryParse(Convert.ToString(row["WKSTDT_PP"]), out wkstpldtPp))
                    schedule.WKSTPLDT = wkstpldtPp;

                // 완료실적일
                if (DateTime.TryParse(Convert.ToString(row["WKFIDT_PP"]), out wkfipldtPp))
                    schedule.WKFIPLDT1 = wkfipldtPp;

                // PE Type 설정 로직 호출
                schedule.SetPEType();
                schedules.Add(schedule);
            }

            return schedules;
        }
        private void ExitMenuItem_Click(object sender, RoutedEventArgs e)
        {
            // 종료 여부를 묻는 메시지 표시
            MessageBoxResult result = MessageBox.Show("프로그램을 종료하시겠습니까?", "종료 확인", MessageBoxButton.YesNo, MessageBoxImage.Question);

            // 사용자가 "Yes"를 선택한 경우에만 종료
            if (result == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }
        private void ALLCopyMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("개별복사 키보드ctrl+마우스 오른쪽/다중선택은 shift+마우스 오른쪽");
        }

        private void ALLPasteMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("개별복사 키보드ctrl+마우스 오른쪽/다중선택은 shift+마우스 오른쪽");
        }

        private void ALLDADeleteMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("개별복사 키보드ctrl+마우스 오른쪽/다중선택은 shift+마우스 오른쪽");
        }
        private void AboutMenuItem_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("버전V1.0 미포조선 CRANE PE 부하률 시뮬레이션입니다.");
        }
        private List<DateCell> GenerateMonthDates(DateTime startDate, DateTime endDate, int month, int daysInMonth)
        {
            var dates = new List<DateCell>();
            var currentDate = new DateTime(2024, month, 1);
            var lastDate = new DateTime(2024, month, daysInMonth);

            while (currentDate <= lastDate)
            {
                var color = (currentDate >= startDate && currentDate <= endDate)
                    ? Brushes.Orange : Brushes.White;

                dates.Add(new DateCell
                {
                    Day = currentDate.Day.ToString("D2"),
                    Color = color
                });

                currentDate = currentDate.AddDays(1);
            }

            return dates;
        }

        private void ShipDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ShipDataGrid_Copy_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ShipDataGrid_Copy_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }
    }


    // ShipSchedule 클래스에 PE구분 속성 추가
    public class ShipSchedule
    {
        public ShipSchedule()
        {
            MonthlyDates = new ArrayList();
            FirstMonthDates = new List<DateCell>();
            SecondMonthDates = new List<DateCell>();
        }
        public bool IsSelected { get; set; }
        public string S_KIND { get; set; }
        public string S_TYPE { get; set; }
        public string OWNER { get; set; }
        public string SHIP_DISP { get; set; }
        public string BLOCK { get; set; }
        public string STG_CD { get; set; }
        public string S_NAME { get; set; }
        public string LOC_DESC { get; set; }
        public string LOC_EQP { get; set; }
        public string PE_TYPE { get; set; } // 새로 추가된 PE구분 속성
        public string MFG_IND { get; set; } //사업장 이동
        public string MFG_IND_After { get; set; }  // 사업장 오리지날
        public DateTime WKSTPLDT { get; set; }
        public DateTime WKSTPLDT1 { get; set; }
        public DateTime WKFIPLDT { get; set; }
        public DateTime WKFIPLDT1 { get; set; }
        public DateTime ERECT_PLDT { get; set; }
        public List<DateCell> FirstMonthDates { get; set; }
        public List<DateCell> SecondMonthDates { get; set; }
        public ArrayList MonthlyDates { get; set; }
        public bool IsWKSTPLDT1Modified { get; set; }
        public bool IsWKFIPLDTModified { get; set; }
        public bool IsERPLDTModified { get; set; }  // 탑재계획일 변경 플래그 추가
        //public bool IsMfgModified { get; set; } // 사업장 수정 여부
        public bool IsMfgModified
        {
            get { return !string.Equals(MFG_IND, MFG_IND_After); }
            set { }  // 값을 직접 설정할 필요 없음
        }
        public string OriginalMfgInd { get; set; }  // 원래 사업장 값 저장
        public string Dur { get; set; }//계획공기 추가

        public int ColoredDaysCount
        {
            get
            {
                if (S_KIND == "LOAD 중일정개수" || S_KIND == "LOAD 조정 개수" || S_KIND == "LOAD 조정결과개수")
                    return 0;

                DateTime endDate;
                switch (STG_CD)
                {
                    case "90":  // 탑재
                        endDate = ERECT_PLDT;
                        break;
                    case "70":  // PE 블록
                    case "80":  // PE 블록
                        endDate = WKFIPLDT;  // 완료계획일 사용
                        break;
                    default:
                        endDate = WKFIPLDT1;  // 그 외의 경우 완료실적일 사용
                        break;
                }

                return (endDate - WKSTPLDT1).Days + 1;
            }
        }

        //PE구분을 자동으로 설정하는 메서드 추가
        public void SetPEType()
        {
            if (string.IsNullOrEmpty(BLOCK))
            {
                PE_TYPE = "일반";
                return;
            }

            // 블록의 첫 글자 가져오기
            char firstChar = BLOCK[0];

            switch (firstChar)
            {
                case '1':
                case '5':
                    PE_TYPE = "1PE";
                    break;
                case '0':
                case '9':
                    PE_TYPE = "선PE";
                    break;
                case '2':
                    PE_TYPE = "2PE";
                    break;
                default:
                    PE_TYPE = "일반";
                    break;
            }
        }
        //public void SetPEType()
        //{
        //    if (string.IsNullOrEmpty(BLOCK))
        //    {
        //        PE_TYPE = "일반";
        //        return;
        //    }

        //    // LOC_DESC 기반으로 PE_TYPE 설정
        //    if (MFG_IND == "본사")
        //    {
        //        switch (LOC_DESC)
        //        {
        //            case "1D 서":
        //                PE_TYPE = "1PE";
        //                break;
        //            case "총조장":
        //                PE_TYPE = "2PE";
        //                break;
        //            case "2 - 3D":
        //                PE_TYPE = "3PE";
        //                break;
        //            case "4D 동":
        //                PE_TYPE = "4PE";
        //                break;
        //            default:
        //                PE_TYPE = "일반";
        //                break;
        //        }
        //    }
        //    else
        //    {
        //        // 기존의 블록 기반 로직 유지
        //        char firstChar = BLOCK[0];
        //        switch (firstChar)
        //        {
        //            case '1':
        //            case '5':
        //                PE_TYPE = "1PE";
        //                break;
        //            case '0':
        //            case '9':
        //                PE_TYPE = "선PE";
        //                break;
        //            case '2':
        //                PE_TYPE = "2PE";
        //                break;
        //            default:
        //                PE_TYPE = "일반";
        //                break;
        //        }
        //    }
        //}
    }


    public class DateCell : INotifyPropertyChanged
    {
        private string day;
        private Brush color;

        public string Day
        {
            get { return day; }
            set
            {
                if (day != value)
                {
                    day = value;
                    OnPropertyChanged("Day");
                }
            }
        }

        public Brush Color
        {
            get { return color; }
            set
            {
                if (color != value)
                {
                    color = value;
                    OnPropertyChanged("Color");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }
    }
}