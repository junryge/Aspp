#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
test_send_ui.py - OHT raw 메시지 전송 테스트 UI

sim_server_3d_D5_D7.py 의 /api/oht-raw 엔드포인트로 OHT 메시지를 보내서
화면에 차량이 표시되는지 확인하기 위한 간단한 Tkinter GUI.

사용법:
    python test_send_ui.py

기능:
    - 서버 URL 설정
    - 메시지 붙여넣기 후 [전송] 버튼
    - 샘플 메시지 로드
    - TXT 파일에서 메시지 불러오기
    - 대량 차량 자동 생성 (layout_cache.json 기반)
    - 자동 반복 전송 (그래프 위 실제 이동 시뮬레이션)
"""

import json
import os
import random
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
import urllib.error
import urllib.request
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional
import heapq


DEFAULT_SERVER_URL = "http://localhost:10003"
DEFAULT_ENDPOINT = "/api/oht-raw"

# layout_cache.json 경로 (자동 탐색)
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_LAYOUT_CACHE = os.path.join(_SCRIPT_DIR, "layout_cache.json")

# 가이드 문서 기준 샘플 메시지 (21필드)
SAMPLE_MESSAGES = [
    "2,OHT,V00795,1,1,0000,1,12340,14,12341,4,4,4PDMV608,36073,00000000,0000,4ABL3301A_OUT04,4ANZ19-701,90,0,0",
    "2,OHT,V00564,1,0,0000,1,2115,9,2116,4,4,,0,00000000,0000,,,0,0,0",
    "2,OHT,V00123,2,1,0000,1,5010,0,5011,4,4,4PDMV700,30000,00000000,0000,4ABL1101A_OUT02,4ABL2201B_IN01,50,0,0",
]


# ============================================================
# 그래프 기반 차량 시뮬레이터
# ============================================================

@dataclass
class SimVehicle:
    """시뮬레이션 차량 상태"""
    vid: str
    currentNode: int
    nextNode: int
    distance: int           # 현재 엣지 위 거리 (100mm 단위)
    destination: int
    isFull: int
    path: List[int] = field(default_factory=list)
    pathIndex: int = 0
    state: int = 1          # 1=RUN, 2=STOP
    speed: int = 5          # 틱당 이동 거리 (100mm 단위)


class GraphSimulator:
    """
    layout_cache.json 기반 차량 이동 시뮬레이터.
    차량이 그래프 위의 엣지를 따라 실제로 이동하며,
    엣지 끝에 도달하면 다음 노드로 전환한다.
    """

    def __init__(self, layout_cache_path: str = DEFAULT_LAYOUT_CACHE):
        with open(layout_cache_path, 'r', encoding='utf-8') as f:
            cache = json.load(f)

        # 노드 목록
        self.node_ids = list(cache.get('nodes', {}).keys())

        # 인접 리스트: {node_id: [(next_node, distance), ...]}
        self.adj: Dict[int, List[Tuple[int, float]]] = defaultdict(list)
        raw_adj = cache.get('adj', {})
        for node_str, neighbors in raw_adj.items():
            node = int(node_str)
            for nb in neighbors:
                nb = int(nb)
                edge_key = f"{node},{nb}"
                dist = cache.get('edges', {}).get(edge_key, 5000.0)
                self.adj[node].append((nb, float(dist)))

        # 엣지 거리: {(from, to): distance_mm}
        self.edge_dist: Dict[Tuple[int, int], float] = {}
        for edge_key, dist in cache.get('edges', {}).items():
            parts = edge_key.split(",")
            self.edge_dist[(int(parts[0]), int(parts[1]))] = float(dist)

        # 차량 저장소
        self.vehicles: Dict[str, SimVehicle] = {}

    def find_path(self, start: int, end: int) -> List[int]:
        """Dijkstra 최단 경로 탐색"""
        if start == end or start not in self.adj:
            return []
        dist_map = {start: 0}
        prev = {}
        pq = [(0, start)]
        while pq:
            d, u = heapq.heappop(pq)
            if u == end:
                break
            if d > dist_map.get(u, float('inf')):
                continue
            for v, w in self.adj.get(u, []):
                nd = d + w
                if nd < dist_map.get(v, float('inf')):
                    dist_map[v] = nd
                    prev[v] = u
                    heapq.heappush(pq, (nd, v))
        if end not in prev:
            return []
        path = []
        curr = end
        while curr in prev:
            path.append(curr)
            curr = prev[curr]
        path.append(start)
        path.reverse()
        return path

    def generate_vehicles(self, count: int, speed: int = 5) -> int:
        """
        count 대의 차량을 그래프 위 랜덤 위치에 배치.
        각 차량에 랜덤 목적지 + 경로를 할당.
        Returns: 실제 생성된 차량 수

        거리 단위:
          layout_cache.json의 edge 거리 = 좌표거리 × 10 (oht_position.py line 239)
          OHT 메시지의 distance = 100mm 단위
          oht_position.py에서 ratio = distance / edge_len 으로 보간
          → distance 범위: 0 ~ edge_len
        """
        self.vehicles.clear()
        edges = list(self.edge_dist.keys())
        if not edges or not self.node_ids:
            return 0

        created = 0
        for i in range(count):
            vid = f"V{i:05d}"

            # 랜덤 엣지에 배치
            from_node, to_node = random.choice(edges)
            edge_len = self.edge_dist.get((from_node, to_node), 100.0)
            # distance 범위: 0 ~ edge_len (둘 다 같은 단위)
            max_dist = max(1, int(edge_len))
            distance = random.randint(0, max_dist)

            # 랜덤 목적지 + 경로
            dest = int(random.choice(self.node_ids))
            attempts = 0
            while dest == from_node and attempts < 10:
                dest = int(random.choice(self.node_ids))
                attempts += 1

            path = self.find_path(from_node, dest)
            if not path or len(path) < 2:
                # 경로 못 찾으면 인접 노드로 이동
                neighbors = self.adj.get(from_node, [])
                if neighbors:
                    dest = neighbors[0][0]
                    path = [from_node, dest]
                else:
                    continue

            self.vehicles[vid] = SimVehicle(
                vid=vid,
                currentNode=from_node,
                nextNode=to_node,
                distance=distance,
                destination=dest,
                isFull=random.choice([0, 1]),
                path=path,
                pathIndex=0,
                speed=speed,
            )
            created += 1

        return created

    def tick(self) -> List[str]:
        """
        모든 차량을 1틱 이동시키고, OHT 메시지 리스트를 반환.
        앞차가 막히면 뒤차도 못 감 (블로킹).
        엣지 끝에 도달하면 다음 노드로 전환.
        """
        # 1. 엣지별 차량 인덱스 구축
        edge_vehicles: Dict[Tuple[int, int], List[str]] = defaultdict(list)
        for vid, v in self.vehicles.items():
            edge_vehicles[(v.currentNode, v.nextNode)].append(vid)

        # 2. 각 차량 이동 (블로킹 체크 포함)
        messages = []
        for vid, v in self.vehicles.items():
            if v.state != 1:  # RUN이 아니면 스킵
                messages.append(self._to_message(v))
                continue

            # 블로킹 체크: 같은 엣지에서 앞에 있는 차량 확인
            edge_key = (v.currentNode, v.nextNode)
            blocked = False
            for other_vid in edge_vehicles.get(edge_key, []):
                if other_vid == vid:
                    continue
                other = self.vehicles[other_vid]
                # 앞에 있는 차량 (distance가 더 큰 차량)
                if other.distance > v.distance:
                    gap = other.distance - v.distance
                    # 간격이 너무 좁으면 (차량 길이 ~10 단위) 블로킹
                    if gap <= v.speed + 10:
                        # 앞차 바로 뒤에서 정지
                        v.distance = max(0, other.distance - 10)
                        v.state = 7  # JAM
                        blocked = True
                        break

            if blocked:
                messages.append(self._to_message(v))
                continue

            # JAM에서 복구 체크: 앞차가 빠졌으면 다시 RUN
            if v.state == 7:
                v.state = 1

            # 이동
            v.distance += v.speed

            # 엣지 끝 도달 체크
            edge_len = self.edge_dist.get(edge_key, 100.0)
            max_dist = max(1, int(edge_len))

            # 다음 엣지 시작점에 차량 있으면 진입 불가
            if v.distance >= max_dist:
                next_node = v.nextNode
                # 다음 엣지에서 시작점 근처에 차량 있는지 확인
                can_enter = True
                if v.path and v.pathIndex + 2 < len(v.path):
                    next_next = v.path[v.pathIndex + 2]
                    next_edge = (next_node, next_next)
                    for other_vid in edge_vehicles.get(next_edge, []):
                        other = self.vehicles[other_vid]
                        if other.distance < 15:  # 시작점 근처
                            can_enter = False
                            break

                if not can_enter:
                    # 현재 엣지 끝에서 정지
                    v.distance = max_dist - 1
                    v.state = 7  # JAM
                    messages.append(self._to_message(v))
                    continue

            while v.distance >= max_dist:
                overflow = v.distance - max_dist
                v.currentNode = v.nextNode
                v.pathIndex += 1

                if v.currentNode == v.destination or v.pathIndex + 1 >= len(v.path):
                    self._assign_new_destination(v)

                if v.pathIndex + 1 < len(v.path):
                    v.nextNode = v.path[v.pathIndex + 1]
                else:
                    neighbors = self.adj.get(v.currentNode, [])
                    if neighbors:
                        v.nextNode = neighbors[0][0]
                    else:
                        v.distance = 0
                        break

                edge_key = (v.currentNode, v.nextNode)
                edge_len = self.edge_dist.get(edge_key, 100.0)
                max_dist = max(1, int(edge_len))
                v.distance = overflow

            messages.append(self._to_message(v))

        return messages

    def _assign_new_destination(self, v: SimVehicle):
        """새 목적지와 경로를 할당"""
        dest = int(random.choice(self.node_ids))
        attempts = 0
        while dest == v.currentNode and attempts < 10:
            dest = int(random.choice(self.node_ids))
            attempts += 1

        path = self.find_path(v.currentNode, dest)
        if path and len(path) >= 2:
            v.destination = dest
            v.path = path
            v.pathIndex = 0
        else:
            # 못 찾으면 인접 노드로
            neighbors = self.adj.get(v.currentNode, [])
            if neighbors:
                v.destination = neighbors[0][0]
                v.path = [v.currentNode, v.destination]
                v.pathIndex = 0

    def _to_message(self, v: SimVehicle) -> str:
        """SimVehicle → 21필드 OHT 메시지"""
        return (
            f"2,OHT,{v.vid},{v.state},{v.isFull},0000,1,"
            f"{v.currentNode},{v.distance},{v.nextNode},"
            f"4,4,,{v.destination},00000000,0000,,,90,0,0"
        )


# ============================================================
# 유틸리티
# ============================================================

def extract_oht_messages(text: str):
    """텍스트에서 '2,OHT,'로 시작하는 메시지만 추출 (따옴표/콤마 제거)."""
    messages = []
    for raw_line in text.split("\n"):
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith('"'):
            line = line.lstrip('"')
        if line.endswith('",') or line.endswith('"'):
            line = line.rstrip(',').rstrip('"')
        line = line.strip()
        if "2,OHT," in line:
            idx = line.index("2,OHT,")
            messages.append(line[idx:])
    return messages


def post_oht_messages(server_url: str, messages: list, timeout: float = 5.0) -> dict:
    """서버에 메시지를 POST하고 응답 dict를 반환."""
    url = server_url.rstrip("/") + DEFAULT_ENDPOINT
    payload = json.dumps({"messages": messages}).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return {"status": "error", "http_status": e.code, "message": e.reason}
    except urllib.error.URLError as e:
        return {"status": "error", "message": str(e.reason)}
    except Exception as e:
        return {"status": "error", "message": str(e)}


def bump_distance(msg: str, delta: int) -> str:
    """메시지의 distance(fields[8])를 delta만큼 증가시켜 이동 효과. (레거시 호환)"""
    fields = msg.split(",")
    if len(fields) < 10 or fields[1] != "OHT":
        return msg
    try:
        dist = int(fields[8])
        fields[8] = str(dist + delta)
    except ValueError:
        return msg
    return ",".join(fields)


# ============================================================
# GUI
# ============================================================

class TestSendUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("OHT Raw 메시지 테스트 전송기")
        self.root.geometry("880x700")

        self.auto_running = False
        self.auto_thread: threading.Thread | None = None
        self.simulator: Optional[GraphSimulator] = None

        self._build_widgets()

    # ------------------------------------------------------------
    # UI 구성
    # ------------------------------------------------------------
    def _build_widgets(self):
        pad = {"padx": 8, "pady": 4}

        # 서버 URL
        top = ttk.Frame(self.root)
        top.pack(fill="x", **pad)
        ttk.Label(top, text="Server URL:").pack(side="left")
        self.url_var = tk.StringVar(value=DEFAULT_SERVER_URL)
        ttk.Entry(top, textvariable=self.url_var, width=40).pack(side="left", padx=6)
        ttk.Label(top, text=DEFAULT_ENDPOINT, foreground="#666").pack(side="left")

        # 메시지 입력
        mid_label = ttk.Frame(self.root)
        mid_label.pack(fill="x", **pad)
        ttk.Label(mid_label, text="OHT 메시지 (줄마다 하나씩):").pack(side="left")
        ttk.Button(mid_label, text="샘플 로드", command=self.load_sample).pack(side="right", padx=2)
        ttk.Button(mid_label, text="파일 열기", command=self.load_file).pack(side="right", padx=2)
        ttk.Button(mid_label, text="비우기", command=self.clear_text).pack(side="right", padx=2)

        self.text = scrolledtext.ScrolledText(self.root, height=12, wrap="none", font=("Consolas", 9))
        self.text.pack(fill="both", expand=True, **pad)

        # === 대량 생성 + 자동 이동 (핵심 기능) ===
        bulk = ttk.LabelFrame(self.root, text="대량 차량 생성 + 그래프 이동 시뮬레이션")
        bulk.pack(fill="x", **pad)

        row0 = ttk.Frame(bulk)
        row0.pack(fill="x", padx=4, pady=4)

        ttk.Label(row0, text="차량 수:").pack(side="left")
        self.bulk_count_var = tk.IntVar(value=450)
        ttk.Entry(row0, textvariable=self.bulk_count_var, width=8).pack(side="left", padx=4)

        ttk.Label(row0, text="속도(틱당):").pack(side="left", padx=(12, 0))
        self.speed_var = tk.IntVar(value=200)
        ttk.Entry(row0, textvariable=self.speed_var, width=5).pack(side="left", padx=4)

        ttk.Label(row0, text="전송주기(초):").pack(side="left", padx=(12, 0))
        self.sim_interval_var = tk.DoubleVar(value=0.5)
        ttk.Entry(row0, textvariable=self.sim_interval_var, width=5).pack(side="left", padx=4)

        row1 = ttk.Frame(bulk)
        row1.pack(fill="x", padx=4, pady=(0, 4))

        ttk.Button(row1, text="생성 + 이동 시작", command=self.start_simulation).pack(side="left", padx=4)
        self.sim_stop_btn = ttk.Button(row1, text="이동 중지", command=self.stop_simulation, state="disabled")
        self.sim_stop_btn.pack(side="left", padx=4)
        ttk.Button(row1, text="데드락 시나리오", command=self.create_deadlock_scenario).pack(side="left", padx=4)
        self.sim_status_var = tk.StringVar(value="대기 중")
        ttk.Label(row1, textvariable=self.sim_status_var, foreground="blue").pack(side="left", padx=12)

        # === 레거시 옵션 (파일 기반 단순 전송) ===
        opt = ttk.LabelFrame(self.root, text="수동 전송 (파일/텍스트 기반)")
        opt.pack(fill="x", **pad)

        ttk.Label(opt, text="주기(초):").grid(row=0, column=0, padx=4, pady=4)
        self.interval_var = tk.DoubleVar(value=0.5)
        ttk.Entry(opt, textvariable=self.interval_var, width=6).grid(row=0, column=1, padx=4)

        ttk.Label(opt, text="distance 증가량:").grid(row=0, column=2, padx=4)
        self.delta_var = tk.IntVar(value=5)
        ttk.Entry(opt, textvariable=self.delta_var, width=6).grid(row=0, column=3, padx=4)

        self.auto_btn = ttk.Button(opt, text="자동 전송 시작", command=self.toggle_auto)
        self.auto_btn.grid(row=0, column=4, padx=8)
        ttk.Button(opt, text="한 번 전송", command=self.send_once).grid(row=0, column=5, padx=4)

        # 결과 출력
        ttk.Label(self.root, text="로그:").pack(anchor="w", padx=8)
        self.log = scrolledtext.ScrolledText(self.root, height=8, wrap="word", font=("Consolas", 9),
                                             background="#111", foreground="#0f0")
        self.log.pack(fill="both", expand=False, padx=8, pady=(0, 8))

    # ------------------------------------------------------------
    # 대량 생성 + 그래프 이동 시뮬레이션
    # ------------------------------------------------------------
    def create_deadlock_scenario(self):
        """양방향 엣지에 JAM 차량 배치 → 즉시 데드락 발생"""
        try:
            sim = GraphSimulator(DEFAULT_LAYOUT_CACHE)
        except Exception as e:
            self._log(f"[오류] {e}")
            return

        # 양방향 엣지 찾기 (A→B AND B→A)
        bidir = []
        for (a, b) in sim.edge_dist.keys():
            if (b, a) in sim.edge_dist:
                bidir.append((a, b))

        if not bidir:
            self._log("[오류] 양방향 엣지가 없어서 데드락 시나리오 불가")
            return

        # 최대 5개 양방향 엣지에 데드락 배치
        deadlock_msgs = []
        used = set()
        count = 0
        for a, b in bidir:
            if a in used or b in used:
                continue
            used.add(a)
            used.add(b)
            dist_ab = sim.edge_dist.get((a, b), 100)
            dist_ba = sim.edge_dist.get((b, a), 100)
            vid1 = f"DEAD{count*2:02d}"
            vid2 = f"DEAD{count*2+1:02d}"
            deadlock_msgs.append(
                f"2,OHT,{vid1},7,0,0000,1,{a},{int(dist_ab*0.95)},{b},4,4,,{b},00000000,0000,,,90,0,0"
            )
            deadlock_msgs.append(
                f"2,OHT,{vid2},7,0,0000,1,{b},{int(dist_ba*0.95)},{a},4,4,,{a},00000000,0000,,,90,0,0"
            )
            count += 1
            if count >= 5:
                break

        self._log(f"[데드락] {count}개 교착점, {len(deadlock_msgs)}대 JAM 차량 배치")

        # 정상 차량 200대도 함께 생성 + 이동
        if self.auto_running:
            self.auto_running = False
            time.sleep(0.6)

        self.simulator = GraphSimulator(DEFAULT_LAYOUT_CACHE)
        self.simulator.generate_vehicles(200, speed=200)

        # 데드락 메시지를 매 틱마다 같이 보냄
        self._deadlock_extra_msgs = deadlock_msgs
        self.auto_running = True
        self.sim_stop_btn.config(state="normal")
        self.sim_status_var.set(f"데드락 시나리오 + 200대 이동 중")

        self.auto_thread = threading.Thread(
            target=self._simulation_loop_with_deadlock, daemon=True
        )
        self.auto_thread.start()

    def _simulation_loop_with_deadlock(self):
        """정상 차량 이동 + 데드락 차량 고정 전송"""
        step = 0
        extra = getattr(self, '_deadlock_extra_msgs', [])
        while self.auto_running and self.simulator:
            try:
                msgs = self.simulator.tick()
                all_msgs = msgs + extra
                resp = post_oht_messages(self.url_var.get().strip(), all_msgs)
                if step % 10 == 0:
                    self._log(f"[tick #{step}] {len(all_msgs)}대 (정상 {len(msgs)} + 데드락 {len(extra)})")
                self.sim_status_var.set(f"tick #{step} | {len(all_msgs)}대")
            except Exception as e:
                self._log(f"[오류] {e}")
            step += 1
            try:
                interval = max(0.05, float(self.sim_interval_var.get()))
            except Exception:
                interval = 0.5
            time.sleep(interval)

    def start_simulation(self):
        """차량 생성 → 그래프 위 이동 시뮬레이션 시작"""
        if self.auto_running:
            self._log("[경고] 이미 실행 중입니다. 먼저 중지하세요.")
            return

        count = self.bulk_count_var.get()
        if count <= 0 or count > 2000:
            self._log("차량 수는 1~2000 범위로 입력하세요")
            return

        try:
            self.simulator = GraphSimulator(DEFAULT_LAYOUT_CACHE)
            speed = self.speed_var.get()
            created = self.simulator.generate_vehicles(count, speed=speed)
            self._log(f"[생성] {created}대 차량 배치 완료 (속도={speed}/틱)")
        except FileNotFoundError:
            self._log(f"[오류] layout_cache.json 없음: {DEFAULT_LAYOUT_CACHE}")
            return
        except Exception as e:
            self._log(f"[오류] 생성 실패: {e}")
            return

        # 시뮬레이션 루프 시작
        self.auto_running = True
        self.sim_stop_btn.config(state="normal")
        self.sim_status_var.set(f"{created}대 이동 중...")

        self.auto_thread = threading.Thread(
            target=self._simulation_loop, daemon=True
        )
        self.auto_thread.start()

    def stop_simulation(self):
        """시뮬레이션 중지"""
        self.auto_running = False
        self.sim_stop_btn.config(state="disabled")
        self.sim_status_var.set("중지됨")
        self._log("[중지] 시뮬레이션 중지")

    def _simulation_loop(self):
        """그래프 이동 시뮬레이션 메인 루프"""
        step = 0
        while self.auto_running and self.simulator:
            try:
                # 차량 이동 (1틱)
                messages = self.simulator.tick()

                # 서버 전송
                resp = post_oht_messages(self.url_var.get().strip(), messages)
                updated = resp.get('updated', 0)
                total = resp.get('total_vehicles', 0)

                if step % 10 == 0:  # 10틱마다 로그 (로그 폭주 방지)
                    self._log(f"[tick #{step}] {len(messages)}대 전송, 서버 {total}대 (updated={updated})")

                # UI 상태 갱신
                self.sim_status_var.set(f"tick #{step} | {len(messages)}대 이동 중")

            except Exception as e:
                self._log(f"[오류] tick #{step}: {e}")

            step += 1
            try:
                interval = max(0.05, float(self.sim_interval_var.get()))
            except Exception:
                interval = 0.5
            time.sleep(interval)

    # ------------------------------------------------------------
    # 레거시 기능 (파일 기반 단순 전송)
    # ------------------------------------------------------------
    def load_sample(self):
        self.text.delete("1.0", "end")
        self.text.insert("1.0", "\n".join(SAMPLE_MESSAGES))

    def load_file(self):
        path = filedialog.askopenfilename(
            title="OHT 메시지 파일 선택",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            messagebox.showerror("파일 읽기 실패", str(e))
            return
        self.text.delete("1.0", "end")
        self.text.insert("1.0", content)

    def clear_text(self):
        self.text.delete("1.0", "end")

    def send_once(self):
        messages = extract_oht_messages(self.text.get("1.0", "end"))
        if not messages:
            self._log("메시지 없음 (2,OHT, 로 시작하는 줄이 필요)")
            return
        resp = post_oht_messages(self.url_var.get().strip(), messages)
        self._log(f"[전송] {len(messages)}건 → {resp}")

    def toggle_auto(self):
        if self.auto_running:
            self.auto_running = False
            self.auto_btn.config(text="자동 전송 시작")
            self._log("자동 전송 중지")
        else:
            messages = extract_oht_messages(self.text.get("1.0", "end"))
            if not messages:
                self._log("자동 전송 실패: 메시지 없음")
                return
            self.auto_running = True
            self.auto_btn.config(text="자동 전송 중지")
            self.auto_thread = threading.Thread(
                target=self._auto_loop, args=(messages,), daemon=True
            )
            self.auto_thread.start()
            self._log(f"자동 전송 시작: {len(messages)}건, 주기 {self.interval_var.get()}s")

    def _auto_loop(self, base_messages: list):
        """레거시 자동 전송 루프 (distance만 증가)"""
        step = 0
        while self.auto_running:
            try:
                delta = self.delta_var.get() * step
                current = [bump_distance(m, delta) for m in base_messages]
                resp = post_oht_messages(self.url_var.get().strip(), current)
                if step % 10 == 0:
                    self._log(f"[auto #{step}] delta=+{delta} → {resp}")
            except Exception as e:
                self._log(f"[auto 오류] {e}")
            step += 1
            try:
                interval = max(0.05, float(self.interval_var.get()))
            except Exception:
                interval = 0.5
            time.sleep(interval)

    # ------------------------------------------------------------
    # 로그 출력 (스레드 안전)
    # ------------------------------------------------------------
    def _log(self, text: str):
        def _append():
            ts = time.strftime("%H:%M:%S")
            self.log.insert("end", f"[{ts}] {text}\n")
            self.log.see("end")
        try:
            self.root.after(0, _append)
        except tk.TclError:
            pass


def main():
    root = tk.Tk()
    try:
        style = ttk.Style()
        if "vista" in style.theme_names():
            style.theme_use("vista")
    except Exception:
        pass
    TestSendUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
