#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
deadlock_predictor.py - OHT 데드락 예측 월드모델

현재 차량 상태를 스냅샷하여 10분/20분 후 시뮬레이션,
순환 대기(Circular Wait) 기반 데드락을 예측한다.

사용:
    from deadlock_predictor import predict_deadlocks
    result = predict_deadlocks(engine, vehicle_state_store)
"""

import copy
import heapq
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple, Callable


# ============================================================
# 데이터 구조
# ============================================================

@dataclass
class PredVehicle:
    """예측용 경량 차량 객체"""
    vid: str
    currentNode: int
    nextNode: int
    ratio: float            # 엣지 위 위치 (0.0 ~ 1.0)
    velocity: float         # m/min (0=정지)
    destination: int
    state: int              # 1=RUN, 2=STOP, 7=JAM
    path: List[int] = field(default_factory=list)
    pathIndex: int = 0
    stoppedTicks: int = 0   # 연속 정지 틱 수
    blockedBy: str = ""     # 누구에게 막혔는지 (차량 ID)


@dataclass
class DeadlockGroup:
    """탐지된 데드락 그룹"""
    groupId: str
    dlType: str             # "CIRCULAR_WAIT" | "ZONE_DEADLOCK"
    vehicles: List[str]     # 관련 차량 ID 목록
    edges: List[Tuple[int, int]]  # 관련 엣지 목록
    zoneId: Optional[int]   # 관련 Zone ID (ZONE_DEADLOCK인 경우)
    detectedAtStep: int     # 탐지된 시뮬레이션 스텝
    detectedAtMinute: float # 탐지된 시점 (분)
    severity: str           # "HIGH" | "MEDIUM"


# ============================================================
# Tarjan SCC 알고리즘
# ============================================================

def tarjan_scc(graph: Dict[str, List[str]]) -> List[List[str]]:
    """
    Tarjan의 강결합 요소(SCC) 알고리즘.
    크기 >= 2인 SCC만 반환 (이것이 순환 대기 = 데드락).
    """
    index_counter = [0]
    stack = []
    on_stack = set()
    index_map = {}
    lowlink = {}
    result = []

    def strongconnect(v):
        index_map[v] = index_counter[0]
        lowlink[v] = index_counter[0]
        index_counter[0] += 1
        stack.append(v)
        on_stack.add(v)

        for w in graph.get(v, []):
            if w not in index_map:
                strongconnect(w)
                lowlink[v] = min(lowlink[v], lowlink[w])
            elif w in on_stack:
                lowlink[v] = min(lowlink[v], index_map[w])

        if lowlink[v] == index_map[v]:
            component = []
            while True:
                w = stack.pop()
                on_stack.discard(w)
                component.append(w)
                if w == v:
                    break
            if len(component) >= 2:
                result.append(component)

    for v in graph:
        if v not in index_map:
            strongconnect(v)

    return result


# ============================================================
# WorldModel - 시뮬레이션 엔진
# ============================================================

DEFAULT_VELOCITY = 180.0  # m/min (RUN 차량 기본 속도)
STOPPED_THRESHOLD = 2     # 이 틱 수 이상 정지 시 데드락 후보 (5초 스텝 × 2 = 10초)


class WorldModel:
    """
    결정론적 전방 시뮬레이터.

    기존 SimulationEngine의 그래프/존 데이터를 읽기 전용으로 참조하고,
    차량 상태를 별도 복사본으로 관리하여 시뮬레이션한다.
    """

    def __init__(
        self,
        graph: Dict[int, List[Tuple[int, float]]],
        edge_dist_map: Dict[Tuple[int, int], float],
        hid_zones_snapshot: Dict[int, dict],
        in_lane_to_zone: Dict[Tuple[int, int], int],
        out_lane_to_zone: Dict[Tuple[int, int], int],
    ):
        """
        Args:
            graph: 인접 리스트 {node: [(next_node, distance), ...]}
            edge_dist_map: 엣지 거리 {(from, to): distance_mm}
            hid_zones_snapshot: Zone 스냅샷 {zoneId: {vehicleMax, currentCount}}
            in_lane_to_zone: IN 레인 → Zone 매핑
            out_lane_to_zone: OUT 레인 → Zone 매핑
        """
        self.graph = graph
        self.edge_dist_map = edge_dist_map
        self.in_lane_to_zone = in_lane_to_zone
        self.out_lane_to_zone = out_lane_to_zone

        # Zone 상태 복사 (수정 가능)
        self.zone_capacity: Dict[int, int] = {}    # zoneId -> vehicleMax
        self.zone_count: Dict[int, int] = {}        # zoneId -> 현재 차량 수
        self.zone_vehicles: Dict[int, Set[str]] = defaultdict(set)
        for zid, zinfo in hid_zones_snapshot.items():
            self.zone_capacity[zid] = zinfo['vehicleMax']
            self.zone_count[zid] = zinfo['currentCount']
            for vid in zinfo.get('vehicleIds', []):
                self.zone_vehicles[zid].add(vid)

        # 차량 저장소
        self.vehicles: Dict[str, PredVehicle] = {}

        # 엣지별 차량 인덱스 (성능 최적화)
        self.edge_vehicles: Dict[Tuple[int, int], List[str]] = defaultdict(list)

        # 차량별 Zone 매핑
        self.vehicle_zone: Dict[str, int] = {}

        # 시뮬레이션 카운터
        self.current_step = 0

        # 탐지된 데드락 기록
        self.detected_deadlocks: List[DeadlockGroup] = []
        self._deadlock_counter = 0

    # --------------------------------------------------------
    # 스냅샷: 현재 차량 상태 → PredVehicle 복사
    # --------------------------------------------------------
    def snapshot(
        self,
        vehicle_state_store: Dict[str, dict],
        find_path_fn: Callable[[int, int], List[int]],
    ):
        """
        vehicle_state_store에서 차량 상태를 복사하여 시뮬레이션 초기 상태 생성.

        Args:
            vehicle_state_store: 서버의 차량 상태 딕셔너리
            find_path_fn: engine._find_path 함수 참조
        """
        self.vehicles.clear()
        self.edge_vehicles.clear()
        self.vehicle_zone.clear()

        for vid, vdata in vehicle_state_store.items():
            current_node = vdata.get('currentNode', 0)
            next_node = vdata.get('nextNode', 0)
            destination = vdata.get('destination', 0)
            state = vdata.get('state', 1)
            distance = vdata.get('distance', 0)

            if current_node == 0 or next_node == 0:
                continue

            # ratio 계산: distance / edge_distance
            edge_key = (current_node, next_node)
            edge_dist = self.edge_dist_map.get(edge_key, 0)
            if edge_dist > 0:
                ratio = min(1.0, (distance * 100.0) / edge_dist)
            else:
                ratio = 0.0

            # 속도: RUN이면 기본 속도, 아니면 0
            velocity = DEFAULT_VELOCITY if state == 1 else 0.0

            # 경로: destination이 있으면 Dijkstra로 경로 계산
            path = []
            path_index = 0
            if destination > 0 and destination != current_node:
                try:
                    path = find_path_fn(current_node, destination)
                except Exception:
                    path = []
                if path and len(path) > 1:
                    # 현재 위치에 맞게 pathIndex 조정
                    try:
                        path_index = path.index(current_node)
                    except ValueError:
                        path_index = 0

            pv = PredVehicle(
                vid=vid,
                currentNode=current_node,
                nextNode=next_node,
                ratio=ratio,
                velocity=velocity,
                destination=destination,
                state=state,
                path=path,
                pathIndex=path_index,
            )
            self.vehicles[vid] = pv
            self.edge_vehicles[(current_node, next_node)].append(vid)

            # Zone 매핑 복사
            zone_id = vdata.get('hidZoneId', -1)
            if zone_id >= 0:
                self.vehicle_zone[vid] = zone_id

    # --------------------------------------------------------
    # 시뮬레이션 스텝
    # --------------------------------------------------------
    def step(self, dt: float = 5.0):
        """
        시간 dt(초) 만큼 전방 시뮬레이션.

        Args:
            dt: 시간 스텝 (초). 기본 5초.
        """
        self.current_step += 1

        # 모든 차량 처리
        for vid, v in self.vehicles.items():
            if v.velocity <= 0 or v.state in (2, 7):
                v.stoppedTicks += 1
                # 정지 차량도 블로킹 관계 갱신 (데드락 탐지용)
                self._check_blocking(v)
                continue

            # 1. 앞차 블로킹 체크
            blocked = self._check_blocking(v)
            if blocked:
                v.velocity = 0.0
                v.stoppedTicks += 1
                continue

            # 2. 이동
            v.stoppedTicks = 0
            v.blockedBy = ""
            edge_key = (v.currentNode, v.nextNode)
            edge_dist = self.edge_dist_map.get(edge_key, 1000.0)  # mm

            # velocity(m/min) → mm/s = velocity * 1000 / 60
            move_mm = v.velocity * 1000.0 / 60.0 * dt
            move_ratio = move_mm / edge_dist if edge_dist > 0 else 0

            v.ratio += move_ratio

            # 3. 엣지 전환 (다음 노드 도착)
            if v.ratio >= 1.0:
                self._advance_to_next_edge(v)

    def _check_blocking(self, v: PredVehicle) -> bool:
        """앞차 블로킹 체크. 블로킹이면 True 반환."""
        edge_key = (v.currentNode, v.nextNode)
        vids_on_edge = self.edge_vehicles.get(edge_key, [])

        for other_vid in vids_on_edge:
            if other_vid == v.vid:
                continue
            other = self.vehicles.get(other_vid)
            if other is None:
                continue

            # 같은 엣지에서 앞에 있고 정지 중인 차량
            if other.ratio > v.ratio and other.velocity <= 0:
                gap = other.ratio - v.ratio
                if gap < 0.3:  # 가까이 있으면 블로킹
                    v.blockedBy = other_vid
                    return True

        # 다음 엣지 시작점 블로킹 체크 (현재 엣지 70% 이상 진행 시)
        if v.ratio > 0.7 and v.path and v.pathIndex + 2 < len(v.path):
            next_from = v.nextNode
            next_to = v.path[v.pathIndex + 2]
            next_edge_key = (next_from, next_to)
            vids_on_next = self.edge_vehicles.get(next_edge_key, [])

            for other_vid in vids_on_next:
                other = self.vehicles.get(other_vid)
                if other and other.ratio < 0.3 and other.velocity <= 0:
                    v.blockedBy = other_vid
                    return True

        return False

    def _advance_to_next_edge(self, v: PredVehicle):
        """엣지 전환: 다음 경로 노드로 이동"""
        old_edge = (v.currentNode, v.nextNode)

        # 엣지 인덱스에서 제거
        if v.vid in self.edge_vehicles.get(old_edge, []):
            self.edge_vehicles[old_edge].remove(v.vid)

        # 경로 진행
        if v.path and v.pathIndex + 1 < len(v.path):
            v.pathIndex += 1
            v.currentNode = v.path[v.pathIndex]

            if v.pathIndex + 1 < len(v.path):
                v.nextNode = v.path[v.pathIndex + 1]
            else:
                # 목적지 도착
                v.nextNode = v.currentNode
                v.velocity = 0.0
                v.state = 2  # STOP
                return
        else:
            # 경로 없음 - 현재 엣지의 nextNode에서 인접 노드로
            v.currentNode = v.nextNode
            neighbors = self.graph.get(v.currentNode, [])
            if neighbors:
                v.nextNode = neighbors[0][0]  # 첫 번째 인접 노드
            else:
                v.velocity = 0.0
                v.state = 2
                return

        # Zone 용량 체크
        new_edge = (v.currentNode, v.nextNode)
        zone_id = self.in_lane_to_zone.get(new_edge)
        if zone_id is not None and zone_id in self.zone_capacity:
            current_count = self.zone_count.get(zone_id, 0)
            max_count = self.zone_capacity[zone_id]
            if current_count >= max_count:
                # Zone FULL → JAM
                v.velocity = 0.0
                v.state = 7  # JAM
                v.blockedBy = f"ZONE_{zone_id}_FULL"
                # 원래 위치로 되돌림 (진입 불가)
                v.currentNode = old_edge[0]
                v.nextNode = old_edge[1]
                v.ratio = 0.99
                self.edge_vehicles[old_edge].append(v.vid)
                return
            else:
                # Zone 진입 성공
                self.zone_count[zone_id] = current_count + 1
                self.zone_vehicles[zone_id].add(v.vid)

        # 이전 Zone에서 나감
        old_zone = self.vehicle_zone.get(v.vid)
        out_zone = self.out_lane_to_zone.get(old_edge)
        if old_zone is not None and out_zone is not None:
            self.zone_count[old_zone] = max(0, self.zone_count.get(old_zone, 0) - 1)
            self.zone_vehicles[old_zone].discard(v.vid)

        # 새 엣지에 등록
        v.ratio = 0.0
        self.edge_vehicles[new_edge].append(v.vid)

    # --------------------------------------------------------
    # 데드락 탐지
    # --------------------------------------------------------
    def build_wait_for_graph(self) -> Dict[str, List[str]]:
        """
        정지 차량간 Wait-For 그래프 구성.
        V가 W에 의해 블로킹 → V → W 엣지.

        데드락 = 엣지 위에서 차량끼리 직접 막는 순환 대기만 해당.
        Zone FULL은 혼잡이지 데드락이 아니므로 제외.
        """
        wfg: Dict[str, List[str]] = defaultdict(list)

        # stoppedTicks 임계값 이상인 차량만
        stuck_vehicles = {
            vid: v for vid, v in self.vehicles.items()
            if v.stoppedTicks >= STOPPED_THRESHOLD and v.velocity <= 0
        }

        for vid, v in stuck_vehicles.items():
            # Zone FULL로 막힌 건 혼잡이지 데드락 아님 → 스킵
            if v.blockedBy and v.blockedBy.startswith("ZONE_"):
                continue

            # Case 1: 직접 블로킹 관계 (엣지 위 차량간)
            if v.blockedBy and v.blockedBy in stuck_vehicles:
                blocker = stuck_vehicles[v.blockedBy]
                # blocker도 Zone이 아닌 엣지 블로킹이어야 함
                if not (blocker.blockedBy and blocker.blockedBy.startswith("ZONE_")):
                    wfg[vid].append(v.blockedBy)
                continue

            # Case 2: 같은 엣지 앞차 (직접 앞에서 막는 차량 1대만)
            edge_key = (v.currentNode, v.nextNode)
            closest_vid = None
            closest_gap = float('inf')
            for other_vid in self.edge_vehicles.get(edge_key, []):
                if other_vid == vid:
                    continue
                other = stuck_vehicles.get(other_vid)
                if other and other.ratio > v.ratio:
                    gap = other.ratio - v.ratio
                    if gap < closest_gap:
                        closest_gap = gap
                        closest_vid = other_vid
            if closest_vid:
                wfg[vid].append(closest_vid)

            # Case 3: 다음 엣지 시작점 블로킹
            elif v.path and v.pathIndex + 2 < len(v.path):
                next_from = v.nextNode
                next_to = v.path[v.pathIndex + 2]
                next_edge = (next_from, next_to)
                for other_vid in self.edge_vehicles.get(next_edge, []):
                    other = stuck_vehicles.get(other_vid)
                    if other and other.ratio < 0.3:
                        wfg[vid].append(other_vid)
                        break  # 1대만

            # Case 4: 엣지 끝(ratio>0.7)인데 nextNode에서 나를 향해 오는 차량
            if not wfg.get(vid) and v.ratio > 0.7:
                # nextNode를 기준으로 역방향 엣지 (nextNode → currentNode)에 차량 확인
                reverse_edge = (v.nextNode, v.currentNode)
                for other_vid in self.edge_vehicles.get(reverse_edge, []):
                    other = stuck_vehicles.get(other_vid)
                    if other and other.ratio > 0.7:
                        # 양쪽 다 엣지 끝에서 서로를 향해 막힘 = 교착
                        wfg[vid].append(other_vid)
                        break

        return dict(wfg)

    def detect_deadlocks(self) -> List[DeadlockGroup]:
        """
        Wait-For 그래프에서 Tarjan SCC로 데드락(순환 대기) 탐지.
        크기 >= 2인 SCC = 데드락 그룹.
        """
        wfg = self.build_wait_for_graph()

        if not wfg:
            return []

        sccs = tarjan_scc(wfg)
        new_deadlocks = []

        for scc in sccs:
            # 50대 넘는 SCC는 혼잡이지 데드락이 아님 → 스킵
            if len(scc) > 50:
                continue

            self._deadlock_counter += 1

            # 관련 엣지 + HID Zone 수집
            edges = set()
            zone_ids = set()
            for vid in scc:
                v = self.vehicles.get(vid)
                if v:
                    edge = (v.currentNode, v.nextNode)
                    edges.add(edge)
                    # 방법1: 레인 매핑으로 Zone 찾기
                    for e in [edge, (edge[1], edge[0])]:
                        zid = self.in_lane_to_zone.get(e)
                        if zid is not None:
                            zone_ids.add(zid)
                        zid = self.out_lane_to_zone.get(e)
                        if zid is not None:
                            zone_ids.add(zid)
                    # 방법2: 차량이 속한 Zone
                    zid = self.vehicle_zone.get(vid)
                    if zid is not None:
                        zone_ids.add(zid)

            # 방법3: Zone 못 찾으면 노드가 포함된 Zone 검색
            if not zone_ids:
                dl_nodes = set()
                for e in edges:
                    dl_nodes.add(e[0])
                    dl_nodes.add(e[1])
                for zid, cap in self.zone_capacity.items():
                    zone_nodes = set()
                    for lane_edge in self.in_lane_to_zone:
                        if self.in_lane_to_zone[lane_edge] == zid:
                            zone_nodes.add(lane_edge[0])
                            zone_nodes.add(lane_edge[1])
                    for lane_edge in self.out_lane_to_zone:
                        if self.out_lane_to_zone[lane_edge] == zid:
                            zone_nodes.add(lane_edge[0])
                            zone_nodes.add(lane_edge[1])
                    if dl_nodes & zone_nodes:
                        zone_ids.add(zid)

            dl_type = "CIRCULAR_WAIT"
            severity = "HIGH" if len(scc) >= 5 else "MEDIUM" if len(scc) >= 3 else "LOW"
            minute = (self.current_step * 5.0) / 60.0  # 5초 스텝 기준

            dl = DeadlockGroup(
                groupId=f"DL-{self._deadlock_counter:03d}",
                dlType=dl_type,
                vehicles=list(scc),
                edges=list(edges),
                zoneId=list(zone_ids) if zone_ids else None,
                detectedAtStep=self.current_step,
                detectedAtMinute=round(minute, 1),
                severity=severity,
            )
            new_deadlocks.append(dl)

        self.detected_deadlocks.extend(new_deadlocks)
        return new_deadlocks


# ============================================================
# 진입점 함수
# ============================================================

def predict_deadlocks(
    engine,
    vehicle_state_store: Dict[str, dict],
    horizons: List[int] = None,
) -> dict:
    """
    데드락 예측 메인 함수.

    Args:
        engine: SimulationEngine 인스턴스 (읽기 전용)
        vehicle_state_store: 현재 차량 상태 딕셔너리
        horizons: 예측 시간(초) 리스트. 기본 [600, 1200] = 10분, 20분

    Returns:
        {
            "timestamp": "...",
            "vehicleCount": N,
            "horizons": {
                "T+10min": { "deadlockCount": N, "deadlocks": [...] },
                "T+20min": { ... }
            },
            "summary": { ... }
        }
    """
    if horizons is None:
        horizons = [600, 1200]

    if not vehicle_state_store:
        return {
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "vehicleCount": 0,
            "horizons": {},
            "summary": {"totalDeadlocks": 0, "affectedVehicles": 0},
        }

    start_time = time.time()

    # Zone 스냅샷 생성
    hid_zones_snapshot = {}
    for zid, zone in engine.hid_zones.items():
        hid_zones_snapshot[zid] = {
            'vehicleMax': zone.vehicleMax,
            'currentCount': zone.vehicleCount,
            'vehicleIds': list(zone.currentVehicles),
        }

    # WorldModel 생성 및 스냅샷
    wm = WorldModel(
        graph=dict(engine.graph),
        edge_dist_map=engine.edge_dist_map,
        hid_zones_snapshot=hid_zones_snapshot,
        in_lane_to_zone=engine.in_lane_to_zone,
        out_lane_to_zone=engine.out_lane_to_zone,
    )
    wm.snapshot(vehicle_state_store, engine._find_path)

    # 시뮬레이션 실행
    dt = 5.0  # 5초 스텝
    results = {}
    all_affected = set()
    total_deadlocks = 0

    prev_horizon = 0
    for horizon_sec in sorted(horizons):
        steps_needed = int((horizon_sec - prev_horizon) / dt)
        for _ in range(steps_needed):
            wm.step(dt)

        # 데드락 탐지
        deadlocks = wm.detect_deadlocks()
        dl_list = []
        for dl in deadlocks:
            # Zone ID → 이름 매핑
            zone_info = []
            if dl.zoneId:
                for zid in (dl.zoneId if isinstance(dl.zoneId, list) else [dl.zoneId]):
                    zone = engine.hid_zones.get(zid)
                    zone_info.append({
                        'zoneId': zid,
                        'fullName': zone.fullName if zone else f'Zone-{zid}',
                        'bayZone': zone.bayZone if zone else '',
                    })

            dl_list.append({
                'id': dl.groupId,
                'type': dl.dlType,
                'vehicleCount': len(dl.vehicles),
                'vehicles': dl.vehicles,
                'edges': [{'from': e[0], 'to': e[1]} for e in dl.edges],
                'zones': zone_info,
                'detectedAtMinute': dl.detectedAtMinute,
                'severity': dl.severity,
            })
            all_affected.update(dl.vehicles)
            total_deadlocks += 1

        # Zone 혼잡 예측: 시뮬레이션 후 FULL/PRECAUTION Zone 찾기
        risk_zones = []
        for zid, cap in wm.zone_capacity.items():
            count = wm.zone_count.get(zid, 0)
            if count <= 0:
                continue
            occ = (count / cap * 100) if cap > 0 else 0
            zone = engine.hid_zones.get(zid)
            if occ >= 70:  # 70% 이상이면 위험
                status = 'FULL' if count >= cap else 'PRECAUTION'
                risk_zones.append({
                    'zoneId': zid,
                    'fullName': zone.fullName if zone else f'Zone-{zid}',
                    'bayZone': zone.bayZone if zone else '',
                    'vehicleCount': count,
                    'vehicleMax': cap,
                    'occupancy': round(occ, 1),
                    'status': status,
                })

        label = f"T+{horizon_sec // 60}min"
        results[label] = {
            'deadlockCount': len(dl_list),
            'deadlocks': dl_list,
            'riskZones': sorted(risk_zones, key=lambda z: z['occupancy'], reverse=True),
        }
        prev_horizon = horizon_sec

    elapsed_ms = round((time.time() - start_time) * 1000, 1)

    # 전체 위험 Zone 수집
    all_risk_zones = {}
    for h_data in results.values():
        for rz in h_data.get('riskZones', []):
            zid = rz['zoneId']
            if zid not in all_risk_zones or rz['occupancy'] > all_risk_zones[zid]['occupancy']:
                all_risk_zones[zid] = rz

    return {
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "vehicleCount": len(vehicle_state_store),
        "elapsedMs": elapsed_ms,
        "horizons": results,
        "summary": {
            "totalDeadlocks": total_deadlocks,
            "affectedVehicles": len(all_affected),
            "affectedVehicleIds": list(all_affected),
            "riskZones": list(all_risk_zones.values()),
            "riskEdges": list({
                (e['from'], e['to'])
                for h in results.values()
                for dl in h.get('deadlocks', [])
                for e in dl.get('edges', [])
            }),
        },
    }
