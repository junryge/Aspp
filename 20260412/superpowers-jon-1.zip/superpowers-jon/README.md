# Superpowers - Jon Edition (8 Core Skills)

obra/superpowers 14개 스킬 중 존님 환경(ASAS, AMHS, Qwen3-235B, 한국어, 단일 서빙)에 맞는 8개를 선별해서 재구성한 스킬 팩.

## 포함된 스킬 (8개)

| # | 스킬 | 언제 발동 |
|---|------|----------|
| 1 | **using-superpowers** | 메타 스킬. 모든 응답 전에 "어떤 스킬 발동?" 체크 강제 |
| 2 | **brainstorming** | 코드 쓰기 전. "만들자", "설계" 요청 시 Socratic 질문 |
| 3 | **writing-plans** | brainstorming 결과물을 2-5분 단위 태스크로 쪼개기 |
| 4 | **test-driven-development** | 구현 중. RED→GREEN→REFACTOR 아이언 룰 |
| 5 | **systematic-debugging** | 버그/에러 시. 4단계 루트코즈 (패치 금지) |
| 6 | **verification-before-completion** | "완료" 선언 전. 실제 검증 증거 필수 |
| 7 | **writing-skills** | 새 스킬 작성 시. TDD for documentation |
| 8 | **requesting-code-review** | PR/리뷰 전. self-checklist + 요청 포맷 + 수용 패턴 |

## obra/superpowers 원본에서 제외한 6개

환경 불일치로 뺀 것들:
- `executing-plans` → writing-plans에 통합
- `receiving-code-review` → requesting-code-review에 통합
- `using-git-worktrees`, `finishing-a-development-branch` → SK Hynix 내부 Git 정책과 불일치
- `dispatching-parallel-agents`, `subagent-driven-development` → 병렬 사용 불가 환경

## 설치
각 `skills/<skill-name>/SKILL.md`를 Claude Code plugin 또는 ASAS 스킬 디렉토리에 배치.

## 출처
- 원본: https://github.com/obra/superpowers (Jesse Vincent, Prime Radiant)
- 라이선스: MIT
