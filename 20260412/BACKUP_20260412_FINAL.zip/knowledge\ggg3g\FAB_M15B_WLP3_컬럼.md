---
title: "QUWA FAB 컬럼 사전"
date: 2026-02-11
updated: 2026-02-11
category: column_definition
fab: [M15B]
tags: [ALERT, CPU, MCS, OHT, QUE, STK, STRATE, m15b, wlp3, 디스크, 메모리, 반송, 장비, 저장률, 컬럼]
description: "M15B 컬럼 사전 (100건)"
---
# QUWA FAB 컬럼 사전
> **구조**: `{FAB}.{Category}.{SubCategory}.{Metric}`
> **영문 Description → 한글 번역 완료**

---

### M15B_WLP3 (100건)

#### M15B_WLP3.STRATE — 저장 현황 (72건)

| # | 컬럼명 (Index) | 한글 설명 |
|---|----------------|-----------|
| 1 | `M15B_WLP3.STRATE.NONCU.N2STORAGECAPACITY` | NONCU N2 전체저장용량 (smartSTAR) |
| 2 | `M15B_WLP3.STRATE.NONCU.N2STORAGECOUNT` | NONCU N2 저장수 (smartSTAR) |
| 3 | `M15B_WLP3.STRATE.NONCU.N2STORAGERATIO` | NONCU N2 저장율 (smartSTAR) |
| 4 | `M15B_WLP3.STRATE.NONCU.N2STORAGESERVICECAPA` | NONCU N2 저장가능용량 (smartSTAR) |
| 5 | `M15B_WLP3.STRATE.NONCU.NONN2STORAGECAPACITY` | NONCU NONN2 전체저장용량 (smartSTAR) |
| 6 | `M15B_WLP3.STRATE.NONCU.NONN2STORAGECOUNT` | NONCU NONN2 저장수 (smartSTAR) |
| 7 | `M15B_WLP3.STRATE.NONCU.NONN2STORAGERATIO` | NONCU NONN2 저장율 (smartSTAR) |
| 8 | `M15B_WLP3.STRATE.NONCU.NONN2STORAGESERVICECAPA` | NONCU NONN2 저장가능용량 (smartSTAR) |
| 9 | `M15B_WLP3.STRATE.NONCU.STORAGECAPACITY` | NONCU 전체저장용량 (smartSTAR) |
| 10 | `M15B_WLP3.STRATE.NONCU.STORAGECOUNT` | NONCU 저장수 (smartSTAR) |
| 11 | `M15B_WLP3.STRATE.NONCU.STORAGERATIO` | NONCU 저장율 (smartSTAR) NONCU Storage로 이동중인 Queue 개수 포함, Down인 장비 제외 |
| 12 | `M15B_WLP3.STRATE.NONCU.STORAGESERVICECAPA` | NONCU 저장가능용량 (smartSTAR) |
| 13 | `M15B_WLP3.STRATE.NONN2.STORAGECAPACITY` | NONN2 전체저장용량 (smartSTAR) |
| 14 | `M15B_WLP3.STRATE.NONN2.STORAGECOUNT` | NONN2 저장수 (smartSTAR) |
| 15 | `M15B_WLP3.STRATE.NONN2.STORAGERATIO` | NONN2 저장율 (smartSTAR) |
| 16 | `M15B_WLP3.STRATE.NONN2.STORAGESERVICECAPA` | NONN2 저장가능용량 (smartSTAR) |
| 17 | `M15B_WLP3.STRATE.ALL.FABSTORAGECAPACITY` | FAB 전체저장용량 (smartSTAR) ReservedLocationCount 포함, Down된 장비 제외 |
| 18 | `M15B_WLP3.STRATE.ALL.FABSTORAGECOUNT` | FAB 저장수 (smartSTAR) ReservedLocationCount 포함, Down된 장비 제외 |
| 19 | `M15B_WLP3.STRATE.ALL.FABSTORAGERATIO` | FAB 저장율 (smartSTAR) ReservedLocationCount 포함, Down된 장비 제외 |
| 20 | `M15B_WLP3.STRATE.ALL.FABSTORAGESERVICECAPA` | FAB 저장가능용량 (smartSTAR) ReservedLocationCount 포함, Down된 장비 제외 |
| 21 | `M15B_WLP3.STRATE.CU.N2STORAGECAPACITY` | CU N2 전체저장용량 (smartSTAR) |
| 22 | `M15B_WLP3.STRATE.CU.N2STORAGECOUNT` | CU N2 저장수 (smartSTAR) |
| 23 | `M15B_WLP3.STRATE.CU.N2STORAGERATIO` | CU N2 저장율 (smartSTAR) |
| 24 | `M15B_WLP3.STRATE.CU.N2STORAGESERVICECAPA` | CU N2 저장가능용량 (smartSTAR) |
| 25 | `M15B_WLP3.STRATE.CU.NONN2STORAGECAPACITY` | CU NONN2 전체저장용량 (smartSTAR) |
| 26 | `M15B_WLP3.STRATE.CU.NONN2STORAGECOUNT` | CU NONN2 저장수 (smartSTAR) |
| 27 | `M15B_WLP3.STRATE.CU.NONN2STORAGERATIO` | CU NONN2 저장율 (smartSTAR) |
| 28 | `M15B_WLP3.STRATE.CU.NONN2STORAGESERVICECAPA` | CU NONN2 저장가능용량 (smartSTAR) |
| 29 | `M15B_WLP3.STRATE.CU.STORAGECAPACITY` | CU 전체저장용량 (smartSTAR) |
| 30 | `M15B_WLP3.STRATE.CU.STORAGECOUNT` | CU 저장수 (smartSTAR) |
| 31 | `M15B_WLP3.STRATE.CU.STORAGERATIO` | CU 저장율 (smartSTAR) |
| 32 | `M15B_WLP3.STRATE.CU.STORAGESERVICECAPA` | CU 저장가능용량 (smartSTAR) |
| 33 | `M15B_WLP3.STRATE.N2.STORAGECAPACITY` | N2 전체저장용량 (smartSTAR) |
| 34 | `M15B_WLP3.STRATE.N2.STORAGECOUNT` | N2 저장수 (smartSTAR) |
| 35 | `M15B_WLP3.STRATE.N2.STORAGERATIO` | N2 저장율 (smartSTAR) N2 STK로 이동중인 Queue 개수 포함, Down인 장비 제외 |
| 36 | `M15B_WLP3.STRATE.N2.STORAGESERVICECAPA` | N2 저장가능용량 (smartSTAR) |
| 37 | `M15B_WLP3.STRATE.POD.FABSTORAGECAPACITY` | POD 전체저장용량 (smartSTAR) |
| 38 | `M15B_WLP3.STRATE.POD.FABSTORAGECOUNT` | POD 저장수 (smartSTAR) |
| 39 | `M15B_WLP3.STRATE.POD.FABSTORAGERATIO` | POD 저장율 (smartSTAR) |
| 40 | `M15B_WLP3.STRATE.POD.FABSTORAGESERVICECAPA` | POD 저장가능용량 (smartSTAR) |
| 41 | `M15B_WLP3.STRATE.STB.N2STORAGECAPACITY` | N2STB 전체저장용량 (smartSTAR) |
| 42 | `M15B_WLP3.STRATE.STB.N2STORAGECOUNT` | N2STB 저장수 (smartSTAR) |
| 43 | `M15B_WLP3.STRATE.STB.N2STORAGERATIO` | N2STB 저장율 (smartSTAR) N2STB 로 이동중인 Queue 개수 포함, Down인 장비 제외 |
| 44 | `M15B_WLP3.STRATE.STB.N2STORAGESERVICECAPA` | N2STB 저장가능용량 (smartSTAR) |
| 45 | `M15B_WLP3.STRATE.STB.NONN2STORAGECAPACITY` | NONN2STB 전체저장용량 (smartSTAR) |
| 46 | `M15B_WLP3.STRATE.STB.NONN2STORAGECOUNT` | NONN2STB 저장수 (smartSTAR) |
| 47 | `M15B_WLP3.STRATE.STB.NONN2STORAGERATIO` | NONN2STB 저장율(%) |
| 48 | `M15B_WLP3.STRATE.STB.NONN2STORAGESERVICECAPA` | NONN2STB 저장가능용량 (smartSTAR) |
| 49 | `M15B_WLP3.STRATE.STB.STORAGECAPACITY` | STB 전체저장용량 (smartSTAR) |
| 50 | `M15B_WLP3.STRATE.STB.STORAGECOUNT` | STB 저장수 (smartSTAR) |
| 51 | `M15B_WLP3.STRATE.STB.STORAGERATIO` | STB 저장율 (smartSTAR) |
| 52 | `M15B_WLP3.STRATE.STB.STORAGESERVICECAPA` | STB 저장가능용량 (smartSTAR) |
| 53 | `M15B_WLP3.STRATE.STK.N2STORAGECAPACITY` | N2STK 전체저장용량 (smartSTAR) |
| 54 | `M15B_WLP3.STRATE.STK.N2STORAGECOUNT` | N2STK 저장수 (smartSTAR) |
| 55 | `M15B_WLP3.STRATE.STK.N2STORAGERATIO` | N2STK 저장율 (smartSTAR) N2Stocker로 이동중인 Queue 개수 포함, Down인 장비 제외 |
| 56 | `M15B_WLP3.STRATE.STK.N2STORAGESERVICECAPA` | N2STK 저장가능용량 (smartSTAR) |
| 57 | `M15B_WLP3.STRATE.STK.NONN2STORAGECAPACITY` | NONN2STK 전체저장용량 (smartSTAR) |
| 58 | `M15B_WLP3.STRATE.STK.NONN2STORAGECOUNT` | NONN2STK 저장수 (smartSTAR) |
| 59 | `M15B_WLP3.STRATE.STK.NONN2STORAGERATIO` | NONN2STK 저장율 (smartSTAR)NON N2Stocker로 이동중인 Queue 개수 포함, Down인 장비 제외 |
| 60 | `M15B_WLP3.STRATE.STK.NONN2STORAGESERVICECAPA` | NONN2STK 저장가능용량 (smartSTAR) |
| 61 | `M15B_WLP3.STRATE.FOUP.NONN2STORAGECAPACITY` | NONN2 전체저장용량 (smartSTAR) |
| 62 | `M15B_WLP3.STRATE.FOUP.NONN2STORAGECOUNT` | NONN2 저장수 (smartSTAR) |
| 63 | `M15B_WLP3.STRATE.FOUP.NONN2STORAGERATIO` | NONN2 저장율 (smartSTAR) |
| 64 | `M15B_WLP3.STRATE.FOUP.NONN2STORAGESERVICECAPA` | NONN2 저장가능용량 (smartSTAR) |
| 65 | `M15B_WLP3.STRATE.RINGCST.STORAGECAPACITY` | RINGCST 전체저장용량 (smartSTAR) |
| 66 | `M15B_WLP3.STRATE.RINGCST.STORAGECOUNT` | RINGCST 저장수 (smartSTAR) |
| 67 | `M15B_WLP3.STRATE.RINGCST.STORAGERATIO` | RINGCST 저장율 (smartSTAR) |
| 68 | `M15B_WLP3.STRATE.RINGCST.STORAGESERVICECAPA` | RINGCST 저장가능용량 (smartSTAR) |
| 69 | `M15B_WLP3.STRATE.STB.NONN2FOUPSTORAGECOUNT_300` | NONN2STB (WLP3_300mm_STB) 저장수 (smartSTAR) |
| 70 | `M15B_WLP3.STRATE.STB.NONN2FOUPSTORAGECAPACITY_300` | NONN2STB (WLP3_300mm_STB) 전체용량 |
| 71 | `M15B_WLP3.STRATE.STB.NONN2FOUPSTORAGERATIO_300` | NONN2STB (WLP3_300mm_STB) 저장율(%) |
| 72 | `M15B_WLP3.STRATE.STB.NONN2FOUPSTORAGESERVICECAPA_300` | NONN2STB (WLP3_300mm_STB) 저장가능용량 (smartSTAR) |

#### M15B_WLP3.QUE — 반송 큐 (21건)

| # | 컬럼명 (Index) | 한글 설명 |
|---|----------------|-----------|
| 1 | `M15B_WLP3.QUE.ABN.N2STOCKERDELAY` | 60분이상 N2Purge Stocker Port 내 FOUP 지연 발생 통지(MCS) |
| 2 | `M15B_WLP3.QUE.ABN.QUETIMEDELAY` | 20분 이상 지연된 FOUP 목록 알림(MCS) |
| 3 | `M15B_WLP3.QUE.ALL.CURRENTQCNT` |  |
| 4 | `M15B_WLP3.QUE.ALL.CURRENTQCOMPLETED` | 최근 10분간 반송명령 완료수(HySTAR) |
| 5 | `M15B_WLP3.QUE.ALL.CURRENTQCREATED` | 최근10분간 Q생성 수(HySTAR) |
| 6 | `M15B_WLP3.QUE.ALL.CURRENTRETICLEQCNT` | 현재 POD 반송 Q 수(MCS) 출발지 장비와 목적지 장비가 다른 Queue 대상 |
| 7 | `M15B_WLP3.QUE.LOAD.AVGFOUPLOADTIME` | 최근 10분간 FOUP 평균 Load반송시간(smartSTAR) |
| 8 | `M15B_WLP3.QUE.LOAD.AVGLOADTIME` | 최근 10분간 평균 Load반송시간(HySTAR) |
| 9 | `M15B_WLP3.QUE.LOAD.AVGLOADTIME1MIN` | 최근 1분간 평균 Load반송시간(smartSTAR) |
| 10 | `M15B_WLP3.QUE.LOAD.AVGRETICLELOADTIME` | 최근 10분간 Reticle 평균 Load반송시간(smartSTAR) |
| 11 | `M15B_WLP3.QUE.LOAD.CURRENTLOADQCNT` | 반송 큐 개수: 목적지가 생산장비인 건(MCS) |
| 12 | `M15B_WLP3.QUE.LOAD.CURRENTRETICLELOADQCNT` | 목적지가 생산장비인 POD 반송 Q수(MCS) |
| 13 | `M15B_WLP3.QUE.OHT.CURRENTOHTQCNT` | 현재 OHT반송 Q 수(MCS) |
| 14 | `M15B_WLP3.QUE.OHT.CURRENTRETICLEOHTQCNT` | 현재 Reticle OHT반송 Q 수(MCS) |
| 15 | `M15B_WLP3.QUE.LOAD.AVGSLOWLOADTIME` | 최근 10분간 SLOW 평균 Load반송시간(smartSTAR) |
| 16 | `M15B_WLP3.QUE.OHT.OHTUTIL_400` | 400 OHT사용율(%)(MCS) |
| 17 | `M15B_WLP3.QUE.OHT.CURRENTOHTQCNT_400` | 현재 OHT 400반송 Q 수(MCS) |
| 18 | `M15B_WLP3.QUE.LOAD.AVGRINGCSTLOADTIME` | 최근 10분간 FOUP 평균 Load반송시간(smartSTAR) |
| 19 | `M15B_WLP3.QUE.OHT.CURRENTOHTQCNT_300` | 현재 OHT 300반송 Q 수(MCS) |
| 20 | `M15B_WLP3.QUE.OHT.OHTUTIL_SLOW` | SLOW OHT사용율(%)(MCS) |
| 21 | `M15B_WLP3.QUE.OHT.CURRENTOHTQCNT_SLOW` | OHT SLOW반송 Q 수(MCS) |

#### M15B_WLP3.INPOS — 포트 상태 (7건)

| # | 컬럼명 (Index) | 한글 설명 |
|---|----------------|-----------|
| 1 | `M15B_WLP3.INPOS.ALERT.112` | 퍼지 미시작 |
| 2 | `M15B_WLP3.INPOS.ALERT.90003` | TraceMessage 통신 단절 |
| 3 | `M15B_WLP3.INPOS.ALERT.101` | I/O 읽기/쓰기 에러 |
| 4 | `M15B_WLP3.INPOS.ALERT.103` | MC OFF 에러 |
| 5 | `M15B_WLP3.INPOS.ALERT.104` | 비상정지(E-STOP) |
| 6 | `M15B_WLP3.INPOS.ALERT.113` | 메인 DC 전원 에러 |
| 7 | `M15B_WLP3.INPOS.ALERT.114` | 메인 PW DC 전원 에러 |

---

## 부록: 주요 영문 용어 번역 참고

| 영문 | 한글 | 비고 |
|------|------|------|
| Storage Ratio | 저장률 | % |
| Storage Count | 저장 수량 | FOUP 수 |
| Storage Max Capa | 최대 용량 | 전체 수용 |
| Storage Service Capa | 가용 용량 | 실사용 가능 |
| Exclude down machine | 다운장비 제외 |  |
| Transport Q Cnt | 반송 큐 개수 |  |
| Trans Time | 반송 시간 |  |
| OHT Usage | OHT 가동률 |  |
| CPU/Memory/Disk Usage | CPU/메모리/디스크 사용률 | FTP 수집 |
| Disconnect Communication | 통신 단절 |  |
| MCP AUTO/PAUSED | MCP 자동/일시정지 |  |
| E-STOP | 비상정지 |  |
| N2 Purge | N2 퍼지 | 질소 퍼지 영역 |
| STK | 스토커 | Stocker |
| STB | STB | Stocker Buffer |
| RETICLE | 레티클 | 포토마스크 |
| Cu Area | Cu 영역 | 구리 배선 공정 |

---
> 생성일: 2026-02-09 | 총 6,111건 전수 한글화 완료 (R3 144건 포함)
