#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
test_send_ui.py - OHT raw 메시지 전송 테스트 UI

sim_server_3d_D5_D7.py 의 /api/oht-raw 엔드포인트로 OHT 메시지를 보내서
화면에 차량이 표시되는지 확인하기 위한 간단한 Tkinter GUI.

사용법:
    python test_send_ui.py

기능:
    - 서버 URL 설정
    - 메시지 붙여넣기 후 [전송] 버튼
    - 샘플 메시지 로드
    - TXT 파일에서 메시지 불러오기
    - 자동 반복 전송 (거리값을 조금씩 늘려 차량 이동 효과)
"""

import json
import os
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
import urllib.error
import urllib.request


DEFAULT_SERVER_URL = "http://localhost:10003"
DEFAULT_ENDPOINT = "/api/oht-raw"

# 가이드 문서 기준 샘플 메시지 (21필드)
SAMPLE_MESSAGES = [
    "2,OHT,V00795,1,1,0000,1,12340,14,12341,4,4,4PDMV608,36073,00000000,0000,4ABL3301A_OUT04,4ANZ19-701,90,0,0",
    "2,OHT,V00564,1,0,0000,1,2115,9,2116,4,4,,0,00000000,0000,,,0,0,0",
    "2,OHT,V00123,2,1,0000,1,5010,0,5011,4,4,4PDMV700,30000,00000000,0000,4ABL1101A_OUT02,4ABL2201B_IN01,50,0,0",
]


def extract_oht_messages(text: str):
    """텍스트에서 '2,OHT,'로 시작하는 메시지만 추출 (따옴표/콤마 제거)."""
    messages = []
    for raw_line in text.split("\n"):
        line = raw_line.strip()
        if not line:
            continue
        # 따옴표/쉼표 정리
        if line.startswith('"'):
            line = line.lstrip('"')
        if line.endswith('",') or line.endswith('"'):
            line = line.rstrip(',').rstrip('"')
        line = line.strip()
        if "2,OHT," in line:
            idx = line.index("2,OHT,")
            messages.append(line[idx:])
    return messages


def post_oht_messages(server_url: str, messages: list, timeout: float = 3.0) -> dict:
    """서버에 메시지를 POST하고 응답 dict를 반환."""
    url = server_url.rstrip("/") + DEFAULT_ENDPOINT
    payload = json.dumps({"messages": messages}).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return {"status": "error", "http_status": e.code, "message": e.reason}
    except urllib.error.URLError as e:
        return {"status": "error", "message": str(e.reason)}
    except Exception as e:
        return {"status": "error", "message": str(e)}


def bump_distance(msg: str, delta: int) -> str:
    """메시지의 distance(fields[8])를 delta만큼 증가시켜 이동 효과."""
    fields = msg.split(",")
    if len(fields) < 10 or fields[1] != "OHT":
        return msg
    try:
        dist = int(fields[8])
        fields[8] = str(dist + delta)
    except ValueError:
        return msg
    return ",".join(fields)


class TestSendUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("OHT Raw 메시지 테스트 전송기")
        self.root.geometry("820x620")

        self.auto_running = False
        self.auto_thread: threading.Thread | None = None

        self._build_widgets()

    # ------------------------------------------------------------
    # UI 구성
    # ------------------------------------------------------------
    def _build_widgets(self):
        pad = {"padx": 8, "pady": 4}

        # 서버 URL
        top = ttk.Frame(self.root)
        top.pack(fill="x", **pad)
        ttk.Label(top, text="Server URL:").pack(side="left")
        self.url_var = tk.StringVar(value=DEFAULT_SERVER_URL)
        ttk.Entry(top, textvariable=self.url_var, width=40).pack(side="left", padx=6)
        ttk.Label(top, text=DEFAULT_ENDPOINT, foreground="#666").pack(side="left")

        # 메시지 입력
        mid_label = ttk.Frame(self.root)
        mid_label.pack(fill="x", **pad)
        ttk.Label(mid_label, text="OHT 메시지 (줄마다 하나씩):").pack(side="left")
        ttk.Button(mid_label, text="샘플 로드", command=self.load_sample).pack(side="right", padx=2)
        ttk.Button(mid_label, text="파일 열기", command=self.load_file).pack(side="right", padx=2)
        ttk.Button(mid_label, text="비우기", command=self.clear_text).pack(side="right", padx=2)

        self.text = scrolledtext.ScrolledText(self.root, height=15, wrap="none", font=("Consolas", 9))
        self.text.pack(fill="both", expand=True, **pad)

        # 옵션
        opt = ttk.LabelFrame(self.root, text="자동 반복 전송 (distance +delta 로 이동 효과)")
        opt.pack(fill="x", **pad)

        ttk.Label(opt, text="주기(초):").grid(row=0, column=0, padx=4, pady=4)
        self.interval_var = tk.DoubleVar(value=0.5)
        ttk.Entry(opt, textvariable=self.interval_var, width=6).grid(row=0, column=1, padx=4)

        ttk.Label(opt, text="distance 증가량:").grid(row=0, column=2, padx=4)
        self.delta_var = tk.IntVar(value=5)
        ttk.Entry(opt, textvariable=self.delta_var, width=6).grid(row=0, column=3, padx=4)

        self.auto_btn = ttk.Button(opt, text="자동 전송 시작", command=self.toggle_auto)
        self.auto_btn.grid(row=0, column=4, padx=8)

        # 전송 버튼
        btns = ttk.Frame(self.root)
        btns.pack(fill="x", **pad)
        ttk.Button(btns, text="한 번 전송", command=self.send_once).pack(side="left", padx=4)
        ttk.Button(btns, text="종료", command=self.root.destroy).pack(side="right", padx=4)

        # 결과 출력
        ttk.Label(self.root, text="응답 / 로그:").pack(anchor="w", padx=8)
        self.log = scrolledtext.ScrolledText(self.root, height=8, wrap="word", font=("Consolas", 9),
                                             background="#111", foreground="#0f0")
        self.log.pack(fill="both", expand=False, padx=8, pady=(0, 8))

    # ------------------------------------------------------------
    # 버튼 핸들러
    # ------------------------------------------------------------
    def load_sample(self):
        self.text.delete("1.0", "end")
        self.text.insert("1.0", "\n".join(SAMPLE_MESSAGES))

    def load_file(self):
        path = filedialog.askopenfilename(
            title="OHT 메시지 파일 선택",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            messagebox.showerror("파일 읽기 실패", str(e))
            return
        self.text.delete("1.0", "end")
        self.text.insert("1.0", content)

    def clear_text(self):
        self.text.delete("1.0", "end")

    def send_once(self):
        messages = extract_oht_messages(self.text.get("1.0", "end"))
        if not messages:
            self._log("메시지 없음 (2,OHT, 로 시작하는 줄이 필요)")
            return
        resp = post_oht_messages(self.url_var.get().strip(), messages)
        self._log(f"[전송] {len(messages)}건 → {resp}")

    def toggle_auto(self):
        if self.auto_running:
            self.auto_running = False
            self.auto_btn.config(text="자동 전송 시작")
            self._log("자동 전송 중지")
        else:
            messages = extract_oht_messages(self.text.get("1.0", "end"))
            if not messages:
                self._log("자동 전송 실패: 메시지 없음")
                return
            self.auto_running = True
            self.auto_btn.config(text="자동 전송 중지")
            self.auto_thread = threading.Thread(
                target=self._auto_loop, args=(messages,), daemon=True
            )
            self.auto_thread.start()
            self._log(f"자동 전송 시작: {len(messages)}건, 주기 {self.interval_var.get()}s")

    # ------------------------------------------------------------
    # 자동 전송 루프
    # ------------------------------------------------------------
    def _auto_loop(self, base_messages: list):
        step = 0
        while self.auto_running:
            try:
                delta = self.delta_var.get() * step
                current = [bump_distance(m, delta) for m in base_messages]
                resp = post_oht_messages(self.url_var.get().strip(), current)
                self._log(f"[auto #{step}] delta=+{delta} → {resp}")
            except Exception as e:
                self._log(f"[auto 오류] {e}")
            step += 1
            # 주기
            try:
                interval = max(0.05, float(self.interval_var.get()))
            except Exception:
                interval = 0.5
            time.sleep(interval)

    # ------------------------------------------------------------
    # 로그 출력 (스레드 안전)
    # ------------------------------------------------------------
    def _log(self, text: str):
        def _append():
            ts = time.strftime("%H:%M:%S")
            self.log.insert("end", f"[{ts}] {text}\n")
            self.log.see("end")
        try:
            self.root.after(0, _append)
        except tk.TclError:
            pass


def main():
    root = tk.Tk()
    try:
        style = ttk.Style()
        if "vista" in style.theme_names():
            style.theme_use("vista")
    except Exception:
        pass
    TestSendUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
