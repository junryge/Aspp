================================================================
v5 검증 패키지 — A(blend 0.15 임계) + B(MLUD/CNV 신규룰)
================================================================

[들어있는 파일]
  hubroom_predictor.py  — 룰베이스 v5 (신규 룰 R-MLUD, R-CNVFULL 추가)
  thresholds.json       — blend 0.15 임계 + 신규 룰 임계
  config.json           — Logpresso 비활성 (적재 차단)

[추가로 필요한 파일 — 같은 폴더에 두기]
  Rule_LO.py            — V4/Rule_LO.py 그대로 복사 (의존성, 비활성 상태로 동작)

[★ Logpresso 안전 — 4중 차단]
  1. config.json: enabled=false
  2. config.json: ml_enabled=false
  3. 코드: run_once 진입 시 _logpresso=None 강제
  4. api_key.txt 파일 만들지 않기

  → 위 4개 중 하나라도 막혀있으면 적재 안 됨. 지금 4개 다 차단.
  실행 로그에 "[백테스트] Logpresso 적재 비활성화" 보이면 정상.

[실행]
  python hubroom_predictor.py <5월_raw_idc.csv> -o ./predict_tobe

  → predict_tobe/YYYYMMDD_사건단위.csv (30개 일자별)
    predict_tobe/YYYYMMDD_발동이벤트.csv

[v5 변경 요약]
  A. 임계 (blend 0.15)
    TH_RA M16HUB:  9.0 → 9.45
    TH_RA M16B:    3.5 → 3.88
    TH_RA_SUSTAINED_RATIO: 0.67 → 0.7
    TH_RC_REVERSE: 2 → 4
    TH_RD_STB:     99.0 → 99.3
    TH_RD_FAB:     25.0 → 25.75
    TH_SLA M16A:   13.0 → 14.05
    TH_SLA M16B:   18.0 → 22.05
    TH_SORTER M14: 100 → 148

  B. 신규 룰 (R-D 우산 아래 통합)
    R-MLUD: M16HUB.QUE.ALL.3F_TO_3F_MLUD_JOB ≥ 50
            OR M16HUBTOM14MANUAL_CURRENTQCNT ≥ 30
    R-CNVFULL: cnv_to_m14a / cnv_capa ≥ 0.85

[기대 결과 (5월 데이터 기준)]
  v4.1 (기존):  사건 387건, FP 339, 재현율 45%
  v5 (A+B):    사건 약 220~260건 (FP 감소), 재현율 47%+ (B로 미세 상승)

[결과물]
  predict_tobe/ 폴더 통째로 압축해서 보내주면 5월 메신저 매칭으로 효과 측정.
================================================================
