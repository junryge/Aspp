# -*- coding: utf-8 -*-
"""llm_engine.py - Gemma GGUF 로드 + 스트리밍 채팅 (llama-cpp-python / Vulkan)"""
import threading

SYSTEM_PROMPT = (
    "너는 파일과 코드를 다루는 한국어 보조 어시스턴트다.\n"
    "- 파일 내용을 받으면 핵심만 간결하게 요약한다.\n"
    "- 코드를 받으면 의미를 짧게 설명하거나 문제점을 짚는다.\n"
    "- 코드 작성 요청이면 즉시 실행 가능한 코드만 깔끔하게 준다.\n"
    "- 작업 로그를 받으면 무엇을 했는지 시간순으로 정리해준다.\n"
    "- 단어 뜻풀이, 발음 설명, 불필요한 표는 만들지 않는다.\n"
    "- 항상 한국어로, 짧고 명확하게 답한다."
)


class _ThinkFilter:
    """<think>...</think> 블록 실시간 제거 (토큰 경계 안전)."""
    OPEN, CLOSE = "<think>", "</think>"

    def __init__(self):
        self.buf = ""
        self.in_think = False

    def feed(self, tok):
        self.buf += tok
        out = ""
        while self.buf:
            if not self.in_think:
                i = self.buf.find(self.OPEN)
                if i == -1:
                    cut = self._safe_len(self.buf, self.OPEN)
                    out += self.buf[:cut]
                    self.buf = self.buf[cut:]
                    break
                out += self.buf[:i]
                self.buf = self.buf[i + len(self.OPEN):]
                self.in_think = True
            else:
                j = self.buf.find(self.CLOSE)
                if j == -1:
                    keep = self._tail_len(self.buf, self.CLOSE)
                    self.buf = self.buf[len(self.buf) - keep:] if keep else ""
                    break
                self.buf = self.buf[j + len(self.CLOSE):]
                self.in_think = False
        return out

    def flush(self):
        out = "" if self.in_think else self.buf
        self.buf = ""
        return out

    @staticmethod
    def _safe_len(s, tag):
        for k in range(min(len(tag) - 1, len(s)), 0, -1):
            if s.endswith(tag[:k]):
                return len(s) - k
        return len(s)

    @staticmethod
    def _tail_len(s, tag):
        for k in range(min(len(tag) - 1, len(s)), 0, -1):
            if s.endswith(tag[:k]):
                return k
        return 0


class LLMEngine:
    """GGUF 모델 로드 + 스트리밍. on_token 콜백으로 토큰 단위 전달."""

    def __init__(self):
        self.llm = None
        self.lock = threading.Lock()    # 동시 추론 방지
        self.stop_flag = False

    @property
    def ready(self):
        return self.llm is not None

    def load(self, model_path, n_ctx=8192, n_gpu_layers=-1, on_log=None):
        """모델 로드. 성공 True / 실패 시 예외. on_log(str): GUI 로그 콜백."""
        import os
        import time
        from llama_cpp import Llama
        log = on_log or (lambda s: None)
        size = os.path.getsize(model_path) / (1024**3) if os.path.exists(model_path) else 0
        log(f"[LOAD] {os.path.basename(model_path)}  ({size:.2f} GB)")
        log(f"[LOAD] n_ctx={n_ctx}  n_gpu_layers={n_gpu_layers}  (verbose=True → 콘솔에서 Vulkan 확인)")
        self.n_ctx = n_ctx
        t0 = time.time()
        self.llm = Llama(
            model_path=model_path,
            n_gpu_layers=n_gpu_layers,
            n_ctx=n_ctx,
            verbose=True,   # 콘솔에서 Vulkan 잡혔는지 확인용
        )
        log(f"[LOAD] 완료  ({time.time()-t0:.1f}s)")
        return True

    def stop(self):
        self.stop_flag = True

    def reset_cache(self):
        """대화 컨텍스트(KV 캐시) 초기화. 새 세션 시 호출."""
        if self.llm is not None:
            try:
                self.llm.reset()
            except Exception:
                pass

    def stream_chat(self, history, on_token, on_done,
                    temperature=0.4, max_tokens=1024):
        """history(list of {role,content}) → 스트리밍 생성.
        on_token(str): 가시 토큰마다 호출 / on_done(full_text): 완료 시 호출."""
        if self.llm is None:
            on_done("[모델이 로드되지 않았습니다. 설정에서 모델 경로 확인]")
            return
        self.stop_flag = False
        # 보낼 컨텍스트 길이 제한: 너무 길면 앞쪽(오래된) 대화 제거
        ctx = self.n_ctx if hasattr(self, "n_ctx") and self.n_ctx else 8192
        budget = ctx - max_tokens - 400          # 답변+시스템 자리 확보
        hist = list(history)
        while len(hist) > 1 and self._approx_tokens(hist) > budget:
            hist = hist[2:]                       # user+assistant 한 쌍씩 제거
        msgs = [{"role": "system", "content": SYSTEM_PROMPT}] + hist
        full = ""
        tf = _ThinkFilter()
        try:
            with self.lock:
                stream = self.llm.create_chat_completion(
                    messages=msgs,
                    temperature=temperature,
                    top_p=0.9,
                    top_k=40,
                    repeat_penalty=1.3,     # 반복 폭주 방지
                    max_tokens=max_tokens,
                    stream=True,
                )
                for chunk in stream:
                    if self.stop_flag:
                        break
                    delta = chunk["choices"][0].get("delta") or {}
                    piece = delta.get("content", "")
                    if not piece:
                        continue
                    vis = tf.feed(piece)
                    if vis:
                        full += vis
                        on_token(vis)
                        # 반복 폭주 안전망: 끝부분에 같은 조각 5회+ → 중단
                        if len(full) > 300:
                            tail = full[-200:]
                            for seg in ("→ ", "**", "| "):
                                if tail.count(seg) >= 6:
                                    self.stop_flag = True
                                    break
            tail = tf.flush()
            if tail:
                full += tail
                on_token(tail)
        except Exception as e:
            es = str(e).lower()
            if any(k in es for k in ("context", "n_ctx", "token", "kv", "exceed", "slot")):
                # 컨텍스트 부족 → 캐시 비우고 안내
                self.reset_cache()
                msg = ("\n\n[대화가 너무 길어 컨텍스트가 찼습니다.\n"
                       " 상단의 '새 세션' 버튼을 눌러 새로 시작하세요. "
                       "지금까지 대화는 자동 저장됩니다.]")
            else:
                msg = f"\n[LLM 오류] {e}"
            full += msg
            on_token(msg)
        on_done(full)

    @staticmethod
    def _approx_tokens(messages):
        """대략적 토큰 수 추정(한글 1.5자≈1토큰, 영문 4자≈1토큰 보수적으로 글자수/2)."""
        chars = sum(len(m.get("content", "")) for m in messages)
        return chars // 2
