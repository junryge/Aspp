# -*- coding: utf-8 -*-
"""
Rule_LO.py — Logpresso 적재기 (hubroom_predictor v4.1 발동이벤트)
=================================================================
패턴: M14A_FAB_data_make.py 와 동일 방식
  - API key: api_key.txt (1줄)
  - 설정: config.json
  - 엔드포인트: http://HOST:PORT/logpresso/httpexport/query.csv
  - 인증: ?_apikey=XXX 쿼리 파라미터

사용 (hubroom_predictor.py 에서 import):
    import Rule_LO
    Rule_LO.start()
    Rule_LO.upload(EVENT_FIELDS, row_values)   # 매 이벤트
    Rule_LO.stop()

저장 방식:
  Logpresso 쿼리 `import csvtbl ... | savetbl test_table3` 형식.
  CSV 한 줄을 inputtxt 로 넣고 savetbl 로 적재.

★ 2026-09-22 — AMHS_SCORE 테이블 (FAB 별 점수) 추가
  발동이벤트 한 줄이 들어오면 FAB 5개(M16HUB · M14 · M14B · M16A · M16B)로
  나눠 한 줄씩, 컬럼 5개만 AMHS_SCORE 에 적재한다.

      datetime              시각 'YYYY-MM-DD HH:MM' (년-월-일 시:분, 초 없음)
      fab_name              FAB 이름 (고정값)
      area_score            0~100 영역 점수
      predicted_fault_type  예측 장애 유형 (발동이벤트 값 그대로)
      area_score_raw        룰 배점 합계 + PIO 점수

  area_score / area_score_raw 는 발동이벤트_영역분리.py 와 같은 식으로 계산한다.
      area_score_raw = {FAB}_score_raw + {FAB}_PIO_SCORE
      area_score     = min(100, round(area_score_raw × 100 ÷ 분모))
  분모는 영역분리와 같은 영역등급.json 을 읽는다 (없으면 70).

  · 발동이벤트(ALL 한 줄)를 test_table3 에 넣던 것을 AMHS_SCORE(FAB 5줄)로 바꾼다.
  · test_table3 에는 아무것도 보내지 않는다 (발동이벤트 · 사건단위 모두).
  · 사건단위 줄(INCIDENT_FIELDS)은 {FAB}_score_raw 가 없어 AMHS_SCORE 로도 가지 않는다.
  · 예전처럼 test_table3 에 보내려면 config.json 에 "send_rule_table": true
  · AMHS_SCORE 를 끄려면 "amhs_enabled": false
  · 테이블 이름을 바꾸려면 "amhs_table_name": "..."
  · config.json 을 안 고쳐도 동작한다 (위 값은 전부 코드에 기본값이 있다).
"""
import json
import logging
import os
import queue
import sys
import threading
import time
import urllib.parse
import urllib3
from datetime import datetime as _dt
from io import StringIO

import requests

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ============================================================
# 로깅
# ============================================================
log = logging.getLogger("Rule_LO")
log.setLevel(logging.INFO)
if not log.handlers:
    h = logging.StreamHandler()
    h.setFormatter(logging.Formatter("%(asctime)s [Rule_LO] %(message)s"))
    log.addHandler(h)


# ============================================================
# 설정 로드 (config.json + api_key.txt)
# ============================================================
_HERE = os.path.dirname(os.path.abspath(__file__))


def _load_config():
    """config.json 로드. 없으면 안전한 기본값."""
    path = os.path.join(_HERE, "config.json")
    if not os.path.exists(path):
        log.warning(f"config.json 없음 ({path}) — 기본값 사용 (비활성)")
        return {"enabled": False}
    try:
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
        return cfg
    except Exception as e:
        log.error(f"config.json 파싱 실패: {e}")
        return {"enabled": False}


def _load_api_key(key_file_name):
    """api_key.txt 로드 (1줄). M14A_FAB_data_make.py 동일 패턴."""
    for p in [os.path.join(_HERE, key_file_name),
              os.path.join(os.getcwd(), key_file_name)]:
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                return f.read().strip().splitlines()[0].strip()
    log.warning(f"{key_file_name} 없음 — 인증 실패 가능")
    return ""


CFG = _load_config()
API_KEY = _load_api_key(CFG.get("api_key_file", "api_key.txt")) if CFG.get("enabled") else ""

LOGPRESSO_BASE = CFG.get("logpresso_base", "http://localhost:8888/logpresso")
TABLE_NAME     = CFG.get("table_name", "test_table3")
FILE_LABEL     = CFG.get("file_label", "Rule_system")
ENABLED        = bool(CFG.get("enabled", False))
ASYNC_UPLOAD   = bool(CFG.get("async_upload", True))
QUEUE_MAX      = int(CFG.get("queue_max_size", 10000))
BATCH_SIZE     = int(CFG.get("batch_size", 50))
RETRY_ON_FAIL  = int(CFG.get("retry_on_fail", 3))
RETRY_BACKOFF  = float(CFG.get("retry_backoff", 1.0))
LOG_EVERY_N    = int(CFG.get("log_every_n", 60))
FAIL_SILENT    = bool(CFG.get("fail_silent", True))
HTTP_TIMEOUT   = int(CFG.get("http_timeout", 30))

INSERT_PATH    = CFG.get("_endpoints", {}).get("insert", "/httpexport/query.csv")
INSERT_URL     = LOGPRESSO_BASE.rstrip("/") + INSERT_PATH

# ★ 2026-09-22 — AMHS_SCORE (FAB 별 점수)
AMHS_TABLE     = CFG.get("amhs_table_name", "AMHS_SCORE")
AMHS_ENABLED   = bool(CFG.get("amhs_enabled", True))   # enabled 가 true 일 때만 동작
SEND_RULE_TABLE = bool(CFG.get("send_rule_table", False))  # test_table3 적재 — 기본 끔 (더 안 씀).
                                                           # 되돌리려면 config.json 에 true
AMHS_FABS      = ["M16HUB", "M14", "M14B", "M16A", "M16B"]
_AMHS_KEEP_ZERO = ("area_score", "area_score_raw")     # 점수 0 도 그대로 적재


def _load_area_denoms():
    """영역별 실효 분모. 발동이벤트_영역분리.py 의 load_denoms 와 같은 규칙.

    영역등급.json
        "분모": 70                       전 영역 공통 (영역별 dict 도 허용)
        "조정": {"M16HUB": 120, ...}     영역별 가감 %
    실효 분모 = 분모 ÷ (조정/100).  파일이 없으면 전 영역 70.
    """
    base, adj = 70, {}
    for p in [os.path.join(_HERE, "영역등급.json"),
              os.path.join(os.getcwd(), "영역등급.json")]:
        if os.path.exists(p):
            try:
                with open(p, encoding="utf-8") as f:
                    cfg = json.load(f)
                base = cfg.get("분모", cfg.get("denom", 70))
                adj = dict(cfg.get("조정") or cfg.get("adjust") or {})
            except Exception as e:
                log.warning(f"영역등급.json 읽기 실패 — 분모 70 사용: {e}")
            break
    out = {}
    for a in AMHS_FABS:
        b = float(base.get(a, 70)) if isinstance(base, dict) else float(base)
        pct = float(adj.get(a, 100)) or 100.0
        out[a] = b / (pct / 100.0)
    return out


AREA_DENOM = _load_area_denoms()


# ============================================================
# 내부 상태
# ============================================================
_queue: "queue.Queue" = None
_worker_thread = None
_stop_flag = threading.Event()
_count = 0
_fail_count = 0


# ============================================================
# Logpresso 쿼리 빌더 (json "{...}" | import <table>)
# ============================================================
# ★ URL 길이 한계 우회 — 긴 한글 텍스트 컬럼은 잘라서 적재
#   (한글은 URL 인코딩 시 1글자=9바이트로 부풀어서 큰 사건은 URL 수KB 초과 → 405/끊김)
_LONG_TEXT_COLS = {
    'reason', 'relation', 'propagation_chain', 'flow_signals',
    'maxcapa_signals', 'risk_factors', 'triggered_rules', 'maxcapa_changes',
    'M16HUB_rev_lids',
}
_MAX_LEN_LONG = int(CFG.get("max_long_text", 150))   # 긴 텍스트 컬럼 자르는 길이
_MAX_LEN_ANY  = int(CFG.get("max_any_text",  500))   # 안전망: 모든 컬럼 절대 상한


def _to_maru_literal(row_dict, keep_zero=()):
    """dict → Maru object literal: {k = 'v', k2 = 'v2'}.
       ★ 0/null/빈값 제외 + 긴 텍스트 자르기로 URL 길이 한계 우회.
       Logpresso 에서는 누락된 컬럼 = null = SQL 에서 0과 동일 처리.
       keep_zero 에 든 컬럼은 0 이어도 적재한다 (AMHS_SCORE 의 점수)."""
    parts = []
    for k, v in row_dict.items():
        # 내부 제어 키(_requeued · _table 등) 제외
        if isinstance(k, str) and k.startswith('_'):
            continue
        # 0/null/빈값 제외 — 쿼리 길이 단축
        if v is None or v == '':
            continue
        if k not in keep_zero and (v == 0 or v == '0' or v == 0.0):
            continue
        s = str(v)
        # ★ 긴 텍스트 컬럼 잘라내기 (URL 폭발 방지)
        max_len = _MAX_LEN_LONG if k in _LONG_TEXT_COLS else _MAX_LEN_ANY
        if len(s) > max_len:
            s = s[:max_len] + '…'
        s = s.replace("'", "\\'")
        parts.append(f"{k} = '{s}'")
    return "{" + ", ".join(parts) + "}"


def _build_query(row_dict):
    """단일 행 INSERT 쿼리. M14A 예시와 동일 패턴.
       row_dict['_table'] 이 있으면 그 테이블로 (AMHS_SCORE), 없으면 TABLE_NAME."""
    table = row_dict.get('_table') or TABLE_NAME
    literal = _to_maru_literal(row_dict, row_dict.get('_keep_zero') or ())
    escaped = literal.replace('"', '\\"')   # json " " 안쪽 " escape
    return f'json "{escaped}" | import {table}'


# ============================================================
# ★ 2026-09-22 — 발동이벤트 한 줄 → AMHS_SCORE 5줄 (FAB 별 5컬럼)
# ============================================================
def _fnum(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


_DT_IN = ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y/%m/%d %H:%M:%S',
          '%Y/%m/%d %H:%M')


def _fmt_minute(v):
    """시각을 'YYYY-MM-DD HH:MM' (년-월-일 시:분) 으로 통일. 초는 버린다."""
    s = str(v or '').strip()
    if s.isdigit():                      # 숫자만 — 자릿수로 형식을 정한다
        fmt = {12: '%Y%m%d%H%M', 14: '%Y%m%d%H%M%S'}.get(len(s))
        if fmt:
            try:
                return _dt.strptime(s, fmt).strftime('%Y-%m-%d %H:%M')
            except ValueError:
                pass
        return s[:16]
    for fmt in _DT_IN:
        try:
            return _dt.strptime(s, fmt).strftime('%Y-%m-%d %H:%M')
        except ValueError:
            continue
    return s[:16]


def _amhs_rows(row_dict):
    """발동이벤트 dict → FAB 5개 각각
       {datetime, fab_name, area_score, predicted_fault_type, area_score_raw}.

    사건단위 줄처럼 {FAB}_score_raw 가 없으면 빈 리스트 (AMHS_SCORE 로 안 보낸다).
    """
    out = []
    pft = row_dict.get('predicted_fault_type') or ''
    for a in AMHS_FABS:
        key = a + '_score_raw'
        if key not in row_dict:
            continue
        raw = _fnum(row_dict.get(key)) + max(0.0, _fnum(row_dict.get(a + '_PIO_SCORE')))
        dn = AREA_DENOM.get(a, 70.0)
        score = min(100, round(raw * 100 / dn)) if dn > 0 else 0
        raw_out = int(raw) if raw == int(raw) else round(raw, 1)
        out.append({
            'datetime': _fmt_minute(row_dict.get('datetime')),
            'fab_name': a,
            'area_score': score,
            'predicted_fault_type': pft,
            'area_score_raw': raw_out,
            '_table': AMHS_TABLE,
            '_keep_zero': _AMHS_KEEP_ZERO,
        })
    return out


def _post_query(q):
    """Logpresso 쿼리 실행 (GET httpexport — POST 는 서버가 405 반환).
       URL 길이 한계는 _to_maru_literal 에서 긴 텍스트 잘라 우회."""
    qs = " ".join(q.split())
    url = f"{INSERT_URL}?_apikey={API_KEY}&_q={urllib.parse.quote(qs, safe='')}"
    r = requests.get(url, verify=False, timeout=HTTP_TIMEOUT)
    if r.status_code != 200 or r.text.strip().startswith("<"):
        raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")
    return r


# ============================================================
# 전송 (재시도 포함) — 단일 행
# ============================================================
def _send_one(row_dict):
    """한 건 전송. 성공 True / 실패 False."""
    q = _build_query(row_dict)
    last_err = None
    for attempt in range(RETRY_ON_FAIL):
        try:
            _post_query(q)
            return True
        except Exception as e:
            last_err = e
            time.sleep(RETRY_BACKOFF * (2 ** attempt))
    log.warning(f"적재 실패 (재시도 {RETRY_ON_FAIL}회): {type(last_err).__name__}: {last_err}")
    return False


# ============================================================
# 비동기 워커 (단일 행씩 처리 — Logpresso json+import 단건 패턴)
# ============================================================
def _worker():
    """큐에서 1건씩 꺼내 전송. 종료 신호 받으면 남은 큐 flush 후 종료."""
    global _count, _fail_count
    while not _stop_flag.is_set() or (_queue and not _queue.empty()):
        try:
            row_dict = _queue.get(timeout=1.0)
        except queue.Empty:
            continue
        ok = _send_one(row_dict)
        if ok:
            _count += 1
            if LOG_EVERY_N and _count % LOG_EVERY_N == 0:
                log.info(f"적재 누적 {_count}행")
        else:
            # ★ 1회 실패한 행은 버리지 말고 큐 뒤에 1번만 재투입 (유실 방지).
            #   _requeued 플래그로 무한 재시도 방지.
            if not row_dict.get('_requeued') and _queue is not None and not _stop_flag.is_set():
                row_dict['_requeued'] = True
                try:
                    _queue.put_nowait(row_dict)
                    log.info("실패 행 재큐잉 (다음 사이클 재시도)")
                except queue.Full:
                    _fail_count += 1
            else:
                _fail_count += 1


# ============================================================
# 외부 API
# ============================================================
def start():
    """predictor 시작 시 호출 (1회)."""
    global _queue, _worker_thread
    if not ENABLED:
        log.info("Rule_LO 비활성 (config.json: enabled=false)")
        return
    if not API_KEY:
        log.warning("API key 없음 — 적재 시도하나 실패 예상")
    if SEND_RULE_TABLE:
        log.info(f"적재 활성 — {LOGPRESSO_BASE} / 테이블={TABLE_NAME} / file={FILE_LABEL}")
    else:
        log.info(f"{TABLE_NAME} 적재 끔 (send_rule_table=false)")
    if AMHS_ENABLED:
        dn = ' · '.join(f'{a} {AREA_DENOM[a]:g}' for a in AMHS_FABS)
        log.info(f"AMHS 적재 활성 — 테이블={AMHS_TABLE} / FAB 5개 × 5컬럼 / 분모 {dn}")
    if ASYNC_UPLOAD:
        _queue = queue.Queue(maxsize=QUEUE_MAX)
        _stop_flag.clear()
        _worker_thread = threading.Thread(target=_worker, daemon=True, name="Rule_LO-worker")
        _worker_thread.start()
        log.info(f"비동기 워커 시작 (queue_max={QUEUE_MAX}, 단일행씩 전송)")


def _enqueue(row_dict):
    """큐에 넣거나(비동기) 바로 보낸다(동기)."""
    if ASYNC_UPLOAD and _queue is not None:
        try:
            _queue.put_nowait(row_dict)
        except queue.Full:
            try:
                _queue.get_nowait()
                _queue.put_nowait(row_dict)
            except queue.Empty:
                pass
    else:
        _send_one(row_dict)


def upload(fields, row):
    """단일 이벤트 적재. fields/row 는 hubroom_predictor 의 EVENT_FIELDS / event_to_row 결과.
       fields(list of str) + row(list of values) → dict 로 변환 후 file 컬럼 덮어쓰기.

       ★ 2026-09-22 — 같은 줄로 AMHS_SCORE 에 FAB 5줄을 추가로 적재한다."""
    if not ENABLED:
        return
    try:
        row_dict = dict(zip(fields, row))
        is_event = any((a + '_score_raw') in row_dict for a in AMHS_FABS)
        # test_table3 — 기본 끔. send_rule_table=true 일 때만 예전처럼 통째로 적재
        if SEND_RULE_TABLE:
            full = dict(row_dict)
            full['file'] = FILE_LABEL   # 무조건 하드코딩
            _enqueue(full)
        # AMHS_SCORE — 발동이벤트 줄만 (사건단위 줄은 FAB 점수가 없어 보내지 않는다)
        if is_event and AMHS_ENABLED:
            for r in _amhs_rows(row_dict):
                _enqueue(r)
    except Exception as e:
        if not FAIL_SILENT:
            raise
        log.debug(f"upload 예외 무시: {e}")


def stop():
    """predictor 종료 시 호출. 남은 큐 flush 후 종료."""
    if not ENABLED:
        return
    _stop_flag.set()
    if _worker_thread and _worker_thread.is_alive():
        _worker_thread.join(timeout=10.0)
    log.info(f"종료 — 적재 성공 {_count}, 실패 {_fail_count}")


def stats():
    return {
        "enabled": ENABLED,
        "uploaded": _count,
        "failed": _fail_count,
        "queued": _queue.qsize() if _queue else 0,
        "url": INSERT_URL,
        "table": TABLE_NAME,
        "file_label": FILE_LABEL,
        "amhs_enabled": AMHS_ENABLED,
        "send_rule_table": SEND_RULE_TABLE,
        "amhs_table": AMHS_TABLE,
        "area_denom": dict(AREA_DENOM),
    }
