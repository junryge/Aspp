"""
demos_v1/__init__.py - Package initialization, Flask app creation, route registration
"""
import os
import sys
import warnings
from flask import Flask

# Create Flask app
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB 제한


_routes_registered = False

def create_app():
    """Create and configure the Flask app with all routes registered."""
    global _routes_registered
    if _routes_registered:
        return app

    from demos_v1.routes_api import register_api_routes
    from demos_v1.routes_chat import register_chat_routes
    from demos_v1.logpresso import register_logpresso_routes
    from demos_v1.knowledge import register_knowledge_routes
    from demos_v1.routes_ppt import register_ppt_routes
    from demos_v1.routes_agents import register_agent_routes

    register_api_routes(app)
    register_chat_routes(app)
    register_logpresso_routes(app)
    register_knowledge_routes(app)
    register_ppt_routes(app)
    register_agent_routes(app)

    # GGUF 를 OpenAI 호환으로 내보낸다 (/v1/*).
    # ★아바타(avatar_2d) 같은 다른 앱이 **같은 모델 한 벌**을 나눠 쓰기 위한
    #   문이다. 없으면 앱마다 llama-cpp 로 모델을 또 올려서 VRAM 이 터진다.
    try:
        from demos_v1.routes_openai import register_openai_routes
        register_openai_routes(app)
    except Exception as _oe:
        print(f"  ⚠️  GGUF OpenAI 라우트 스킵: {_oe}")

    # 루프 엔지니어링(loop_engine) 라우트 — 실패해도 본체 정상 동작
    try:
        from demos_v1.routes_loop import register_loop_routes
        register_loop_routes(app)
        print("  🔁 루프엔진 라우트 등록 완료 (/api/loop/run)")
    except Exception as _le:
        print(f"  ⚠️  루프엔진 라우트 스킵: {_le}")

    # 세션 서버 저장 + 전문검색 — 실패해도 본체는 정상 동작(localStorage 유지)
    try:
        from demos_v1.routes_sessions import register_session_routes
        _fts = register_session_routes(app)
        print(f"  🗂  세션 저장·검색 라우트 등록 완료 (/api/sessions/*, "
              f"검색엔진 {'FTS5' if _fts else 'LIKE 폴백'})")
    except Exception as _se:
        print(f"  ⚠️  세션 저장·검색 라우트 등록 실패(무시): {_se}")

    # ⏰ 예약 작업 (매일/간격 프롬프트 실행) — 실패해도 본체는 정상 동작
    try:
        from demos_v1.routes_schedule import register_schedule_routes
        register_schedule_routes(app)
        print("  ⏰ 예약 작업 라우트 등록 완료 (/api/schedules/*, 30초 주기 워커)")
    except Exception as _sce:
        print(f"  ⚠️  예약 작업 라우트 등록 실패(무시): {_sce}")

    # 🧠 기억 (잘려 나가는 대화에서 오래 갈 것만 건진다) — 실패해도 본체는 정상
    try:
        from demos_v1.routes_memory import register_memory_routes
        register_memory_routes(app)
        from demos_v1 import memory as _memmod
        _memmod.start_worker()
        print("  🧠 기억 라우트 등록 완료 (/api/memory/*)")
    except Exception as _me:
        print(f"  ⚠️  기억 등록 실패(무시): {_me}")

    # 헤르메스(재해석) 엔진 라우트 — 실패해도 데모스 본체는 정상 동작
    try:
        from demos_v1.hermes.routes import register_hermes_routes
        register_hermes_routes(app)
        print("  🔮 헤르메스 라우트 등록 완료 (/api/hermes/*)")
    except Exception as _he:
        print(f"  ⚠️  헤르메스 라우트 등록 실패(무시): {_he}")

    # 🖼 화이트보드 (답변 속 Mermaid 글 → 그림) — 데모스·코딩 어시스턴트가 같이 쓴다.
    #    실패해도 본체는 정상 동작 (그림 대신 글이 그대로 보인다)
    try:
        from demos_v1.whiteboard import register_whiteboard_routes
        register_whiteboard_routes(app)
        print("  🖼  화이트보드 라우트 등록 완료 (/api/whiteboard/render)")
    except Exception as _wbe:
        print(f"  ⚠️  화이트보드 등록 실패(무시): {_wbe}")

    # code_assist_v1 통합 (Blueprint, url_prefix="/code", demos_v1 리소스 공유)
    try:
        from code_assist_v1.blueprint import register_code_blueprint
        register_code_blueprint(app)
        print("  🖥️  code_assist_v1 Blueprint 등록 완료 (/code/*)")
    except Exception as _e:
        print(f"  ⚠️  code_assist_v1 Blueprint 등록 실패: {_e}")

    # 하네스(harness) 스킬 라우터 — init_harness() 를 호출하지 않으면 레지스트리가
    # 빈 채로 남아 라우터/Expert Pool/조합추천이 전부 빈 결과(자동 비활성)가 된다.
    # 여기서 명시적으로 초기화 + /api/harness/* 라우트 등록. 실패해도 본체는 정상 동작.
    try:
        from harness_bridge import init_harness, register_harness_routes
        from demos_v1.utils import SKILLS_DIR as _HSD
        try:
            from demos_v1.skills import SKILL_KEYWORDS as _HKW
        except Exception:
            _HKW = None
        _hreg = init_harness(skills_dir=_HSD, skill_keywords=_HKW)
        register_harness_routes(app)
        print(f"  🧰 하네스 등록 완료 ({len(_hreg.list_all())}개 스킬, 라우터/Expert Pool 활성, /api/harness/*)")
    except Exception as _hb:
        print(f"  ⚠️  하네스 등록 실패(무시): {_hb}")

    _routes_registered = True
    return app
