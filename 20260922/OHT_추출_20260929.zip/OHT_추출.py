#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OHT_추출.py — 로그프레소 OHT(M16HUB) 50초 집계 → CSV 저장 · 스코어 알람 판정

쿼리 형식은 logpresso_query.py 와 같다.
  remote icamcslogdt01 [ table from=… to=… oht_data_m16br | search MSG_ID == "2" | … ]
  · MSG_ID=2 만 쓴다 (차량 상태 메시지)
  · 로그프레소 안에서 50초로 묶어 차량당 한 줄만 받는다 (datetrunc 50s) — 원본보다 훨씬 가볍다

명령어
  ① 연결 확인
     python OHT_추출.py --test
  ② 날짜 → CSV 저장
     python OHT_추출.py 20260929
     python OHT_추출.py 20260901 20260929
     python OHT_추출.py --from "2026-09-29 07:00" --to "2026-09-29 08:50"
  ③ 스코어 알람 판정 (알람 앞뒤 구간만 조회 → 한 달 전체보다 훨씬 빠르다)
     python OHT_추출.py --score 실시간스코어.csv
     python OHT_추출.py --score 실시간스코어.csv --truth 실제사건.csv

저장
  oht_raw/OHT50_YYYYMMDD_HHMM.csv   로그프레소 조회 결과 조각 (차량 × 50초) — 이어받기용
  oht_50s/OHT50_YYYYMMDD.csv        50초 집계 (시각, 보고차량, 미보고, JAM, HT_STOP)
  out/알람판정.csv · out/요약.txt     ③ 의 결과

· 끊기면 같은 명령을 다시 실행 — 받은 조각은 건너뛴다
· 판정: 알람 시각 기준 과거 10분 OHT 로 확정 / 전조 / 관찰
"""
import argparse
import csv
import io
import json
import os
import sys
import time
import urllib.parse
from collections import Counter, defaultdict
from datetime import datetime, timedelta

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
HERE = os.path.dirname(os.path.abspath(__file__))

# ───────────────────────────────────────────────────────────
# 접속 설정 — logpresso_query.py 와 같은 자리
# ───────────────────────────────────────────────────────────
# [운영]
HOST    = "10.40.42.27"
PORT    = 8888
API_KEY = ""          # ★키를 여기에 적으세요 (저장소에 올릴 때는 다시 비울 것)

# [개발]
# HOST    = "10.125.173.63"
# PORT    = 8888
# API_KEY = ""

REMOTE_NODE = "icamcslogdt01"     # 비우면 remote 로 감싸지 않음
TABLE       = "oht_data_m16br"    # M16HUB OHT 테이블

# ───────────────────────────────────────────────────────────
# 분석 설정
# ───────────────────────────────────────────────────────────
BUCKET_SEC   = 50        # ★ 50초 집계 — 50초 안에 보고 없으면 미보고(멈춘 차량)
FLEET_SIZE   = 270       # M16HUB 전체 차량 수
VEHICLE_PREFIX = "BV"    # M16HUB 차량 (BV0001~)
CHUNK_MIN    = 60        # 한 번에 조회하는 길이(분). 느리거나 끊기면 30
MAX_BYTES    = 30 * 1024 * 1024   # 한 조각 응답이 이보다 크면 반으로 나눠 다시
HTTP_TIMEOUT = 600
RETRY        = 3

LOOKBACK_MIN = 10        # 알람 시각 기준 과거 몇 분
AFTER_MIN    = 10        # 알람 뒤 몇 분까지 (참고용 조회)

# 판정 — 과거 10분 안 50초 구간 값의 최댓값 (사건 2건 기준 후보)
TH_CONFIRM_MISS, TH_CONFIRM_HT = 100, 1    # 확정
TH_ALERT_MISS,   TH_ALERT_JAM  = 30, 20    # 경보
TH_PRE_MISS,     TH_PRE_JAM    = 10, 1     # 전조

FMT = "%Y%m%d%H%M%S"
GRADE_RANK = {"정상": 0, "경계": 1, "위험": 2, "초위험": 3}


# ───────────────────────────────────────────────────────────
# 키 · 주소 — 위를 비워 두면 환경변수 → 같은 폴더 config.json / api_key.txt 순으로 찾는다
# ───────────────────────────────────────────────────────────
def _borrow():
    global HOST, PORT, API_KEY
    src = "파일"
    if not API_KEY:
        API_KEY = os.environ.get("LP_API_KEY", "").strip()
        src = "환경변수"
    if not API_KEY:
        for base in (HERE, os.getcwd()):
            try:
                with open(os.path.join(base, "config.json"), encoding="utf-8-sig") as f:
                    c = json.load(f) or {}
                b = str(c.get("logpresso_base") or "")
                if "//" in b:                       # 키를 빌리면 주소도 같은 곳에서 (401 방지)
                    hp = b.split("//", 1)[1].split("/", 1)[0]
                    HOST = hp.split(":")[0]
                    if ":" in hp:
                        PORT = int(hp.split(":")[1])
                kf = c.get("api_key_file") or "api_key.txt"
                with open(os.path.join(base, kf), encoding="utf-8-sig") as f:
                    API_KEY = f.read().strip().splitlines()[0].strip()
                src = f"config.json ({base})"
                break
            except Exception:
                pass
    if not API_KEY:
        for base in (HERE, os.getcwd()):
            p = os.path.join(base, "api_key.txt")
            if os.path.exists(p):
                with open(p, encoding="utf-8-sig") as f:
                    API_KEY = f.read().strip().splitlines()[0].strip()
                src = "api_key.txt"
                break
    HOST = os.environ.get("LP_HOST", "").strip() or HOST
    PORT = int(os.environ.get("LP_PORT", "").strip() or PORT)
    if not API_KEY:
        sys.exit("API 키가 없습니다 — 이 파일 위 API_KEY, 환경변수 LP_API_KEY, 또는 api_key.txt")
    return src


# ───────────────────────────────────────────────────────────
# 쿼리
# ───────────────────────────────────────────────────────────
def build_query(frm, to):
    """차량 × 50초 한 줄. 50초 안의 첫/끝 STATUS 와 JAM·HT-STOP 이 있었는지 표시."""
    inner = (
        f'table from={frm.strftime(FMT)} to={to.strftime(FMT)} {TABLE}'
        ' | search MSG_ID == "2"'
        ' | fields _time, VEHICLE, STATUS'
        f' | eval _time = datetrunc(_time, "{BUCKET_SEC}s")'
        ' | stats first(STATUS) as STATUS, last(STATUS) as STATUS_LAST by VEHICLE, _time'
        ' | sort _time, VEHICLE'
    )
    return f"remote {REMOTE_NODE} [ {inner} ]" if REMOTE_NODE else inner


def http_get(q):
    url = (f"http://{HOST}:{PORT}/logpresso/httpexport/query.csv"
           f"?_apikey={API_KEY}&_q={urllib.parse.quote(q, safe='')}")
    last = None
    for k in range(RETRY):
        try:
            r = requests.get(url, verify=False, timeout=HTTP_TIMEOUT)
            if r.status_code == 401:
                raise RuntimeError(f"401 인증 실패 — 주소 {HOST}:{PORT} 와 키가 짝이 맞는지 확인 "
                                   f"(키 끝 4자 …{API_KEY[-4:]})")
            if r.status_code != 200 or r.text.lstrip().startswith("<"):
                raise RuntimeError(f"HTTP {r.status_code}: {r.text[:300]}")
            return r.content
        except RuntimeError as e:
            if "401" in str(e):
                raise
            last = e
        except Exception as e:
            last = e
        time.sleep(3 * (k + 1))
    raise RuntimeError(f"조회 실패 ({RETRY}회) — {last}\n  쿼리: {q}")


def fetch_range(frm, to, raw_dir):
    """[frm, to) 를 CHUNK_MIN 조각으로 받아 파일로 저장. 이미 있으면 건너뛴다. 파일 목록 반환."""
    os.makedirs(raw_dir, exist_ok=True)
    files = []

    def one(s, e):
        p = os.path.join(raw_dir, f"OHT50_{s:%Y%m%d_%H%M%S}_{e:%H%M%S}.csv")
        if os.path.exists(p) and os.path.getsize(p) > 0:
            files.append(p)
            return
        t0 = time.time()
        body = http_get(build_query(s, e))
        if len(body) > MAX_BYTES and (e - s) > timedelta(minutes=2):
            m = s + (e - s) / 2
            print(f"    [분할] {s:%m-%d %H:%M}~{e:%H:%M} {len(body)/1e6:.1f}MB → 반으로")
            one(s, m)
            one(m, e)
            return
        with open(p + ".part", "wb") as f:
            f.write(body)
        os.replace(p + ".part", p)
        files.append(p)
        print(f"    {s:%m-%d %H:%M}~{e:%H:%M}  {len(body)/1e6:6.2f}MB  {time.time()-t0:5.0f}초")

    s = frm
    while s < to:
        e = min(to, s + timedelta(minutes=CHUNK_MIN))
        one(s, e)
        s = e
    return files


# ───────────────────────────────────────────────────────────
# 50초 집계
# ───────────────────────────────────────────────────────────
def parse_time(s):
    s = (s or "").strip().strip('"')[:19]
    for f in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M"):
        try:
            return datetime.strptime(s, f)
        except ValueError:
            pass
    return None


def aggregate(files):
    """조각 파일들 → {50초 시각: {rep, miss, jam, ht}}"""
    rep, jam, ht = defaultdict(set), defaultdict(set), defaultdict(set)
    for p in files:
        with open(p, encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                v = (r.get("VEHICLE") or "").strip()
                if not v or (VEHICLE_PREFIX and not v.startswith(VEHICLE_PREFIX)):
                    continue
                t = parse_time(r.get("_time"))
                if not t:
                    continue
                sts = {(r.get("STATUS") or "").strip(), (r.get("STATUS_LAST") or "").strip()}
                rep[t].add(v)
                if "7" in sts:
                    jam[t].add(v)
                if "8" in sts:
                    ht[t].add(v)
    return {t: {"rep": len(rep[t]), "miss": max(0, FLEET_SIZE - len(rep[t])),
                "jam": len(jam[t]), "ht": len(ht[t])} for t in sorted(rep)}


def save_50s(table, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    by_day = defaultdict(list)
    for t, v in table.items():
        by_day[t.strftime("%Y%m%d")].append((t, v))
    paths = []
    for d, rows in sorted(by_day.items()):
        p = os.path.join(out_dir, f"OHT50_{d}.csv")
        old = {}
        if os.path.exists(p):                       # 같은 날 다른 구간을 받았으면 합친다
            with open(p, encoding="utf-8-sig") as f:
                for r in csv.DictReader(f):
                    old[r["시각"]] = r
        for t, v in rows:
            old[t.strftime("%Y-%m-%d %H:%M:%S")] = {"시각": t.strftime("%Y-%m-%d %H:%M:%S"),
                                                   "보고차량": v["rep"], "미보고": v["miss"],
                                                   "JAM": v["jam"], "HT_STOP": v["ht"]}
        with open(p, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, ["시각", "보고차량", "미보고", "JAM", "HT_STOP"])
            w.writeheader()
            for k in sorted(old):
                w.writerow(old[k])
        paths.append(p)
    return paths


# ───────────────────────────────────────────────────────────
# 스코어 알람 · 판정
# ───────────────────────────────────────────────────────────
def read_table(path, must):
    with open(path, encoding="utf-8-sig") as f:
        raw = f.read()
    text = raw
    if raw.lstrip().startswith("{"):                # 노트북(.ipynb → txt)도 받는다
        text = None
        for c in json.loads(raw).get("cells", []):
            s = "".join(c["source"]) if isinstance(c["source"], list) else c["source"]
            if s and must in s.splitlines()[0]:
                text = s
                break
        if text is None:
            sys.exit(f"{path} 에서 '{must}' 헤더를 못 찾았습니다")
    return list(csv.DictReader(io.StringIO(text)))


def load_alarms(path):
    recs = []
    for r in read_table(path, "시간"):
        t = parse_time(r.get("시간"))
        if t:
            recs.append((t, (r.get("등급") or "").strip(), r.get("종합점수", ""), (r.get("알람") or "").strip()))
    recs.sort()
    out, prev = [], 0
    for t, g, sc, al in recs:
        rk = GRADE_RANK.get(g, 0)
        if rk >= 1 and rk > prev:                   # 경계/위험/초위험으로 올라간 순간
            out.append({"time": t, "grade": g, "score": sc, "alarm": al})
        prev = rk
    return out


def alarm_windows(alarms):
    iv = sorted((a["time"] - timedelta(minutes=LOOKBACK_MIN + 1),
                 a["time"] + timedelta(minutes=AFTER_MIN)) for a in alarms)
    merged = []
    for s, e in iv:
        if merged and s <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    return merged


def level(mm, jj, hh):
    if mm >= TH_CONFIRM_MISS or hh >= TH_CONFIRM_HT:
        return "확정"
    if mm >= TH_ALERT_MISS or jj >= TH_ALERT_JAM:
        return "경보"
    if mm >= TH_PRE_MISS or jj >= TH_PRE_JAM:
        return "전조"
    return "정상"


def judge(alarms, table, truth=None):
    res = []
    for a in alarms:
        t = a["time"]
        w = [v for b, v in table.items() if t - timedelta(minutes=LOOKBACK_MIN) <= b <= t]
        if w:
            mm, jj, hh = (max(v[k] for v in w) for k in ("miss", "jam", "ht"))
            lv = level(mm, jj, hh)
            verdict = {"확정": "진짜(확정)", "경보": "진짜(확정)", "전조": "진짜(전조)", "정상": "관찰"}[lv]
        else:
            mm = jj = hh = ""
            lv, verdict = "데이터없음", "판정불가"
        r = {**a, "n": len(w), "miss": mm, "jam": jj, "ht": hh, "oht": lv, "verdict": verdict}
        if truth is not None:
            r["truth"] = "진짜사건" if any(tt - timedelta(minutes=60) <= t <= tt + timedelta(minutes=10)
                                         for tt in truth) else "사건없음"
        res.append(r)
    return res


def write_judge(res, out_dir, has_truth):
    os.makedirs(out_dir, exist_ok=True)
    cols = ["알람시각", "등급", "점수", "알람", "과거10분_구간수", "미보고_최대", "JAM_최대",
            "HT_STOP_최대", "OHT단계", "판정"] + (["정답"] if has_truth else [])
    with open(os.path.join(out_dir, "알람판정.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for r in res:
            row = [r["time"].strftime("%Y-%m-%d %H:%M"), r["grade"], r["score"], r["alarm"], r["n"],
                   r["miss"], r["jam"], r["ht"], r["oht"], r["verdict"]]
            w.writerow(row + ([r["truth"]] if has_truth else []))
    lines = [f"알람 {len(res)}건 · 과거 {LOOKBACK_MIN}분 · {BUCKET_SEC}초 집계 · 전체 차량 {FLEET_SIZE}대", "",
             "등급 × 판정"]
    for g in ("경계", "위험", "초위험"):
        c = Counter(r["verdict"] for r in res if r["grade"] == g)
        if c:
            lines.append(f"  {g:4} " + " · ".join(f"{k} {v}" for k, v in c.most_common()))
    if has_truth:
        ok = [r for r in res if r["verdict"] != "판정불가"]
        lines += ["", "정답 비교 (알람이 사건 60분 전 ~ 10분 후 안이면 진짜사건 · 판정불가 제외)"]
        for name, rs in (("기존 알람 전체", ok),
                         ("OHT 진짜 판정만", [r for r in ok if r["verdict"].startswith("진짜")])):
            tp = sum(r["truth"] == "진짜사건" for r in rs)
            lines.append(f"  {name:12} 알람 {len(rs):4}건 · 진짜사건 {tp:4}건 · 정밀도 "
                         f"{(tp / len(rs) * 100 if rs else 0):5.1f}%")
        lines.append(f"  진짜사건인데 '관찰' 판정 {sum(r['truth']=='진짜사건' and r['verdict']=='관찰' for r in ok)}건 (확인 필요)")
    txt = "\n".join(lines)
    with open(os.path.join(out_dir, "요약.txt"), "w", encoding="utf-8") as f:
        f.write(txt + "\n")
    return txt


# ───────────────────────────────────────────────────────────
# main
# ───────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(description="OHT 50초 집계 CSV 저장 · 스코어 알람 판정")
    ap.add_argument("start", nargs="?", help="시작일 YYYYMMDD")
    ap.add_argument("end", nargs="?", help="끝일 YYYYMMDD (포함)")
    ap.add_argument("--from", dest="frm", help='"YYYY-MM-DD HH:MM"')
    ap.add_argument("--to", dest="to", help='"YYYY-MM-DD HH:MM"')
    ap.add_argument("--score", help="실시간 스코어 CSV → 알람 앞뒤만 조회해 판정")
    ap.add_argument("--truth", help="실제 사건 시각 CSV (헤더 '시간')")
    ap.add_argument("--test", action="store_true", help="연결 확인 (최근 조각 5줄)")
    ap.add_argument("--dry-run", action="store_true", help="쿼리·구간만 출력")
    ap.add_argument("--raw", default=os.path.join(HERE, "oht_raw"))
    ap.add_argument("--out50", default=os.path.join(HERE, "oht_50s"))
    ap.add_argument("--out", default=os.path.join(HERE, "out"))
    a = ap.parse_args()

    src = _borrow() if not a.dry_run else "-"
    print(f"[접속] {HOST}:{PORT}  remote={REMOTE_NODE or '(없음)'}  테이블 {TABLE}  "
          f"키 {src}{(' (끝 4자 …' + API_KEY[-4:] + ')') if API_KEY else ''}")

    if a.test:
        t = datetime.now().replace(second=0, microsecond=0) - timedelta(minutes=5)
        q = build_query(t, t + timedelta(minutes=2)).replace(" | sort _time, VEHICLE", " | limit 5")
        print("  [Q]", q)
        print(http_get(q).decode("utf-8", "replace")[:1500])
        print("  ↑ VEHICLE, _time, STATUS, STATUS_LAST 가 보이면 정상")
        return

    if a.score:
        alarms = load_alarms(a.score)
        print(f"[알람] {len(alarms)}건  " + " · ".join(f"{g} {n}" for g, n in Counter(x['grade'] for x in alarms).items()))
        if not alarms:
            sys.exit("알람이 없습니다 — 스코어 파일의 '시간' '등급' 컬럼 확인")
        wins = alarm_windows(alarms)
        print(f"[구간] {len(wins)}개 · 합계 {sum((e-s).total_seconds() for s, e in wins)/3600:.1f}시간")
        if a.dry_run:
            for s, e in wins:
                print("  ", build_query(s, e))
            return
        files = []
        for i, (s, e) in enumerate(wins, 1):
            print(f"  ({i}/{len(wins)}) {s:%m-%d %H:%M} ~ {e:%m-%d %H:%M}")
            files += fetch_range(s, e, a.raw)
        table = aggregate(files)
        save_50s(table, a.out50)
        truth = None
        if a.truth:
            truth = [t for t in (parse_time(r.get("시간")) for r in read_table(a.truth, "시간")) if t]
        print(write_judge(judge(alarms, table, truth), a.out, a.truth is not None))
        print(f"\n저장 → {a.out}/알람판정.csv · {a.out}/요약.txt · {a.out50}/")
        return

    if a.frm and a.to:
        s, e = parse_time(a.frm), parse_time(a.to)
    elif a.start:
        s = datetime.strptime(a.start, "%Y%m%d")
        e = datetime.strptime(a.end or a.start, "%Y%m%d") + timedelta(days=1)
    else:
        ap.error("날짜, --from/--to, --score, --test 중 하나를 주세요")
    if not s or not e or s >= e:
        ap.error("시작/끝 시각 확인")
    if a.dry_run:
        print("  ", build_query(s, min(e, s + timedelta(minutes=CHUNK_MIN))))
        return
    print(f"[추출] {s:%Y-%m-%d %H:%M} ~ {e:%Y-%m-%d %H:%M} · 조각 {CHUNK_MIN}분 · {BUCKET_SEC}초 집계")
    t0 = time.time()
    day = s.replace(hour=0, minute=0, second=0)
    while day < e:                                  # 하루씩 받고 하루씩 저장
        d0, d1 = max(s, day), min(e, day + timedelta(days=1))
        files = fetch_range(d0, d1, a.raw)
        for p in save_50s(aggregate(files), a.out50):
            print(f"■ 저장 → {p}")
        day += timedelta(days=1)
    print(f"완료 · {time.time()-t0:.0f}초")


if __name__ == "__main__":
    main()
