#!/usr/bin/env python3
"""
AMHS Sentinel_M16BR — 날짜별 CSV 누적 저장 (독립)

실시간 수집이 1분마다 가져온 데이터를 날짜 파일에 한 줄씩 붙인다.

    data/20260727_TOTAL.CSV

  · 기본 데이터 + AMOS 4개 컬럼이 합쳐진 상태 그대로 저장
  · 같은 시각(datetime)은 다시 안 쓴다 (재폴링 중복 방지)
  · 평가·리포트는 이 파일을 읽어서 한다 (로그프레소 재조회 불필요)
"""
from __future__ import annotations

import csv
import os
import re
import threading
from datetime import datetime, timedelta

from lp_client import load_config

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_lock = threading.Lock()
_keys_cache: dict[str, set] = {}      # {파일경로: {이미 쓴 키}}


_MADE: set = set()          # 이미 만들어 본 폴더 (같은 mkdir 을 매번 부르지 않게)


def _dir_of(cfg: dict) -> str:
    """저장 폴더 경로만 (만들지는 않는다 — 정리처럼 '보기만' 하는 쪽이 쓴다)."""
    return os.path.join(BASE_DIR, cfg.get("storage", {}).get("daily_csv_dir", "data"))


def data_dir(cfg: dict | None = None) -> str:
    """저장 폴더. 없으면 만든다 — 단, **한 번만**.

    ★day_path() 가 이걸 부르고, day_path 는 읽기·쓰기 경로 어디서나 불린다.
      예전엔 부를 때마다 os.makedirs 가 나가서, 하루치를 넣는 동안만
      1440번, 화면이 3초마다 물을 때마다 또 한 번씩 디스크를 두드렸다.
      폴더가 생겼는지 한 번 확인했으면 그 뒤로는 안 물어도 된다.
    """
    cfg = cfg or load_config()
    d = _dir_of(cfg)
    if d not in _MADE:
        os.makedirs(d, exist_ok=True)
        _MADE.add(d)
    return d


def day_path(day: str, cfg: dict | None = None) -> str:
    """'20260727' → data/20260727_TOTAL.CSV"""
    return os.path.join(data_dir(cfg), f"{day}_TOTAL.CSV")


def _day_of(row: dict, time_col: str) -> str:
    """행의 날짜(yyyyMMdd) 추출."""
    d = "".join(ch for ch in str(row.get(time_col) or "") if ch.isdigit())
    return d[:8] if len(d) >= 8 else datetime.now().strftime("%Y%m%d")


def _key_of(row: dict, time_col: str, key_cols: list[str]) -> str:
    return "|".join(str(row.get(c) or "") for c in ([time_col] + key_cols))


def _load_keys(day: str, path: str, time_col: str, key_cols: list[str]) -> set:
    """파일에 이미 있는 키를 읽어둔다 (재시작 후에도 중복 방지).

    ★캐시는 **날짜가 아니라 파일 경로** 기준이다. 날짜로만 잡으면
      저장 폴더가 바뀌었을 때(설정 변경·다중 인스턴스·테스트) 다른 폴더에서
      읽은 키를 그대로 써서 **새 파일에 아무것도 안 쓰인다** — 실시간 관제가
      데이터를 조용히 버리게 된다.
    ★파일이 사라졌으면(외부에서 지웠거나 폴더가 바뀜) 캐시도 버린다.
      안 그러면 "이미 있다" 고 착각해 영원히 다시 안 쓴다.
    """
    exists = os.path.isfile(path)
    if not exists:
        _keys_cache[path] = set()
        return _keys_cache[path]
    if path in _keys_cache:
        return _keys_cache[path]
    keys = set()
    try:
        with open(path, "r", encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                keys.add(_key_of(r, time_col, key_cols))
    except Exception as e:
        print(f"[CSV] ⚠️ 기존 파일 읽기 실패({path}): {e}")
    _keys_cache[path] = keys
    return keys


def append_rows(rows: list[dict], cfg: dict | None = None) -> dict:
    """수집한 행을 날짜별 CSV 에 한 줄씩 추가. 이미 있는 시각은 건너뛴다.

    반환 {"written": n, "skipped": n, "files": [...]}
    """
    cfg = cfg or load_config()
    if not rows:
        return {"written": 0, "skipped": 0, "files": []}

    sc = cfg.get("storage", {})
    time_col = cfg.get("amos", {}).get("base_time_col", "datetime")
    key_cols = sc.get("dedupe_cols", ["hot_area"])

    written = skipped = failed = 0
    files: set[str] = set()

    with _lock:
        for row in rows:
            day = _day_of(row, time_col)
            path = day_path(day, cfg)
            keys = _load_keys(day, path, time_col, key_cols)
            k = _key_of(row, time_col, key_cols)
            if k in keys:
                skipped += 1
                continue

            # 헤더는 파일당 한 번만 정하고 이후 그 순서를 그대로 따른다.
            # (행마다 키 순서가 달라도 컬럼이 밀리지 않게)
            fields = _fields(path, row)
            new_file = not os.path.isfile(path) or os.path.getsize(path) == 0
            try:
                with open(path, "a", encoding="utf-8-sig", newline="") as f:
                    w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
                    if new_file:
                        w.writeheader()
                    w.writerow(row)
            except Exception as e:
                print(f"[CSV] ❌ 쓰기 실패({path}): {e}")
                failed += 1
                continue

            keys.add(k)
            written += 1
            files.add(path)

    out = {"written": written, "skipped": skipped,
           "files": sorted(os.path.basename(p) for p in files)}
    if failed:
        out["failed"] = failed
    return out


_fields_cache: dict[str, list] = {}


def _fields(path: str, row: dict) -> list:
    """그 파일의 컬럼 순서. 기존 파일이 있으면 그 헤더를 그대로 쓴다.

    ★행에 파일 헤더에 없는 컬럼이 있으면 **파일을 넓혀서 다시 쓴다**.
      예전엔 헤더를 그대로 두고 DictWriter(extrasaction="ignore") 로 썼는데,
      그러면 새 컬럼이 **아무 말 없이 버려진다**. 실제로 데이터 출처가
      로그프레소(90컬럼) → 주피터 CSV(143컬럼) 로 바뀌던 날, 그날 파일이
      이미 90컬럼으로 만들어져 있으면 룰별 점수(*_pts_*) 45개가 통째로
      사라졌다. 관제 데이터가 소리 없이 없어지는 건 최악이다.
    """
    fields = _fields_cache.get(path)
    if fields is None:
        if os.path.isfile(path) and os.path.getsize(path) > 0:
            try:
                with open(path, "r", encoding="utf-8-sig", newline="") as f:
                    fields = next(csv.reader(f), None)
            except Exception:
                fields = None
        if not fields:
            fields = list(row.keys())
        _fields_cache[path] = fields

    extra = [k for k in row.keys() if k not in fields]
    if extra:
        fields = _widen(path, fields, extra)
    return fields


def _widen(path: str, fields: list, extra: list) -> list:
    """헤더에 없던 컬럼이 생겼다 — 파일을 새 헤더로 다시 쓴다.

    기존 행은 새 컬럼이 빈 값으로 채워진다. 원자적으로 교체하므로
    중간에 죽어도 원본이 남는다.
    """
    new_fields = list(fields) + [k for k in extra if k not in fields]
    if not (os.path.isfile(path) and os.path.getsize(path) > 0):
        _fields_cache[path] = new_fields
        return new_fields
    tmp = path + ".widen.tmp"
    try:
        with open(path, "r", encoding="utf-8-sig", newline="") as fr, \
                open(tmp, "w", encoding="utf-8-sig", newline="") as fw:
            w = csv.DictWriter(fw, fieldnames=new_fields, extrasaction="ignore")
            w.writeheader()
            for r in csv.DictReader(fr):
                w.writerow({k: r.get(k, "") for k in new_fields})
        os.replace(tmp, path)
        print(f"[CSV] 🔧 컬럼 확장 {len(fields)}→{len(new_fields)}개 "
              f"({os.path.basename(path)}) — 새 컬럼 {len(extra)}개 "
              f"{', '.join(extra[:4])}{'…' if len(extra) > 4 else ''}")
    except Exception as e:
        print(f"[CSV] ⚠️ 컬럼 확장 실패({path}): {e} — 기존 헤더로 계속")
        try:
            os.remove(tmp)
        except OSError:
            pass
        return fields
    _fields_cache[path] = new_fields
    return new_fields


# 읽어 둔 날짜 CSV — {경로: (mtime_ns, size, rows)}
# ★화면이 3초마다 /api/feed 를 부르고 그때마다 하루치를 통째로 다시 읽었다.
#   현장에서 이 읽기가 30초씩 걸려(디스크·백신·네트워크 드라이브) 요청이
#   줄줄이 밀렸다 — "데이터가 안 뜬다"·"저장이 오래 걸린다" 의 진짜 원인.
#   파일이 안 바뀌었으면 다시 읽지 않는다. 바뀌면(수집이 한 줄 쓰면)
#   mtime·크기가 달라지므로 저절로 새로 읽는다 — 오래된 값을 볼 일이 없다.
_day_cache: dict[str, tuple] = {}
_DAY_CACHE_MAX = 4          # 오늘 + 최근 몇 개면 충분 (메모리 보호)


def read_day(day: str, cfg: dict | None = None) -> list[dict]:
    """날짜 CSV 전체 읽기. '2026-07-27' / '20260727' 모두 허용.

    같은 파일을 다시 읽지 않는다 (mtime·크기가 같으면 캐시).
    """
    day = "".join(ch for ch in str(day) if ch.isdigit())[:8]
    path = day_path(day, cfg)
    try:
        st = os.stat(path)
    except OSError:
        _day_cache.pop(path, None)
        return []
    sig = (st.st_mtime_ns, st.st_size)
    hit = _day_cache.get(path)
    if hit and hit[0] == sig[0] and hit[1] == sig[1]:
        return hit[2]
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        rows = [dict(r) for r in csv.DictReader(f)]
    if len(_day_cache) >= _DAY_CACHE_MAX:
        _day_cache.pop(next(iter(_day_cache)), None)
    _day_cache[path] = (sig[0], sig[1], rows)
    return rows


def read_range(from_dt: str, to_dt: str, cfg: dict | None = None) -> list[dict]:
    """구간(yyyyMMddHHmmss) 에 걸친 날짜 파일들을 읽어 합친다."""
    cfg = cfg or load_config()
    time_col = cfg.get("amos", {}).get("base_time_col", "datetime")
    f8, t8 = from_dt[:8], to_dt[:8]

    out: list[dict] = []
    for day in sorted({p[:8] for p in _days_between(f8, t8)}):
        out.extend(read_day(day, cfg))

    def stamp(r):
        return "".join(ch for ch in str(r.get(time_col) or "") if ch.isdigit())[:14]

    out = [r for r in out if from_dt[:14] <= stamp(r) <= to_dt[:14]]
    out.sort(key=stamp)
    return out


def _days_between(f8: str, t8: str) -> list[str]:
    from datetime import timedelta
    try:
        a, b = datetime.strptime(f8, "%Y%m%d"), datetime.strptime(t8, "%Y%m%d")
    except ValueError:
        return [f8]
    days, cur = [], a
    while cur <= b:
        days.append(cur.strftime("%Y%m%d"))
        cur += timedelta(days=1)
    return days


def last_time(day: str, cfg: dict | None = None) -> datetime | None:
    """그 날 파일에 저장된 가장 늦은 시각. 없으면 None."""
    cfg = cfg or load_config()
    time_col = cfg.get("amos", {}).get("base_time_col", "datetime")
    newest = None
    for r in read_day(day, cfg):
        d = "".join(ch for ch in str(r.get(time_col) or "") if ch.isdigit())[:14]
        if len(d) < 12:
            continue
        try:
            t = datetime.strptime(d.ljust(14, "0"), "%Y%m%d%H%M%S")
        except ValueError:
            continue
        if newest is None or t > newest:
            newest = t
    return newest


# ─────────────────── LLM 판단 CSV (1분 1행, 판정은 나중에 채워짐) ───────────────────
# data/20260729_LLM.CSV — 열어보면 바로 읽히도록 컬럼명을 한글로 둔다.
# 'datetime' 만 영문인데, TOTAL.CSV 와 이 열로 조인하기 때문이다.
#
#   datetime   그 분 (TOTAL.CSV 와 같은 키)
#   스코어/등급/구역   그 분 상태
#   실제이상   LLM 판단 — 지금 대응이 필요한 진짜 이상인가 (예/아니오)  ★채점 대상
#   확신도     LLM 확신도 0~100
#   판단/근거/조치     LLM 이 쓴 문장 (정상 구간은 '판단' 한 줄만)
#   판정       사후검증 결과 — 적중/과다탐지/누락/조치효과, 사람이 누르면 정탐/오탐
#   판정시각/판정근거  왜 그렇게 판정했는지
#   추론깊이   간단(정상 구간) / 상세(경계 이상)
LLM_FIELDS = [
    "datetime", "스코어", "등급", "구역",
    "실제이상", "확신도", "판단", "근거", "조치",
    "판정", "판정시각", "판정근거",
    "모델", "추론깊이", "소요ms", "오류",
]
_llm_lock = threading.Lock()


def llm_suffix(cfg: dict | None = None) -> str:
    cfg = cfg or load_config()
    return (cfg.get("llm", {}).get("per_minute", {}) or {}).get("csv_suffix", "_LLM")


def llm_path(day: str, cfg: dict | None = None) -> str:
    """'20260729' → data/20260729_LLM.CSV"""
    day = "".join(ch for ch in str(day) if ch.isdigit())[:8]
    return os.path.join(data_dir(cfg), f"{day}{llm_suffix(cfg)}.CSV")


def read_llm_day(day: str, cfg: dict | None = None) -> list[dict]:
    p = llm_path(day, cfg)
    if not os.path.isfile(p):
        return []
    try:
        with open(p, "r", encoding="utf-8-sig", newline="") as f:
            return [dict(r) for r in csv.DictReader(f)]
    except Exception as e:
        print(f"[LLM CSV] ⚠️ 읽기 실패({p}): {e}")
        return []


def llm_minutes(day: str, cfg: dict | None = None) -> set:
    """그 날 이미 추론을 남긴 분(datetime) 집합 — 중복 호출 방지."""
    return {(r.get("datetime") or "").strip() for r in read_llm_day(day, cfg)}


def upsert_llm_rows(rows: list[dict], cfg: dict | None = None) -> dict:
    """LLM 판단 행을 datetime 기준으로 추가하거나 갱신한다.

    판정(적중/과다탐지…)은 검증 창이 찬 뒤에 같은 행에 채워 넣어야 하므로
    append 가 아니라 upsert 다. 하루 1440행이라 통째로 다시 써도 부담 없다.
    """
    if not rows:
        return {"written": 0, "updated": 0, "files": []}
    cfg = cfg or load_config()
    written = updated = 0
    files: set[str] = set()

    with _llm_lock:
        by_day: dict[str, list[dict]] = {}
        for r in rows:
            by_day.setdefault(_day_of(r, "datetime"), []).append(r)

        for day, new_rows in by_day.items():
            cur = {(r.get("datetime") or "").strip(): r for r in read_llm_day(day, cfg)}
            for r in new_rows:
                k = (r.get("datetime") or "").strip()
                if not k:
                    continue
                if k in cur:
                    cur[k].update({f: v for f, v in r.items() if v not in (None, "")})
                    updated += 1
                else:
                    cur[k] = {f: r.get(f, "") for f in LLM_FIELDS}
                    written += 1
            p = llm_path(day, cfg)
            tmp = p + f".tmp{os.getpid()}"
            try:
                with open(tmp, "w", encoding="utf-8-sig", newline="") as f:
                    w = csv.DictWriter(f, fieldnames=LLM_FIELDS, extrasaction="ignore")
                    w.writeheader()
                    for k in sorted(cur):
                        w.writerow({f: cur[k].get(f, "") for f in LLM_FIELDS})
                os.replace(tmp, p)
                files.add(os.path.basename(p))
            except Exception as e:
                print(f"[LLM CSV] ❌ 쓰기 실패({p}): {e}")
                try:
                    os.remove(tmp)
                except OSError:
                    pass
    return {"written": written, "updated": updated, "files": sorted(files)}


# 날짜 목록의 줄 수 — {경로: (mtime_ns, size, 줄 수)}
# ★list_days 는 부를 때마다 **모든 날짜 파일을 처음부터 끝까지 읽어** 줄 수를
#   셌다. UI대쉬보드 한 화면이 30초마다 6번(패널 1 + 오른쪽 상황판 5) 부르니,
#   날짜가 쌓일수록 느려졌다 — 재 보니 180일치에서 상황판 한 번에 2.4초, 그동안
#   다른 요청도 같이 밀렸다 (고객: "파일을 전에 것까지 같이 읽어 들이나 보네.
#   그래서 느리네").
# ★파일이 안 바뀌었으면(크기·수정 시각 그대로) 세어 둔 줄 수를 쓴다. 오늘 파일처럼
#   바뀐 것만 다시 센다 → 180일치에서도 0.005초. 목록·줄 수는 전과 똑같다.
# ★과거 날짜를 여는 read_day 는 그대로다 — 과거 데이터 조회는 전과 같다
#   (고객: "과거 파일 읽어 들이는 부분은 그대로 하자"). 이 고침은 데이터를 지우지 않는다.
_rows_cache: dict[str, tuple] = {}


def list_days(cfg: dict | None = None) -> list[dict]:
    """저장된 날짜 파일 목록 (최신순)."""
    d = data_dir(cfg)
    out = []
    for fn in sorted(os.listdir(d), reverse=True):
        if fn.upper().endswith("_TOTAL.CSV"):
            p = os.path.join(d, fn)
            try:
                st = os.stat(p)
            except OSError:
                continue                    # 목록을 읽는 사이에 없어졌다
            hit = _rows_cache.get(p)
            if hit and hit[0] == st.st_mtime_ns and hit[1] == st.st_size:
                n = hit[2]
            else:
                try:
                    with open(p, "r", encoding="utf-8-sig") as f:
                        n = max(0, sum(1 for _ in f) - 1)
                    _rows_cache[p] = (st.st_mtime_ns, st.st_size, n)
                except Exception:
                    n = 0                   # ★못 읽은 것은 기억하지 않는다 — 다음에 다시 센다
            out.append({"day": fn[:8], "file": fn, "rows": n, "bytes": st.st_size})
    return out


# ★list_days 는 **최신순**이다. 그래서 [-1] 은 '가장 오래된 날' 이다.
#   실제로 여러 곳이 [-1] 을 '최신' 인 줄 알고 써서, 8월 25일에 7월 28일
#   데이터를 '현재 상태' 로 보여 주고 있었다 (파일이 0728·0819 두 개였다).
#   다시는 헷갈리지 않게 이름을 붙여 둔다 — 순서를 몰라도 되게.
def latest_day(cfg: dict | None = None) -> str | None:
    """확보된 가장 **최근** 날짜 (없으면 None).

    ★행이 없는 파일은 건너뛴다. 수집이 막 시작돼 머리글만 있는 파일이
      '최신' 이 되면, 볼 게 있는 어제를 두고 빈 오늘을 골라 버린다.
    """
    d = [x for x in list_days(cfg) if x["rows"] > 0]
    return d[0]["day"] if d else None


def recent_days(limit: int, cfg: dict | None = None) -> list[str]:
    """최근 limit 일 — **오래된 날부터** 늘어놓는다 (그래야 그래프·추이가 맞다)."""
    d = [x["day"] for x in list_days(cfg)]     # 최신순
    return list(reversed(d[:max(0, int(limit))]))



# ─────────────────────── 과거 파일 정리 (보관 기간) ───────────────────────
# 고객: "주기적으로 데이터 삭제 필요하네" · "정책에서 과거 파일 정리 기간 해주라"
#       · "설정할수 있게".
# ★지우는 것은 **이름에 날짜가 박힌 파일**뿐이다 —
#     {날짜}_TOTAL.CSV (원본) · {날짜}_LLM.CSV (LLM 판단) · {날짜}_ML.CSV (ML)
#     raw/{날짜}_*.csv (주피터에서 받은 원본 그대로)
#   케이스(cases.json)·리포트·분석·피드백·설정은 건드리지 않는다.
# ★보관 기간 N일 = 오늘을 포함해 N일을 남긴다 (30 → 오늘과 그 앞 29일).
#   0 이하면 아무것도 안 지운다 — 기본값이다. 설정하기 전에는 안 지운다.
# ★이름의 날짜가 달력에 없는 날(예: 20261399)이면 모르는 파일로 보고 그대로 둔다.
_DATED_TOP = re.compile(r"^(\d{8})(_[^.\\/]+)\.CSV$", re.I)
_DATED_RAW = re.compile(r"^(\d{8})_[^\\/]*\.CSV$", re.I)


def _dated_files(cfg: dict | None = None) -> list[tuple]:
    """정리 대상이 될 수 있는 날짜 파일 [(날짜, 경로, 크기), …].

    ★폴더를 만들지 않는다 — 수집을 안 하는 FAB 의 빈 폴더가 생기면 안 된다.
    """
    cfg = cfg or load_config()
    d = _dir_of(cfg)
    kinds = {"_TOTAL", "_ML", llm_suffix(cfg).upper()}
    out = []
    for sub, pat in (("", _DATED_TOP), ("raw", _DATED_RAW)):
        folder = os.path.join(d, sub) if sub else d
        try:
            ents = list(os.scandir(folder))
        except OSError:
            continue                            # raw 폴더가 없는 시스템도 있다
        for ent in ents:
            m = pat.match(ent.name)
            if not m or (not sub and m.group(2).upper() not in kinds):
                continue
            try:
                datetime.strptime(m.group(1), "%Y%m%d")
                if not ent.is_file():
                    continue
                size = ent.stat().st_size
            except (ValueError, OSError):
                continue
            out.append((m.group(1), ent.path, size))
    return out


def keep_from(keep_days: int, today: datetime | None = None) -> str:
    """보관 기간 N일이면 남기는 첫 날 (yyyymmdd) — 이 날보다 앞선 날을 지운다."""
    t = today or datetime.now()
    return (t - timedelta(days=max(1, int(keep_days)) - 1)).strftime("%Y%m%d")


def usage(cfg: dict | None = None) -> dict:
    """지금 쌓인 날짜 파일 → {files, bytes, days, oldest, day_list}."""
    fs = _dated_files(cfg)
    days = sorted({d for d, _p, _s in fs})
    return {"files": len(fs), "bytes": sum(s for _d, _p, s in fs),
            "days": len(days), "oldest": days[0] if days else None,
            "day_list": days}


def prune_days(keep_days: int, cfg: dict | None = None, dry_run: bool = False,
               today: datetime | None = None) -> dict:
    """보관 기간을 넘긴 날짜 파일을 지운다.

    → {files, bytes, days, first, last, keep_from, failed, errors, day_list}
    dry_run=True 면 지울 것을 세기만 한다 (정책 화면의 '이 기간이면 지울 것').
    못 지운 파일(잠김·권한)은 건너뛰고 errors 에 적는다 — 다음 정리 때 또 해 본다.
    """
    out = {"files": 0, "bytes": 0, "days": 0, "first": None, "last": None,
           "keep_from": None, "failed": 0, "errors": [], "day_list": []}
    try:
        keep = int(keep_days)
    except (TypeError, ValueError):
        keep = 0
    if keep <= 0:
        return out
    cut = keep_from(keep, today)
    out["keep_from"] = cut
    days = set()
    for day, p, size in _dated_files(cfg):
        if day >= cut:
            continue
        if not dry_run:
            try:
                with _lock:
                    os.remove(p)
                    # ★지운 파일을 기억에서도 뺀다 — 안 빼면 같은 날을 다시 받을 때
                    #   '이미 쓴 줄' 로 착각하거나, 목록에 옛 줄 수가 남는다.
                    for c in (_rows_cache, _day_cache, _keys_cache, _fields_cache):
                        c.pop(p, None)
            except OSError as e:
                out["failed"] += 1
                if len(out["errors"]) < 20:
                    out["errors"].append(f"{os.path.basename(p)}: {type(e).__name__}: {e}")
                continue
        out["files"] += 1
        out["bytes"] += size
        days.add(day)
    if days:
        out["day_list"] = sorted(days)
        out["days"], out["first"], out["last"] = len(days), min(days), max(days)
    return out

if __name__ == "__main__":
    cfg = load_config()
    print(f"저장 위치: {data_dir(cfg)}")
    for d in list_days(cfg):
        print(f"  {d['file']}  {d['rows']:>6}행  {d['bytes']/1024:.1f}KB")
