#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
OHT_50s_수집기.py — M16HUB OHT 50초 집계 실시간 수집기 (oht_50s 만)

50초마다 로그프레소에서 **방금 끝난 50초 구간**을 받아
  oht_50s/OHT50_YYYYMMDD.csv   (시각, 보고차량, {FAB}_OHT_missing, {FAB}_OHT_JAM, {FAB}_OHT_HT_STOP)
에 한 줄씩 이어 쓴다. OHT_추출.py 와 같은 쿼리 · 같은 CSV 형식이다.

  쿼리  remote icamcslogdt01 [ table from=… to=… oht_data_m16br
          | search MSG_ID == "2" | fields _time, VEHICLE, STATUS
          | eval _time = datetrunc(_time, "50s")
          | stats first(STATUS) as STATUS, last(STATUS) as STATUS_LAST by VEHICLE, _time ]
  {FAB}_OHT_missing = 미보고 = FLEET_SIZE(270) − 그 50초 안에 보고한 차량 수
  {FAB}_OHT_JAM     = 그 50초 안에 STATUS 7 이 있었던 차량 수
  {FAB}_OHT_HT_STOP = 그 50초 안에 STATUS 8 이 있었던 차량 수

실행
  python OHT_50s_수집기.py              계속 돈다 (Ctrl+C 로 멈춤)
  python OHT_50s_수집기.py --once       한 번만 받고 끝
  python OHT_50s_수집기.py --test       연결 확인 (최근 구간 5줄)

· 처음 켜면 최근 BACKFILL_MIN(10분)을 먼저 채운다 — 과거 10분 판정이 바로 되게.
· 다시 켜면 오늘 파일의 마지막 시각 다음부터 이어 받는다 (빈 구간 없이, 중복 없이).
· 로그프레소 적재가 늦게 들어오는 것을 감안해 LAG_SEC(30초) 지난 구간만 받는다.
· 조회가 실패해도 멈추지 않는다 — 다음 사이클에 빠진 구간까지 같이 받는다.
"""
import argparse
import csv
import io
import logging
import os
import sys
import time
import urllib.parse
from collections import defaultdict
from datetime import datetime, timedelta

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
HERE = os.path.dirname(os.path.abspath(__file__))

# ───────────────────────────────────────────────────────────
# 접속 설정 — 직접 넣는다
# ───────────────────────────────────────────────────────────
HOST        = "10.40.42.27"
PORT        = 8888
API_KEY     = ""                  # ★키 (비우면 환경변수 LP_API_KEY → 같은 폴더 api_key.txt)
REMOTE_NODE = "icamcslogdt01"     # 비우면 remote 로 감싸지 않음
TABLE       = "oht_data_m16br"    # ★M16HUB OHT 테이블

# ───────────────────────────────────────────────────────────
# 수집 설정
# ───────────────────────────────────────────────────────────
FAB            = "M16HUB" # 컬럼 이름 앞머리 — {FAB}_OHT_missing · {FAB}_OHT_JAM · {FAB}_OHT_HT_STOP
BUCKET_SEC     = 50       # ★50초 집계
FLEET_SIZE     = 270      # M16HUB 전체 차량 수
VEHICLE_PREFIX = "BV"     # M16HUB 차량 (BV0001~)
LAG_SEC        = 30       # 구간이 끝나고 이만큼 지난 뒤에 받는다 (로그프레소 적재 지연)
BACKFILL_MIN   = 10       # 처음 켤 때 채울 과거 분
MAX_CATCHUP_MIN = 120     # 오래 멈췄다 켜도 이보다 오래된 구간은 안 받는다
HTTP_TIMEOUT   = 120
OUT_DIR        = os.path.join(HERE, "oht_50s")
LOG_FILE       = os.path.join(HERE, "OHT_50s_수집기.log")

FMT = "%Y%m%d%H%M%S"
HEADER = ["시각", "보고차량", f"{FAB}_OHT_missing", f"{FAB}_OHT_JAM", f"{FAB}_OHT_HT_STOP"]
EPOCH_KST = datetime(1970, 1, 1, 9, 0, 0)     # datetrunc(_time, "50s") 와 같은 기준

log = logging.getLogger("OHT50")
log.setLevel(logging.INFO)
if not log.handlers:
    fmt = logging.Formatter("%(asctime)s [OHT50] %(message)s")
    for h in (logging.StreamHandler(), logging.FileHandler(LOG_FILE, encoding="utf-8")):
        h.setFormatter(fmt)
        log.addHandler(h)


# ───────────────────────────────────────────────────────────
def load_key():
    global API_KEY
    if API_KEY:
        return
    API_KEY = os.environ.get("LP_API_KEY", "").strip()
    if not API_KEY:
        for base in (HERE, os.getcwd()):
            p = os.path.join(base, "api_key.txt")
            if os.path.exists(p):
                with open(p, encoding="utf-8-sig") as f:
                    lines = f.read().strip().splitlines()
                    API_KEY = lines[0].strip() if lines else ""
                break
    if not API_KEY:
        sys.exit("API 키가 없습니다 — 파일 위 API_KEY, 환경변수 LP_API_KEY, 또는 api_key.txt")


def bucket_floor(t):
    """t 가 속한 50초 구간의 시작 (datetrunc 50s 와 같은 경계)"""
    sec = int((t - EPOCH_KST).total_seconds()) // BUCKET_SEC * BUCKET_SEC
    return EPOCH_KST + timedelta(seconds=sec)


def build_query(frm, to):
    inner = (
        f'table from={frm.strftime(FMT)} to={to.strftime(FMT)} {TABLE}'
        ' | search MSG_ID == "2"'
        ' | fields _time, VEHICLE, STATUS'
        f' | eval _time = datetrunc(_time, "{BUCKET_SEC}s")'
        ' | stats first(STATUS) as STATUS, last(STATUS) as STATUS_LAST by VEHICLE, _time'
    )
    return f"remote {REMOTE_NODE} [ {inner} ]" if REMOTE_NODE else inner


def http_get(q):
    url = (f"http://{HOST}:{PORT}/logpresso/httpexport/query.csv"
           f"?_apikey={API_KEY}&_q={urllib.parse.quote(q, safe='')}")
    r = requests.get(url, verify=False, timeout=HTTP_TIMEOUT)
    if r.status_code == 401:
        raise RuntimeError(f"401 인증 실패 — 주소 {HOST}:{PORT} 와 키 확인 (키 끝 4자 …{API_KEY[-4:]})")
    if r.status_code != 200 or r.text.lstrip().startswith("<"):
        raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")
    return r.content


def parse_time(s):
    s = (s or "").strip().strip('"')[:19]
    for f in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            return datetime.strptime(s, f)
        except ValueError:
            pass
    return None


def aggregate(body, frm, to):
    """조회 결과 → [(구간시각, 보고, 미보고, JAM, HT)]. 결과가 없는 구간도 한 줄 (보고 0)."""
    rep, jam, ht = defaultdict(set), defaultdict(set), defaultdict(set)
    for r in csv.DictReader(io.StringIO(body.decode("utf-8-sig", "replace"))):
        v = (r.get("VEHICLE") or "").strip()
        if not v or (VEHICLE_PREFIX and not v.startswith(VEHICLE_PREFIX)):
            continue
        t = parse_time(r.get("_time"))
        if not t:
            continue
        b = bucket_floor(t)
        sts = {(r.get("STATUS") or "").strip(), (r.get("STATUS_LAST") or "").strip()}
        rep[b].add(v)
        if "7" in sts:
            jam[b].add(v)
        if "8" in sts:
            ht[b].add(v)
    rows = []
    b = frm
    while b < to:
        n = len(rep[b])
        rows.append((b, n, max(0, FLEET_SIZE - n), len(jam[b]), len(ht[b])))
        b += timedelta(seconds=BUCKET_SEC)
    return rows


def day_file(t):
    return os.path.join(OUT_DIR, f"OHT50_{t:%Y%m%d}.csv")


def last_saved(now):
    """오늘(없으면 어제) 파일의 마지막 구간 시각"""
    for d in (now, now - timedelta(days=1)):
        p = day_file(d)
        if not os.path.exists(p):
            continue
        last = None
        with open(p, encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                last = r.get("시각") or last
        if last:
            return parse_time(last)
    return None


def append_rows(rows):
    os.makedirs(OUT_DIR, exist_ok=True)
    by_day = defaultdict(list)
    for r in rows:
        by_day[day_file(r[0])].append(r)
    for p, rs in by_day.items():
        if os.path.exists(p):                      # 예전 컬럼 이름으로 된 파일이면 옆으로 옮기고 새로 시작
            with open(p, encoding="utf-8-sig") as f:
                head = f.readline().strip().split(",")
            if head != HEADER:
                old = p.replace(".csv", "_예전컬럼.csv")
                os.replace(p, old)
                log.info(f"컬럼 이름이 달라 옮김 → {old}")
        new = not os.path.exists(p)
        with open(p, "a", encoding="utf-8-sig" if new else "utf-8", newline="") as f:
            w = csv.writer(f)
            if new:
                w.writerow(HEADER)
            for b, n, m, j, h in rs:
                w.writerow([b.strftime("%Y-%m-%d %H:%M:%S"), n, m, j, h])


def cycle(now=None):
    """받을 구간을 계산해 받고 저장. 저장한 줄 수를 돌려준다."""
    now = now or datetime.now()
    end = bucket_floor(now - timedelta(seconds=LAG_SEC))          # 여기 전까지 끝난 구간만
    last = last_saved(now)
    start = (last + timedelta(seconds=BUCKET_SEC)) if last else bucket_floor(now - timedelta(minutes=BACKFILL_MIN))
    start = max(start, bucket_floor(now - timedelta(minutes=MAX_CATCHUP_MIN)))
    if start >= end:
        return 0
    body = http_get(build_query(start, end))
    rows = aggregate(body, start, end)
    append_rows(rows)
    b, n, m, j, h = rows[-1]
    log.info(f"{start:%H:%M:%S}~{end:%H:%M:%S} {len(rows)}구간 저장 · 마지막 {b:%H:%M:%S} "
             f"보고 {n} · {FAB}_OHT_missing {m} · {FAB}_OHT_JAM {j} · {FAB}_OHT_HT_STOP {h}")
    return len(rows)


def main():
    ap = argparse.ArgumentParser(description="M16HUB OHT 50초 집계 실시간 수집기")
    ap.add_argument("--once", action="store_true", help="한 번만 받고 끝")
    ap.add_argument("--test", action="store_true", help="연결 확인 (5줄)")
    a = ap.parse_args()
    load_key()
    log.info(f"시작 — {HOST}:{PORT} remote={REMOTE_NODE or '(없음)'} 테이블 {TABLE} · "
             f"{BUCKET_SEC}초 · 전체 {FLEET_SIZE}대 · 저장 {OUT_DIR}")

    if a.test:
        t = bucket_floor(datetime.now() - timedelta(minutes=2))
        q = build_query(t, t + timedelta(seconds=BUCKET_SEC)) + ""
        q = q.replace(" by VEHICLE, _time", " by VEHICLE, _time | limit 5")
        print("[Q]", q)
        print(http_get(q).decode("utf-8", "replace")[:1500])
        print("↑ VEHICLE, _time, STATUS, STATUS_LAST 가 보이면 정상")
        return
    if a.once:
        cycle()
        return

    while True:
        try:
            cycle()
        except KeyboardInterrupt:
            raise
        except Exception as e:                       # 멈추지 않는다 — 다음 사이클에 이어 받는다
            log.warning(f"조회 실패 — 다음 사이클에 다시: {e}")
        # 다음 구간 경계 + LAG 까지 잔다
        now = datetime.now()
        nxt = bucket_floor(now - timedelta(seconds=LAG_SEC)) + timedelta(seconds=BUCKET_SEC + LAG_SEC)
        time.sleep(max(5.0, (nxt - now).total_seconds() + 1))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log.info("멈춤 (Ctrl+C)")
