# -*- coding: utf-8 -*-
"""
LO_진단.py — 로그프레소 AMHS_SCORE 적재 실패(HTTP 500) 원인 가르기

Rule_LO.py 옆(config.json · api_key.txt 있는 곳)에서 실행:
    python LO_진단.py            읽기만 한다 (데이터 안 넣음)
    python LO_진단.py --write    AMHS_SCORE 에 fab_name='DIAG_TEST' 한 줄을 시험으로 넣어본다

키 값은 화면에 절대 안 찍는다.
"""
import json
import os
import re
import sys
import urllib.parse

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
HERE = os.path.dirname(os.path.abspath(__file__))


def read_json(name):
    p = os.path.join(HERE, name)
    if not os.path.exists(p):
        return {}
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def read_key(name):
    p = os.path.join(HERE, name)
    if not os.path.exists(p):
        return ""
    with open(p, encoding="utf-8") as f:
        lines = f.read().strip().splitlines()
    return lines[0].strip() if lines else ""


def text_of(body):
    """HTML 이면 태그를 벗겨 글자만 남긴다."""
    if body.lstrip().startswith("<"):
        body = re.sub(r"(?is)<(script|style).*?</\1>", " ", body)
        body = re.sub(r"(?s)<[^>]+>", " ", body)
    return re.sub(r"\s+", " ", body).strip()


def run(base, path, key, q):
    url = base.rstrip("/") + path
    full = f"{url}?_apikey={key}&_q={urllib.parse.quote(' '.join(q.split()), safe='')}"
    try:
        r = requests.get(full, verify=False, timeout=30)
    except Exception as e:
        return None, f"접속 실패 — {type(e).__name__}: {e}"
    body = r.text or ""
    html = body.lstrip().startswith("<")
    return r.status_code, ("[HTML 페이지] " if html else "") + text_of(body)[:300]


def main():
    write = "--write" in sys.argv
    cfg = read_json("config.json")
    base = cfg.get("logpresso_base", "")
    path = cfg.get("_endpoints", {}).get("insert", "/httpexport/query.csv")
    t_old = cfg.get("table_name", "test_table3")
    t_new = cfg.get("amhs_table_name", "AMHS_SCORE")
    kf = cfg.get("api_key_file", "api_key.txt")
    kf2 = cfg.get("amhs_api_key_file", "api_key_amhs.txt")
    keys = [(kf, read_key(kf))]
    if read_key(kf2):
        keys.append((kf2, read_key(kf2)))

    print("=" * 70)
    print("로그프레소 :", base + path)
    print("enabled    :", cfg.get("enabled"))
    for nm, k in keys:
        print("키 파일    : %s  (%s)" % (nm, "있음 %d자" % len(k) if k else "없음/비어있음"))
    print("=" * 70)
    if not base:
        print("config.json 에 logpresso_base 가 없습니다.")
        return

    tests = [
        ("① 기존 테이블 읽기", f"table {t_old} | limit 1"),
        ("② 새 테이블 읽기", f"table {t_new} | limit 1"),
        ("③ 테이블 목록", "system tables"),
    ]
    if write:
        tests.append(("④ 새 테이블에 시험 1줄 쓰기",
                      f'json "{{datetime = \'2000-01-01 00:00\', fab_name = \'DIAG_TEST\', '
                      f'area_score = \'0\', area_score_raw = \'0\'}}" | import {t_new}'))

    for nm, k in keys:
        if not k:
            continue
        print("\n■ 키: %s" % nm)
        for title, q in tests:
            st, msg = run(base, path, k, q)
            ok = st == 200 and not msg.startswith("[HTML")
            print("  %-26s HTTP %-4s %s" % (title, st, "성공" if ok else "실패"))
            if title.startswith("③") and ok:
                for t in (t_old, t_new):
                    print("      %-14s 목록에 %s" % (t, "있음" if t in msg else "없음"))
            elif not ok:
                print("      응답:", msg[:200])

    print("\n" + "=" * 70)
    print("읽는 법")
    print("  ① 실패         → 키 또는 주소 자체 문제 (AMHS 와 무관)")
    print("  ① 성공 ② 실패  → ③ 목록에 새 테이블이 없으면: 테이블 미생성")
    print("                   ③ 목록에 있는데 ② 실패면: 이 키에 새 테이블 권한 없음")
    print("  ② 성공 ④ 실패  → 읽기 권한만 있고 쓰기 권한 없음")
    print("  권한 있는 키를 받으면 api_key_amhs.txt 에 넣으면 Rule_LO 가 AMHS 에 그 키를 쓴다")
    if not write:
        print("  쓰기까지 보려면: python LO_진단.py --write  (fab_name='DIAG_TEST' 1줄 들어감)")


if __name__ == "__main__":
    main()
