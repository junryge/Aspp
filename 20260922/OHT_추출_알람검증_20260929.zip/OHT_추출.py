# -*- coding: utf-8 -*-
"""
OHT_추출.py — 날짜를 주면 로그프레소에서 OHT 를 뽑아 CSV 로 저장

설정(주소 · API 키 · 테이블 · 쿼리)은 같은 폴더 OHT_알람검증.py 맨 위 설정 칸을 그대로 쓴다.

명령어
  python OHT_추출.py 20260929                                  하루
  python OHT_추출.py 20260901 20260929                         기간 (시작일 ~ 끝일, 끝일 포함)
  python OHT_추출.py --from "2026-09-29 07:00" --to "2026-09-29 08:50"   시각 지정
  python OHT_추출.py 20260901 20260929 --no-raw                원본은 지우고 50초 집계만 남김 (용량 절약)

저장
  oht_raw/OHT_YYYYMMDD_HHMM.csv   원본 (VEHICLE, _time, STATUS) — 1시간 단위 조각
  oht_50s/OHT50_YYYYMMDD.csv      50초 집계 (시각, 보고차량, 미보고, JAM, HT_STOP) — 하루 1개

· 중간에 끊겨도 다시 실행하면 이미 받은 조각은 건너뛴다
· 한 조각이 너무 오래 걸리면 OHT_알람검증.py 의 CHUNK_MIN 을 60 → 30 으로 줄인다
"""
import argparse
import csv
import os
import sys
import time
from datetime import datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import OHT_알람검증 as C   # 설정 · 조회 · 집계 함수 재사용


def parse_args():
    ap = argparse.ArgumentParser(description="OHT 추출 → CSV 저장 (50초 집계 포함)")
    ap.add_argument("start", nargs="?", help="시작일 YYYYMMDD")
    ap.add_argument("end", nargs="?", help="끝일 YYYYMMDD (없으면 시작일 하루)")
    ap.add_argument("--from", dest="frm", help='시작 시각 "YYYY-MM-DD HH:MM"')
    ap.add_argument("--to", dest="to", help='끝 시각 "YYYY-MM-DD HH:MM"')
    ap.add_argument("--raw", default=os.path.join(HERE, "oht_raw"))
    ap.add_argument("--out", default=os.path.join(HERE, "oht_50s"))
    ap.add_argument("--no-raw", action="store_true", help="50초 집계 후 원본 조각 삭제")
    a = ap.parse_args()
    if a.frm and a.to:
        s, e = C.parse_time(a.frm), C.parse_time(a.to)
    elif a.start:
        s = datetime.strptime(a.start, "%Y%m%d")
        e = datetime.strptime(a.end or a.start, "%Y%m%d") + timedelta(days=1)
    else:
        ap.error("날짜를 주세요 — 예: python OHT_추출.py 20260929")
    if not s or not e or s >= e:
        ap.error("시작/끝 시각을 확인하세요")
    return a, s, e


def main():
    a, s, e = parse_args()
    key = C.api_key()
    os.makedirs(a.raw, exist_ok=True)
    os.makedirs(a.out, exist_ok=True)
    print(f"OHT 추출 {s:%Y-%m-%d %H:%M} ~ {e:%Y-%m-%d %H:%M} · 테이블 {C.OHT_TABLE} · "
          f"조각 {C.CHUNK_MIN}분 · 집계 {C.BUCKET_SEC}초")

    day = s.replace(hour=0, minute=0, second=0)
    t_all = time.time()
    while day < e:
        d0, d1 = max(s, day), min(e, day + timedelta(days=1))
        files = []
        t = d0
        while t < d1:
            n = min(d1, t + timedelta(minutes=C.CHUNK_MIN))
            p = os.path.join(a.raw, f"OHT_{t:%Y%m%d_%H%M}.csv")
            files.append(p)
            if not (os.path.exists(p) and os.path.getsize(p) > 0):
                t0 = time.time()
                try:
                    C.fetch(C.build_query(t, n), p, key)
                except Exception as ex:
                    print(f"  ✗ {t:%m-%d %H:%M}~{n:%H:%M} 실패: {ex}")
                    print("    → 다시 실행하면 이어서 받습니다")
                    sys.exit(1)
                print(f"  {t:%m-%d %H:%M}~{n:%H:%M}  {os.path.getsize(p)/1e6:6.1f}MB  {time.time()-t0:5.0f}초")
            t = n

        table, fleet = C.aggregate(files)
        op = os.path.join(a.out, f"OHT50_{day:%Y%m%d}.csv")
        with open(op, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(["시각", "보고차량", "미보고", "JAM", "HT_STOP"])
            for b, v in sorted(table.items()):
                if d0 <= b < d1:
                    w.writerow([b.strftime("%Y-%m-%d %H:%M:%S"), v["rep"], v["miss"], v["jam"], v["ht"]])
        print(f"■ {day:%Y-%m-%d} 저장 → {op}  (50초 구간 {sum(1 for b in table if d0 <= b < d1)}개 · 전체 차량 {fleet}대)")
        if a.no_raw:
            for p in files:
                if os.path.exists(p):
                    os.remove(p)
        day += timedelta(days=1)

    print(f"완료 · {time.time()-t_all:.0f}초")


if __name__ == "__main__":
    main()
