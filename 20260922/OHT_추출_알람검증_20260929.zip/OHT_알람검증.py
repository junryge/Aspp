# -*- coding: utf-8 -*-
"""
OHT_알람검증.py — 스코어 알람이 난 순간, 과거 10분 OHT 로 판정

흐름
  1) 실시간 스코어 CSV 에서 알람 발생 시각을 뽑는다
     (등급이 경계/위험/초위험으로 올라간 순간)
  2) 알람마다 [알람 10분 전 ~ 알람 10분 후] 구간만 로그프레소에서 OHT 를 뽑는다
     (한 달 전체를 뽑지 않는다 — 겹치는 구간은 합쳐서 한 번만 조회)
  3) 50초 단위로 센다: 보고 차량 수 · 미보고 · JAM(STATUS 7) · HT-STOP(STATUS 8)
  4) 알람 시각 기준 과거 10분 OHT 로 판정 → 확정 / 전조 / 관찰

사용
  python OHT_알람검증.py --score 실시간스코어.csv --test      연결·테이블 확인 (5줄만 조회)
  python OHT_알람검증.py --score 실시간스코어.csv --dry-run   조회할 구간·쿼리만 출력
  python OHT_알람검증.py --score 실시간스코어.csv             실행
  python OHT_알람검증.py --score 실시간스코어.csv --truth 실제사건.csv   정답과 비교까지

  · 중간에 끊겨도 다시 실행하면 이미 받은 구간은 건너뛴다 (oht_raw/ 폴더)
  · 스코어 파일은 CSV 또는 노트북(.ipynb 를 txt 로 저장한 것) 둘 다 된다

결과 (out/ 폴더)
  oht_50s.csv      50초 단위 OHT 집계
  알람판정.csv      알람별 과거 10분 OHT 와 판정
  요약.txt          등급 × 판정 건수 (정답을 주면 정밀도까지)
"""
import argparse
import csv
import io
import json
import os
import sys
import time
import urllib.parse
from collections import Counter, defaultdict
from datetime import datetime, timedelta

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ============================================================
# ★ 설정 — 여기만 고치면 된다
# ============================================================
LOGPRESSO_BASE = "http://10.40.42.167:8888/logpresso"   # 로그프레소 주소
API_KEY        = ""                   # 비워두면 같은 폴더 api_key.txt 첫 줄을 읽는다
OHT_TABLE      = "OHT_TABLE_이름"      # ★ OHT 원본 테이블 이름
# 조회 쿼리 — {table} {frm} {to} 는 자동으로 채워진다 (frm/to 형식 yyyyMMddHHmmss)
#   컬럼은 VEHICLE, _time, STATUS 세 개만 있으면 된다
QUERY_TEMPLATE = "table from={frm} to={to} {table} | fields VEHICLE, _time, STATUS"
VEHICLE_PREFIX = "BV"                 # M16HUB 차량만 (BV0001~). 전체면 ""
FLEET_SIZE     = 270                  # M16HUB 전체 차량 수 (9/12 269대 · 9/29 270대). 0 이면 구간에 나온 차량 수로 자동

BUCKET_SEC     = 50                   # ★ 집계 단위 50초 — 50초 안에 한 번도 보고 없으면 미보고(멈춘 차량)
LOOKBACK_MIN   = 10                   # 알람 시각 기준 과거 몇 분을 볼지
AFTER_MIN      = 10                   # 알람 뒤 몇 분까지 뽑을지 (참고용)
CHUNK_MIN      = 60                   # 한 번에 조회하는 최대 길이 (분) — 느리면 줄인다
HTTP_TIMEOUT   = 600                  # 초
RETRY          = 3

# 판정 기준 — 과거 10분 안에서 50초 구간 값의 최댓값으로 본다 (사건 2건 기준 후보)
TH_CONFIRM_MISS = 100   # 확정: 미보고 100대 이상 또는 HT-STOP 1대 이상
TH_CONFIRM_HT   = 1
TH_ALERT_MISS   = 30    # (확정 아래) 경보: 미보고 30대 이상 또는 JAM 20대 이상
TH_ALERT_JAM    = 20
TH_PRE_MISS     = 10    # 전조: 미보고 10대 이상 또는 JAM 1대 이상
TH_PRE_JAM      = 1

GRADE_RANK = {"정상": 0, "경계": 1, "위험": 2, "초위험": 3}
HERE = os.path.dirname(os.path.abspath(__file__))


# ============================================================
# 공통
# ============================================================
def api_key():
    if API_KEY:
        return API_KEY
    p = os.path.join(HERE, "api_key.txt")
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            lines = f.read().strip().splitlines()
            if lines:
                return lines[0].strip()
    sys.exit("API 키가 없습니다 — 코드 맨 위 API_KEY 에 넣거나 api_key.txt 를 만드세요")


def parse_time(s):
    """'2026-09-12 13:50:00.000+0900' / '2026-09-12 13:50' 등 → datetime (초까지)"""
    s = (s or "").strip().strip('"')
    s = s[:19]
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y/%m/%d %H:%M:%S", "%Y/%m/%d %H:%M"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def bucket_of(t):
    day0 = t.replace(hour=0, minute=0, second=0, microsecond=0)
    sec = int((t - day0).total_seconds()) // BUCKET_SEC * BUCKET_SEC
    return day0 + timedelta(seconds=sec)


def read_text_table(path, must_have):
    """CSV 또는 노트북(json) 파일에서 must_have 헤더가 있는 표를 읽는다."""
    with open(path, encoding="utf-8-sig") as f:
        raw = f.read()
    text = raw
    if raw.lstrip().startswith("{"):
        nb = json.loads(raw)
        text = None
        for c in nb.get("cells", []):
            s = "".join(c["source"]) if isinstance(c["source"], list) else c["source"]
            if must_have in s.splitlines()[0] if s else False:
                text = s
                break
        if text is None:
            sys.exit(f"{path} 안에서 '{must_have}' 헤더가 있는 셀을 못 찾았습니다")
    return list(csv.DictReader(io.StringIO(text)))


# ============================================================
# 1) 알람 시각
# ============================================================
def load_alarms(path):
    rows = read_text_table(path, "시간")
    recs = []
    for r in rows:
        t = parse_time(r.get("시간"))
        if not t:
            continue
        g = (r.get("등급") or "").strip()
        recs.append((t, g, r.get("종합점수", ""), (r.get("알람") or "").strip()))
    recs.sort()
    alarms = []
    prev = 0
    for t, g, sc, al in recs:
        rk = GRADE_RANK.get(g, 0)
        if rk >= 1 and rk > prev:            # 경계/위험/초위험으로 올라간 순간
            alarms.append({"time": t, "grade": g, "score": sc, "alarm_col": al})
        prev = rk
    return alarms


def windows_for(alarms):
    """알람마다 [t-LOOKBACK, t+AFTER] → 겹치면 합치고 CHUNK_MIN 으로 자른다."""
    iv = sorted((a["time"] - timedelta(minutes=LOOKBACK_MIN + 1),
                 a["time"] + timedelta(minutes=AFTER_MIN)) for a in alarms)
    merged = []
    for s, e in iv:
        if merged and s <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    chunks = []
    for s, e in merged:
        while s < e:
            n = min(e, s + timedelta(minutes=CHUNK_MIN))
            chunks.append((s, n))
            s = n
    return chunks


# ============================================================
# 2) 로그프레소 조회 (구간별 파일로 저장 · 이어받기)
# ============================================================
def build_query(frm, to):
    return QUERY_TEMPLATE.format(table=OHT_TABLE, frm=frm.strftime("%Y%m%d%H%M%S"),
                                 to=to.strftime("%Y%m%d%H%M%S"))


def fetch(q, out_path, key):
    url = (LOGPRESSO_BASE.rstrip("/") + "/httpexport/query.csv"
           f"?_apikey={key}&_q={urllib.parse.quote(' '.join(q.split()), safe='')}")
    last = None
    for k in range(RETRY):
        try:
            with requests.get(url, verify=False, timeout=HTTP_TIMEOUT, stream=True) as r:
                if r.status_code != 200:
                    raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")
                tmp = out_path + ".part"
                with open(tmp, "wb") as f:
                    first = True
                    for chunk in r.iter_content(1 << 20):
                        if first and chunk.lstrip().startswith(b"<"):
                            raise RuntimeError("HTML 응답 (키·주소·쿼리 확인): "
                                               + chunk[:200].decode("utf-8", "replace"))
                        first = False
                        f.write(chunk)
                os.replace(tmp, out_path)
                return
        except Exception as e:
            last = e
            time.sleep(3 * (k + 1))
    raise RuntimeError(f"조회 실패 ({RETRY}회): {last}")


# ============================================================
# 3) 50초 집계
# ============================================================
def aggregate(files):
    rep = defaultdict(set)
    jam = defaultdict(set)
    ht = defaultdict(set)
    seen_by_file = []
    for p in files:
        seen = set()
        with open(p, encoding="utf-8-sig", newline="") as f:
            for r in csv.DictReader(f):
                v = (r.get("VEHICLE") or "").strip()
                if not v or (VEHICLE_PREFIX and not v.startswith(VEHICLE_PREFIX)):
                    continue
                t = parse_time(r.get("_time"))
                if not t:
                    continue
                b = bucket_of(t)
                st = (r.get("STATUS") or "").strip()
                rep[b].add(v)
                seen.add(v)
                if st == "7":
                    jam[b].add(v)
                elif st == "8":
                    ht[b].add(v)
        seen_by_file.append((p, seen))
    fleet_auto = max((len(s) for _, s in seen_by_file), default=0)
    fleet = FLEET_SIZE or fleet_auto
    table = {}
    for b in sorted(rep):
        table[b] = {"rep": len(rep[b]), "miss": max(0, fleet - len(rep[b])),
                    "jam": len(jam[b]), "ht": len(ht[b])}
    return table, fleet


# ============================================================
# 4) 판정
# ============================================================
def level(mm, jj, hh):
    if mm >= TH_CONFIRM_MISS or hh >= TH_CONFIRM_HT:
        return "확정"
    if mm >= TH_ALERT_MISS or jj >= TH_ALERT_JAM:
        return "경보"
    if mm >= TH_PRE_MISS or jj >= TH_PRE_JAM:
        return "전조"
    return "정상"


def judge(alarms, table):
    out = []
    for a in alarms:
        t = a["time"]
        s = t - timedelta(minutes=LOOKBACK_MIN)
        w = [v for b, v in table.items() if s <= b <= t]
        if not w:
            out.append({**a, "n": 0, "miss": "", "jam": "", "ht": "", "oht": "데이터없음", "판정": "판정불가"})
            continue
        mm = max(v["miss"] for v in w)
        jj = max(v["jam"] for v in w)
        hh = max(v["ht"] for v in w)
        lv = level(mm, jj, hh)
        verdict = {"확정": "진짜(확정)", "경보": "진짜(확정)", "전조": "진짜(전조)", "정상": "관찰"}[lv]
        out.append({**a, "n": len(w), "miss": mm, "jam": jj, "ht": hh, "oht": lv, "판정": verdict})
    return out


def load_truth(path):
    rows = read_text_table(path, "시간")
    ts = [parse_time(r.get("시간")) for r in rows]
    return [t for t in ts if t]


def score_truth(res, truth, before_min=60, after_min=10):
    """알람 시각이 [사건-60분, 사건+10분] 안이면 그 사건을 잡은 것으로 본다."""
    for r in res:
        r["정답"] = "진짜사건" if any(tt - timedelta(minutes=before_min) <= r["time"] <= tt + timedelta(minutes=after_min)
                                  for tt in truth) else "사건없음"
    return res


# ============================================================
# main
# ============================================================
def main():
    ap = argparse.ArgumentParser(description="스코어 알람 → 과거 10분 OHT 판정")
    ap.add_argument("--score", required=True, help="실시간 스코어 CSV (시간, 등급, 종합점수, 알람 …)")
    ap.add_argument("--truth", help="실제 사건 시각 CSV (헤더 '시간') — 있으면 정밀도 계산")
    ap.add_argument("--out", default=os.path.join(HERE, "out"))
    ap.add_argument("--raw", default=os.path.join(HERE, "oht_raw"))
    ap.add_argument("--test", action="store_true", help="연결 확인 (5줄만)")
    ap.add_argument("--dry-run", action="store_true", help="조회 구간·쿼리만 출력")
    args = ap.parse_args()

    alarms = load_alarms(args.score)
    print(f"[1] 알람 발생 {len(alarms)}건  " + " · ".join(
        f"{g} {n}" for g, n in Counter(a['grade'] for a in alarms).items()))
    if not alarms:
        sys.exit("알람이 없습니다 — 스코어 파일의 '시간' '등급' 컬럼을 확인하세요")
    chunks = windows_for(alarms)
    total_min = sum((e - s).total_seconds() for s, e in chunks) / 60
    print(f"[2] 조회 구간 {len(chunks)}개 · 합계 {total_min/60:.1f}시간 "
          f"({alarms[0]['time']:%m-%d %H:%M} ~ {alarms[-1]['time']:%m-%d %H:%M})")

    if args.dry_run:
        for s, e in chunks:
            print("   ", build_query(s, e))
        return

    key = api_key()
    if args.test:
        s, e = chunks[0]
        q = build_query(s, s + timedelta(minutes=1)) + " | limit 5"
        p = os.path.join(HERE, "_test.csv")
        print("   쿼리:", q)
        fetch(q, p, key)
        with open(p, encoding="utf-8-sig") as f:
            print(f.read()[:1500])
        print("   ↑ VEHICLE, _time, STATUS 가 보이면 정상입니다")
        return

    os.makedirs(args.raw, exist_ok=True)
    files = []
    for i, (s, e) in enumerate(chunks, 1):
        p = os.path.join(args.raw, f"oht_{s:%Y%m%d_%H%M%S}_{e:%H%M%S}.csv")
        files.append(p)
        if os.path.exists(p) and os.path.getsize(p) > 0:
            continue
        t0 = time.time()
        fetch(build_query(s, e), p, key)
        print(f"   {i}/{len(chunks)}  {s:%m-%d %H:%M}~{e:%H:%M}  "
              f"{os.path.getsize(p)/1e6:.1f}MB  {time.time()-t0:.0f}초")

    print("[3] 50초 집계")
    table, fleet = aggregate(files)
    print(f"    구간 {len(table)}개 · 전체 차량 {fleet}대")
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "oht_50s.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["시각", "보고차량", "미보고", "JAM", "HT_STOP"])
        for b, v in sorted(table.items()):
            w.writerow([b.strftime("%Y-%m-%d %H:%M:%S"), v["rep"], v["miss"], v["jam"], v["ht"]])

    print("[4] 알람 판정")
    res = judge(alarms, table)
    if args.truth:
        res = score_truth(res, load_truth(args.truth))
    cols = ["알람시각", "등급", "점수", "알람컬럼", "과거10분_구간수", "미보고_최대", "JAM_최대",
            "HT_STOP_최대", "OHT단계", "판정"] + (["정답"] if args.truth else [])
    with open(os.path.join(args.out, "알람판정.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for r in res:
            row = [r["time"].strftime("%Y-%m-%d %H:%M"), r["grade"], r["score"], r["alarm_col"],
                   r["n"], r["miss"], r["jam"], r["ht"], r["oht"], r["판정"]]
            if args.truth:
                row.append(r["정답"])
            w.writerow(row)

    lines = [f"알람 {len(res)}건 · 기준: 과거 {LOOKBACK_MIN}분 · {BUCKET_SEC}초 집계 · 전체 차량 {fleet}대", ""]
    lines.append("등급 × 판정")
    for g in ("경계", "위험", "초위험"):
        c = Counter(r["판정"] for r in res if r["grade"] == g)
        if c:
            lines.append(f"  {g:4} " + " · ".join(f"{k} {v}" for k, v in c.most_common()))
    if args.truth:
        lines += ["", "정답 비교 (알람이 사건 60분 전 ~ 10분 후 안이면 진짜사건)"]
        for name, sel in (("기존 알람 전체", lambda r: True),
                          ("OHT 진짜 판정만", lambda r: r["판정"].startswith("진짜"))):
            rs = [r for r in res if sel(r)]
            tp = sum(r["정답"] == "진짜사건" for r in rs)
            prec = tp / len(rs) * 100 if rs else 0
            lines.append(f"  {name:12} 알람 {len(rs):4}건 · 진짜사건 {tp:4}건 · 정밀도 {prec:5.1f}%")
        miss_true = [r for r in res if r["정답"] == "진짜사건" and r["판정"] == "관찰"]
        lines.append(f"  진짜사건인데 '관찰'로 판정한 알람 {len(miss_true)}건 (놓친 것 — 확인 필요)")
    txt = "\n".join(lines)
    print(txt)
    with open(os.path.join(args.out, "요약.txt"), "w", encoding="utf-8") as f:
        f.write(txt + "\n")
    print(f"\n완료 → {args.out}")


if __name__ == "__main__":
    main()
