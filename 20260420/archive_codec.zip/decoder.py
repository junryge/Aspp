# -*- coding: utf-8 -*-
"""
decoder.py — 압축 파일(ZIP/7Z/RAR/TAR 등) → Base64 텍스트(.txt)
- 폐쇄망에서 바이너리 못 빼내는 경우, 텍스트 복붙으로 반출하기 위함
- SHA256 해시를 헤더에 기록해서 encoder.py에서 무결성 검증
- 원본 파일명/크기 헤더에 보존
"""

import os
import base64
import hashlib
import threading
import queue
import tkinter as tk
from tkinter import ttk, filedialog, scrolledtext, messagebox
from pathlib import Path

HEADER_VERSION = "v1"
LINE_WIDTH = 76  # Base64 한 줄 너비 (MIME 표준)


def decode_file_to_text(src: Path, dst: Path, log):
    """바이너리 파일을 Base64 텍스트로 변환"""
    size = src.stat().st_size
    log(f"[1/4] 원본 읽는 중: {src.name} ({size:,} bytes)")

    with open(src, 'rb') as f:
        data = f.read()

    log(f"[2/4] SHA256 계산 중...")
    sha = hashlib.sha256(data).hexdigest()

    log(f"[3/4] Base64 인코딩 중...")
    b64 = base64.b64encode(data).decode('ascii')
    # LINE_WIDTH 단위로 줄바꿈
    lines = [b64[i:i + LINE_WIDTH] for i in range(0, len(b64), LINE_WIDTH)]

    log(f"[4/4] 텍스트 파일 저장 중: {dst}")
    with open(dst, 'w', encoding='utf-8', newline='\n') as f:
        f.write(f"# FOLDER_ARCHIVE_BASE64 {HEADER_VERSION}\n")
        f.write(f"# filename: {src.name}\n")
        f.write(f"# size: {size}\n")
        f.write(f"# sha256: {sha}\n")
        f.write(f"# lines: {len(lines)}\n")
        f.write("# ---BEGIN---\n")
        f.write('\n'.join(lines))
        f.write("\n# ---END---\n")

    return size, len(b64), sha


class DecoderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Archive Decoder — ZIP → Base64 텍스트")
        self.root.geometry("760x520")

        self.log_queue = queue.Queue()
        self.worker = None
        self._build_ui()
        self._poll_log()

    def _build_ui(self):
        pad = {'padx': 8, 'pady': 4}

        # 입력 파일
        frm1 = ttk.Frame(self.root); frm1.pack(fill='x', **pad)
        ttk.Label(frm1, text="압축 파일:", width=12).pack(side='left')
        self.var_src = tk.StringVar()
        ttk.Entry(frm1, textvariable=self.var_src).pack(side='left', fill='x', expand=True, padx=4)
        ttk.Button(frm1, text="찾기", command=self._browse_src).pack(side='left')

        # 출력 TXT
        frm2 = ttk.Frame(self.root); frm2.pack(fill='x', **pad)
        ttk.Label(frm2, text="출력 TXT:", width=12).pack(side='left')
        self.var_dst = tk.StringVar()
        ttk.Entry(frm2, textvariable=self.var_dst).pack(side='left', fill='x', expand=True, padx=4)
        ttk.Button(frm2, text="저장", command=self._browse_dst).pack(side='left')

        # 실행 버튼
        frm3 = ttk.Frame(self.root); frm3.pack(fill='x', **pad)
        self.btn_run = ttk.Button(frm3, text="▶ 디코딩 시작 (ZIP → TEXT)", command=self._start)
        self.btn_run.pack(side='left')
        ttk.Button(frm3, text="로그 지우기", command=lambda: self.log_box.delete('1.0', tk.END)).pack(side='left', padx=6)
        ttk.Button(frm3, text="클립보드 복사", command=self._copy_to_clipboard).pack(side='left', padx=6)

        # 진행바
        self.progress = ttk.Progressbar(self.root, mode='indeterminate')
        self.progress.pack(fill='x', padx=8, pady=4)

        # 로그
        self.log_box = scrolledtext.ScrolledText(self.root, height=22, font=('Consolas', 10))
        self.log_box.pack(fill='both', expand=True, padx=8, pady=6)

        # 상태바
        self.var_status = tk.StringVar(value="대기")
        ttk.Label(self.root, textvariable=self.var_status, relief='sunken', anchor='w').pack(fill='x', side='bottom')

    def _browse_src(self):
        path = filedialog.askopenfilename(
            title="압축 파일 선택",
            filetypes=[
                ("압축 파일", "*.zip *.7z *.rar *.tar *.gz *.tgz *.bz2 *.xz"),
                ("모든 파일", "*.*"),
            ],
        )
        if path:
            self.var_src.set(path)
            if not self.var_dst.get():
                self.var_dst.set(str(Path(path).with_suffix(Path(path).suffix + '.txt')))

    def _browse_dst(self):
        path = filedialog.asksaveasfilename(
            title="출력 TXT 저장",
            defaultextension=".txt",
            filetypes=[("텍스트 파일", "*.txt"), ("모든 파일", "*.*")],
        )
        if path:
            self.var_dst.set(path)

    def _copy_to_clipboard(self):
        dst = self.var_dst.get().strip()
        if not dst or not Path(dst).exists():
            messagebox.showwarning("알림", "먼저 디코딩을 완료하세요.")
            return
        try:
            content = Path(dst).read_text(encoding='utf-8')
            self.root.clipboard_clear()
            self.root.clipboard_append(content)
            self.root.update()
            self._log(f"→ 클립보드에 복사됨 ({len(content):,}자)")
            messagebox.showinfo("복사 완료", f"클립보드에 복사되었습니다.\n({len(content):,}자)")
        except Exception as e:
            messagebox.showerror("오류", str(e))

    def _log(self, msg):
        self.log_queue.put(msg)

    def _poll_log(self):
        try:
            while True:
                msg = self.log_queue.get_nowait()
                self.log_box.insert(tk.END, msg + '\n')
                self.log_box.see(tk.END)
        except queue.Empty:
            pass
        self.root.after(100, self._poll_log)

    def _start(self):
        if self.worker and self.worker.is_alive():
            messagebox.showwarning("진행 중", "작업 중입니다.")
            return

        src = self.var_src.get().strip()
        dst = self.var_dst.get().strip()
        if not src or not Path(src).is_file():
            messagebox.showerror("오류", "압축 파일을 선택해주세요.")
            return
        if not dst:
            messagebox.showerror("오류", "출력 경로를 지정해주세요.")
            return

        self.worker = threading.Thread(
            target=self._run, args=(Path(src), Path(dst)), daemon=True,
        )
        self.btn_run.config(state='disabled')
        self.progress.start(10)
        self.worker.start()

    def _run(self, src: Path, dst: Path):
        try:
            self.var_status.set("디코딩 중...")
            self._log(f"{'='*60}")
            size, b64_len, sha = decode_file_to_text(src, dst, self._log)
            self._log(f"\n✔ 완료")
            self._log(f"  원본 크기:  {size:,} bytes")
            self._log(f"  Base64 길이: {b64_len:,} 문자")
            self._log(f"  SHA256:     {sha}")
            self._log(f"  출력:       {dst}")
            self._log(f"{'='*60}")
            self.var_status.set(f"완료 - {size:,} bytes → {b64_len:,} chars")
        except Exception as e:
            self._log(f"\n✘ 실패: {type(e).__name__}: {e}")
            self.var_status.set(f"실패: {e}")
        finally:
            self.root.after(0, lambda: (self.btn_run.config(state='normal'), self.progress.stop()))


if __name__ == '__main__':
    root = tk.Tk()
    app = DecoderApp(root)
    root.mainloop()
